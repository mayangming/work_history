package com.xiaocoder.android.fw.general.http;

import android.content.Context;

import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.base.XCBaseFragment;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonParse;

import org.apache.http.Header;

/**
 * @author xiaocoder
 * @date 2014-12-30 下午5:04:48
 */
public class XCHttpResponseHandler<T> extends AsyncHttpResponseHandler {
    /**
     * 结果集
     */
    public XCJsonBean result_bean;
    /**
     * 回调的接口
     */
    public XCIHttpResult result_http;
    /**
     * 请求是否成功
     */
    public boolean result_boolean;
    /**
     * activity
     */
    public Context context;
    /**
     * gson反射new出的结果集
     */
    public T mResultModel;
    /**
     * model的字节码
     */
    public Class<T> mClassModel;

    /**
     * @param result_http      网络失败成功的回调接口，可以null
     * @param classModel       model的字节码，可以null，如果是null这是jsonbean解析
     */
    @SuppressWarnings("rawtypes")
    @Deprecated
    public XCHttpResponseHandler(XCIHttpResult result_http, Class<T> classModel) {
        super();
        this.result_boolean = false;
        this.result_http = result_http;
        this.mClassModel = classModel;
    }

    public XCHttpResponseHandler() {
        this(null, null);
    }

    @Deprecated
    public XCHttpResponseHandler(XCIHttpResult result_http) {
        this(result_http, null);
    }

    public void setContext(Context context) {
        this.context = context;
    }

    @Override
    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
        XCApplication.base_log.i(XCConfig.TAG_HTTP, "onFailure----->status code " + code);

        e.printStackTrace();

        XCApplication.base_log.i(XCConfig.TAG_HTTP, e.toString());

        if (XCConfig.IS_OUTPUT && headers != null) {
            for (Header header : headers) {
                XCApplication.base_log.i(XCConfig.TAG_HTTP, "headers----->" + header.toString());
            }
        }
        fail();
    }

    public void fail() {
        if (result_http != null) {
            // 回调访问网络失败时的界面
            result_http.onNetFail();
        }
        XCHttpAsyn.closeLoadingDialog();
        // 显示吐司
        XCApplication.base_log.shortToast(XCConfig.NO_NET);

    }

    @Override
    public void onSuccess(int code, Header[] headers, byte[] arg2) {
        XCApplication.base_log.i(XCConfig.TAG_HTTP, "onSuccess----->status code " + code);

        if (XCConfig.IS_OUTPUT && headers != null) {
            for (Header header : headers) {
                XCApplication.base_log.i(XCConfig.TAG_HTTP, "headers----->" + header.toString());
            }
        }

        check(arg2);
        success();
    }

    public void success() {
        if (result_http != null) {
            result_http.onNetSuccess();
        }
    }

    /**
     * onFailure和onSuccess方法调用完成后,调用onFinish()
     */
    @Override
    public void onFinish() {
        super.onFinish();
        XCApplication.base_log.i(XCConfig.TAG_HTTP, "onFinish");
        XCHttpAsyn.httpFinish();
    }

    /**
     * 解析http返回的数据
     *
     * @param response_bytes
     */
    private void check(byte[] response_bytes) {
        try {
            // 解析数据
            String response = new String(response_bytes, XCConfig.ENCODING_UTF8);
            // 把json串打印到控制台
            XCApplication.base_log.i(XCConfig.TAG_HTTP, response);

            result_bean = XCJsonParse.getJsonParseData(response);

            if (mClassModel != null) {
                // gson解析model
                mResultModel = new Gson().fromJson(response, mClassModel);

                // gson解析结果判断
                if (mResultModel == null) {
                    result_boolean = false;
                    XCApplication.base_log.i(XCConfig.TAG_HTTP, "onSuccess , gson解析数据失败");
                    return;
                }
            } else {

                // jsonbean的解析结果判断
                if (result_bean == null) {
                    result_boolean = false;
                    XCApplication.base_log.i(XCConfig.TAG_HTTP, "onSuccess , jsonbean解析数据失败");
                    return;
                }
            }

            yourCompanyLogic();
        } catch (Exception e) {
            e.printStackTrace();
            result_boolean = false;
            XCApplication.base_log.shortToast("解析数据异常");
        }
    }

    /**
     * http请求返回后的状态判断
     */
    public void yourCompanyLogic() {
        if (HTTP_OK.equals(getCode())) {
            if (context instanceof XCBaseActivity) {
                if (((XCBaseActivity) context).isDestroy) {

                    result_boolean = false;
                    XCApplication.base_log.i(XCConfig.TAG_ALOG, context + "--yourCompanyLogic-------acitivity被回收了------");

                } else {
                    result_boolean = true;
                }
            } else {

                result_boolean = true;
            }

        } else {
            result_boolean = false;
        }
    }

    public static final String HTTP_OK = "0"; // "0"表示成功 ，非“0”表示失败
    private final static String CODE = "code";
    private final static String MSG = "msg";

    public String getCode() {
        if (result_bean != null) {
            return result_bean.getString(CODE);
        }
        return "";
    }

    public String getMsg() {
        if (result_bean != null) {
            return result_bean.getString(MSG);
        }
        return "";
    }

    /**
     * 假数据调试界面
     * @param jsonStr 假数据
     * @param classOfT
     */
    public void setTestData(String jsonStr,Class<T> classOfT) {
        result_boolean = true;
        result_bean = new XCJsonBean();
        result_bean.set("code",0);
        Gson gson = new Gson();
        mResultModel = gson.fromJson(jsonStr,classOfT);
    }

}
