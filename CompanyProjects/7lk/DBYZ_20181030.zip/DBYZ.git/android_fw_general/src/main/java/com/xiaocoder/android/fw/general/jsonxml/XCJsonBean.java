package com.xiaocoder.android.fw.general.jsonxml;

import com.xiaocoder.android.fw.general.util.UtilString;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class XCJsonBean implements Serializable {

    private static final long serialVersionUID = 8461633826093329307L;

    public HashMap<String, Object> getParaMap() {
        return paraMap;
    }

    public void setParaMap(HashMap<String, Object> paraMap) {
        this.paraMap = paraMap;
    }

    private HashMap<String, Object> paraMap = new HashMap<String, Object>();

    public Boolean getBoolean(String name) {
        return getBoolean(name, false);
    }

    public Boolean getBoolean(String name, Boolean defaultValue) {
        Object value = paraMap.get(name.toLowerCase());
        if (value != null) {
            try {
                return (Boolean) value;
            } catch (Exception e) {
                e.printStackTrace();
                return defaultValue;
            }
        }
        return defaultValue;
    }

    public String getString(String name) {
        return getString(name, "");
    }

    public String getString(String name, String default_value) {

        Object value = paraMap.get(name.toLowerCase());

        if (value == null || value.equals(JSONObject.NULL)) {
            return default_value;
        }

        return value + "";
    }

    public void setString(String name, String value) {
        paraMap.put(name.toLowerCase(), value);
    }

    public Integer getInt(String name) {
        return getInt(name, 0);
    }

    public Integer getInt(String name, int default_value) {
        Object value = paraMap.get(name.toLowerCase());
        if (value == null) {
            return default_value;
        }
        try {
            if (value instanceof Integer) {
                return (Integer) value;
            } else if (value instanceof String) {
                return Integer.parseInt((String) value);
            } else {
                return default_value;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return default_value;
        }
    }

    public Long getLong(String name) {
        return getLong(name, 0);
    }

    public Long getLong(String name, long default_value) {
        Object value = paraMap.get(name.toLowerCase());
        if (value == null)
            return default_value;
        try {
            if (value instanceof Long) {
                return (Long) value;
            } else if (value instanceof Integer) {
                return (long) ((int) value);
            } else if (value instanceof String) {
                return Long.parseLong((String) value);
            } else {
                return default_value;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return default_value;
        }
    }

    public void setBoolean(String name, Boolean value) {
        paraMap.put(name.toLowerCase(), value);
    }

    public void set(String name, Object value) {
        paraMap.put(name.toLowerCase(), value);
    }

    public void remove(String name) {
        paraMap.remove(name.toLowerCase());
    }

    public Object get(String name) {
        return paraMap.get(name.toLowerCase());
    }

    public void clear() {
        paraMap.clear();
    }

    public XCJsonBean getModel(String name) {
        Object value = paraMap.get(name.toLowerCase());
        if (null == value || value.equals(JSONObject.NULL))
            return new XCJsonBean();
        return (XCJsonBean) value;
    }

    public List<XCJsonBean> getListIsNull(String name) {
        Object value = paraMap.get(name.toLowerCase());
        if (value == null || value.equals(JSONObject.NULL))
            return null;
        return (List<XCJsonBean>) value;
    }

    @SuppressWarnings("unchecked")
    public List<XCJsonBean> getList(String name) {
        Object value = paraMap.get(name.toLowerCase());
        if (value == null || value.equals(JSONObject.NULL))
            return new ArrayList<XCJsonBean>();
        return (List<XCJsonBean>) value;


    }

    public List<String> getStringList(String name) {
        Object value = paraMap.get(name.toLowerCase());
        if (value == null || value.equals(JSONObject.NULL))
            return new ArrayList<String>();
        return (List<String>) value;
    }

    public List<Integer> getIntegerList(String name) {
        Object value = paraMap.get(name.toLowerCase());
        if (value == null || value.equals(JSONObject.NULL))
            return new ArrayList<Integer>();
        return (List<Integer>) value;
    }

    @Override
    public String toString() {
        return paraMap.toString();
    }

    public boolean containsKey(String key) {
        return paraMap.containsKey(key.toLowerCase());
    }

    public String toJson(){
        String json;
        json = toJson(paraMap);
        return UtilString.f(json);
    }

    private String toJson(Map<String,Object> map){
        String result;
        JSONObject jsonObject = new JSONObject();
        try {
            for (String key : map.keySet()){
                Object object = map.get(key);
                if (object instanceof List){//集合
                    JSONArray jsonArray = new JSONArray();
                    for (Object o : (List)map.get(key)){
                        if (o instanceof XCJsonBean){
                            XCJsonBean xcJsonBeanObj = (XCJsonBean) o;
                            String xcJsonBeanJson = toJson(xcJsonBeanObj.getParaMap());
                            JSONObject jsonObjectInner = new JSONObject(xcJsonBeanJson);
                            jsonArray.put(jsonObjectInner);
                        }else {
                            jsonArray.put(o);
                        }
                    }
                    jsonObject.put(key,jsonArray);
                }else if (object instanceof XCJsonBean){//对象
                    XCJsonBean xcJsonBeanObj = (XCJsonBean) object;
                    String xcJsonBeanJson = toJson(xcJsonBeanObj.getParaMap());
                    JSONObject jsonObjectInner = new JSONObject(xcJsonBeanJson);
                    jsonObject.put(key,jsonObjectInner);
                }else {// String、Boolean、Integer、Long
                    jsonObject.put(key,object);
                }
            }
        }catch (JSONException e){
            e.printStackTrace();
        }
        result = jsonObject.toString();
        return result;
    }
}
