package com.xiaocoder.android.fw.general.util;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.PowerManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.xiaocoder.android.fw.general.application.XCApplication;

import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.List;
import java.util.UUID;

public class UtilSystem {
    /**微信包名*/
    public static final String WEIXIN_PACKAGE_NAME = "com.tencent.mm";
    /**QQ包名*/
    public static final String MOBILEQQ_PACKAGE_NAME = "com.tencent.mobileqq";
    /**
     * 获取进程id
     *
     * @return
     */
    public static int getPid() {
        return android.os.Process.myPid();
    }

    /**
     * 获取线程id
     *
     * @return
     */
    public static long getThreadId() {
        return Thread.currentThread().getId();
    }

    /**
     * 程序是否在前台运行
     *
     * @return true为前台
     */
    public static boolean isAppToForeground(Context context) {

        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);

        String packageName = context.getPackageName();

        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();

        if (appProcesses == null) {
            return false;
        }

        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {

            if (appProcess.processName.equals(packageName)
                    && appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                return true;
            }
        }
        return false;
    }

    /**
     * 获取android系统版本号
     *
     * @return 系统版本号
     */
    public static String getOSVersion() {
        String release = android.os.Build.VERSION.RELEASE; // android系统版本号
        release = "android" + release;
        return release;
    }

    /**
     * 获取设备系统SDK API号
     *
     * @return
     */
    public static int getOSVersionSDKINT() {
        int currentapiVersion = android.os.Build.VERSION.SDK_INT;
        return currentapiVersion;
    }


    /**
     * 首先取deviceId，如果没有取macAddress，再没有就自定义一个变量 规则：id开头的一个32位字符串，根据java.util.UUID类生成，
     * 防止重复 如果到java.util.uuid生成的时候，数据被清掉后会被清除。 但对于这样的设备，比较罕见，模拟器是一类
     *
     * @param context 上下文
     * @return
     */
    public static String getDeviceId(Context context) {
        // 没有设备id，则生成保存
        TelephonyManager tm = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
        String deviceId = tm.getDeviceId();
        if (deviceId != null) {
            char[] chs = deviceId.toCharArray();
            int size = chs.length;
            boolean all0 = true;
            for (int i = 0; i < size; i++) {
                if (chs[i] != '0') {
                    all0 = false;
                    break;
                }
            }
            if (all0)
                deviceId = null;
        }
        // 获取不到时
        if (TextUtils.isEmpty(deviceId)) {
            deviceId = getMacAddress();
        }
        return deviceId;
    }

    /**
     * 获取mac地址，获取不到则生成一个
     *
     * @return
     */
//    public static String getMacAddress(Context context) {
//        WifiManager wifiMgr = (WifiManager) context
//                .getSystemService(Context.WIFI_SERVICE);
//        WifiInfo info = (null == wifiMgr ? null : wifiMgr.getConnectionInfo());
//        if (info != null) {
//            String macAddress = info.getMacAddress();
//            if (macAddress == null) {
//                UUID u = UUID.randomUUID();
//                macAddress = "id"
//                        + u.toString().replaceAll("-", "").substring(2);
//            }
//            macAddress = macAddress.toLowerCase();
//            return macAddress.replaceAll(":", "");
//        } else {
//            UUID u = UUID.randomUUID();
//            String uuid = "id" + u.toString().replaceAll("-", "").substring(2);
//            return uuid;
//        }
//    }
    public static String getMacAddress(){
 /*获取mac地址有一点需要注意的就是android 6.0版本后，以下注释方法不再适用，不管任何手机都会返回"02:00:00:00:00:00"这个默认的mac地址，这是googel官方为了加强权限管理而禁用了getSYstemService(Context.WIFI_SERVICE)方法来获得mac地址。*/
        //        String macAddress= "";
//        WifiManager wifiManager = (WifiManager) MyApp.getContext().getSystemService(Context.WIFI_SERVICE);
//        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
//        macAddress = wifiInfo.getMacAddress();
//        return macAddress;

        String macAddress;
        StringBuffer buf = new StringBuffer();
        NetworkInterface networkInterface;
        try {
            networkInterface = NetworkInterface.getByName("eth1");
            if (networkInterface == null) {
                networkInterface = NetworkInterface.getByName("wlan0");
            }
            if (networkInterface == null) {
                return createUUID();
            }
            byte[] addr = networkInterface.getHardwareAddress();
            for (byte b : addr) {
                buf.append(String.format("%02X:", b));
            }
            if (buf.length() > 0) {
                buf.deleteCharAt(buf.length() - 1);
            }
            macAddress = buf.toString();
        } catch (SocketException e) {
            e.printStackTrace();
            return createUUID();
        }
        return macAddress;
    }

    private static String createUUID(){
        UUID u = UUID.randomUUID();
        return  "id"
                + u.toString().replaceAll("-", "").substring(2);
    }

    /**
     * 获取手机型号
     *
     * @return
     */
    public static String getModel() {
        return android.os.Build.MODEL;
    }

    /**
     * 获取手机品牌
     *
     * @return
     */
    public static String getPhoneBrand() {
        return android.os.Build.BRAND;
    }


    /**
     * 获取版本号
     *
     * @param context 上下文
     */
    public static int getVersionCode(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
            return -1;
        }
    }

    /**
     * 获取版本名字
     *
     * @param context 上下文
     */
    public static String getVersionName(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (NameNotFoundException e) {
            return "-1";
        }
    }

    /**
     * 获取网络类型
     * @return 返回网络类型 2g 3g 4g wifi
     */
    public static String getNetworkType() {
        try {
            String strNetworkType = "";
            NetworkInfo networkInfo = ((ConnectivityManager) XCApplication.getInstance().getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected()) {
                if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                    strNetworkType = "WIFI";
                } else if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                    String _strSubTypeName = networkInfo.getSubtypeName();
                    XCApplication.base_log.i("http", "Network getSubtypeName : " + _strSubTypeName);
                    // TD-SCDMA   networkType is 17
                    int networkType = networkInfo.getSubtype();
                    switch (networkType) {
                        case TelephonyManager.NETWORK_TYPE_GPRS:
                        case TelephonyManager.NETWORK_TYPE_EDGE:
                        case TelephonyManager.NETWORK_TYPE_CDMA:
                        case TelephonyManager.NETWORK_TYPE_1xRTT:
                        case TelephonyManager.NETWORK_TYPE_IDEN: //api<8 : replace by 11
                            strNetworkType = "2G";
                            break;
                        case TelephonyManager.NETWORK_TYPE_UMTS:
                        case TelephonyManager.NETWORK_TYPE_EVDO_0:
                        case TelephonyManager.NETWORK_TYPE_EVDO_A:
                        case TelephonyManager.NETWORK_TYPE_HSDPA:
                        case TelephonyManager.NETWORK_TYPE_HSUPA:
                        case TelephonyManager.NETWORK_TYPE_HSPA:
                        case TelephonyManager.NETWORK_TYPE_EVDO_B: //api<9 : replace by 14
                        case TelephonyManager.NETWORK_TYPE_EHRPD:  //api<11 : replace by 12
                        case TelephonyManager.NETWORK_TYPE_HSPAP:  //api<13 : replace by 15
                            strNetworkType = "3G";
                            break;
                        case TelephonyManager.NETWORK_TYPE_LTE:    //api<11 : replace by 13
                            strNetworkType = "4G";
                            break;
                        default:
                            // http://baike.baidu.com/item/TD-SCDMA 中国移动 联通 电信 三种3G制式
                            if (_strSubTypeName.equalsIgnoreCase("TD-SCDMA") || _strSubTypeName.equalsIgnoreCase("WCDMA") || _strSubTypeName.equalsIgnoreCase("CDMA2000")) {
                                strNetworkType = "3G";
                            } else {
                                strNetworkType = _strSubTypeName;
                            }
                            break;
                    }

                    XCApplication.base_log.i("http", "Network getSubtype : " + Integer.valueOf(networkType).toString());
                }
            }
            XCApplication.base_log.i("http", "Network Type : " + strNetworkType);
            return strNetworkType;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
    /**
     * 获取运营商名字
     */
    public static String getOperatorName() {
        try {
            String currentName = "";
            TelephonyManager tm = (TelephonyManager) XCApplication.getInstance().getSystemService(Context.TELEPHONY_SERVICE);
            String imsi = tm.getSubscriberId();
            if (imsi != null) {
                //因为移动网络编号46000下的IMSI已经用完，所以虚拟了一个46002编号，134/159号段使用了此编号 //中国移动
                if (imsi.startsWith("46000") || imsi.startsWith("46002")) {
                    currentName = "1";
                    //中国联通
                } else if (imsi.startsWith("46001")) {
                    currentName = "2";
                    //中国电信
                } else if (imsi.startsWith("46003")) {
                    currentName = "3";
                }
            }
            return currentName;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * app是否在栈顶,false在栈顶
     *
     * @param context 上下文
     * @return true为在后台
     */
    public static boolean isApplicationToBackground(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
        if (!tasks.isEmpty()) {
            ComponentName topActivity = tasks.get(0).topActivity;
            if (!topActivity.getPackageName().equals(context.getPackageName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断微信是否安装
     * @param context
     * @param appPackageName 应用包名
     * @return true 安装;  false 没安装
     */
    public static boolean checkAppInstall(Context context, String appPackageName) {
        if (null != context && !UtilString.isBlank(appPackageName)){
            final PackageManager packageManager = context.getPackageManager();// 获取packagemanager
            List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);// 获取所有已安装程序的包信息
            if (pinfo != null) {
                for (int i = 0; i < pinfo.size(); i++) {
                    String pn = pinfo.get(i).packageName;
                    if (pn.equals(appPackageName)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * 获取application中指定的meta-data
     * @return 如果没有获取成功(没有对应值，或者异常)，则返回值为""
     */
    public static String getAppMetaData(Context ctx, String key) {
        if (ctx == null || TextUtils.isEmpty(key)) {
            return null;
        }
        String resultData = null;
        try {
            PackageManager packageManager = ctx.getPackageManager();
            if (packageManager != null) {
                ApplicationInfo applicationInfo = packageManager.getApplicationInfo(ctx.getPackageName(), PackageManager.GET_META_DATA);
                if (applicationInfo != null) {
                    if (applicationInfo.metaData != null) {
                        resultData = applicationInfo.metaData.getString(key);
                    }
                }

            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return UtilString.f(resultData);
    }

    /**
     * 屏幕息屏判断
     * @param context
     * @return
     */
    public static boolean isScreenOn(Context context){
        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            boolean isScreenOn = pm.isScreenOn();//如果为true，则表示屏幕“亮”了，否则屏幕“暗”了。
            return isScreenOn;
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }
}
