package com.xiaocoder.android.fw.general.base;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import java.util.List;

public abstract class XCBaseFragment extends Fragment implements OnClickListener {

    /**
     * 页面滑动切换的时候，用得到
     * <p/>
     * 如果是bodyfragment，则子类中应该重写返回true
     */
    public boolean isBodyFragment() {
        return false;
    }

    public ViewGroup mContainer;

    @SuppressWarnings("unchecked")
    public <T extends View> T getViewById(int id) {
        return (T) mContainer.findViewById(id);
    }

    public View init(LayoutInflater inflater, int layout_id) {
        ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        mContainer = (ViewGroup) inflater.inflate(layout_id, null);
        mContainer.setLayoutParams(lp);
        // 如果没有以上的会变成包裹高度
        return mContainer;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initWidgets();
        listeners();
    }

    /**
     * 初始化控件
     */
    public abstract void initWidgets();

    /**
     * 初始化监听
     */
    public abstract void listeners();

    public XCBaseActivity getBaseActivity() {
        if (getActivity() != null) {
            return (XCBaseActivity) getActivity();
        }
        return null;
    }

    /**
     * 销毁activity
     */
    public void myFinish() {
        if (getActivity() != null) {
            getBaseActivity().myFinish();
        }
    }

    /**
     * 注意1 : 这里得重写, 否则如果有嵌套fragment的话,回调不到
     * 注意2 : 需要被回调业务代码的那个fragment中的onActivityResult()不要调用super
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 调用子fragment中的onActivityResult方法
        List<Fragment> fragments = getChildFragmentManager().getFragments();
        if (fragments != null) {
            for (Fragment fragment : fragments) {
                printi(fragment.toString() + "----onActivityResult");
                fragment.onActivityResult(requestCode, resultCode, data);
            }
        }
    }

    @Override
    public void onClick(View v) {

    }

    public void myStartActivity(Intent intent) {

        startActivity(intent);
    }


    public void myStartActivity(Class<? extends XCBaseActivity> activity_class, String[] command_keys, Object[] command_values) {
        if (getActivity() != null) {
            getBaseActivity().myStartActivity(activity_class, command_keys, command_values);
        }
    }

    public void myStartActivity(Class<? extends XCBaseActivity> activity_class) {
        if (getActivity() != null) {
            getBaseActivity().myStartActivity(activity_class, new String[]{}, new String[]{});
        }
    }

    public void myStartActivityForResult(Class<? extends XCBaseActivity> activity_class, int requestCode) {
        if (getActivity() != null) {
            getBaseActivity().myStartActivityForResult(activity_class, requestCode, new String[]{}, new String[]{});
        }
    }

    public void myStartActivityForResult(Class<? extends XCBaseActivity> activity_class, int requestCode, String[] command_keys, String[] command_values) {
        if (getActivity() != null) {
            getBaseActivity().myStartActivityForResult(activity_class, requestCode, command_keys, command_values);
        }
    }

    /**
     * 受debug控制开关的打印
     *
     * @param msg 消息
     */
    public void printi(String msg) {
        if (getBaseActivity() != null) {
            getBaseActivity().printi(msg);
        }
    }

    /**
     * 受debug控制开关的打印
     *
     * @param msg 消息
     */
    public void printi(String tag, String msg) {
        if (getBaseActivity() != null) {
            getBaseActivity().printi(tag, msg);
        }
    }

    /**
     * 受debug控制土司
     *
     * @param msg 消息
     */
    public void dShortToast(String msg) {
        if (getBaseActivity() != null) {
            getBaseActivity().dShortToast(msg);
        }
    }

    /**
     * 短土司
     *
     * @param msg 消息
     */
    public void shortToast(String msg) {
        if (getBaseActivity() != null) {
            getBaseActivity().shortToast(msg);
        }
    }

}
