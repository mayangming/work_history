package com.xiaocoder.android.fw.general.application;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.xiaocoder.android_fw_general.R;


/**
 * Created by xilinch on 2015/5/20.
 * 开发的时候，出现错误异常，会直接将异常错误信息通过activity方式直接显示出来
 */
public class XL_ShowExceptionsActivity extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xl_activity_show_exception);
        TextView tv = (TextView) findViewById(R.id.tv);
        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            String text  = bundle.getString("text");
            tv.setText(text);
        }
    }
}
