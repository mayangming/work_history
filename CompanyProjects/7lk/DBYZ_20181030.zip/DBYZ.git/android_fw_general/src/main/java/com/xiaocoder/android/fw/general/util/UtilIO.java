package com.xiaocoder.android.fw.general.util;

import java.io.Closeable;
import java.io.IOException;

/**
 * IO工具
 * @author wpq
 * @version 1.0
 */
public class UtilIO {

    private UtilIO(){
        throw new AssertionError("cannot be instantiated");
    }

    /**
     * 静默关闭流
     * @param closeables one or more classes that implements Closeable
     */
    public static void closeQuietly(Closeable... closeables) {
        if (closeables == null)
            return;
        for (Closeable closeable : closeables) {
            if (closeable != null) {
                try {
                    closeable.close();
                } catch (IOException e) {
//                    e.printStackTrace();
                }
            }
        }
    }
}
