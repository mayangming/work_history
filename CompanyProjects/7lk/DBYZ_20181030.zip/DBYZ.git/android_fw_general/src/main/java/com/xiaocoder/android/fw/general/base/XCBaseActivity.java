package com.xiaocoder.android.fw.general.base;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCIHttpResult;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.android_fw_general.R;

import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

/**
 * 基类
 */
public abstract class XCBaseActivity extends FragmentActivity implements OnClickListener, XCIHttpResult {
    public FragmentManager base_fm;
    /**
     * 整个layout
     */
    public ViewGroup xc_id_model_layout;
    /**
     * title
     */
    public ViewGroup xc_id_model_titlebar;
    /**
     * content
     */
    public ViewGroup xc_id_model_content;
    /**
     * 无网络时显示的界面
     */
    public ViewGroup xc_id_model_no_net;
    /**
     * 无网络界面中的button
     */
    public Button xc_id_no_net_button;

    public <T extends View> T getViewById(int id) {
        return (T) findViewById(id);
    }

    /**
     * 别的应用调用时传进来的
     */
    protected Uri interceptUri() {
        Intent intent = getIntent();
        if (intent != null) {
            Uri uri = intent.getData();
            if (uri != null) {
                return uri;
            }
        }
        return null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (savedInstanceState != null) {
            XCApplication.base_log.i(XCConfig.TAG_SYSTEM_OUT, this + "回收后重新创建");
        }

        // 添加到stack
        ((XCApplication) getApplication()).addActivityToStack(this);
        base_fm = getSupportFragmentManager();

        // 找到页面的布局控件
        xc_id_model_layout = getViewById(R.id.xc_id_model_layout);
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_content = getViewById(R.id.xc_id_model_content);
        xc_id_model_no_net = getViewById(R.id.xc_id_model_no_net);

        // 无网络的背景
        if (xc_id_model_no_net != null) {
            xc_id_model_no_net.setOnClickListener(this);
        }
        xc_id_no_net_button = getViewById(R.id.xc_id_no_net_button);
        if (xc_id_no_net_button != null) {
            xc_id_no_net_button.setOnClickListener(this);
        }
        initWidgets();
        listeners();
        showPage();

    }

    /**
     * 初始化控件
     */
    public abstract void initWidgets();

    /**
     * 设置监听
     */
    public abstract void listeners();

    /**
     * 网络访问失败时, 调用该方法
     */
    @Override
    public void onNetFail() {
        showNoNetLayout();
    }

    /**
     * 显示无网络的界面
     */
    public void showNoNetLayout() {

        if (xc_id_model_content != null) {
            UtilViewShow.setVisible(false, xc_id_model_content);
        }

        if (xc_id_model_no_net != null) {
            UtilViewShow.setVisible(true, xc_id_model_no_net);
        }
    }

    /**
     * 网络访问成功时访问该方法
     */
    @Override
    public void onNetSuccess() {
        showContentLayout();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.xc_id_no_net_button) {
            onNetRefresh();
        }
    }

    /**
     * activity是否调用了结束
     */
    public boolean isDestroy = false;

    @Override
    protected void onDestroy() {
        isDestroy = true;
        super.onDestroy();
        XCApplication.delActivityFromStack(this);

    }

    @Override
    public void finish() {
        XCHttpAsyn.httpFinish();
        super.finish();
    }

    public XCBaseActivity getXCBaseActivity() {
        return this;
    }

    public void addFragment(int layout_id, Fragment fragment, String tag, boolean isToBackStack) {
        FragmentTransaction ft = base_fm.beginTransaction();
        ft.add(layout_id, fragment, tag);
        if (isToBackStack) {
            ft.addToBackStack(tag);
        }
        ft.commitAllowingStateLoss();
        base_fm.executePendingTransactions();
    }

    public void addFragment(int layout_id, Fragment fragment, String tag) {
        addFragment(layout_id, fragment, tag, false);
    }

    public void addFragment(int layout_id, Fragment fragment) {
        addFragment(layout_id, fragment, fragment.getClass().getSimpleName(), false);
    }

    public void removeFragment(Fragment fragment) {
        FragmentTransaction ft = base_fm.beginTransaction();
        ft.remove(fragment);
        ft.commitAllowingStateLoss();
        base_fm.executePendingTransactions();
    }

    public void hideFragment(Fragment fragment) {
        if (fragment != null) {
            FragmentTransaction ft = base_fm.beginTransaction();
            ft.hide(fragment);
            ft.commitAllowingStateLoss();
        }
    }

    public void showFragment(Fragment fragment) {
        FragmentTransaction ft = base_fm.beginTransaction();
        ft.show(fragment);
        ft.commitAllowingStateLoss();
    }

    public void myFinish() {
        UtilInputMethod.hiddenInputMethod(this);
        finish();
    }

    @SuppressWarnings("unchecked")
    public <T extends Fragment> T getFragmentByTag(String tag) {
        return (T) base_fm.findFragmentByTag(tag);
    }

    /**
     * 显示一个fragment
     *
     * @param fragment_class fragment的字节码
     * @param layout_id      布局id
     * @return
     */
    public Fragment showFragmentByClass(Class<? extends Fragment> fragment_class, int layout_id) {
        // 显示点击的哪个fragment
        Fragment fragment = getFragmentByTag(fragment_class.getSimpleName());
        if (fragment == null) {
            try {
                Constructor<? extends Fragment> cons = fragment_class.getConstructor();
                fragment = cons.newInstance();
                addFragment(layout_id, fragment, fragment.getClass().getSimpleName());
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            showFragment(fragment);
        }
        return fragment;
    }

    /**
     * title等别的fragment不隐藏
     */
    public void hideBodyFragment() {
        List<Fragment> fragments = (base_fm.getFragments());
        if (fragments != null) {
            for (Fragment fragment : fragments) {
                if (((XCBaseFragment) fragment).isBodyFragment()) {
                    hideFragment(fragment);
                }
            }
        }
    }

    /**
     * 显示title布局
     *
     * @param isVisible true可见
     */
    public void showTitleLayout(boolean isVisible) {
        if (xc_id_model_titlebar != null) {
            UtilViewShow.setGone(isVisible, xc_id_model_titlebar);
        }
    }

    /**
     * 显示内容布局
     */
    public void showContentLayout() {
        if (xc_id_model_content != null) {
            UtilViewShow.setVisible(true, xc_id_model_content);
        }

        if (xc_id_model_no_net != null) {
            UtilViewShow.setVisible(false, xc_id_model_no_net);
        }
    }

    /**
     * 这里得重写,否则startforresult时, 无法回调到fragment中的方法 , 如果fragment中又有嵌套的话,
     * fragmetn中的该方法也得重写
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        printi("activity---onActivityResult");
        List<Fragment> fragments = base_fm.getFragments();
        if (fragments != null) {
            for (Fragment fragment : fragments) {
                printi("onActivityResult---" + fragment.toString());
                fragment.onActivityResult(requestCode, resultCode, data);
            }
        }
    }

    /**
     * 在onCreate()中调用，默认在onCreate()中 只显示title和content的布局，根据需求是否重写
     */
    public void showPage() {
        showTitleLayout(true);
        showContentLayout();
    }

    /**
     * 启动activity
     *
     * @param activity_class 启动activity的字节码文件
     * @param command_keys   传给该activity的key值
     * @param command_values 传给该activity的value值
     */
    public void myStartActivity(Class<? extends XCBaseActivity> activity_class, String[] command_keys, Object[] command_values) {
        Intent intent = new Intent(this, activity_class);
        int size = command_keys.length;
        for (int i = 0; i < size; i++) {
            Object obj = command_values[i];
            if (obj instanceof String) {
                intent.putExtra(command_keys[i], (String) obj);
            } else if (obj instanceof Boolean) {
                intent.putExtra(command_keys[i], (Boolean) obj);
            } else if (obj instanceof Integer) {
                intent.putExtra(command_keys[i], (Integer) obj);
            } else if (obj instanceof Serializable) {
                intent.putExtra(command_keys[i], (Serializable) obj);
            } else if (obj instanceof Parcelable) {
                intent.putExtra(command_keys[i], (Parcelable) obj);
            } else {
                throw new RuntimeException("myStartActivity()中intent的putExtra参数没有转型");
            }
        }
        startActivity(intent);
        activityAnimation();
    }

    /**
     * 启动activity
     *
     * @param activity_class 启动activity的字节码文件
     * @param key            传给该activity的key值
     * @param command_values 传给该activity的value值
     */
    public void myStartActivity(Class<? extends XCBaseActivity> activity_class, String key, ArrayList<String> command_values) {
        Intent intent = new Intent(this, activity_class);
        intent.putStringArrayListExtra(key, command_values);
        startActivity(intent);
        activityAnimation();
    }

    /**
     * 启动activity
     *
     * @param intent
     */
    public void myStartActivity(Intent intent) {
        startActivity(intent);
        activityAnimation();
    }

    /**
     * 启动activity
     *
     * @param activity_class 启动activity的字节码文件
     */
    public void myStartActivity(Class<? extends XCBaseActivity> activity_class) {
        myStartActivity(activity_class, new String[]{}, new String[]{});
        activityAnimation();
    }

    /**
     * activity的动画效果
     */
    private void activityAnimation() {
        overridePendingTransition(R.anim.xc_anim_right_in, R.anim.xc_anim_left_out);  //此为自定义的动画效果，下面两个为系统的动画效果
    }

    public void myStartActivityForResult(Class<? extends XCBaseActivity> activity_class, int requestCode, String[] command_keys, Object[] command_values) {
        Intent intent = new Intent(this, activity_class);
        int size = command_keys.length;
        for (int i = 0; i < size; i++) {
            Object obj = command_values[i];
            if (obj instanceof String) {
                intent.putExtra(command_keys[i], (String) obj);
            } else if (obj instanceof Boolean) {
                intent.putExtra(command_keys[i], (Boolean) obj);
            } else if (obj instanceof Parcelable) {
                intent.putExtra(command_keys[i], (Parcelable) obj);
            } else {
                throw new RuntimeException("myStartActivity()中intent的putExtra参数没有转型");
            }
        }
        startActivityForResult(intent, requestCode);
    }

    public void myStartActivityForResult(Intent intent, Class<? extends XCBaseActivity> activity_class, int requestCode, int flags) {
        intent.setClass(this, activity_class);
        intent.setFlags(flags);
        startActivityForResult(intent, requestCode);
    }

    public void myStartActivityForResult(Intent intent, int requestCode) {

        startActivityForResult(intent, requestCode);
    }

    public void myStartActivityForResult(Class<? extends XCBaseActivity> activity_class, int requestCode) {
        myStartActivityForResult(activity_class, requestCode, new String[]{}, new String[]{});
    }

    /**
     * 受debug控制开关的打印
     *
     * @param msg 消息
     */
    public void printi(String msg) {
        XCApplication.base_log.i(XCConfig.TAG_SYSTEM_OUT, msg);
    }

    /**
     * 受debug控制开关的打印
     *
     * @param msg 消息
     */
    public void printi(String tag, String msg) {
        XCApplication.base_log.i(tag, msg);
    }

    /**
     * 受debug控制土司
     *
     * @param msg 消息
     */
    public void dShortToast(String msg) {
        XCApplication.base_log.debugShortToast(msg);
    }

    /**
     * 短土司
     *
     * @param msg 消息
     */
    public void shortToast(String msg) {
        XCApplication.base_log.shortToast(msg);
    }
}
