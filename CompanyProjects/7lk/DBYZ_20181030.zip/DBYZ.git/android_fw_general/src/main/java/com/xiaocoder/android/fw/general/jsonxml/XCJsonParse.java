package com.xiaocoder.android.fw.general.jsonxml;

import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/**
 * 2.7版本为以前会对每一个字段都进行解析，2.7版本之后加入控制，使用者可以对部分字段进行控制不再解析
 * */
public class XCJsonParse {

//    //用于针对设定的类型进行限制
//    private static List<String> noParseContentTypes = new ArrayList<>();
//    //设置字段不再进行解析
//    private static List<String> noParseContentkeys = new ArrayList<>();
//
//    public static void setNoParseContentTypes(List<String> noParseContentTypes) {
//        XCJsonParse.noParseContentTypes = noParseContentTypes;
//    }
//
//    public static void setNoParseContentkeys(List<String> no      ParseContentkeys) {
//        XCJsonParse.noParseContentkeys = noParseContentkeys;
//    }

    /** 便利keys中的字段不对其进行解析 */
    public static XCJsonBean getJsonParseData(String json) {

        try {

            if (TextUtils.isEmpty(json)) {
                return null;
            }

            XCJsonBean result = new XCJsonBean();
            JSONObject obj = new JSONObject(json);

            return parse(result, obj);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }
//    private static boolean isParseKey(JSONObject obj, String key) throws JSONException{
//        return obj.has("type") && noParseContentkeys.contains(key) && noParseContentTypes.contains(obj.getString("type"));
//    }
    private static XCJsonBean parse(XCJsonBean result, JSONObject obj) {
        try {
            Object o, object;
            JSONArray array;
            Iterator it = obj.keys();
            while (it.hasNext()) {
                String key = (String) it.next();
//                if (isParseKey(obj,key)){
//                    result.setString(key,obj.getString(key));
//                    continue;
//                }
                o = obj.get(key);
                if (o instanceof JSONObject) {
                    XCJsonBean bean = new XCJsonBean();
                    parse(bean, (JSONObject) o);
                    result.set(key, bean);
                } else if (o instanceof JSONArray) {
                    array = (JSONArray) o;
                    List list = new ArrayList();
                    result.set(key, list);
                    for (int i = 0; i < array.length(); i++) {
                        object = array.get(i);
                        if (object instanceof JSONObject) {
                            XCJsonBean bean = new XCJsonBean();
                            parse(bean, (JSONObject) object);
                            list.add(bean);
                        } else {
                            list.add(object);
                        }
                    }
                } else {
                    result.set(key, o);
                }
            }
            return result;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static List<XCJsonBean> getJsonListParseData(String json) {
        List<XCJsonBean>  list = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(json);
            int size = array.length();
            for (int i = 0; i < size; i++) {
                JSONObject json_object = array.getJSONObject(i);
                if (json_object != null) {
                    XCJsonBean bean = getJsonParseData(json_object.toString());
                    if (bean != null) {
                        list.add(bean);
                    }
                }
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return list;
        }
    }

}
