package com.xiaocoder.android.fw.general.io;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.util.UtilFiles;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.DateFormat;
import java.util.Date;

/**
 * 1 可以控制频率的吐司
 * 2 输出log到控制台
 * 3 输出log到文件
 */
public class XCLog {
    /**
     * 上下文
     */
    private Context context;
    /**
     * 记录上一次的土司时间
     */
    private long last_time;
    private File file;
    /**
     * 短土司的时间间隔
     */
    private int TOAST_SHORT_TIME_GAP;
    /**
     * 长土司的时间间隔
     */
    private int TOAST_LONG_TIME_GAP;

    public XCLog(Context context) {
        this.TOAST_SHORT_TIME_GAP = 2000;
        this.TOAST_LONG_TIME_GAP = 3000;
        this.context = context;
    }

    /**
     * 防止点击频繁, 不断的弹出
     */
    public void longToast(String msg) {
        if (System.currentTimeMillis() - last_time > TOAST_LONG_TIME_GAP) {
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
            last_time = System.currentTimeMillis();
        }
    }

    /**
     * 防止点击频繁, 不断的弹出
     */
    public void shortToast(String msg) {
        if (System.currentTimeMillis() - last_time > TOAST_SHORT_TIME_GAP) {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
            last_time = System.currentTimeMillis();
        }
    }

    /**
     * 调试的toast
     */
    public void debugShortToast(String msg) {
        if (XCConfig.IS_DTOAST) {
            if (System.currentTimeMillis() - last_time > TOAST_SHORT_TIME_GAP) {
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                last_time = System.currentTimeMillis();
            }
        }
    }

    /**
     * 调试的toast
     */
    public void debugLongToast(String msg) {
        if (XCConfig.IS_DTOAST) {
            if (System.currentTimeMillis() - last_time > TOAST_LONG_TIME_GAP) {
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                last_time = System.currentTimeMillis();
            }
        }
    }

    /**
     * 以tag打印到控制台 和 文件
     * update by yangming 2016/4/13 为新添加Log输出添加类名、方法名、行数等相关信息
     * @param tag 标记
     * @param msg 日志内容
     */
    public void i(String tag, String msg) {
        newI(tag,msg);
    }

    /**
     * 以tag打印到控制台 和 文件
     * update by yangming 2016/4/13 为新添加Log输出添加类名、方法名、行数等相关信息
     * @param msg 日志内容
     */
    public void i(String msg) {
        newI(XCConfig.TAG_SYSTEM_OUT,msg);
    }

    /**
     * 打印异常
     * update by yangming 2016/4/13 为新添加Log输出添加类名、方法名、行数等相关信息
     * @param context 上下文对象，用于获取相关类的类名
     * @param msg 日志内容
     */
    public void e(Context context, String msg) {
        newE(XCConfig.TAG_ANDROID_RUNTIME,"Exception-->" + msg);
        writeLog2File("Exception-->" + context.getClass().getSimpleName() + "--" + msg, true);
    }

    /**
     * 打印异常
     * update by yangming 2016/4/13 为新添加Log输出添加类名、方法名、行数等相关信息
     * @param e 异常对象
     */
    public void e(String hint, Exception e) {
        e.printStackTrace();
        newE(XCConfig.TAG_ANDROID_RUNTIME,hint + "--" + "Exception-->" + e.toString() + "--" + e.getMessage());
        // 强制打印日志
        writeLog2File("Exception-->" + hint + "-->" + e.toString() + "--" + e.getMessage(), true);
    }


    /**
     * 写日志到文件中
     *
     * @param content   日志内容
     * @param is_append 是否追加
     */
    public synchronized void writeLog2File(String content, boolean is_append) {

        if (TextUtils.isEmpty(content) || !UtilFiles.isSDcardExist()) {
            return;
        }

        try {
            if (file == null || !file.exists()) {

                File dir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + System.getProperty("file.separator") + XCConfig.APP_ROOT);

                if (!dir.exists()) {
                    dir.mkdirs();
                }

                file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + System.getProperty("file.separator") + XCConfig.LOG_FILE);
                file.createNewFile();
            }

            // 已存在文件
            if (!is_append) {
                // 假如不允许追加写入，则删除 后 重新创建
                file.delete();
                file.createNewFile();
            }

            RandomAccessFile raf = new RandomAccessFile(file, "rw");
            long len = raf.length();
            raf.seek(len);
            raf.write((content + "-->" + DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.LONG).format(new Date()) + "  end  " + System.getProperty("line.separator"))
                    .getBytes(XCConfig.ENCODING_UTF8));

            raf.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // ---------------------------  以下  xilin-----------------------------------------------
    /**
     * 打印异常
     */
    public void e(String tag, String msg, String fileName, boolean is_append) {

        if (XCConfig.IS_PRINTLOG) {
//            Log.e(tag, msg);
            newE(tag,msg);
        }
        writeLog2File(fileName, msg, is_append);
    }

    public synchronized void writeLog2File(String fileName, String content, boolean is_append) {

        if (TextUtils.isEmpty(content) || !UtilFiles.isSDcardExist()) {
            return;
        }
        File saveFile = null;
        try {
            if (file == null || !file.exists()) {

                File dir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + System.getProperty("file.separator") + XCConfig.APP_ROOT);

                if (!dir.exists()) {
                    dir.mkdirs();
                }
            }

            saveFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + System.getProperty("file.separator") + XCConfig.APP_ROOT
                    + File.separator + fileName);
            if (saveFile != null && !saveFile.exists()) {

                saveFile.createNewFile();
            }
            // 已存在文件
            if (!is_append) {
                // 假如不允许追加写入，则删除 后 重新创建
                saveFile.delete();
                saveFile.createNewFile();
            }

            RandomAccessFile raf = new RandomAccessFile(saveFile, "rw");
            long len = raf.length();
            raf.seek(len);
            raf.write((content + "-->" + DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.LONG).format(new Date()) + "  end  " + System.getProperty("line.separator"))
                    .getBytes(XCConfig.ENCODING_UTF8));

            raf.close();
        } catch (Exception e) {

            e.printStackTrace();
        }
    }
    //--------------------以下代码作用是获取调用打印日志代码所在类及方法名和行数，作者：马杨茗 时间：2016年4月12日19:44--------------------------------
//    public static boolean DEBUG = Log.isLoggable(TAG, Log.VERBOSE);
    /** 该方法打印的Log日志能够输出所在的类名、方法名、行数 */
    public void newV(String logValue){
        newV("",logValue);
    }
    /** 该方法打印的Log日志能够输出所在的类名、方法名、行数 */
    public void newV(String tag, String logValue){
        if(XCConfig.IS_OUTPUT){
            String[] logMsg = getLogCurrentMsg();
            Log.v(logMsg[0] + "." + logMsg[1] + "(L:" + logMsg[2] + ") "+tag, TextUtils.isEmpty(logValue) ? "" : logValue);
        }
    }
    /** 该方法打印的Log日志能够输出所在的类名、方法名、行数 */
    public void newD(String logValue){
        newD("",logValue);
    }
    /** 该方法打印的Log日志能够输出所在的类名、方法名、行数 */
    public void newD(String tag, String logValue){
        if(XCConfig.IS_OUTPUT) {
            String[] logMsg = getLogCurrentMsg();
            Log.d(logMsg[0] + "." + logMsg[1] + "(L:" + logMsg[2] + ") "+tag, TextUtils.isEmpty(logValue) ? "" : logValue);
        }
    }
    /** 该方法打印的Log日志能够输出所在的类名、方法名、行数 */
    public void newE(String logValue){
        newE("",logValue);
    }
    /** 该方法打印的Log日志能够输出所在的类名、方法名、行数 */
    public void newE(String tag, String logValue){
            String[] logMsg = getLogCurrentMsg();
            Log.e(logMsg[0] + "." + logMsg[1] + "(L:" + logMsg[2] + ") "+tag, TextUtils.isEmpty(logValue) ? "" : logValue);
    }
    /** 该方法打印的Log日志能够输出所在的类名、方法名、行数 */
    public void newI(String logValue){
        newI("",logValue);
    }
    /** 该方法打印的Log日志能够输出所在的类名、方法名、行数 */
    public void newI(String tag, String logValue){
        if (XCConfig.IS_OUTPUT) {
            String[] logMsg = getLogCurrentMsg();
            Log.i(logMsg[0] + "." + logMsg[1] + "(L:" + logMsg[2] + ") "+tag, TextUtils.isEmpty(logValue) ? "" : logValue);
        }
    }
    /** 该方法打印的Log日志能够输出所在的类名、方法名、行数 */
    public void newW(String logValue){
        newW("",logValue);
    }
    /** 该方法打印的Log日志能够输出所在的类名、方法名、行数 */
    public void newW(String tag, String logValue){
        if(XCConfig.IS_OUTPUT) {
            String[] logMsg = getLogCurrentMsg();
            Log.w(logMsg[0] + "." + logMsg[1] + "(L:" + logMsg[2] + ") "+tag, TextUtils.isEmpty(logValue) ? "" : logValue);
        }
    }
    /**
     * @return 获取当前日志输出所在的方法名
     */
    public String getLogCurrentMethodName() {
        int level = 1;
        StackTraceElement[] stacks = new Throwable().getStackTrace();
        String methodName = stacks[level].getMethodName();
        return methodName;
    }
    /**
     * @return 获取当前日志输出所在的类名
     */
    public String getLogCurrentClassName() {
        /**
         * 系统会返回一个数组，该数组的下标从本类(或方法)开始并逐步向上调用直至最终的类，
         * 如下标为0是 StackTraceElementTest类
         * 下标为1则为MainActivity(这个方法在MainActivity中被调用,如果再在本类中的方法又进行调用则进行+1)，下标为2则表示MainActivity的父类Activity
         */
        int level = 1;
        StackTraceElement[] stacks = new Throwable().getStackTrace();
        String className = stacks[level].getClassName();
        return className;
    }
    /**
     * @return 获取当前日志输出所在的行数
     */
    public int getLogCurrentLineNumber() {
        int level = 1;
        StackTraceElement[] stacks = new Throwable().getStackTrace();
        int lineNumber = stacks[level].getLineNumber();
        return lineNumber;
    }

    /**
     * @return 获取当前日志输出所在的信息的集合 集合内包含类名、方法名、行数
     */
    private String[] getLogCurrentMsg() {
        String[] arr = new String[3];
        int level = 3;
        StackTraceElement[] stacks = new Throwable().getStackTrace();
        StackTraceElement element = stacks[level];
        arr[0] = element.getClassName();
        arr[1] = element.getMethodName();
        arr[2] = element.getLineNumber()+"";
        return arr;
    }
}
