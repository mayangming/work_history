package com.xiaocoder.android.fw.general.util;

import java.io.Closeable;
import java.io.IOException;

/**
 * IO工具
 * @author wpq
 * @version 1.0
 */
public final class IOUtil {

    private IOUtil(){
        throw new AssertionError("cannot be instantiated");
    }

    /**
     * 静默关闭流
     * @param closeables e.g. SQLiteDatabase, Cursor, InputStream etc.
     */
    public static void closeQuietly(Closeable... closeables) {
        if (closeables == null)
            return;
        for (Closeable closeable : closeables) {
            if (closeable != null) {
                try {
                    closeable.close();
                } catch (IOException e) {
//                    e.printStackTrace();
                }
            }
        }
    }
}
