package com.xiaocoder.android.fw.general.adapter;

import android.content.Context;
import android.widget.BaseAdapter;

import java.util.ArrayList;
import java.util.List;
/**
 * 基类adapter
 *
 * @author xiaocoder
 */
public abstract class XCBaseAdapter<T> extends BaseAdapter {
    /**
     * 列表的数据集
     */
    public List<T> list;
    /**
     * 上下文
     */
    public Context context;

    public XCBaseAdapter(Context context, List<T> list) {
        this.list = list;
        this.context = context;
    }

    /**
     * 获取列表集合
     * @return
     */
    public List<T> getList() {
        if (list == null) {
            return list = new ArrayList<T>();
        }
        return list;
    }

    /**
     * 更新列表集合
     * @param list
     */
    public void update(List<T> list) {
        this.list = list;
    }

    @Override
    public int getCount() {
        if (list != null)
            return list.size();
        return 0;
    }

    @Override
    public Object getItem(int position) {
        if (list != null) {
            return list.get(position);
        } else {
            return null;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

}
