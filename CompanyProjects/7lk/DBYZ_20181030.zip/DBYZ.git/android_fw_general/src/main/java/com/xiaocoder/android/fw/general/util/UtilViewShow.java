package com.xiaocoder.android.fw.general.util;


import android.app.Dialog;
import android.view.View;

public class UtilViewShow {

    public static void setVisible(boolean isShow, View view) {
        if (view != null) {
            if (isShow) {
                view.setVisibility(View.VISIBLE);
            } else {
                view.setVisibility(View.INVISIBLE);
            }
        }
    }

    public static void setGone(boolean isShow, View view) {
        if (view != null) {
            if (isShow) {
                view.setVisibility(View.VISIBLE);
            } else {
                view.setVisibility(View.GONE);
            }
        }
    }

    /**
     * 关闭释放当前页面所有对话框
     * @param dialogs
     */
    public static void destoryDialogs(Dialog... dialogs){
        for(int i=0; i<dialogs.length;i++){
            if (dialogs[i] != null && dialogs[i].isShowing()) {
                dialogs[i].dismiss();
            }
            dialogs[i] = null;
        }
    }

}
