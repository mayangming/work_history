package com.xiaocoder.android.fw.general.util;

import android.content.Context;
import android.os.Environment;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

/**
 * @author jingyu
 */
public class UtilFiles {

    /**
     * sd卡是否存在
     *
     * @return true为存在
     */
    public static boolean isSDcardExist() {
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 现在sd卡中创建，如果没有sd卡， 则在内部存储中创建
     *
     * @param dirName 文件夹名字
     * @param context 上下文
     * @return 如果创建成功返回file，失败返回null
     */
    public static File createDirInAndroid(String dirName, Context context) {
        try {
            if (isSDcardExist()) {
                return createDirInSDCard(dirName, context);
            } else {
                return createDirInside(dirName, context);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 在android环境下的SDCard中创建文件夹,如果没有SDCard,则返回null
     *
     * @param dirName 如果传入的为 null或""或"   ",
     *                则返回的file为Environment.getExternalStorageState()目录 如果传入的为
     *                "aa/bb" 或"aa"
     *                则返回的是在Environment.getExternalStorageState()目录下创建aa/bb 或aa文件夹
     * @param context 上下文
     * @return 如果创建成功返回file，失败返回null
     */
    public static File createDirInSDCard(String dirName, Context context) {
        File dir = null;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            // 传入"",或"     ",则返回file =
            // Environment.getExternalStorageDirectory();
            if (dirName == null || dirName.trim().length() == 0) {
                return Environment.getExternalStorageDirectory();// mnt/sdcard
            }
            String dirPath = Environment.getExternalStorageDirectory().getAbsolutePath() + FILE_SEPARATOR + dirName;
            dir = new File(dirPath);

            if (!dir.exists()) {
                dir.mkdirs();
            }
        }
        return dir;
    }

    /**
     * 在android环境下的内部存储中创建文件夹
     *
     * @param dirName 如果传入的为 null或""或"   ", 则返回的file为context.getCacheDir()目录 如果传入的为
     *                "aa/bb" 或"aa" 则在context.getFilesDir()目录下创建aa/bb或aa文件夹
     * @param context
     * @return 如果创建成功返回file，失败返回null
     */
    public static File createDirInside(String dirName, Context context) {
        File dir = null;
        if (dirName == null || dirName.trim().length() == 0) {
            return context.getCacheDir();// 内部存储下的/data/data/<package name>/cache
        }
        String dirPath = context.getFilesDir() + FILE_SEPARATOR + dirName;
        dir = new File(dirPath);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    /**
     * 先在sd卡中创建，如果没有sd卡， 则在内部存储中创建
     *
     * @param dirName  文件夹名
     * @param fileName 文件名
     * @param context  上下文
     * @return 如果创建成功返回file，失败返回null
     */
    public static File createFileInAndroid(String dirName, String fileName, Context context) {
        try {
            if (isSDcardExist()) {
                return createFileInSDCard(dirName, fileName, context);
            } else {
                return createFileInside(dirName, fileName, context);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 在SDCard中创建文件
     *
     * @param dirName  "aa/bb" "aa"都可,如果是null
     *                 或""默认为在Environment.getExternalStorageState()目录下创建文件
     * @param fileName 文件名-->"abc.txt"格式, 不可写成"abc/ed.txt"
     * @param context  上下文
     * @return 返回一个创建了文件夹和文件的目录, 如果没有SD卡, 返回null
     * @throws java.io.IOException
     */
    public static File createFileInSDCard(String dirName, String fileName, Context context) throws IOException {
        File dir = createDirInSDCard(dirName, context);
        if (dir == null) {
            return null;
        }
        File file = new File(dir, fileName);
        if (!file.exists()) {
            file.createNewFile();
        }
        return file;
    }

    /**
     * 在内部存储中创建文件
     *
     * @param dirName  "aa/bb","aa"都可,如果是null 或""默认为在context.getCacheDir()目录下创建文件
     * @param fileName 文件名-->"abc.txt"格式, 不可写成"abc/ed.txt"
     * @param context  上下文
     * @return 返回一个创建了文件夹和文件的目录
     * @throws java.io.IOException
     */
    public static File createFileInside(String dirName, String fileName, Context context) throws IOException {
        File file = new File(createDirInside(dirName, context), fileName);
        if (!file.exists()) {
            file.createNewFile();
        }
        return file;
    }

    /**
     * 从资产目录获取输入流
     *
     * @param fileName 文件名
     * @return 目标文件输入流
     * @throws IOException
     */
    public static InputStream getInputStreamFromAssets(Context context, String fileName) throws IOException {
        if (context == null || UtilString.isBlank(fileName)) {
            return null;
        }
        return context.getResources().getAssets().open(fileName);
    }

    /**
     * 读取本地文件
     *
     * @param name 文件路径
     * @return 文件内容
     */
    public static String readFile(String name) {
        String str = "";
        InputStreamReader isr = null;
        BufferedReader br = null;
        try {
            File urlFile = new File(name);
            if (!urlFile.exists()) {
                return str;
            }
            isr = new InputStreamReader(new FileInputStream(urlFile), "UTF-8");
            br = new BufferedReader(isr);
            String mimeTypeLine = null;
            while ((mimeTypeLine = br.readLine()) != null) {
                str = str + mimeTypeLine;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != isr) {
                    isr.close();
                }
                if (null != br) {
                    br.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return str;
    }

    /**
     * 换行符
     */
    public static final String LINE_SEPARATOR = System.getProperty("line.separator");
    /**
     * 如环境变量的路径分隔符
     */
    public static final String PATH_SEPARATOR = System.getProperty("path.separator");
    /**
     * c:// 文件分隔符
     */
    public static final String FILE_SEPARATOR = System.getProperty("file.separator");

    /**
     * 把输入流转为字节数组
     *
     * @param in ：InputStream
     * @return byte[] :字节数组
     */
    public static byte[] toBytesByInputStream(InputStream in) {
        ByteArrayOutputStream baos = null;
        try {
            baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];

            for (int len = -1; (len = in.read(buffer)) != -1; ) {
                baos.write(buffer, 0, len);
            }
            in.close();
            baos.close();
            return baos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (baos != null) {
                        try {
                            baos.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }

    /**
     * 把输入流转为文件
     *
     * @param in 输入流
     * @param file 目标文件
     * @throws java.io.IOException
     */
    public static void toFileByInputStream(InputStream in, File file) {
        OutputStream os = null;
        try {
            os = new FileOutputStream(file);// 该句只会创建文件,不会创建文件夹,否则异常
            byte[] buffer = new byte[10240];
            int len = -1;
            while ((len = in.read(buffer)) != -1) {
                os.write(buffer, 0, len);
            }
            in.close();
            os.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (os != null) {
                        try {
                            os.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }

    /**
     * 判断文件是否存在
     * */
    public static boolean fileIsExists(String strFile)
    {
        try
        {
            File f=new File(strFile);
            if(!f.isFile())
            {
                return false;
            }

        }
        catch (Exception e)
        {
            return false;
        }

        return true;
    }

    /**
     * 删除文件夹
     */
    public static void removeDir(File dir) {
        boolean isGoOnDeleting = true; // 如果是实际中, 可能存在正在删除, 而应用此时退出的情况
        if (dir != null && dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles();
            for (File file : files) {// 如果目录是系统级文件夹，java没有访问权限，那么会返回null数组。最好加入判断。
                if (files != null) {
                    // 2,对遍历到的file对象判断是否是目录。
                    if (isGoOnDeleting) {
                        if (file.isDirectory()) {
                            removeDir(file);
                        } else {
                            file.delete();
                        }
                    } else {
                        break;
                    }
                }
            }
            dir.delete();
        }
    }

    /**
     * 复制文件夹
     *
     * @param fromPath
     * @param toPath
     * @return
     * @throws IOException
     */
    public static void copyDirAndFile(String fromPath, String toPath) throws IOException {
        // 1.将原始路径和目标路径转为File
        File fromFile = new File(fromPath);
        if (!fromFile.exists()) {
            return;
        }
        File toFile = new File(toPath);
        // 2.如果目标路径不存在，则创建该路径
        if (!toFile.exists()) {
            toFile.mkdirs();
        }
        // 3.判断原始路径是一个目录还是一个文件，如果是一个文件，直接复制，
        // 递归遍历

        if (fromFile.isFile()) {
            copyFile(fromFile.getAbsolutePath(), toPath + fromFile.getName());
        } else if (fromFile.isDirectory()) {
            // fromFile = new File(fromFile.getAbsoluteFile() + "/");
            File[] listFiles = fromFile.listFiles();
            if (listFiles == null) {
                return;
            }
            for (File file : listFiles) {
                if (file.isDirectory()) {
                    // 4.如果是一个文件夹，得到该文件夹下的所有文件，需要将该文件夹的所有文件都复制，文件夹需要
                    // 递归遍历,因为是文件夹，所以最后都要加上"/"
                    copyDirAndFile(file.getAbsolutePath() + "/", toPath + "/" + file.getName() + "/");
                } else {
                    // 5.是一个目录还是一个文件，如果是一个文件，直接复制，
                    copyFile(file.getAbsolutePath(), toPath + "/" + file.getName());
                }
            }
        }
    }

    /**
     * 拷贝文件用字节流
     *
     * @param srcPath
     * @param destPath
     */
    public static void copyFile(String srcPath, String destPath) {
        InputStream in = null;
        OutputStream out = null;
        try {
            // 打开流
            out = new FileOutputStream(destPath);
            in = new FileInputStream(srcPath);

            // 使用流
            byte[] data = new byte[1024];
            for (int len = -1; (len = in.read(data)) != -1; ) {
                out.write(data, 0, len);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            // 关闭流
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if (out != null) {
                        out.close();
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
