package com.xiaocoder.android.fw.general.fragment;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.base.XCBaseFragment;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilOom;
import com.xiaocoder.android_fw_general.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.UUID;

/**
 * @author xiaocoder
 * @Description: 打开图片
 * @date 2015-1-6 下午10:50:22
 */
public class XCCameraPhotoFragment extends XCBaseFragment {
    ImageView xc_id_photo_camera_imageview;
    public static final int CAMERA_REQUEST_CODE = 0;// 打开当地相册的请求码
    public static final int RESIZE_REQUEST_CODE = 1;// 裁剪的请求码

    public File temp_photo_file;
    //图片临时文件夹
    private File takePhotoFolder;

    public boolean is_allow_resize; // 是否允许裁剪图片，默认为不允许
    public int image_id;

    public interface OnCaremaSelectedFileListener {
        void onCaremaSelectedFile(File file);
    }

    OnCaremaSelectedFileListener listener;

    public void setOnCaremaSelectedFileListener(OnCaremaSelectedFileListener listener) {
        this.listener = listener;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return init(inflater, R.layout.xc_l_fragment_photo_camera);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.xc_id_fragment_photo_camera_imageview) {
            getTakePhoto();
        }
    }

    public void getTakePhoto() {
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            Intent cameraIntent = new Intent("android.media.action.IMAGE_CAPTURE");
            takePhotoFolder = new File(Environment.getExternalStorageDirectory(),
                    "/QLK/");
            if(!takePhotoFolder.exists()) {
                takePhotoFolder.mkdirs();
            }
            temp_photo_file = new File(takePhotoFolder, UUID.randomUUID
                    ().toString()+".jpg");

            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(temp_photo_file));
            cameraIntent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
            try {
                startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
            } catch(ActivityNotFoundException e) {
                Toast.makeText(getActivity(), "您没有拍照功能，此功能不能正常进行！", Toast.LENGTH_LONG).show();
            } catch(Exception e) {
                e.printStackTrace();
            }

        } else {
            XCApplication.base_log.shortToast("请插入sd卡");
        }
    }

    public void resizeImage(Uri uri) {
        try {
            Intent intent = new Intent("com.android.camera.action.CROP");
            intent.setDataAndType(uri, "image/*");
            intent.putExtra("crop", "true");
            intent.putExtra("aspectX", 1);
            intent.putExtra("aspectY", 1);
            intent.putExtra("outputX", 150);
            intent.putExtra("outputY", 150);
            intent.putExtra("return-data", true);
            startActivityForResult(intent, RESIZE_REQUEST_CODE);
        } catch(ActivityNotFoundException e) {
            Toast.makeText(getActivity(), "您没有相册功能，此功能不能正常进行！", Toast.LENGTH_LONG).show();
        } catch(Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        } else {
            switch (requestCode) {
                case CAMERA_REQUEST_CODE:
                    if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                        if (temp_photo_file != null) {
                            Uri uri = Uri.fromFile(temp_photo_file);
                            if (is_allow_resize) {
                                resizeImage(uri);
                            } else {
                                Bitmap bitmap = UtilOom.getBitmapFromUriForLarge(getActivity(),uri, 1000);// 采样率压缩提到1000  防止图片失真  add by  xd
                                getImage(bitmap);
                            }
                        }else{
                            XCApplication.base_log.shortToast("获取图片失败");
                        }
                    } else {
                        XCApplication.base_log.shortToast("未找到存储卡，无法存储照片！");
                    }
                    break;

                case RESIZE_REQUEST_CODE:
                    // 裁剪之后,关闭裁剪的activity后,会调用这个方法,
                    if (data != null) { // 加入data不等于空,即可以去到bitmap
                        getResizeImage(data);
                    }
                    break;
            }
        }
    }

    // 从这里获取最后返回的图片
    private void getImage(Bitmap bitmap) {
        FileOutputStream fos = null;
        try {
            if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                if (takePhotoFolder != null && takePhotoFolder.exists()) {
                    UtilFiles.removeDir(takePhotoFolder);
                }
                File file = new File(createDir(), "photo" + getTime() + ".jpg");
                fos = new FileOutputStream(file);
//                bitmap = Bitmap.createScaledBitmap(bitmap, 700, 700, true);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);//压缩图片质量 减少上传图片大小  add by  xd
                fos.close();
                if (listener != null) {
                    listener.onCaremaSelectedFile(file);
                }
            } else {
                XCApplication.base_log.shortToast("未检测到SD卡");
                if (listener != null) {
                    listener.onCaremaSelectedFile(null);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                    if(null != bitmap){
                        bitmap.recycle();
                        bitmap = null;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 这里获得裁剪后 图片数据，
     * @param data 按照预定规格对图片进行大小700*700以及显示质量90%的调整。目的降低OOM
     */
    public void getResizeImage(Intent data) {
        Bundle extras = data.getExtras();
        if (extras != null) {
            Bitmap bitmap = extras.getParcelable("data");
            // 保存到本地
            FileOutputStream fos = null;
            try {
                if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                    if (temp_photo_file != null && temp_photo_file.exists()) {
                        temp_photo_file.delete();
                    }
                    File file = new File(createDir(), "photo" + getTime() + ".jpg");
                    fos = new FileOutputStream(file);
                    bitmap = Bitmap.createScaledBitmap(bitmap, 700, 700, true);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
                    fos.close();
                    if (listener != null) {
                        listener.onCaremaSelectedFile(file);
                    }
                } else {
                    XCApplication.base_log.shortToast("未检测到SD卡");
                    if (listener != null) {
                        listener.onCaremaSelectedFile(null);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                        if(null != bitmap){
                            bitmap.recycle();
                            bitmap = null;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public File createDir() {
        File dir = new File(Environment.getExternalStorageDirectory() + "/" + XCConfig.CHAT_PHOTO_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    public String getTime() {
        return UtilDate.format(new Date(), UtilDate.FORMAT_FULL_S);
    }

    public void setImage(int drawable_id) {
        this.image_id = drawable_id;
        if (xc_id_photo_camera_imageview != null) {
            xc_id_photo_camera_imageview.setImageResource(drawable_id);
        }
    }

    public void setIsAllowResizeImage(boolean is_allow_resize) {
        this.is_allow_resize = is_allow_resize;
    }

    @Override
    public void initWidgets() {
        xc_id_photo_camera_imageview = getViewById(R.id.xc_id_fragment_photo_camera_imageview);
        if (image_id > 0) {
            xc_id_photo_camera_imageview.setImageResource(image_id);
        }
    }

    @Override
    public void listeners() {
        xc_id_photo_camera_imageview.setOnClickListener(this);
    }
}
