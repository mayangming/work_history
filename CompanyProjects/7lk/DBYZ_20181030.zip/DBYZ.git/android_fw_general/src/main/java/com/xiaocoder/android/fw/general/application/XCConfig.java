package com.xiaocoder.android.fw.general.application;

/**
 * 配置类
 *
 * @author xiaocoder
 */
public class XCConfig {

    public synchronized static void initDebug(boolean isDev) {
        if (isDev) {

            IS_DTOAST = true;
            IS_OUTPUT = true;
            IS_INIT_CRASH_HANDLER = true;
            IS_PRINTLOG = true;
            IS_SHOW_EXCEPTION_ACTIVITY = true;

        } else {

            IS_DTOAST = false;
            IS_OUTPUT = false;
            IS_INIT_CRASH_HANDLER = true;
            IS_PRINTLOG = false;
            IS_SHOW_EXCEPTION_ACTIVITY = false;
        }
    }

    /**
     * 不要用system.out输出，用i(),i方法里默认的是该tag
     */
    public static String TAG_SYSTEM_OUT = "System.out";
    /**
     * 可查看如url 参数 返回的json等
     */
    public static String TAG_HTTP = "http";
    /**
     * 可查看如url 参数 返回的json等
     */
    public static String TAG_HTML5 = "html5";
    /**
     * DB的相关操作记录
     */
    public static String TAG_DB = "db";
    /**
     * 如异常、重要的日志等用该tag，e()方法里就是用了该tag
     */
    public static String TAG_ALOG = "alog";
    public static String TAG_ANDROID_RUNTIME = "AndroidRuntime";
    /**
     * app的名字与根目录
     */
    public static String APP_ROOT = "app_ymz";
    /**
     * 打印到日志文件
     */
    public static String LOG_FILE = APP_ROOT + "/log";
    /**
     * crash日志文件
     */
    public static String CRASH_DIR = APP_ROOT + "/crash";
    /**
     * chat
     */
    public static String CHAT_DIR = APP_ROOT + "/chat";
    public static String CHAT_PHOTO_DIR = CHAT_DIR + "/photo";
    public static String CHAT_VOICE_DIR = CHAT_DIR + "/voice";
    public static String CHAT_MOIVE_DIR = CHAT_DIR + "/moive";
    public static String PDF_DIR = CHAT_DIR + "/pdf";
    /**
     * 缓存目录的路径
     */
    public static String CACHE_DIR = APP_ROOT + "/cache";
    /**
     * sp文件 , 仅文件名
     */
    public static String SP_FILE = APP_ROOT + "_setting";
    /**
     * sp文件 , h5用到的
     */
    public static String SP_HTML = APP_ROOT + "_htmlsp";
    /**
     * DB文件
     */
    public static String DB_DIR = APP_ROOT + "/db";
    /**
     * 打印测试的文件
     */
    public static String TEMP_PRINT_FILE = APP_ROOT + "/temp_print_file";
    /**
     * 没网的提示
     */
    public static String NO_NET = "网络有误";

    public static String ENCODING_UTF8 = "utf-8";

    /**
     * 是否打印日志到控制台
     */
    public static boolean IS_OUTPUT;
    /**
     * 是否弹出调试的土司
     */
    public static boolean IS_DTOAST;
    /**
     * 是否初始化crashHandler,上线前也不关
     */
    public static boolean IS_INIT_CRASH_HANDLER;
    /**
     * 是否打印异常的日志到屏幕， 上线前得关
     */
    public static boolean IS_SHOW_EXCEPTION_ACTIVITY;
    /**
     * 是否打印日志到手机文件中,i()中的上线前全部关闭
     */
    public static boolean IS_PRINTLOG;

    public static String RMB = "¥";
    /**
     * 乘号
     */
    public static String X = "×";
    /**
     * 下滑线
     */
    public static String UNDERLINE = "_";

    public static String MAIN_ACTIVITY_NAME = "JS_MainActivity";
}
