package com.xiaocoder.android.fw.general.http;

import android.app.Activity;
import android.content.Context;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilSystem;

import org.apache.http.entity.StringEntity;

import java.io.UnsupportedEncodingException;

/**
 * 1如果是上传文件:
 * 可以 params.put("字段", new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/0912/compass.png"));
 * <p/>
 * 2不管是失败还是完成都会调用onFinish()方法
 * <p/>
 * 3下载数据可以用byte[]
 * <p/>
 * 4是异步的
 * params.put("字段", new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/0912/compass.png"));
 * isShowDialog 是否在加载网络时显示dialog
 * isAllowConcurrent 当设置了该参数时 ,isNeting就无效了 ,如果isAllowConcurrent为true ,则默认同一时刻可以访问很多请求, 如果为false,则只有前一个网络请求完成了,再点击时才有效
 */
public class XCHttpAsyn {
    private static AsyncHttpClient client = new AsyncHttpClient();

    public static HttpDialog httpDialog = HttpDialog.getInstance();

    /**
     * 是否正在联网, 防止不停的点击带有访问网络的按钮
     */
    public static boolean isNeting;

    /**
     * 设置链接超时，如果不设置，默认为15
     */
    static {
        client.setTimeout(15000);

    }

    public static AsyncHttpClient getClient() {
        return client;
    }

    public static void getAsyn(Context context, String urlString, RequestParams params, XCHttpResponseHandler res) {
        getAsyn(true, true, true, context, urlString, params, res);
    }

    public static void getAsyn(boolean isShowDialog, Context context, String urlString, RequestParams params, XCHttpResponseHandler res) {
        getAsyn(true, true, isShowDialog, context, urlString, params, res);
    }

    @Deprecated
    public static void getAsyn(boolean isAllowConcurrent, boolean isShowDialog, Context context, String urlString, RequestParams params, XCHttpResponseHandler res) {
        getAsyn(true, isAllowConcurrent, isShowDialog, context, urlString, params, res);
    }

    /**
     * @param isSecret          是否加密
     * @param isAllowConcurrent 是否允许同时多个请求访问
     * @param isShowDialog      是否显示网络加载的dialog
     * @param context           上下文
     * @param urlString         url
     * @param params            请求参数
     * @param res               回调对象
     */
    public static void getAsyn(boolean isSecret, boolean isAllowConcurrent, boolean isShowDialog, Context context, String urlString, RequestParams params, XCHttpResponseHandler res) {
        XCApplication.base_log.i(XCConfig.TAG_HTTP, params.toString());
        if (isAllowConcurrent || !isNeting) {
            isNeting = true;
            showLoadingDialog(isShowDialog, context);
            if (isSecret) {
                secret(params, context);
            }
            XCApplication.base_log.i(XCConfig.TAG_HTTP, urlString + "------>get http url");
            res.setContext(context);
            client.get(urlString, params, res);
        }
    }


    public static void postAsyn(Context context, String urlString, RequestParams params, XCHttpResponseHandler res) {
        postAsyn(true, context, urlString, params, res);
    }

    public static void postAsyn(boolean isShowDialog, Context context, String urlString, RequestParams params, XCHttpResponseHandler res) {
        postAsyn(true, isShowDialog, context, urlString, params, res);
    }

    @Deprecated
    public static void postAsyn(boolean isAllowConcurrent, boolean isShowDialog, Context context, String urlString, RequestParams params, XCHttpResponseHandler res) {
        XCApplication.base_log.i(XCConfig.TAG_HTTP, params.toString());
        if (isAllowConcurrent || !isNeting) {
            isNeting = true;
            showLoadingDialog(isShowDialog, context);
            secret(params, context);
            XCApplication.base_log.i(XCConfig.TAG_HTTP, urlString + "------>post http url");
            res.setContext(context);
            client.post(urlString, params, res);
        }
    }


    public static void postAsync(Context context, String url, String body, XCHttpResponseHandler responseHandler) {
        postAsync(true, context, url, body, responseHandler);
    }

    public static void postAsync(boolean isShowDialog, Context context, String url, String body, XCHttpResponseHandler responseHandler) {
        postAsync(true, isShowDialog, context, url, body, responseHandler);
    }

    public static void postAsync(boolean isAllowConcurrent, boolean isShowDialog, Context context, String url, String body, XCHttpResponseHandler responseHandler) {
        XCApplication.base_log.i(XCConfig.TAG_HTTP, "POST -> URL：" + url + " ~ BODY：" + body);
        try {
            if (isAllowConcurrent || !isNeting) {
                isNeting = true;
                showLoadingDialog(isShowDialog, context);
                secret(null, context);
                responseHandler.setContext(context);
                client.post(context, url, new StringEntity(body, "UTF-8"), "application/json", responseHandler);
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }
    /**
     * 显示加载的dialog
     *
     * @param isShowDialog 是否显示dialog
     * @param context      上下文
     */
    public static void showLoadingDialog(boolean isShowDialog, Context context) {
        if (isShowDialog) {
            if (context instanceof Activity && !((Activity) context).isFinishing()) {
                // 如果是activity页面 且 activity没有关闭
                httpDialog.getDialog(context);
                httpDialog.show();
                XCApplication.base_log.i(XCConfig.TAG_HTTP, "showLoadingDialog");
            }
        }
    }

    /**
     * 关闭正在加载的dialog
     */
    public static void closeLoadingDialog() {
        if (httpDialog != null) {
            httpDialog.dismiss();
            XCApplication.base_log.i(XCConfig.TAG_HTTP, "closeLoadingDialog");
        }
    }

    /**
     * http请求返回后会调用到
     */
    public static void httpFinish() {
        closeLoadingDialog();
        isNeting = false;
    }

    /**
     * 加密
     *
     * @param params  原始参数集合
     * @param context 上下文
     */
    public static void secret(RequestParams params, Context context) {
        client.addHeader("_p", "0"); // V2.6 为0
        client.addHeader("_o", "1"); // V2.6 医生app
        client.addHeader("_n", "1"); // V2.6 原生
        client.addHeader("_v", UtilSystem.getVersionName(context));// 版本号，必填
        client.addHeader("_m", UtilSystem.getPhoneBrand() + " " + UtilSystem.getModel());
        client.addHeader("_nv", XCApplication.base_sp.getString("htmlVersion", "1.0"));//  h5页面版本号

        if (params != null) {
            String token = XCApplication.base_sp.getString("token", "");
            if (!UtilString.isBlank(token) && !params.has("token")) {
                params.put("token", token);
            }
            // add by 崔毅然 on 216/9/21 start  永祥要求把医生id放在公共参数中，因部分接口需要传doctorId,判断是否已经有doctorId
            String doctorId = XCApplication.base_sp.getString("doctorId", "");
            if (!UtilString.isBlank(doctorId) && !params.has("doctorId")) {
                params.put("doctorId", doctorId);
            }
            if (!UtilString.isBlank(doctorId) && !params.has("userId")) {
                params.put("userId", doctorId);
            }
            // add by 崔毅然 on 216/9/21 end  永祥要求把这个放在公共参数中
            XCApplication.base_log.i(XCConfig.TAG_HTTP, "plus public params-->" + params.toString());
        }
    }

}
