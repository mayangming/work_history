package com.xiaocoder.android.fw.general.view;

import android.content.Context;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.xiaocoder.android_fw_general.R;

/**
 *
 * @author xilinch on 2015/12/2.
 * @modifier xilinch 2015/12/2 14:34.
 * @description
 */
public class XLDeleteEditText extends RelativeLayout{

    /**
     * 输入按钮
     */
    private EditText et;
    /**
     * 删除按钮
     */
    private ImageView ivClose;
    /**
     * 文本变化监听器
     */
    private OnEditTextLengthChangedListener onEditTextLengthChangedListener;

    public XLDeleteEditText(Context context){
        super(context);
        initViews();
    }

    public XLDeleteEditText(Context context, AttributeSet attrs){
        super(context,attrs);
        initViews();
    }

    public XLDeleteEditText(Context context, AttributeSet attrs, int defStyle){
        super(context,attrs,defStyle);
        initViews();
    }

    private void initViews(){

        et = new EditText(getContext());
        et.setTextSize(18);
        et.setTextColor(getResources().getColor(R.color.c_gray_6a6a6a));
        et.setSingleLine();
        et.setBackgroundColor(getResources().getColor(R.color.c_white_ffffff));

        ivClose = new ImageView(getContext());
        ivClose.setImageResource(R.drawable.xc_d_main_close);
        RelativeLayout.LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        params.setMargins(0,0,30,0);
        addView(et, params);

        RelativeLayout.LayoutParams params1 = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params1.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        params1.addRule(RelativeLayout.CENTER_VERTICAL);
        params1.setMargins(0,0,10,0);
        addView(ivClose, params1);

        initListener();
    }

    private void initListener(){
        ivClose.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                //一次删除一个
//                String text = et.getText().toString();
//                if(TextUtils.isEmpty(text)){
//                    return;
//                } else {
//                    text = text.substring(0,text.length() - 1);
//                    et.setText(text);
//                    et.setSelection(text.length());
//                }
                //全删除
                et.setText("");
            }
        });

        ivClose.setOnLongClickListener(new OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                et.setText("");
                return false;
            }
        });

        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                //处理文字长度为0，以及不为0的时候

                if(TextUtils.isEmpty(editable)){

                    ivClose.setVisibility(View.GONE);
                } else {

                    ivClose.setVisibility(View.VISIBLE);
                }
                if(onEditTextLengthChangedListener != null){
                    onEditTextLengthChangedListener.onEditTextLengthChanged(editable.length());
                }
            }
        });
    }

    public EditText getEt() {
        return et;
    }

    public void setEt(EditText et) {
        this.et = et;
    }

    public void setOnEditTextLengthChangedListener(OnEditTextLengthChangedListener onEditTextLengthChangedListener){
        this.onEditTextLengthChangedListener = onEditTextLengthChangedListener;
    }

    public interface OnEditTextLengthChangedListener{

        public void onEditTextLengthChanged(int length);
    }
}
