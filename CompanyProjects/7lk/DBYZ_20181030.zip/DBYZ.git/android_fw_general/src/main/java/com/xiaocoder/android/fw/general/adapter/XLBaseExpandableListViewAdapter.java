package com.xiaocoder.android.fw.general.adapter;

import android.content.Context;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import java.util.List;

public abstract class XLBaseExpandableListViewAdapter<DrugBean> extends XLAbsBaseExpandableListViewAdapter {
    /**
     * 上下文环境
     */
    public Context context;
    /**
     * 图片加载
     */
    public ImageLoader imageloader;
    /**
     * 图片加载配置项
     */
    public DisplayImageOptions options;
    /**
     * 实体对象
     */
    public Object bean;
    /**
     * 子集合数据对象
     */
    public Object childBean;

    /**
     * @param context 上下文环境
     * @param list 数据集合
     * @param imageloader 如果传null 则用默认的imageloader， 该默认的为universal imageloader框架
     */
    public XLBaseExpandableListViewAdapter(Context context, List<Object> list, ImageLoader imageloader) {
        this.list = list;
        this.context = context;
        this.options = XCImageLoaderHelper.getDisplayImageOptions();
        if (imageloader == null) {
            this.imageloader = XCApplication.base_imageloader;
        } else {
            this.imageloader = imageloader;
        }
    }

    public XLBaseExpandableListViewAdapter(Context context, List<Object> list) {
        this(context, list, null);
    }

    public List<Object> getList() {
        return list;
    }

    @Override
    public void update(List list) {
        this.list = list;
    }

    @Override
    public void update(List list, List childList) {
        this.list = list;
        this.childList = childList;
    }

    @Override
    public int getGroupCount() {
        if (list != null) {
            return list.size();
        }
        return 0;
    }

    @Override
    public int getChildrenCount(int i) {
        if (list != null) {
            XCJsonBean childBean = (XCJsonBean)list.get(i);
            List<XCJsonBean> childList = childBean.getList("list");
            if (childList != null) {
                return childList.size();
            }
        }
        return 0;
    }

    @Override
    public XCJsonBean getGroup(int i) {
        if (list != null) {
            return (XCJsonBean)(list.get(i));
        }
        return null;
    }

    @Override
    public Object getChild(int i, int i1) {
        if (list != null) {
            XCJsonBean xcJsonBean = (XCJsonBean)list.get(i);
            List<DrugBean> list = (List<DrugBean>)xcJsonBean.get("list");
            if(list != null && list.size() > 0) {
                return list.get(i1);
            }
        }
        return null;
    }

    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }


    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }

}
