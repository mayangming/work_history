package com.xiaocoder.android.fw.general.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;

/**
 * Created by zhangpengfei on 2015/12/28 14:10.
 * description:
 */
public class PFViewPager extends ViewPager{
    private boolean scrollble = true;
    float x = 0;
    float moveX = 0;
    public PFViewPager(Context context) {
        super(context);
    }

    public PFViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }


    @Override
    public boolean onTouchEvent(MotionEvent ev) {
//        if (!scrollble) {
//            return true;
//        }
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x = ev.getX();
                break;
            case MotionEvent.ACTION_MOVE:
                moveX = ev.getX();
                if (moveX - x < 0 && !scrollble) {
                    return false;
                }
                break;
            case MotionEvent.ACTION_UP:
                break;

        }
        return super.onTouchEvent(ev);
    }

//    @Override
//    public boolean onInterceptTouchEvent(MotionEvent arg0) {
//        if (!scrollble)
//            return false;
//        else
//            return super.onInterceptTouchEvent(arg0);
//    }
    public boolean isScrollble() {
        return scrollble;
    }

    public void setScrollble(boolean scrollble) {
        this.scrollble = scrollble;
    }
}
