package com.xiaocoder.android.fw.general.adapter;

import android.widget.BaseExpandableListAdapter;

import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import java.util.List;

/**
 * @author xilinch on 2016/1/19.
 * @modifier xilinch 2016/1/19 15:43.
 * @description
 */
public abstract class XLAbsBaseExpandableListViewAdapter<T> extends BaseExpandableListAdapter {
    /**
     * 组数据集合
     */
    public List<T> list;
    /**
     * 子数据集合
     */
    public List<T> childList;

    public abstract void update(List<T> list);

    public abstract void update(List<T> list,List<T> childList);
}
