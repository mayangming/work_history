/**
 *
 */
package com.xiaocoder.android.fw.general.util;

import android.app.Activity;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.xiaocoder.android.fw.general.application.XCApplication;

/**
 * @author xiaocoder
 * @Description: 键盘的控制
 * @date 2015-3-2 下午4:48:56
 */
public class UtilInputMethod {

    /**
     * 弹出输入法
     *
     * @param context 上下文
     */
    public static void openInputMethod(EditText view, final Context context) {
        // 弹出输入法
        view.setFocusable(true);
        view.requestFocus();
        view.selectAll();
        // 必须是handler.否则无法弹出 why?
        new Handler().postDelayed(new Runnable() {
            public void run() {
                InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
                // imm.hideSoftInputFromWindow(editText.getWindowToken(),0);
            }
        }, 200);
    }

    /**
     * 隐藏输入法
     *
     * @param context 上下文
     */
    public static void hiddenInputMethod(Context context) {
        if (((Activity) context).getCurrentFocus() != null) {
            if (((Activity) context).getCurrentFocus().getWindowToken() != null) {
                // 先隐藏键盘
                ((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(((Activity) context).getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }

    /**
     * 隐藏输入法另一种方式
     *
     * @param context 上下文
     */
    public static void hiddenInputMethod(View view, Context context) {
        // 隐藏键盘
        ((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(view.getWindowToken(),
                0);
    }

    /**
     * 复制文本
     *
     * @param context 上线文
     * @param content 文本内容
     */
    public static void copyText(Context context, String content) {
        int versionInt = UtilSystem.getOSVersionSDKINT();
        if (versionInt > 10) {
            ClipboardManager clipboardManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            clipboardManager.setText(content);
            XCApplication.base_log.shortToast("已经复制到粘贴板");

        } else {
            android.text.ClipboardManager clipboardManager1 = (android.text.ClipboardManager) context.getSystemService(context.CLIPBOARD_SERVICE);
            clipboardManager1.setText(content);
            XCApplication.base_log.shortToast("已经复制到粘贴板");
        }
    }

}
