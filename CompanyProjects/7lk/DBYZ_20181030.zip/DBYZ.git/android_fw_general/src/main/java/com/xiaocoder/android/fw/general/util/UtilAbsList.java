package com.xiaocoder.android.fw.general.util;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ExpandableListView;
import android.widget.GridView;
import android.widget.ListView;

public class UtilAbsList {
    /**
     * 设置gridview的样式
     *
     * @param view
     * @param show_bar   是否显示滚动条
     * @param space_h_px 水平间距
     * @param space_v_px 垂直间距
     * @param num        每一列显示的数量
     */
    public static void setGridViewStyle(GridView view, boolean show_bar, int space_h_px, int space_v_px, int num) {
        view.setCacheColorHint(0x00000000);
        view.setSelector(new ColorDrawable(0x00000000));
        view.setVerticalScrollBarEnabled(show_bar);
        view.setHorizontalSpacing(space_h_px);
        view.setVerticalSpacing(space_v_px);
        view.setNumColumns(num);
    }

    public static void setExpandListViewStyle(Context context, ExpandableListView view, boolean show_bar, int groupIndicate) {
        view.setCacheColorHint(0x00000000);
        view.setSelector(new ColorDrawable(0x00000000));
        view.setVerticalScrollBarEnabled(show_bar);
        if (groupIndicate <= 0) {
            view.setGroupIndicator(null);
        } else {
            view.setGroupIndicator(context.getResources().getDrawable(groupIndicate));
        }
    }

    /**
     * 设置listview的样式
     *
     * @param view
     * @param divider_drawable 水平线
     * @param height_px        高度间隔
     * @param show_bar         是否显示滚动条
     */
    public static void setListViewStyle(ListView view, Drawable divider_drawable, int height_px, boolean show_bar) {
        view.setCacheColorHint(0x00000000);
        view.setSelector(new ColorDrawable(0x00000000));
        view.setDivider(divider_drawable);
        view.setDividerHeight(height_px);
        view.setVerticalScrollBarEnabled(show_bar);
    }

}
