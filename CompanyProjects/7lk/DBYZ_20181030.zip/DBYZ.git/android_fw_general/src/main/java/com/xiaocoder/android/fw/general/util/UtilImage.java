package com.xiaocoder.android.fw.general.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.ThumbnailUtils;
import android.provider.MediaStore.Video.Thumbnails;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import java.io.File;
import java.lang.reflect.Field;

/**
 * @author xiaocoder
 * @date 2014-10-23 下午10:38:26
 */
public class UtilImage {

    /**
     * 获取状态栏高度
     *
     * @return
     */
    public static int getStatusBarHeight(Context context) {
        Class<?> c = null;

        Object obj = null;

        Field field = null;

        int x = 0, sbar = 0;

        try {

            c = Class.forName("com.android.internal.R$dimen");

            obj = c.newInstance();

            field = c.getField("status_bar_height");

            x = Integer.parseInt(field.get(obj).toString());

            sbar = context.getResources().getDimensionPixelSize(x);

        } catch (Exception e1) {

            e1.printStackTrace();

        }

        return sbar;
    }

    /**
     * 获取屏幕分辨率
     */
    public static int[] getScreenSize(Context context) {
        // 获取屏幕分辨率
        WindowManager manager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metric = new DisplayMetrics();
        manager.getDefaultDisplay().getMetrics(metric);
        int[] size = new int[2];
        size[0] = metric.heightPixels;
        size[1] = metric.widthPixels;
        return size;
    }

    /**
     * 获取屏幕分辨率
     *
     * @return  数组，三个值依次为（屏幕像素宽度、屏幕像素高度、像素密度）
     */
    public static int[] getScreenSizeByMetric(Context context) {
        WindowManager manager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metric = new DisplayMetrics();
        manager.getDefaultDisplay().getMetrics(metric);
        int[] size = new int[3];
        size[0] = metric.widthPixels;
        size[1] = metric.heightPixels;
        size[2] = metric.densityDpi;
        return size;
    }

    public static Bitmap getVideoFirstFrameFull(File file) {
        return ThumbnailUtils.createVideoThumbnail(file.getAbsolutePath(), Thumbnails.FULL_SCREEN_KIND);
    }

    public static int dip2px(Context context, float dipValue) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (scale * dipValue + 0.5f);
    }

    public static int px2dip(Context context, float pxValue) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }

    /**
     * 获取drawable
     *
     * @param id 如R.drawable.ic_pada
     */
    public static Drawable getDrawable(Context context, int id) {
        // Drawable drawable=image.getDrawable();
        return (context == null || id == 0) ? null : context.getResources().getDrawable(id);
    }



}
