package com.xiaocoder.android.fw.general.http;

/**
 * @author xiaocoder
 */
public interface XCIHttpResult {
    /**
     * 访问失败的回调
     */
    void onNetFail();

    /**
     * 访问成功的回调-->显示内容视图
     */
    void onNetSuccess();

    /**
     * 访问失败后点击按钮或屏幕刷新的回调
     */
    void onNetRefresh();

}
