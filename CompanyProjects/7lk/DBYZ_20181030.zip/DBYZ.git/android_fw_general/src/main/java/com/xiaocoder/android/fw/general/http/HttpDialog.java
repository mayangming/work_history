package com.xiaocoder.android.fw.general.http;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.KeyEvent;

import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.dialog.XCSystemVDialog;

/**
 * @author xiaocoder
 * @date 2014-10-17 下午1:52:37
 */
public class HttpDialog {

    private Dialog dialog;

    private static final HttpDialog instance = new HttpDialog();

    public static HttpDialog getInstance() {
        return instance;
    }

    public Dialog getDialog(Context context) {

        if (context == null) {
            return null;
        }

        dismiss();

        final Context ctx = context;

        dialog = new XCSystemVDialog(context);

        dialog.setOnKeyListener(new Dialog.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    XCHttpAsyn.httpFinish();

                    if (!XCConfig.MAIN_ACTIVITY_NAME.equals(ctx.getClass().getSimpleName())) {
                        // 不是首页
                        ((Activity) ctx).finish();
                    }
                }
                return false;
            }
        });

        return dialog;
    }

    public void show() {
        if (dialog != null && !dialog.isShowing()) {
            dialog.show();
        }
    }

    public void dismiss() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
            dialog.setOnKeyListener(null);
        }
        dialog = null;
    }

    private HttpDialog() {
    }

}
