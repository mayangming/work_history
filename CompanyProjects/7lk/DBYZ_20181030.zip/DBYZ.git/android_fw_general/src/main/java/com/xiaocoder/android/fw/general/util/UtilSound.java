package com.xiaocoder.android.fw.general.util;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;

/**
 * Created by xiaocoder on 2015/11/11.
 */
public class UtilSound {

    /**
     * 设置扬声器是否可用
     *
     * @param activity 上下文
     * @param on       true为打开扬声器
     */
    public static void setSpeakerphoneOn(Activity activity, boolean on) {

        AudioManager audioManager = (AudioManager) activity.getSystemService(Context.AUDIO_SERVICE);

        if (on) {
            //add by syy on 20160505 jira 1072 为了兼容魅族，重置听筒模式时放大了的音乐流音量。(不同模式的媒体流流音量，android是分开保存的，需在下面audioManager.set模式之前调用)
            resetMeiZuVoice(audioManager);
            audioManager.setSpeakerphoneOn(true);
            // add by xjs on 20151123 08:13 start
            // 修复：“当手机中启动过大白云诊后，打电话时，默认为扬声器模式”的问题。
            audioManager.setMode(AudioManager.MODE_NORMAL);
            // add by xjs on 20151123 08:13 end
        } else {
            //关闭扬声器
            audioManager.setSpeakerphoneOn(false);
            //把声音设定成Earpiece（听筒）出来，设定为正在通话中
            // modify by xjs on 20151121 15:25 start
            // 设置声音模式，使用 MODE_IN_COMMUNICATION 代替 MODE_IN_CALL，修复JIRA上904的问题。
            // audioManager.setMode(AudioManager.MODE_IN_CALL); // deleted by xjs on 20151121 15:28
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            // modify by xjs on 20151121 15:25 end
            //add by syy on 20160505  jira 1072增大魅族手机听筒音量，魅族听筒模式用的是媒体流的通道，听筒模式媒体流音量与扬声器模式媒体流的音量是不同的保存值
            setMeiZuMaxVoice(audioManager);
        }
    }



    /** 保存魅族当前听筒模式的媒体流音量
     * (默认值需设置为-1，注意：不同模式的媒体流音量是不同的，这里只保存听筒模式下的媒体流音量)
     */
    public static int oldVoice_systemMusic = -1;
    /**
     * 增大魅族手机媒体流音量(听筒模式下调用)
     * @param audioManager
     */
    private static void setMeiZuMaxVoice(AudioManager audioManager) {
        if(UtilSound.oldVoice_systemMusic == - 1 && "Meizu".equals(android.os.Build.BRAND)){
            //获得当前手机音乐流音量
            oldVoice_systemMusic = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            //获得手机音乐流的最大音量
            int maxVoice_systemMusic = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            //把当前手机音乐流音量设为最大值(因魅蓝note2听筒放音用的是音乐流音量而不是语音电话流音量，导致刚流音量设置很小时听不到声音）
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,maxVoice_systemMusic,0);
        }
    }


    /**
     * 重置魅族手机听筒模式下的媒体流音量
     * @param audioManager
     */
    private static void resetMeiZuVoice(AudioManager audioManager) {
        if(UtilSound.oldVoice_systemMusic != -1 && "Meizu".equals(android.os.Build.BRAND)){
            //先设置成听筒模式：
            audioManager.setSpeakerphoneOn(false);
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            //再还原媒体流音量
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,UtilSound.oldVoice_systemMusic,0);
            //只要音量被还原过就设置回-1
            oldVoice_systemMusic = -1;
        }
    }

    /**
     * 请求音频焦点，暂停第三方的音乐播放
     * @param activity
     * @param mAudioFocusChangeListener 音频焦点切换的监听器
     */
    public static void requestAudioFocus(Activity activity,AudioManager.OnAudioFocusChangeListener mAudioFocusChangeListener) {
        AudioManager audioManager = (AudioManager) activity.getSystemService(Context.AUDIO_SERVICE);
        //先进行短暂获得焦点的方式，以该方式获得焦点，当放弃焦点时，被暂停的第三方音乐能再次自动播放
        int ret = audioManager.requestAudioFocus(mAudioFocusChangeListener,
                AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
        if (ret != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            //如果短暂获得焦点的方式不成功，则进行长期获得焦点的方式
            audioManager.requestAudioFocus(mAudioFocusChangeListener,
                    AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    /**
     * 放弃音频焦点
     * @param activity
     * @param mAudioFocusChangeListener 音频焦点切换的监听器
     */
    public static void abandonAudioFocus(Activity activity,AudioManager.OnAudioFocusChangeListener mAudioFocusChangeListener) {
        AudioManager audioManager = (AudioManager) activity.getSystemService(Context.AUDIO_SERVICE);
        audioManager.abandonAudioFocus(mAudioFocusChangeListener);

    }

}
