package com.xiaocoder.android.fw.general.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;

/**
 * @author xiaocoder on 2016/1/6.
 * @modifier xiaocoder 2016/1/6 18:46.
 * @description 注册广播
 */
public class UtilBroadcast {
    /**
     * 注册广播
     *
     * @param context  上下文
     * @param priority 优先级
     * @param action   注册
     * @param receiver 广播
     */
    public static void myRegisterReceiver(Context context, int priority, String action, BroadcastReceiver receiver) {
        IntentFilter filter = new IntentFilter();
        filter.setPriority(priority);
        filter.addAction(action);
        context.registerReceiver(receiver, filter);
    }
    /**
     * 注册广播
     *
     * @param context  上下文
     * @param priority 优先级
     * @param receiver 广播
     * @param actions  广播的Action
     */
    public static void myRegisterReceiver(Context context, int priority, BroadcastReceiver receiver, String... actions) {
        IntentFilter filter = new IntentFilter();
        filter.setPriority(priority);
        for (String action : actions){
            filter.addAction(action);
        }
        context.registerReceiver(receiver, filter);
    }

    /**
     * 解绑广播
     * @param context 上下文
     * @param receiver 广播
     */
    public static void myUnregisterReceiver(Context context, BroadcastReceiver receiver) {
        context.unregisterReceiver(receiver);
    }
}
