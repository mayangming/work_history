package com.xiaocoder.android.fw.general.io;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Map;

/**
 * @author xiaocoder
 * 2015-2-28 上午11:30:18
 */
public class XCSP {
	/**
	 * 缓存对象
	 */
	private SharedPreferences sharedPreferences;
	/**
	 * 缓存编辑者
	 */
	private SharedPreferences.Editor editor;

	/**
	 * @param context
	 * @param fileName
	 *            不要加 ".xml"的后缀名
	 * @param mode
	 *            Context.Mode 下有四种模式常量,一般都用私有模式
	 */
	public XCSP(Context context, String fileName, int mode) {
		super();
		this.sharedPreferences = context.getSharedPreferences(fileName, mode);
	}

	// =============================sharedPreferences存数据======================================================
	public void putString(String key, String value) {
		editor = sharedPreferences.edit();
		editor.putString(key, value);
		editor.apply();
	}

	public void putInt(String key, int value) {
		editor = sharedPreferences.edit();
		editor.putInt(key, value);
		editor.apply();
	}

	public void putLong(String key, long value) {
		editor = sharedPreferences.edit();
		editor.putLong(key, value);
		editor.apply();
	}

	public void putFloat(String key, float value) {
		editor = sharedPreferences.edit();
		editor.putFloat(key, value);
		editor.apply();
	}

	public void putBoolean(String key, boolean value) {
		editor = sharedPreferences.edit();
		editor.putBoolean(key, value);
		editor.apply();
	}

	// =============================sharedPreferences取数据======================================================
	public String getString(String key, String defaultValue) {
		return sharedPreferences.getString(key, defaultValue);
	}

	public int getInt(String key, int defaultValue) {
		return sharedPreferences.getInt(key, defaultValue);
	}

	public long getLong(String key, long defaultValue) {
		return sharedPreferences.getLong(key, defaultValue);
	}

	public float getFloat(String key, float defaultValue) {
		return sharedPreferences.getFloat(key, defaultValue);
	}

	public boolean getBoolean(String key, boolean defaultValue) {
		return sharedPreferences.getBoolean(key, defaultValue);
	}

	public Map<String, ?> getAll() {
		return sharedPreferences.getAll();
	}

	/** 此处需要返回值判断，所以用commit */
	public boolean clear(){
		editor = sharedPreferences.edit();
		editor.clear();
		return editor.commit();
	}
}
