package com.xiaocoder.android.fw.general.adapter;

import android.content.Context;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ListView;

import java.util.List;

public abstract class YYBaseExpandableListViewAdapter<T,E> extends BaseExpandableListAdapter {
    /** 上下文环境*/
    public Context context;
    /** 组对象*/
    public T groupBean;
    /** 子集合数据对象*/
    public E childBean;
    /** 数据集合*/
    public List<T> list;
    /** 子数据集合*/
    public List<E> childList;

    /**
     * @param context 上下文环境
     * @param list 数据集合
     */
    public YYBaseExpandableListViewAdapter(Context context, List<T> list) {
        this.list = list;
        this.context = context;
    }
    @Override
    public int getGroupCount() {
        if (list != null) {
            return list.size();
        }
        return 0;
    }



    @Override
    public T getGroup(int groupPosition) {
        if (list != null) {
            return (T)(list.get(groupPosition));
        }
        return null;
    }

    public abstract List<E> getChildList(int groupPosition);

    @Override
    public E getChild(int groupPosition, int childPosition){
        try {
            return getChildList(groupPosition).get(childPosition);
        } catch (Exception e) {
            return null;
        }
    }


    @Override
    public int getChildrenCount(int groupPosition){
        childList = getChildList(groupPosition);
        return childList == null ? 0 : childList.size();
    }


    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }


    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }


    /**
     * 更新数据
     * @param list
     */
    public void update(List list) {
        this.list = list;
    }

    /**
     * 更新数据并展开所有子列表
     * @param list 数据集
     * @param listView 数据视图
     */
    public void update(List list,ExpandableListView listView) {
        this.list = list;
        expandAll(listView);
    }

    /**
     * 展开所有子视图
     * @param listView 数据视图
     */
    public void expandAll(ExpandableListView listView) {
        int size = list == null ? 0 : list.size();
        for (int i = 0; i < size; i++) {
            listView.expandGroup(i);
        }
    }
}
