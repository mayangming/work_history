package com.xiaocoder.android.fw.general.dialog;


import com.xiaocoder.android.fw.general.base.XCBaseActivity;

/**
 * @author shuYanYi on 2016/7/22.
 * @description  只设置内容变化的 “我知道”对话框
 */
public class YY_KnowDialog extends XCQueryDialog {
   private XCBaseActivity mContext;
   private CloseListener closeListener;
    /**
     * 按钮文字
     */
   public static String BTN_STR = "我知道了";

    public YY_KnowDialog(XCBaseActivity context) {
        super(context,"温馨提示", "", new String[]{BTN_STR}, false);
        mContext = context;
        setOnDecideListener(new XCQueryDialog.OnDecideListener(){
            @Override
            public void confirm() {
                if(mContext != null){
                    dismiss();
                    if(closeListener != null){
                        closeListener.afterClose();
                    }
                }
            }
            @Override
            public void cancle() {

            }
        });

    }

    /**
     * 显示此提示框
     * @param content
     */
    public void show(String content){
        super.setParams("温馨提示",content,new String[]{BTN_STR},false);
        check();
        if(mContext != null && !mContext.isFinishing() && !this.isShowing()){
            this.show();
        }
    }

    public interface CloseListener{
        /** 点击关闭对话框后的动作*/
        void afterClose();
    }

    /**
     * 设置关闭对话框后动作监听
     * @param closeListener
     */
    public void setCloseListener(CloseListener closeListener) {
        this.closeListener = closeListener;
    }

    /**
     * 显示此提示框
     * @param content 显示内容
     * @param closeListener 点击知道关闭对话框后的回调动作
     */
    public void show(String content,CloseListener closeListener){
        this.setCloseListener(closeListener);
        show(content);
    }

}
