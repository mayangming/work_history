package com.xiaocoder.android.fw.general.util;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.net.Uri;

public class UtilMedia {

    /**
     * 结束播放
     */
    public static void finishPlaying(MediaPlayer mediaplayer) {
        if (mediaplayer != null) {
            mediaplayer.stop();
            mediaplayer.release();
        }
    }

    /**
     * 开始播放
     */
    public static MediaPlayer openVoice(Context context, Uri uri) {
        try {
            MediaPlayer mp = new MediaPlayer();
            // 置为初始状态
            mp.reset();
            // 设置文件路径
            mp.setDataSource(context, uri);

            // 设置缓冲完成监听(当缓冲完成的时候,调用该监听器)
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                    if (mediaPlayer != null) {
                        mediaPlayer.start();
                    }
                }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    if (mediaPlayer != null) {
                        finishPlaying(mediaPlayer);
                    }
                }
            });

            mp.prepareAsync();
            return mp;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 开始播放
     *
     * @param fileId R.raw.filename
     */
    public static MediaPlayer openVoice(MediaPlayer mediaPlayer,final Context context, final int fileId) {
        try {
            AssetFileDescriptor file = context.getResources().openRawResourceFd(fileId);


            // 置为初始状态
            mediaPlayer.reset();
            // 设置文件路径
            mediaPlayer.setDataSource(file.getFileDescriptor(), file.getStartOffset(), file.getLength());

            file.close();

            // 设置缓冲完成监听(当缓冲完成的时候,调用该监听器)
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                    if (mediaPlayer != null) {
                        mediaPlayer.start();
                    }
                }
            });

            mediaPlayer.prepareAsync();
            return mediaPlayer;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 播放音乐
     * @param context
     * @param resId
     */
    public static void openVoice(Context context, int resId) {
        MediaPlayer mMediaPlayer = MediaPlayer.create(context, resId);
        try {
            mMediaPlayer.start();
            mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

                @Override
                public void onCompletion(MediaPlayer mp) {
                    if (null != mp) {
                        mp.release();
                    }
                }
            });
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }
}


