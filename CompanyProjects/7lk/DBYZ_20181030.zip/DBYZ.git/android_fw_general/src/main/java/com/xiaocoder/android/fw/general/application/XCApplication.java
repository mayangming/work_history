package com.xiaocoder.android.fw.general.application;

import android.app.Activity;
import android.content.Context;
import android.os.Environment;
import android.support.multidex.MultiDexApplication;
import android.widget.ImageView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.io.XCLog;
import com.xiaocoder.android.fw.general.io.XCSP;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

/**
 * 初始化数据
 *
 * @author jingyu
 */
public class XCApplication extends MultiDexApplication {
    /**
     * 存储activity的集合 将stack改为静态在qlkservicehelper中使用   因点击通知栏需要跳转到客服聊天页面，如在Notifier设置会出现应用杀死时点击桌面程序会直接跳转到聊天页面，
     */
    public static Stack<Activity> stack;
    /**
     * 日志类
     */
    public static XCLog base_log;
    /**
     * sp存储
     */
    public static XCSP base_sp;
    /**
     * html存储sp
     */
    public static XCSP html_sp;
    /**
     * 图片加载器
     */
    public static ImageLoader base_imageloader;
    /**
     * 上下文
     */
    public static Context base_context;

    @Override
    public void onCreate() {
        super.onCreate();

        base_context = getApplicationContext();

        stack = new Stack<Activity>();

        deleteLog();

        // log , 可以打印日志 与 toast
        base_log = new XCLog(base_context);
        base_sp = new XCSP(base_context, XCConfig.SP_FILE, Context.MODE_APPEND);
        html_sp = new XCSP(base_context, XCConfig.SP_HTML, Context.MODE_APPEND);
        // 异步加载图片
        base_imageloader = XCImageLoaderHelper.getInitedImageLoader(XCImageLoaderHelper.getImageLoaderConfiguration(base_context, UtilFiles.createDirInside("", base_context)));

        UtilFiles.createDirInAndroid(XCConfig.CHAT_MOIVE_DIR, base_context);
        UtilFiles.createDirInAndroid(XCConfig.CHAT_VOICE_DIR, base_context);
        UtilFiles.createDirInAndroid(XCConfig.CHAT_PHOTO_DIR, base_context);

    }

    /**
     * 获取保存activity的集合
     *
     * @return 装有activity的集合
     */
    public static Stack<Activity> getStack() {
        return stack;
    }

    /**
     * 删除日志
     */
    private void deleteLog() {
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + System.getProperty("file.separator") + XCConfig.LOG_FILE);
        if (file.exists()) {
            file.delete();
        }
    }

    /**
     * 添加activity到集合中
     *
     * @param activity 添加目标acivity到集合中
     */
    public static void addActivityToStack(Activity activity) {
        stack.add(activity);
    }

    /**
     * 把activity从集合中移除
     *
     * @param activity 被删除的activity
     */
    public static void delActivityFromStack(Activity activity) {
        stack.remove(activity);
    }

    /**
     * 判断某个acivity实例是否存在
     *
     * @param cls activity的字节码
     */
    public static boolean isActivityExist(Class<?> cls) {
        for (Activity activity : stack) {
            if (activity.getClass().equals(cls)) {
                return true;
            }
        }
        return false;
    }
    /**
     * 判断某个acivity实例是否在栈顶
     *
     * @param cls activity的字节码
     */
    public static boolean isActivityTop(Class<?> cls) {
        if (XCApplication.stack.size() > 0){
            return  XCApplication.stack.get(XCApplication.stack.size() - 1).getClass().equals(cls);
        }
        return false;
    }
    /**
     * 获取某个activity（activity不删除）
     *
     * @param cls activity的字节码
     */
    public static List<Activity> getActivity(Class<?> cls) {
        List<Activity> list = new ArrayList<Activity>();
        for (Activity activity : stack) {
            if (activity.getClass().equals(cls)) {
                list.add(activity);
            }
        }
        return list;
    }

    /**
     * 通过class ， 结束指定类名的Activity
     *
     * @param cls activity的字节码
     */
    public static void finishActivities(Class<?> cls) {
        for (Iterator<Activity> it = stack.iterator(); it.hasNext(); ) {
            Activity activity = it.next();
            if (activity.getClass().equals(cls)) {
                // finishActivity(activity);// 并发修改异常
                it.remove();
                activity.finish();
            }
        }
    }

    /**
     * 关闭所有的activity
     */
    public static void finishAllActivity() {
        if(null != stack & !stack.isEmpty()){
            Stack<Activity> currentStack = new Stack<>();
            currentStack.addAll(stack);
            for (Activity activity : currentStack) {
                if (activity != null) {
                    activity.finish();// 销毁
                }
            }
            stack.clear();
        }
    }

    /**
     * 退出应用程序
     */
    public static void AppExit() {
        try {
            finishAllActivity();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Context getInstance() {
        return XCApplication.base_context;
    }

    /**
     * 长土司
     *
     * @param msg 消息
     */
    public static void longToast(String msg) {
        XCApplication.base_log.longToast(msg);
    }

    /**
     * 加载图片
     *
     * @param uri       图片地址
     * @param imageView 图片控件
     * @param options   加载参数
     */
    public static void displayImage(String uri, ImageView imageView, DisplayImageOptions options) {
        base_imageloader.displayImage(uri, imageView, options);
    }

    /**
     * 加载图片
     *
     * @param uri       图片地址
     * @param imageView 图片控件
     */
    public static void displayImage(String uri, ImageView imageView) {
        displayImage(uri, imageView, XCImageLoaderHelper.getDisplayImageOptions());
    }

}
