package com.qlk.ymz;

import android.app.Application;
import android.test.ApplicationTestCase;

import com.qlk.ymz.db.mqttlog.MqttLogDb;
import com.qlk.ymz.db.mqttlog.MqttLogModel;
import com.qlk.ymz.util.UtilIMCreateJson;

import java.util.ArrayList;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }

    public String testCreateMedicRecordJson() {
        ArrayList<String> list = new ArrayList<>();
        list.add("http://image1");
        list.add("http://image2");
        list.add("http://image3");
        list.add("http://image4");
        String result = UtilIMCreateJson.createMedicRecordJson(getContext(), "测试文本", list, "31", "12");
        System.out.println("testCreateMedicRecordJson----" + result);
        return result;
    }

    public void testLogDb() {
        MqttLogDb db = MqttLogDb.getInstance(getContext());
        //db.deleteAll();
        for (int i = 211; i <= 212; i++) {
            MqttLogModel model = new MqttLogModel();
            model.setMsg("{" + i + "}");
            model.setTime(System.currentTimeMillis() + "");
            db.insert(model);
        }

        System.out.println(db.queryCount());

        System.out.println(db.queryLogString());

    }

}