package com.qlk.ymz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.MedicationRemindAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.ReBuyNotic;
import com.qlk.ymz.parse.Parse2ReBuyNotic;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;
import com.xiaocoder.ptrrefresh.XCMaterialListPinRefreshLayout;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2018/3/21.
 * 用药提醒  v2.16 复购需求
 */

public class XD_MedicationRemindActivity extends DBActivity {
    /**
     * 标题栏
     */
    private XCTitleCommonLayout xc_id_model_titlebar;
    /*
    用药提醒患者上拉刷新列表
     */
    private XCMaterialListPinRefreshLayout mXCMaterialListPinRefreshLayout;
    /*
    用药提醒患者列表
     */
    private ListView mListView;
    /*
    提醒列表适配器
     */
    private MedicationRemindAdapter mMedicationRemindAdapter;
    /*
    提醒数据集
     */
    private List<ReBuyNotic> mReBuyNotics = new ArrayList<>();
    /*
    通知id
     */
    private String notificationId ="1";
    /*
    通知id跳转标识
     */
    public static final String NOTIFICATION_ID = "notificationId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_medication_remind);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_MedicationRemindActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    private void initData() {
        if(getIntent()!=null&&getIntent().getStringExtra(NOTIFICATION_ID)!=null){
            notificationId = getIntent().getStringExtra(NOTIFICATION_ID);
        }
        getMedicationRemindData(1);
    }

    @Override
    public void onNetRefresh() {
        getMedicationRemindData(1);
    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "处方用药提醒");
        xc_id_model_titlebar.setTitleLeft(true, "");
        mXCMaterialListPinRefreshLayout = getViewById(R.id.rfl_medication_remind);
        mXCMaterialListPinRefreshLayout.setBgZeroHintInfo("无用药提醒数据", "", R.mipmap
                .js_d_icon_no_data);
        mListView = (ListView) mXCMaterialListPinRefreshLayout.getListView();
        mMedicationRemindAdapter = new MedicationRemindAdapter(this,
                mReBuyNotics);
        mListView.setAdapter(mMedicationRemindAdapter);
    }

    @Override
    public void listeners() {
        mXCMaterialListPinRefreshLayout.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {
                return false;
            }

            @Override
            public boolean canLoad() {
                return true;
            }

            @Override
            public void refresh(View view, int request_page) {

            }

            @Override
            public void load(View view, int request_page) {
                getMedicationRemindData(request_page);
            }
        });
    }

    /**
     * 获取用药提醒列表
     * @param page
     */
    private void getMedicationRemindData(int page){
        RequestParams params = new RequestParams();
        params.put("num",20);
        params.put("page", page);
        params.put("notifyId",notificationId);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.patientMedicationRemind), params,
                new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            List<XCJsonBean> data = result_bean.getList("data");
                            mXCMaterialListPinRefreshLayout.setTotalPage(data.get(0).getInt("totalPages")+"");
                            List<ReBuyNotic> reBuyNoticList = parseReBuyNoticList(data.get(0).getList("result"));
                            mReBuyNotics.addAll(reBuyNoticList);
                            mXCMaterialListPinRefreshLayout.updateListAdd(reBuyNoticList, mMedicationRemindAdapter);
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        if(mXCMaterialListPinRefreshLayout.base_currentPage ==1){
                            showNoNetLayout();
                        }
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        // 处理code操作
                        if (null != result_bean && "13010301".equals(getCode())) {//15天过期异常码
                            mXCMaterialListPinRefreshLayout.setBgZeroHintInfo("该页面已过期 " +
                                            "无法再访问...\n(页面访问有效期为15天)", "", R.mipmap.js_d_icon_no_data);
                        }else if( null != result_bean && GeneralReqExceptionProcess.checkCode(XD_MedicationRemindActivity.this, getCode(), getMsg())){
                        }
                        mXCMaterialListPinRefreshLayout.completeRefresh(result_boolean);
                    }

                });
    }


    /**
     * 解析用药提醒列表
     * @param xcJsonBeans
     * @return List<ReBuyNotic>
     */
    private List<ReBuyNotic> parseReBuyNoticList(List<XCJsonBean> xcJsonBeans) {
        ArrayList<ReBuyNotic> reBuyNotics = new ArrayList<>();
        Parse2ReBuyNotic parse2ReBuyNotic = new Parse2ReBuyNotic();
        for (XCJsonBean xcJsonBean : xcJsonBeans) {
            ReBuyNotic reBuyNotic = new ReBuyNotic();
            parse2ReBuyNotic.parse(reBuyNotic, xcJsonBean);
            reBuyNotics.add(reBuyNotic);
        }
        return reBuyNotics;
    }
}
