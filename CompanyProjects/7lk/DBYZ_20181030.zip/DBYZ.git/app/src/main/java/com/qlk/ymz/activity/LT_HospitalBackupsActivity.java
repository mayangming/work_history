package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gdca.sdk.casign.model.GdcaCertModel;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.parse.Parse2HospitalBackupsBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.ElectronicSignatureHelper;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.HospitalBackupsBeanSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 李涛
 * @description 互联网医院备案
 * @Date 2017/7/18.
 */
public class LT_HospitalBackupsActivity extends DBActivity implements View.OnClickListener {
    /**
     * 公共标题
     */
    private XCTitleCommonLayout xcTitleCommonLayout;
    /**
     * 身份证布局内容
     */
    private RelativeLayout lt_hospital_idcard_view;
    private TextView lt_idCardState;
    /**
     * 职称证书内容布局
     */
    private RelativeLayout lt_hospital_certificate_view;
    private TextView lt_certificateState;

    /**
     * 医师资格证内容布局
     */
    private RelativeLayout lt_hospital_doctorstatus_view;
    private TextView lt_hospital_mustfill3;
    private TextView lt_hospitallQualificationState;

    /**
     * 执业证
     */
    private RelativeLayout lt_hospital_practising_view;
    private TextView lt_hospitall_state5;

    /**
     * 电子签名内容布局
     */
    private RelativeLayout lt_hospital_signature_view;
    private TextView signatureState;
    /**
     * 提交按钮
     */
    private Button lt_hospital_commitbt;
    /**
     * 无网络页面
     */
    private RelativeLayout lt_hospital_nonetview;
    private Button xc_id_no_net_button;
    /**
     * 正文内容页面
     */
    private LinearLayout lt_hospital_contentview;
    /**
     * 身份证编辑页  职称证书编辑页 返回数据
     */
    private File frontImage;
    private File reverseImage;
    private String idCardNun;
    private File cfefile;

    /**
     * 网络返回数据
     */
    Parse2HospitalBackupsBean backupsBean;
    /**
     * 审核通过的商标
     */
    private RelativeLayout lt_hospital_log;
    /**
     * 医生合法备案状态（0 未申请备案; 1 备案审核中;2 备案成功; 3 备案失败; 4 要求备案）
     */
    private String viewFlag;
    /**
     * 必填 Textview只做隐藏显示操作
     */
    private TextView lt_hospital_mustfill1;
    private TextView lt_hospital_mustfill2;
    private TextView lt_hospital_mustfill4;

    /**
     * 电子签名字段设置
     */
    private int signature_code = -1;
    /**
     * 将ImageLoader图片缓存到缓存中
     */
    private ImageView imageView1;
    private ImageView imageView2;
    private ImageView imageView3;
    private ImageView imageView4;
    private ImageView imageView5;
    private ImageView imageView6;
    private ImageView imageView7;
    private TextView lt_hospital_argeement_down;
    private TextView lt_hospital_argeement_up;

    /**
     * 新版资格证页面返回数据或网络返回数据
     */
    private File aptitudeNewfile;
    /**
     * 旧版资格证页面返回数据或网络返回数据
     */
    private File aptitudeOldUpImage;
    private File aptitudeOldDownImage;

    private String practisingVersionType = "0";
    private String doctorPracticeCertificateString;
    private String mDoctorPracticeCertificatePath;
    /**
     * 新版执业证页面返回数据或网络返回数据
     */
    private File practisingNewfile;
    /**
     * 旧版执业证页面返回数据或网络返回数据
     */
    private File practisingOldUpImage;
    private File practisingOldDownImage;
    /**
     * 判断新旧版本数据
     */
    private String versionType = "0";
    private YR_CommonDialog commitDialog;
    private YR_CommonDialog successDialog;
    private YR_CommonDialog recordDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.lt_activity__hospital_backups);
        super.onCreate(savedInstanceState);
        initData();
    }

    private void initData() {
        viewFlag = UtilSP.getDoctorStatus();
        requestBackupsData();
//         viewFlag = "2";
        if ("0".equals(viewFlag) || "4".equals(viewFlag)) {
            lt_hospital_log.setVisibility(View.GONE);
            lt_hospital_commitbt.setVisibility(View.VISIBLE);
            lt_hospital_signature_view.setVisibility(View.GONE);
            lt_idCardState.setText("");
            lt_certificateState.setText("");
            lt_hospitallQualificationState.setText("");
            lt_hospitall_state5.setText("");
        } else if ("1".equals(viewFlag)) {
            lt_hospital_mustfill1.setVisibility(View.GONE);
            lt_hospital_mustfill2.setVisibility(View.GONE);
            lt_hospital_mustfill3.setVisibility(View.GONE);
            lt_hospital_mustfill4.setVisibility(View.GONE);
            lt_hospital_log.setVisibility(View.GONE);
            lt_hospital_commitbt.setVisibility(View.GONE);
            lt_hospital_signature_view.setVisibility(View.GONE);
            if (aptitudeNewfile == null || (aptitudeOldUpImage == null && aptitudeOldDownImage == null)) {
                lt_hospital_doctorstatus_view.setVisibility(View.GONE);
            }
            lt_idCardState.setText("审核中");
            lt_certificateState.setText("审核中");
            lt_hospitallQualificationState.setText("审核中");
            lt_hospitall_state5.setText("审核中");
        } else if ("2".equals(viewFlag)) {
            setSignatureView();
            lt_hospital_mustfill1.setVisibility(View.GONE);
            lt_hospital_mustfill2.setVisibility(View.GONE);
            lt_hospital_mustfill3.setVisibility(View.GONE);
            lt_hospital_mustfill4.setVisibility(View.GONE);
            lt_hospital_commitbt.setVisibility(View.GONE);
            lt_hospital_signature_view.setVisibility(View.VISIBLE);
            lt_idCardState.setText("审核通过");
            lt_certificateState.setText("审核通过");
            lt_hospitallQualificationState.setText("审核通过");
            lt_hospitall_state5.setText("审核通过");
            lt_hospitall_state5.setTextColor(getResources().getColor(R.color.c_42bd05));
            lt_hospitallQualificationState.setTextColor(getResources().getColor(R.color.c_42bd05));
            lt_idCardState.setTextColor(getResources().getColor(R.color.c_42bd05));
            lt_certificateState.setTextColor(getResources().getColor(R.color.c_42bd05));
            if (aptitudeNewfile == null || (aptitudeOldUpImage == null && aptitudeOldDownImage == null)) {
                lt_hospital_doctorstatus_view.setVisibility(View.GONE);
            }
        } else if ("3".equals(viewFlag)) {
            lt_hospital_log.setVisibility(View.GONE);
            lt_hospital_commitbt.setVisibility(View.VISIBLE);
            lt_hospital_signature_view.setVisibility(View.GONE);
            lt_hospital_doctorstatus_view.setVisibility(View.VISIBLE);
        }
    }

    //显示 必填 文案
    private void goneMustfill() {
        if (frontImage != null && reverseImage != null && !TextUtils.isEmpty(idCardNun)) {
            lt_hospital_mustfill1.setVisibility(View.GONE);
            lt_idCardState.setText("待提交");
        }
        if (cfefile != null) {
            lt_hospital_mustfill2.setVisibility(View.GONE);
            lt_certificateState.setText("待提交");
        }
        if (aptitudeNewfile != null || (aptitudeOldUpImage != null && aptitudeOldDownImage != null)) {
            lt_hospital_mustfill3.setVisibility(View.GONE);
            lt_hospitallQualificationState.setText("待提交");
        }
        if (practisingNewfile != null || (practisingOldUpImage != null && practisingOldDownImage != null)) {
            lt_hospital_mustfill4.setVisibility(View.GONE);
            lt_hospitall_state5.setText("待提交");
        }
    }

    //备案成功后设置电子签名
    private void setSignatureView() {
        ElectronicSignatureHelper.getInstance().getCertInfo(false, LT_HospitalBackupsActivity.this,
                new ElectronicSignatureHelper.CertInfoListener() {
                    @Override
                    public void onCertInfo(GdcaCertModel var1) {
                        signatureState.setText("已设置");
                        signature_code = 1;
                        lt_hospital_log.setVisibility(View.VISIBLE);
                        signatureState.setTextColor(getResources().getColor(R.color.c_42bd05));
                        lt_hospital_argeement_up.setVisibility(View.VISIBLE);
                        lt_hospital_argeement_down.setVisibility(View.GONE);
                    }

                    @Override
                    public void onFail(String msg, int code) {
                        //没设置的 UNSET_CERT
                        if (ElectronicSignatureHelper.UNSET_CERT == code) {
                            signature_code = 2;
                            signatureState.setText("待设置");
                            lt_hospital_log.setVisibility(View.GONE);
                            signatureState.setTextColor(getResources().getColor(R.color.c_e2231a));
                            lt_hospital_argeement_up.setVisibility(View.GONE);
                            lt_hospital_argeement_down.setVisibility(View.VISIBLE);
                        }
                    }
                });
    }


    //如果备案 审核中 审核通过 审核失败都会请求网络返回的数据
    private void requestBackupsData() {
        backupsBean = new Parse2HospitalBackupsBean();
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.backups_detail), new RequestParams(), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    lt_hospital_contentview.setVisibility(View.VISIBLE);
                    lt_hospital_nonetview.setVisibility(View.GONE);
                    List<XCJsonBean> data = result_bean.getList("data");
                    Parse2HospitalBackupsBean.ParseJson(data, backupsBean);
                    if (!TextUtils.isEmpty(backupsBean.getIdCardUpUrl())) {
                        XCApplication.base_imageloader.displayImage("" + backupsBean.getIdCardUpUrl(), imageView1, XCImageLoaderHelper.getDisplayImageOptions());
                        frontImage = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getIdCardUpUrl());
                    }
                    if (!TextUtils.isEmpty(backupsBean.getIdCardDownUrl())) {
                        XCApplication.base_imageloader.displayImage("" + backupsBean.getIdCardDownUrl(), imageView2, XCImageLoaderHelper.getDisplayImageOptions());
                        reverseImage = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getIdCardDownUrl());
                    }
                    if (!TextUtils.isEmpty(backupsBean.getTitleCertificateUrl())) {
                        XCApplication.base_imageloader.displayImage("" + backupsBean.getTitleCertificateUrl(), imageView3, XCImageLoaderHelper.getDisplayImageOptions());
                        cfefile = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getTitleCertificateUrl());
                    }
                    if (!TextUtils.isEmpty(backupsBean.getIdCardNum())) {
                        idCardNun = backupsBean.getIdCardNum();
                        UtilSP.setUseridCardNum(idCardNun);
                    }

                    if (!TextUtils.isEmpty(backupsBean.getNewDoctorQuqlification()) || (!TextUtils.isEmpty(backupsBean.getOldDoctorQuqlificationUp()) && !TextUtils.isEmpty(backupsBean.getOldDoctorQuqlificationDown()))) {
                        //判断 医师资格证入口是否显示  1显示 2不显示、

                        if ("1".equals(backupsBean.getDisplayState())) {
                            lt_hospital_doctorstatus_view.setVisibility(View.VISIBLE);
                        }
                        if ("2".equals(backupsBean.getDisplayState())) {
                            lt_hospital_doctorstatus_view.setVisibility(View.GONE);
                        }
                        //VersionType 1新版  2旧版
                        versionType = backupsBean.getVersionType();
                        if ("1".equals(backupsBean.getVersionType())) {
                            XCApplication.base_imageloader.displayImage("" + backupsBean.getNewDoctorQuqlification(), imageView4, XCImageLoaderHelper.getDisplayImageOptions());
                            aptitudeNewfile = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getNewDoctorQuqlification());
                        }
                        if ("2".equals(backupsBean.getVersionType())) {
                            XCApplication.base_imageloader.displayImage("" + backupsBean.getOldDoctorQuqlificationUp(), imageView4, XCImageLoaderHelper.getDisplayImageOptions());
                            aptitudeOldUpImage = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getOldDoctorQuqlificationUp());
                            XCApplication.base_imageloader.displayImage("" + backupsBean.getOldDoctorQuqlificationDown(), imageView5, XCImageLoaderHelper.getDisplayImageOptions());
                            aptitudeOldDownImage = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getOldDoctorQuqlificationDown());
                        }
                    }
                    doctorPracticeCertificateString = backupsBean.getDoctorPracticeCertificateString();
                    practisingVersionType = backupsBean.getPractisingVersionType();
                    if ("3".equals(viewFlag) || "0".equals(viewFlag) || "4".equals(viewFlag)) {
                        if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingNewImageUrl())) {
                            practisingNewfile = new File(HospitalBackupsBeanSP.getPractisingNewImageUrl());
                            practisingVersionType = "1";
                        }else if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingOldUpImageUrl()) &&
                                !TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingOldDownImageUrl())) {
                            practisingOldUpImage = new File(HospitalBackupsBeanSP.getPractisingOldUpImageUrl());
                            practisingOldDownImage = new File(HospitalBackupsBeanSP.getPractisingOldDownImageUrl());
                            practisingVersionType = "2";
                        }else {
                            if ("1".equals(backupsBean.getPractisingVersionType())) {
                                XCApplication.base_imageloader.displayImage("" + backupsBean.getPractisingNewImageUrl(), imageView6, XCImageLoaderHelper.getDisplayImageOptions());
                                practisingNewfile = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getPractisingNewImageUrl());
                            }else if ("2".equals(backupsBean.getPractisingVersionType())) {
                                XCApplication.base_imageloader.displayImage("" + backupsBean.getPractisingOldUpImageUrl(), imageView6, XCImageLoaderHelper.getDisplayImageOptions());
                                practisingOldUpImage = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getPractisingOldUpImageUrl());
                                XCApplication.base_imageloader.displayImage("" + backupsBean.getPractisingOldDownImageUrl(), imageView7, XCImageLoaderHelper.getDisplayImageOptions());
                                practisingOldDownImage = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getPractisingOldDownImageUrl());
                            }
                        }

                    }else {
                        if ("1".equals(backupsBean.getPractisingVersionType())) {
                            XCApplication.base_imageloader.displayImage("" + backupsBean.getPractisingNewImageUrl(), imageView6, XCImageLoaderHelper.getDisplayImageOptions());
                            practisingNewfile = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getPractisingNewImageUrl());
                        }else if ("2".equals(backupsBean.getPractisingVersionType())) {
                            XCApplication.base_imageloader.displayImage("" + backupsBean.getPractisingOldUpImageUrl(), imageView6, XCImageLoaderHelper.getDisplayImageOptions());
                            practisingOldUpImage = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getPractisingOldUpImageUrl());
                            XCApplication.base_imageloader.displayImage("" + backupsBean.getPractisingOldDownImageUrl(), imageView7, XCImageLoaderHelper.getDisplayImageOptions());
                            practisingOldDownImage = XCApplication.base_imageloader.getDiscCache().get(backupsBean.getPractisingOldDownImageUrl());
                        }
                    }

                    if("1".equals(viewFlag) || "2".equals(viewFlag)){ // 审核中或者审核通过
                        if (TextUtils.isEmpty(backupsBean.getPractisingNewImageUrl())
                                && (TextUtils.isEmpty(backupsBean.getPractisingOldUpImageUrl()) && TextUtils.isEmpty(backupsBean.getPractisingOldDownImageUrl()))) {
                            lt_hospital_practising_view.setVisibility(View.GONE);
                        }
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                lt_hospital_contentview.setVisibility(View.GONE);
                lt_hospital_nonetview.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                checkButton();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LT_HospitalBackupsActivity.this,
                        getCode(),
                        getMsg())) {
                }
                //在返回失败或者未备案的时候判断
                if ("3".equals(viewFlag) || "0".equals(viewFlag) || "4".equals(viewFlag)) {
                    getLocalData();
                    goneMustfill();
                }
            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();
        //created by songxin,date：2017-9-26,about：bi,begin */
        BiUtil.savePid(LT_HospitalBackupsActivity.class);
        //created by songxin,date：2017-9-26,about：bi,end */
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        checkButton();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        UtilViewShow.destoryDialogs(commitDialog);
        UtilViewShow.destoryDialogs(successDialog);
    }

    @Override
    public void initWidgets() {
        initDialog();
        imageView1 = new ImageView(this);
        imageView2 = new ImageView(this);
        imageView3 = new ImageView(this);
        imageView4 = new ImageView(this);
        imageView5 = new ImageView(this);
        imageView6 = new ImageView(this);
        imageView7 = new ImageView(this);
        //标题部分
        xcTitleCommonLayout = (XCTitleCommonLayout) findViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonLayout.setTitleLeft(true, "");
        xcTitleCommonLayout.setTitleCenter(true, "互联网医院备案");

        //身份证
        lt_hospital_idcard_view = (RelativeLayout) findViewById(R.id.lt_hospital_idcard_view);
        lt_hospital_mustfill1 = (TextView) findViewById(R.id.lt_hospital_mustfill1);
        lt_idCardState = (TextView) findViewById(R.id.lt_hospitall_state);
        //职称证书
        lt_hospital_certificate_view = (RelativeLayout) findViewById(R.id.lt_hospital_certificate_view);
        lt_hospital_mustfill2 = (TextView) findViewById(R.id.lt_hospital_mustfill2);
        lt_certificateState = (TextView) findViewById(R.id.lt_hospitall_state2);
        //电子签名
        lt_hospital_signature_view = (RelativeLayout) findViewById(R.id.lt_hospital_signature_view);
        signatureState = (TextView) findViewById(R.id.lt_hospitall_state3);
        //医师资格证
        lt_hospital_doctorstatus_view = (RelativeLayout) findViewById(R.id.lt_hospital_doctorstatus_view);
        lt_hospital_mustfill3 = (TextView) findViewById(R.id.lt_hospital_mustfill3);
        lt_hospitallQualificationState = (TextView) findViewById(R.id.lt_hospitall_state4);

        //医师资格证
        lt_hospital_practising_view = (RelativeLayout) findViewById(R.id.lt_hospital_practising_view);
        lt_hospital_mustfill4 = (TextView) findViewById(R.id.lt_hospital_mustfill4);
        lt_hospitall_state5 = (TextView) findViewById(R.id.lt_hospitall_state5);

        //提交按钮
        lt_hospital_commitbt = (Button) findViewById(R.id.lt_hospital_commitbt);
        //无网络数据页面
        lt_hospital_nonetview = (RelativeLayout) findViewById(R.id.lt_hospital_nonetview);
        xc_id_no_net_button = (Button) findViewById(R.id.xc_id_no_net_button);
        lt_hospital_contentview = (LinearLayout) findViewById(R.id.lt_hospital_contentview);
        //icon
        lt_hospital_log = (RelativeLayout) findViewById(R.id.lt_hospital_icon);

        //备案协议 跳转
        lt_hospital_argeement_up = (TextView) findViewById(R.id.lt_hospital_argeement_up);
        lt_hospital_argeement_down = (TextView) findViewById(R.id.lt_hospital_argeement_down);
        lt_hospital_argeement_up.setText(Html.fromHtml("您已同意<font color = '#e2231a'>《互联网医院备案协议》</font> "));
        lt_hospital_argeement_down.setText(Html.fromHtml("您已同意<font color = '#e2231a'>《互联网医院备案协议》</font> "));
    }


    @Override
    public void listeners() {

        lt_hospital_idcard_view.setOnClickListener(this);
        lt_hospital_certificate_view.setOnClickListener(this);
        lt_hospital_signature_view.setOnClickListener(this);
        lt_hospital_commitbt.setOnClickListener(this);
        xc_id_no_net_button.setOnClickListener(this);
        lt_hospital_argeement_up.setOnClickListener(this);
        lt_hospital_argeement_down.setOnClickListener(this);
        lt_hospital_doctorstatus_view.setOnClickListener(this);
        lt_hospital_practising_view.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()) {
            case R.id.lt_hospital_idcard_view:
                //进入身份证编辑页
                toJumpIDCard();
                break;
            case R.id.lt_hospital_certificate_view:
                //进入职称证书展示页
                toJumpCFE();
                break;
            case R.id.lt_hospital_signature_view:
                //设置电子签名
                if (2 == signature_code) {
                    ToJumpHelp.toJumpEditPhoneNumberActivity(this, 2, XD_EditPhoneNumberActivity.FROM_BACKUP);
                } else if (1 == signature_code) {
                    ToJumpHelp.toJumpElectronicSignatureActivity(this, XD_ElectronicSignatureActivity.FROM_BACKUP);
                }
                break;
            case R.id.lt_hospital_commitbt:
                //提交按钮
                SendDalogMsg();
                break;
            case R.id.xc_id_no_net_button:
                requestBackupsData();
                break;
            case R.id.lt_hospital_doctorstatus_view:
                //跳转医师资格证
                toJumoAptitude();
                break;
            case R.id.lt_hospital_practising_view:
                toJumpPractice();
                break;
            //跳转到备案协议
            case R.id.lt_hospital_argeement_up:
                ToJumpHelp.toJumpProtocolNetWorkHospitalProtocol(LT_HospitalBackupsActivity.this,"");
                break;
            //跳转到备案协议
            case R.id.lt_hospital_argeement_down:
                ToJumpHelp.toJumpProtocolNetWorkHospitalProtocol(LT_HospitalBackupsActivity.this,"");
                break;
        }

    }
    //进入医师执业证页面
    private void toJumpPractice() {
        if ("2".equals(viewFlag)) {
            //审核通过
            ArrayList<String> urlList = new ArrayList<>();
            if ("1".equals(backupsBean.getPractisingVersionType())) {
                urlList.add(backupsBean.getPractisingNewImageUrl());
            }else if ("2".equals(backupsBean.getPractisingVersionType())) {
                urlList.add(backupsBean.getPractisingOldUpImageUrl());
                urlList.add(backupsBean.getPractisingOldDownImageUrl());
            }
            ToJumpHelp.toJumpChatImageShowActivity(LT_HospitalBackupsActivity.this, urlList, 0);
            return;
        }else if("0".equals(viewFlag) || "3".equals(viewFlag) || "4".equals(viewFlag)){
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingNewImageUrl()))
                practisingNewfile = new File(HospitalBackupsBeanSP.getPractisingNewImageUrl());
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingOldUpImageUrl()))
                practisingOldUpImage = new File(HospitalBackupsBeanSP.getPractisingOldUpImageUrl());
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingOldDownImageUrl()))
                practisingOldDownImage = new File(HospitalBackupsBeanSP.getPractisingOldDownImageUrl());
        }
        Intent intent = new Intent();
        if (practisingNewfile != null) {
            intent.putExtra("filePath", practisingNewfile.getAbsolutePath());
        } else if (practisingOldUpImage != null && practisingOldDownImage != null) {
            intent.putExtra("filePath", practisingOldUpImage.getAbsolutePath() +
                    "," + practisingOldDownImage.getAbsolutePath());
        } else {
            intent.putExtra("filePath", "");
        }
        if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getDoctorPracticeCertificateString())){
            intent.putExtra("doctorPracticeCertificateString", HospitalBackupsBeanSP.getDoctorPracticeCertificateString());
        }else {
            intent.putExtra("doctorPracticeCertificateString", doctorPracticeCertificateString);
        }
        intent.putExtra("startCode", "4");
        intent.setClass(LT_HospitalBackupsActivity.this, SX_QualificationSelectionActivity.class);
        startActivityForResult(intent, 4);
    }

    //进入医师资格证页面
    private void toJumoAptitude() {
        if ("2".equals(viewFlag)) {
            //审核通过
            ArrayList<String> AptitudeList = new ArrayList<>();
            if ("1".equals(backupsBean.getVersionType())) {
                AptitudeList.add(backupsBean.getNewDoctorQuqlification());
            }
            if ("2".equals(backupsBean.getVersionType())) {
                AptitudeList.add(backupsBean.getOldDoctorQuqlificationUp());
                AptitudeList.add(backupsBean.getOldDoctorQuqlificationDown());
            }
            ToJumpHelp.toJumpChatImageShowActivity(LT_HospitalBackupsActivity.this, AptitudeList, 0);
        }else if("0".equals(viewFlag) || "3".equals(viewFlag) || "4".equals(viewFlag)){
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getNewDoctorQuqlification())) {
                aptitudeNewfile = new File(HospitalBackupsBeanSP.getNewDoctorQuqlification());
                versionType = "1";
            }
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getOldDoctorQuqlificationUp()) && !TextUtils.isEmpty(HospitalBackupsBeanSP.getOldDoctorQuqlificationDown())) {
                aptitudeOldUpImage = new File(HospitalBackupsBeanSP.getOldDoctorQuqlificationUp());
                aptitudeOldDownImage = new File(HospitalBackupsBeanSP.getOldDoctorQuqlificationDown());
                aptitudeNewfile = null;
                versionType = "2";
            }
            ToJumpHelp.toJumpDoctorqualificationActivity(LT_HospitalBackupsActivity.this, aptitudeNewfile, aptitudeOldUpImage, aptitudeOldDownImage, versionType);
        } else {
            ToJumpHelp.toJumpDoctorqualificationActivity(LT_HospitalBackupsActivity.this, aptitudeNewfile, aptitudeOldUpImage, aptitudeOldDownImage, versionType);
        }
    }

    //进入身份证编辑页 || 大图页
    private void toJumpIDCard() {
        if ("2".equals(viewFlag)) {
            //审核通过
            ArrayList<String> idCardList = new ArrayList<>();
            idCardList.add(backupsBean.getIdCardUpUrl());
            idCardList.add(backupsBean.getIdCardDownUrl());
            ToJumpHelp.toJumpChatImageShowActivity(LT_HospitalBackupsActivity.this, idCardList, 0);
        } else if("0".equals(viewFlag) || "3".equals(viewFlag) || "4".equals(viewFlag)){
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getIdCardUpUrl()))
                frontImage = new File(HospitalBackupsBeanSP.getIdCardUpUrl());
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getIdCardDownUrl()))
                reverseImage = new File(HospitalBackupsBeanSP.getIdCardDownUrl());
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getIdCardNum()))
                idCardNun = HospitalBackupsBeanSP.getIdCardNum();
            ToJumpHelp.toJumpIDCardEditorActivity(LT_HospitalBackupsActivity.this, frontImage, reverseImage, idCardNun);
        }else {
            ToJumpHelp.toJumpIDCardEditorActivity(LT_HospitalBackupsActivity.this, frontImage, reverseImage, idCardNun);
        }
    }

    //进入职称证书展示页 || 大图页
    private void toJumpCFE() {
        if ("2".equals(viewFlag)) {
            ArrayList<String> cfelist = new ArrayList<String>();
            cfelist.add(backupsBean.getTitleCertificateUrl());
            ToJumpHelp.toJumpChatImageShowActivity(LT_HospitalBackupsActivity.this, cfelist, 0);
        } else if("0".equals(viewFlag) || "3".equals(viewFlag) || "4".equals(viewFlag)) {
            if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getTitleCertificateUrl()))
                cfefile = new File(HospitalBackupsBeanSP.getTitleCertificateUrl());
            ToJumpHelp.toJumpCertificateEditorActivity(LT_HospitalBackupsActivity.this, cfefile);
        } else {
            //编辑页
            ToJumpHelp.toJumpCertificateEditorActivity(LT_HospitalBackupsActivity.this, cfefile);
        }
    }

    /**
     * 读取本地图片数据
     */
    private void getLocalData(){
        if("0".equals(viewFlag) || "3".equals(viewFlag) || "4".equals(viewFlag)) {
            if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getIdCardUpUrl()))
                frontImage = new File(HospitalBackupsBeanSP.getIdCardUpUrl());
            if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getIdCardDownUrl()))
                reverseImage = new File(HospitalBackupsBeanSP.getIdCardDownUrl());
            if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getIdCardNum()))
                idCardNun = HospitalBackupsBeanSP.getIdCardNum();
            if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getTitleCertificateUrl()))
                cfefile = new File(HospitalBackupsBeanSP.getTitleCertificateUrl());
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getNewDoctorQuqlification())) {
                aptitudeNewfile = new File(HospitalBackupsBeanSP.getNewDoctorQuqlification());
                versionType = "1";
            }
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getOldDoctorQuqlificationUp()) && !TextUtils.isEmpty(HospitalBackupsBeanSP.getOldDoctorQuqlificationDown())) {
                aptitudeOldUpImage = new File(HospitalBackupsBeanSP.getOldDoctorQuqlificationUp());
                aptitudeOldDownImage = new File(HospitalBackupsBeanSP.getOldDoctorQuqlificationDown());
                aptitudeNewfile = null;
                versionType = "2";
            }
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingNewImageUrl()))
                practisingNewfile = new File(HospitalBackupsBeanSP.getPractisingNewImageUrl());
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingOldUpImageUrl()))
                practisingOldUpImage = new File(HospitalBackupsBeanSP.getPractisingOldUpImageUrl());
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingOldDownImageUrl()))
                practisingOldDownImage = new File(HospitalBackupsBeanSP.getPractisingOldDownImageUrl());
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getDoctorPracticeCertificateString())){
                doctorPracticeCertificateString = HospitalBackupsBeanSP.getDoctorPracticeCertificateString();
            }
        }
    }

    /**
     * 提交数据
     */
    private void commitData() throws FileNotFoundException {
        RequestParams params = getParamsData();

        XCHttpAsyn.postAsyn(true, LT_HospitalBackupsActivity.this, AppConfig.getHostUrl(AppConfig.backups), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    //提交完成后修改本地状态为备案审核中
                    UtilSP.setDoctorStatus("1");
                    // 提交完成后清空本地图片Sp
                    HospitalBackupsBeanSP.clearAllImageUrl();
                    // flag (integer, optional): 是否为广东省医生（0：否，1：是） ,
                    // remindInfo (string, optional): 提醒信息

                    if("1".equals(result_bean.getList("data").get(0).getString("flag"))) {
                        showRecordDialog(result_bean.getList("data").get(0).getString("remindInfo"));
                    }else {
                        showSuccess();
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                dismissCommit();
                lt_hospital_contentview.setVisibility(View.GONE);
                lt_hospital_nonetview.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LT_HospitalBackupsActivity.this, getCode(), getMsg())) {
                    dismissCommit();
                } else {
                    dismissCommit();
                }
            }
        });
    }

    private RequestParams getParamsData() throws FileNotFoundException {
        RequestParams params = new RequestParams();
        if("0".equals(viewFlag) || "3".equals(viewFlag) || "4".equals(viewFlag)) {
            // 身份证正面
            if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getIdCardUpUrl())){
                File frontImage = new File(HospitalBackupsBeanSP.getIdCardUpUrl());
                params.put("idCardUp", frontImage);
            }
            // 身份证背面
            if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getIdCardDownUrl())) {
                File reverseImage = new File(HospitalBackupsBeanSP.getIdCardDownUrl());
                params.put("idCardDown", reverseImage);
            }
            // 身份证号
            if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getIdCardNum())) {
                idCardNun = HospitalBackupsBeanSP.getIdCardNum();
            }
            // 职称
            if (!TextUtils.isEmpty(HospitalBackupsBeanSP.getTitleCertificateUrl())) {
                File cfefile = new File(HospitalBackupsBeanSP.getTitleCertificateUrl());
                params.put("titleCertificate", cfefile);
            }
            // 新版资格
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getNewDoctorQuqlification())) {
                File aptitudeNewfile = new File(HospitalBackupsBeanSP.getNewDoctorQuqlification());
                versionType = "1";
                params.put("photoPage", aptitudeNewfile);
            }
            // 旧版资格
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getOldDoctorQuqlificationUp()) && !TextUtils.isEmpty(HospitalBackupsBeanSP.getOldDoctorQuqlificationDown())) {
                File aptitudeOldUpImage = new File(HospitalBackupsBeanSP.getOldDoctorQuqlificationUp());
                File aptitudeOldDownImage = new File(HospitalBackupsBeanSP.getOldDoctorQuqlificationDown());
                aptitudeNewfile = null;
                versionType = "2";
                params.put("photoPage", aptitudeOldUpImage);
                params.put("infoPage", aptitudeOldDownImage);
            }
            // 新版职业证
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingNewImageUrl())) {
                File practisingNewfile = new File(HospitalBackupsBeanSP.getPractisingNewImageUrl());
                params.put("licensePhotoPage", practisingNewfile);
            }
            // 旧版职业证
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingOldUpImageUrl())) {
                File practisingOldUpImage = new File(HospitalBackupsBeanSP.getPractisingOldUpImageUrl());
                params.put("licensePhotoPage", practisingOldUpImage);
            }
            // 旧版职业证
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getPractisingOldDownImageUrl())) {
                File practisingOldDownImage = new File(HospitalBackupsBeanSP.getPractisingOldDownImageUrl());
                params.put("licenseInfoPage", practisingOldDownImage);
            }
            if(!TextUtils.isEmpty(HospitalBackupsBeanSP.getDoctorPracticeCertificateString())){
                doctorPracticeCertificateString = HospitalBackupsBeanSP.getDoctorPracticeCertificateString();
            }
            params.put("idNumber", idCardNun);
            params.put("versionType", versionType);
            // 医师执业证号
            params.put("number", doctorPracticeCertificateString);
            // 医师执业证类型(1:新版,2:旧版本)
            params.put("licenseType", practisingVersionType);
        }
        return params;
    }

    private void checkButton() {

        if (frontImage != null && reverseImage != null
                && !TextUtils.isEmpty(idCardNun) && cfefile != null
                && ((aptitudeNewfile != null) ||
                (aptitudeOldUpImage != null && aptitudeOldDownImage != null))) {
            lt_hospital_commitbt.setTextColor(getResources().getColor(R.color.c_e2231a));
        } else {
            lt_hospital_commitbt.setTextColor(getResources().getColor(R.color.c_login_text_bg));
        }
    }


    public void SendDalogMsg() {
        if (frontImage != null && reverseImage != null && !TextUtils.isEmpty(idCardNun) && cfefile != null
                && ((aptitudeNewfile != null) ||
                (aptitudeOldUpImage != null && aptitudeOldDownImage != null))
                && ((practisingNewfile != null) ||
                (practisingOldUpImage != null && practisingOldDownImage != null))) {
            showCommit();
        } else {
            if (frontImage == null) {
                shortToast("请添加您的身份证");
            }
            if (cfefile == null) {
                shortToast("请添加您的职称证书");
            }
            if (aptitudeOldUpImage == null && aptitudeNewfile == null) {
                shortToast("请添加您的医师资格证");
            }
            if ( ((practisingNewfile == null) ||
                    (practisingOldUpImage == null && practisingOldDownImage == null))){
                shortToast("请添加您的医师执业证");
            }
        }
    }

    private void initDialog() {

        if (commitDialog == null) {
            String commitText = "审核通过前不可撤销,请再次确认资料真实性";
            commitDialog = new YR_CommonDialog(LT_HospitalBackupsActivity.this, commitText, "取消", "确定") {
                @Override
                public void confirmBtn() {
                    //提交数据
                    try {
                        commitData();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                        dismissCommit();
                        shortToast("您所提交的相关文件不存在");
                    }
                }

                @Override
                public void cancelBtn() {
                    super.cancelBtn();
                    dismissCommit();
                }
            };
        }

        if (successDialog == null) {
            String successText = "资料审核通过后，执业备案由卫健委分批进行，预计在3~6个月内完成，期间您可以正常使用石榴云医\n\n如有问题，您可以通过医生助手联系";
            successDialog = new YR_CommonDialog(LT_HospitalBackupsActivity.this, successText, "", "知道了") {
                @Override
                public void confirmBtn() {
                    Intent intent;
                    if(NativeHtml5.QLK_HOME.equals(HospitalBackupsBeanSP.TO_ACTIVITY)) {
                        intent = new Intent(LT_HospitalBackupsActivity.this, JS_MainActivity.class);
                        intent.putExtra(JS_MainActivity.IS_SHOWN_IDENTYFY_DIALOG, true);
                        intent.putExtra(JS_MainActivity.TAB_TAG,JS_MainActivity.TAB_HOME);
                        startActivity(intent);
                        finish();
                    }else if(NativeHtml5.DOCTOR_MINE.equals(HospitalBackupsBeanSP.TO_ACTIVITY)){
                        intent = new Intent(LT_HospitalBackupsActivity.this, JS_MainActivity.class);
                        intent.putExtra(JS_MainActivity.TAB_TAG,JS_MainActivity.TAB_MY);
                        startActivity(intent);
                        finish();
                    }else if(NativeHtml5.RECOMMEND_DETAIL.equals(HospitalBackupsBeanSP.TO_ACTIVITY)){
                        SQ_RecommendActivity.launch(LT_HospitalBackupsActivity.this);
                        finish();
                    }else if(NativeHtml5.QLK_JIFEN_MANAGE.equals(HospitalBackupsBeanSP.TO_ACTIVITY)){
                        intent = new Intent(LT_HospitalBackupsActivity.this, XL_PointsActivityV2.class);
                        startActivity(intent);
                        finish();
                    }
                    dismissSuccess();
                }
            };
        }
    }

    private void showRecordDialog(String text){
        if(recordDialog == null){
            recordDialog = new YR_CommonDialog(this,"因您是广东省医生，根据卫健委要求还需要通过卫健委电子化注册系统提交多点执业备案申请","","查看电子注册教程"){
                @Override
                public void confirmBtn() {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("K",HospitalBackupsBeanSP.TO_ACTIVITY);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    UtilNativeHtml5.toJumpNativeH5(LT_HospitalBackupsActivity.this, UtilNativeHtml5.REGISTRATION_PROCESS,jsonObject.toString());
                    dismiss();
                    LT_HospitalBackupsActivity.this.finish();
                }
            };
        }
        recordDialog.setTitle("提交成功");
        recordDialog.show();
        recordDialog.setCancelable(false);
    }

    private void dismissCommit() {
        if (commitDialog != null) {
            commitDialog.dismiss();
        }
    }

    private void showCommit() {
        if (commitDialog != null) {
            commitDialog.show();
        }
    }

    private void dismissSuccess() {
        if (successDialog != null) {
            successDialog.dismiss();
        }
    }

    private void showSuccess() {
        if (successDialog != null) {
            successDialog.show();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case 0:
                    //身份证编辑页
                    if (data == null) {
                        return;
                    }
                    frontImage = (File) data.getSerializableExtra("frontImage");
                    reverseImage = (File) data.getSerializableExtra("reverseImage");
                    idCardNun = data.getStringExtra("idCardNum");
                    if (frontImage != null && reverseImage != null && !TextUtils.isEmpty(idCardNun)) {
                        HospitalBackupsBeanSP.setIdCardUpUrl(frontImage.getAbsolutePath());
                        HospitalBackupsBeanSP.setIdCardDownUrl(reverseImage.getAbsolutePath());
                        HospitalBackupsBeanSP.setIdCardNum(idCardNun);
                    }
                    goneMustfill();
                    break;
                case 1:
                    //职称证书编辑页
                    if (data == null) {
                        return;
                    }
                    cfefile = (File) data.getSerializableExtra("cfefile");
                    if (cfefile != null) {
                        HospitalBackupsBeanSP.setTitleCertificateUrl(cfefile.getAbsolutePath());
                    }
                    goneMustfill();
                    break;
                case 2:
                    setSignatureView();
                    break;

                case 3:
                    //医师资格证
                    if (data == null) {
                        return;
                    }
                    aptitudeNewfile = (File) data.getSerializableExtra("backNewImage");
                    aptitudeOldUpImage = (File) data.getSerializableExtra("backOldUpImage");
                    aptitudeOldDownImage = (File) data.getSerializableExtra("backOldDownImage");
                    if (aptitudeNewfile != null) {
                        versionType = "1";
                    }
                    if (aptitudeOldUpImage != null && aptitudeOldDownImage != null) {
                        versionType = "2";
                    }
                    if (aptitudeNewfile != null || (aptitudeOldUpImage != null && aptitudeOldDownImage != null)) {
                        if (aptitudeNewfile != null) {
                            HospitalBackupsBeanSP.setNewDoctorQuqlification(aptitudeNewfile.getAbsolutePath());
                            HospitalBackupsBeanSP.setOldDoctorQuqlificationUp("");
                            HospitalBackupsBeanSP.setOldDoctorQuqlificationDown("");
                        }else if (aptitudeOldUpImage != null && aptitudeOldDownImage != null) {
                            HospitalBackupsBeanSP.setOldDoctorQuqlificationUp(aptitudeOldUpImage.getAbsolutePath());
                            HospitalBackupsBeanSP.setOldDoctorQuqlificationDown(aptitudeOldDownImage.getAbsolutePath());
                            HospitalBackupsBeanSP.setNewDoctorQuqlification("");
                        }
                    }
                    goneMustfill();
                    break;

                case 4:
                    doctorPracticeCertificateString = data.getStringExtra("doctorPracticeCertificateString");
                    mDoctorPracticeCertificatePath = data.getStringExtra("filePath");
                    if (!UtilString.isBlank(mDoctorPracticeCertificatePath)) {
                        if (mDoctorPracticeCertificatePath.contains("http")) {
                            if (mDoctorPracticeCertificatePath.contains(",")) {
                                practisingVersionType = "2";
                                String filePaths[] = mDoctorPracticeCertificatePath.split(",");
                                XCApplication.displayImage(filePaths[0], imageView6);
                                XCApplication.displayImage(filePaths[1], imageView7);
                                practisingOldUpImage = XCApplication.base_imageloader.getDiscCache().get(filePaths[0]);
                                practisingOldDownImage = XCApplication.base_imageloader.getDiscCache().get(filePaths[1]);
                                practisingNewfile = null;
                            } else {
                                practisingVersionType = "1";
                                XCApplication.displayImage(mDoctorPracticeCertificatePath, imageView6);
                                practisingNewfile = XCApplication.base_imageloader.getDiscCache().get(mDoctorPracticeCertificatePath);
                                practisingOldUpImage = null;
                                practisingOldDownImage = null;
                            }
                        } else {
                            if (mDoctorPracticeCertificatePath.contains(",")) {
                                practisingVersionType = "2";
                                String filePaths[] = mDoctorPracticeCertificatePath.split(",");
                                File picFile = new File(filePaths[0]);
                                if (!picFile.isFile()) {
                                    return;
                                }
                                practisingOldUpImage = picFile;
                                File infoFile = new File(filePaths[1]);
                                if (!infoFile.isFile()) {
                                    return;
                                }
                                practisingOldDownImage = infoFile;
                                practisingNewfile = null;
                            } else {
                                practisingVersionType = "1";
                                File infoFile = new File(mDoctorPracticeCertificatePath);
                                if (!infoFile.isFile()) {
                                    return;
                                }
                                practisingNewfile = infoFile;
                                practisingOldUpImage = null;
                                practisingOldDownImage = null;
                            }
                        }
                    }
                    if (practisingNewfile != null || (practisingOldUpImage != null && practisingOldDownImage != null)) {
                        if (practisingNewfile != null) {
                            HospitalBackupsBeanSP.setPractisingNewImageUrl(practisingNewfile.getAbsolutePath());
                            HospitalBackupsBeanSP.setPractisingOldUpImageUrl("");
                            HospitalBackupsBeanSP.setPractisingOldDownImageUrl("");
                        }else if (practisingOldUpImage != null && practisingOldDownImage != null) {
                            HospitalBackupsBeanSP.setPractisingOldUpImageUrl(practisingOldUpImage.getAbsolutePath());
                            HospitalBackupsBeanSP.setPractisingOldDownImageUrl(practisingOldDownImage.getAbsolutePath());
                            HospitalBackupsBeanSP.setPractisingNewImageUrl("");
                        }
                        HospitalBackupsBeanSP.setDoctorPracticeCertificateString(doctorPracticeCertificateString);
                    }
                    goneMustfill();
                    break;
            }
        }
    }
}
