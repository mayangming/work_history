package com.qlk.ymz.db.im.chatmodel;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * description: 聊天消息中的新的量表内容
 * autour: YM
 * date: 2018/6/27
 * update: $date$
 * version: $version$
 */

public class ChatModelScaleNew implements Serializable,Cloneable{
    private String scaleId = "";//量表Id
    private String title = "";//量表标题
    private String detailUrl = "";//量表明细查询地址
    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getScaleId() {
        return scaleId;
    }

    public void setScaleId(String scaleId) {
        this.scaleId = scaleId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetailUrl() {
        return detailUrl;
    }

    public void setDetailUrl(String detailUrl) {
        this.detailUrl = detailUrl;
    }

}
