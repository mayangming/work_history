package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.YY_feedbackTemBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.SX_ClearEditText;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.LinkedList;
import java.util.List;

/**
 * @author shuYanYi on 2016/11/07.
 * @description 增加/编辑随访模板
 * @version V2.6.5
 */
public class YY_TemplateEditActivity extends DBActivity {

    /** 标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** 列表适配器*/
    private TemplateListEditAdapter adapter;

    private List<YY_feedbackTemBean> list = new LinkedList<>();
    /** 随访模板列表*/
    private XCListViewFragment listViewFragment;

    private String temName = "";
    /** 问题数量限制*/
    private int maxQuestionNum = 7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yy_l_template_edit);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-22,about：saveInfo,begin
        BiUtil.saveBiInfo(YY_TemplateEditActivity.class, "1", "", "","", false);
        // created by songxin,date：2016-4-22,about：saveInfo,end

    }


    /** created by songxin,date：2016-8-16,about：bi,begin*/
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YY_TemplateEditActivity.class);
    }
    /** created by songxin,date：2016-8-16,about：bi,end*/

    @Override
    public void initWidgets() {
        Intent intent = getIntent();
        if (intent != null) {
            temName = intent.getStringExtra("name");
        }
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        if (UtilString.isBlank(temName)) {
            temName = "新建自定义模板";
        }
        xc_id_model_titlebar.setTitleCenter(true, temName);
        xc_id_model_titlebar.setTitleLeft(R.drawable.xc_d_main_close, null);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) xc_id_model_titlebar.getXc_id_titlebar_left_imageview().getLayoutParams();
        ;
        lp.width = ViewGroup.LayoutParams.WRAP_CONTENT;
        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        xc_id_model_titlebar.setTitleRight2(true, 0, "保存");
        for (int i = 1; i <= maxQuestionNum; i++) {
            list.add(new YY_feedbackTemBean());
        }
        adapter = new TemplateListEditAdapter(this, list);
        listViewFragment = new XCListViewFragment();
        listViewFragment.setAdapter(adapter);
        listViewFragment.setMode(XCListViewFragment.MODE_NOT_PULL);//设置不能上下拉
        listViewFragment.setBgZeroHintInfo("暂无模板", "", R.mipmap.js_d_icon_no_data);//无数据遮罩
        addFragment(R.id.lv_templete_list_edit, listViewFragment);
    }

    @Override
    public void listeners() {
        //保存按钮
        xc_id_model_titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSave();
            }
        });
    }

    @Override
    public void onNetRefresh() {


    }

    @Override
    protected void onResume() {
        super.onResume();


    }

    @Override
    public void onClick(final View v) {
        super.onClick(v);
    }

    private void requestSave(){
        // TODO: 2016/11/9 待api
        //过滤没写问题的bean
        List<YY_feedbackTemBean> uploadList = new LinkedList<>();
        for(YY_feedbackTemBean bean : list){
            if(bean != null && !UtilString.isBlank(bean.getQuestion())){
                uploadList.add(bean);
            }
        }
        Gson gson = new Gson();
        String templetInfo = gson.toJson(uploadList);

        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("templetInfo", templetInfo);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.feedback_edit_template), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (!result_boolean) {
                    return;
                }
                if("0".equals(getCode())){
                    myFinish();
                }else{
                    shortToast(getMsg());
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(YY_TemplateEditActivity.this,
                        getCode(),
                        getMsg())){
                    // 接口请求业务成功时的处理
                }
            }
        });
    }


    /**
     * 编辑模板适配器
     */
    class TemplateListEditAdapter extends XCBaseAdapter<YY_feedbackTemBean> {
        //保存当前被触摸的EditText的位置
        private int mTouchItemPosition = -1;

        public TemplateListEditAdapter(Context context, List<YY_feedbackTemBean> list) {
            super(context, list);
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup viewGroup) {
            ViewHolder holder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(R.layout.yy_item_feedback_template_edit, null);
                holder = new ViewHolder(convertView);

                holder.tv_content.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        mTouchItemPosition = (Integer) v.getTag();
                        return false;
                    }
                });
                // 让ViewHolder持有一个TextWathcer，动态更新position来防治数据错乱
                holder.mTextWatcher = new MyTextWatcher();
                holder.tv_content.addTextChangedListener(holder.mTextWatcher);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            YY_feedbackTemBean bean = list.get(position);
            holder.updatePosition(position);
            String question = bean.getQuestion();
            //只在第一个框设置提示
            if (position == 0 && UtilString.isBlank(question)) {
                holder.tv_content.setHint("请输入问题（至少设置一个问题，50个字符）");
            }
            holder.tv_num.setText(String.valueOf(position + 1) + "、");
            holder.tv_content.setText(question);
            holder.tv_content.setTag(position);
            if (mTouchItemPosition == position) {
                holder.tv_content.requestFocus();
                holder.tv_content.setSelection(holder.tv_content.getText().length());
            } else {
                holder.tv_content.clearFocus();
            }

            //点击其他地方隐藏键盘
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    UtilInputMethod.hiddenInputMethod(context);
                }
            });

            //多选的答案布局
            if(bean.getAnswerType() == YY_feedbackTemBean.ANSWER_TYPE_MULTISELECT){
                // TODO: syy 2016/11/9   待UI
            }
            return convertView;
        }

        private class ViewHolder {
            private SX_ClearEditText tv_content;
            private TextView tv_num;
            MyTextWatcher mTextWatcher;
            //动态更新TextWathcer的position
            public void updatePosition(int position) {
                mTextWatcher.updatePosition(position);
            }

            public ViewHolder(View convertView) {
                tv_content = (SX_ClearEditText) convertView.findViewById(R.id.tv_content);
                tv_num = (TextView) convertView.findViewById(R.id.tv_num);
            }
        }

        /**
         * 自定义一个TextWatcher类，以更新对应的position
         */
        class MyTextWatcher implements TextWatcher {
            private int mPosition;
            public void updatePosition(int position) {
                mPosition = position;
            }
            @Override
            public void afterTextChanged(Editable s) {
                YY_feedbackTemBean bean = list.get(mPosition);
                if(bean == null) {
                    return;
                }
                bean.setQuestion(s.toString());
                list.set(mPosition, bean);
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        }

    }
}
