package com.qlk.ymz.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.adapter.ImageAdapter;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.model.record.ImgListBean;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2018/6/25.
 * v2.19 病历预览fragment
 */

public class XD_CasePreviewFragment extends DBFragment {

    /** 患者姓名*/
    private TextView tv_patient_name;
    /** 患者年龄*/
    private TextView tv_patient_age;
    /** 患者性别*/
    private TextView tv_patient_sex;
    /** 时间*/
    private TextView tv_time;

    /** 医生填写部分*/
    private LinearLayout ll_doctor_edit;
    /** 主诉布局*/
    private LinearLayout ll_suit;
    /** 主诉*/
    private TextView tv_suit;
    /** 既往史布局*/
    private LinearLayout ll_history;
    /** 既往史*/
    private TextView tv_history;
    /** 检查指标布局*/
    private LinearLayout ll_check;
    /** 检查指标*/
    private TextView tv_check;
    /** 其它检查布局*/
    private LinearLayout ll_other_check;
    /** 其它检查*/
    private TextView tv_other_check;
    /** 诊断布局*/
    private LinearLayout ll_diagnosis;
    /** 诊断*/
    private TextView tv_diagnosis;
    /** 医嘱小结布局*/
    private LinearLayout ll_doctor_advice;
    /** 医嘱小结*/
    private TextView tv_doctor_advice;

    /** 图片布局*/
    private LinearLayout ll_doctor_pic;
    /** 图片列表*/
    private RecyclerView rv_doctor_pic;

    /** 医生科室*/
    private TextView tv_department;
    /** 医生姓名*/
    private LinearLayout ll_doctor_name;
    private TextView tv_doctor_name;
    /** 医院*/
    private LinearLayout ll_hospital;
    private TextView tv_hospital;

    private DrRecordVOBean mDrRecordVOBean;
    private boolean haveDoctorEdit = false;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return init(inflater, R.layout.xd_fragment_case_preview);
    }

    @Override
    public void initWidgets() {
        tv_patient_name = getViewById(R.id.tv_patient_name);
        tv_patient_age = getViewById(R.id.tv_patient_age);
        tv_patient_sex = getViewById(R.id.tv_patient_sex);
        tv_time = getViewById(R.id.tv_time);

        ll_doctor_edit = getViewById(R.id.ll_doctor_edit);
        ll_suit = getViewById(R.id.ll_suit);
        tv_suit = getViewById(R.id.tv_suit);
        ll_history = getViewById(R.id.ll_history);
        tv_history = getViewById(R.id.tv_history);
        ll_check = getViewById(R.id.ll_check);
        tv_check = getViewById(R.id.tv_check);
        ll_other_check = getViewById(R.id.ll_other_check);
        tv_other_check = getViewById(R.id.tv_other_check);
        ll_diagnosis = getViewById(R.id.ll_diagnosis);
        tv_diagnosis = getViewById(R.id.tv_diagnosis);
        ll_doctor_advice = getViewById(R.id.ll_doctor_advice);
        tv_doctor_advice = getViewById(R.id.tv_doctor_advice);

        ll_doctor_pic = getViewById(R.id.ll_doctor_pic);
        rv_doctor_pic = getViewById(R.id.rv_doctor_pic);

        tv_department = getViewById(R.id.tv_department);
        ll_doctor_name = getViewById(R.id.ll_doctor_name);
        tv_doctor_name = getViewById(R.id.tv_doctor_name);
        ll_hospital = getViewById(R.id.ll_hospital);
        tv_hospital = getViewById(R.id.tv_hospital);
    }

    @Override
    public void listeners() {
        initData();
    }

    public void initData() {
        if(mDrRecordVOBean!=null){
            tv_patient_name.setText("姓名："+mDrRecordVOBean.getName());
            tv_patient_age.setText("年龄："+mDrRecordVOBean.getAge()+mDrRecordVOBean.getAgeUnit());
            tv_time.setText("时间："+ DateUtils.DateFormat(mDrRecordVOBean.getCreateAt(),"yyyy/MM/dd"));
            if("0".equals(mDrRecordVOBean.getGender())){
                tv_patient_sex.setText("性别：女");
            }else if("1".equals(mDrRecordVOBean.getGender())){
                tv_patient_sex.setText("性别：男");
            }
            if(!TextUtils.isEmpty(UtilSP.getFirstDepartmentName())){
                tv_department.setVisibility(View.VISIBLE);
                tv_department.setText("科室："+UtilSP.getFirstDepartmentName());
            }
            DrCaseVOBean drCaseVOBean = (DrCaseVOBean) mDrRecordVOBean.getMdicalRecordVO();
            if(UtilString.isAllBlank(drCaseVOBean.getMainComplaint(),drCaseVOBean.getPresentDisease())){
                ll_suit.setVisibility(View.GONE);
            }else {
                haveDoctorEdit = true;
                ll_suit.setVisibility(View.VISIBLE);
                String suitStr = "";
                if (!TextUtils.isEmpty(drCaseVOBean.getMainComplaint())) {
                    suitStr = getTrimStr("",drCaseVOBean.getMainComplaint(),"") +"\n"+
                            getTrimStr("现病史：", drCaseVOBean.getPresentDisease(),"");
                }else {
                    suitStr = getTrimStr("现病史：", drCaseVOBean.getPresentDisease(),"");
                }
                tv_suit.setText(clearEnd(suitStr));
            }
            fillDoctorEditWidget(ll_history,tv_history,drCaseVOBean.getPastHistory(),"");
            if(UtilString.isAllBlank(drCaseVOBean.getTemperature(), drCaseVOBean.getWeight(),
                    drCaseVOBean.getHeartRete(),drCaseVOBean.getDiastole(),
                    drCaseVOBean.getSystolic(),drCaseVOBean.getMoreExamin())){
                ll_check.setVisibility(View.GONE);
            }else {
                haveDoctorEdit = true;
                ll_check.setVisibility(View.VISIBLE);
                String str = getTrimStr("体温：",drCaseVOBean.getTemperature(),"度")+
                        getTrimStr("体重：", drCaseVOBean.getWeight(),"kg")+
                        getTrimStr("心率：",drCaseVOBean.getHeartRete(),"bpm")+
                        getTrimStr("收缩压：", drCaseVOBean.getSystolic(),"mmhg")+
                        getTrimStr("舒张压：",drCaseVOBean.getDiastole(),"mmhg")+
                        getTrimStr("",drCaseVOBean.getMoreExamin(),"");
                tv_check.setText(clearEnd(str));
            }
            if("1".equals(drCaseVOBean.getTemplateType())||UtilString.isAllBlank(drCaseVOBean.getAlt(), drCaseVOBean.getAst(),drCaseVOBean.getHbvDna())){
                ll_other_check.setVisibility(View.GONE);
            }else {
                haveDoctorEdit = true;
                ll_other_check.setVisibility(View.VISIBLE);
                String str = getTrimStr("谷丙转氨酶(ALT)：",drCaseVOBean.getAlt(),"IU/ml")+
                        getTrimStr("谷草转氨酶(AST)：",drCaseVOBean.getAst(),"IU/ml")+
                        getTrimStr("HBV-DNA：",drCaseVOBean.getHbvDna(),"IU/ml");
                tv_other_check.setText(clearEnd(str));
            }
            fillDoctorEditWidget(ll_diagnosis,tv_diagnosis,drCaseVOBean.getDiagnosis(),"");
            if(TextUtils.isEmpty(drCaseVOBean.getDoctorOrder())&&"2".equals(drCaseVOBean.getRevisitFalg())){
                ll_doctor_advice.setVisibility(View.GONE);
            }else {
                haveDoctorEdit = true;
                ll_doctor_advice.setVisibility(View.VISIBLE);
                String str = "";
                if("2".equals(drCaseVOBean.getRevisitFalg())){
                    str= drCaseVOBean.getDoctorOrder();
                }else {
                    if("月".equals(drCaseVOBean.getRevisitDateUnit())){
                        str= getTrimStr("下次复诊时间：",drCaseVOBean.getRevisitNumber() +"个"+drCaseVOBean.getRevisitDateUnit(),"后")+
                                getTrimStr( "", drCaseVOBean.getDoctorOrder(),"");
                    }else {
                        str= getTrimStr("下次复诊时间：",drCaseVOBean.getRevisitNumber() +drCaseVOBean.getRevisitDateUnit(),"后")+
                                getTrimStr( "", drCaseVOBean.getDoctorOrder(),"");
                    }
                }
                tv_doctor_advice.setText(clearEnd(str));
            }

            //展示医生填写信息
            if(haveDoctorEdit){
                ll_doctor_edit.setVisibility(View.VISIBLE);
            }
            //展示图片
            List<ImgListBean> imgList = drCaseVOBean.getImgList();
            fillPicWidget(ll_doctor_pic,rv_doctor_pic,imgList);

            fillDoctorEditWidget(ll_doctor_name,tv_doctor_name,UtilSP.getUserName(),"");
            fillDoctorEditWidget(ll_hospital,tv_hospital,UtilSP.getHospitalName(),"");
        }
    }

    public void setDrRecordVOBean(DrRecordVOBean drRecordVOBean) {
        mDrRecordVOBean = drRecordVOBean;
    }

    /**
     * 填写医生输入的控件
     * @param viewGroup
     * @param textView
     * @param str
     * @param unit
     */
    private void fillDoctorEditWidget(ViewGroup viewGroup, TextView textView, String str, String unit){
        if(TextUtils.isEmpty(str)){
            viewGroup.setVisibility(View.GONE);
        }else {
            haveDoctorEdit =true;
            viewGroup.setVisibility(View.VISIBLE);
            textView.setText(str+unit);
        }
    }

    /**
     * 填充图片控件
     * @param viewGroup
     * @param rv
     * @param strings
     */
    private void fillPicWidget(ViewGroup viewGroup, RecyclerView rv, List<ImgListBean> imgListBeans){
        if(imgListBeans!=null&&imgListBeans.size()>0){
            ArrayList<String> imgList = new ArrayList<>();
            final ArrayList<String> urls = new ArrayList<>();
            for(ImgListBean imgListBean:imgListBeans){
                imgList.add(imgListBean.getImgUrl());
                if(!imgListBean.getImgUrl().startsWith("http")){
                    urls.add("file://"+imgListBean.getImgUrl());
                }else {
                    urls.add(imgListBean.getImgUrl());
                }
            }
            viewGroup.setVisibility(View.VISIBLE);
            //此设置优化recyclerview
            rv.setHasFixedSize(true);
            //设置recyclerview的布局方式
            rv.setLayoutManager(new GridLayoutManager(getActivity(), 4));
            //设置适配器
            ImageAdapter imageAdapter = new ImageAdapter(getActivity(),imgList);
            imageAdapter.setOnItemClickListener(new ImageAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(int position) {
                    ToJumpHelp.toJumpChatImageShowActivity(getActivity(), urls,position);}
            });
            rv.setAdapter(imageAdapter);
        }
    }

    private String getTrimStr(String str,String values,String unit){
        String s ="";
        s +=TextUtils.isEmpty(values)? "":str+values+unit+"\n";
        return s;
    }

    private String clearEnd(String str){
        while (str.endsWith("\n")){
            str = UtilString.getStringWithoutLast(str,"\n");
        }
        return str;
    }

}
