package com.qlk.ymz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.TextChangedListenerUtil;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.SX_ClearEditText;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilRSA;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

/**
 * SX_ForgetPasswordActivity
 * 忘记密码
 * @author songxin on 2016/1/8.
 * @version 2.0
 */
public class SX_ForgetPasswordActivity extends DBActivity implements View.OnClickListener {
    /** title左边按钮*/
    private ImageView sx_id_title_left;
    /** title中间文字*/
    private TextView sx_id_title_center;
    /** 用户名输入框*/
    private SX_ClearEditText sx_l_register_username_edit;
    /** 输入密码框*/
    private SX_ClearEditText sx_l_register_pw_edit;
    /** 再次输入密码框*/
    private SX_ClearEditText sx_l_again_forget_pw_edit;
    /** 完成按钮*/
    private Button sx_l_over_set_button;
	/** 用户名(手机号)*/
	private String mUserName = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// 设置布局
		setContentView(R.layout.sx_l_activity_forget_password);
		super.onCreate(savedInstanceState);
		sx_id_title_center.setText("重新设置登录密码");
		mUserName = getIntent().getStringExtra("USERNAME");
		sx_l_register_username_edit.setText(mUserName);
		sx_l_register_username_edit.setClearIconVisible(false);
	}

	/** created by songxin,date：2016-4-23,about：bi,begin */
	@Override
	protected void onStart() {
		super.onStart();
		BiUtil.savePid(SX_ForgetPasswordActivity.class);
	}

	/** created by songxin,date：2016-4-23,about：bi,end */

	// 无网络时,点击屏幕后回调的方法
	@Override
	public void onNetRefresh() {
	}

	// 初始化控件
	@Override
	public void initWidgets() {
		sx_id_title_left = getViewById(R.id.sx_id_title_left);
		sx_id_title_center = getViewById(R.id.sx_id_title_center);
		sx_l_register_username_edit = getViewById(R.id.sx_l_register_username_edit);
		sx_l_register_pw_edit = getViewById(R.id.sx_l_register_pw_edit);
		sx_l_again_forget_pw_edit = getViewById(R.id.sx_l_again_forget_pw_edit);
		sx_l_over_set_button = getViewById(R.id.sx_l_over_set_button);
	}

	// 设置监听
	@Override
	public void listeners() {
		sx_id_title_left.setOnClickListener(this);
		sx_l_over_set_button.setOnClickListener(this);
		//监听输入框变化，控制登录按钮颜色，是否可点击
		TextChangedListenerUtil.textChanged(sx_l_register_username_edit,SX_ForgetPasswordActivity.this,sx_l_over_set_button,sx_l_register_pw_edit,sx_l_again_forget_pw_edit);
		//监听输入框变化，控制登录按钮颜色，是否可点击
		TextChangedListenerUtil.textChanged(sx_l_register_pw_edit,SX_ForgetPasswordActivity.this,sx_l_over_set_button,sx_l_register_username_edit,sx_l_again_forget_pw_edit);
		//监听输入框变化，控制登录按钮颜色，是否可点击
		TextChangedListenerUtil.textChanged(sx_l_again_forget_pw_edit,SX_ForgetPasswordActivity.this,sx_l_over_set_button,sx_l_register_username_edit,sx_l_register_pw_edit);

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()){
			case R.id.sx_id_title_left:{
				finish();
				break;
			}
			case R.id.sx_l_over_set_button:{
				doctorForgetPassword(sx_l_register_username_edit.getText().toString().trim(),
						sx_l_register_pw_edit.getText().toString().trim(),
						sx_l_again_forget_pw_edit.getText().toString().trim(), UtilSP.getPublicKey());
				break;
			}
			default:{
				break;
			}
		}
	}

	private void doctorForgetPassword(String username,String password,String newPassword,String pubKey) {
		if (UtilString.isBlank(username)) {
			shortToast("请输入手机号");
			return;
		}
		if (UtilString.isBlank(password) || UtilString.isBlank(newPassword)) {
			shortToast("请输入密码");
			return;
		}
		if (!UtilString.isPhoneNum(username)) {
			shortToast("手机号格式不对，请重新输入");
			return;
		}

		if (!newPassword.equals(password)) {
			shortToast("两次密码输入不同，请检查后重试");
			return;
		}
		RequestParams params = new RequestParams();
		params.put("phoneNum", username);
		params.put("password", UtilRSA.encryByRSA(pubKey, password));
		//成功进入填写注册信息
		XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.login_setForgetPwd), params, new XCHttpResponseHandler() {
			@Override
			public void onSuccess(int code, Header[] headers, byte[] arg2) {
				super.onSuccess(code, headers, arg2);
				if (result_boolean) {
					myStartActivity(LoginAndRegisterActivity.class);
					shortToast("密码重置成功！请重新登录");
				}
			}

			// add by xjs on 20151027 19:48 start
			// 对账户冻结情况的判断处理
			public void onFinish() {
				super.onFinish();
				if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_ForgetPasswordActivity.this,
						getCode(),
						getMsg())) {
					// 接口请求业务成功时的处理
				}
			}
			// add by xjs on 20151027 19:48 end
		});
	}
}
