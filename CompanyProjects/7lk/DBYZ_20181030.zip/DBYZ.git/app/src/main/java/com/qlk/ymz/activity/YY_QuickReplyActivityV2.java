package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.YY_BaseSwipeAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.UtilToast;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.SwipeLayout.SwipeOnTouchListener;
import com.qlk.ymz.view.SwipeLayout.SwipeViewHolder;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.util.List;

/**
 * @description 快捷回复新版、去掉多选删除功能，增加文字编辑、增加滑动删除
 * @author ShuYanYi on 2016-09-08
 * @version 2.7
 */
public class YY_QuickReplyActivityV2 extends DBActivity {

    /**标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** 快捷回复内容listview*/
    private ListView lv_replay;
    /** 添加内容按钮*/
    private TextView tv_add;
    /** 带滑动删除的适配器*/
    private YY_QuickReplyAdapter adapter;
    /** 数据集 */
    public List<XCJsonBean> dataList;
    /** 已有快捷回复条数*/
    private int dataCount = 0;
    /** 最多增加信息数量*/
    private int maxAddCount = 7;
    private View noDataView;
    /** 编辑时传递的内容key*/
    public static String KEY_EDIT_CONTENT = "edit_content";
    /** 编辑时传递的id key*/
    public static String KEY_EDIT_ID = "edit_id";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yy_l_activity_quick_replay);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void initWidgets() {
        lv_replay = getViewById(R.id.lv_replay);
        tv_add = getViewById(R.id.tv_add);
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleLeft(true, null);
        xc_id_model_titlebar.setTitleCenter(true, "快捷回复");
        xc_id_model_titlebar.setTitleRight2(true, 0, "编辑");
        initNoDataLayout();
        adapter = new YY_QuickReplyAdapter(YY_QuickReplyActivityV2.this,
                R.layout.yy_l_adapter_reply_item_v2,R.layout.yy_l_adapter_quick_replay_action,dataList);
        lv_replay.setAdapter(adapter);

    }

    @Override
    public void listeners() {
        tv_add.setOnClickListener(this);

        //编辑/完成点击切换状态
        xc_id_model_titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.isEdit = !adapter.isEdit;
                if(adapter.isEdit){
                    xc_id_model_titlebar.setTitleRight2(true, 0, "完成");
                    xc_id_model_titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_e2231a));
                }else{
                    xc_id_model_titlebar.setTitleRight2(true, 0, "编辑");
                    xc_id_model_titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
                }
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        requestQuickReplyList();
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(YY_QuickReplyActivityV2.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.tv_add:
                if(dataCount >= maxAddCount){
                    UtilToast.showCenterToast(YY_QuickReplyActivityV2.this,maxAddCount + "条已经够多了吧，别再添加啦！", 2000);
                    return;
                }
                myStartActivity(SK_AddQuickReplyActivity.class);
                overridePendingTransition(R.anim.activity_open_up, R.anim.activity_no_move);
                break;
        }
    }

    /**
     * 无网络背景的点击回调，重新请求数据
     */
    @Override
    public void onNetRefresh() {
        requestQuickReplyList();
    }


    /**
     * 请求快捷回复的列表数据接口
     */
    public void requestQuickReplyList(){
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.quickreply_list),  new RequestParams(), new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && result_bean != null) {
//                    listViewFragment.setBgZeroHintInfo("无快捷回复记录","",R.mipmap.js_d_icon_no_data);
                    dataList = result_bean.getList("data");
                    if(dataList == null || dataList.size() == 0){
                        noDataView.setVisibility(View.VISIBLE);
                    }else{
                        dataCount = dataList.size();
                        noDataView.setVisibility(View.GONE);
                    }
                    adapter.update(dataList);
                    adapter.notifyDataSetChanged();

                }
            }
            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YY_QuickReplyActivityV2.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });

    }



    /**
     * 请求删除快捷回复的接口
     * @param id 要删除的id
     */
    public void requestQuickReplyDelete(String id){
        RequestParams params = new RequestParams();
        params.put("ids",id);

        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.quickreply_remove),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean){
                    shortToast("删除成功");
                    requestQuickReplyList();
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YY_QuickReplyActivityV2.this,
                        getCode(),
                        getMsg())) {
                }
            }

        });

    }

    /**
     * 初始化无数据的布局
     */
    private void initNoDataLayout(){
        noDataView = findViewById(R.id.xc_id_listview_plus_zero_bg);
        ((ImageView)(findViewById(R.id.xc_id_data_zero_imageview))).setImageResource(R.mipmap.js_d_icon_no_data);
        ((TextView)(findViewById(R.id.xc_id_data_zero_hint_textview))).setText("您还没有添加快捷回复");

    }


    /**
     * @author shuYanYi on 2016/9/8.
     * @description 快捷回复适配器
     */
    class YY_QuickReplyAdapter extends YY_BaseSwipeAdapter {
        /** 是否编辑状态*/
        public boolean isEdit = false;
        /** 文字容器高度*/
        public int tHeight = 0;
        /**
         * 滑动控件持有类
         */
        class ActionViewHolder{
            /** 删除按钮*/
            TextView tv_delete;
        }
        /**
         * 内容持有类
         */
        class ContentViewHolder{
            /** 文本*/
            TextView tv_content;
            /** 编辑状态时的左侧删除图标*/
            ImageView iv_delete;
            /** 编辑右箭头*/
            ImageView iv_arrow;
            /** 文字父容器*/
            RelativeLayout rl_container;
        }

        /**
         * 构造方法
         * @param context               上下文
         * @param contentViewResourceId 默认显示区域的布局ID
         * @param actionViewResourceId  侧滑显示区域的布局ID
         * @param list               适配器的数据
         */
        public YY_QuickReplyAdapter(Activity context, int contentViewResourceId, int actionViewResourceId, List<XCJsonBean> list){
            super(context,contentViewResourceId,actionViewResourceId,list);
            this.list = list;
            tHeight = UtilScreen.dip2px(context,40f);
        }

        @Override
        public void setContentView(View contentView, int position, HorizontalScrollView parent, final SwipeViewHolder holder,final SwipeOnTouchListener swipeOnTouchListener) {
            //设置内容显示区域的View
            final ContentViewHolder contentViewHolder;
            if(null == contentView.getTag()) {
                contentViewHolder = new ContentViewHolder();
                contentViewHolder.tv_content = (TextView) contentView.findViewById(R.id.tv_content);
                contentViewHolder.iv_delete = (ImageView) contentView.findViewById(R.id.iv_delete);
                contentViewHolder.iv_arrow = (ImageView) contentView.findViewById(R.id.iv_arrow);
                contentViewHolder.rl_container = (RelativeLayout) contentView.findViewById(R.id.rl_container);
                contentView.setTag(contentViewHolder);
            }else {
                contentViewHolder = (ContentViewHolder) contentView.getTag();
            }
            XCJsonBean bean = (XCJsonBean)getItem(position);
            final String content = bean.getString("content");
            final String id = bean.getString("id");
            contentViewHolder.tv_content.setText(content);

            if(isEdit){
                contentViewHolder.iv_delete.setVisibility(View.VISIBLE);
                contentViewHolder.iv_arrow.setVisibility(View.VISIBLE);
            }else{
                contentViewHolder.iv_delete.setVisibility(View.GONE);
                contentViewHolder.iv_arrow.setVisibility(View.GONE);
            }
            //文字区点击
            contentViewHolder.tv_content.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    Intent it = new Intent();
                    if(isEdit){
                        //编辑状态点击，进入编辑文字页面
                        it.putExtra(KEY_EDIT_CONTENT, content);
                        it.putExtra(KEY_EDIT_ID, id);
                        it.setClass(YY_QuickReplyActivityV2.this,SK_AddQuickReplyActivity.class);
                        myStartActivity(it);
                    }else{
                        //非编辑状态点击，传送文字到聊天窗
                        it.putExtra(CommonConfig.QUICK_REPLY_KEY, content);
                        ((DBActivity)context).setResult(Activity.RESULT_OK, it);
                        ((DBActivity)context).myFinish();
                    }
                }
            });

            //编辑状态 左侧删除图标点击：滑出右侧删除按钮（设计的要求）
            contentViewHolder.iv_delete.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    swipeOnTouchListener.setCurrentActiveHSV(holder);
                }
            });
        }

        @Override
        public void setActionView(View actionView, int position, HorizontalScrollView parent) {
            //设置滑动控件的View
            ActionViewHolder actionViewHolder;
            if(null == actionView.getTag()) {
                actionViewHolder = new ActionViewHolder();
                actionViewHolder.tv_delete = (TextView) actionView.findViewById(R.id.tv_delete);
                actionView.setTag(actionViewHolder);
            }else {
                actionViewHolder = (ActionViewHolder) actionView.getTag();
            }
            XCJsonBean bean = (XCJsonBean)getItem(position);
            final String id = bean.getString("id");
            //删除按钮
            actionViewHolder.tv_delete.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    requestQuickReplyDelete(id);
                }
            });
        }



    }


}
