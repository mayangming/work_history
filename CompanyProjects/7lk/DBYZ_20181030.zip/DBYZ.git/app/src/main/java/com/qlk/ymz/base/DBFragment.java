package com.qlk.ymz.base;

import com.xiaocoder.android.fw.general.base.XCBaseFragment;

/**
 * Created by jingyu
 *
 * @description 基类
 */
public abstract class DBFragment extends XCBaseFragment {



}
