package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.DrugBean;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;

import java.util.List;

/**
 * @author 赖善琦
 * @version 2.2.0
 * @description 聊天页的推荐药品列表适配器--自主购药的布局
 */
public class SK_ChatLeftMedichineAdapter extends XCBaseAdapter<DrugBean> {

    /**
     * 构造方法
     *
     * @param context 上下文
     * @param list    数据
     */
    public SK_ChatLeftMedichineAdapter(Context context, List<DrugBean> list) {
        super(context, list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        DrugBean bean = list.get(position);
        SK_ChatMedichineAdapter_Holder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.sk_adapter_chat_left_medichine, null);
            holder = new SK_ChatMedichineAdapter_Holder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (SK_ChatMedichineAdapter_Holder) convertView.getTag();
        }

        holder.sk_id_tv_chat_medichine_name.setText(bean.getName());
        holder.sk_id_tv_chat_medichine_quantity.setText(bean.getMedicineUsageBean().getQuantity());
        holder.sk_id_tv_chat_medichine_spec.setText(!"".equals(bean.getSpec()) ? bean.getSpec() : "无");
        // holder.sk_id_tv_chat_medichine_usage.setText(!"".equals(bean.getImUsage()) ? bean.getImUsage() : "无");
        // holder.sk_id_tv_chat_medichine_bakup.setText(!"".equals(bean.getBakup()) ? bean.getBakup() : "无");

        return convertView;
    }

    class SK_ChatMedichineAdapter_Holder {
        /**
         * 商品名
         */
        TextView sk_id_tv_chat_medichine_name;
        /**
         * 通用名
         */
        TextView sk_id_tv_chat_medichine_commonname;
        /**
         * 购买数量
         */
        TextView sk_id_tv_chat_medichine_quantity;
        /**
         * 规格
         */
        TextView sk_id_tv_chat_medichine_spec;
        /**
         * 用法用量
         */
        TextView sk_id_tv_chat_medichine_usage;
        /**
         * 备注
         */
        TextView sk_id_tv_chat_medichine_bakup;

        public SK_ChatMedichineAdapter_Holder(View convertView) {

            sk_id_tv_chat_medichine_name = (TextView) convertView.findViewById(R.id.sk_id_tv_chat_medichine_name);
            //sk_id_tv_chat_medichine_commonname = (TextView)convertView.findViewById(R.id.sk_id_tv_chat_medichine_commonname);
            sk_id_tv_chat_medichine_quantity = (TextView) convertView.findViewById(R.id.sk_id_tv_chat_medichine_quantity);
            sk_id_tv_chat_medichine_spec = (TextView) convertView.findViewById(R.id.sk_id_tv_chat_medichine_spec);
            sk_id_tv_chat_medichine_usage = (TextView) convertView.findViewById(R.id.sk_id_tv_chat_medichine_usage);
            sk_id_tv_chat_medichine_bakup = (TextView) convertView.findViewById(R.id.sk_id_tv_chat_medichine_bakup);

        }
    }
}
