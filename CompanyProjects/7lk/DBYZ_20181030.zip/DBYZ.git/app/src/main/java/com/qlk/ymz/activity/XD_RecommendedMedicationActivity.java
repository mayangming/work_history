package com.qlk.ymz.activity;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.fragment.XD_CommonMedicineFragment;
import com.qlk.ymz.fragment.XD_CommonRecipeFragment;
import com.qlk.ymz.fragment.XD_ContinueRecipeFragment;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

/**
 * Created by xiedong on 2017/12/11.
 * 推荐用药首页
 */

public class XD_RecommendedMedicationActivity extends DBActivity {
    /**
     * 返回
     */
    private LinearLayout ll_titlebar_left;
    /**
     * 搜索
     */
    private RelativeLayout rl_search;
    /**
     * 续方tab
     */
    private RelativeLayout rl_continue_recipe;
    /**
     * 常用药tab
     */
    private RelativeLayout rl_common_medicine;
    /**
     * 常用处方tab
     */
    private RelativeLayout rl_common_recipe;
    /**
     * 续方
     */
    private TextView tv_continue_recipe;
    /**
     * 常用药
     */
    private TextView tv_common_medicine;
    /**
     * 常用处方
     */
    private TextView tv_common_recipe;
    /**
     * 续方指示
     */
    private View v_continue_indicate;
    /**
     * 常用药指示
     */
    private View v_common_medicine_indicate;
    /**
     * 常用处方指示
     */
    private View v_common_recipe_indicate;
    /**
     * 全科用药
     */
    private RelativeLayout rl_general_medicine;
    /**
     * 药箱
     */
    private RelativeLayout rl_recipe_cart;
    /**
     * 药数量的布局
     */
    private LinearLayout ll_medicine_num;
    /**
     * 药数量
     */
    private TextView tv_medicine_num;
    /**
     * 正在展示的fragment标识
     */
    private int mCurrentPageNum = 1;// 1 XD_ContinueRecipeFragment 2 3

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_recommended_medication);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_RecommendedMedicationActivity.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */

    @Override
    protected void onRestart() {
        super.onRestart();
        setMedicineNum();//设置药品数量
        XD_CommonMedicineFragment commonMedicineFragment = getFragmentByTag(XD_CommonMedicineFragment.class
                .getSimpleName());
        if (commonMedicineFragment != null) {
            commonMedicineFragment.updateUI();  //刷新常用药列表
        }
        if (RecomMedicineHelper.getInstance().isUpdateCommonRecipe()) {//需要刷新常用处方列表
            XD_CommonRecipeFragment fragment = getFragmentByTag(XD_CommonRecipeFragment.class.getSimpleName());
            if (fragment != null) {
                fragment.refresData();  //刷新常用处方列表
            }
        }
    }

    private void initData() {
        //显示药品数量
        setMedicineNum();

        //默认显示常用药tab
        showFragmentByClass(XD_CommonMedicineFragment.class, R.id.xc_id_model_content);
        switchTabUI(2);
        mCurrentPageNum = 2;
        if(!UtilSP.isRecomSafe()) {
            requestRemind();//不是灰度医生才请求
        }
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        ll_titlebar_left = getViewById(R.id.ll_titlebar_left);
        rl_search = getViewById(R.id.rl_search);
        rl_continue_recipe = getViewById(R.id.rl_continue_recipe);
        rl_common_medicine = getViewById(R.id.rl_common_medicine);
        rl_common_recipe = getViewById(R.id.rl_common_recipe);
        rl_general_medicine = getViewById(R.id.rl_general_medicine);
        tv_continue_recipe = getViewById(R.id.tv_continue_recipe);
        tv_common_medicine = getViewById(R.id.tv_common_medicine);
        tv_common_recipe = getViewById(R.id.tv_common_recipe);
        v_common_medicine_indicate = getViewById(R.id.v_common_medicine_indicate);
        v_common_recipe_indicate = getViewById(R.id.v_common_recipe_indicate);
        v_continue_indicate = getViewById(R.id.v_continue_indicate);
        rl_recipe_cart = getViewById(R.id.rl_recipe_cart);
        ll_medicine_num = getViewById(R.id.ll_medicine_num);
        tv_medicine_num = getViewById(R.id.tv_medicine_num);
    }

    @Override
    public void listeners() {
        ll_titlebar_left.setOnClickListener(this);
        rl_search.setOnClickListener(this);
        rl_continue_recipe.setOnClickListener(this);
        rl_common_medicine.setOnClickListener(this);
        rl_common_recipe.setOnClickListener(this);
        rl_general_medicine.setOnClickListener(this);
        rl_recipe_cart.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_titlebar_left:
                myFinish();
                break;
            case R.id.rl_search:
                // 搜索
                ToJumpHelp.toJumpMedicineSearchActivity(this, CommonConfig.ALL_MEDICINE_FLAG_2, "");
                break;
            case R.id.rl_continue_recipe:
                if (mCurrentPageNum != 1) {
                    switchTab(XD_ContinueRecipeFragment.class, 1);
                }
                // created by songxin,date：2018-01-09,about：saveInfo,begin
                BiUtil.saveBiInfo(XD_RecommendedMedicationActivity.class, "2", "128", "E00092","", false);
                // created by songxin,date：2018-01-09,about：saveInfo,end
                break;
            case R.id.rl_common_medicine:
                if (mCurrentPageNum != 2) {
                    switchTab(XD_CommonMedicineFragment.class, 2);
                }
                // created by songxin,date：2018-01-09,about：saveInfo,begin
                BiUtil.saveBiInfo(XD_RecommendedMedicationActivity.class, "2", "128", "E00090","", false);
                // created by songxin,date：2018-01-09,about：saveInfo,end
                break;
            case R.id.rl_common_recipe:
                if (mCurrentPageNum != 3) {
                    switchTab(XD_CommonRecipeFragment.class, 3);
                }
                // created by songxin,date：2018-01-09,about：saveInfo,begin
                BiUtil.saveBiInfo(XD_RecommendedMedicationActivity.class, "2", "128", "E00091","", false);
                // created by songxin,date：2018-01-09,about：saveInfo,end
                break;
            case R.id.rl_general_medicine:
                //  全科药品
                ToJumpHelp.toJumpAllMedicineClassActivity(this, CommonConfig.ALL_MEDICINE_FLAG_2);
                break;
            case R.id.rl_recipe_cart:
                if (checkMedicneNum()) {
                    SQ_RecommendActivity.launch(this);
                } else {
                    shortToast("请选择药品");
                }
                break;
        }
        super.onClick(v);
    }

    /**
     * 检查药箱是否有药或者诊断
     *
     * @return
     */
    private boolean checkMedicneNum() {
        if (RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size() > 0
                || RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getDiagnoseBeanList()
                .size() > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 用药安全提示
     */
    public void requestRemind() {
        RequestParams params = new RequestParams();
        try {
            // 患者性别：0.女 1.男
            String gender;
            String age;
            if (RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getRecommendInfo() == null) {
                age = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getChatModel().getUserPatient()
                        .getPatientAge();
                gender = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getChatModel().getUserPatient().getPatientGender();
            } else {
                age = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getRecommendInfo().getPatientAge();
                gender = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getRecommendInfo().getPatientGender() + "";
            }

            params.put("patientId", RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getChatModel().getUserPatient().getPatientId());
            params.put("age", age);
            params.put("gender", Integer.parseInt(gender));
        } catch (Exception e) {
            e.printStackTrace();
        }

        XCHttpAsyn.postAsyn(false, this, AppConfig.getTuijianUrl(AppConfig.recomRemind), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    try {
                        //content (string,): 提醒内容 ,
                        //remind (integer): 是否提示：0.不提示 1.提示
                        if ("1".equals(result_bean.getList("data").get(0).getString("remind"))) {
                            XCApplication.base_log.shortToast(result_bean.getList("data").get(0).getString("content"));
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    /**
     * 切换tab
     *
     * @param mClass
     * @param switchPageNum
     */
    private void switchTab(Class mClass, int switchPageNum) {
        Fragment mCurrentFragment = null;
        switch (mCurrentPageNum) {
            case 1:
                mCurrentFragment = getFragmentByTag(XD_ContinueRecipeFragment.class.getSimpleName());
                break;
            case 2:
                mCurrentFragment = getFragmentByTag(XD_CommonMedicineFragment.class.getSimpleName());
                break;
            case 3:
                mCurrentFragment = getFragmentByTag(XD_CommonRecipeFragment.class.getSimpleName());
                break;
        }
        hideFragment(mCurrentFragment);//隐藏当前显示fragment
        showFragmentByClass(mClass, R.id.xc_id_model_content);//显示要展示fragment
        switchTabUI(switchPageNum);
        mCurrentPageNum = switchPageNum;
    }

    /**
     * 切换tab的ui
     *
     * @param switchPageNum
     */
    private void switchTabUI(int switchPageNum) {
        if (mCurrentPageNum == 1) {
            tv_continue_recipe.setTextColor(getResources().getColor(R.color.c_7b7b7b));
            v_continue_indicate.setVisibility(View.GONE);
        } else if (mCurrentPageNum == 2) {
            tv_common_medicine.setTextColor(getResources().getColor(R.color.c_7b7b7b));
            v_common_medicine_indicate.setVisibility(View.GONE);
        } else if (mCurrentPageNum == 3) {
            tv_common_recipe.setTextColor(getResources().getColor(R.color.c_7b7b7b));
            v_common_recipe_indicate.setVisibility(View.GONE);
        }
        switch (switchPageNum) {
            case 1:
                tv_continue_recipe.setTextColor(getResources().getColor(R.color.c_f84b62));
                v_continue_indicate.setVisibility(View.VISIBLE);
                break;
            case 2:
                tv_common_medicine.setTextColor(getResources().getColor(R.color.c_f84b62));
                v_common_medicine_indicate.setVisibility(View.VISIBLE);
                break;
            case 3:
                tv_common_recipe.setTextColor(getResources().getColor(R.color.c_f84b62));
                v_common_recipe_indicate.setVisibility(View.VISIBLE);
                break;
        }
    }

    /**
     * 设置药箱药品数量
     *
     */
    public void setMedicineNum() {
        int num = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size();
        if (num == 0) {
            ll_medicine_num.setVisibility(View.GONE);
        } else if (num < 100) {
            ll_medicine_num.setVisibility(View.VISIBLE);
            ll_medicine_num.setBackgroundResource(R.mipmap.xd_red_round);
        } else if (num >= 100) {
            ll_medicine_num.setVisibility(View.VISIBLE);
            ll_medicine_num.setBackgroundResource(R.drawable.xd_red_round);
        }
        tv_medicine_num.setText("" + num);
    }

    /**
     * 数字动画
     */
    private void startNumAnimation() {
        ObjectAnimator rotation = ObjectAnimator.ofFloat(ll_medicine_num, "rotation", -180f,
                0f);
        rotation.setDuration(300);
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(ll_medicine_num, "scaleX", 0.8f, 1f);
        scaleX.setDuration(300);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(ll_medicine_num, "scaleY", 0.8f, 1f);
        scaleY.setDuration(300);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(rotation, scaleX, scaleY);
        animatorSet.setStartDelay(500);
        animatorSet.start();
    }

    /**
     * 获取 XC_PatientDrugInfo
     * @return XC_PatientDrugInfo
     */
    public XC_PatientDrugInfo getPatientDrugInfo() {
        return RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        if (requestCode == UsageActivityV2.REQUEST_CODE_USAGE) {
            //用法用量回来逻辑
            DrugBean drugBean = (DrugBean) data.getSerializableExtra(UsageActivityV2.DRUG_INFO);
            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().add(drugBean);
            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().checkDrugMap.put(drugBean
                    .getId(), true);
            //设置药品数量
            setMedicineNum();
            //开始数量动画
            startNumAnimation();
        }
    }

}
