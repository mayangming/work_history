package com.qlk.ymz.db.im.chatmodel;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;

/**
 * Created by jingyu on 2015/6/22.
 * @version 1.0
 * @description 聊天存储到数据库的model
 * update: 2017/7/5
 * @description 抽离用户信息成单独的model
 */
public class XC_ChatModel implements Serializable, Cloneable {
    /**
     * 本地模拟的系统消息
     */
    public static final int SYSTEM = -1;
    /**
     * 医生
     */
    public static final int DOCTOR = 0;
    /**
     * 患者
     */
    public static final int PATIENT = 1;

    // add by xjs on 20160428 start
    // 2.3.0版本更改了“通知类消息”的类型值定义，下面是最新的值定义
    /**
     * 信息发送者类型：公告通知
     */
    public static final int MSG_SENDER_TYPE_PUB_NOTICE = 2;
    /**
     * 信息发送者类型：系统通知
     */
    public static final int MSG_SENDER_TYPE_ACCOUNT_STATE = 3;
    /**
     * 信息发送者类型：系统确认购药咨询通知
     */
    public static final int MSG_SENDER_TYPE_SYSTEM_AFFIRM_BUY_RX = 5;
    // add by xjs on 20160428 end
    // add by tengfei on 20160428 start
    /**
     * 信息发送者类型：七乐康客服
     */
    public static final int MSG_SENDER_TYPE_SERVICE = 6;
    /**
     * 信息发送者类型：和客服聊天的医生
     */
    public static final int MSG_SENDER_TYPE_SERVICE_MY = 7;

    /** 药品时限 */
    public static final int MSG_MEDICINE_TIME_LIMIT = 8;

    // add by tengfei on 20160428 end
    public static final String SEND_FAIL = "0";
    public static final String SEND_SUCCESS = "1";
    public static final String SEND_ING = "2";
    // add by xjs on 20151017 02:12 start
    public static final String SEND_NOT = "3";
    // add by xjs on 20151017 02:12 end

    /**
     * 已读消息
     */
    public static final String READED = "1";
    /**
     * 未读消息
     */
    public static final String UN_READED = "0";

    public static final int TEXT = 1;
    public static final int PHOTO = 2;
    public static final int VOICE = 4;
    public static final int MOVIE = 8;
    /**  推荐用药药方消息 */
    public static final int RECOMMAND_MEDICINE = 16;
    /** 用药助手， 即转到搜索界面的关键字 */
    public static final int ASSISTANT_MEDICINE = 32;
    /** 患者自主购药 */
    public static final int PATIENT_BUY = 64;
    /** 视频通话的诊疗记录 */
    public static final int MEDIC_RECORD = 256;
    /** 疗效随访 */
    public static final int VISIT = 512;

    /** 成功开启付费咨询消息 */
    public static final int PAID = 1024;

    /** 宣教(宣传教育) */
    public static final int PUBLICITY_EDUCATION = 2048;
    /** 个性化服务收费 */
    public static final int INDIVIDUATION_COST = 4096;
    /** 量表(旧类型，为做旧版本兼容，旧的类型依然保持) */
    public static final int SCALE = 8192;
    /** 健康体检 */
    public static final int CHECK_HEALTH = 10001;

    /** 患者填写的病历 */
    public static final int MEDICINE_RECORD = 10002;

    /** 患者最近一份病历(聊天框加载) */
    public static final int MEDICINE_RECORD_LAST = 10003;

    /** 医生端提醒患者填写病历消息 */
    public static final int MEDICINE_RECORD_REMIND = 10004;

    /** 病历详情 */
    public static final int MEDICAL_RECORD = 10005;

    /**量表回执(新类型) */
    public static final int SCALE_NEW = 10006;

    /**显示检查报告 */
    public static final int CHECK_REPORT = 10007;

    /**
     * 自主购药接收时的本地提示(SYSTEM)
     */
    public static final String TYPE_PATIENT_BUY_COME_HINT = "-1000";
    /**
     * 自主购药超时的本地提示(SYSTEM)
     */
    public static final String TYPE_PATIENT_BUY_END_HINT = "-1001";
    /**
     * 会话结束的本地提示(SYSTEM)
     */
    public static final String TYPE_SESSION_END_HINT = "-1002";

    protected String _id = "";
    protected ChatSession chatSession = new ChatSession();
    protected UserPatient userPatient = new UserPatient();
    private UserDoctor userDoctor = new UserDoctor();
    private ChatModelPhoto chatModelPhoto = new ChatModelPhoto();
    private String msgTime = ""; //发送时间
    private String messageTextRecommand = "";//用药助手
    private String messageText = "";//文本信息
    private String msgType = "";//消息类型有 图片 视频 音频 文本 文本+医药链接 文本+推荐用药
    private String msgUnique = ""; //每条信息的唯一标示  user_id + time
    private String voiceLocalUri = "";//声音的本地缓存
    private String voiceHttpUri = "";//声音的网络地址
    private String moveLocalUri = "";//视频的本地缓存
    private String moveHttpUri = "";//视频的网络地址
    private String mediaDuration = "";
    private String mediaSize = "";
    private String sender = "";// 0医生，1患者，2 公共通知(云诊公告)，3私人通知（云诊公告），4个人动态（账户动态）
    private String unReadMessageNum = "";//未读消息数量
    private String isSendSuccess = ""; //是否发送成功   0失败 1 成功 2正在发送

    private String msgServerId = ""; //服务端信息ID

    /** 声音的读取标志*/
    private String isRead = "";
    // 目标对象类型（1：患者；2：手机联系人。默认1）
    protected String type = "1";
    /**
     * 聊天会话ID
     */
    private String sessionId = "";
    /**
     * 会话生命周期状态（0：进行中；1：已结束）
     */
    private String sessionLifeCycle = "";
    /**
     * 会话的付费模式（0：免费；1：付费）
     * 用于图文咨询付费状态的判断（2017-3-31）
     */
    private String payMode = "";
    /**
     * 会话的付费状态（0：未付费；1：已付费）
     */
    private String payResult = "";
    /**
     * 会话开始时间（毫秒值）
     */
    private String sessionBeginTime = "";
//    /** 状态：payStatus -1:咨询中,0:未支付,1:已支付 */
//    protected String payStatus = "";
    /**
     * 会话结束时间（毫秒值）
     */
    private String sessionEndTime = "";

    /**
     * 系统类消息，chat的mqtt接收
     */
    private String LinkUrl = "";
    /**
     * 原始推送时间（购药咨询的推送中返回的，也返回了一个sendTime字段）
     */
    private String originSendTime = "";
    /**
     * 购药咨询id
     */
    protected String requireId = "";

    /**
     * 用药建议有效期 毫秒值
     */
    private String expiration = "";
    //add by cyr on 2017-2-15 end

    /**
     * 编号
     */
    protected String serialNumber = "";

    /** 临床诊断 之前的版本是需要由聊天页面传值给推荐用药详情页，现在改由网络获取，故废弃，需择时删除*/
    protected String diagnosis = "";

    // add by xjs on 20160428 start
    /**
     * 公告二级分类id
     */
    protected String topic = "";

    /**
     * 有以下作用：
     * 1、发送的信息如果是推荐用药，则会返回该值，用于重复推荐时使用
     * 2、发送的推荐健康检查的ID;
     */
    protected String recommandId = "";

    /**
     * 当前聊天对象上条消息来源
     * 0：患者App
     * 1：医生App
     * 2：患者微信
     * 3：互联网医院（PC）
     * 未知，传空
     */
    private String lastPlatform = "";
    /**
     * 新增推荐用药审核状态
     * 0：默认（不需要审核）
     * 1：审核中
     * 2：审核通过
     * 3：审核不通过
     */
    private String recommandStatus = "";

    /**
     * 处方合规化推荐用药审核备注（可为空）
     */
    private String auditDesc = "";

    /** v2.6.5 增加随访 */
    private String visitId = "";
    private String visitType = "";
    private String viewMessage = "";

    //v2.7 增加以下字段 ------start
    private String content = ""; //用于存储IM中的content字段
    private String messageId = "";//消息Id 2.7之后所有收到的消息都会有这个字段，调用发消息接口后也会有这个字段返回

    private ChatModelEdu chatModelEdu = new ChatModelEdu();
    private ChatModelCustomAdvisory chatModelCustomAdvisory = new ChatModelCustomAdvisory();
    private ChatModelScale chatModelScale = new ChatModelScale();
    private ChatModelPaid chatModelPaid = new ChatModelPaid();
    private ChatModelMedicineRecord chatModelMedicineRecord = new ChatModelMedicineRecord();
    private ChatModelMedicalRecord chatModelMedicalRecord = new ChatModelMedicalRecord();
    private ChatModelScaleNew chatModelScaleNew = new ChatModelScaleNew();

    //聊天页面用于提示是否收费的提示，该字段用于判断是否关闭，存储在JS_ChatListDB里面
    private String titleTipCloseTime = "";
    /* 2.8添加撤销功能标志 */
    private String cancelFlag = "0";//（0:表示未撤销；1:表示已撤销）
    public static final String CANCEL_TIP = "您撤回了一条消息";//撤销提示语
    /** 是否为强制推荐 true：是 false：不是 */
    private boolean force = false;

    /* 2.15添加 启事消息 功能 */
    private AdditionalNoticeModel additionalNoticeModel = new AdditionalNoticeModel();

    /* 复购提示 */
    private ReBuyNotic reBuyNotic = new ReBuyNotic();
    /* 是否显示到期提示,复购为true */
    private boolean isShowExpire = false;

    /* 2.17 添加 IM消息中的拓展字段 exd
     * json 示例:
     {
       "sendTime":1302238374929,
       "content":{
           ....
       },
       "exd":{//拓展字段
           "batchId":“1232ddw32f2fff”,//群发ID
           },
         ...
       }
     * */
    private String exd = ""; //用于存储IM中的exd字段
    private String summary = ""; //推荐活动付费咨询(该字段从exd中解析获取)
    private String sessionJson = ""; //IM中session节点的json
    //3.4版本作废标记
    private String invalid = "0";//0 没有作废(默认值)、1 处方作废、2 病历作废、3 处方和病历作废
    public XC_ChatModel(){
    }
    public String getVisitId() {
        if (visitId == null) {
            visitId = "";
        }
        return visitId;
    }

    public void setVisitId(String visitId) {
        this.visitId = visitId;
    }

    public String getVisitType() {
        if (visitType == null) {
            visitType = "";
        }
        return visitType;
    }

    public void setVisitType(String visitType) {
        this.visitType = visitType;
    }

    public String getViewMessage() {
        if (viewMessage == null) {
            viewMessage = "";
        }
        return viewMessage;
    }

    public void setViewMessage(String viewMessage) {
        this.viewMessage = viewMessage;
    }

    public String getTopic() {
        return this.topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getAuditDesc() {
        if (auditDesc == null) {
            auditDesc = "";
        }
        return auditDesc;
    }

    public void setAuditDesc(String auditDesc) {
        this.auditDesc = auditDesc;
    }

    public String getRecommandStatus() {
        return recommandStatus;
    }

    public void setRecommandStatus(String recommandStatus) {
        this.recommandStatus = recommandStatus;
    }

    public boolean isForce() {
        return force;
    }

    public void setForce(boolean force) {
        this.force = force;
    }

    public boolean isMedicineChecking() {
        return "1".equals(recommandStatus);
    }

    public boolean isMedicineCheckSuccess() {
        return "2".equals(recommandStatus);
    }

    public boolean isMedicineCheckFail() {
        return "3".equals(recommandStatus);
    }

    public boolean isMedicineStatusDefault() {
        return "0".equals(recommandStatus);
    }

    public String getLastPlatform() {
        if (lastPlatform == null) {
            lastPlatform = "";
        }
        return lastPlatform;
    }

    public void setLastPlatform(String lastPlatform) {
        this.lastPlatform = lastPlatform;
    }

    public String getRecommandId() {
        if (recommandId == null) {
            recommandId = "";
        }
        return recommandId;
    }

    public void setRecommandId(String recommandId) {
        this.recommandId = recommandId;
    }

    public String getOriginSendTime() {
        if (originSendTime == null) {
            originSendTime = "";
        }
        return originSendTime;
    }

    public void setOriginSendTime(String originSendTime) {
        this.originSendTime = originSendTime;
    }

    public String getRequireId() {
        if (requireId == null) {
            requireId = "";
        }
        return requireId;
    }

    public void setRequireId(String requireId) {
        this.requireId = requireId;
    }

    public String getSerialNumber() {
        if (serialNumber == null) {
            serialNumber = "";
        }
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getDiagnosis() {
        if (diagnosis == null) {
            diagnosis = "";
        }
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    /**
     * 会话进行中
     */
    public static final String SESSION_ING = "0";
    /**
     * 会话结束
     */
    public static final String SESSION_END = "1";

    public String getExpiration() {
        if (expiration == null) {
            expiration = "";
        }
        return expiration;
    }

    public void setExpiration(String expiration) {
        this.expiration = expiration;
    }

    public String getLinkUrl() {
        if (LinkUrl == null) {
            LinkUrl = "";
        }
        return LinkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        LinkUrl = linkUrl;
    }

    public String getSessionLifeCycle() {
        if (sessionLifeCycle == null) {
            sessionLifeCycle = "";
        }
        return sessionLifeCycle;
    }

    public void setSessionLifeCycle(String sessionLifeCycle) {
        this.sessionLifeCycle = sessionLifeCycle;
    }

    public String getPayMode() {
        if (payMode == null) {
            payMode = "";
        }
        return payMode;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    public String getPayResult() {
        if (payResult == null) {
            payResult = "";
        }
        return payResult;
    }

    public void setPayResult(String payResult) {
        this.payResult = payResult;
    }

    public String getSessionBeginTime() {
        if (sessionBeginTime == null) {
            sessionBeginTime = "";
        }
        return sessionBeginTime;
    }

    public void setSessionBeginTime(String sessionBeginTime) {
        this.sessionBeginTime = sessionBeginTime;
    }

    public String getIsSendSuccess() {
        if (isSendSuccess == null) {
            isSendSuccess = "";
        }
        return isSendSuccess;
    }

    public void setIsSendSuccess(String isSendSuccess) {
        this.isSendSuccess = isSendSuccess;
    }

    public String getMediaSize() {
        if (mediaSize == null) {
            mediaSize = "";
        }
        return mediaSize;
    }

    public void setMediaSize(String mediaSize) {
        this.mediaSize = mediaSize;
    }

    public String getMediaDuration() {
        if (mediaDuration == null) {
            mediaDuration = "";
        }
        return mediaDuration;
    }

    public void setMediaDuration(String mediaDuration) {
        this.mediaDuration = mediaDuration;
    }

    public String getUnReadMessageNum() {
        try {
            Integer.valueOf(unReadMessageNum);
        } catch (Exception e) {
            unReadMessageNum = "0";
        }
        return unReadMessageNum;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getSessionId() {
        if (null == sessionId || sessionId.trim().length() == 0) {
            sessionId = "";
        }
        return sessionId;
    }

    /**
     * 获得未读消息数。<p>
     * 当defaultValue值无效时（例：“”，“null”，null时），将defaultValue的值设置为"0"<p>
     * 当未读消息数的值无效时（例：“”，“0”，“null”，null时），将未读消息数的值设置为defaultValue<p>
     * 注意：此方法与getUnReadMessageNum(String defaultValue)方法不同之处在于，对“未读消息数的值”是“0”无效值时，进行了默认值的赋值处理。
     *
     * @param defaultValue 默认值
     * @return 未读消息数。当未读消息数的值无效时（例：“”，“null”，null时），将未读消息数的值设置为defaultValue进行返回。
     */
    public String getUnReadMessageNumWhenZero(String defaultValue) {
        try {
            Integer.valueOf(defaultValue);
        } catch (Exception e) {
            defaultValue = "0";
        }
        if ("0".equals(unReadMessageNum)){
            unReadMessageNum = defaultValue;
        }else {
            try {
                Integer.valueOf(unReadMessageNum);
            } catch (Exception e) {
                unReadMessageNum = defaultValue;
            }
        }

        return unReadMessageNum;
    }

    public void setUnReadMessageNum(String unReadMessageNum) {
        this.unReadMessageNum = unReadMessageNum;
    }

    public String getSender() {
        return UtilString.f(sender);
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getMsgTime() {
        return UtilString.f(msgTime);
    }

    public String getType() {
        if (UtilString.isBlank(type)) {
            type = "1";
        }
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setMsgTime(String msgTime) {
        this.msgTime = msgTime;
    }

    public String getMessageTextRecommand() {
        return UtilString.f(messageTextRecommand);
    }

    public void setMessageTextRecommand(String messageTextRecommand) {
        this.messageTextRecommand = messageTextRecommand;
    }

    public String getMessageText() {
        return UtilString.f(messageText);
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public String getMsgType() {
        return UtilString.f(msgType);
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getMsgUnique() {
        return UtilString.f(msgUnique);
    }

    /**
     * UtilSP.getLocalChatMsgUnique(...)
     */
    public void setMsgUnique(String msgUnique) {
        this.msgUnique = msgUnique;
    }

    public String get_id() {
        return UtilString.f(_id);
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    @Override
    public String toString() {
        return "XC_ChatModel{" +
                ", msgTime='" + msgTime + '\'' +
                ", messageTextRecommand='" + messageTextRecommand + '\'' +
                ", messageText='" + messageText + '\'' +
                ", msgType='" + msgType + '\'' +
                ", msgUnique='" + msgUnique + '\'' +
                ", voiceLocalUri='" + voiceLocalUri + '\'' +
                ", voiceHttpUri='" + voiceHttpUri + '\'' +
                ", moveLocalUri='" + moveLocalUri + '\'' +
                ", moveHttpUri='" + moveHttpUri + '\'' +
                ", sender='" + sender + '\'' +
                ", mediaDuration='" + mediaDuration + '\'' +
                ", mediaSize='" + mediaSize + '\'' +
                ", unReadMessageNum='" + unReadMessageNum + '\'' +
                ", isSendSuccess='" + isSendSuccess + '\'' +
                ", msgServerId='" + msgServerId + '\'' +
                ", isRead='" + isRead + '\'' +
                ", sessionId='" + sessionId + '\'' +
                ", sessionLifeCycle='" + sessionLifeCycle + '\'' +
                ", payMode='" + payMode + '\'' +
                ", payResult='" + payResult + '\'' +
                ", sessionBeginTime='" + sessionBeginTime + '\'' +
                ", sessionEndTime='" + sessionEndTime + '\'' +
                ", LinkUrl='" + LinkUrl + '\'' +
                ", originSendTime='" + originSendTime + '\'' +
                ", requireId='" + requireId + '\'' +
                ", expiration='" + expiration + '\'' +
                '}';
    }

    public String getVoiceLocalUri() {
        return UtilString.f(voiceLocalUri);
    }

    public void setVoiceLocalUri(String voiceLocalUri) {
        this.voiceLocalUri = voiceLocalUri;
    }

    public String getVoiceHttpUri() {
        return UtilString.f(voiceHttpUri);
    }

    public void setVoiceHttpUri(String voiceHttpUri) {
        this.voiceHttpUri = voiceHttpUri;
    }


    public String getMoveLocalUri() {
        return UtilString.f(moveLocalUri);


    }

    public void setMoveLocalUri(String moveLocalUri) {
        this.moveLocalUri = moveLocalUri;
    }

    public String getMoveHttpUri() {
        return UtilString.f(moveHttpUri);
    }

    public void setMoveHttpUri(String moveHttpUri) {
        this.moveHttpUri = moveHttpUri;
    }

    public String getMsgServerId() {
        return UtilString.f(msgServerId);
    }

    public void setMsgServerId(String msgServerId) {
        this.msgServerId = msgServerId;
    }

    public String getIsRead() {
        return UtilString.f(isRead);
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead;
    }

    public String getSessionEndTime() {
        if (sessionEndTime == null || "0".equals(sessionEndTime)) {
            sessionEndTime = "";
        }
        return sessionEndTime;
    }

    public void setSessionEndTime(String sessionEndTime) {
        this.sessionEndTime = sessionEndTime;
    }

    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getContent() {
        return UtilString.f(content);
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTitleTipCloseTime() {
        return UtilString.f(titleTipCloseTime);
    }

    public void setTitleTipCloseTime(String titleTipCloseTime) {
        this.titleTipCloseTime = titleTipCloseTime;
    }

    public String getMessageId() {
        return UtilString.f(messageId);
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public boolean isDoctorRecommandMedicineType() {
        // mqtt收到服务器代替医生发的、推荐用药审核的消息
        return String.valueOf(XC_ChatModel.DOCTOR).equals(getSender())
                && String.valueOf(XC_ChatModel.RECOMMAND_MEDICINE).equals(getMsgType());
    }
    public boolean isDoctorMedicineRecordType() {
        // mqtt收到服务器代替医生发的、病历处方审核的消息
        return String.valueOf(XC_ChatModel.DOCTOR).equals(getSender())
                && String.valueOf(XC_ChatModel.MEDICAL_RECORD).equals(getMsgType());
    }

    public boolean isSessionEndType() {
        return (XC_ChatModel.SYSTEM + "").equals(getSender()) &&
                XC_ChatModel.TYPE_SESSION_END_HINT.equals(getMsgType());
    }


    public String getCancelFlag() {
        return UtilString.isBlank(cancelFlag) ? "0" : cancelFlag;
    }

    public void setCancelFlag(String cancelFlag) {
        this.cancelFlag = cancelFlag;
    }

    public UserPatient getUserPatient() {
        return userPatient;
    }

    public void setUserPatient(UserPatient userPatient) {
        this.userPatient = userPatient;
    }

    public UserDoctor getUserDoctor() {
        return userDoctor;
    }


    public ChatModelPhoto getChatModelPhoto() {
        return chatModelPhoto;
    }

    public ChatModelEdu getChatModelEdu() {
        return chatModelEdu;
    }


    public ChatModelCustomAdvisory getChatModelCustomAdvisory() {
        return chatModelCustomAdvisory;
    }


    public ChatModelScale getChatModelScale() {
        return chatModelScale;
    }


    public ChatModelPaid getChatModelPaid() {
        return chatModelPaid;
    }


    public AdditionalNoticeModel getAdditionalNoticeModel() {
        return additionalNoticeModel;
    }

    public void setAdditionalNoticeModel(AdditionalNoticeModel additionalNoticeModel) {
        this.additionalNoticeModel = additionalNoticeModel;
    }

    public ReBuyNotic getReBuyNotic() {
        return reBuyNotic;
    }

    public void setReBuyNotic(ReBuyNotic reBuyNotic) {
        this.reBuyNotic = reBuyNotic;
    }

    public boolean isShowExpire() {
        return isShowExpire;
    }

    public void setShowExpire(boolean showExpire) {
        isShowExpire = showExpire;
    }

    public String getExd() {
        return exd;
    }

    public void setExd(String exd) {
        this.exd = exd;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public ChatModelMedicineRecord getChatModelMedicineRecord() {
        return chatModelMedicineRecord;
    }

    public ChatModelMedicalRecord getChatModelMedicalRecord() {
        return chatModelMedicalRecord;
    }

    public void setChatModelMedicalRecord(ChatModelMedicalRecord chatModelMedicalRecord) {
        this.chatModelMedicalRecord = chatModelMedicalRecord;
    }

    public ChatModelScaleNew getChatModelScaleNew() {
        return chatModelScaleNew;
    }

    public String getSessionJson() {
        return UtilString.f(sessionJson);
    }

    public void setSessionJson(String sessionJson) {
        this.sessionJson = sessionJson;
    }

    public ChatSession getChatSession() {
        return chatSession;
    }

    //假如为空时返回默认值0(不作废)
    public String getInvalid() {
        return UtilString.isBlank(invalid) ? "0" : invalid;
    }

    public void setInvalid(String invalid) {
        this.invalid = invalid;
    }
}