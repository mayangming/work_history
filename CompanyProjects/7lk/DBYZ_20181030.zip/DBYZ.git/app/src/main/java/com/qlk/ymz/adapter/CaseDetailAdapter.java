package com.qlk.ymz.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;


/**
 * Created by xiedong on 2018/10/29.
 */

public class CaseDetailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private View headView;
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new HeadHolder(headView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 1;
    }

    public void addHeadView(View view){
        this.headView = view;
    }

    class HeadHolder extends RecyclerView.ViewHolder{
        public HeadHolder(View itemView) {
            super(itemView);
        }
    }
}
