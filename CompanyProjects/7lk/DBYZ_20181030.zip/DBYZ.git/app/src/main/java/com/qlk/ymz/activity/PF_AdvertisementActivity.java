package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.BannerInfoBean_V2;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonParse;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * 广告模层
 * @author zhangpengfei.
 * @version 1.0
 */
public class PF_AdvertisementActivity extends DBActivity {
    /**广告信息Key*/
    private static final String AD_INFO = "adInfo";
    /**显示图*/
    private ImageView pf_id_show_img;
    /**关闭*/
    private ImageView pf_id_close_btn;
    /**
     * 图片显示设置
     */
    private DisplayImageOptions options;
    /**广告信息*/
    private BannerInfoBean_V2 infoBean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_activity_advertisement);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_AdvertisementActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */
    /**
     * 启动页面
     * @param context 上下文对象
     * @param infoBean 广告信息
     */
    public static void launch(Context context, BannerInfoBean_V2 infoBean) {
        Intent intent = new Intent(context, PF_AdvertisementActivity.class);
        intent.putExtra(AD_INFO, infoBean);
        context.startActivity(intent);
        if (context instanceof Activity){
            ((Activity)context).overridePendingTransition(R.anim.pop_up, R.anim.pop_down);
        }
    }
    @Override
    public void initWidgets() {
        pf_id_show_img = getViewById(R.id.pf_id_show_img);
        pf_id_close_btn = getViewById(R.id.pf_id_close_btn);
        if (null != getIntent()){
            infoBean = (BannerInfoBean_V2) getIntent().getSerializableExtra(AD_INFO);
        }
        if (null == infoBean){
            infoBean = new BannerInfoBean_V2();
        }
        options = XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.sx_d_identity_personal_head_icon_v2);
        XCApplication.displayImage(infoBean.getImageUrl(), pf_id_show_img, options);
    }

    @Override
    public void listeners() {
        pf_id_show_img.setOnClickListener(this);
        pf_id_close_btn.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            //关闭
            case R.id.pf_id_close_btn:
                onBack();
                // 记录此用户已看过此图片
                saveLookedLayerImage();
                break;
            //大图, 如果没有跳转链接,就不进行操作
            case R.id.pf_id_show_img:
                if (!UtilString.isBlank(infoBean.getTargetUrl())) {
                    XCJsonBean result_bean = XCJsonParse.getJsonParseData(infoBean.getTargetUrl());
                    if (null == result_bean) {
                        return;
                    }
                    String keyName = UtilString.f(result_bean.getString("K"));
                    String valueName = UtilString.f(result_bean.getString("V"));
                    if (!UtilString.isBlank(valueName) && !UtilString.isBlank(keyName)) {
                        saveLookedLayerImage();

                        // created by songxin,date：2016-4-25,about：saveInfo,begin
                        BiUtil.saveBiInfo(PF_AdvertisementActivity.class, "2", "128", "pf_id_show_img","", false);
                        // created by songxin,date：2016-4-25,about：saveInfo,end
                        onBack();
                        //跳转操作
                        NativeHtml5.newInstance(PF_AdvertisementActivity.this).webToAppPage(UtilString.f(infoBean.getTargetUrl()), 0);
                    }
                }
                break;
        }
    }

    /**
     * 记录此用户已看过此图片
     */
    private void saveLookedLayerImage() {
        String doctorId = UtilSP.getUserId();
        String layerImageId = infoBean.getVersionCode();
        GlobalConfigSP.setLookedLayerCode(layerImageId);
    }

    @Override
    public void onBackPressed() {
    }

    /**
     * 关闭页面
     */
    private void onBack(){
        finish();
        overridePendingTransition(0, R.anim.pop_down);
    }
}
