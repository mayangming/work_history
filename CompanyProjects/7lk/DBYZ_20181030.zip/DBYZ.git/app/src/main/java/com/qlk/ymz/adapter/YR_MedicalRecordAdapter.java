package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import java.util.List;

/**
 * 用药记录list的适配器
 *
 * @author 崔毅然
 * @version 1.0
 */
public class YR_MedicalRecordAdapter  extends XCBaseAdapter<XCJsonBean> {

    public YR_MedicalRecordAdapter(Context context,List<XCJsonBean> list){
        super(context, list);
    }

    class ViewHolder{
        TextView tv_patient_name,tv_patient_time,tv_medical_name,tv_medical_num,tv_medical_intro,tv_buy_status;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        XCJsonBean bean = list.get(position);
        ViewHolder holder;
        if(view == null){
            holder = new ViewHolder();
            view = LayoutInflater.from(context).inflate(R.layout.yr_item_medicationrecord,null);
            holder.tv_patient_name = (TextView) view.findViewById(R.id.tv_patient_name);
            holder.tv_patient_time = (TextView) view.findViewById(R.id.tv_patient_time);
            holder.tv_medical_name = (TextView) view.findViewById(R.id.tv_medical_name);
            holder.tv_medical_num = (TextView) view.findViewById(R.id.tv_medical_num);
            holder.tv_medical_intro = (TextView) view.findViewById(R.id.tv_medical_intro);
            holder.tv_buy_status = (TextView) view.findViewById(R.id.tv_buy_status);

            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }

        //此处有患者备注名，显示备注名，没有显示患者姓名
        if (!TextUtils.isEmpty(bean.getString("remarkName"))) {
            holder.tv_patient_name.setText(bean.getString("remarkName"));
        } else {
            holder.tv_patient_name.setText(bean.getString("name"));
        }
        //药单的产生日期
        holder.tv_patient_time.setText(bean.getString("createdAt"));

        //获得药单的信息，此处只显示一个药品的信息，接口也只给了一个
        List<XCJsonBean> skusList = bean.getList("skus");
        if (skusList != null && skusList.size()>0) {
            XCJsonBean skusBean = skusList.get(0);
            holder.tv_medical_name.setText(skusBean.getString("name"));
            holder.tv_medical_num.setText("×" + skusBean.getString("quantity"));
            holder.tv_medical_intro.setText(skusBean.getString("usages"));
        }

        //显示药单状态
        if ("1".equals(bean.getString("status"))) {
            holder.tv_buy_status.setText("已购买");
            holder.tv_buy_status.setTextColor(context.getResources().getColor(R.color.c_7b7b7b));
        } else {
            holder.tv_buy_status.setText("未购买");
            holder.tv_buy_status.setTextColor(context.getResources().getColor(R.color.c_e2231a));
        }
        return view;
    }
}
