package com.qlk.ymz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PF_WaitRegisterContactsAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.PF_WaitRegisterContactsInfo;
import com.qlk.ymz.parse.Parse2WaitRegisterContactsBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.PinnedHeaderExpandableListView;
import com.qlk.ymz.view.XCSlideBar_V2;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * 等待注册联系人
 * @author zhangpengfei
 * @version 1.2
 */
public class PF_WaitRegisterContactsActivity extends DBActivity {
    /** 返回 */
    private LinearLayout pf_id_wait_register_contacts_back;
    /**添加*/
    private RelativeLayout pf_id_wait_register_contacts_add;
    /**搜索*/
    private LinearLayout pf_id_wait_register_contacts_search;
    /**没有数据页面*/
    private LinearLayout rl_noData;
    private PinnedHeaderExpandableListView xc_id_fragment_search_slide_listview;
    /**字母条*/
    private LinearLayout ll_SlideBar;
    private XCSlideBar_V2 pf_id_search_slide_slidebar;
    /**中间显示字母*/
    private TextView xc_id_fragment_search_slide_dialog;
    /**联系人集合*/
    private List<List<PF_WaitRegisterContactsInfo>> waitRegisterContactsInfos;
    /**key集合*/
    private ArrayList<String> keyList;
    /**字母对应listview中的位置*/
    private LinkedHashMap<String, Integer> sava_letter_position_map = new LinkedHashMap<>();
    private PF_WaitRegisterContactsAdapter contactsAdapter;
    /**解析联系人数据*/
    private Parse2WaitRegisterContactsBean parse2WaitRegisterContactsBean;
    /*** 联系人数据*/
    public static List<List<PF_WaitRegisterContactsInfo>> WAIT_REGISTER_CONTACTS_INFO = new ArrayList<>();
    /** 是否正在获取短信模板*/
    private boolean isGetingSMSModel = false;
    /**第一次进来页面,用来进行请求短信模板*/
    private boolean isFirstInto = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_activity_wait_register_contact);
        super.onCreate(savedInstanceState);

    }

    /** created by songxin,date：2016-6-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_WaitRegisterContactsActivity.class);
    }

    /** created by songxin,date：2016-6-29,about：bi,end */

    @Override
    protected void onResume() {
        super.onResume();
        requestContacts();
    }

    @Override
    public void initWidgets() {
        rl_noData = getViewById(R.id.rl_noData);
        ((TextView)getViewById(R.id.id_zero_data_tv)).setText("一个联系人都没有");

        pf_id_wait_register_contacts_back = getViewById(R.id.pf_id_wait_register_contacts_back);
        pf_id_wait_register_contacts_add = getViewById(R.id.pf_id_wait_register_contacts_add);
        pf_id_wait_register_contacts_search = getViewById(R.id.pf_id_wait_register_contacts_search);
        xc_id_fragment_search_slide_dialog = getViewById(R.id.xc_id_fragment_search_slide_dialog);
        xc_id_fragment_search_slide_listview = getViewById(R.id.xc_id_fragment_search_slide_listview);
        ll_SlideBar = getViewById(R.id.ll_SlideBar);
        pf_id_search_slide_slidebar = getViewById(R.id.pf_id_search_slide_slidebar);
        pf_id_search_slide_slidebar.setTextView(xc_id_fragment_search_slide_dialog);
        waitRegisterContactsInfos = new ArrayList<>();
        keyList = new ArrayList<>();
        parse2WaitRegisterContactsBean = new Parse2WaitRegisterContactsBean(waitRegisterContactsInfos, keyList);
        contactsAdapter = new PF_WaitRegisterContactsAdapter(waitRegisterContactsInfos, xc_id_fragment_search_slide_listview, keyList, this);
        xc_id_fragment_search_slide_listview.setAdapter(contactsAdapter);
        pf_id_search_slide_slidebar.setVisibility(View.INVISIBLE);
        requestContactsSMSModel();
        pf_id_search_slide_slidebar.setABC(keyList);
    }

    @Override
    public void listeners() {
        pf_id_wait_register_contacts_add.setOnClickListener(this);
        pf_id_wait_register_contacts_search.setOnClickListener(this);
        pf_id_wait_register_contacts_back.setOnClickListener(this);
        // 右侧字母列表的滑动监听
        pf_id_search_slide_slidebar.setOnTouchingLetterChangedListener(new XCSlideBar_V2.OnTouchingLetterChangedListener() {

            @Override
            public void onTouchingLetterChanged(String s) {
                //获得手指按压的字母位置，患者列表滑动到相应字母位置
                int position = null == sava_letter_position_map.get(s) ? 0 : sava_letter_position_map.get(s);
                if (position >= 0) {
                    xc_id_fragment_search_slide_listview.setSelection(position); // 由于有headView所以得加1
                }
            }
        });
        // 返回true，不会收缩(点击效果还在)，即在调用allExpand后， 再设置该监听，即可达到全部展示不会收缩的效果
        xc_id_fragment_search_slide_listview.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                return true;
            }
        });
    }

    @Override
    public void onNetRefresh() {
        requestContacts();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            // 添加
            case R.id.pf_id_wait_register_contacts_add :
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(PF_WaitRegisterContactsActivity.class,"2","128","pf_id_wait_register_contacts_add","",false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                myStartActivity(XL_ContactsInviteActivity.class);
                break;
            // 搜索
            case R.id.pf_id_wait_register_contacts_search :
                WAIT_REGISTER_CONTACTS_INFO.clear();
                WAIT_REGISTER_CONTACTS_INFO.addAll(waitRegisterContactsInfos);
                myStartActivity(PF_WaitRegisterContactSearchActivity.class);
                break;
            case R.id.pf_id_wait_register_contacts_back :
                myFinish();
                break;
        }
    }
    /**
     * 获取邀请联系人的短信模板
     */
    public void requestContactsSMSModel() {
        //每次进入联系人页会都会进行请求短信模板或者短信模板为空的时候才进行请求
        if (UtilString.isBlank(GlobalConfigSP.getInvitedMsg()) || !isFirstInto){
            if(isGetingSMSModel){
                return;
            }
            isGetingSMSModel = true;
            XCHttpAsyn.postAsyn(false, false, this, AppConfig.getHostUrl(AppConfig.model_contacts_sms),  new RequestParams(), new XCHttpResponseHandler() {
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if(result_boolean){
                        List<XCJsonBean> jsonBeans = result_bean.getList("data");
                        if (jsonBeans != null && jsonBeans.size() > 0) {
                            XCJsonBean obj = jsonBeans.get(0);
                            String messageContent = obj.getString("messageContent");
                            if(!UtilString.isBlank(messageContent)){
                                GlobalConfigSP.setInvitedMsg(messageContent);
                            }
                        }
                    }
                }

                @Override
                public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                    super.onFailure(code, headers, arg2, e);
                }

                @Override
                public void fail() {
                }

                @Override
                public void onFinish() {
                    super.onFinish();
                    isGetingSMSModel = false;
                    isFirstInto = true;
                }
            });
        }
    }

    /** 和患者列表中的字母位置对应：右侧按住哪个字母，列表就滑动到相应位置 */
    public LinkedHashMap<String, Integer> initLettersPosition(List<String> listParent, List<List<PF_WaitRegisterContactsInfo>> listChild) {
        String record_last_letter = null;
        for (int i = 0; i < listParent.size(); i++) {
            String letter = listParent.get(i);
            if (!letter.equals(record_last_letter)) {
                if (listChild.get(i) != null) {
                    if (i == 0) {
                        sava_letter_position_map.put(letter, 0);
                    } else {
                        // position等于上一个字母的位置+改字母的子项的数量
                        int position = 1 + sava_letter_position_map.get(record_last_letter) + listChild.get(i - 1).size();
                        sava_letter_position_map.put(letter, position);
                    }
                }
            }
            record_last_letter = letter;
        }
        return sava_letter_position_map;
    }

    /**
     * 请求联系人数据
     */
    private void requestContacts(){
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.waitRegisterContacts), new RequestParams(), new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (xc_id_model_no_net != null) {
                    UtilViewShow.setVisible(false, xc_id_model_no_net);
                }
                if(result_boolean){
                    //清除list数据
                    keyList.clear();
                    waitRegisterContactsInfos.clear();
                    //解析数据
                    parse2WaitRegisterContactsBean.parseJson(result_bean);
                    if (keyList.size() == 0){
                        rl_noData.setVisibility(View.VISIBLE);
                    }else{
                        rl_noData.setVisibility(View.GONE);
                        pf_id_search_slide_slidebar.setABC(keyList);
                        contactsAdapter.update(keyList, waitRegisterContactsInfos);
                        initLettersPosition(keyList, waitRegisterContactsInfos);
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                if (xc_id_model_no_net != null) {
                    UtilViewShow.setVisible(true, xc_id_model_no_net);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                isGetingSMSModel = false;
            }
        });
    }
}
