package com.qlk.ymz.activity;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import java.util.List;

/**
 * 患者搜索结果页
 * create by 马杨茗 on 2016-6-13 数据由从本地数据库获取
 * @version  2.5
 */
public class YM_PatientSearchResultActivity extends DBActivity{
    private ListView patientListView;//显示患者搜索结果的列表
    /** 新患者适配器 */
    private NewPatientAdapter adapter;
    /** 搜索关键字 */
    private  String keyword;
    /** 显示患者信息不全的对话框 */
    private YR_CommonDialog commonInfoDialog;

    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.ym_l_activity_patient_result);

        keyword = getIntent().getStringExtra(YR_PatientSearchActivity.SEARCH_KEY);
        super.onCreate(savedInstanceState);

        initTitle();
    }

    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YM_PatientSearchResultActivity.class);
    }

    /** 初始化title */
    public void initTitle(){
        findViewById(R.id.sx_id_title_left).setOnClickListener(this);
        ((TextView)findViewById(R.id.sx_id_title_center)).setText(keyword);
    }

    /** 无网络时,点击屏幕后回调的方法 */
    public void onNetRefresh() {

    }

    /** 初始化控件 */
    public void initWidgets() {
        adapter = new NewPatientAdapter(this, null);
        patientListView = (ListView) findViewById(R.id.ym_id_patient_result);
        View emptyView = getLayoutInflater().inflate(R.layout.xc_l_view_data_zero,null);
        TextView xc_id_data_zero_hint_textview = (TextView) emptyView.findViewById(R.id.xc_id_data_zero_hint_textview);
        ImageView xc_id_data_zero_imageview = (ImageView) emptyView.findViewById(R.id.xc_id_data_zero_imageview);
        patientListView.setAdapter(adapter);
        xc_id_data_zero_hint_textview.setText("抱歉，没有匹配的患者");
        xc_id_data_zero_imageview.setImageResource(R.mipmap.js_d_icon_no_data);
        addContentView(emptyView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        patientListView.setEmptyView(emptyView);
    }

    public void listeners() {
        patientListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                dShortToast(String.valueOf(position));
                JS_ChatListModel bean = (JS_ChatListModel) parent.getItemAtPosition(position);
                bean.getUserDoctor().setDoctorSelfId(UtilSP.getUserId());
                if (TextUtils.isEmpty(bean.getUserPatient().getPatientName())) { //患者资料不全,弹出dialog
                    if (commonInfoDialog == null) {
                        commonInfoDialog = new YR_CommonDialog(YM_PatientSearchResultActivity.this, "患者资料不全!", "", "我知道了") {

                            @Override
                            public void confirmBtn() {
                                dismiss();
                            }
                        };
                    }
                    commonInfoDialog.show();
                    return;
                }
                ToJumpHelp.toJumpChatPatientInfoActivity(YM_PatientSearchResultActivity.this,bean);
            }
        });
    }



    protected void onResume() {
        super.onResume();
        patientSearchResult();
    }

    /** created by 马杨茗,date：2016-4-13
     * 从数据库查询匹配的患者信息
     */
    private void patientSearchResult(){
        List<JS_ChatListModel> chatListModels = JS_ChatListDB.getInstance(getApplicationContext(), UtilSP.getUserId())
                .getSearchPatientInfo(keyword);
        adapter.update(chatListModels);
        adapter.notifyDataSetChanged();
    }

    /** 患者搜索结果适配器 */
    public class NewPatientAdapter extends XCBaseAdapter<JS_ChatListModel> {
        public String KEYWORD_COLOR = "#e2231a";

        public DisplayImageOptions options;

        public NewPatientAdapter(Context context, List<JS_ChatListModel> list) {
            super(context, list);
            options = XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_patient_default);
        }

        class ViewHolder {
            XCRoundedImageView xc_id_patient_imagehead;
            TextView xy_id_patient_display_name;
            TextView xy_id_patient_name;
            View v_bottom_line;
        }

        public View getView(final int position, View convertView, ViewGroup parent) {
            JS_ChatListModel bean = list.get(position);
            ViewHolder holder;
            if (convertView == null) {
                holder = new ViewHolder();
                convertView = LayoutInflater.from(context).inflate(R.layout.xy_l_adapter_patient_search_result, parent, false);

                holder.xc_id_patient_imagehead = (XCRoundedImageView) convertView.findViewById(R.id.xc_id_patient_imagehead);
                holder.xy_id_patient_display_name = (TextView) convertView.findViewById(R.id.xy_id_patient_display_name);
                holder.xy_id_patient_name = (TextView) convertView.findViewById(R.id.xy_id_patient_name);
                holder.v_bottom_line = convertView.findViewById(R.id.v_bottom_line);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

//          设置底部分割线，如果是当前字母最后一个则隐藏
            holder.v_bottom_line.setVisibility(View.VISIBLE);
            if (list.size() - 1 == position) {
                holder.v_bottom_line.setVisibility(View.INVISIBLE);
            }
//          设置患者头像
            XCApplication.displayImage(bean.getUserPatient().getPatientImgHead(), holder.xc_id_patient_imagehead, options);
//          患者备注名
            String memoName = bean.getUserPatient().getPatientMemoName();
//          患者昵称
            String name = bean.getUserPatient().getPatientName();
            String displayName = name;

            //有备注名时，上面大字体tv放备注名，下面tv放昵称
            //没备注名时，上面大字体tv放昵称、居中，下面tv不显示
            if(!TextUtils.isEmpty(memoName)){//有备注名时
                displayName = memoName;
                String nameText = "昵称：" + name;
                holder.xy_id_patient_display_name.setText(memoName);
                holder.xy_id_patient_name.setText(nameText);
                holder.xy_id_patient_name.setVisibility(View.VISIBLE);
                //下行昵称关键字高亮
                if(name.contains(keyword)){
                    int start = name.indexOf(keyword) + 3;
                    int end = start + keyword.length();
                    UtilString.setLightString(nameText,holder.xy_id_patient_name,start,end, KEYWORD_COLOR);
                }
            }else{
                holder.xy_id_patient_name.setVisibility(View.GONE);
            }

            holder.xy_id_patient_display_name.setText(displayName);
            //上行关键字高亮
            if(displayName.contains(keyword)){
                int start = displayName.indexOf(keyword);
                int end = start + keyword.length();
                UtilString.setLightString(displayName, holder.xy_id_patient_display_name, start, end, KEYWORD_COLOR);
            }
            return convertView;
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(commonInfoDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
    }

    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()){
            case R.id.sx_id_title_left:
                myFinish();
                break;
        }
    }
}