package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PatientsRecoverAdapter;
import com.qlk.ymz.application.DBApplication;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.maintab.YR_PatientFragment;
import com.qlk.ymz.model.CheckPatientBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 李涛
 * @description   删除患者恢复页面
 * @Date 2018/10/15
 */
public class PatientsRecoverActivity extends DBActivity {

    /**恢复患者列表*/
    private ListView lv_patients_list;
    /**标题*/
    private XCTitleCommonLayout patients_recover_titlebar;
    /**恢复按钮*/
    private Button bt_patient_recover;
    /**选中的患者ID*/
    private ArrayList<CheckPatientBean> checkedList = new ArrayList();
    /**患者列表数据*/
    private ArrayList<CheckPatientBean> dataList = new ArrayList<>() ;
    private PatientsRecoverAdapter adapter;
    /** 无患者时候的背景图 */
    private  View include_data_zero_view;
    /**正文布局*/
    private LinearLayout ll_patient_context;
    /**无网络布局*/
    private RelativeLayout lt_put_nonetview;

    private boolean isRecoverPatients = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.patients_recover_activity);
        super.onCreate(savedInstanceState);
        initData();
    }

    @Override
    public void initWidgets() {

        ll_patient_context = findViewById(R.id.ll_patient_context);
        lt_put_nonetview = findViewById(R.id.lt_put_nonetview);
        xc_id_no_net_button =   findViewById(R.id.xc_id_no_net_button);
        patients_recover_titlebar = findViewById(R.id.patients_recover_titlebar);
        patients_recover_titlebar.setTitleLeft( true, "");
        patients_recover_titlebar.setTitleCenter(true,"恢复患者");
        lv_patients_list = findViewById(R.id.lv_patients_list);
        bt_patient_recover = findViewById(R.id.bt_patient_recover);
        bt_patient_recover.setEnabled(false);
        adapter = new PatientsRecoverAdapter(this,dataList);
        lv_patients_list.setAdapter(adapter);
        //初始化无数据页面
        setNoPatientView();
    }

    @Override
    public void listeners() {
        xc_id_no_net_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initData();
            }
        });
        adapter.setOnclickCheckListener(new PatientsRecoverAdapter.OnclickCheckListener() {
            @Override
            public void onClick(ArrayList<CheckPatientBean> checkList) {
                checkedList = checkList;
                updateButtomBg();
            }
        });

        bt_patient_recover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                patientRecover();
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }


    private void initData() {

        XCHttpAsyn.getAsyn(true,this, AppConfig.getHostUrl(AppConfig.patient_delete_list),new RequestParams(),new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    lt_put_nonetview.setVisibility(View.GONE);
                    List<XCJsonBean> data =  result_bean.getList("data");
                    dataList = parseData(data);
                    if(dataList.size()>0){
                        include_data_zero_view.setVisibility(View.GONE);
                        ll_patient_context.setVisibility(View.VISIBLE);
                        adapter.update(dataList);
                    }else{
                        include_data_zero_view.setVisibility(View.VISIBLE);
                        ll_patient_context.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                lt_put_nonetview.setVisibility(View.VISIBLE);
                include_data_zero_view.setVisibility(View.GONE);
                ll_patient_context.setVisibility(View.GONE);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(PatientsRecoverActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }


    /**
     * 解析当前列表数据
     * @param data
     * @return
     */
    public ArrayList<CheckPatientBean> parseData(List<XCJsonBean> data){
        ArrayList<CheckPatientBean> list = new ArrayList<>();
        try {
            for (int i=0;i<data.size();i++){
                CheckPatientBean bean = new CheckPatientBean();
                bean.setPatientGender(data.get(i).getString("gender"));
                bean.setPatientName(data.get(i).getString("name"));
                bean.setPatientAge(data.get(i).getString("age"));
                bean.setPatientImgHead(data.get(i).getString("patientIcon"));
                bean.setPatientId(data.get(i).getString("patientId"));
                list.add(bean);
            }
        }catch (Exception e){
            Log.e("PatientsRecoverActivity","恢复删除患者解析失败");
        }
        return list;
    }


    /**
     * 恢复删除患者
     */
    public void patientRecover(){

        StringBuilder builder = new StringBuilder();
        for (int i = 0;i < checkedList.size();i++){
            if(i== (checkedList.size()-1)){
                builder.append(checkedList.get(i).getPatientId());
            }else{
                builder.append(checkedList.get(i).getPatientId()).append(",");
            }
        }
        RequestParams params = new RequestParams();
        params.put("patientIds",builder.toString());
        XCHttpAsyn.getAsyn(true,this,AppConfig.getHostUrl(AppConfig.patient_recover),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean){
                    isRecoverPatients = true;
                    lt_put_nonetview.setVisibility(View.GONE);
                    dataList.removeAll(checkedList);
                    adapter.notifyDataSetChanged();
                    checkedList.clear();

                    bt_patient_recover.setBackgroundResource(R.mipmap.buttom_bt_bg_ubdertint);
                    bt_patient_recover.setEnabled(false);

                    if (dataList.size()==0){
                        lt_put_nonetview.setVisibility(View.GONE);
                        include_data_zero_view.setVisibility(View.VISIBLE);
                        ll_patient_context.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                lt_put_nonetview.setVisibility(View.VISIBLE);
                ll_patient_context.setVisibility(View.GONE);
                include_data_zero_view.setVisibility(View.GONE);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(PatientsRecoverActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }



    /** 初始化无患者时候的背景图 */
    public void setNoPatientView() {
        include_data_zero_view = findViewById(R.id.include_data_zero_view);
        include_data_zero_view.setVisibility(View.GONE);
        TextView xc_id_no_net_button =  include_data_zero_view.findViewById(R.id.xc_id_data_zero_hint_textview);
        xc_id_no_net_button.setText("暂无可恢复患者");
        ((ImageView) include_data_zero_view.findViewById(R.id.xc_id_data_zero_imageview)).setImageResource(R.mipmap.js_d_icon_no_data);
    }


    private void updateButtomBg(){
        if(checkedList.size()>0){
            bt_patient_recover.setBackgroundResource(R.mipmap.buttom_bt_bg);
            bt_patient_recover.setEnabled(true);
        }else{
            bt_patient_recover.setBackgroundResource(R.mipmap.buttom_bt_bg_ubdertint);
            bt_patient_recover.setEnabled(false);
        }
    }


    @Override
    protected void onDestroy() {
        //刷新患者页面
       if( isRecoverPatients ){
           Intent intent = new Intent();
           intent.setAction(YR_PatientFragment.REFRESH_ACTION);
           sendBroadcast(intent);
       }
        super.onDestroy();
    }

}
