package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.reply.YRAutoReplyDao;
import com.qlk.ymz.db.reply.YRAutoReplyHelper;
import com.qlk.ymz.db.reply.YRAutoReplyModel;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.PickerView;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.android.fw.general.view.XCSwitchButton;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * SX_DisturbModeActivity
 * 勿扰模式页面
 *
 * @author songxin on 2015/11/12.
 * @version 1.4.0
 */
public class SX_DisturbModeActivity extends DBActivity {
    /** 自动回复Dao */
    YRAutoReplyDao replyDao ;
    /** 勿扰模式开关 */
    private XCSwitchButton sx_id_setting_open_do_not_disturb_mode;
    /** 开启勿扰模式显示布局 */
    private RelativeLayout sx_id_mode_open_show_rl;
    /** 开启时间rl */
    private RelativeLayout sx_id_begin_time_rl;
    /** 开启时间显示 */
    private TextView sx_id_begin_time_show;
    /** 结束时间rl */
    private RelativeLayout sx_id_end_time_rl;
    /** 结束时间显示 */
    private TextView sx_id_end_time_show;
    /** 开启自动回复开关*/
    private XCSwitchButton xc_id_setting_open_automatic_reply;
    /** 开启自动回复显示布局*/
    private RelativeLayout sx_id_show_automatic_reply_rl;
    /** 自动回复显示*/
    private TextView sx_id_show_automatic_reply_text;
    /** title Fragment */
    private XCTitleCommonLayout xcTitleCommonFragment;
    /** 自定义时间选择dialog */
    ConfirmDialog mChooseDateDialog;
    /** 请求服务器传的开始时，分，结束时，分 */
    String mBeginHour = "00", mBeginMinute = "00", mEndHour = "06", mEndMinute = "00";
    /** 时间设置临时的开始时，分，结束时，分 */
    String tBeginHour = "00", tBeginMinute = "00", tEndHour = "06", tEndMinute = "00";
//    /** 自定义时间选择dialog title */
//    TextView sx_id_choose_date_name_text;
    /** 自定义时间选择dialog 小时选择器 */
    PickerView sx_id_minute_pv;
    /** 自定义时间选择dialog 分钟选择器 */
    PickerView sx_id_second_pv;
    /** 自定义时间选择dialog 确定按钮 */
    TextView sx_id_confirm_button;
    /** 自定义时间选择dialog 取消按钮 */
    TextView sx_id_cencel;

    /** 是否打开了勿扰模式 */
    private boolean mOpenDisturbMode = false;
    /** 是否打开了自动回复 */
    private boolean mOpenAutomaticReply = false;
    /** 勿扰模式回复内容 */
    public final static String AVOID_DISTURB_CONTENT = "avoid_disturb_content";
    /** 勿扰时间分隔统一冒号 */
    public static String RISK = ":";
    /** 是否点击回复按钮跳转到回复列表页,防止返回时先走监听事件，再走forResult ，重复启动列表页*/
    public boolean isOpenBtn = false;
    /** 是否是进入页面的时候，打开勿扰模式开关，非手动，初始化后变为false */
    public boolean isComeOpen = true;
    /** 标记选择*/
    private String mChooseFlag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //初始化db
        replyDao = YRAutoReplyDao.getInstance(this);
        // 设置布局
        setContentView(R.layout.sx_l_activity_do_not_disturb_mode);
        super.onCreate(savedInstanceState);

        // created by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(SX_DisturbModeActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-25,about：saveInfo,end
        xcTitleCommonFragment = getViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonFragment.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        xcTitleCommonFragment.setTitleLeft(true, "");
        xcTitleCommonFragment.setTitleCenter(true, "勿扰模式");
        xcTitleCommonFragment.setTitleRight2(true, 0, "保存");

        // 初始化时间参数
        if (UtilSP.getDistrubBeginTime().contains(RISK)) {
            String currentBeginTime[] = UtilSP.getDistrubBeginTime().split(RISK);
            tBeginHour = mBeginHour = currentBeginTime[0];
            if (currentBeginTime.length>1)
                tBeginMinute = mBeginMinute = currentBeginTime[1];
        }
        if (UtilSP.getDistrubEndTime().contains(RISK)) {
            String currentEndTime[] = UtilSP.getDistrubEndTime().split(RISK);
            tEndHour = mEndHour = currentEndTime[0];
            if (currentEndTime.length>1)
                tEndMinute = mEndMinute = currentEndTime[1];
        }

        if (UtilSP.getDistrubSetting()) {
            mOpenDisturbMode = true;
            sx_id_mode_open_show_rl.setVisibility(View.VISIBLE);
            sx_id_setting_open_do_not_disturb_mode.setState(true);

            sx_id_begin_time_show.setText(checkDate(mBeginHour + RISK + mBeginMinute));
            sx_id_end_time_show.setText(checkDate(mEndHour + RISK + mEndMinute));
        } else {
            mOpenDisturbMode = false;
            sx_id_mode_open_show_rl.setVisibility(View.GONE);
            sx_id_setting_open_do_not_disturb_mode.setState(false);
        }

        //初始化回复按钮
        if (UtilSP.getDistrubAutoReply()) {
            setReplyBtnStatus(true, UtilSP.getDistrubAutoReplyContent());
            replyDao.insertSelectedInfo(UtilSP.getDistrubAutoReplyContent());
        } else {
            setReplyBtnStatus(false, "");
        }
        //初始化完后设置成false
        isComeOpen = false;


        //完成按钮
        xcTitleCommonFragment.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(SX_DisturbModeActivity.class,"2","128","SX_DisturbModeActivity_getXc_id_titlebar_right2_layout","",false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                requestDisturb();
            }
        });

        //Dialog初始化
        int srceenW = this.getWindowManager().getDefaultDisplay().getWidth();
        mChooseDateDialog = new ConfirmDialog(SX_DisturbModeActivity.this, srceenW, 260
                , R.layout.sx_l_date_choose_dialog, R.style.xc_s_dialog);
        mChooseDateDialog.setCanceledOnTouchOutside(false);
        Window window = mChooseDateDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
//        sx_id_choose_date_name_text = (TextView) mChooseDateDialog.findViewById(R.id.sx_id_choose_date_name_text);
        sx_id_minute_pv = (PickerView) mChooseDateDialog.findViewById(R.id.sx_id_minute_pv);
        sx_id_second_pv = (PickerView) mChooseDateDialog.findViewById(R.id.sx_id_second_pv);
        sx_id_cencel = (TextView)mChooseDateDialog.findViewById(R.id.sx_id_cencel);

        sx_id_confirm_button = (TextView) mChooseDateDialog.findViewById(R.id.sx_id_confirm_button);
        sx_id_confirm_button.setOnClickListener(this);
        sx_id_minute_pv.setOnSelectListener(new PickerView.onSelectListener() {
            @Override
            public void onSelect(String text) {
                printi("http", "text------->" + text);
                if (mChooseFlag.equals("开启时间")) {
                    tBeginHour = text;
                } else {
                    tEndHour = text;
                }
            }
        });

        sx_id_second_pv.setOnSelectListener(new PickerView.onSelectListener() {
            @Override
            public void onSelect(String text) {
                printi("http", "text------->" + text);
                if (mChooseFlag.equals("开启时间")) {
                    tBeginMinute = text;
                } else {
                    tEndMinute = text;
                }
            }
        });
        sx_id_cencel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mChooseDateDialog.dismiss();
            }
        });

    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_DisturbModeActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    /** 设置勿扰回复信息开关 */
    public void setReplyBtnStatus(boolean isOpen, String content) {
        sx_id_show_automatic_reply_text.setText(content);
        sx_id_show_automatic_reply_rl.setVisibility(isOpen ? View.VISIBLE : View.GONE);
        mOpenAutomaticReply = isOpen;
        xc_id_setting_open_automatic_reply.setState(isOpen);
    }

    // 无网络时,点击屏幕后回调的方法
    @Override
    public void onNetRefresh() {
    }

    // 初始化控件
    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        sx_id_setting_open_do_not_disturb_mode = getViewById(R.id.sx_id_setting_open_do_not_disturb_mode);
        sx_id_mode_open_show_rl = getViewById(R.id.sx_id_mode_open_show_rl);
        sx_id_begin_time_rl = getViewById(R.id.sx_id_begin_time_rl);
        sx_id_begin_time_show = getViewById(R.id.sx_id_begin_time_show);
        sx_id_end_time_rl = getViewById(R.id.sx_id_end_time_rl);
        sx_id_end_time_show = getViewById(R.id.sx_id_end_time_show);
        xc_id_setting_open_automatic_reply = getViewById(R.id.xc_id_setting_open_automatic_reply);
        sx_id_show_automatic_reply_rl = getViewById(R.id.sx_id_show_automatic_reply_rl);
        sx_id_show_automatic_reply_text = getViewById(R.id.sx_id_show_automatic_reply_text);

    }

    // 设置监听
    @Override
    public void listeners() {
        sx_id_begin_time_rl.setOnClickListener(this);
        sx_id_end_time_rl.setOnClickListener(this);
        sx_id_show_automatic_reply_rl.setOnClickListener(this);
        //勿扰模式监听事件
        sx_id_setting_open_do_not_disturb_mode.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            @Override
            public void open() {
                mOpenDisturbMode = true;
                sx_id_mode_open_show_rl.setVisibility(View.VISIBLE);
                sx_id_begin_time_show.setText(checkDate(mBeginHour + RISK + mBeginMinute));
                sx_id_end_time_show.setText(checkDate( mEndHour + RISK + mEndMinute));
                //手动点击勿扰开关，走下面代码
                if (!isComeOpen) {//sp不空，则设置回复开关打开，并在db中检查此内容
                    if (!TextUtils.isEmpty(UtilSP.getDistrubAutoReplyContent())) {
                        setReplyBtnStatus(true, UtilSP.getDistrubAutoReplyContent());
                        replyDao.insertSelectedInfo(UtilSP.getDistrubAutoReplyContent());
                    }else {//sp为空，检查db，如果有列表项，取第一条；为空，打开，跳转到回复列表页
                        YRAutoReplyModel replyModel = replyDao.selectReplyFirst();
                        if (replyModel != null) {
                            setReplyBtnStatus(true, replyModel.getContent());
                        } else {
                            xc_id_setting_open_automatic_reply.setState(true);
//                            setReplyBtnStatus(true, "");
                        }
                    }
                }
            }

            @Override
            public void close() {
                mOpenDisturbMode = false;
                sx_id_mode_open_show_rl.setVisibility(View.GONE);
                //设置回复按钮状态，当勿扰按钮关闭时，回复按钮也关闭
                setReplyBtnStatus(false, "");
            }
        });

        //自动回复监听事件
        xc_id_setting_open_automatic_reply.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            @Override
            public void open() {
                if (!TextUtils.isEmpty(sx_id_show_automatic_reply_text.getText().toString().trim())) {
                    mOpenAutomaticReply = true;
                    sx_id_show_automatic_reply_rl.setVisibility(View.VISIBLE);
                } else {
                    if (!isOpenBtn ) {//锁监听事件，防止从回复列表页返回时先走这里，重复启动页面
                        myStartActivityForResult(YR_AvoidDisturbActivity.class, 2);
                        isOpenBtn = true;
                    }
                }
            }

            @Override
            public void close() {
                mOpenAutomaticReply = false;
                sx_id_show_automatic_reply_rl.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.sx_id_begin_time_rl: {
                showDatePickDialog("开启时间");
                break;
            }
            case R.id.sx_id_end_time_rl: {
                showDatePickDialog("结束时间");
                break;
            }
            case R.id.sx_id_show_automatic_reply_rl:
                Intent intent = new Intent(this,YR_AvoidDisturbActivity.class);
                intent.putExtra(YRAutoReplyHelper.CONTENT,sx_id_show_automatic_reply_text.getText().toString().trim());
                myStartActivityForResult(intent, 1);
                break;
            case R.id.sx_id_confirm_button: {
                if (null != mChooseDateDialog) {
                    mChooseDateDialog.dismiss();
                }
                if (mChooseFlag.equals("开启时间")) {
                    mBeginHour = tBeginHour;
                    mBeginMinute = tBeginMinute;
                    sx_id_begin_time_show.setText(checkDate(mBeginHour + RISK + mBeginMinute));
                } else if (mChooseFlag.equals("结束时间")) {
                    mEndHour = tEndHour;
                    mEndMinute = tEndMinute;
                    sx_id_end_time_show.setText(checkDate(mEndHour + RISK + mEndMinute));
                }
                break;
            }
        }
    }

    private void showDatePickDialog(final String titleName) {
        mChooseFlag = titleName;
        List<String> minutes = new ArrayList<>();
        List<String> seconds = new ArrayList<>();
        for (int i = 0; i < 24; i++) {
            minutes.add(i < 10 ? "0" + i : "" + i);
        }
        for (int i = 0; i < 60; i++) {
            seconds.add(i < 10 ? "0" + i : "" + i);
        }

        sx_id_minute_pv.setData(minutes);
        sx_id_second_pv.setData(seconds);

//        deleted by cyr on 20151215 start
//        产品需求更改，设置时间更改为当前显示时间
//        Time t = new Time();
//        t.setToNow();
//        sx_id_minute_pv.setSelected(t.hour);
//        sx_id_second_pv.setSelected(t.minute);
//        if (titleName.equals("开启时间")) {
//            tBeginHour = t.hour < 10 ? "0" + t.hour : t.hour + "";
//            tBeginMinute = t.minute < 10 ? "0" + t.minute : t.minute + "";
//
//        } else if (titleName.equals("结束时间")) {
//            tEndHour = t.hour < 10 ? "0" + t.hour : t.hour + "";
//            tEndMinute = t.minute < 10 ? "0" + t.minute : t.minute + "";
//        }
//        deleted by cyr on 20151215 end

//       add by cyr on 20151215 start
//        产品需求更改，设置时间更改为当前显示时间

        if (titleName.equals("开启时间")) {
        sx_id_minute_pv.setSelected(tBeginHour);
        sx_id_second_pv.setSelected(tBeginMinute);

        } else if (titleName.equals("结束时间")) {
        sx_id_minute_pv.setSelected(tEndHour);
        sx_id_second_pv.setSelected(tEndMinute);
        }
//       add by cyr on 20151215 end

     /*   mChooseDateDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                printe(SX_DisturbModeActivity.this, UtilSP.getDistrubBeginTime()+ UtilSP.getDistrubEndTime());
                if (titleName.equals("开启时间")) {
                    if(!UtilString.isBlank(UtilSP.getDistrubBeginTime())){
                        String currentBeginTime[] = UtilSP.getDistrubBeginTime().split("：");
                        mBeginHour = currentBeginTime[0];
                        mBeginMinute = currentBeginTime[1];
                    }
                }
                if (titleName.equals("结束时间")){
                    if(!UtilString.isBlank(UtilSP.getDistrubEndTime())){
                        String currentEndTime[] = UtilSP.getDistrubEndTime().split("：");
                        mEndHour = currentEndTime[0];
                        mEndMinute = currentEndTime[1];
                    }
                }
            }
        });*/
        if (null != mChooseDateDialog) {
            mChooseDateDialog.show();
        }
    }

    private String checkDate(String time) {
        String times[] = time.split(RISK);
        String currentHour = times[0];
        if (!UtilString.isBlank(currentHour)) {
            int hour = Integer.valueOf(currentHour);
            if (hour >= 0 && hour < 6) {
                return "凌晨 " + time;
            } else if (hour >= 6 && hour < 12) {
                return "早上 " + time;
            } else if (hour >= 12 && hour < 13) {
                return "中午 " + time;
            } else if (hour >= 13 && hour < 18) {
                return "下午 " + (hour - 12) + RISK + times[1];
            } else if (hour >= 18 && hour < 24) {
                return "晚上 " + (hour - 12) + RISK + times[1];
            }
        }
        return "";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1) {//点击回复内容跳转到回复列表页，当回复内容不为空时
            if (resultCode == RESULT_OK) {
                setReplyBtnStatus(true, data.getStringExtra(AVOID_DISTURB_CONTENT));
            } else if (resultCode == 1) {//在列表中删除默认回复选项时，返回code==1
                setReplyBtnStatus(false, "");
            }
        } else if (requestCode == 2) {//点击回复开关跳转到回复列表页，当回复内容为空时
            if (resultCode == RESULT_OK) {//点击回复选项返回
                setReplyBtnStatus(true,data.getStringExtra(AVOID_DISTURB_CONTENT));
            } else {//点击返回或手机回退按钮返回
                setReplyBtnStatus(false,"");
            }
            isOpenBtn = false;
        }
    }

    /** 向服务器发送免打扰信息 */
    public void requestDisturb(){
        RequestParams params = new RequestParams();
        params.put("operate", mOpenDisturbMode ? 1 : 0);
        if(mOpenDisturbMode){
            params.put("beginTime", mBeginHour + RISK + mBeginMinute);
            params.put("endTime", mEndHour + RISK + mEndMinute);
        }else{
            params.put("beginTime", "");
            params.put("endTime", "");
        }

        XCHttpAsyn.postAsyn(this, AppConfig.getChatUrl(AppConfig.disturb_set), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (mOpenDisturbMode) {//sp存储勿扰时间和状态
                        UtilSP.setDistrubSetting(true);
                        UtilSP.setDistrubBeginTime(mBeginHour + RISK + mBeginMinute);
                        UtilSP.setDistrubEndTime(mEndHour + RISK + mEndMinute);
                    } else {
                        UtilSP.setDistrubSetting(false);
                        UtilSP.setDistrubBeginTime("");
                        UtilSP.setDistrubEndTime("");
                    }
                    request_reply();
                }

            }
        });
    }


  /** 设置自动回复状态 (0:关闭；1：开启)*/
    public void request_reply(){
        RequestParams params = new RequestParams();
        if (mOpenDisturbMode && mOpenAutomaticReply) {
            params.put("operate",1);
            params.put("content", sx_id_show_automatic_reply_text.getText().toString());
        } else {
            params.put("operate", 0);
            params.put("content", "");
        }

        XCHttpAsyn.postAsyn(this, AppConfig.getChatUrl(AppConfig.disturb_auto_reply), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {//sp存储勿扰回复信息和状态
                    dShortToast("设置成功！");
                    if (mOpenDisturbMode && mOpenAutomaticReply) {
                        UtilSP.setDistrubAutoReply(true);
                        UtilSP.setDistrubAutoReplyContent(sx_id_show_automatic_reply_text.getText().toString());
                    } else {
                        UtilSP.setDistrubAutoReply(false);
                        UtilSP.setDistrubAutoReplyContent("");
                    }
                    myFinish();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mChooseDateDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }
}
