package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.db.medicineUageDosage.XLMedicineUseageDosageDAO;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.util.SP.UtilSP;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * @author 马杨茗 on 2016/6/23.
 * @version 2.5.0
 * @description 用药确认界面药品列表
 */
public class SQ_RecommendAdapter extends XCBaseAdapter<DrugBean> {
//    /** 推荐用药的数据 */
//    private List<DrugBean> list;
    private boolean isShowEdtLinearLayout;

    /**
     * 上下文
     */
    private Context context;
    private LayoutInflater layoutInflater;
    private XLMedicineUseageDosageDAO xlMedicineUseageDosageDAO;//用法用量的数据库

    public SQ_RecommendAdapter(Context context, List<DrugBean> list) {
        super(context, list);
        this.context = context;
        xlMedicineUseageDosageDAO = new XLMedicineUseageDosageDAO(context, UtilSP.getUserId());
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = convertView;
        ViewHolder viewHolder;
        final DrugBean drugBean = (DrugBean)getItem(position);
        if (null == view) {
            view = layoutInflater.inflate(R.layout.sq_item_ordonnance_medication, null);
            viewHolder = new ViewHolder(view);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.ym_item_ordonnance_edt_drugusage.setTag(drugBean);
        viewHolder.ym_item_ordonnance_edt_drugusage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recommendAdapterOnClickListener.OnEditUsageDataClickListener(v,position);
            }
        });

        viewHolder.ym_item_ordonnance_del.setTag(drugBean);
        viewHolder.ym_item_ordonnance_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recommendAdapterOnClickListener.OnRemoveClickListener(v, position);
            }
        });

        viewHolder.sk_id_ordonnance_presell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                XCApplication.base_log.shortToast(drugBean.getPresellInfo());
            }
        });
        try {
            // 是否为预售  1 是 0 否
            if("1".equals(drugBean.getInventoryInfo().getIsPresell())){
                viewHolder.ll_ico.setVisibility(View.VISIBLE);
                viewHolder.sk_id_ordonnance_presell.setVisibility(View.VISIBLE);
                viewHolder.sk_id_ordonnance_short_iv.setVisibility(View.GONE);
            }else {
                viewHolder.sk_id_ordonnance_presell.setVisibility(View.GONE);
                // 购买数量是否大于库存
                if (Integer.parseInt(drugBean.getMedicineUsageBean().getQuantity()) > Integer.parseInt(drugBean.getInventoryInfo().getStockNum())) {
                    viewHolder.sk_id_ordonnance_short_iv.setVisibility(View.VISIBLE);
                    viewHolder.ll_ico.setVisibility(View.VISIBLE);
                } else {
                    viewHolder.ll_ico.setVisibility(View.GONE);
                    viewHolder.sk_id_ordonnance_short_iv.setVisibility(View.GONE);
                }
            }
        } catch (Exception e) {e.printStackTrace();}



        if (isShowEdtLinearLayout) {
            viewHolder.ym_item_ordonnance_medicition_number.setVisibility(View.GONE);
            viewHolder.ym_item_ordonnance_medicition_edt_ll.setVisibility(View.VISIBLE);
        } else {
            viewHolder.ym_item_ordonnance_medicition_number.setVisibility(View.VISIBLE);
            viewHolder.ym_item_ordonnance_medicition_edt_ll.setVisibility(View.GONE);
        }
        viewHolder.ym_item_ordonnance_medicition_name.setText(drugBean.getRecomName());
        viewHolder.ym_item_ordonnance_medicition_number.setText("x" + drugBean
                .getMedicineUsageBean().getQuantity()+ (TextUtils.isEmpty(drugBean
                .getMedicineUsageBean().getQuantityUnit())?"":drugBean.getMedicineUsageBean()
                .getQuantityUnit()));
        if ("".equals(drugBean.getMedicineUsageBean().getBakUp())) { // 备注为空
            viewHolder.ym_item_ordonnance_medicition_direction.setText("用法：" + drugBean.getMedicineUsageBean().getUsages());
        } else { // 备注不为空

            if ("".equals(drugBean.getMedicineUsageBean().getUsages())) { // 用法用量为空
                viewHolder.ym_item_ordonnance_medicition_direction.setText(
                        "用法：" + drugBean.getMedicineUsageBean().getBakUp());
            } else {
                viewHolder.ym_item_ordonnance_medicition_direction.setText(
                        "用法：" + drugBean.getMedicineUsageBean().getUsages() + "," + drugBean.getMedicineUsageBean().getBakUp());
            }

        }
        if (list.size()-1 == position){
            viewHolder.medication_listview_divider.setVisibility(View.GONE);
        }else {
            viewHolder.medication_listview_divider.setVisibility(View.VISIBLE);
        }

        showSafeHint(drugBean,viewHolder);

        return view;
    }

    public void showEdtLinearLayout() {
        isShowEdtLinearLayout = true;
        notifyDataSetChanged();
    }

    public void hideEdtLinearLayout() {
        isShowEdtLinearLayout = false;
        notifyDataSetChanged();
    }

    /**
     * 安全用量提示
     */
    public void showSafeHint(DrugBean drugBean,ViewHolder viewHolder){
        String hint = "";
        if(UtilSP.isRecomSafe()) {
            int num = UtilString.toInt(drugBean.getMedicineUsageBean().getQuantity(), 0);
            if (drugBean.getSixtyDosage()>0 &&num >drugBean.getSixtyDosage()) {
                hint = "禁止：超出安全用药用量上限(上限2个月)";
                viewHolder.tv_item_safe_dosage.setTextColor(context.getResources().getColor(R.color.c_e2231a));
            } else if (drugBean.getDosageMonth()>0 &&num >drugBean.getDosageMonth()) {
                hint = "谨慎：当前药品用量大于30天用量";
                viewHolder.tv_item_safe_dosage.setTextColor(context.getResources().getColor(R.color.c_f5a623));
            } else if (drugBean.getDosageWeek()>0 &&num >drugBean.getDosageWeek()) {
                hint = "谨慎：当前药品用量大于7天用量";
                viewHolder.tv_item_safe_dosage.setTextColor(context.getResources().getColor(R.color.c_f5a623));
            }
            if(TextUtils.isEmpty(hint)){
                viewHolder.tv_item_safe_dosage.setVisibility(View.GONE);
            }else {
                viewHolder.tv_item_safe_dosage.setVisibility(View.VISIBLE);
                viewHolder.tv_item_safe_dosage.setText(hint);
            }
        }
    }

    /**
     * 设置推荐用药列表适配器的监听接口
     *
     * @param recommendAdapterOnClickListener 推荐用药列表适配器的监听接口实现类
     */
    public void setRecommendAdapterOnClickListener(RecommendAdapterOnClickListener recommendAdapterOnClickListener) {
        this.recommendAdapterOnClickListener = recommendAdapterOnClickListener;
    }

    private RecommendAdapterOnClickListener recommendAdapterOnClickListener;

    /**
     * 推荐用药列表适配器的监听接口
     */
    public interface RecommendAdapterOnClickListener {
        /**
         * 删除药品的监听
         *
         * @param v 删除按钮
         */
        void OnRemoveClickListener(View v, int position);

        /**
         * 调整用法用量的监听
         *
         * @param v 调整用法用量的按钮
         */
        void OnEditUsageDataClickListener(View v,int position);

    }

    /**
     * 缓存类
     */
    class ViewHolder {
        public TextView ym_item_ordonnance_medicition_name;//药品名字
        public TextView ym_item_ordonnance_medicition_direction;//药品用法
        public TextView tv_item_safe_dosage;//安全用量提示
        public TextView ym_item_ordonnance_medicition_number;//药品数量
        public LinearLayout ym_item_ordonnance_medicition_edt_ll;//药品编辑的布局,默认为不显示
        public TextView ym_item_ordonnance_edt_drugusage;//调整药品用法数量
        public TextView ym_item_ordonnance_del;//删除药品
        public LinearLayout ll_ico;//库存预售布局
        public ImageView sk_id_ordonnance_presell;//预售
        public ImageView sk_id_ordonnance_short_iv;//库存不足
        public View medication_listview_divider; //分割线

        public ViewHolder(View convertView) {
            ym_item_ordonnance_medicition_name = (TextView) convertView.findViewById(R.id.ym_item_ordonnance_medicition_name);
            ym_item_ordonnance_medicition_direction = (TextView) convertView.findViewById(R.id.ym_item_ordonnance_medicition_direction);
            tv_item_safe_dosage = convertView.findViewById(R.id.tv_item_safe_dosage);
            ym_item_ordonnance_medicition_number = (TextView) convertView.findViewById(R.id.ym_item_ordonnance_medicition_number);
            ym_item_ordonnance_medicition_edt_ll = (LinearLayout) convertView.findViewById(R.id.ym_item_ordonnance_medicition_edt_ll);
            ym_item_ordonnance_edt_drugusage = (TextView) convertView.findViewById(R.id.ym_item_ordonnance_edt_drugusage);
            ym_item_ordonnance_del = (TextView) convertView.findViewById(R.id.ym_item_ordonnance_del);
            ll_ico = convertView.findViewById(R.id.ll_ico);
            sk_id_ordonnance_presell = (ImageView) convertView.findViewById(R.id.sk_id_ordonnance_presell);
            sk_id_ordonnance_short_iv = (ImageView) convertView.findViewById(R.id.sk_id_ordonnance_short_iv);
            medication_listview_divider = convertView.findViewById(R.id.medication_listview_divider);
        }
    }
}