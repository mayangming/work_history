package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.os.MessageQueue;
import android.text.Editable;
import android.text.InputFilter;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.record.CaseInitBean;
import com.qlk.ymz.util.EditsChangeCheckUtil;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SpanUtils;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.EditLinearLayout;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * 主诉页面
 * @author sinki
 */
public class SQ_ChiefComplaintActivity extends DBActivity {
    private XCTitleCommonLayout title_bar;
    /**病情描述内容*/
    private TextView tv_description;
    /**复制到主诉 */
    private TextView tv_copy;
    /**主诉*/
    private EditText et_chief_complaint;
    /**主诉字数*/
    private TextView tv_chief_complaint_text_count;
    /**现病史*/
    private EditText et_current_medical_history;
    /**清空 */
    private TextView tv_clear_medical_history,tv_clear_chief_complaint;
    /**现病史字数*/
    private TextView tv_current_medical_history_text_count;
    /** 更多 */
    private ImageView iv_more;
    private RelativeLayout rl_description;
    private EditLinearLayout ll_chief_complaint,ll_current_medical_history;
    private ScrollView scroll_view;
    private EditsChangeCheckUtil.textChangeListener textChangeListener;
    private YR_CommonDialog dialog;
    private CaseInitBean caseInitBean;

    private boolean requiredFlag = false; // 是否填过数据,true:是,false:否

    private int chiefComplaintMax;
    private int chiefComplaintMin;
    private int medicalHistoryMax;
    private int medicalHistoryMin;

    public static void launch(Activity activity, CaseInitBean caseInitBean,String suit, String
            presentDisease){
        Intent intent = new Intent(activity,SQ_ChiefComplaintActivity.class);
        intent.putExtra(XD_EditMedicalRecordActivity.SUIT,suit);
        intent.putExtra(XD_EditMedicalRecordActivity.PRESENT_DISEASE,presentDisease);
        intent.putExtra(XD_EditMedicalRecordActivity.CASE_INIT_BEAN,caseInitBean);
        activity.startActivityForResult(intent,XD_EditMedicalRecordActivity.TO_SUIT);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_chief_complaint);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SQ_ChiefComplaintActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */



    @Override
    public void initWidgets() {
        title_bar = getViewById(R.id.title_bar);
        tv_description = getViewById(R.id.tv_description);
        tv_copy = getViewById(R.id.tv_copy);
        et_chief_complaint = getViewById(R.id.et_chief_complaint);
        tv_chief_complaint_text_count = getViewById(R.id.tv_chief_complaint_text_count);
        et_current_medical_history = getViewById(R.id.et_current_medical_history);
        tv_clear_medical_history = getViewById(R.id.tv_clear_medical_history);
        tv_current_medical_history_text_count = getViewById(R.id.tv_current_medical_history_text_count);
        ll_chief_complaint = getViewById(R.id.ll_chief_complaint);
        ll_current_medical_history = getViewById(R.id.ll_current_medical_history);
        iv_more = getViewById(R.id.iv_more);
        scroll_view = getViewById(R.id.scroll_view);
        rl_description = getViewById(R.id.rl_description);
        tv_clear_chief_complaint = getViewById(R.id.tv_clear_chief_complaint);

        ll_chief_complaint.setEditText(et_chief_complaint);
        ll_chief_complaint.setParentScrollview(scroll_view);

        ll_current_medical_history.setEditText(et_current_medical_history);
        ll_current_medical_history.setParentScrollview(scroll_view);

        chiefComplaintMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.CASEMAINCOMPLAINT,0,1000);
        chiefComplaintMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.CASEMAINCOMPLAINT,1,3);
        medicalHistoryMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.CASEPRESENTDISEASE,0,1000);
        medicalHistoryMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.CASEPRESENTDISEASE,1,3);
        et_chief_complaint.setFilters(new InputFilter[]{new InputFilter.LengthFilter(chiefComplaintMax)});
        et_chief_complaint.setHint("输入主诉不少于"+chiefComplaintMin +"个字");
        et_current_medical_history.setFilters(new InputFilter[]{new InputFilter.LengthFilter(medicalHistoryMax)});
        et_current_medical_history.setHint("输入现病史不少于"+medicalHistoryMin +"个字");

        Looper.myQueue().addIdleHandler(new MessageQueue.IdleHandler() {
            @Override
            public boolean queueIdle() {
                if(tv_description.getLayout().getEllipsisCount(tv_description.getLineCount() - 1) > 0){
                    iv_more.setVisibility(View.VISIBLE);
                }else {
                    iv_more.setVisibility(View.GONE);
                }
                return false;
            }
        });

        setData2View();

    }

    public void setData2View(){
        String suit = getIntent().getStringExtra(XD_EditMedicalRecordActivity.SUIT);
        String presentDisease = getIntent().getStringExtra(XD_EditMedicalRecordActivity.PRESENT_DISEASE);
        caseInitBean = (CaseInitBean) getIntent().getSerializableExtra(XD_EditMedicalRecordActivity.CASE_INIT_BEAN);

        title_bar.setTitleCenter(true,"主诉/现病史");
        title_bar.setTitleLeft(true,"取消");
        title_bar.getXc_id_titlebar_left_imageview().setVisibility(View.GONE);
        title_bar.setTitleRight2(true,0,"保存");

        tv_description.setText(getDescriptionText());

        if(!TextUtils.isEmpty(suit))  et_chief_complaint.setText(suit);
        tv_chief_complaint_text_count.setText(et_chief_complaint.getText().toString().trim().length() + "/" + chiefComplaintMax);

        if(!TextUtils.isEmpty(presentDisease)){
            et_current_medical_history.setText(presentDisease);
        }else if(!caseInitBean.isClickSaveSuit() && null != caseInitBean.getAmcResultBean() && !TextUtils.isEmpty(caseInitBean.getAmcResultBean().getInquirySymptom())){
            String str = caseInitBean.getAmcResultBean().getInquirySymptom();
            et_current_medical_history.setText(str);
        }

        tv_current_medical_history_text_count.setText(et_current_medical_history.getText().toString().trim().length() + "/" + medicalHistoryMax);

        if(TextUtils.isEmpty(getDescriptionText()) || caseInitBean.isClickSaveSuit()){
            rl_description.setVisibility(View.GONE);
        }else {
            rl_description.setVisibility(View.VISIBLE);
        }

        // 若主诉和现病史为空 则保存按钮置灰并不可点击
        if(TextUtils.isEmpty(et_chief_complaint.getText().toString().trim()) && TextUtils.isEmpty(et_current_medical_history.getText().toString().trim())){
            title_bar.getXc_id_titlebar_right2_textview().setEnabled(false);
            title_bar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_cccccc));
        }else{
            isShowFinishDialog = true;
            requiredFlag = true;
            title_bar.getXc_id_titlebar_right2_textview().setEnabled(true);
            title_bar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        }

        if (TextUtils.isEmpty(suit)){
            tv_clear_chief_complaint.setTextColor(getResources().getColor(R.color.c_gray_cccccc));
        }else {
            tv_clear_chief_complaint.setTextColor(getResources().getColor(R.color.c_7b7b7b));
        }

        if (TextUtils.isEmpty(et_current_medical_history.getText().toString().trim())){
            tv_clear_medical_history.setTextColor(getResources().getColor(R.color.c_gray_cccccc));
        }else {
            tv_clear_medical_history.setTextColor(getResources().getColor(R.color.c_7b7b7b));
        }

    }

    /**
     * 拼接病情描述内容
     * @return 拼接好的字符串
     */
    private SpannableStringBuilder getDescriptionText() {
        SpanUtils spanUtils = new SpanUtils();
        if(!TextUtils.isEmpty(caseInitBean.getPregnancy())){
            spanUtils.append(caseInitBean.getPregnancy() + "\n").setForegroundColor(getResources().getColor(R.color.c_444444)).setFontSize(UtilScreen.dip2px(this,14));
        }
        if(!TextUtils.isEmpty(caseInitBean.getHeight())){
            spanUtils.append("身高：").setForegroundColor(getResources().getColor(R.color.c_444444)).setFontSize(UtilScreen.dip2px(this,14))
                    .append(caseInitBean.getHeight()+ "cm" + "\n").setForegroundColor(getResources().getColor(R.color.c_7b7b7b)).setFontSize(UtilScreen.dip2px(this,14));
        }
        if(!TextUtils.isEmpty(caseInitBean.getWeight())){
            spanUtils.append("体重：").setForegroundColor(getResources().getColor(R.color.c_444444)).setFontSize(UtilScreen.dip2px(this,14))
                    .append(caseInitBean.getWeight()+ "kg" + "\n").setForegroundColor(getResources().getColor(R.color.c_7b7b7b)).setFontSize(UtilScreen.dip2px(this,14));
        }
        if(!TextUtils.isEmpty(caseInitBean.getDescription())){
            spanUtils.append("病情描述：").setForegroundColor(getResources().getColor(R.color.c_444444)).setFontSize(UtilScreen.dip2px(this,14))
                    .append(caseInitBean.getDescription()).setForegroundColor(getResources().getColor(R.color.c_7b7b7b)).setFontSize(UtilScreen.dip2px(this,14));
        }
        return spanUtils.create();
    }

    /**
     * 复制病情描述内容
     * @return 复制的字符串
     */
    private SpannableStringBuilder copyDescriptionText() {
        SpanUtils spanUtils = new SpanUtils();
        if(!TextUtils.isEmpty(caseInitBean.getPregnancy())){
            spanUtils.append(caseInitBean.getPregnancy() + "\n");
        }
        if(!TextUtils.isEmpty(caseInitBean.getHeight())){
            spanUtils.append("身高：").append(caseInitBean.getHeight()+ "cm" + "\n");
        }
        if(!TextUtils.isEmpty(caseInitBean.getWeight())){
            spanUtils.append("体重：").append(caseInitBean.getWeight()+ "kg" + "\n");
        }
        if(!TextUtils.isEmpty(caseInitBean.getDescription())){
            spanUtils.append(caseInitBean.getDescription());
        }
        return spanUtils.create();
    }

    @Override
    public void listeners() {
        tv_copy.setOnClickListener(this);
        tv_clear_medical_history.setOnClickListener(this);
        iv_more.setOnClickListener(this);
        tv_clear_chief_complaint.setOnClickListener(this);

        textChangeListener = new EditsChangeCheckUtil.textChangeListener(null){
            @Override
            public boolean btnChange() {
                boolean isAllEmpty = super.btnChange();
                if(!isAllEmpty){ // false == editext为空
                    if(requiredFlag && "0".equals(GlobalConfigSP.getRequiredFlag())){
                        // 二次进入页面 有数据 并且 非必填
                        title_bar.getXc_id_titlebar_right2_textview().setEnabled(true);
                        title_bar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
                        isShowFinishDialog = true;

                    }else if(requiredFlag && "1".equals(GlobalConfigSP.getRequiredFlag())){
                        // 二次进入页面 有数据 并且 必填
                        title_bar.getXc_id_titlebar_right2_textview().setEnabled(false);
                        title_bar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_cccccc));
                        isShowFinishDialog = true;
                    }else if(!requiredFlag && "0".equals(GlobalConfigSP.getRequiredFlag())){
                        // 无数据进入 非必填
                        title_bar.getXc_id_titlebar_right2_textview().setEnabled(false);
                        title_bar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_cccccc));
                        isShowFinishDialog = false;
                    }else if(!requiredFlag && "1".equals(GlobalConfigSP.getRequiredFlag())){
                        // 无数据进入 必填
                        title_bar.getXc_id_titlebar_right2_textview().setEnabled(false);
                        title_bar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_cccccc));
                        isShowFinishDialog = false;
                    }
                }else {
                    title_bar.getXc_id_titlebar_right2_textview().setEnabled(true);
                    title_bar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
                    isShowFinishDialog = true;
                }

                return isAllEmpty;
            }
        };
        textChangeListener.addAllEditText(et_chief_complaint,et_current_medical_history);

        title_bar.getXc_id_titlebar_left_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        title_bar.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!TextUtils.isEmpty(et_chief_complaint.getText().toString().trim()) && chiefComplaintMin > et_chief_complaint.getText().toString().trim().length()){
                    shortToast("主诉不能少于"+chiefComplaintMin+"个字");
                    return;
                }
                if(!TextUtils.isEmpty(et_current_medical_history.getText().toString().trim()) && medicalHistoryMin > et_current_medical_history.getText().toString().trim().length()){
                    shortToast("现病史不能少于"+medicalHistoryMin+"个字");
                    return;
                }
                if(StringUtils.containsEmoji(et_chief_complaint.getText().toString().trim())){
                    shortToast("主诉不能输入表情");
                    return;
                }
                if(StringUtils.containsEmoji(et_current_medical_history.getText().toString().trim())){
                    shortToast("现病史不能输入表情");
                    return;
                }
                caseInitBean.setClickSaveSuit(true);
                Intent intent = new Intent();
                intent.putExtra(XD_EditMedicalRecordActivity.CASE_INIT_BEAN,caseInitBean);
                intent.putExtra(XD_EditMedicalRecordActivity.SUIT,et_chief_complaint.getText().toString().trim());
                intent.putExtra(XD_EditMedicalRecordActivity.PRESENT_DISEASE,et_current_medical_history.getText().toString().trim());
                setResult(Activity.RESULT_OK,intent);
                myFinish();
            }
        });
        et_chief_complaint.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (0 != et_chief_complaint.getText().toString().trim().length()) {
                    tv_clear_chief_complaint.setEnabled(true);
                    tv_clear_chief_complaint.setTextColor(XCApplication.getInstance().getResources().getColor(R.color.c_7b7b7b));
                } else{
                    tv_clear_chief_complaint.setEnabled(false);
                    tv_clear_chief_complaint.setTextColor(XCApplication.getInstance().getResources().getColor(R.color.c_gray_cccccc));
                }
                tv_chief_complaint_text_count.setText(et_chief_complaint.getText().toString().trim().length() + "/" + chiefComplaintMax);
            }
        });

        et_current_medical_history.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (0 != et_current_medical_history.getText().toString().trim().length()) {
                    tv_clear_medical_history.setEnabled(true);
                    tv_clear_medical_history.setTextColor(XCApplication.getInstance().getResources().getColor(R.color.c_7b7b7b));
                } else{
                    tv_clear_medical_history.setEnabled(false);
                    tv_clear_medical_history.setTextColor(XCApplication.getInstance().getResources().getColor(R.color.c_gray_cccccc));
                }
                tv_current_medical_history_text_count.setText(et_current_medical_history.getText().toString().trim().length() + "/" + medicalHistoryMax);
            }
        });

    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch(v.getId()){
            // 复制到主诉
            case R.id.tv_copy :
                String copyChief = copyDescriptionText().toString();
                if(!UtilString.isBlank(et_chief_complaint.getText().toString().trim())){
                    et_chief_complaint.setText(et_chief_complaint.getText().toString().trim() + "\n" +copyChief);
                }else {
                    et_chief_complaint.setText(copyChief);
                }
                et_chief_complaint.setSelection(et_chief_complaint.getText().toString().trim().length());
                rl_description.setVisibility(View.GONE);
                break;
            // 清空
            case R.id.tv_clear_medical_history :
                et_current_medical_history.setText("");
                tv_clear_medical_history.setTextColor(getResources().getColor(R.color.c_gray_cccccc));
                break;
            case R.id.iv_more:
                showDialog();
                break;
            case R.id.tv_clear_chief_complaint:
                et_chief_complaint.setText("");
                tv_clear_chief_complaint.setTextColor(getResources().getColor(R.color.c_gray_cccccc));
                break;

        }
    }

    private boolean isShowFinishDialog;
    @Override
    public void onBackPressed() {
        if(isShowFinishDialog){
            showFinishDialog();
        }else {
            myFinish();
        }
    }

    /** 点击取消按钮，如果输入框有数据，弹出阻止dialog */
    private void showFinishDialog() {
        YR_CommonDialog dialog = new YR_CommonDialog(this, "放弃保存吗？", "放弃", "取消") {
            @Override
            public void confirmBtn() {
                dismiss();
            }

            @Override
            public void cancelBtn() {
                super.cancelBtn();

                SQ_ChiefComplaintActivity.this.finish();
            }
        };
        dialog.setCancelable(false);
        dialog.show();
    }

    private void showDialog(){
        if(dialog != null){
            dialog.show();
            return;
        }
        YR_CommonDialog dialog = new YR_CommonDialog(this,"","关闭","复制到主诉") {
            @Override
            public void confirmBtn() {
                if(!TextUtils.isEmpty(et_chief_complaint.getText().toString().trim())){
                    et_chief_complaint.setText(et_chief_complaint.getText().toString().trim() + "\n" + copyDescriptionText());
                }else {
                    et_chief_complaint.setText(copyDescriptionText());
                }
                et_chief_complaint.setSelection(et_chief_complaint.getText().toString().trim().length());
                rl_description.setVisibility(View.GONE);
                dismiss();
            }

            @Override
            public void cancelBtn() {
                super.cancelBtn();
            }
        };
        dialog.getContentTV().setText(getDescriptionText());
        dialog.show();
    }
}
