package com.qlk.ymz.fragment;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBFragment;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

/**
 * Created by xiedong on 2017/12/29.
 * 用于网络请求失败
 */

public abstract class XD_BaseFragment extends DBFragment {
    /**
     * 无网络
     */
    private LinearLayout ll_no_net;

    private LinearLayout ll_content;
    /**
     * 无网络界面中的button
     */
    public Button xc_id_no_net_button;
    @Override
    public void initWidgets() {
        ll_no_net = getViewById(R.id.ll_no_net);
        ll_content = getViewById(R.id.ll_content);
        xc_id_no_net_button = getViewById(R.id.xc_id_no_net_button);
        if (xc_id_no_net_button != null) {
            xc_id_no_net_button.setOnClickListener(this);
        }
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
            int id = v.getId();
            if (id == R.id.xc_id_no_net_button) {
                onNetRefresh();
            }
    }

    public abstract void onNetRefresh();

    /**
     * 显示无网络的界面
     */
    public void showNoNetLayout() {

        if (ll_content != null) {
            UtilViewShow.setVisible(false, ll_content);
        }

        if (ll_no_net != null) {
            UtilViewShow.setVisible(true, ll_no_net);
        }
    }


    /**
     * 显示内容布局
     */
    public void showContentLayout() {
        if (ll_content != null) {
            UtilViewShow.setVisible(true, ll_content);
        }

        if (ll_no_net != null) {
            UtilViewShow.setVisible(false, ll_no_net);
        }
    }
}
