package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * @author YM on 2018/3/21 14:21
 * @description 药品到期系统消息提示
 */
public class XC_ChatSystemMedicineTimeLimitHolder {
    /**
     * 本地模拟系统消息提示视图
     */
    public TextView textview;

    public XC_ChatSystemMedicineTimeLimitHolder(View convertView) {
        this.textview = (TextView) convertView.findViewById(R.id.chat_system_medicine_time_limit);
    }
}
