package com.qlk.ymz.activity;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.InputType;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseExpandableListAdapter;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PF_SelectContactsAdapter;
import com.qlk.ymz.db.invited.XL_ContactsInvitedModel;
import com.qlk.ymz.db.invited.XL_ContactsModelDb;
import com.qlk.ymz.model.XL_RawContactModel;
import com.qlk.ymz.util.ChineseContactUtils;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.OPCircleProgressBar;
import com.qlk.ymz.view.PinnedHeaderExpandableListView;
import com.qlk.ymz.view.TF_InputCommonDialog;
import com.qlk.ymz.view.XCSlideBar_V2;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author xilinch on 2016/3/27.
 * @modifier xilinch 2016/3/27 11:45.
 * @description  邀请联系人 界面
 *
 * @modifier shuYanYi on 2016/04/12
 * @description  增加邀请联系人操作日志埋点；
 * @version v2.3
 *
 * @modifier zhangpengfei on 2016/04/18
 * @description  修改页面,逻辑
 * @version v2.3
 */
public class XL_ContactsInviteActivity extends XL_BaseContactInviteActivity {
    /** 头部布局 */
    XCTitleCommonLayout xc_id_model_titlebar;
    /*** 联系人数据*/
    public static ArrayList<XL_RawContactModel> CONTACTS_INFO = new ArrayList<>();
    /*** 每个字母在list中的位置*/
    private ArrayList<String> parentList;
    /**加载数据*/
    private OPCircleProgressBar pf_id_contacts_loading;
    /**没有联系人数据显示提示文字*/
    private TextView pf_id_contacts_empty;
    /*** 按字母分组的所有患者list*/
    private List<List<XL_RawContactModel>> childList;
    /*** 右侧字母滑条*/
    private XCSlideBar_V2 xc_id_fragment_search_slide_slidebar;
    /*** 屏幕中间弹出的字母*/
    private TextView xc_id_fragment_search_slide_dialog;
    /*** headView里的搜索栏*/
    private LinearLayout ll_patient_search;
    /*** headView里输入手机号*/
    private LinearLayout xc_id_invite_patients_ll;
    /*** 联系人可扩展列表*/
    private PinnedHeaderExpandableListView xc_id_fragment_search_slide_listview;
    /*** 联系人适配器*/
    private XL_ContactAdapter contactAdapter;
    /*** 邀请联系人输入电话号码对话框*/
    private TF_InputCommonDialog inviteContactInputDialog;
    /*** 没有联系人的时候提示语*/
    public static final String TIPS = "对不起,没有找到您的手机联系人,赶紧上大白寻找您的小伙伴吧!";
    /*** 更新邀请状态的广播*/
    public static final String ACTION_UPDATE_INVITED_STATUS = "com.qlk.ymz.ACTION_UPDATE_INVITED_STATUS";
    /*** 联系人ID*/
    public static final String CONTACT_INVITED = "CONTACT_INVITED";
    /*** 两次点击最短时间，用于实现双击回到第一条记录*/
    public static final int CLICK_INTERVAL_TIME_MILLSECOND = 500;
    /**
     * 更新邀请状态的广播，其他页面对联系人有邀请动作
     */
    private BroadcastReceiver updateInvitedBroadcast = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            HashMap<String, XL_ContactsInvitedModel> map = (HashMap<String, XL_ContactsInvitedModel>)intent.getExtras().get(CONTACT_INVITED);

            //更新当前内存 邀请状态
            if(!map.isEmpty()){
                Iterator<XL_ContactsInvitedModel> iterator = map.values().iterator();
                while (iterator.hasNext()){
                    XL_ContactsInvitedModel contactsInvitedModel = iterator.next();
                    int size = 0;
                    if(contactsInvitedModels != null){
                        size = contactsInvitedModels.size();
                    }
                    boolean has = false;
                    for(int i = 0 ; i < size && !has; i++){
                        XL_ContactsInvitedModel invitedModel = contactsInvitedModels.get(i);
                        if(!TextUtils.isEmpty(contactsInvitedModel.getContactId())
                                && !TextUtils.isEmpty(invitedModel.getContactId())
                                && contactsInvitedModel.getContactId().equals(invitedModel.getContactId())){
                            has = true;
                        }
                    }
                    if(!has){
                        contactsInvitedModels.add(contactsInvitedModel);
                    }
                }
                addInvitedStatusRawContacts();
                //更新数据显示
                if(contactAdapter != null){
                    contactAdapter.notifyDataSetChanged();
                }
            }

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xl_activity_invitepatient);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(XL_ContactsInviteActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-25,about：saveInfo,end
        //---------------------zhangpengfei 2.5版本取消这个接口埋点 2016-6-22 add-------------
//        requestContactsLog(1,null);//记录邀请联系人功能使用次数
        //---------------------zhangpengfei 2016-6-22 end-------------
        isGetFinishMsg = true; //每次都要进行请求短信模板
        requestContactsSMSModel();//获取一次短信模板

    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_ContactsInviteActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    protected void onRestart() {
        super.onRestart();
        if (IS_FROM_SMS && null != contactAdapter){
            //用来初始化当前页面数据
            clickedPhoneContactMap.clear();
            uiUpdateChoiceRawContact();
            if (null == contactsModelDb){
                contactsModelDb = XL_ContactsModelDb.getInstance(getApplicationContext());
            }
            contactsInvitedModels = contactsModelDb.queryStatusInvitied(UtilSP.getUserId());
            //model 2 map,提高执行性能
            addInvitedStatusRawContacts();
            contactAdapter.update(parentList, childList);
            IS_FROM_SMS = false;
        }
    }

    @Override
    public void initWidgets() {
        selectContactsAdapter = new PF_SelectContactsAdapter(this, mSelectContacts);
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "邀请联系人");
        xc_id_model_titlebar.setTitleLeft(R.mipmap.xc_d_chat_back, "");
        xc_id_model_titlebar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long nowMillisSecond = System.currentTimeMillis();
                long sub = clickTopTimeMillisSecond - nowMillisSecond;
                if (sub <= CLICK_INTERVAL_TIME_MILLSECOND && xc_id_fragment_search_slide_listview != null
                        && xc_id_fragment_search_slide_listview.getAdapter() != null
                        && xc_id_fragment_search_slide_listview.getAdapter().getCount() >= 0) {
                    xc_id_fragment_search_slide_listview.setSelectedGroup(0);

                }
                clickTopTimeMillisSecond = nowMillisSecond;
            }
        });
        xc_id_model_titlebar.getXc_id_titlebar_left_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });
        pf_id_contacts_loading = getViewById(R.id.pf_id_contacts_loading);
        pf_id_contacts_loading.setColorSchemeResources(R.color.c_gray_555555,R.color.c_blue_1988ea,R.color.c_orange_f56c0b);
        xc_id_tv_invite_name = getViewById(R.id.xc_id_tv_invite_name);
        pf_id_contacts_empty = getViewById(R.id.pf_id_contacts_empty);
        pf_id_invite_name_lv = getViewById(R.id.pf_id_invite_name_lv);
        xc_id_tv_invite = getViewById(R.id.xc_id_tv_invite);
        xc_id_ll_invite = getViewById(R.id.xc_id_ll_invite);
        xc_id_tv_invite.setOnClickListener(this);
        xc_id_ll_invite.setVisibility(View.GONE);
        pf_id_invite_name_lv.setAdapter(selectContactsAdapter);

        xc_id_fragment_search_slide_listview = getViewById(R.id.xc_id_fragment_search_slide_listview);
        final View mHeaderView = View.inflate(this, R.layout.xc_l_adapter_patient_letter_out_item, null);
        xc_id_fragment_search_slide_listview.setHeaderView(mHeaderView);//字母位置显示的布局
        View headView = getViewById(R.id.head_view);
        ll_patient_search = (LinearLayout) headView.findViewById(R.id.ll_patient_search);
        //默认先把搜索框隐藏,只有在有联系人数据的时候才显示
        ll_patient_search.setVisibility(View.GONE);
        xc_id_invite_patients_ll = (LinearLayout) headView.findViewById(R.id.xc_id_invite_patients_ll);
        xc_id_invite_patients_ll.setVisibility(View.GONE);
        xc_id_fragment_search_slide_listview.setPinnedableView(new PinnedHeaderExpandableListView.Pinnedable() {
            @Override
            public void setHeaderData(int groupPosition) {
                if (groupPosition < 0 || contactAdapter == null || groupPosition >= contactAdapter.getGroupCount())
                    return;
                String groupData = contactAdapter.getGroup(groupPosition);
                ((TextView) mHeaderView.findViewById(R.id.xc_id_fragment_search_letter_view)).setText(groupData);
            }
        });
        xc_id_fragment_search_slide_dialog = (TextView) findViewById(R.id.xc_id_fragment_search_slide_dialog);
        xc_id_fragment_search_slide_slidebar = (XCSlideBar_V2) findViewById(R.id.xc_id_fragment_search_slide_slidebar);
        xc_id_fragment_search_slide_slidebar.setTextView(xc_id_fragment_search_slide_dialog);
        contactAdapter = new XL_ContactAdapter(null,null);
        xc_id_fragment_search_slide_listview.setAdapter(contactAdapter);

        parentList = initA2Z();
        int size = parentList.size();
        childList = new ArrayList<>();
        for(int i = 0 ;i <  size ; i++){
            childList.add(new ArrayList<XL_RawContactModel>());
        }

        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_UPDATE_INVITED_STATUS);
        registerReceiver(updateInvitedBroadcast, filter);
        asyncQueryContacts();

    }

    /**
     * 异步查询联系人数据
     */
    private void asyncQueryContacts() {
        new AsyncTask<Void, Void, Void>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                //转动进度条
                pf_id_contacts_loading.setVisibility(View.VISIBLE);
            }

            @Override
            protected Void doInBackground(Void... params) {
                searchContracts();
                contactsModelDb = XL_ContactsModelDb.getInstance(getApplicationContext());
                contactsInvitedModels = contactsModelDb.queryStatusInvitied(UtilSP.getUserId());
                //model 2 map,提高执行性能
                addInvitedStatusRawContacts();
                return null;
            }


            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                //关闭转动进度条
                pf_id_contacts_loading.setVisibility(View.GONE);
                xc_id_invite_patients_ll.setVisibility(View.VISIBLE);
                if(contactAdapter != null){
                    contactAdapter.update(parentList, childList);
                    if (contactAdapter.getGroupCount() == 0){
                        ll_patient_search.setVisibility(View.GONE);
                        pf_id_contacts_empty.setVisibility(View.VISIBLE);
                    }else{
                        ll_patient_search.setVisibility(View.VISIBLE);
                        pf_id_contacts_empty.setVisibility(View.GONE);
                    }
                }
            }

        }.execute();
    }


    @Override
    public void listeners() {
        xc_id_invite_patients_ll.setOnClickListener(this);
        ll_patient_search.setOnClickListener(this);
        pf_id_invite_name_lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                XL_ContactsInvitedModel rawContactModel = mSelectContacts.get(position);
                if(clickedPhoneContactMap.containsKey(rawContactModel.getContactId())){
                    clickedPhoneContactMap.remove(rawContactModel.getContactId());
                    uiUpdateChoiceRawContact();
                    contactAdapter.update(parentList, childList);
                }
            }
        });
        // 字母滑动监听
        xc_id_fragment_search_slide_slidebar.setOnTouchingLetterChangedListener(new XCSlideBar_V2.OnTouchingLetterChangedListener() {

            @Override
            public void onTouchingLetterChanged(String s) {
                Integer position = contactAdapter.getPositionFromLetter(s);
                if (position >= 0 && position < contactAdapter.getGroupCount()) {

                    xc_id_fragment_search_slide_listview.setSelectedGroup(position);
                }
            }
        });
        xc_id_fragment_search_slide_listview.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                return true;
            }
        });
        xc_id_fragment_search_slide_listview.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                XL_RawContactModel rawContactModel = (XL_RawContactModel) parent.getExpandableListAdapter().getChild(groupPosition, childPosition);
                String contactId = rawContactModel.getId();
                if (TextUtils.isEmpty(contactId)) {
                    return false;
                }
                ImageView iv = (ImageView) v.findViewById(R.id.tv_invited_status);


                // 已经发送过短信邀请的用户（含多次），默认勾选对号（灰色），可以被再次邀请，如果钩选，则对号从灰色变为蓝色；

                handleInviteContact(rawContactModel, iv);
                return false;
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            //输入手机号
            case R.id.xc_id_invite_patients_ll:
                showInviteContactInputDialog();
                break;
            //搜索
            case R.id.ll_patient_search:
                CONTACTS_INFO.clear();
                CONTACTS_INFO.addAll(rawContactModels);
                myStartActivity(XL_ContactSearchActivity.class);
                break;
            //邀请
            case R.id.xc_id_tv_invite:
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(XL_ContactsInviteActivity.class,"2","128","xc_id_tv_invite","",false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                save2InvitedDb();
                requestContactsLog_batchInvite();//批量邀请患者操作日志埋点
                break;
        }
    }


    @Override
    public void onNetRefresh() {

    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(inviteContactInputDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
        if(updateInvitedBroadcast != null){
            unregisterReceiver(updateInvitedBroadcast);
        }
    }



    /**
     * 获取联系人
     *
     * @return 联系人列表
     */
    private List<XL_RawContactModel> searchContracts() {
        //存储联系人电话,key 联系人id, value 电话 格式 123;123.....
        Map<String, String> mapPhoneNumbers = new HashMap<>();
        ContentResolver cr = getContentResolver();
        // 查询contacts表的所有记录
        Cursor contactsCursor = null;
        // 如果记录不为空
        int size = 0;
        if (null != parentList){
            size = parentList.size();
        }
        try {
            contactsCursor = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    S_PROJECTIONS_PHONE, null, null, null);
            if (contactsCursor.getCount() > 0) {
                // 游标初始指向查询结果的第一条记录的上方，执行moveToNext函数会判断
                // 下一条记录是否存在，如果存在，指向下一条记录。否则，返回false。
                while (contactsCursor.moveToNext()) {
                    String contact_id =
                            contactsCursor.getString(contactsCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID));
                    String displayName =
                            contactsCursor.getString(contactsCursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    String phoneNumber =
                            contactsCursor.getString(contactsCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    //如果查出来的联系人是同一个,就只添加电话
                    if (mapPhoneNumbers.containsKey(contact_id)) {
                        phoneNumber = phoneNumber + ";" + mapPhoneNumbers.get(contact_id);
                        mapPhoneNumbers.put(contact_id, phoneNumber);
                        List<XL_RawContactModel.XL_PhoneContent> phoneContents = new ArrayList<>();
                        if (phoneNumber.indexOf(";") > 0) {
                            String[] phones = phoneNumber.split(";");
                            //格式化数据,放到list里
                            for (int i = 0; i < phones.length; i++) {
                                XL_RawContactModel.XL_PhoneContent phoneContent = new XL_RawContactModel.XL_PhoneContent();
                                phoneContent.setPhone(phones[i]);
                                phoneContent.setDisplay_name(displayName);
                                phoneContent.setContactId(contact_id);
                                phoneContents.add(phoneContent);
                            }
                            for (int i = 0; i < rawContactModels.size(); i++) {
                                if (contact_id.equals(rawContactModels.get(i).getId())) {
                                    rawContactModels.get(i).setPhoneContents(phoneContents);
                                    break;
                                }
                            }
                        }
                    }
                    //第一次查出联系人
                    else if (mapPhoneNumbers.containsKey(contact_id) == false) {
                        mapPhoneNumbers.put(contact_id, phoneNumber);
                        //联系人信息
                        XL_RawContactModel rawContactModel = new XL_RawContactModel();
                        rawContactModel.setId(contact_id);
                        rawContactModel.setDisplay_name(displayName);
                        String sort_key1 = ChineseContactUtils.getSortKey(displayName);
                        rawContactModel.setSort_key(sort_key1);

                        List<XL_RawContactModel.XL_PhoneContent> phoneContents = new ArrayList<>();
                        //电话号码信息
                        XL_RawContactModel.XL_PhoneContent phoneContent = new XL_RawContactModel.XL_PhoneContent();
                        phoneContent.setPhone(phoneNumber);
                        phoneContent.setDisplay_name(displayName);
                        phoneContent.setContactId(contact_id);
                        phoneContents.add(phoneContent);
                        rawContactModel.setPhoneContents(phoneContents);
                        rawContactModels.add(rawContactModel);
                        //将rawContactModel分组
                        String sort_key_index = rawContactModel.getSort_key_index();

                        boolean isParentContain = false;
                        for (int i = 0; i < size && !isParentContain; i++) {
                            String index_key = parentList.get(i);
                            if (sort_key_index.equals(index_key)) {
                                //包含该key
                                isParentContain = true;
                                childList.get(i).add(rawContactModel);
                                break;
                            }
                        }
                        if (!isParentContain) {
                            printi("异常的索引号");
                        }
                    }
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        } finally{
            if (null != contactsCursor){
                contactsCursor.close();
            }
        }
        return rawContactModels;
    }


    /**
     * 显示输入电话号码对话框
     */
    private void showInviteContactInputDialog(){
        if(inviteContactInputDialog == null){
            inviteContactInputDialog = new TF_InputCommonDialog(XL_ContactsInviteActivity.this,"","立即邀请","输入手机号","邀请患者,使用石榴云医吗?") {
                @Override
                public void confirmBtnForInput(EditText editText) {
                    String phone = editText.getText().toString();

                    //合法性判断，因为有短号等情况，暂不限制
                    if (UtilString.isBlank(phone)){
                        shortToast("手机号不能为空");
                        return ;
                    }
                    sendSMS(phone);
                    JSONArray contactsList = new JSONArray();
                    JSONObject contacts = new JSONObject();
                    try {
                        contacts.put("name", UtilString.f(phone));
                        contacts.put("phone", UtilString.f(phone));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    contactsList.put(contacts);
                    uploadContactsInfo(contactsList.toString());
                    //---------------------zhangpengfei 2.5版本取消这个接口埋点 2016-6-22 add-------------
//                requestContactsLog(2,phone);//邀请患者日志操作埋点
                    //---------------------zhangpengfei 2016-6-22 end-------------
                    if (inviteContactInputDialog != null) {

                        inviteContactInputDialog.dismiss();
                        uiUpdateChoiceRawContact();
                    }
                }
            };
            inviteContactInputDialog.setInputType(InputType.TYPE_CLASS_NUMBER);
            inviteContactInputDialog.setInputMaxLength(11);
        }
        inviteContactInputDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                uiUpdateChoiceRawContact();
            }
        });
        EditText editText = ((EditText)inviteContactInputDialog.findViewById(R.id.xl_id_dialog_invite_contact_et_phone));
        editText.setText("");
        inviteContactInputDialog.show();
        xc_id_ll_invite.setVisibility(View.GONE);
        //弹键盘，光标定位到输入手机号处
        UtilInputMethod.openInputMethod(editText,XL_ContactsInviteActivity.this);
    }


    /**
     * 联系人适配器
     */
    private class XL_ContactAdapter extends BaseExpandableListAdapter {

        private ArrayList<String> parentList;

        private List<List<XL_RawContactModel>> childList;

        public XL_ContactAdapter( ArrayList<String> parentList,List<List<XL_RawContactModel>> childList){
            if(parentList == null){
                this.parentList = new ArrayList<>();
            } else {
                this.parentList = parentList;
            }
            if(childList == null){
                this.childList = new ArrayList<>();
            }else {
                this.childList = childList;
            }
        }

        /**
         * 更新数据
         * @param parentList 组列表
         * @param childList 子列表
         */
        public void update(ArrayList<String> parentList,List<List<XL_RawContactModel>> childList){
            if(parentList == null){
                this.parentList = new ArrayList<>();
            } else {
                this.parentList.clear();
                this.parentList.addAll(parentList);
            }
            if(childList == null){
                this.childList = new ArrayList<>();
            }else {
                this.childList.clear();
                this.childList.addAll(childList);

            }
            //清除对应字母分组联系人数据为空的分组以及字母索引。
            logicRemoveSubListGroupZeroContact();
            notifyDataSetChanged();
            expanAll();
        }

        /**
         * 展开所有的组
         */
        public void expanAll(){
            int size = parentList.size();
            for(int i = 0 ; i < size ; i++){
                xc_id_fragment_search_slide_listview.expandGroup(i);
            }
        }

        /**
         * 清除对应字母分组联系人数据为空的分组以及字母索引
         */
        private void logicRemoveSubListGroupZeroContact(){
            int size_parent = 0;
            int size_child = 0;
            if(parentList != null){
                size_parent = parentList.size();
            }
            if(childList != null){
                size_child = childList.size();
            }
            if(size_child != size_parent){
                dShortToast("字母分组和 分组数量不一致!");
                return;
            }
            for(int i = 0 ; i < parentList.size() ; i++){
                List list = childList.get(i);
                if(UtilCollection.isBlank(list)){
                    //删除这个字母索引
                    parentList.remove(i);
                    //删除子list数据
                    childList.remove(i);
                    --i;

                }
            }
            if(xc_id_fragment_search_slide_slidebar != null){
                xc_id_fragment_search_slide_slidebar.setABC(parentList);
            }
        }

        /**
         * 获取字母对应的组位置索引
         * @param letter 字母#A-Z
         * @return 获取字母对应的组位置索引0-27
         */
        public int getPositionFromLetter(String letter){
            // parentList.indexOf(letter)  ?
            int index = 0;
            int size = parentList.size();
            for(int i = 0; i < size ; i ++){
                String groupLetter = parentList.get(i);
                if(letter.equals(groupLetter)){
                    index = i;
                    break;
                }
            }

            return index;
        }

        @Override
        public int getGroupCount() {
            if(parentList != null){

                return parentList.size();
            }
            return 0;
        }


        @Override
        public int getChildrenCount(int groupPosition) {
            if(childList != null){

                return childList.get(groupPosition).size();
            }
            return 0;
        }


        @Override
        public String getGroup(int groupPosition) {
            if(parentList != null){
                return parentList.get(groupPosition);
            }
            return null;
        }


        @Override
        public XL_RawContactModel getChild(int groupPosition, int childPosition) {
            return childList.get(groupPosition).get(childPosition);
        }


        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }


        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }


        @Override
        public boolean hasStableIds() {
            return true;
        }


        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
            GroupViewHolder groupViewHolder;
            if (convertView != null) {
                groupViewHolder = (GroupViewHolder) convertView.getTag();
            } else {
                convertView = LayoutInflater.from(XL_ContactsInviteActivity.this).inflate(R.layout.xc_l_adapter_patient_letter_out_item, null);
                groupViewHolder = new GroupViewHolder();
                groupViewHolder.xc_id_fragment_search_letter_view = (TextView) convertView.findViewById(R.id.xc_id_fragment_search_letter_view);
                convertView.setTag(groupViewHolder);
            }
            if (groupViewHolder.xc_id_fragment_search_letter_view != null) {
                groupViewHolder.xc_id_fragment_search_letter_view.setText(parentList.get(groupPosition));
            }
            return convertView;
        }


        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

            final ChildViewHolder childViewHolder;
            if(childPosition < childList.get(groupPosition).size()){

                final XL_RawContactModel bean = childList.get(groupPosition).get(childPosition);
                if (convertView != null) {
                    childViewHolder = (ChildViewHolder) convertView.getTag();
                } else {
                    childViewHolder = new ChildViewHolder();
                    convertView = LayoutInflater.from(XL_ContactsInviteActivity.this).inflate(R.layout.xl_item_contact, null);
                    childViewHolder.tv_name = (TextView) convertView.findViewById(R.id.tv_name);
                    childViewHolder.tv_invited_status = (ImageView) convertView.findViewById(R.id.tv_invited_status);
                    childViewHolder.tv_bottom_line =  convertView.findViewById(R.id.tv_bottom_line);
                    convertView.setTag(childViewHolder);
                }
                String displayName = bean.getDisplay_name();
                childViewHolder.tv_name.setText(displayName);

                String flag = bean.getFlag();
                String contactId = bean.getId();
                //是否选中，
                boolean isChicked = false;
                if(!TextUtils.isEmpty(contactId)){
                    isChicked = clickedPhoneContactMap.containsKey(contactId);
                }

                if(isChicked){
                    //选择了，显示选中图标
                    childViewHolder.tv_invited_status.setImageLevel(0);

                } else {

                    boolean isInvitedFlage = false;

                    if(XL_ContactsInvitedModel.STATUS_INVITIED_YES.equals(flag)){
                        isInvitedFlage = true;
                    } else {
                        isInvitedFlage = false;
                    }

                    if(isInvitedFlage){
                        //邀请过，则显示灰色图标
                        childViewHolder.tv_invited_status.setImageLevel(1);
                    } else {
                        //否则不显示图标
                        childViewHolder.tv_invited_status.setImageLevel(2);
                    }

                }

                if(isLastChild){
                    childViewHolder.tv_bottom_line.setVisibility(View.GONE);
                } else {
                    childViewHolder.tv_bottom_line.setVisibility(View.VISIBLE);
                }

            }
            return convertView;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }

        class GroupViewHolder {
            TextView xc_id_fragment_search_letter_view;
        }

        class ChildViewHolder {
            TextView tv_name;
            ImageView tv_invited_status;
            View tv_bottom_line;//底部分割线
        }
    }

    /**
     * 获取一个#A-Z的字符列表
     * @return 一个#A-Z的字符列表，一般字母索引定位
     */
    public  ArrayList<String> initA2Z() {
        ArrayList<String> parentList = new ArrayList<>();
        parentList.add("#");
        parentList.add("A");
        parentList.add("B");
        parentList.add("C");
        parentList.add("D");
        parentList.add("E");
        parentList.add("F");
        parentList.add("G");
        parentList.add("H");
        parentList.add("I");
        parentList.add("J");
        parentList.add("K");
        parentList.add("L");
        parentList.add("M");
        parentList.add("N");
        parentList.add("O");
        parentList.add("P");
        parentList.add("Q");
        parentList.add("R");
        parentList.add("S");
        parentList.add("T");
        parentList.add("U");
        parentList.add("V");
        parentList.add("W");
        parentList.add("X");
        parentList.add("Y");
        parentList.add("Z");
        return parentList;
    }
}
