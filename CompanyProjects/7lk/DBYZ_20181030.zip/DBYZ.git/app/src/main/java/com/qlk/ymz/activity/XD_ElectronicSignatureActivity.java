package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.gdca.sdk.casign.GdcaResultListener;
import com.gdca.sdk.casign.SdkManager;
import com.gdca.sdk.casign.model.GdcaCertModel;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.ElectronicSignatureHelper;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;


/**
 * Created by xiedong on 2017/7/31.
 * 电子签名页 包含签名的各种状态
 */

public class XD_ElectronicSignatureActivity extends DBActivity {
    public static final String FROM = "from";//从哪个页面来的标识
    public static final int FROM_BACKUP = 1;//从备案页面过来
    public static final int FROM_PHONE= 2;//从手机号页面过来
    /**
     * 标题栏
     */
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**
     * 医生真实姓名
     */
    private TextView tv_doctor_name;
    /**
     * 身份证
     */
    private TextView tv_doctor_id_card;
    /**
     * 手机号码
     */
    private TextView tv_phone_number;
    /**
     * 更换认证
     */
    private TextView tv_change;
    /**
     * 有限期
     */
    private TextView tv_indate;
    /**
     * 重新安装证书
     */
    private TextView tv_recertification;
    /**
     * 证书有效期
     */
    private String indate = "";
    /**
     * 证书是否更新了已通知备案页面刷新
     */
    private boolean isUpdate = false;
    /**
     * 来自哪个页面标识
     */
    private int fromCode = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_electronic_signatrue);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_ElectronicSignatureActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */

    //初始化数据和ui
    private void initData() {
        fromCode = getIntent().getIntExtra(FROM, 0);
        if (fromCode == 1) {//从备案页面过来
            ElectronicSignatureHelper.getInstance().clearCert();
            getCertInfo();//获取证书信息并刷新ui
        } else if(fromCode ==2 ){//从手机号页面过来
            xc_id_model_content.setVisibility(View.GONE);
            //申请证书
            ElectronicSignatureHelper.getInstance().createCert(this, new GdcaResultListener() {
                @Override
                public void onResultSuccess(String s) {
                    isUpdate = true;//之前未生成证书  返回备案页时需要更新
                    xc_id_model_content.setVisibility(View.VISIBLE);
                    getCertInfo();
                    shortToast("电子签名设置成功，您可以正常处方了");
                }

                @Override
                public void onResultError(int errode, String s) {
                    shortToast("证书生成失败");
                    myFinish();
                }
            });
        }
    }

    /**
     * 刷新Ui
     *
     * @param indate 有效期
     * @param code  是否有效code
     */
    private void initUI(String indate) {
        tv_doctor_name.setText(UtilSP.getUserName());
        tv_doctor_id_card.setText(emcryptString(UtilSP.getUseridCardNum(),4,4));
        String phone = UtilSP.getLastCertificationPhone();
        tv_phone_number.setText(emcryptString(phone,3,3));
        if(indate.contains("日")){
            indate = indate.substring(0, indate.indexOf("日")+1);
        }
        tv_indate.setText(indate + "之前有效");

    }

    @Override
    public void onNetRefresh() {
    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "电子签名");
        xc_id_model_titlebar.setTitleLeft(true, "");

        tv_doctor_name = getViewById(R.id.tv_doctor_name);
        tv_doctor_id_card = getViewById(R.id.tv_doctor_id_card);
        tv_phone_number = getViewById(R.id.tv_phone_number);
        tv_change = getViewById(R.id.tv_change);
        tv_indate = getViewById(R.id.tv_indate);
        tv_recertification = getViewById(R.id.tv_recertification);
    }

    @Override
    public void listeners() {
        xc_id_model_titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        //更换手机号码监听
        tv_change.setOnClickListener(this);
        //重新安装证书监听
        tv_recertification.setOnClickListener(this);
    }


    @Override
    public void onBackPressed() {
        if (isUpdate) {
            setResult(RESULT_OK);
        }
        super.onBackPressed();
    }

    /**
     * 获取证书信息并刷新ui
     */
    private void getCertInfo() {
        ElectronicSignatureHelper.getInstance().getCertInfo(true,this, new
                ElectronicSignatureHelper.CertInfoListener() {
            @Override
            public void onCertInfo(GdcaCertModel gdcaCertModel) {
                initUI(gdcaCertModel.getCertNotAfter());//刷新ui
            }

            @Override
            public void onFail(String s,int code) {
                if(ElectronicSignatureHelper.OTHER_ERROR ==code){
                    shortToast(s);
                }
            }
        });
    }

    /**
     * 字符串星号处理
     * @param s
     * @param prevIndex
     * @param afterIndex
     * @return
     */
    private String emcryptString(String s, int prevIndex, int afterIndex) {
        if (!TextUtils.isEmpty(s)) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (i >= prevIndex && i <= s.length() - afterIndex-1) {
                    sb.append('*');
                } else {
                    sb.append(c);
                }
            }
            return sb.toString();
        } else {
            return "";
        }

    }
}
