package com.qlk.ymz.maintab;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.PF_WaitRegisterContactsActivity;
import com.qlk.ymz.activity.XC_ChatDetailActivity;
import com.qlk.ymz.activity.YR_NewPatientActivity;
import com.qlk.ymz.activity.YR_PatientGroupManagerActivity;
import com.qlk.ymz.activity.YR_PatientSearchActivity;
import com.qlk.ymz.adapter.YR_PatientGroupAdapter;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.parse.Parse2PatientBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.PinnedHeaderExpandableListView;
import com.qlk.ymz.view.XCSlideBar_V2;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YRExpandableListRefreshLayout;
import com.xiaocoder.android.fw.general.dialog.XCSystemVDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonParse;
import com.xiaocoder.android.fw.general.util.UtilMd5;
import com.xiaocoder.android.fw.general.util.UtilNet;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;

import org.apache.http.Header;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 患者列表首页
 * @anthor xiaocoder 2015/6/19
 * @version 1.0.0
 *
 * @author 崔毅然 2016-1-7
 * @version 2.0.0
 */
public class YR_PatientFragment extends DBFragment {
    private XCTitleCommonLayout titleCommonFragment;
    /** 从接口获得的字母list（有患者的字母） */
    private ArrayList<String> parentList = new ArrayList<>();
    /** 按字母分组的所有患者list */
    private List<List<XC_ChatModel>> childList = new ArrayList<>();

    /** 右侧字母列表的滑条 */
    private XCSlideBar_V2 xc_id_fragment_search_slide_slidebar;
    /** 屏幕中间弹出的显示字母的dialog */
    private TextView xc_id_fragment_search_slide_dialog;
    /** 患者可扩展列表刷新 */
    private YRExpandableListRefreshLayout re_fragment_search_slide_listview;
    /** 患者可扩展列表 */
    private PinnedHeaderExpandableListView xc_id_fragment_search_slide_listview;
    /** 添加患者的适配器 */
    private YR_PatientGroupAdapter patientGroupAdapter;

    /** 无网络显示 */
    private LinearLayout xc_id_model_no_net_main;
    /** 无网络的提示栏
     * V2.5 add  患者信息修改，刷新患者列表广播
     * */
    public NoNetBroadCastReceiver noNetBroadCastReceiver;
    /** V2.5  患者信息修改,广播ACTION */
    public static final String REFRESH_ACTION = "refresh_action";
    /** 无患者时候的背景图 */
    private  View include_data_zero_view;
    /** headView里的搜索栏 */
    private LinearLayout ll_patient_search;
    /** headView里的手机联系人 */
    private LinearLayout ll_phone_contact;
    /** headView里的新的患者 */
    private LinearLayout ll_new_patient;
    /** headView里的新患者数量 */
    private TextView tv_new_patient_num;
    /** headView里的患者分组 */
    private LinearLayout ll_patient_group;

    /** 特别关注标题名 */
    public static String myAttention = "我的关注";
    /**
     * 设置特别关注状态
     * 防止同时发送多个关注请求，导致的异步数据异常
     * */
    public static boolean isSettingAttention = false;
    /** 等待对话框 */
    private Dialog loadingDialog;

    /**
     * 判断智能标签是否能点击 true能点击
     * （同时不能点击其他按钮）
     * */
    public static boolean signCanClick = true;


    @Override
    public boolean isBodyFragment() {
        return true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return init(inflater, R.layout.xc_l_fragment_patient);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        mContainer.postDelayed(new Runnable() {
            @Override
            public void run() {
                requestPatientABC(true);
            }
        }, 200);
    }

    @Override
    public void initWidgets() {
        titleCommonFragment = getViewById(R.id.xc_id_model_titlebar);
        titleCommonFragment.setTitleLeft(false, "");
        titleCommonFragment.setTitleRight(true, R.mipmap.pf_d_add);
        titleCommonFragment.setTitleCenter(true,"我的患者");

        loadingDialog = new XCSystemVDialog(getActivity());

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(REFRESH_ACTION);
        getActivity().registerReceiver(noNetBroadCastReceiver = new NoNetBroadCastReceiver(), intentFilter);

        xc_id_model_no_net_main = (LinearLayout) mContainer.findViewById(R.id.xc_id_model_no_net_main);
        ll_patient_search = (LinearLayout) mContainer.findViewById(R.id.ll_patient_search);
        //检查网络是否连接
        xc_id_model_no_net_main.setVisibility(UtilNet.isNetworkAvailable(getActivity()) ? View.GONE : View.VISIBLE);
        //初始化右侧字母列表bar和字母提示dialog
        xc_id_fragment_search_slide_dialog = (TextView) mContainer.findViewById(R.id.xc_id_fragment_search_slide_dialog);
        xc_id_fragment_search_slide_slidebar = (XCSlideBar_V2) mContainer.findViewById(R.id.xc_id_fragment_search_slide_slidebar);
        xc_id_fragment_search_slide_slidebar.setTextView(xc_id_fragment_search_slide_dialog);
        //初始化患者列表
        initListView();
        //初始化无患者时候的背景图
        setNoPatientView();
    }

    /** 初始化患者列表 */
    public void initListView(){
        re_fragment_search_slide_listview = (YRExpandableListRefreshLayout) mContainer.findViewById(R.id.re_fragment_search_slide_listview);
        xc_id_fragment_search_slide_listview = (PinnedHeaderExpandableListView) re_fragment_search_slide_listview.getListView();
        xc_id_fragment_search_slide_listview.setDividerHeight(UtilScreen.dip2px(getActivity(),5));
        xc_id_fragment_search_slide_listview.setDivider(new ColorDrawable(getContext().getResources().getColor(R.color.c_black_000000)));
        //给患者列表添加headerView
        View headView = LayoutInflater.from(getActivity()).inflate(R.layout.xc_l_view_patient_headview, null);
        tv_new_patient_num = (TextView) headView.findViewById(R.id.tv_new_patient_num);
        ll_phone_contact = (LinearLayout) headView.findViewById(R.id.ll_phone_contact);
        ll_new_patient = (LinearLayout) headView.findViewById(R.id.ll_new_patient);
        ll_patient_group = (LinearLayout) headView.findViewById(R.id.ll_patient_group);
        xc_id_fragment_search_slide_listview.addHeaderView(headView);
        //添加悬浮view的布局
        final View mHeaderView = View.inflate(getActivity(), R.layout.xc_l_adapter_patient_letter_out_item, null);
        xc_id_fragment_search_slide_listview.setHeaderView(mHeaderView);
        int itemWidth = UtilScreen.getScreenWidthPx(getContext()) - UtilScreen.dip2px(getContext(), 20);
        patientGroupAdapter = new YR_PatientGroupAdapter(childList,parentList,itemWidth, getActivity());
        xc_id_fragment_search_slide_listview.setAdapter(patientGroupAdapter);
        //ListView中有headerView
        xc_id_fragment_search_slide_listview.setHasHeaderView(true);
        //给悬浮字母View添加数据
        xc_id_fragment_search_slide_listview.setPinnedableView(new PinnedHeaderExpandableListView.Pinnedable() {
            @Override
            public void setHeaderData(int groupPosition) {
                if (groupPosition < 0)
                    return;
                String groupData = patientGroupAdapter.getGroupDate().get(groupPosition);
                TextView textView = (TextView) mHeaderView.findViewById(R.id.xc_id_fragment_search_letter_view);
                textView.setText(groupData);
            }
        });

        re_fragment_search_slide_listview.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {
                return true;
            }

            @Override
            public boolean canLoad() {
                return false;
            }

            @Override
            public void refresh(View view, int request_page) {
                requestPatientABC(false);
            }

            @Override
            public void load(View view, int request_page) {
            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();

        if (!isHidden()) {
            // 从新患者页面返回时，新患者气泡数刷新，一般为0，隐藏
            setNewPatientCount();
        }
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(YR_PatientFragment.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden){
            UtilSP.setDelFrom(JS_MainActivity.TAB_PATIENT);
        }
    }

    /**
     * 获取患者abc列表
     * 为了避免低性能手机在请求的时候产生卡顿现象，做了减少请求次数的优化
     * 目前只有四种情况需要请求患者列表：1、医生登陆的时候；2、patientFragment创建的时候；
     *                                   3、医生添加新患者，向服务器发送push消息的时候；4、医生主动修改患者备注名后。
     * @param isProgress 是否显示加载进度条（true 显示；false 不显示）
     */
    public void requestPatientABC(boolean isProgress) {
        if (isProgress){
            if (loadingDialog == null) {
                loadingDialog = new XCSystemVDialog(getActivity());
            }
            loadingDialog.show();
        }
        XCHttpAsyn.postAsyn(false, getActivity(), AppConfig.getHostUrl(AppConfig.patient_my), new RequestParams(), new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, final byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean != null) {
                        refreshPatientList(result_bean, arg2);
                    }
                } else {
                    //请求数据为空时，获取sp中存储的患者列表String，并进行json解析，刷新患者列表
                    refreshPatientList(XCJsonParse.getJsonParseData(UtilSP.getContactsList()), null);
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                //请求失败时，获取sp中存储的患者列表String，并进行json解析，刷新患者列表
                refreshPatientList( XCJsonParse.getJsonParseData(UtilSP.getContactsList()), null);
                if (loadingDialog != null && loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }
            }


            @Override
            public void onFinish() {
                super.onFinish();
                //create by songxin date:2016-10-11 about:bug begin
                if (null != result_bean && getActivity() != null) {
                    GeneralReqExceptionProcess.checkCode(getActivity(),
                            getCode(),
                            getMsg());
                }
                //create by songxin date:2016-10-11 about:bug end
                re_fragment_search_slide_listview.completeRefresh(result_boolean, false);
            }
        });
    }

    /**
     * 将接口请求到的数组流转成字符转
     * @param arg2 byte数组流
     *  */
    public String saveContacts2Local(byte[] arg2) {
        try {
            return  new String(arg2, "utf-8");
        } catch (Exception e) {
            return new String(arg2);
        }
    }

    /** 更新新患者气泡数 */
    public void setNewPatientCount() {
        if (getActivity()!= null) {
            ( (JS_MainActivity)getActivity()).setBubbleNum(tv_new_patient_num,UtilSP.getNewPatientNum());
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()){
            case R.id.xc_id_titlebar_right_layout:  // V2.7改成打开下拉菜单（包括二维码邀请和群发消息）
                UtilNativeHtml5.toJumpQRcode(getActivity(), "0");
//                patientMenuPopupWindow.showAtLocation(iv_head_right_menu, Gravity.BOTTOM, 0, 0);
                break;
            case R.id.ll_new_patient://跳转到新患者页面
                myStartActivity(YR_NewPatientActivity.class);
                break;
            case R.id.ll_patient_group://跳转到分组管理页
                myStartActivity(YR_PatientGroupManagerActivity.class);
                break;
            case R.id.ll_patient_search://跳转到患者搜索页
                myStartActivity(YR_PatientSearchActivity.class);
                break;
            case R.id.ll_phone_contact://跳转到重新邀请手机联系人页
                myStartActivity(PF_WaitRegisterContactsActivity.class);
                break;
            case R.id.xc_id_model_no_net_main:
                //判断手机系统的版本  即API大于10 就是3.0或以上版本
                if(android.os.Build.VERSION.SDK_INT > 10 ){
                    //3.0以上打开设置界面，也可以直接用ACTION_WIRELESS_SETTINGS打开到wifi界面
                    startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
                } else {
                    startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS));
                }
                break;
        }
    }

    @Override
    public void listeners() {
        titleCommonFragment.getXc_id_titlebar_right_layout().setOnClickListener(this);

        ll_new_patient.setOnClickListener(this);
        ll_phone_contact.setOnClickListener(this);
        ll_patient_group.setOnClickListener(this);
        ll_patient_search.setOnClickListener(this);
        xc_id_model_no_net_main.setOnClickListener(this);
        // 右侧字母列表的滑动监听
        xc_id_fragment_search_slide_slidebar.setOnTouchingLetterChangedListener(new XCSlideBar_V2.OnTouchingLetterChangedListener() {

            @Override
            public void onTouchingLetterChanged(String s) {
                //获得手指按压的字母位置，患者列表滑动到相应字母位置
                Integer position = patientGroupAdapter.getPositionFromLetter(s);
                if (position != null) {
                    xc_id_fragment_search_slide_listview.setSelection(position + 1); // 由于有headView所以+1；2.5版本添加了"我的关注"+1
                }
            }
        });
        // 返回true，不会收缩(点击效果还在)，即在调用allExpand后， 再设置该监听，即可达到全部展示不会
        // 收缩的效果
        xc_id_fragment_search_slide_listview.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                return true;
            }
        });

        patientGroupAdapter.setOnClickItemBtn(new YR_PatientGroupAdapter.OnClickItemBtn() {
            @Override
            public void onClickAttention(XC_ChatModel patientBean, int groupPosition, int childPosition) {
                //设置特别关注时，先设置异步状态，防止设置和刷新列表请求同时运行
                if (!isSettingAttention) {
                    isSettingAttention = true;
                    requestPatientAttention(patientBean, groupPosition, childPosition);
                }
            }

            @Override
            public void onClickSign(View view, String content) {
                if (signCanClick) {
                    //智能标签解释dialog监听
                    int[] location = new int[2];
                    view.getLocationOnScreen(location);
                    if (!TextUtils.isEmpty(content)) {
                        ToJumpHelp.toJumpSignContentAcitivity(getActivity(), location, content, view.getMeasuredWidth(), view.getMeasuredHeight());
                        getBaseActivity().overridePendingTransition(R.anim.pop_up, R.anim.pop_down);
                    }
                }
            }
        });

    }

    /**
     * 刷新患者列表,无数据显示遮罩
     * @param result_bean 患者的整个报文数据
     * @param arg2 接口请求获得的患者列表byte数组
     * */
    public void refreshPatientList(XCJsonBean result_bean, final byte[] arg2) {
        Parse2PatientBean.parseort(parentList, childList, result_bean);
        updateParentAndChild(arg2);
    }

    /**
     * 更新parentList和childList
     * @param arg2 接口请求获得的患者列表byte数组
     * */
    public void updateParentAndChild(final byte[] arg2 ) {
        int patientNum = 0;//患者总数，所有字母下的患者数之和

        //遍历患者列表，获得患者总数
        for (List<XC_ChatModel> list: childList) {
            patientNum += list.size();
        }

        //如果没有患者，显示无患者默认图
        if (patientNum>0) {
            include_data_zero_view.setVisibility(View.GONE);
        } else {
            include_data_zero_view.setVisibility(View.VISIBLE);
        }
        titleCommonFragment.getXc_id_titlebar_center_textview().setVisibility(View.VISIBLE);
//        titleCommonFragment.getXc_id_titlebar_center_textview().setText(Html.fromHtml("我的患者<small>(" + patientNum +")</small>"));
        titleCommonFragment.getXc_id_titlebar_center_textview().setText(Html.fromHtml("我的患者(" + patientNum +"人)"));
        // notifyDataSetChanged和adapter数据修改必须放在同一线程中（主线程），如果多线程处理，会发生异常：
        // Java.lang.IllegalStateException: The content of the adapter has changed but ListView did not receive a notification
        //存储患者总数，首页要用
        UtilSP.setPatientSum(String.valueOf(patientNum));
        if (parentList.size() > 0 && myAttention.equals(parentList.get(0))) {
            ArrayList<String> campList = new ArrayList<>();
            campList.addAll(parentList);
            campList.set(0, "");
            xc_id_fragment_search_slide_slidebar.setABC(campList);
        } else {
            xc_id_fragment_search_slide_slidebar.setABC(parentList);
        }
        patientGroupAdapter.updateABCPosition();
        patientGroupAdapter.notifyDataSetChanged();
        allExpandList();

        if (loadingDialog != null && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }

        // 解决主线程卡死问题。开子线程，更新数据库，插入患者
        if (arg2 != null) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    updatePatientDB(arg2);
                }
            }).start();
        }

    }
    /**
     * 将接口请求的患者列表数据存入数据库，如果DB中已经有患者列表，则进行数据比较，更新修改的数据
     * @param arg2 网络请求获得的患者列表数据的byte数组
     * */
    public void updatePatientDB(byte[] arg2) {
        //如果为null,表示是缓存中取sp，否则是接口取；只有从接口中取得数据才进行字符串匹配，进行查库操作
        //将接口请求的数据进行MD5加密
        String byteStr = saveContacts2Local(arg2);
        String newJson = UtilMd5.MD5Encode(byteStr);
        //从sp中获得已经存储的加密字符串
        String oldJson = GlobalConfigSP.getMD5PatientListJson();
        //比对上次患者列表json和新获得的患者列表json数据,不相等进行下面操作
        if (!newJson.equals(oldJson)) {
            //将字符串存储到sp中
            UtilSP.putContactsList(byteStr);
            //将新的加密字符串存储到sp中
            GlobalConfigSP.putMD5PatientListJson(newJson);
            //将数据插入患者db
            ArrayList<XC_ChatModel> allPatientList = new ArrayList<>();
            for (List<XC_ChatModel> c : childList) {
                allPatientList.addAll(c);
            }
            //UPDATE BY CYR on 2017-4-17 修改数据库插入逻辑
            // 1、刷新或插入新患者时，走insertAllChatInfo
            // 2、批量更新价格时，走updatePatientPayAmount2
            if ("0".equals(((JS_MainActivity) getActivity()).patientListRefreshType)) {
                JS_ChatListDB.getInstance(getActivity(), UtilSP.getUserId())
                        .insertAllChatInfo(allPatientList);

                if ( ((JS_MainActivity) getActivity()).handler!= null) {
                    ((JS_MainActivity) getActivity()).handler.sendEmptyMessage(1);
                }

            } else {
                JS_ChatListDB.getInstance(getActivity(), UtilSP.getUserId())
                        .updatePatientPayAmount2(allPatientList);
                ((JS_MainActivity) getActivity()).patientListRefreshType = "0";
            }
            //更新聊天详情数据库的患者信息
            //只找出新添加的患者进行数据更新，代码逻辑为判断此次json和上次json的不同，选择不同的数据ID进行更新，代码未完成

            UserPatient userPatient = null;
            for (XC_ChatModel chatModel : allPatientList){
                boolean isUpdate = false;//数据库是否被更改过了
                String tableName = UtilSP.getIMDetailDbName(UtilSP.getUserId(), chatModel.getUserPatient().getPatientId());
                if (XCChatModelDb.map.containsKey(tableName)){
                    XCChatModelDb chat_dao = XCChatModelDb.getInstance(getContext(),tableName);
                    isUpdate = chat_dao.updateMsgHisttory(chatModel);
                }
                if (isUpdate && XC_ChatDetailActivity.recoder_which_patient_id.equals(chatModel.getUserPatient().getPatientId())){
                    userPatient = chatModel.getUserPatient();
                    sendUpdatePatientMsgReceiver(userPatient);
                }
            }
        }
    }
    /* 发送更新患者的通知 */
    private void sendUpdatePatientMsgReceiver(UserPatient userPatient){
        Intent model_intent = new Intent();
        model_intent.setAction(XC_ChatDetailActivity.UpdatePatientReceiver.UPDATE_PATIENT_ACTION);
        model_intent.putExtra(XC_ChatDetailActivity.UpdatePatientReceiver.UPDATE_PATIENT, userPatient);
        getContext().sendBroadcast(model_intent);
    }

    /** 初始化abc患者列表全部展开 */
    public void allExpandList() {
        int count = patientGroupAdapter.getGroupCount();
        for (int i = 0; i < count; i++) {
            if (!xc_id_fragment_search_slide_listview.isGroupExpanded(i)) {
                xc_id_fragment_search_slide_listview.expandGroup(i);
            }
        }
    }

    /**
     * 1、监听网络状态，无网络显示提示view
     * 2、监听备注页患者信息变化，本地刷新患者列表
     */
    private class NoNetBroadCastReceiver extends BroadcastReceiver {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (REFRESH_ACTION.equals(action)) {
                requestPatientABC(false);
            }
        }
    }

    /**
     * 2.5V
     * 设置/取消患者特别关注，患者位置重新放置的方法
     * 策略：1、列表中的患者设置特别关注后，从患者列表中去除，放入特别关注列表，并按首字母排序
     *       2、如果没有特别关注列表，需添加
     *       3、特殊关注的患者取消关注后，从特别关注列表中去除，放入患者列表相应的字母中，按createTime（医生添加患者时间）倒序排列（和服务器排序统一）
     * 注：因手机性能考虑，不支持姓名全排序
     *
     *   @param patientBean 设置或取消设置选中的患者bean
     *   @param groupPosition 选中患者的字母位置，仅设置关注时有用
     *   @param groupPosition 选中患者的在对应字母的患者列表中的位置
     * */
    public void refreshPatientAttention(XC_ChatModel patientBean, int groupPosition,int childPosition){
        if ("true".equals(patientBean.getUserPatient().getIsAttention())) { //从特别关注列表中去掉，放入字母列表中(没有小七助手)
            patientBean.getUserPatient().setIsAttention("false");
            //获得特别关注列表
            List<XC_ChatModel> attentionList = childList.get(0);
            //从特别关注列表中去掉
            if (attentionList.size() == 1) {
                childList.remove(0);
                parentList.remove(0);
            } else {
                for (XC_ChatModel bean : attentionList) {
                    if (!TextUtils.isEmpty(bean.getUserPatient().getPatientId()) && bean.getUserPatient().getPatientId().equals(patientBean.getUserPatient().getPatientId())) {
                        attentionList.remove(bean);
                        break;
                    }
                }
            }

            //名称首字母
            String word = patientBean.getUserPatient().getPatientLetter();
            // 判断放置在哪个字母位置，两种情况，字母和"#","#"号放在字母后面
            // 比较首字母ASCII大小，因为"#"==35 ,"A" == 65 ；排序后"#"要在"A"的后面，所以此处"#" = 35 + 100,比较的时候就可以放在A后面
            char w = word.charAt(0);
            int wAscii = (int) w;
            if ("#".equals(word)) {
                wAscii = wAscii + 100;//为了方便排序
            }
            if (parentList.size() == 0 || (parentList.size() == 1 && myAttention.equals(parentList.get(0)))) {//没有患者列表
                setListDate(patientBean, -1, word);
            } else {
                for (int i = 0; i < parentList.size(); i++) {
                    String str = parentList.get(i);
                    if (myAttention.equals(str)) {
                        continue;
                    }
                    char c = str.charAt(0);
                    int cAscii = (int) c;
                    if ("#".equals(str)) {
                        cAscii = cAscii + 100;//为了方便排序
                    }
                    //比较策略：
                    // 如果cAscii < wAscii
                    // 如果cAscii = wAscii
                    // 如果cAscii > wAscii
                    if (i == (parentList.size() - 1) && cAscii < wAscii) {//当列表最后一个字母也小于待插入的患者的首字母时，特殊处理
                        setListDate(patientBean, -1, word);
                        break;
                    }
                    if (cAscii == wAscii) {//如果字母中有待插入的患者首字母
                        List<XC_ChatModel> wList = childList.get(i);
                        wList.add(0, patientBean);
                        Collections.sort(wList, new SortCreateTime());
                        childList.set(i, wList);
                        break;
                    } else if (cAscii > wAscii) {//列表中无待插入的患者首字母，且待插入字母需放在列表中间
                        setListDate(patientBean, i, word);
                        break;
                    }
                }
            }
        } else {// 从字母列表中去掉，放入特别关注列表中
            patientBean.getUserPatient().setIsAttention("true");
            // 从字母列表中去掉
            List<XC_ChatModel> campList = childList.get(groupPosition);
            if (campList.size() == 1) {//如果对应字母的患者列表只有一个患者，删除该列表和字母
                childList.remove(groupPosition);
                parentList.remove(groupPosition);
            } else {//如果对应字母的患者列表有多个患者，从当前患者列表中去除该患者
                campList.remove(childPosition);
            }
            // 放入特别关注列表中
            if (parentList.size() > 0 && myAttention.equals(parentList.get(0))) {
                List<XC_ChatModel> attentionList = childList.get(0);
                attentionList.add(patientBean);
                Collections.sort(attentionList, Parse2PatientBean.getSortChineseName());
            } else {
                setListDate(patientBean, 0, myAttention);
            }
        }
        //更新患者列表相关数据
        //重置页面患者列表和右侧字母列表
        if (myAttention.equals(parentList.get(0))) {
            ArrayList<String> campList = new ArrayList<>();
            campList.addAll(parentList);
            campList.set(0, "");
            xc_id_fragment_search_slide_slidebar.setABC(campList);
        } else {
            xc_id_fragment_search_slide_slidebar.setABC(parentList);
        }
        patientGroupAdapter.updateABCPosition();
        patientGroupAdapter.notifyDataSetChanged();
        allExpandList();
        //关注请求处理完后，将状态充值
        isSettingAttention = false;


    }

    /**
     * 设置/取消特别关注时，患者位置调整时，重置患者列表
     * @param patientBean 设置或取消设置选中的患者bean
     * @param  i 要插入的位置
     * @param word 插入的首字母
     * */
    public void setListDate(XC_ChatModel patientBean, int i, String word) {
        List<XC_ChatModel> attentionList = new ArrayList<>();
        attentionList.add(patientBean);
        Collections.sort(attentionList, new SortCreateTime());
        if (i == -1) {
            childList.add(attentionList);
            parentList.add(word);
        } else {
            childList.add(i, attentionList);
            parentList.add(i, word);
        }
    }

    /**
     * 添加/取消特别关注
     * 添加或取消特别关注患者为同一接口，原状态为非关注变为关注，已关注的变为非关注
     *   @param patientBean 设置或取消设置选中的患者bean
     *   @param groupPosition 选中患者的字母位置，仅设置关注时有用
     *   @param groupPosition 选中患者的在对应字母的患者列表中的位置
     */
    public void requestPatientAttention(final XC_ChatModel patientBean, final int groupPosition, final int childPosition) {
        RequestParams params = new RequestParams();
        params.put("patientId", patientBean.getUserPatient().getPatientId());
        XCHttpAsyn.postAsyn(getActivity(), AppConfig.getHostUrl(AppConfig.patient_spec), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, final byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    refreshPatientAttention(patientBean,groupPosition,childPosition);
                }
            }

        });
    }

    // 根据时间排序
    class SortCreateTime implements Comparator<XC_ChatModel> {
        Collator cmp = Collator.getInstance(java.util.Locale.CHINA);

        @Override
        public int compare(XC_ChatModel o1, XC_ChatModel o2) {
            // 比较创建时间，创建时间早的放后面
            if (cmp.compare(o1.getUserPatient().getCreateTime(), o2.getUserPatient().getCreateTime()) > 0) {
                return 1;
            } else {
                return -1;
            }
        }

    }

    /** 初始化无患者时候的背景图 */
    public void setNoPatientView() {
        include_data_zero_view = mContainer.findViewById(R.id.include_data_zero_view);
        include_data_zero_view.setVisibility(View.GONE);

        TextView xc_id_no_net_button = (TextView) include_data_zero_view.findViewById(R.id.xc_id_data_zero_hint_textview);
        xc_id_no_net_button.setText(Html.fromHtml("您还没有新增患者，快让患者扫描您的<font color='#e2231a'>二维码</font>吧!"));
        xc_id_no_net_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UtilNativeHtml5.toJumpQRcode(getActivity(), "0");
            }
        });
        ((ImageView) include_data_zero_view.findViewById(R.id.xc_id_data_zero_imageview)).setImageResource(R.mipmap.js_d_icon_no_data);
    }

    @Override
    public void onDestroy() {
        if(loadingDialog != null && loadingDialog.isShowing()){
            loadingDialog.dismiss();
        }
        super.onDestroy();
    }


    /**
     * MainActivity广播调用
     * 修改单个患者图文咨询价格，更新数据库，更新患者列表
     * add by cyr on  2017-4-12
   *
     * @param chatModel 修改了价格的患者bean
     * */
    public void updateConsultCastRefreshPatientList(XC_ChatModel chatModel) {
        if (chatModel == null || childList == null) {
            return;
        }
        String patientId = chatModel.getUserPatient().getPatientId();
        if ("0".equals(patientId)) {
            return;
        }
        List<XC_ChatModel> list;
        XC_ChatModel bean;
        int flag = 0 ;
        for (int i = 0; i < childList.size(); i++) {
            list = childList.get(i);
            for (int j = 0; j < list.size(); j++) {
                bean = list.get(j);
                if (bean.getUserPatient().getPatientId().equals(patientId)) {
                    bean.getUserPatient().setPayAmount(chatModel.getUserPatient().getPayAmount());
                    //update by cyr on 2017-6-23 因患者信息修改更新列表，添加 start
                    bean.getUserPatient().setPatientAge(chatModel.getUserPatient().getPatientAge());
                    bean.getUserPatient().setPatientMemoName(chatModel.getUserPatient().getPatientMemoName());
                    bean.getUserPatient().setPatientGender(chatModel.getUserPatient().getPatientGender());
                    bean.getUserPatient().setPatientName(chatModel.getUserPatient().getPatientName());
                    //update by cyr on 2017-6-23 因患者信息修改更新列表，添加 end
                    flag = 1;
                    break;
                }
            }
            if (flag == 1) {
                break;
            }
        }
        patientGroupAdapter.notifyDataSetChanged();
    }

    @Override
    public void onPause() {
        super.onPause();

        signCanClick = false;
    }

    @Override
    public void onResume() {
        super.onResume();

        signCanClick = true;
    }
}
