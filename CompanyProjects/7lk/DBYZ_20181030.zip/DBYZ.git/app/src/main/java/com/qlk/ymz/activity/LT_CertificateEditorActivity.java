
package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.fragment.XCCameraPhotoFragment;

import java.io.File;
/**
 * @author 李涛
 * @description 互联网医院备案   职称证书页面
 * @Date 2017/7/18.
 */
public class LT_CertificateEditorActivity extends DBActivity implements XCCameraPhotoFragment.OnCaremaSelectedFileListener {

    /**
     * 证书上传
     */
    private ImageView lt_certificate_photo;
    private RelativeLayout lt_certificate_photorl;
    /**
     * 提交按钮
     */
    private Button lt_certificate_commit;
    /**
     * 上传文件弹出Dialog
     */
    private ConfirmDialog mUploadDialog;
    private TextView xc_id_pop_photoUpload;//照相机
    private TextView xc_id_pop_localAlbum;//图库
    private TextView xc_id_pop_cancel;//取消
    /**
     * 照相机
     */
    private XCCameraPhotoFragment cameraPhotoFragment;
    /**
     * 删除按钮
     */
    private ImageView lt_hospital_cfedelete;
    /**
     * 照片的文件变量
     */
    private File mCFEFile = null;
    private Intent intent;
    private Intent backIntent;
    /**
     * 图片路径
     */
    String mFilePath = "";
    /**
     * 医生合法备案状态（0 未申请备案; 1 备案审核中;2 备案成功; 3 备案失败; 4 要求备案）
     */
    private String viewFlag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lt__certificate_editor);
        super.onCreate(savedInstanceState);
        initDate();
    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(LT_CertificateEditorActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */


    /**
     * 初始化数据
     */
    private void initDate() {
        viewFlag = UtilSP.getDoctorStatus();
        //   viewFlag = "3";
        mCFEFile = (File) backIntent.getSerializableExtra("cfefile");
        if("4".equals(viewFlag)){
            viewFlag ="0";
        }
        if (mCFEFile != null) {
            //第一次进入页面确认按钮是不能点击的  (如果数据不为空说明 1 有后台操作上传一部分数据  2是审核状态    3是审核失败状态  提交按钮都是置灰不可点击的)
            lt_certificate_commit.setEnabled(false);
            switch (viewFlag) {
                //未审核
                case "0":
                    lt_certificate_photo.setVisibility(View.VISIBLE);
                    lt_hospital_cfedelete.setVisibility(View.VISIBLE);
                    setImageViewUrl(mCFEFile);
                    break;
                //待审核
                case "1":
                    lt_certificate_photo.setVisibility(View.VISIBLE);
                    lt_hospital_cfedelete.setVisibility(View.GONE);
                    setImageViewUrl(mCFEFile);
                    break;
                //审核失败
                case "3":
                    lt_certificate_photo.setVisibility(View.VISIBLE);
                    lt_hospital_cfedelete.setVisibility(View.VISIBLE);
                    setImageViewUrl(mCFEFile);
                    break;
            }
        }
    }


    @Override
    public void initWidgets() {
        initDialog();
        intent = new Intent();
        backIntent = getIntent();
        cameraPhotoFragment = new XCCameraPhotoFragment();
        addFragment(R.id.lt_certificate_camera, cameraPhotoFragment);
        //标题部分
        XCTitleCommonLayout xcTitleCommonLayout = (XCTitleCommonLayout) findViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonLayout.setTitleLeft(true, "");
        xcTitleCommonLayout.setTitleCenter(true, "职称证书");
        //上传证件
        lt_certificate_photo = (ImageView) findViewById(R.id.lt_certificate_photo);
        lt_certificate_photorl = (RelativeLayout) findViewById(R.id.lt_certificate_photorl);
        //提交按钮
        lt_certificate_commit = (Button) findViewById(R.id.lt_certificate_commit);
        //删除按钮
        lt_hospital_cfedelete = (ImageView) findViewById(R.id.lt_hospital_cfedelete);

    }

    @Override
    public void listeners() {
        lt_certificate_photo.setOnClickListener(this);
        lt_certificate_photorl.setOnClickListener(this);
        lt_certificate_commit.setOnClickListener(this);
        cameraPhotoFragment.setOnCaremaSelectedFileListener(this);
        lt_hospital_cfedelete.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {}

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.lt_certificate_photo:
                //显示大图
                mFilePath = mCFEFile.getAbsolutePath();
                startShowPictureActivity(mFilePath,"职称证书",0);
                break;
            case R.id.lt_certificate_photorl:
                //弹出窗口（相册）
                uploadDialogShow();
                break;
            case R.id.xc_id_pop_photoUpload:
                //跳转相机
                uploadDialogDismiss();
                cameraPhotoFragment.getTakePhoto();
                break;
            case R.id.xc_id_pop_localAlbum:
                //跳转相册
                uploadDialogDismiss();
                ToJumpHelp.toJumpSelctImgsActivity(this, 1, YY_SelectImgsActivity.MODE_SINGLE,
                        false, true, false, true);
                break;
            case R.id.lt_hospital_cfedelete:
                //删除图片
                mFilePath ="";
                mCFEFile = null;
                lt_certificate_photo.setImageURI(null);
                lt_certificate_photo.setVisibility(View.GONE);
                lt_hospital_cfedelete.setVisibility(View.GONE);
                //控制提交按钮的可点击事件
                lt_certificate_commit.setEnabled(true);
                checkButton();
                break;
            case R.id.xc_id_pop_cancel:
                //取消窗口
                uploadDialogDismiss();
                break;
            case R.id.lt_certificate_commit:
                //确认按钮
                saveData();
                break;
        }
    }

    //IamegView显示图片
    private  void setImageViewUrl(File  file){
        lt_certificate_photo.setImageURI(Uri.fromFile(file));
    }

    private void saveData(){
        if(mCFEFile!=null){
            backIntent.putExtra("cfefile",mCFEFile);
            backIntent.putExtra("cfewaitCommit","待提交");
            setResult(RESULT_OK,backIntent);
            finish();
        }else{
            shortToast("请添加您的职称证书");
        }
    }

    /**
     * dialog初始化
     */
    private void initDialog(){
        int srceenW =  this.getWindowManager().getDefaultDisplay().getWidth();
        mUploadDialog = new ConfirmDialog(LT_CertificateEditorActivity.this, srceenW,245
                , R.layout.xc_l_pop_window_photo,R.style.xc_s_dialog);
        mUploadDialog.setCanceledOnTouchOutside(false);
        Window window = mUploadDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        xc_id_pop_photoUpload = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_photoUpload);
        xc_id_pop_localAlbum = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_localAlbum);
        xc_id_pop_cancel = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_cancel);
        xc_id_pop_photoUpload.setOnClickListener(this);
        xc_id_pop_localAlbum.setOnClickListener(this);
        xc_id_pop_cancel.setOnClickListener(this);
    }

    /**
     * 显示大图页
     * @param filepath  图片路径
     * @param filename 图片标题
     * @param flag 显示的方式（网络1、本地0）
     */
    private void startShowPictureActivity(String filepath,String filename,int  flag){
        intent.setFlags(flag);
        intent.putExtra("FILE_PATH", filepath);
        intent.putExtra("PICTURE_NAME", filename);
        intent.setClass(LT_CertificateEditorActivity.this,SX_ShowPictureActivity.class);
        myStartActivity(intent);
    }

    /**
     * 设置按钮颜色
     */
    private void checkButton(){
        if(mCFEFile!=null){
            lt_certificate_commit.setTextColor(getResources().getColor(R.color.c_e2231a));
            lt_certificate_commit.setEnabled(true);
        }else {
            lt_certificate_commit.setTextColor(getResources().getColor(R.color.c_login_text_bg));
        }
    }
    private void uploadDialogDismiss(){
        if(null != mUploadDialog && mUploadDialog.isShowing()){
            mUploadDialog.dismiss();
        }
    }

    private void uploadDialogShow(){
        if(null != mUploadDialog && !mUploadDialog.isShowing()){
            mUploadDialog.show();
        }
    }

    /**
     * 相册回调照片
     * @param file
     */
    @Override
    public void onCaremaSelectedFile(File file) {
        if (file != null) {
            mCFEFile = file;
            lt_certificate_photo.setVisibility(View.VISIBLE);
            lt_hospital_cfedelete.setVisibility(View.VISIBLE);
//            lt_certificate_photo.setImageURI(Uri.fromFile(file));
            setImageViewUrl(file);
            checkButton();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        //用户选择图片完成 add by xd 2017/11/27
        if (requestCode == YY_SelectImgsActivity.REQUEST_IMAGE) {
            if (data == null || data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT) == null) {
                return;
            }
            File file = (File) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
            if (file != null) {
                File toUploadFile = UtilFile.ChangeImgsToUploadFile(file);//压缩图片
                mCFEFile = toUploadFile;
                lt_certificate_photo.setVisibility(View.VISIBLE);
                lt_hospital_cfedelete.setVisibility(View.VISIBLE);
                setImageViewUrl(toUploadFile);
                checkButton();
            }
        }
    }
}