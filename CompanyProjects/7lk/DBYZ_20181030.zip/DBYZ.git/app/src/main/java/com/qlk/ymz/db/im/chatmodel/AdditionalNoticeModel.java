package com.qlk.ymz.db.im.chatmodel;

import java.io.Serializable;

/**
 * description: 附加启事消息
 * autour: YM
 * date: 2018/1/8
 * version:
 */
public class AdditionalNoticeModel  implements Serializable, Cloneable {
    private String detail = "";//详细内容
    private String displayPosition = "";//1-前（显示在消息的上面）,2-后（显示在消息的下面）
    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getDisplayPosition() {
        return displayPosition;
    }

    public void setDisplayPosition(String displayPosition) {
        this.displayPosition = displayPosition;
    }
}