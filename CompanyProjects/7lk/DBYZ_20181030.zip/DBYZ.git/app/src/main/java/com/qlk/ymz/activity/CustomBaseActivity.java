package com.qlk.ymz.activity;

import android.view.View;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.view.XCTitleCommonLayout;

/**
 * 自定义的父控件
 */

public class CustomBaseActivity extends DBActivity {
    /** 标题布局 */
    private XCTitleCommonLayout xcTitleCommonLayout;
    /** 标题右边按钮文字 */
    private String titleRight = "保存";
    /** 标题左边按钮文字 */
    private String titleLeft = "取消";
    /** 页面标题内容 */
    protected String title;

    @Override
    public void initWidgets() {
        xcTitleCommonLayout = getViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonLayout.setTitleCenter(true, title);
        xcTitleCommonLayout.setTitleRight2(true, 0, titleRight);
        xcTitleCommonLayout.setTitleLeft(true, titleLeft);
        xcTitleCommonLayout.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });
    }

    @Override
    public void listeners() {


    }
    @Override
    public void onNetRefresh() {

    }

    /** 点击右侧保存 */
    protected void save(){

    }

}
