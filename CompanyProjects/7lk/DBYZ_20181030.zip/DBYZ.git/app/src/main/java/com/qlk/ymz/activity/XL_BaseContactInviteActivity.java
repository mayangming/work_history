package com.qlk.ymz.activity;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PF_SelectContactsAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.invited.XL_ContactsInvitedModel;
import com.qlk.ymz.db.invited.XL_ContactsModelDb;
import com.qlk.ymz.model.XL_RawContactModel;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilAppToSystemApp;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.HorizontalListView;
import com.qlk.ymz.view.XL_InviteContactChoicePhoneDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * @author xilinch on 2016/4/5.
 * @modifier xilinch 2016/4/5 14:22.
 * @description 邀请联系人和选择联系人基类，公共的操作。比如显示电话号码选择框、数据库存入等
 *
 * @modifier shuYanYi on 2016/04/12
 * @description  增加邀请联系人操作日志埋点。
 * @version v2.3
 */
public abstract class XL_BaseContactInviteActivity extends DBActivity{

    /*** 联系人数据*/
    protected ArrayList<XL_RawContactModel> rawContactModels = new ArrayList<>();
    /*** 邀请联系人选择电话对话框*/
    protected XL_InviteContactChoicePhoneDialog inviteContactChoicePhoneDialog;
    /*** 记录上一次点击的时间，实现与微信相同的功能*/
    protected long clickTopTimeMillisSecond = 0;
    /*** 联系人是否发送数据库*/
    protected XL_ContactsModelDb contactsModelDb;
    /*** 联系人是否发送model*/
    protected  List<XL_ContactsInvitedModel> contactsInvitedModels;
    /*** 联系人是否被点击map,注意 使用map不会保持选中的顺序*/
    protected HashMap<String,XL_ContactsInvitedModel> clickedPhoneContactMap = new LinkedHashMap<>();
    /*** 邀请联系人姓名*/
    protected TextView xc_id_tv_invite_name;
    /**选中联系人listview*/
    protected HorizontalListView pf_id_invite_name_lv;
    /*** 选中联系人适配器*/
    protected PF_SelectContactsAdapter selectContactsAdapter;
    /** 选中的联系人 */
    protected List<XL_ContactsInvitedModel> mSelectContacts = new ArrayList<>();
    /*** 邀请 */
    protected TextView xc_id_tv_invite;
    /*** 底部邀请布局 */
    protected LinearLayout xc_id_ll_invite;

    protected boolean isSearchResult = false;

    /** 是否正在获取短信模板*/
    public boolean isGetingSMSModel = false;
    /** 是否可发送邀请联系人操作日志*/
    public boolean canRequestContactsLog = false;

    /*** 联系人指定的几列，优化查询用*/
    protected static final String[] S_PROJECTIONS = new String[]{
            ContactsContract.Contacts._ID,
            ContactsContract.Contacts.DISPLAY_NAME,
            ContactsContract.Contacts.SORT_KEY_PRIMARY};
    /*** 查询电话号码 指定的几列，优化查询用*/
    protected static final String[] S_PROJECTIONS_PHONE = new String[]{
            ContactsContract.CommonDataKinds.Phone._ID,
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER};
    /**用来区分是否需要请求短信模板  只有在联系人页的时候才变成 true */
    public boolean isGetFinishMsg = false;
    /**是否上传完成联系人*/
    public boolean isUploadContactsFinish = false;
    /**是否从短信页面回来 true 是 false 不是*/
    public static boolean IS_FROM_SMS = false;
    /**手机号格式*/
    public String phoneFormat = "[^0-9]";
    /**
     * 处理邀请的联系人
     * 1.如果多个号码，显示号码选择框则在批量邀请时弹出手机号选择框，一次一个用户只能被选择一个手机号，同时隐藏批量邀请的浮层；
     * 2.只有一个号码直接选中，更新下方选中文字
     * 3.无号码，不显示出来
     *
     * @param model  联系人model
     */
    protected void handleInviteContact(XL_RawContactModel model,final ImageView iv){
        if(model == null){
            dShortToast("数据错误!");
            return;
        }
        List<XL_RawContactModel.XL_PhoneContent> phoneContents = model.getPhoneContents();
        model.setPhoneContents(phoneContents);
        XL_RawContactModel.XL_PhoneContent phoneContent = phoneContents.get(0);
        int phone_size = phoneContents.size();
        if(phone_size == 1){

            //只有一个号码，直接加到选中数据集合中来
            XL_ContactsInvitedModel contactsInvitedModel = new XL_ContactsInvitedModel();
            contactsInvitedModel.setContactId(phoneContent.getContactId());
            contactsInvitedModel.setDisplay_name(phoneContent.getDisplay_name());
            contactsInvitedModel.setFlag(XL_ContactsInvitedModel.STATUS_INVITIED_YES);
            contactsInvitedModel.setNumber(phoneContent.getPhone());
            contactsInvitedModel.setPhoneId(phoneContent.get_id());
            contactsInvitedModel.setDoctorId(UtilSP.getUserId());
            if(clickedPhoneContactMap.containsKey(phoneContent.getContactId())){
                clickedPhoneContactMap.remove(phoneContent.getContactId());
            } else {

                clickedPhoneContactMap.put(phoneContents.get(0).getContactId(), contactsInvitedModel);
            }
            uiUpdateChoiceRawContact();
            uiUpdateInvitedStatus(model, iv);


        } else if(phone_size > 1){
            //多个号码，显示号码选择框
            if(clickedPhoneContactMap.containsKey(phoneContent.getContactId())){
                clickedPhoneContactMap.remove(phoneContent.getContactId());
                uiUpdateChoiceRawContact();
                uiUpdateInvitedStatus(model, iv);
            }else{
                showInviteContactChoicePhoneDialog(model, iv);
            }

        } else {
            //错误数据
            shortToast("该联系人号码为空!");
        }
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_BaseContactInviteActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    /**
     * 更新邀请状态。邀请过了没有被选中：灰色；未邀请的被选中：蓝色；邀请过了被选中：蓝色；未邀请为被选中的：空白
     * @param model 联系人
     * @param iv 邀请状态按钮
     */
    protected void uiUpdateInvitedStatus(XL_RawContactModel model, ImageView iv) {
        String flag = model.getFlag();
        boolean invited = false;
        if (XL_ContactsInvitedModel.STATUS_INVITIED_YES.equals(flag)) {
            invited = true;
        } else {
            invited = false;
        }
        boolean contains = clickedPhoneContactMap.containsKey(model.getId());
        if (contains) {
            iv.setImageLevel(0);
        } else if (invited) {
            iv.setImageLevel(1);
        } else {
            iv.setImageLevel(2);
        }
    }

    /**
     * 显示选择号码提示框
     * 1.当选择号码匡显示的时候，下方的选中联系人文本内容隐藏
     * @param model
     */
    protected void showInviteContactChoicePhoneDialog(final XL_RawContactModel model,final ImageView iv) {
        if(inviteContactChoicePhoneDialog == null){

            inviteContactChoicePhoneDialog = new XL_InviteContactChoicePhoneDialog(XL_BaseContactInviteActivity.this,model);

        }
        ListView lv_phone= (ListView) inviteContactChoicePhoneDialog.findViewById(R.id.xl_id_dialog_invite_contact_lv_phone);
        if( lv_phone != null){
            lv_phone.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    XL_RawContactModel.XL_PhoneContent phoneContent = (XL_RawContactModel.XL_PhoneContent) parent.getAdapter().getItem(position);


                    //加到选中数据集合中来
                    XL_ContactsInvitedModel contactsInvitedModel = new XL_ContactsInvitedModel();
                    contactsInvitedModel.setContactId(phoneContent.getContactId());
                    contactsInvitedModel.setDisplay_name(phoneContent.getDisplay_name());
                    contactsInvitedModel.setFlag(XL_ContactsInvitedModel.STATUS_INVITIED_YES);
                    contactsInvitedModel.setNumber(phoneContent.getPhone());
                    contactsInvitedModel.setPhoneId(phoneContent.get_id());
                    contactsInvitedModel.setDoctorId(UtilSP.getUserId());

                    if (clickedPhoneContactMap.containsKey(phoneContent.getContactId())) {
                        String _id_choice = clickedPhoneContactMap.get(phoneContent.getContactId()).getPhoneId();
                        if (!TextUtils.isEmpty(_id_choice)
                                && !TextUtils.isEmpty(phoneContent.get_id())
                                && _id_choice.equals(phoneContent.get_id())) {
                            //多个电话的时候，选择电话号码，如果是电话号码ID也一样，则是取消电话，否则就是更新
                            //判断电话id
//                            clickedPhoneContactMap.remove(phoneContent.getContactId());
                        } else {
                            clickedPhoneContactMap.put(phoneContent.getContactId(), contactsInvitedModel);
                        }
                    } else {

                        clickedPhoneContactMap.put(phoneContent.getContactId(), contactsInvitedModel);
                    }

                    if (inviteContactChoicePhoneDialog != null) {

                        inviteContactChoicePhoneDialog.dismiss();
                    }
                    //更新视图
                    xc_id_ll_invite.setVisibility(View.VISIBLE);
                    uiUpdateChoiceRawContact();
                    uiUpdateInvitedStatus(model, iv);
                }
            });
        }
        inviteContactChoicePhoneDialog.updateRawContact(model);
        inviteContactChoicePhoneDialog.show();
    }

    /**
     *
     * 为了检索的性能，将列表形式的受邀请联系人 转变为map形式，在listview中可以减少一定开销
     */
    protected void addInvitedStatusRawContacts(){

        if(contactsInvitedModels !=  null){
            int size  = contactsInvitedModels.size();
            for(int i = 0; i < size ; i++){
                XL_ContactsInvitedModel model = contactsInvitedModels.get(i);
                String id = model.getContactId();
                String phone = model.getNumber(); //数据库里的电话
                String name = model.getDisplay_name(); //数据库里的姓名
                String isInvited = model.getFlag(); //数据库里的状态
                int size_rawContact = 0;
                if(rawContactModels != null){
                    size_rawContact = rawContactModels.size();
                }
                for(int j = 0 ; j < size_rawContact ; j ++){
                    XL_RawContactModel rawContactModel = rawContactModels.get(j);
                    String contactId = rawContactModel.getId(); //读取的联系人id
                    String contactName = rawContactModel.getDisplay_name(); //读取的联系人姓名
                    if(( id.equals(contactId) || name.equals(contactName) )&& XL_ContactsInvitedModel.STATUS_INVITIED_YES.equals(isInvited)){
                        if (id.equals(contactId)){
                            rawContactModel.setFlag(XL_ContactsInvitedModel.STATUS_INVITIED_YES);
                        }else if (name.equals(contactName)){
                            List<XL_RawContactModel.XL_PhoneContent> phoneContents = rawContactModel.getPhoneContents();
                            for (int k = 0 ; k < phoneContents.size() ; k ++){
                                if (phone.equals(phoneContents.get(k).getPhone())){
                                    rawContactModel.setFlag(XL_ContactsInvitedModel.STATUS_INVITIED_YES);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }


    /**
     * 保存到已经邀请联系人数据库
     */
    protected void save2InvitedDb() {
        if(clickedPhoneContactMap == null){
            return;
        } else if(clickedPhoneContactMap.isEmpty()){
            shortToast("请选择联系人!");
            return;
        } else {

            if (contactsModelDb == null) {
                contactsModelDb = XL_ContactsModelDb.getInstance(getApplicationContext());
            }
            Collection collection = clickedPhoneContactMap.values();
            Iterator<XL_ContactsInvitedModel> iterator = collection.iterator();
            HashMap<String,XL_ContactsInvitedModel> map = new HashMap<>();
            StringBuilder phoneBuilder = new StringBuilder();
            while (iterator.hasNext()){
                XL_ContactsInvitedModel contactsInvitedModel = iterator.next();
                map.put(contactsInvitedModel.getContactId(),contactsInvitedModel);
                contactsInvitedModel.setFlag(XL_ContactsInvitedModel.STATUS_INVITIED_YES);
                phoneBuilder.append(contactsInvitedModel.getNumber());
                phoneBuilder.append(";");
                List<XL_ContactsInvitedModel> list = contactsModelDb.queryByContactId(contactsInvitedModel.getContactId(), UtilSP.getUserId());
                if (list == null || list.size() == 0) {
                    contactsModelDb.insert(contactsInvitedModel);
                } else {
                    contactsModelDb.updateStatusByContactId(contactsInvitedModel, contactsInvitedModel.getContactId(), UtilSP.getUserId());
                }
            }
            if(phoneBuilder.length() > 0){
                phoneBuilder.deleteCharAt(phoneBuilder.lastIndexOf(";"));
            }

            if(isSearchResult){

                Intent intentBroadcast = new Intent();
                intentBroadcast.setAction(XL_ContactsInviteActivity.ACTION_UPDATE_INVITED_STATUS);
                intentBroadcast.putExtra(XL_ContactsInviteActivity.CONTACT_INVITED,map);
                sendBroadcast(intentBroadcast);
            }

            sendSMS(phoneBuilder.toString());
        }
    }


    /**
     * 更新底部已经选择联系人视图
     * 显示样式 张三、李四、jjj...
     */
    protected  void uiUpdateChoiceRawContact(){

        if(clickedPhoneContactMap != null){
            Iterator<String> iterator = clickedPhoneContactMap.keySet().iterator();
            mSelectContacts.clear();
            if(!iterator.hasNext()){
                //没有选中掩藏下方的邀请
                xc_id_ll_invite.setVisibility(View.GONE);
                xc_id_tv_invite_name.setText("");
            } else {
                xc_id_ll_invite.setVisibility(View.VISIBLE);
                while (iterator.hasNext()){
                    String key = iterator.next();
                    XL_ContactsInvitedModel model = clickedPhoneContactMap.get(key);
                    String name = model.getDisplay_name();
                    mSelectContacts.add(model);

                }
                if(mSelectContacts.size() > 0 ){
                    selectContactsAdapter.setList(mSelectContacts);
                }
            }

        }
    }

    /**
     * 根据联系人ID 检索改联系人下面所有的电话
     * @param contact_id 联系人id
     * @return 对应这个联系人所有的电话
     */
    protected List<XL_RawContactModel.XL_PhoneContent> searchContactsPhone(String contact_id) {
        ContentResolver cr = getContentResolver();
        List<XL_RawContactModel.XL_PhoneContent> phoneContents = new ArrayList<>();
        // 读取phone
        Cursor phoneCursor = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                S_PROJECTIONS_PHONE,
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                new String[]{contact_id}, null);
        // 该查询结果一般只返回一条记录，所以我们直接让游标指向第一条记录
        int size = phoneCursor.getCount();
        while (phoneCursor.moveToNext()) {
            String _id = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID));
            String phone = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            String contactId = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID));
            String displayName_phone = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));

            XL_RawContactModel.XL_PhoneContent phoneContent = new XL_RawContactModel.XL_PhoneContent();
            phoneContent.set_id(_id);
            phoneContent.setPhone(phone);
            phoneContent.setDisplay_name(displayName_phone);
            phoneContent.setContactId(contactId);
            phoneContents.add(phoneContent);
        }
        phoneCursor.close();
        return phoneContents;
    }

    /**
     * 发送短信
     * @param phone 电话
     */
    protected void sendSMS(String phone ){
//        String smsContent = UtilSP.INVITED_MSG;
        //----start 在进入邀请页面时已结开始获取一次后端模板，用户选择完患者还未返回模板的情况一般是网络问题或后端模板未配置 add by syy
        if(UtilString.isBlank(GlobalConfigSP.getInvitedMsg())){
            shortToast("网络出了点问题，请稍后再试");
            requestContactsSMSModel();//再次请求短信模板，待用户下次点击
            canRequestContactsLog = false;
            return;
        }
        canRequestContactsLog = true;//只好先在这控制能否发送日志的逻辑，不然全局改动较大。（有的地方如保存数据库save2InvitedDb()里发现会有调用sendSMS的方法，不太单一职责）
        //----end add by syy
        UtilAppToSystemApp.toSendSMS(this, phone, GlobalConfigSP.getInvitedMsg());
        IS_FROM_SMS = true;
    }


    /**
     * 记录医生添加联系人操作日志（邀请功能使用次数，邀请用户次数)
     * @param type 操作类型：1-手机联系人功能使用（每打开一次手机联系人页面），2-邀请患者
     * @param patientPhones 被邀请的患者手机号，英文逗号分隔
     */
    public void requestContactsLog(int type, String patientPhones) {
        if(type == 2 && !canRequestContactsLog){
            return;
        }
        RequestParams params = new RequestParams();
        params.put("type", type);
        if(type == 2){
            if(UtilString.isBlank(patientPhones)){
                return;
            }
            params.put("patientPhone", patientPhones);
        }
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.user_contacts_log), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
            }
            @Override
            public void fail() {
            }
            @Override
            public void onFinish() {
                super.onFinish();
            }
        });
    }


    /**
     * 组装手机号，批量邀请患者操作日志 发送到服务端
     * zhangpengfei -----2.5增加发送邀请的联系人电话和姓名到服务器
     */
    public void  requestContactsLog_batchInvite(){
        if(!canRequestContactsLog){
            return;
        }
        if(null != clickedPhoneContactMap && !clickedPhoneContactMap.isEmpty()){
            Collection<XL_ContactsInvitedModel> models = clickedPhoneContactMap.values();
            StringBuilder numSB = new StringBuilder();
            JSONArray contactsList = new JSONArray();
            boolean isFirst = true;
            for(XL_ContactsInvitedModel model : models){//遍历models中的手机号
                String num = model.getNumber();
                JSONObject contacts = new JSONObject();
                try {
                    contacts.put("name", UtilString.f(model.getDisplay_name()));
                    String phone = UtilString.f(model.getNumber());
                    //过滤电话中的除数字以外的字符
                    phone = phone.replaceAll(phoneFormat, "");
                    contacts.put("phone", phone);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if(isFirst){
                    isFirst = false;
                }else{
                    numSB.append(",");
                }
                numSB.append(num);
                contactsList.put(contacts);
            }
            //---------------------zhangpengfei 2.5版本取消这个接口埋点 2016-6-22 add-------------
//            requestContactsLog(2,numSB.toString());
            //---------------------zhangpengfei 2016-6-22 end-------------
            uploadContactsInfo(contactsList.toString());
        }

    }

    /**
     * 获取邀请联系人的短信模板
     */
    public void requestContactsSMSModel() {
        //每次进入联系人页会都会进行请求短信模板或者短信模板为空的时候才进行请求
        if (isGetFinishMsg || UtilString.isBlank(GlobalConfigSP.getInvitedMsg())){
            if(isGetingSMSModel){
                return;
            }
            isGetingSMSModel = true;
            XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.model_contacts_sms), new RequestParams(), new XCHttpResponseHandler() {
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if(result_boolean){
                        List<XCJsonBean> jsonBeans = result_bean.getList("data");
                        if (jsonBeans != null && jsonBeans.size() > 0) {
                            XCJsonBean obj = jsonBeans.get(0);
                            String messageContent = obj.getString("messageContent");
                            if(!UtilString.isBlank(messageContent)){
                                GlobalConfigSP.setInvitedMsg(messageContent);
                            }
                        }
                    }
                }

                @Override
                public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                    super.onFailure(code, headers, arg2, e);
                }

                @Override
                public void fail() {
                }

                @Override
                public void onFinish() {
                    super.onFinish();
                    isGetingSMSModel = false;
                }
            });
        }
    }

    /**
     * zhangpengfei
     * 上次邀请的联系人姓名和电话
     */
    public void uploadContactsInfo(String contactsJson) {
        if (!isUploadContactsFinish){
            isUploadContactsFinish = true;
            RequestParams params = new RequestParams();
            params.put("phoneContacts", contactsJson);
            XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.uploadContacts), params, new XCHttpResponseHandler() {
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                }

                @Override
                public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                }

                @Override
                public void fail() {
                }

                @Override
                public void onFinish() {
                    super.onFinish();
                    isUploadContactsFinish = false;
                }
            });
        }
    }

}
