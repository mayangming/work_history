package com.qlk.ymz.db.im.chatmodel;

import java.io.Serializable;

/**
 * autor:YM
 * date:2018-3-26
 * version:2.16.0
 * description:复购功能，主要用于展示药品到期的提示
 */
public class ReBuyNotic implements Serializable, Cloneable {

    /* 结束天数 */
    private String endDay = "";
    /* 患者头像 */
    private String headUrl = "";
    /* 药品名称 */
    private String medicationName = "";
    /* 患者id */
    private String patientId = "";
    /* 患者姓名 */
    private String patientName = "";
    /* 推荐id */
    private String recommandId = "";
    /* 推荐日期 */
    private String recommandTime = "";
    /* 药品规格 */
    private String spec = "";

    /* 病历ID */
    private String recordId = "";

    @Override
    protected Object clone() throws CloneNotSupportedException {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getEndDay() {
        return endDay;
    }

    public void setEndDay(String endDay) {
        this.endDay = endDay;
    }

    public String getHeadUrl() {
        return headUrl;
    }

    public void setHeadUrl(String headUrl) {
        this.headUrl = headUrl;
    }

    public String getMedicationName() {
        return medicationName;
    }

    public void setMedicationName(String medicationName) {
        this.medicationName = medicationName;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String parientId) {
        this.patientId = parientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String parientName) {
        this.patientName = parientName;
    }

    public String getRecommandId() {
        return recommandId;
    }

    public void setRecommandId(String recommandId) {
        this.recommandId = recommandId;
    }

    public String getRecommandTime() {
        return recommandTime;
    }

    public void setRecommandTime(String recommandTime) {
        this.recommandTime = recommandTime;
    }

    public String getSpec() {
        return spec;
    }

    public void setSpec(String spec) {
        this.spec = spec;
    }

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }
}