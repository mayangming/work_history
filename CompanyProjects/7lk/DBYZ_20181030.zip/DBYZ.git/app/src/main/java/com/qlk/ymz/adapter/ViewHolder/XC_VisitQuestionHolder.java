package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * @author jingyu on 2016/6/25 0:29
 * @description dialog里的listview用的
 */
public class XC_VisitQuestionHolder {

    public TextView question;
    public TextView id_suifang_answer_text;

    public XC_VisitQuestionHolder(View convertView) {
        this.question = (TextView) convertView.findViewById(R.id.id_suifang_question);
        this.id_suifang_answer_text = (TextView) convertView.findViewById(R.id.id_suifang_answer_text);
    }
}
