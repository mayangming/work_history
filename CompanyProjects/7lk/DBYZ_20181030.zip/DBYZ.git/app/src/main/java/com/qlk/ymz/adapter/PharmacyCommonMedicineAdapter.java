package com.qlk.ymz.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.view.SwipeLayout.PullSwipeLayoutAdapter;
import com.qlk.ymz.view.SwipeLayout.SwipeOnTouchListener;
import com.qlk.ymz.view.SwipeLayout.SwipeViewHolder;
import com.xiaocoder.android.fw.general.application.XCApplication;

import java.util.List;
import java.util.Map;

/**
 * Created by xiedong on 2017/12/14.
 */

public class PharmacyCommonMedicineAdapter extends PullSwipeLayoutAdapter<DrugBean> {

    /**监听*/
    private CommonMedicineActionListener mCommonMedicineActionListener;

    /**
     * 构造函数
     *
     * @param context
     * @param contentViewResourceId
     * @param actionViewResourceId
     * @param itemWidth
     * @param contentWidth
     * @param list
     */
    public PharmacyCommonMedicineAdapter(Context context, int contentViewResourceId, int actionViewResourceId, int itemWidth, int contentWidth, List<DrugBean> list) {
        super(context, contentViewResourceId, actionViewResourceId, itemWidth, contentWidth, list);
    }

    @Override
    public void setContentView(View contentView, final int position, HorizontalScrollView parent, final SwipeViewHolder holder, final SwipeOnTouchListener swipeOnTouchListener) {
        final DrugBean bean = list.get(position);
        ViewHolder viewHolder = (ViewHolder) contentView.getTag();
        if (viewHolder == null) {
            viewHolder = new ViewHolder(context, contentView);
            contentView.setTag(viewHolder);
        }
       /* // 若是本组最后一条数据，则隐藏分割线
        if(position == list.size() - 1){
            viewHolder.sk_id_medichine_item_line.setVisibility(View.INVISIBLE);
        }else {
            viewHolder.sk_id_medichine_item_line.setVisibility(View.VISIBLE);
        }*/

        // 显示库存数量
        viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.VISIBLE);
        try {
            if(Integer.parseInt(bean.getStockNum()) <= 99)
                viewHolder.sk_id_medichine_item_stock_num.setText("剩余" + bean.getStockNum() + "件");
            else
                viewHolder.sk_id_medichine_item_stock_num.setText("剩余99+件");
        }catch (Exception e){e.printStackTrace();}

        viewHolder.sk_id_medichine_item_bg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCommonMedicineActionListener!=null){
                    mCommonMedicineActionListener.onItemClick(position);
                }
            }
        });

        // 是否推荐商品（1 是 0否）
        if("1".equals(bean.getIsRecommend())){
            viewHolder.sk_id_medichine_item_bg.setBackgroundResource(R.drawable.sk_dd_selector_img_red_fff4ee);
            viewHolder.sk_id_medichine_item_recommend.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medichine_item_remove_recommend.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medichine_item_remove_recommend.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    swipeOnTouchListener.setCurrentActiveHSV(holder);
                }
            });
        }else {
            viewHolder.sk_id_medichine_item_bg.setBackgroundResource(R.drawable.sk_dd_selector_img_gray_eeeeee);
            viewHolder.sk_id_medichine_item_recommend.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_item_remove_recommend.setVisibility(View.INVISIBLE);
        }

        // 是否缺货，1 是，0 否
        if ("1".equals(bean.getIsShort())) {
            // 显示缺货view
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.GONE);
        } else {
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.GONE);
        }

        // 是否为预售，1 是，0 否
        // 若是预售，则不显示库存状态
        if ("1".equals(bean.getIsPresell())) {
            // 显示预售view
            viewHolder.sk_id_medichine_item_presell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    XCApplication.base_log.shortToast(bean.getPresellInfo());
                }
            });
            viewHolder.sk_id_medichine_item_presell.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.GONE);
        } else {
            viewHolder.sk_id_medichine_item_presell.setVisibility(View.GONE);
        }

        // 是否在销售
        if (bean.isSale()) {
            viewHolder.sk_id_medichine_item_sale_ll.setVisibility(View.GONE);
        } else {
            // 已下架，则不显示库存状态
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_item_sale_ll.setVisibility(View.VISIBLE);
        }

        viewHolder.sk_id_medichine_item_oprice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG); //删除线
        viewHolder.sk_id_medichine_item_oprice.getPaint().setAntiAlias(true); //抗锯齿
        viewHolder.sk_id_medichine_item_common_name.setText(bean.getName());
        viewHolder.sk_id_medichine_item_name.setText(bean.getManufacturer());

        // 是否已经调价
        if(bean.isModified()){
            viewHolder.sk_id_medichine_change_price.setText("已调价");
        }else {
            viewHolder.sk_id_medichine_change_price.setText("调价");
        }

        // 获取调价后的价格，用完后情况静态值
        if(!TextUtils.isEmpty(DrugBean.drug_id) && bean.getId().equals(DrugBean.drug_id)
                && !TextUtils.isEmpty(DrugBean.drug_price)){
            bean.setSalePrice(DrugBean.drug_price);
            bean.setModified(true);
            viewHolder.sk_id_medichine_change_price.setText("已调价");
            DrugBean.drug_id = "";
            DrugBean.drug_price = "";
        }

        viewHolder.sk_id_medichine_item_pprice.setText(bean.getSalePrice());
        viewHolder.sk_id_medichine_item_oprice.setText(AppConfig.renminbi + bean.getMarketPrice());
        XCApplication.displayImage(bean.getImage(), viewHolder.sk_id_medichine_item_img);

        contentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UtilNativeHtml5.toJumpDrugDetail(context,bean.getId());
                DrugBean.drug_id = bean.getId();
            }
        });

        viewHolder.sk_id_medichine_change_price.setTag(bean);

        // 是否显示小七指数或市场积分,0：不显示，1小七指数、2市场积分
        if ("0".equals(bean.getShowCommission())) {
            viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.GONE);
        } else if("2".equals(bean.getShowCommission())){
            viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medicine_drcommission.setText(bean.getMarketPoint());
            viewHolder.sk_id_medicine_point_name.setText(context.getResources().getText(R.string.medicine_MarketPoint));

        }else if("1".equals(bean.getShowCommission())){
            viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medicine_drcommission.setText(bean.getDrCommission());
            viewHolder.sk_id_medicine_point_name.setText(context.getResources().getText(R.string.medicine_commission));
        }

        // 是否显示病历数据收集标签,0:不显示,1：显示
        if("1".equals(bean.getShowRecomCollect())){
            viewHolder.sk_id_medichine_item_collect.setVisibility(View.VISIBLE);
        }else {
            viewHolder.sk_id_medichine_item_collect.setVisibility(View.GONE);
        }
        viewHolder.sk_id_medichine_item_collect.setTag(bean);

        // 是否显示调价按钮
        if(bean.getModifyFlag()){
            viewHolder.sk_id_medichine_change_price.setVisibility(View.VISIBLE);
        }else {
            viewHolder.sk_id_medichine_change_price.setVisibility(View.GONE);
        }
    }
    @Override
    public void setActionView(View actionView, final int position, HorizontalScrollView parent) {
        ActionViewHolder viewHolder = ActionViewHolder.getViewHolder(actionView);
        viewHolder.tv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCommonMedicineActionListener!=null){
                    mCommonMedicineActionListener.delete(position);
                }
            }
        });
    }



    /**
     * 设置常用药动作的监听
     * @param commonMedicineActionListener
     */
    public void setCommonMedicineActionListener(CommonMedicineActionListener commonMedicineActionListener) {
        this.mCommonMedicineActionListener = commonMedicineActionListener;
    }


    static class ActionViewHolder {
        //删除
        TextView tv_delete;

        public ActionViewHolder(View convertView) {
            tv_delete = (TextView) convertView.findViewById(R.id.tv_delete);
        }

        public static ActionViewHolder getViewHolder(View convertview) {
            ActionViewHolder holder = (ActionViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new ActionViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }

    public interface CommonMedicineActionListener{
        void delete(int position);
        void onItemClick(int position);
    }


    /**
     * ViewHolder类
     */
    private class ViewHolder {
        /**
         * 调价
         */
        private Button sk_id_medichine_change_price;
        /**
         * 药品图片
         */
        private ImageView sk_id_medichine_item_img;
        /**
         * 厂家
         */
        private TextView sk_id_medichine_item_name;
        /**
         * 药品名 + （常用名）
         */
        private TextView sk_id_medichine_item_common_name;
        /**
         * 价格
         */
        private TextView sk_id_medichine_item_pprice;
        /**
         * 市场价
         */
        private TextView sk_id_medichine_item_oprice;
        /**
         * 积分
         */
        private TextView sk_id_medichine_item_recom_point;

        /**
         * 是否已下架的浮层
         */
        private LinearLayout sk_id_medichine_item_sale_ll;
        public LinearLayout sk_id_medicine_drcommission_ll;
        public TextView sk_id_medicine_drcommission;
        /**
         * 小七指数
         */
        public TextView sk_id_medicine_point_name;
        /**
         * 预售图片
         */
        public ImageView sk_id_medichine_item_presell;
        /**
         * 库存数量
         */
        public TextView sk_id_medichine_item_stock_num;
        /**
         * 无货标识
         */
        public ImageView sk_id_medichine_item_short_iv;
        /**
         * 背景
         */
        public RelativeLayout sk_id_medichine_item_bg;
        /**
         * 小七推荐图片
         */
        public ImageView sk_id_medichine_item_recommend;
        /**
         * 删除小七推荐的图片
         */
        public ImageView sk_id_medichine_item_remove_recommend;
        /**
         * 分割线
         */
        public View sk_id_medichine_item_line;
        /**
         * 病历收集
         */
        public ImageView sk_id_medichine_item_collect;

        /**
         * 初始化控件
         *
         * @param convertView 包含控件的布局View
         */
        public ViewHolder(final Context activity,View convertView) {
            sk_id_medichine_change_price = (Button) convertView.findViewById(R.id.sk_id_medichine_change_price);
            //把内容区和操作区添加到item
            sk_id_medichine_item_img = (ImageView) convertView.findViewById(R.id.sk_id_medichine_item_img);
            sk_id_medichine_item_name = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_name);
            sk_id_medichine_item_common_name = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_common_name);
            sk_id_medichine_item_pprice = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_pprice);
            sk_id_medichine_item_oprice = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_oprice);
            sk_id_medichine_item_sale_ll = (LinearLayout) convertView.findViewById(R.id.sk_id_medichine_item_sale_ll);
            sk_id_medichine_item_recom_point = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_recom_point);
            sk_id_medicine_drcommission_ll = (LinearLayout) convertView.findViewById(R.id.sk_id_medicine_drcommission_ll);
            sk_id_medicine_drcommission = (TextView) convertView.findViewById(R.id.sk_id_medicine_drcommission);
            sk_id_medichine_item_presell = (ImageView)convertView.findViewById(R.id.sk_id_medichine_item_presell);
            sk_id_medichine_item_stock_num = (TextView)convertView.findViewById(R.id.sk_id_medichine_item_stock_num);
            sk_id_medichine_item_short_iv = (ImageView)convertView.findViewById(R.id.sk_id_medichine_item_short_iv);
            sk_id_medichine_item_bg = (RelativeLayout)convertView.findViewById(R.id.sk_id_medichine_item_bg);
            sk_id_medichine_item_recommend = (ImageView)convertView.findViewById(R.id.sk_id_medichine_item_recommend);
            sk_id_medichine_item_remove_recommend = (ImageView)convertView.findViewById(R.id.sk_id_medichine_item_remove_recommend);
            sk_id_medichine_item_collect = (ImageView)convertView.findViewById(R.id.sk_id_medichine_item_collect);
            sk_id_medichine_item_line = convertView.findViewById(R.id.sk_id_medichine_item_line);
            sk_id_medicine_point_name = (TextView) convertView.findViewById(R.id.sk_id_medicine_point_name);
            sk_id_medichine_change_price.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DrugBean bean = (DrugBean) v.getTag();
                    DrugBean.drug_id = bean.getId();
                    if (!UtilCollection.isBlank(bean.getSkus()))
                        ToJumpHelp.toJumpPriceCalculatorActivity((Activity)activity,bean.getSkuId());
                }
            });
            sk_id_medichine_item_collect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DrugBean bean = (DrugBean) v.getTag();
                    UtilNativeHtml5.toJumpSunlightPage(context,bean.getId());
                }
            });
        }
    }
}
