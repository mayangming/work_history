package com.qlk.ymz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.ILoadingLayout;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_MassHistoryAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.MassHistoryBean;
import com.qlk.ymz.parse.Parse2MassHistoryBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCIMMenuDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * SX_MassHistoryActivity
 * 群发历史页面
 * @author songxin on 2017/2/22.
 * @version 2.7.0
 */
public class SX_MassHistoryActivity extends DBActivity {
    /** title左边按钮*/
    private ImageView sx_id_title_left;
    /** title中间文字*/
    private TextView sx_id_title_center;
    /** 聊天记录listView*/
    private PullToRefreshListView sx_id_mass_history_list;
    private ListView myListView;
    /** 长按显示dialog*/
    private XCIMMenuDialog dialog;
    private List<MassHistoryBean> mMassHistoryBeenList;
    /** 没有网络时显示*/
    private LinearLayout sx_id_no_net_rl;
    /** 群发历史适配器*/
    private SX_MassHistoryAdapter mSX_MassHistoryAdapter;
    /** 当前页号*/
    private String mPageNo = "0";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_mass_history);
        super.onCreate(savedInstanceState);
        sx_id_title_center.setText("群发历史");
        mMassHistoryBeenList = new ArrayList<>();

        sx_id_mass_history_list.setMode(PullToRefreshBase.Mode.PULL_FROM_END);

        ILoadingLayout endLabels = sx_id_mass_history_list.getLoadingLayoutProxy(
                false, true);
        endLabels.setPullLabel("上拉刷新...");// 刚下拉时，显示的提示
        endLabels.setRefreshingLabel("正在载入...");// 刷新时
        endLabels.setReleaseLabel("放开刷新...");// 下来达到一定距离时，显示的提示
    }

    /** created by songxin,date：2017-4-10,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_MassHistoryActivity.class);
    }

    /** created by songxin,date：2016-4-10,about：bi,end */

    @Override
    public void initWidgets() {
        sx_id_title_left = getViewById(R.id.sx_id_title_left);
        sx_id_title_center = getViewById(R.id.sx_id_title_center);
        sx_id_mass_history_list = getViewById(R.id.sx_id_mass_history_list);

        sx_id_no_net_rl = getViewById(R.id.sx_id_no_net_rl);
        ((TextView)sx_id_no_net_rl.findViewById(R.id.id_zero_data_tv)).setText("还没有群发过消息");

        myListView = sx_id_mass_history_list.getRefreshableView();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getMassHistoryList(Integer.valueOf("".equals(mPageNo) ? "0" : mPageNo) + 1, "10");
    }

    @Override
    public void listeners() {
        sx_id_title_left.setOnClickListener(this);
        //长按事件
        myListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(SX_MassHistoryActivity.class, "2", "128", "massHistorySetOnItemLongClickListener","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end
                showLongClickDialog(mMassHistoryBeenList.get(position - 1).getMsgId());
                return true;
            }
        });

        sx_id_mass_history_list.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
               //下拉刷新
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                //上拉加载
                getMassHistoryList(Integer.valueOf("".equals(mPageNo) ? "0" : mPageNo) + 1, "10");
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            //返回
            case R.id.sx_id_title_left:{
                finish();
                break;
            }
            default:
                break;
        }
    }

    /**
     * 获取列表
     * @param pageNo
     * @param pageSize
     */
    private void getMassHistoryList(int pageNo,String pageSize){
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("token", UtilSP.getUserToken());
        params.put("page", pageNo);
        params.put("num", pageSize);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.batch_message_list), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                        Parse2MassHistoryBean parse2MassHistoryBean = new Parse2MassHistoryBean();
                        mMassHistoryBeenList.addAll(parse2MassHistoryBean.parse(result_bean));
                        //当前页号
                        mPageNo = parse2MassHistoryBean.getPageNo();

                        sx_id_mass_history_list.onRefreshComplete();
                        if(null != mMassHistoryBeenList) {
                            if (mMassHistoryBeenList.size() == 0) {
                                sx_id_no_net_rl.setVisibility(View.VISIBLE);
                            } else {
                                sx_id_no_net_rl.setVisibility(View.GONE);
                            }
                            //如果不够一页，不显示下拉加载
                            if(UtilString.toInt(parse2MassHistoryBean.getTotalCount()) >= mMassHistoryBeenList.size()){
                                sx_id_mass_history_list.setMode(PullToRefreshBase.Mode.PULL_FROM_END);
                            }else{
                                sx_id_mass_history_list.setMode(PullToRefreshBase.Mode.DISABLED);
                            }
//                        }
                            //适配数据
                            if(null == mSX_MassHistoryAdapter){
                                mSX_MassHistoryAdapter = new SX_MassHistoryAdapter(SX_MassHistoryActivity.this,mMassHistoryBeenList);
                                myListView.setAdapter(mSX_MassHistoryAdapter);
                            }else{
                                mSX_MassHistoryAdapter.notifyDataSetChanged();
                            }
                        }
                    }
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_MassHistoryActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }


    /**
     * 长按后显示dialog
     */
    private void showLongClickDialog(final String id) {
        if (dialog == null) {
            dialog = new XCIMMenuDialog(this);
        }
        dialog.update("", new String[]{XCIMMenuDialog.DELETE});

        dialog.setOnDialogItemClickListener(new XCIMMenuDialog.OnDialogItemClickListener() {
            public void onClick(View view, String hint) {
                //长按删除操作
                if (XCIMMenuDialog.DELETE.equals(hint)) {
                    deleteItem(id);
                }
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private  void deleteItem(String id){
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("token", UtilSP.getUserToken());
        params.put("id", id);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.batch_message_remove), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if(null != mMassHistoryBeenList){
                        mMassHistoryBeenList.clear();
                    }
                    mPageNo = "0";
                    getMassHistoryList(Integer.valueOf("".equals(mPageNo) ? "0" : mPageNo) + 1, "10");
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_MassHistoryActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }
}
