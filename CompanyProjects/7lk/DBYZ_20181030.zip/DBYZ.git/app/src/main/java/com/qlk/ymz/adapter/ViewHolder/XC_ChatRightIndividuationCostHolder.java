package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 聊天详情  医生 个性化收费功能
 */
public class XC_ChatRightIndividuationCostHolder extends XC_ChatRightBaseHolder  {
    public TextView id_right_individuation_cost_title;
    public TextView id_right_individuation_cost_date;
    public ImageView id_right_individuation_cost_img;
    public TextView id_right_individuation_cost_price_name;
    public TextView id_right_individuation_cost_price;
    public View id_right_individuation_cost_layout;
    public View id_right_individuation_cost_price_layout;
    public TextView id_right_save_cost;//存为常用
    public TextView id_right_cost_recommend_again;//再次推荐

    public XC_ChatRightIndividuationCostHolder(View convertView) {
        super(convertView);
        id_right_individuation_cost_layout = convertView.findViewById(R.id.id_right_individuation_cost_layout);
        id_right_individuation_cost_price_layout = convertView.findViewById(R.id.id_right_individuation_cost_price_layout);
        id_right_individuation_cost_title = (TextView) convertView.findViewById(R.id.id_right_individuation_cost_title);
        id_right_individuation_cost_date = (TextView) convertView.findViewById(R.id.id_right_individuation_cost_date);
        id_right_individuation_cost_img = (ImageView) convertView.findViewById(R.id.id_right_individuation_cost_img);
        id_right_individuation_cost_price_name = (TextView) convertView.findViewById(R.id.id_right_individuation_cost_price_name);
        id_right_individuation_cost_price = (TextView) convertView.findViewById(R.id.id_right_individuation_cost_price);
        id_right_save_cost = (TextView) convertView.findViewById(R.id.id_right_save_cost);
        id_right_cost_recommend_again = (TextView) convertView.findViewById(R.id.id_right_cost_recommend_again);
    }
}
