package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.SQ_ExamineListActivity;
import com.qlk.ymz.adapter.ViewHolder.ExamineHolder;
import com.qlk.ymz.application.DBApplication;
import com.qlk.ymz.model.ExamineBean;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @description 检查单搜索结果列表适配器
 * @author 赖善琦
 * @version 2.2.0
 */
public class SQ_InspectSearchResultAdapter extends XCBaseAdapter<ExamineBean> {
    /** 勾选按钮的点击监听 */
    private View.OnClickListener onClickListener;

    /**
     * 是否勾选的map集合
     * K：检查单ID
     * V：（true,false）true：已勾选 false：未勾选
     */
    private Map<String,Boolean> mCheckMap = new HashMap<>();

    /**
     * 构造方法
     * @param context 上下文
     * @param list 数据
     */
    public SQ_InspectSearchResultAdapter(Context context, List<ExamineBean> list) {
        super(context, list);
    }

    /**
     * 设置勾选按钮的监听
     * @param onClick 点击监听
     */
    public void setCheckBoxOnClick(View.OnClickListener onClick) {
        onClickListener = onClick;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ExamineBean bean = list.get(i);
        ExamineHolder holder;
        if(view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.sq_item_inspect_search_result, null);
            holder = new ExamineHolder(view);
            holder.sk_id_examine_cb.setOnClickListener(onClickListener);
            view.setTag(holder);
        }else {
            holder = (ExamineHolder) view.getTag();
        }

        holder.sk_id_examine_cb.setTag(bean);
        holder.sk_id_examine_name.setText(bean.getName());
        holder.sk_id_examine_item_pprice.setText(StringUtils.getMoneyString(bean.getSalePrice()));
        holder.sk_id_medicine_drcommission.setText(bean.getCommission());

        DBApplication.base_imageloader.displayImage(bean.getThumbImage(),holder.sk_id_examine_item_img,
                XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.sq_d_defimg));

        // 判断是否被勾选，mCheckMap.get(bean.getId())为空和false表示未勾选，true表示已勾选
        if(null == mCheckMap.get(bean.getId())){
            bean.setCheck(false);
        }else{
            bean.setCheck(mCheckMap.get(bean.getId()));
        }


        holder.sk_id_examine_cb.setTag(R.id.sk_id_medichine_img,holder.sk_id_examine_item_img);
        // 选中状态
        if(bean.isCheck()){
            holder.sk_id_examine_cb.setTextColor(context.getResources().getColor(R.color.c_gray_7b7b7b));
            holder.sk_id_examine_cb.setBackgroundResource(R.mipmap.sk_dd_added);
            holder.sk_id_examine_cb.setText("移出检查单");
        }else {
            // created by songxin,date：2017-10-30,about：saveInfo,begin
            BiUtil.saveBiInfo(SQ_ExamineListActivity.class, "2", "128", "sk_id_examine_cb","", false);
            // created by songxin,date：2016-10-30,abou t：saveInfo,end
            holder.sk_id_examine_cb.setTextColor(context.getResources().getColor(R.color.c_white_ffffff));
            holder.sk_id_examine_cb.setBackgroundResource(R.mipmap.sk_dd_add);
            holder.sk_id_examine_cb.setText("加入检查单");
        }

        showFooterView(holder.sk_id_examine_item_footerView,bean);

        return view;
    }

    /**
     * 显示底部布局
     * @param view 底部布局
     * @param bean bean
     */
    public void showFooterView(View view,ExamineBean bean){
        if(list.size() > 0){
            ExamineBean lastBean = list.get(list.size() - 1);
            if(bean == lastBean){
                view.setVisibility(View.VISIBLE);
            }else {
                view.setVisibility(View.GONE);
            }
        }

    }

    public void setCheckMap(Map<String, Boolean> mCheckMap) {
        this.mCheckMap = mCheckMap;
    }
}
