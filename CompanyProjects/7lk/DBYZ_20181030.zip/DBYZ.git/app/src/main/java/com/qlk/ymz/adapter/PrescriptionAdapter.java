package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.DrugBean;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;

import java.util.ArrayList;

/**
 * 常用处方药界面药品列表
 */
public class PrescriptionAdapter extends XCBaseAdapter<DrugBean> {
    private boolean isShowEdtLinearLayout;
    /**
     * 上下文
     */
    private Context context;
    private LayoutInflater layoutInflater;

    public PrescriptionAdapter(Context context, ArrayList<DrugBean> list) {
        super(context,list);
        this.context = context;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = convertView;
        final ViewHolder viewHolder;
        final DrugBean drugBean = (DrugBean) getItem(position);
        if (null == view) {
            view = layoutInflater.inflate(R.layout.item_prescription_medication, null);
            viewHolder = new ViewHolder(view);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.ym_item_ordonnance_edt_drugusage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usage = viewHolder.ym_item_ordonnance_medicition_direction.getText().toString().trim();
                recommendAdapterOnClickListener.OnEditUsageDataClickListener(v,position,usage,drugBean);
            }
        });

        viewHolder.ym_item_ordonnance_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recommendAdapterOnClickListener.OnRemoveClickListener(v, position,drugBean);
            }
        });

        if (isShowEdtLinearLayout) {
            viewHolder.ym_item_ordonnance_medicition_edt_ll.setVisibility(View.VISIBLE);
        } else {
            viewHolder.ym_item_ordonnance_medicition_edt_ll.setVisibility(View.GONE);
        }
        viewHolder.ym_item_ordonnance_medicition_name.setText(drugBean.getRecomName());
        viewHolder.ym_item_ordonnance_medicition_number.setText("x" + drugBean
                .getMedicineUsageBean().getQuantity()+(TextUtils.isEmpty(drugBean
                .getMedicineUsageBean().getQuantityUnit())?"":drugBean.getMedicineUsageBean()
                .getQuantityUnit()));
        if ("".equals(drugBean.getMedicineUsageBean().getBakUp())) { // 备注为空
            viewHolder.ym_item_ordonnance_medicition_direction.setText("用法：" + drugBean.getMedicineUsageBean().getUsages());
        } else { // 备注不为空
            if ("".equals(drugBean.getMedicineUsageBean().getUsages())) { // 用法用量为空
                viewHolder.ym_item_ordonnance_medicition_direction.setText("用法：" + drugBean.getMedicineUsageBean().getBakUp());
            } else {
                viewHolder.ym_item_ordonnance_medicition_direction.setText("用法：" + drugBean.getMedicineUsageBean().getUsages() + "，" + drugBean.getMedicineUsageBean().getBakUp());
            }

        }
        if (list.size()-1 == position){
            viewHolder.medication_listview_divider.setVisibility(View.GONE);
        }else {
            viewHolder.medication_listview_divider.setVisibility(View.VISIBLE);
        }

        return view;
    }

    public void showEdtLinearLayout() {
        isShowEdtLinearLayout = true;
        notifyDataSetChanged();
    }

    public void hideEdtLinearLayout() {
        isShowEdtLinearLayout = false;
        notifyDataSetChanged();
    }

    /**
     * 设置推荐用药列表适配器的监听接口
     *
     * @param recommendAdapterOnClickListener 推荐用药列表适配器的监听接口实现类
     */
    public void setRecommendAdapterOnClickListener(RecommendAdapterOnClickListener recommendAdapterOnClickListener) {
        this.recommendAdapterOnClickListener = recommendAdapterOnClickListener;
    }

    private RecommendAdapterOnClickListener recommendAdapterOnClickListener;

    /**
     * 推荐用药列表适配器的监听接口
     */
    public interface RecommendAdapterOnClickListener {
        /**
         * 删除药品的监听
         *
         * @param v 删除按钮
         */
        void OnRemoveClickListener(View v, int position,DrugBean drugBean );

        /**
         * 调整用法用量的监听
         *
         * @param v 调整用法用量的按钮
         */
        void OnEditUsageDataClickListener(View v, int position,String usage,DrugBean drugBean );

    }

    /**
     * 缓存类
     */
    class ViewHolder {
        public TextView ym_item_ordonnance_medicition_name;//药品名字
        public TextView ym_item_ordonnance_medicition_direction;//药品用法
        public TextView ym_item_ordonnance_medicition_number;//药品数量
        public LinearLayout ym_item_ordonnance_medicition_edt_ll;//药品编辑的布局,默认为不显示
        public TextView ym_item_ordonnance_edt_drugusage;//调整药品用法数量
        public TextView ym_item_ordonnance_del;//删除药品
        public View medication_listview_divider; //分割线

        public ViewHolder(View convertView) {
            ym_item_ordonnance_medicition_name = (TextView) convertView.findViewById(R.id.ym_item_ordonnance_medicition_name);
            ym_item_ordonnance_medicition_direction = (TextView) convertView.findViewById(R.id.ym_item_ordonnance_medicition_direction);
            ym_item_ordonnance_medicition_number = (TextView) convertView.findViewById(R.id.ym_item_ordonnance_medicition_number);
            ym_item_ordonnance_medicition_edt_ll = (LinearLayout) convertView.findViewById(R.id.ym_item_ordonnance_medicition_edt_ll);
            ym_item_ordonnance_edt_drugusage = (TextView) convertView.findViewById(R.id.ym_item_ordonnance_edt_drugusage);
            ym_item_ordonnance_del = (TextView) convertView.findViewById(R.id.ym_item_ordonnance_del);
            medication_listview_divider = convertView.findViewById(R.id.medication_listview_divider);
        }
    }
}