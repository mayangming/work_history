package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 聊天详情  医生 纯文本消息
 */
public class XC_ChatLeftMovieHolder extends XC_ChatLeftBaseHolder {

    public ImageView xc_id_adapter_left_moive_content_imageview;
    public ImageView xc_id_adapter_left_moive_play_imageview;
    public RelativeLayout xc_id_adapter_left_moive_content_layout;

    public XC_ChatLeftMovieHolder(View convertView) {
        super(convertView);
        xc_id_adapter_left_moive_content_imageview = (ImageView) convertView.findViewById(R.id.xc_id_adapter_left_moive_content_imageview);
        xc_id_adapter_left_moive_play_imageview = (ImageView) convertView.findViewById(R.id.xc_id_adapter_left_moive_play_imageview);
        xc_id_adapter_left_moive_content_layout = (RelativeLayout) convertView.findViewById(R.id.xc_id_adapter_left_moive_content_layout);
    }
}