package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.PointInfoBean;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.parse.Parse2PointInfoModel;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.HospitalBackupsBeanSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

/**
 * @Created by xilinch on 2015/6/16.
 * @version 1.0
 * @description 积分信息
 *
 * @version 2.3
 * @author 马杨茗 2016-4-18
 * @description 1、通过后台的openApply字段控制提现布局的显示与隐藏
 *              2、传递 积分信息到下个页面
 *
 * @version  2.3
 * @author cyr 2016-4-27
 *
 *
 * TODO update by cyr on 2017-1-9 修改PointInfoBean结构，及parse解析方式
 */
public class XL_PointsActivityV2 extends DBActivity {
    /*** 通用标题*/
    private XCTitleCommonLayout xcTitleCommonFragment;
    /** 可提现积分数值 */
    private TextView xl_activity_point_tv_canMentionPoint;
    /** 账户总积分行 */
    private LinearLayout xl_activity_point_ll_totalPoint;
    /** 账户总积分数值 */
    private TextView xl_activity_point_tv_totalPoint;
    /** 累计提现行 */
    private LinearLayout xl_activity_point_ll_grandMention;
    /** 累计提现数值 */
    private TextView xl_activity_point_tv_grandMention;
    /** 立即提现 */
    private TextView xl_activity_point_tv_applycash;
//    /** 提现入口 */
//    private LinearLayout xl_activity_point_pay_content;
    /** 积分信息，传递积分信息时统一使用此名称 */
    public static final String POINT_INFO= "point_info";
    /** 用户积分信息的封装对象以供他用 */
    private PointInfoBean pointInfoBean;
    /** 提现到银行卡 */
    private LinearLayout xl_activity_add_back_card;
    /** 提示 */
    private TextView tv_tips;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xl_activity_points_v2);
        super.onCreate(savedInstanceState);
        /** created by songxin,date：2016-4-25,about：saveInfo,begin */
        BiUtil.saveBiInfo(XL_PointsActivityV2.class,"1","","","",false);
        /** created by songxin,date：2016-4-25,about：saveInfo,end */
    }


    @Override
    public void initWidgets() {
        xcTitleCommonFragment = (XCTitleCommonLayout) findViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonFragment.setTitleLeft(true, "");
        xcTitleCommonFragment.setTitleCenter(true, getString(R.string.points_titile));
        xcTitleCommonFragment.setTitleRight2(true, 0, "积分规则");
        xcTitleCommonFragment.getXc_id_titlebar_left_imageview().setImageResource(R.mipmap.xc_d_chat_back);
        xcTitleCommonFragment.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));
        xcTitleCommonFragment.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        xcTitleCommonFragment.getXc_id_titlebar_common_layout().setBackgroundColor(getResources().getColor(R.color.c_white_ffffff));

        tv_tips = (TextView) findViewById(R.id.tv_tips);
        xl_activity_point_tv_canMentionPoint = (TextView) findViewById(R.id.xl_activity_point_tv_canMentionPoint);
        xl_activity_point_ll_totalPoint = (LinearLayout) findViewById(R.id.xl_activity_point_ll_totalPoint);
        xl_activity_point_tv_totalPoint = (TextView) findViewById(R.id.xl_activity_point_tv_totalPoint);
        xl_activity_point_ll_grandMention = (LinearLayout) findViewById(R.id.xl_activity_point_ll_grandMention);
        xl_activity_point_tv_grandMention = (TextView) findViewById(R.id.xl_activity_point_tv_grandMention);
        xl_activity_point_tv_applycash = (TextView) findViewById(R.id.xl_activity_point_tv_applycash);
//        xl_activity_point_pay_content = (LinearLayout) findViewById(R.id.xl_activity_point_pay_content);
        xl_activity_add_back_card = (LinearLayout)findViewById(R.id.xl_activity_add_back_card);

    }

    /** 请求积分信息 */
    private void requestData() {
        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.doctorPoint), new RequestParams(), new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    pointInfoBean = new PointInfoBean();
                    Parse2PointInfoModel.parse(result_bean, pointInfoBean);

                    xl_activity_point_tv_canMentionPoint.setText(pointInfoBean.canMentionPoint);
                    xl_activity_point_tv_totalPoint.setText(pointInfoBean.totalPoint);
                    xl_activity_point_tv_grandMention.setText(pointInfoBean.grandMention);

                    isOpenApply(pointInfoBean.openApply);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();

                if (null != result_bean && GeneralReqExceptionProcess.checkCode(XL_PointsActivityV2.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    /**
     * 是否开启提现入口:0 隐藏 1 开启 2 不可提现
     * @param isApply 是否开启提现的状态，2.3版本步长医生显示状态0，非步长显示1，其他显示2
     * */
    private void isOpenApply(String isApply) {
        switch (isApply) {
            case "1":
            case "2":
                tv_tips.setVisibility(View.VISIBLE);
                xl_activity_point_tv_applycash.setVisibility(View.VISIBLE);
                xl_activity_point_ll_grandMention.setVisibility(View.VISIBLE);
                break;
            case "0":
            default:
                tv_tips.setVisibility(View.GONE);
                xl_activity_point_tv_applycash.setVisibility(View.GONE);
                xl_activity_point_ll_grandMention.setVisibility(View.GONE);
        }
    }

    @Override
    public void listeners() {
        xl_activity_point_ll_totalPoint.setOnClickListener(this);
        xl_activity_point_ll_grandMention.setOnClickListener(this);
        xl_activity_add_back_card.setOnClickListener(this);
        xl_activity_point_tv_applycash.setOnClickListener(this);

        xcTitleCommonFragment.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WebviewBean bean = new WebviewBean(AppConfig.getH5Url(AppConfig.doctor_integral_rule));
                bean.title = getString(R.string.point_rule_titile);
                myStartActivity(JS_WebViewActivity.newIntent(XL_PointsActivityV2.this, bean));
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.xl_activity_point_ll_totalPoint:
                //积分历史 2.3版本换成h5
                UtilNativeHtml5.toJumpPointHistory(this);
                break;
            case R.id.xl_activity_point_ll_grandMention:
                //提现历史
                /** created by songxin,date：2016-4-25,about：saveInfo,begin */
                BiUtil.saveBiInfo(XL_PointsActivityV2.class,"2","128","xl_activity_point_ll_grandMention","",false);
                /** created by songxin,date：2016-4-25,about：saveInfo,end */
                // 提现记录改为H5页      sk 修改于2016年8月21日16:15:46
                UtilNativeHtml5.toJumpNativeH5(this,UtilNativeHtml5.NATIVE_APPLY_RECORD);
                break;
            case R.id.xl_activity_point_tv_applycash:
                /** created by songxin,date：2016-4-25,about：saveInfo,begin */
                BiUtil.saveBiInfo(XL_PointsActivityV2.class,"2","128","xl_activity_point_tv_applycash","",false);
                /** created by songxin,date：2016-4-25,about：saveInfo,end */
                if("4".equals(UtilSP.getDoctorStatus())){
                    requestCheck();
                }else {
                    // 申请提现
                    logicForApplyCash();
                }

                break;
                //提现到银行卡
            case R.id.xl_activity_add_back_card:
                myStartActivity(YY_EditBankCardActivityV2.class);
                break;
        }
    }

    /** 点击申请提现的逻辑 */
    private void logicForApplyCash() {
        if(pointInfoBean != null){
            String authStatus = UtilSP.getAuthStatus("0");
            try {
                float canMentionPoint_float = Float.valueOf(pointInfoBean.canMentionPoint);
                //判断 积分大于最低积分同时认证通过
                if (canMentionPoint_float >= AppConfig.LIMITE_POINT && "1".equals(authStatus)) {
                    Intent intent = new Intent(this, XL_ApplyCashBackActivityV2.class);
                    intent.putExtra(POINT_INFO, pointInfoBean);
                    myStartActivityForResult(intent, 1);
                }else if(canMentionPoint_float < AppConfig.LIMITE_POINT && "1".equals(authStatus)){
                    shortToast("积分不足" + AppConfig.LIMITE_POINT + "，无法申请提现。");
                }else if(canMentionPoint_float < AppConfig.LIMITE_POINT && !"1".equals(authStatus)){
                    shortToast("积分不足" + AppConfig.LIMITE_POINT + "且未通过身份认证，无法申请提现。");
                }else if(canMentionPoint_float >= AppConfig.LIMITE_POINT && !"1".equals(authStatus)){
                    shortToast("未通过身份认证，无法申请提现。");
                }
            } catch(Exception e) {
                shortToast("数据异常！");
            }
        }else{
            shortToast("未能获取积分信息，请重新登录！");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (1 == requestCode) {
            if (resultCode == RESULT_OK) {//从申请提现页面返回时调用
                finish();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        requestData();
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(XL_PointsActivityV2.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    @Override
    public void onNetRefresh() {

    }

    /**
     * 2.16 版本
     * 提现前前校验备案
     */
    public void requestCheck() {
        RequestParams params = new RequestParams();

        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.checkApplyCash), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    try {
                        // remindInfo (string, optional): 提醒文案 ,
                        // withdrawal (integer, optional): 提现（1：允许，2：禁止，0：无文案，直接去提现（历史数据））
                        String withdrawal = result_bean.getList("data").get(0).getString("withdrawal");
                        String remindInfo = result_bean.getList("data").get(0).getString("remindInfo");
                        if("0".equals(withdrawal) || "3".equals(withdrawal)){
                            logicForApplyCash();
                            return;
                        }
                        showSHospitalBackupsDialog(remindInfo,withdrawal);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(XL_PointsActivityV2.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 备案dialog
     * @param text 对话框内容
     * @param withdrawal  提现（1：允许，2：禁止，0：无文案（历史数据））
     */
    private void showSHospitalBackupsDialog( String text,final String withdrawal) {
        new YR_CommonDialog(this, text, "取消", "去备案") {
            @Override
            public void confirmBtn() {
                HospitalBackupsBeanSP.TO_ACTIVITY = NativeHtml5.QLK_JIFEN_MANAGE;
                UtilNativeHtml5.toJumpNativeH5(XL_PointsActivityV2.this, UtilNativeHtml5.INTERNET_HOSPITAL_RECORD);
                dismiss();
            }

            @Override
            public void cancelBtn() {
                if("1".equals(withdrawal )){ // 允许提现
                    dismiss();
                    logicForApplyCash();
                }else if("2".equals(withdrawal)){ // 禁止提现
                    dismiss();
                }
            }
        }.show();
    }

    /**
     * 提示dialog
     *
     * @param content 内容
     */
    public void showCommonDialog(String content) {
        new YR_CommonDialog(this, content, "", "知道了") {
            @Override
            public void confirmBtn() {
                dismiss();
            }
        };

    }
}
