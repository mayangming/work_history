package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

/**
 * 聊天详情  医生 声音消息
 */
public class XC_ChatRightPhotoHolder extends XC_ChatRightBaseHolder {

    public RelativeLayout xc_id_adapter_right_photo_layout;
    public XCRoundedImageView xc_id_adapter_right_photo_imageview;

    public XC_ChatRightPhotoHolder(View convertView) {
        super(convertView);
        xc_id_adapter_right_photo_layout = (RelativeLayout) convertView.findViewById(R.id.xc_id_adapter_right_photo_layout);
        xc_id_adapter_right_photo_imageview = (XCRoundedImageView) convertView.findViewById(R.id.xc_id_adapter_right_photo_imageview);
    }
}