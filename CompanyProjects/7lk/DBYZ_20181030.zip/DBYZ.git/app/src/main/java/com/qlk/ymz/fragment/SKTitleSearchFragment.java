package com.qlk.ymz.fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.db.search.XCSearchRecordModel;
import com.qlk.ymz.db.search.XCSearchRecordModelDb;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * @description 药品搜索的title
 * @author 赖善琦
 * @version 2.0.0
 */
public class SKTitleSearchFragment extends DBFragment {
    /** 左边图片 */
    private ImageView xc_id_titlebar_left_imageview;
    /** 搜索文本编辑框 */
    private EditText sk_id_search_edit;
    /** 搜索框右边文字 “搜索” */
    private TextView xc_id_titlebar_right2_textview;
    /** 历史记录的数据库操作类 */
    private XCSearchRecordModelDb db;
    /** 数据库表名 */
    private String tabName;
    //    TextView xc_id_fragment_search_cancle;
    /** 是否弹键盘，true：是，false：否， 默认是*/
    private boolean isOpenInputMethod = true;

    private LinearLayout xc_id_titlebar_left_layout;

    private LinearLayout xc_id_titlebar_right2_layout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        if (item_layout_id == 0) {
            return init(inflater, R.layout.sk_l_fragment_title_search);
        } else {
            return init(inflater, item_layout_id);
        }
    }

    @Override
    public void initWidgets() {
        xc_id_titlebar_right2_layout = getViewById(R.id.xc_id_titlebar_right2_layout);
        xc_id_titlebar_left_layout = getViewById(R.id.xc_id_titlebar_left_layout);
        xc_id_titlebar_left_imageview = getViewById(R.id.xc_id_titlebar_left_imageview);
        sk_id_search_edit = getViewById(R.id.sk_id_search_edit);
        xc_id_titlebar_right2_textview = getViewById(R.id.xc_id_titlebar_right2_textview);
        sk_id_search_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(GlobalConfigSP.getLimitValue(GlobalConfigSP.MEDICINE_SEARCH,0,19))});
        if(isOpenInputMethod){
            sk_id_search_edit.requestFocus();
            UtilInputMethod.openInputMethod(sk_id_search_edit, getActivity());
        }
        db = new XCSearchRecordModelDb(getActivity(), XCSearchRecordModelDb.SEARCH_DB_NAME, XCSearchRecordModelDb.SEARCH_DB_VERSION, tabName);
        if (hint != null) {
            sk_id_search_edit.setHint(hint);
        }

    }

    @Override
    public void listeners() {
        xc_id_titlebar_left_imageview.setOnClickListener(this);
        xc_id_titlebar_right2_textview.setOnClickListener(this);
        sk_id_search_edit.setOnClickListener(this);
        sk_id_search_edit.addTextChangedListener(textWatcher);
        sk_id_search_edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if(clicklistener != null)
                        clicklistener.clicked();
                }
            }
        });
        sk_id_search_edit.setOnEditorActionListener(new OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

                if (actionId == EditorInfo.IME_ACTION_SEARCH) {

                    String keyword = sk_id_search_edit.getText().toString().trim();
                    if ("".equals(keyword)) {
                        return false;
                    }
                    if (getActivity().getCurrentFocus() != null) {
                        if (getActivity().getCurrentFocus().getWindowToken() != null) {
                            // 先隐藏键盘
                            ((InputMethodManager) sk_id_search_edit.getContext().getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getActivity().getCurrentFocus()
                                    .getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                        }
                    }
                    save(keyword);
                    // 进入搜索结果页面
                    if (searchlistener != null) {
                        searchlistener.searchKeyDown(keyword);
                    }
                    return true;
                }
                return false;
            }
        });
    }

    public void hideLeftLayout(){
        if(xc_id_titlebar_left_layout!=null)xc_id_titlebar_left_layout.setVisibility(View.GONE);
    }
    public void showLeftLayout(){
        if(xc_id_titlebar_left_layout!=null)xc_id_titlebar_left_layout.setVisibility(View.VISIBLE);
    }
    public void hideRightLayout(){
        if(xc_id_titlebar_right2_layout!=null)xc_id_titlebar_right2_layout.setVisibility(View.GONE);
        sk_id_search_edit.clearFocus();
        sk_id_search_edit.setText("");
    }
    public void showRightLayout(){
        if(xc_id_titlebar_right2_layout!=null)xc_id_titlebar_right2_layout.setVisibility(View.VISIBLE);
    }

//
//        @Override
//        public void onHiddenChanged(boolean hidden) {
//            super.onHiddenChanged(hidden);
//            if(!hidden){
//                sk_id_search_edit.requestFocus();
//                UtilInputMethod.openInputMethod(sk_id_search_edit, getActivity());
//            }
//
//        }

    public void setTabName(String tabName) {
        this.tabName = tabName;
    }

    // 点击取消按钮时（有时可能不是取消，而是搜索）
    public interface OnClickCancleButtonListener {
        void clicked(String key_word);
    }

    public void setOnClickCancleButtonListener(OnClickCancleButtonListener canclelistener) {
        this.canclelistener = canclelistener;
    }

    OnClickCancleButtonListener canclelistener;

    // 当eidttext整个被点击的时候
    public interface OnEditTextClickedListener {
        void clicked();
    }

    // 当键盘的搜索的按钮点击时
    public interface OnKeyBoardSearchListener {
        void searchKeyDown(String key_word);
    }

    public void setOnClicklistener(OnEditTextClickedListener clicklistener) {
        this.clicklistener = clicklistener;
    }

    public void setOnSearchlistener(OnKeyBoardSearchListener searchlistener) {
        this.searchlistener = searchlistener;
    }

    //左侧监听事件
    public interface LeftListener {
        void leftClick();
    }

    LeftListener left_listener;

    public void setLeft_listener(LeftListener left_listener) {
        this.left_listener = left_listener;
    }
//    //右侧监听事件
//    public interface Right2TextViewClickListener {
//        void onRight2TextViewClick();
//    }
//    Right2TextViewClickListener right2TextViewClickListener;
//
//    public void setOnRight2TextViewClickListener(Right2TextViewClickListener right2TextViewClickListener) {
//        this.right2TextViewClickListener = right2TextViewClickListener;
//    }

    OnEditTextClickedListener clicklistener;
    OnKeyBoardSearchListener searchlistener;

    int item_layout_id;

    public void setItem_layout_id(int item_layout_id) {
        this.item_layout_id = item_layout_id;
    }


    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.xc_id_titlebar_left_imageview) {
            if (left_listener != null) {
                // 自定义逻辑
                left_listener.leftClick();
            } else {
                // 默认的
                myFinish();
            }
        }
//        if (id == R.id.xc_id_titlebar_right2_textview) {
//            if (right2TextViewClickListener != null) {
//                right2TextViewClickListener.onRight2TextViewClick();
//            }
//        }

        // 取消
        if (id == R.id.xc_id_titlebar_right2_textview) {
            if (getActivity().getCurrentFocus() != null) {
                if (getActivity().getCurrentFocus().getWindowToken() != null) {
                    // 先隐藏键盘
                    ((InputMethodManager) sk_id_search_edit.getContext().getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getActivity().getCurrentFocus()
                            .getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }
            }
            if (canclelistener != null) {
                xc_id_titlebar_right2_textview.requestFocus();
                sk_id_search_edit.clearFocus();
                sk_id_search_edit.setText("");
                String keyword = sk_id_search_edit.getText().toString().trim();

                if ("搜索".equals(xc_id_titlebar_right2_textview.getText().toString().trim())) {

                    if ("".equals(keyword)) {
                        shortToast("关键字不能为空");
                        return;
                    }

                    save(keyword);
                }
                canclelistener.clicked(keyword);
            } else {
                myFinish();
            }
        } else if (id == R.id.sk_id_search_edit) {
            if (clicklistener != null) {
                clicklistener.clicked();
            }
        }
    }

    /**
     * 关键字保存到数据库
     * @param keyword 关键字
     */
    public void save(String keyword) {
        if (UtilString.isBlank(keyword)) {
            return;
        }

        List<XCSearchRecordModel> xcSearchRecordModels1 = db.queryAllByDESC();
        boolean is_exist = false;
        for (XCSearchRecordModel model : xcSearchRecordModels1) {
            if (keyword.equals(model.getKey_word())) {
                is_exist = true;
                break;
            }
        }

        // 记录存入数据库
        if (!is_exist) {
            db.insert(new XCSearchRecordModel(keyword, System.currentTimeMillis() + ""));
        }

        int count = db.queryCount();

        if (count > 10) {
            List<XCSearchRecordModel> xcSearchRecordModels = db.queryAllByDESC();
            for (int i = 10; i < count; i++) {
                XCSearchRecordModel model = xcSearchRecordModels.get(i);
                if (model != null) {
                    db.deleteByTime(model.getTime());
                }
            }
        }


    }

    /**
     * 设置title编辑框的内容
     * @param keyword 关键字
     */
    public void setText(String keyword) {
        int max = GlobalConfigSP.getLimitValue(GlobalConfigSP.MEDICINE_SEARCH,0,19);
        // 限制最多不能超过max个字符
        if( keyword.length()> max ){
            keyword = keyword.substring(0,max - 1);
        }
        if (sk_id_search_edit != null) {
            sk_id_search_edit.setText(keyword);
            sk_id_search_edit.setSelection(sk_id_search_edit.getText().toString().trim().length());
        }
    }


    public void setHint(String hint) {
        this.hint = hint;
    }

    String hint;
    TextWatcher textWatcher;

    public void setSearchTextWatcher(TextWatcher textWatcher) {
        this.textWatcher = textWatcher;

    }

    public void addSearchTextWatcher(TextWatcher textWatcher) {
        if (sk_id_search_edit != null)
            sk_id_search_edit.addTextChangedListener(textWatcher);
        this.textWatcher = textWatcher;
    }

    public void removeSearchTextWatcher() {
        if (sk_id_search_edit != null)
            sk_id_search_edit.removeTextChangedListener(textWatcher);
    }

    public void setOpenInputMethod(boolean openInputMethod) {
        isOpenInputMethod = openInputMethod;
    }
}
