package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 量表：调查表
 */
public class XC_ChatLeftQuesitionaryHolder extends XC_ChatLeftBaseHolder {

    public TextView id_left_quesitionary_title;
    public TextView id_left_quesitionary_content;
    public RelativeLayout id_left_quesitionary_layout;

    public XC_ChatLeftQuesitionaryHolder(View convertView) {
        super(convertView);
        id_left_quesitionary_title = (TextView) convertView.findViewById(R.id.id_left_quesitionary_title);
        id_left_quesitionary_content = (TextView) convertView.findViewById(R.id.id_left_quesitionary_content);
        id_left_quesitionary_layout = (RelativeLayout) convertView.findViewById(R.id.id_left_quesitionary_layout);
    }
}