package com.qlk.ymz.activity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.application.DBApplication;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.parse.Parse2PatientBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.TextChangedListenerUtil;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.InputMethodEventView;
import com.qlk.ymz.view.SX_ClearEditText;
import com.qlk.ymz.view.YR_CommonDialog;
import com.tencent.qcloud.presenters.LoginHelper;
import com.tencent.qcloud.utils.Constants;
import com.xiaocoder.android.fw.general.dialog.XCSystemVDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilMd5;
import com.xiaocoder.android.fw.general.util.UtilRSA;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * LoginActivity
 * 石榴云医3.0.0 登录
 * @author songxin on 2018/7/31.
 * @version 3.0.0
 */
public class LoginActivity extends DBActivity{
    /** 最外层布局*/
    private InputMethodEventView imv_login_page;
    /** 最外层滑动布局*/
    private ScrollView sv_body_content;
    /** 返回按钮*/
    private ImageView iv_login_back;
    /** 密码登录*/
    private TextView tv_password_login;
    /** 验证码登录*/
    private TextView tv_vcode_login;
    /** 用户名输入框*/
    private SX_ClearEditText et_username;
    /** 获取验证码*/
    private TextView tv_get_vcode;
    /** 提示切换（密码 or 验证码）*/
    private TextView tv_password_or_vcode;
    /** 密码输入框*/
    private SX_ClearEditText et_password;
    /** 密码明文密文切换*/
    private ImageView iv_see_password;
    /** 忘记密码*/
    private TextView tv_forget_password;
    /** 登录按钮*/
    private Button bt_login;
    /** 是否显示密码*/
    private boolean isShowPassword = false;
    /** 是否是密码登录*/
    private boolean isPwLogin = true;
    /** 计时器*/
    Timer mTimer;
    TimerTask mTask;
    int mTime = 60;
    /** 等待对话框 */
    private Dialog dialog;
    /** 患者存完数据库,关闭对话框 */
    public static final int CLOSE_DIALOG = 0;
    /** 设备判断完毕 */
    private  final int DEVICE_OVER = 1;
    /** 患者数据请求失败 */
    private  final int PATIENT_REQUEST_ERRO = 2;
    /**最少密码长度*/
    private int minLength = 0;
    /**最大密码长度*/
    private int maxLength = 0;
    /** 公钥*/
    private String mLoginKey;
    /** 手机号未注册提示dialog*/
    private YR_CommonDialog mCustomDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_login);
        super.onCreate(savedInstanceState);
        mTimer = new Timer();
        requestPubKey(false);
        selectLoginMode(true);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(LoginActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        imv_login_page = getViewById(R.id.imv_login_page);
        sv_body_content = getViewById(R.id.sv_body_content);
        iv_login_back = getViewById(R.id.iv_login_back);
        tv_password_login = getViewById(R.id.tv_password_login);
        tv_vcode_login = getViewById(R.id.tv_vcode_login);
        et_username = getViewById(R.id.et_username);
        tv_get_vcode = getViewById(R.id.tv_get_vcode);
        tv_password_or_vcode = getViewById(R.id.tv_password_or_vcode);
        et_password = getViewById(R.id.et_password);
        iv_see_password = getViewById(R.id.iv_see_password);
        tv_forget_password = getViewById(R.id.tv_forget_password);
        tv_forget_password.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        bt_login = getViewById(R.id.bt_login);
        dialog = new XCSystemVDialog(LoginActivity.this);
        dialog.setCancelable(false);
        minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PASSWORD,1,6);
        maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PASSWORD,0,19);
        et_password.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
    }

    @Override
    public void listeners() {
        iv_login_back.setOnClickListener(this);
        tv_password_login.setOnClickListener(this);
        tv_get_vcode.setOnClickListener(this);
        tv_vcode_login.setOnClickListener(this);
        iv_see_password.setOnClickListener(this);
        tv_forget_password.setOnClickListener(this);
        bt_login.setOnClickListener(this);
        // 页面布局发生变化的监听处理
        imv_login_page.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                int heightDiff = imv_login_page.getRootView().getHeight() - imv_login_page.getHeight();
                if (heightDiff > 100) {
                    sv_body_content.smoothScrollBy(0, 300);
                }
            }
        });
        //监听用户名输入框，控制登录按钮颜色，是否可点击
        TextChangedListenerUtil.textChanged(et_username,LoginActivity.this,bt_login,et_password);
        //监听密码输入框变化，控制登录按钮颜色，是否可点击
        TextChangedListenerUtil.textChanged(et_password,LoginActivity.this,bt_login,minLength,maxLength);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            //返回
            case R.id.iv_login_back:
                onBackPressed();
                break;
            //切换到密码登录
            case R.id.tv_password_login:
                selectLoginMode(true);
                break;
            //切换到验证码登录
            case R.id.tv_vcode_login:
                selectLoginMode(false);
                break;
            //获取验证码
            case R.id.tv_get_vcode:
                getCurtentTime(et_username.getText().toString().trim());
                break;
            //密码明文or密文
            case R.id.iv_see_password:
                if(!isShowPassword){
                    iv_see_password.setImageResource(R.mipmap.open_eyes);
                    et_password.setTransformationMethod(HideReturnsTransformationMethod
                            .getInstance());
                }else {
                    iv_see_password.setImageResource(R.mipmap.close_eyes);
                    et_password.setTransformationMethod(PasswordTransformationMethod
                            .getInstance());
                }
                isShowPassword = !isShowPassword;
                et_password.setSelection(et_password.getText().toString().length());
                break;
            //忘记密码
            case R.id.tv_forget_password:
                Intent intent = new Intent();
                intent.putExtra("toRegister",1);
                intent.setClass(LoginActivity.this, SX_RegisterActivityV2.class);
                myStartActivity(intent);
                break;
            //登录
            case R.id.bt_login:
                if(isPwLogin){
                    String publicKey = UtilSP.getPublicKey();
                    if (TextUtils.isEmpty(publicKey)) {
                        requestPubKey(true);
                    } else {
                        requestLoginPubKey(et_username.getText().toString().trim(), et_password.getText().toString().trim());
                    }
                }else {
                    confirmationCodeLogin(et_username.getText().toString().trim(), et_password.getText().toString().trim());
                }
                break;
        }
    }

    /**
     * 选择登录方式，显示UI
     * @param isPasswordLogin 是否是密码登录
     */
    private void selectLoginMode(boolean isPasswordLogin){
        isPwLogin = isPasswordLogin;
        if(isPasswordLogin){
            tv_password_login.setTextColor(getResources().getColor(R.color.c_183029));
            tv_vcode_login.setTextColor(getResources().getColor(R.color.c_7f848d));
            et_username.setText("");
            et_password.setText("");
            et_password.setHint("请输入密码");
            bt_login.setText("登录");
            //输入类型为密码
            et_password.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
            //解决密码间距问题
            et_password.setTypeface(Typeface.DEFAULT);
            et_password.setTransformationMethod(new PasswordTransformationMethod());
            tv_forget_password.setVisibility(View.VISIBLE);
            isShowPassword = false;
            iv_see_password.setImageResource(R.mipmap.close_eyes);
            iv_see_password.setVisibility(View.VISIBLE);
            tv_password_or_vcode.setText("密码");
            tv_get_vcode.setVisibility(View.GONE);
            et_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
            //监听密码输入框变化，控制登录按钮颜色，是否可点击
            TextChangedListenerUtil.textChanged(et_password,LoginActivity.this,bt_login,minLength,maxLength);

        }else{
            tv_password_login.setTextColor(getResources().getColor(R.color.c_7f848d));
            tv_vcode_login.setTextColor(getResources().getColor(R.color.c_183029));
            et_username.setText("");
            et_password.setText("");
            et_password.setHint("请输入验证码");
            //输入类型为数字文本
            et_password.setInputType(InputType.TYPE_CLASS_NUMBER);
            tv_forget_password.setVisibility(View.INVISIBLE);
            isShowPassword = false;
            iv_see_password.setImageResource(R.mipmap.close_eyes);
            iv_see_password.setVisibility(View.GONE);
            tv_password_or_vcode.setText("验证码");
            bt_login.setText("验证并登录");
            tv_get_vcode.setVisibility(View.VISIBLE);
            et_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            //监听密码输入框变化，控制登录按钮颜色，是否可点击
            TextChangedListenerUtil.textChanged(et_password,LoginActivity.this,bt_login,4,6);
        }
    }

    /**
     * 获取登录pubkey
     *
     * @param username 用户名
     * @param password 密码
     */
    private void requestLoginPubKey(final String username, final String password) {
        if (UtilString.isBlank(username) || UtilString.isBlank(password)) {
            return;
        }
        if (!UtilString.isPhoneNum(username)) {
            shortToast("手机号格式不对，请重新输入");
            return;
        }
        RequestParams params = new RequestParams();
        params.put("phoneNum", username);
        try {
            if (null != dialog && !isFinishing()) {
                dialog.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.login_genLoginKey), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2===genLoginKey======>" + new String(arg2));
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                        printi("songxin", "genLoginKey==============>" + jsonBeans.get(0).getString("publicKey"));
                        mLoginKey = jsonBeans.get(0).getString("loginKey");
                        String doctorId = jsonBeans.get(0).getString("doctorId");
                        requestLogin(doctorId, password, mLoginKey, username);
                        return;
                    }
                }
                dismiss();
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                dismiss();
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LoginActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    /**
     * 登录成功后保存信息获取患者列表
     *
     * @param result_bean
     * @param username
     */
    private void loginSuccessSaveInfo(XCJsonBean result_bean, String username) {
        List<XCJsonBean> jsonBeans = result_bean.getList("data");
        if (jsonBeans != null && jsonBeans.size() > 0) {
            UtilSP.putUserId(jsonBeans.get(0).getString("doctorId"));
            UtilSP.putUserToken(jsonBeans.get(0).getString("token"));
            //UtilSP.setUserName(username);//这个 username是个手机号不是医生名
            UtilSP.setUserPhone(username);//设置页要用一下
            UtilSP.putLogin(true);
//                        UtilSP.setStatus(jsonBeans.get(0).getString("status"));
            //登陆成功之后服务器返回是否第一次登陆的值
            UtilSP.setFirstFlag(jsonBeans.get(0).getString("firstFlag"));
            UtilSP.setInitNotice(UtilSP.INIT_NOTICE_NO);
            // add by xjs on 20151211 start
            // 修复JIRA上1383的BUG。因为在“个人资料”页中使用的医生认证状态的SP的名为“authStatus”,所以增加此行代码。
            UtilSP.setAuthStatus(jsonBeans.get(0).getString("status"));
            // add by xjs on 20151211 end
            dShortToast(jsonBeans.get(0).getString("doctorId") + "---登录成功，doctorId");
            String deviceFlag = UtilString.isBlank(jsonBeans.get(0).getString("deviceFlag")) ? "1" : jsonBeans.get(0).getString("deviceFlag");
            if ("0".equals(deviceFlag)) {
                new Thread(new Runnable() {
                    public void run() {
                        // add by xjs on 20160516 start
                        // 如果两次登录的设备不同，则要清除“咨询列表DB”及“咨询详情DB”当中的表内容
                        // 先清除“咨询详情DB”
                        //----------------zhangpengfie 2016-07-11 add-----------
                        GlobalConfigSP.putMD5PatientListJson(""); //清除患者列表MD5
                        //----------------zhangpengfie 2016-07-11 end-----------
                        String doctorId = UtilSP.getUserId();
                        ArrayList<JS_ChatListModel> chatListModelObj = JS_ChatListDB.getInstance(LoginActivity.this, doctorId).getAllRecord();
                        int size = chatListModelObj.size();
                        for (int i = 0; i < size; i++) {
                            String patientId = chatListModelObj.get(i).getUserPatient().getPatientId();
                            if (!TextUtils.isEmpty(patientId)) {
                                XCChatModelDb chatDao = XCChatModelDb.getInstance(getApplicationContext(), UtilSP.getIMDetailDbName(doctorId, patientId));
                                chatDao.deleteAll();
                            }
                        }

                        // 再清除“咨询列表DB”
                        JS_ChatListDB.getInstance(LoginActivity.this, doctorId).removeAllRecord();
                        // add by xjs on 20160516 end
                        //清楚首页未读系统消息 add by xd start
                        UtilSP.setSystemMessage("");
                        UtilSP.setLateTitle("");
                        UtilSP.setNoticeDot(false);
                        //add by xd 20180808 end
                        handler.sendEmptyMessage(DEVICE_OVER);
                    }
                }).start();
            } else {
                handler.sendEmptyMessage(DEVICE_OVER);
            }
        }
    }

    /**
     * 请求登陆接口
     *
     * @param checkDoctorId 校验doctorId
     * @param loginKey      手机号获取登录key
     * @param password      密码
     */
    public void requestLogin(String checkDoctorId, String password, String loginKey, final String username) {
        //发送请求
        RequestParams params = new RequestParams();
        params.put("doctorId", checkDoctorId);
        params.put("loginKey", loginKey);
        params.put("password", UtilRSA.encryByRSA(UtilSP.getPublicKey(), password));
        //设备唯一标识
        params.put("deviceSN", GlobalConfigSP.getDeviceId(this));
        //成功进入填写注册信息
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.login_login), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2===login======>" + new String(arg2));
                if (result_boolean) {
                    loginSuccessSaveInfo(result_bean, username);
                }
                dismiss();
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                dismiss();
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LoginActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    /**
     * 请求登录公钥
     *
     * @param needLogin 是否登录
     */
    private void requestPubKey(final boolean needLogin) {
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.login_getPublicKey), new RequestParams(), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2===regist======>" + new String(arg2));
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                        printi("songxin", "PublicKey==============>" + jsonBeans.get(0).getString("publicKey"));

                        UtilSP.putPublicKey(jsonBeans.get(0).getString("publicKey"));
                        if (needLogin) {
                            requestLoginPubKey(et_username.getText().toString().trim(), et_password.getText().toString().trim());
                        } else {

                        }
                    }
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LoginActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    /**
     * 得到患者列表
     */
    public void requestPatientABC() {
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.patient_my), new RequestParams(), new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, final byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean != null) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                String oldJson = GlobalConfigSP.getMD5PatientListJson();
                                String newJson = UtilMd5.MD5Encode(new String(arg2));
                                //比对上次患者列表json和新获得的患者列表json数据,相等不进行存库操作
                                if (!newJson.equals(oldJson)) {
                                    ArrayList<XC_ChatModel> xc_chatModels = new ArrayList();
                                    Parse2PatientBean.parse(xc_chatModels, result_bean);
                                    GlobalConfigSP.putMD5PatientListJson(newJson);
                                    UtilSP.setPatientSum(xc_chatModels.size() + "");
                                    //更新数据库
                                    JS_ChatListDB.getInstance(LoginActivity.this, UtilSP.getUserId()).insertAllChatInfo(xc_chatModels);
                                }
                                handler.sendEmptyMessage(CLOSE_DIALOG);
                            }
                        }).start();
                        return;
                    }
                }
                // 接口请求业务成功时的处理
                handler.sendEmptyMessage(PATIENT_REQUEST_ERRO);

            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                handler.sendEmptyMessage(PATIENT_REQUEST_ERRO);
            }

            public void onFinish() {
                super.onFinish();
                dismiss();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LoginActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 关闭dialog
     * 对对话框的关闭做统一处理,防止页面销毁后出现关闭对话框的情况
     * add by 马杨茗 on 20160520 pm
     */
    public void dismiss() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }


    private MyHandler handler = new MyHandler(LoginActivity.this);

    private class MyHandler extends Handler {
        WeakReference<LoginActivity> weakReference;

        public MyHandler(LoginActivity loginActivity) {
            weakReference = new WeakReference<>(loginActivity);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case CLOSE_DIALOG:
                    //测试 登录成功
                    qcloudTLSGetUserSig();
                    Intent intent = new Intent(LoginActivity.this, JS_MainActivity.class);
                    intent.putExtra(JS_MainActivity.FROM_PAGE, JS_MainActivity.FROM_LOGIN);
                    myStartActivity(intent);
                    finish();
                    break;
                case DEVICE_OVER:
                    requestPatientABC();
                    break;
                case PATIENT_REQUEST_ERRO:
                    dismiss();
                    qcloudTLSGetUserSig();
                    intent = new Intent(LoginActivity.this, JS_MainActivity.class);
                    intent.putExtra(JS_MainActivity.FROM_PAGE, JS_MainActivity.FROM_LOGIN);
                    intent.putExtra(JS_MainActivity.PATIENT_REQUEST, JS_MainActivity.PATIENT_REQUEST_ERRO);
                    myStartActivity(intent);
                    finish();
                    break;
            }
        }
    }


    /**
     * 自主账号独立模式管理
     * 获取userSig
     */
    private void qcloudTLSGetUserSig() {
        //发送请求
        RequestParams params = new RequestParams();
        params.put("userId", "dr_" + UtilSP.getUserId());
        params.put("appId", Constants.SDK_APPID);

        XCHttpAsyn.postAsyn(false, this, AppConfig.getChatUrl(AppConfig.get_sig), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    final List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                        //登录腾讯IM模块
                        LoginHelper.getLoginHelper(DBApplication.getInstance()).imLogin("dr_" + UtilSP.getUserId(), jsonBeans.get(0).getString("sig"));
                        //登录成功之后存usersig
                        UtilSP.setUserSig(jsonBeans.get(0).getString("sig"));
                    }
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LoginActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    /***
     * 开始倒计时60s
     */
    private void startTimer() {
        tv_get_vcode.setEnabled(false);
        mTask = new TimerTask() {
            @Override
            public void run() {

                runOnUiThread(new Runnable() { // UI thread
                    @Override
                    public void run() {
                        if (mTime <= 0) {
                            tv_get_vcode.setEnabled(true);
                            tv_get_vcode.setText("重新获取");
                            tv_get_vcode.setTextColor(getResources().getColor(R.color.c_395998));
                            mTask.cancel();
                        } else {
                            tv_get_vcode.setText(mTime + "s后重新获取");
                            tv_get_vcode.setTextColor(getResources().getColor(R.color.c_7f848d));
                        }
                        mTime--;
                    }
                });
            }
        };
        mTime = 60;
        mTimer.schedule(mTask, 0, 1000);
    }

    /**
     * 结束倒计时调用
     */
    private void stopTimer() {
        if (null != mTimer) {
            mTimer.purge();
            mTimer.cancel();
        }
    }

    /**
     * 请求验证码
     *
     * @param phoneNumber :医生输入手机号码
     * @param actionType  ：功能类型(1/注册；2/忘记密码；3/修改手机号；4/修改密码；/5.获取验证码；/6新需求，没有注册的手机号收不到验证码)
     */
    private void requestVcode(final String phoneNumber, String actionType, String currentTime) {
        if (UtilString.isBlank(phoneNumber)) {
            shortToast("手机号不能为空！");
            return;
        }
        //发送请求
        RequestParams params = new RequestParams();
        params.put("phoneNum", phoneNumber);
        params.put("actionType", actionType);
        params.put("t", currentTime);
        params.put("sign", UtilMd5.MD5Encode("actionType=" + actionType + "&phoneNum=" + phoneNumber + "&t=" + currentTime + AppConfig.SECRET_KEY));

        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.sendSms), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    startTimer();
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                //如果未注册，跳转注册
                if (null != result_bean && "30106".equals(getCode())) {
                    showNoRegisterDialog();
                } else if (null != result_bean && GeneralReqExceptionProcess.checkCode(LoginActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    private void getCurtentTime(final String username) {
        try {
            //发送请求
            RequestParams params = new RequestParams();
            XCHttpAsyn.postAsyn(false, LoginActivity.this, AppConfig.getHostUrl(AppConfig.get_time), params, new XCHttpResponseHandler() {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if (result_boolean) {
                        long time = ((List<Long>) result_bean.get("data")).get(0);
                        requestVcode(username, "6", time + "");
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取验证码时检测到手机号未注册，弹出提示dialog
     */
    public void showNoRegisterDialog() {
        if (mCustomDialog == null) {
            mCustomDialog = new YR_CommonDialog(this, "该手机号未注册，是否立即注册？", "不了", "好的") {
                @Override
                public void confirmBtn() {
                    mCustomDialog.dismiss();

                    Intent intent = new Intent();
                    intent.putExtra("USERNAME", et_username.getText().toString().trim());
                    intent.putExtra("toRegister", 0);
                    intent.setClass(LoginActivity.this, SX_RegisterActivityV2.class);
                    myStartActivity(intent);
                    finish();
                }
            };
        }
        mCustomDialog.show();
    }

    private void confirmationCodeLogin(final String username, String verifyCode) {
        //发送请求
        RequestParams params = new RequestParams();
        params.put("phoneNum", username);
        params.put("verifyCode", verifyCode);
        //设备唯一标识
        params.put("deviceSN", GlobalConfigSP.getDeviceId(this));
        try {
            if (null != dialog && !isFinishing()) {
                dialog.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.validLogin), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2===confirmationCodeLogin======>" + new String(arg2));
                if (result_boolean) {
                    loginSuccessSaveInfo(result_bean, username);
                }
                dismiss();
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                dismiss();
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LoginActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        UtilInputMethod.hiddenInputMethod(LoginActivity.this);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopTimer();
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(dialog, mCustomDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
    }
}
