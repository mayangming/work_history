package com.qlk.ymz.activity;


import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;

import java.io.File;

/**
 * 视频播放
 */
public class XC_VideoActivity extends XCBaseActivity implements MediaPlayer.OnErrorListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnPreparedListener {
    private static Handler handler = new Handler();
    private SurfaceView surface_view;
    private SurfaceHolder surface_holder;
    private MediaPlayer player;
    private Uri uri;
    private int seekToWhenPreparedFinished;
    private boolean isPrepared;
    private boolean isPause;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xc_l_activity_chat_video);
        super.onCreate(savedInstanceState);
    }

    public void initSurfaceView() {
        surface_view = (SurfaceView) findViewById(R.id.surface_view);
        surface_view.setFocusable(true);
        surface_view.setFocusableInTouchMode(true);
        surface_holder = surface_view.getHolder();
        surface_holder.setFormat(PixelFormat.RGBA_8888);
        surface_holder.addCallback(new Callback() {
            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                release();
            }

            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                launchMediaPlayer(uri);
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        printi("videoActivity--onResume");
        recoverState();
    }

    @Override
    protected void onPause() {
        super.onPause();
        printi("videoActivity--onPause");
        saveState();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        printi("videoActivity--onDestroy");
    }


    @Override
    public void initWidgets() {
        uri = interceptUri();
        initSurfaceView();
    }

    @Override
    public void listeners() {
    }

    @Override
    public void onNetRefresh() {
    }

    public void launchMediaPlayer(Uri uri) {
        try {
            if (uri == null) {
                return;
            }

            if (player == null) {
                player = new MediaPlayer();
            }

            seekToWhenPreparedFinished = 0;
            isPrepared = false;
            isPause = false;

            player.reset();
            player.setDataSource(getApplicationContext(), uri);
            surface_holder = surface_view.getHolder();
            player.setDisplay(surface_holder);
            player.setScreenOnWhilePlaying(true);
            player.setLooping(false);
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            addMediaPlayerListener();
            player.prepareAsync();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addMediaPlayerListener() {
        if (player != null) {
            player.setOnPreparedListener(this);
            player.setOnCompletionListener(this);
            player.setOnErrorListener(this);
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        XCApplication.base_log.debugShortToast("onError");
        release();

//        XCApplication.base_log.i(uri.toString());///storage/emulated/0/app_ymz/chat/moive/video_6355725216726288632.mp4
//        XCApplication.base_log.i(uri.getPath());///storage/emulated/0/app_ymz/chat/moive/video_6355725216726288632.mp4
//        XCApplication.base_log.i(new File(uri.toString()).exists() + ""); //true
//        XCApplication.base_log.i(new File(uri.getPath()).exists() + "");//true

        if (uri != null) {
            // 可能文件损坏,删除
            try {
                File file = new File(uri.getPath());
                if (file.exists()) {
                    file.delete();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return false;
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        isPause = true;
        seekToWhenPreparedFinished = 0;

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                start();
            }
        }, 700);
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        isPrepared = true;
        player.seekTo(seekToWhenPreparedFinished);
        if (!isPause) {
            start();
        }
    }

    public void saveState() {
        if (player != null && isPrepared) {
            player.pause();
            if (seekToWhenPreparedFinished != 0) {
                seekToWhenPreparedFinished = player.getCurrentPosition();
            }
        }
    }

    public void recoverState() {
        if (player != null && isPrepared) {
            if (!isPause) {
                player.seekTo(seekToWhenPreparedFinished);
                player.start();
            }
        }
    }

    public void release() {
        if (player != null) {
            player.stop();
            player.reset();
            player.release();
            player = null; // 没这句就报错,why?
        }
    }

    private void start() {
        if (player != null && isPrepared) {
            player.seekTo(seekToWhenPreparedFinished);
            player.start();
            isPause = false;
        }
    }
}
