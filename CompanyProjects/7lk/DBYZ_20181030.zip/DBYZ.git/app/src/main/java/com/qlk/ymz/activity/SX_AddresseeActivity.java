package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_AddresseeAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.AddresseeInfoBean;
import com.qlk.ymz.model.PatientGroupBean;
import com.qlk.ymz.parse.Parse2PatientGroupBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * SX_AddresseeActivity
 * 收件人选择
 * @author songxin on 2017/3/27.
 * @version 2.7.0
 */
public class SX_AddresseeActivity extends DBActivity {
    /** title*/
    private XCTitleCommonLayout titleCommonFragment;
    /** 收件人数据集合*/
    private List<AddresseeInfoBean> addresseeInfoBeenList = new ArrayList<>();
    /** 患者分组列表数据*/
    private List<PatientGroupBean> patientGroupBeenList = new ArrayList<>();
    private List<PatientGroupBean> patientGroupBeenList2 = new ArrayList<>();
    /**  个别患者集合*/
    private List<XC_ChatModel> currentChoosePatientBean = new ArrayList<>();
    /** 患者可扩展列表刷新 */
    private ExpandableListView re_fragment_search_slide_listview;
    /** 收件人列表适配器 */
    private SX_AddresseeAdapter sx_addresseeAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_addressee);
        super.onCreate(savedInstanceState);
        //获取分组列表
        requestPatientGroupList(true);
    }

    /** created by songxin,date：2017-4-10,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_AddresseeActivity.class);
    }

    /** created by songxin,date：2016-4-10,about：bi,end */

    /**
     * 数据装配
     */
    private void initData(){
        int type = 0;
        Intent intent = getIntent();
        if(intent != null){
            type = intent.getIntExtra("type",0);
        }
        String[] names = {"所有患者","选择的分组能收到","选中的分组收不到","个别选中能收到"};

        for(int i = 0;i < names.length;i++){
            AddresseeInfoBean addresseeInfoBean = new AddresseeInfoBean();
            addresseeInfoBean.setAddresseeName(names[i]);
            switch (i){
                //所有患者
                case 0:{
                    addresseeInfoBean.setAddresseeType(AddresseeInfoBean.ALL_PATIENTS);
                    if(type == AddresseeInfoBean.ALL_PATIENTS){
                        addresseeInfoBean.setChoose(true);
                    }else {
                        addresseeInfoBean.setChoose(false);
                    }
                    break;
                }
                //选择的分组能收到
                case 1:{
                    if(patientGroupBeenList.size() > 0){
                        List<PatientGroupBean> currentPatientGroupBeenList = new ArrayList<>();
                        currentPatientGroupBeenList.addAll(patientGroupBeenList);
                        addresseeInfoBean.setAddresseeType(AddresseeInfoBean.CAN_RECEIVE);
                        addresseeInfoBean.setPatientGroupBeen(currentPatientGroupBeenList);
                        if(type == AddresseeInfoBean.CAN_RECEIVE){
                            addresseeInfoBean.setChoose(true);
                            List<PatientGroupBean> currentPatientGroupBeanList = (List<PatientGroupBean>)intent.getSerializableExtra("patientGroupBeanList");
                            if(null != currentPatientGroupBeanList && currentPatientGroupBeanList.size() > 0){
                                for(PatientGroupBean patientGroupBean : currentPatientGroupBeenList){
                                    for(PatientGroupBean currentPatientGroupBean :currentPatientGroupBeanList){
                                        if(currentPatientGroupBean.getId().equals(patientGroupBean.getId())){
                                            patientGroupBean.setChoose(true);
                                        }
                                    }
                                }
                            }
                        }else {
                            addresseeInfoBean.setChoose(false);
                        }
                    }
                    break;
                }
                //选中的分组收不到
                case 2:{
                    if(patientGroupBeenList.size() > 0){
                        List<PatientGroupBean> currentPatientGroupBeenList = new ArrayList<>();
                        currentPatientGroupBeenList.addAll(patientGroupBeenList2);
                        addresseeInfoBean.setAddresseeType(AddresseeInfoBean.CANNOT_RECEIVE);
                        addresseeInfoBean.setPatientGroupBeen(currentPatientGroupBeenList);
                        if(type == AddresseeInfoBean.CANNOT_RECEIVE){
                            addresseeInfoBean.setChoose(true);
                            List<PatientGroupBean> currentPatientGroupBeanList = (List<PatientGroupBean>)intent.getSerializableExtra("patientGroupBeanList");
                            if(null != currentPatientGroupBeanList && currentPatientGroupBeanList.size() > 0){
                                for(PatientGroupBean patientGroupBean : currentPatientGroupBeenList){
                                    for(PatientGroupBean currentPatientGroupBean :currentPatientGroupBeanList){
                                        if(currentPatientGroupBean.getId().equals(patientGroupBean.getId())){
                                            patientGroupBean.setChoose(true);
                                        }
                                    }
                                }
                            }
                        }else {
                            addresseeInfoBean.setChoose(false);
                        }
                    }
                    break;
                }
                //个别分组收到
                case 3:{
                    addresseeInfoBean.setAddresseeType(AddresseeInfoBean.INDIVIDUAL);
                    if(type == AddresseeInfoBean.INDIVIDUAL){
                        addresseeInfoBean.setChoose(true);
                    }else {
                        addresseeInfoBean.setChoose(false);
                    }
                    List<XC_ChatModel> currentChoosePatientBeanList = (List<XC_ChatModel>)intent.getSerializableExtra("currentChoosePatientBeanList");
                    currentChoosePatientBean.clear();
                    if(null != currentChoosePatientBeanList && currentChoosePatientBeanList.size() > 0){
                        currentChoosePatientBean.addAll(currentChoosePatientBeanList);
                    }
                    break;
                }
                default:{
                    break;
                }
            }
            addresseeInfoBeenList.add(addresseeInfoBean);
            printi("http","addresseeInfoBeenList.size-->"+addresseeInfoBeenList.size());
        }
        sx_addresseeAdapter = new SX_AddresseeAdapter(addresseeInfoBeenList,SX_AddresseeActivity.this,re_fragment_search_slide_listview);
        re_fragment_search_slide_listview.setAdapter(sx_addresseeAdapter);
        //如果有已选中，展开已选中的子项，仅限于CAN_RECEIVE，CANNOT_RECEIVE
        for(int i = 0; i < addresseeInfoBeenList.size(); i++){
            if(addresseeInfoBeenList.get(i).isChoose()){
                if(addresseeInfoBeenList.get(i).getAddresseeType() == AddresseeInfoBean.CANNOT_RECEIVE ||
                        addresseeInfoBeenList.get(i).getAddresseeType() == AddresseeInfoBean.CAN_RECEIVE){
                    re_fragment_search_slide_listview.expandGroup(i);
                    break;
                }
            }
        }
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        titleCommonFragment = getViewById(R.id.xc_id_model_titlebar);
        titleCommonFragment.setTitleLeft(true, "");
        titleCommonFragment.setTitleRight2(true, 0,"完成");
        titleCommonFragment.setTitleCenter(true,"收件人");
        re_fragment_search_slide_listview = getViewById(R.id.re_fragment_search_slide_listview);
    }

    @Override
    public void listeners() {
        titleCommonFragment.getXc_id_titlebar_right2_textview().setOnClickListener(this);

        re_fragment_search_slide_listview.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                printi("http","position--------->"+groupPosition);
                if(groupPosition == 0){
                    addresseeInfoBeenList.get(0).setChoose(true);
                    addresseeInfoBeenList.get(1).setChoose(false);
                    addresseeInfoBeenList.get(2).setChoose(false);
                    addresseeInfoBeenList.get(3).setChoose(false);

                }else if(groupPosition == 1){
                    if(addresseeInfoBeenList.get(1).getPatientGroupBeen().size() == 0){
                        shortToast("请到患者列表页，先对患者分组");
                        addresseeInfoBeenList.get(0).setChoose(true);
                        addresseeInfoBeenList.get(1).setChoose(false);
                    }else {
                        addresseeInfoBeenList.get(0).setChoose(false);
                        addresseeInfoBeenList.get(1).setChoose(true);

                    }
                    addresseeInfoBeenList.get(2).setChoose(false);
                    addresseeInfoBeenList.get(3).setChoose(false);

                }else if(groupPosition == 2){
                    if(addresseeInfoBeenList.get(2).getPatientGroupBeen().size() == 0){
                        shortToast("请到患者列表页，先对患者分组");
                        addresseeInfoBeenList.get(0).setChoose(true);
                        addresseeInfoBeenList.get(2).setChoose(false);
                    }else {
                        addresseeInfoBeenList.get(0).setChoose(false);
                        addresseeInfoBeenList.get(2).setChoose(true);
                    }
                    addresseeInfoBeenList.get(1).setChoose(false);
                    addresseeInfoBeenList.get(3).setChoose(false);

                }else if(groupPosition == 3){
                    addresseeInfoBeenList.get(0).setChoose(false);
                    addresseeInfoBeenList.get(1).setChoose(false);
                    addresseeInfoBeenList.get(2).setChoose(false);
                    addresseeInfoBeenList.get(3).setChoose(true);
                    Intent intent = new Intent();
                    if(currentChoosePatientBean.size() > 0){
                        intent.putExtra("currentChoosePatientBean",(Serializable) currentChoosePatientBean);
                    }
                    intent.setClass(SX_AddresseeActivity.this, SX_ChoosePatientActivity.class);
                    myStartActivityForResult(intent,0);

                }
                //清掉组内所有选择
                for(AddresseeInfoBean addresseeInfoBean : addresseeInfoBeenList){
                    if(!addresseeInfoBean.isChoose()){
                        for(PatientGroupBean patientGroupBean : addresseeInfoBean.getPatientGroupBeen()){
                            patientGroupBean.setChoose(false);
                        }
                    }
                }
                sx_addresseeAdapter.notifyDataSetChanged();
                return false;
            }
        });

        re_fragment_search_slide_listview.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                printi("http","gposition--------->"+groupPosition+"cposition--------->"+childPosition);
                boolean isChoose = addresseeInfoBeenList.get(groupPosition).getPatientGroupBeen().get(childPosition).isChoose();
                addresseeInfoBeenList.get(groupPosition).getPatientGroupBeen().get(childPosition).setChoose(!isChoose);
                sx_addresseeAdapter.notifyDataSetChanged();
                return true;
            }
        });


    }

    /** 获得分组列表
     * @param isDialog 是否显示进度条
     * */
    public void  requestPatientGroupList(boolean isDialog) {
        XCHttpAsyn.postAsyn(isDialog, this, AppConfig.getHostUrl(AppConfig.batch_group_list), new RequestParams(), new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<XCJsonBean> result_list = result_bean.getList("data");
                    if (result_list != null) {
                        //解析患者分组列表数据
                        Parse2PatientGroupBean parse2PatientGroupBean = new Parse2PatientGroupBean();
                        patientGroupBeenList.addAll(parse2PatientGroupBean.parse(result_bean));
                        patientGroupBeenList2.addAll(parse2PatientGroupBean.parse(result_bean));
                        //初始化数据
                        initData();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_AddresseeActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 去选择联系人界面之后返回数据
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == 0){
            if(data != null){
                currentChoosePatientBean.clear();
                currentChoosePatientBean.addAll((List<XC_ChatModel>)data.getSerializableExtra("ChoosePatientBeanList"));
                if(null != currentChoosePatientBean && currentChoosePatientBean.size() > 0){
                    for(XC_ChatModel choosePatientBean : currentChoosePatientBean){
                        printi("http","choosePatientBean---------->"+choosePatientBean.getUserPatient().getPatientName());
                    }
                }
            }
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.xc_id_titlebar_right2_textview:{
                Intent intent = new Intent();
                List<PatientGroupBean> currentPatientGroupBeanList = new ArrayList<>();
                //遍历数据，根据不同选择发送不同数据到编辑群发页面
                for(AddresseeInfoBean addresseeInfoBean :addresseeInfoBeenList){
                    //先判断几项中哪项被选中
                    if(addresseeInfoBean.isChoose()){
                        //被选中的type放到intent里面
                        intent.putExtra("type",addresseeInfoBean.getAddresseeType());
                        //判断被选中的type,如果是全部患者，不传值，编辑群发页面直接取医生id
                        if(addresseeInfoBean.getAddresseeType() == AddresseeInfoBean.ALL_PATIENTS){
                            // created by songxin,date：2017-4-10,about：saveInfo,begin
                            BiUtil.saveBiInfo(SX_AddresseeActivity.class, "2", "128", "ALL_PATIENTS","", false);
                            // created by songxin,date：2017-4-10,about：saveInfo,end
                            break;
                        //如果是能收到的患者组，传入能收到患者组下面被选中的组bean
                        }else if(addresseeInfoBean.getAddresseeType() == AddresseeInfoBean.CAN_RECEIVE){
                            // created by songxin,date：2017-4-10,about：saveInfo,begin
                            BiUtil.saveBiInfo(SX_AddresseeActivity.class, "2", "128", "CAN_RECEIVE","", false);
                            // created by songxin,date：2017-4-10,about：saveInfo,end
                            //遍历患者分组，找到被选中的分组
                            for(PatientGroupBean patientGroupBean : addresseeInfoBean.getPatientGroupBeen()){
                                if(patientGroupBean.isChoose()){
                                    currentPatientGroupBeanList.add(patientGroupBean);
                                }
                            }
                            if(currentPatientGroupBeanList.size() == 0){
                                shortToast("请至少选择一个分组");
                                return;
                            }
                            intent.putExtra("patientGroupBeanList",(Serializable)currentPatientGroupBeanList);
                            break;
                        //如果是不能收到的患者组，传入不能收到患者组下面被选中的组bean
                        }else if(addresseeInfoBean.getAddresseeType() == AddresseeInfoBean.CANNOT_RECEIVE){
                            // created by songxin,date：2017-4-10,about：saveInfo,begin
                            BiUtil.saveBiInfo(SX_AddresseeActivity.class, "2", "128", "CANNOT_RECEIVE","", false);
                            // created by songxin,date：2017-4-10,about：saveInfo,end
                            //遍历患者分组，找到被选中的分组
                            for(PatientGroupBean patientGroupBean : addresseeInfoBean.getPatientGroupBeen()){
                                if(patientGroupBean.isChoose()){
                                    currentPatientGroupBeanList.add(patientGroupBean);
                                }
                            }
                            if(currentPatientGroupBeanList.size() == 0){
                                shortToast("请至少选择一个分组");
                                return;
                            }
                            intent.putExtra("patientGroupBeanList",(Serializable)currentPatientGroupBeanList);
                            break;
                        //如果是个别患者组，传入个别患者组下面被选中的组bean
                        }else if(addresseeInfoBean.getAddresseeType() == AddresseeInfoBean.INDIVIDUAL){
                            // created by songxin,date：2017-4-10,about：saveInfo,begin
                            BiUtil.saveBiInfo(SX_AddresseeActivity.class, "2", "128", "INDIVIDUAL","", false);
                            // created by songxin,date：2017-4-10,about：saveInfo,end
                            if(currentChoosePatientBean.size() == 0){
                                shortToast("请至少选择一个患者");
                                return;
                            }
                            intent.putExtra("currentChoosePatientBeanList",(Serializable)currentChoosePatientBean);
                            break;
                        }
                    }
                }
                setResult(1,intent);
                finish();
                break;
            }
        }
    }
}
