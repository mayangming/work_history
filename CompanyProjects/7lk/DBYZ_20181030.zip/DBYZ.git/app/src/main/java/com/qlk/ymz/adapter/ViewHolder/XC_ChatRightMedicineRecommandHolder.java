package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.view.XCNoScrollListview;


public class XC_ChatRightMedicineRecommandHolder extends XC_ChatRightBaseHolder {

    public LinearLayout sk_id_medichine_rl;
    public XCNoScrollListview sk_id_medichine_listview;
    public TextView details;

    public ImageView check_img;
    public TextView check_text;
    public TextView right_show_ellipsis;
    public LinearLayout check_layout;
    public TextView id_right_patient_medicine_show;
    public TextView id_right_patient_medicine_recommend_again;
    public TextView medicine_invalid_tv;
    public XC_ChatRightMedicineRecommandHolder(View convertView) {
        super(convertView);
        sk_id_medichine_rl = (LinearLayout) convertView.findViewById(R.id.sk_id_medichine_rl);
        sk_id_medichine_listview = (XCNoScrollListview) convertView.findViewById(R.id.sk_id_medichine_listview);
        details = (TextView) convertView.findViewById(R.id.details);
        check_img = (ImageView) convertView.findViewById(R.id.check_img);
        check_text = (TextView) convertView.findViewById(R.id.check_text);
        right_show_ellipsis = (TextView) convertView.findViewById(R.id.right_show_ellipsis);
        check_layout = (LinearLayout) convertView.findViewById(R.id.check_layout);
        id_right_patient_medicine_show = (TextView) convertView.findViewById(R.id.id_right_patient_medicine_show);
        id_right_patient_medicine_recommend_again = (TextView) convertView.findViewById(R.id.id_right_patient_medicine_recommend_again);
        medicine_invalid_tv = (TextView) convertView.findViewById(R.id.medicine_invalid_tv);
    }
}