package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.UtilPackMsg;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.util.List;

/**
 * SX_SessionEndActivity
 * 会话结束页面
 * 2.6.5统一dialog将结束会话布局修改
 * @author songxin on 2016/1/13.
 * @version 2.0
 */
public class SX_SessionEndActivity extends DBActivity implements View.OnClickListener {

    /** 咨询结束页面icon*/
//    private ImageView sx_id_session_end_icon;
//    /** 咨询结束提示*/
//    private TextView sx_id_session_end_text;
//    /** 咨询结束免单*/
//    private TextView sx_id_free;
//    /** 咨询结束不免单*/
//    private TextView sx_id_not_free;
    /** 关闭结束会话*/
//    private ImageView sx_id_session_end_close;
    private TextView sx_id_session_end_close;
    /** 立即结束会话*/
    private TextView sx_id_immediately_end;
//    private TextView sx_id_immediately_end;
//    /** 立即结束是否免单linear*/
//    private LinearLayout sx_id_whether_free_rl;
    /** 数据模型*/
    private XC_ChatModel mParamsModel = null;
    /** 支付类型*/
    private String mPayType = "";
    /** 会话id*/
    private String mSessionId = "";
    /** 会话开始时间*/
    private String mSessionBeginTime = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 设置布局
        setContentView(R.layout.sx_l_activity_session_end);
        super.onCreate(savedInstanceState);

        // created by songxin,date：2016-4-22,about：saveInfo,begin
        BiUtil.saveBiInfo(SX_SessionEndActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-22,about：saveInfo,end

        mParamsModel = (XC_ChatModel) getIntent().getSerializableExtra(CommonConfig.CHAT_PARAMS_MODEL);

        if (mParamsModel != null) {
            mSessionId = mParamsModel.getSessionId();
            mSessionBeginTime = mParamsModel.getSessionBeginTime();
            mPayType = mParamsModel.getPayMode();
//            if(UtilSP.getIsCharge()){
//                mPayType = "1";
//                sx_id_session_end_text.setText("是否给患者免个单？");
//                sx_id_session_end_icon.setImageResource(R.mipmap.sx_d_session_end_not_free_icon);
//                sx_id_whether_free_rl.setVisibility(View.VISIBLE);
//            }else{
//                sx_id_session_end_text.setText("此次咨询为免费咨询");
//                mPayType = "0";
//                sx_id_session_end_icon.setImageResource(R.mipmap.sx_d_session_end_free_icon);
//                sx_id_whether_free_rl.setVisibility(View.GONE);
//            }
//            requestServierTime();
        }

    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_SessionEndActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    // 无网络时,点击屏幕后回调的方法
    @Override
    public void onNetRefresh() {
    }

    @Override
    public void finish() {
        super.finish();

        overridePendingTransition(R.anim.pop_up, R.anim.pop_down);//不加的话默认页面从左向右划出
    }

    // 初始化控件
    @Override
    public void initWidgets() {
//        sx_id_session_end_icon = getViewById(R.id.sx_id_session_end_icon);
        sx_id_session_end_close = getViewById(R.id.sx_id_session_end_close);
//        sx_id_free = getViewById(R.id.sx_id_free);
//        sx_id_not_free = getViewById(R.id.sx_id_not_free);
//        sx_id_whether_free_rl = getViewById(R.id.sx_id_whether_free_rl);
        sx_id_immediately_end = getViewById(R.id.sx_id_immediately_end);
//        sx_id_session_end_text = getViewById(R.id.sx_id_session_end_text);
    }

    // 设置监听
    @Override
    public void listeners() {
        sx_id_session_end_close.setOnClickListener(this);
//        sx_id_free.setOnClickListener(this);
//        sx_id_not_free.setOnClickListener(this);
        sx_id_immediately_end.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.sx_id_session_end_close: {
                finish();
                break;
            }
//            case R.id.sx_id_free: {
//                // 给患者免单
//                mPayType = "0";
//                sx_id_free.setTextColor(getResources().getColor(R.color.c_blue_2b98f6));
//                sx_id_free.setBackgroundResource(R.mipmap.sx_d_session_end_free_selected);
//                sx_id_not_free.setTextColor(getResources().getColor(R.color.c_gray_666666));
//                sx_id_not_free.setBackgroundResource(R.mipmap.sx_d_session_end_free_default);
//                break;
//            }
//            case R.id.sx_id_not_free: {
//                // 给患者不免单
//                mPayType = "1";
//                sx_id_not_free.setTextColor(getResources().getColor(R.color.c_blue_2b98f6));
//                sx_id_not_free.setBackgroundResource(R.mipmap.sx_d_session_end_free_selected);
//                sx_id_free.setTextColor(getResources().getColor(R.color.c_gray_666666));
//                sx_id_free.setBackgroundResource(R.mipmap.sx_d_session_end_free_default);
//                break;
//            }
            case R.id.sx_id_immediately_end: {
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(SX_SessionEndActivity.class,"2","128","sx_id_immediately_end","",false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                // 立即结束会话
                endSession(mSessionId, mPayType);
                break;
            }
            default: {
                break;
            }
        }
    }

    public static final String SESSION_END_MODEL = "session_end_model";

    private void endSession(String sessionId, String payType) {
        //发送请求
        RequestParams params = new RequestParams();
        params.put("sessionId", sessionId);
        // modify by jingyu 2016.5.4 17:10 以下
        // params.put("freeFlag", payType);
        // 与东强沟通，传0
        params.put("freeFlag", "0");
        // modify by jingyu 2016.5.4 17:10 以上
        params.put("patientId", mParamsModel.getUserPatient().getPatientId());

        XCHttpAsyn.postAsyn(this, AppConfig.getChatUrl(AppConfig.endSession), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                String currentEndTime = "";
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans != null && jsonBeans.size() > 0) {
                        currentEndTime = jsonBeans.get(0).getString("endTime");
                    }

                    XC_ChatModel sessionEndModel = UtilPackMsg.getSessionEndMsg(getApplicationContext()
                            , mParamsModel.getUserDoctor().getDoctorSelfId()
                            , mParamsModel.getUserPatient().getPatientId()
                            , mSessionId
                            , mSessionBeginTime
                            , mPayType
                            , currentEndTime);

                    Intent intent = new Intent();
                    intent.putExtra(SESSION_END_MODEL,sessionEndModel);

                    setResult(RESULT_OK,intent);

                    finish();

                }

            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_SessionEndActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        stopTimer();
//        Intent intent = new Intent();
//        intent.putExtra("",mCountdownTime);
//        setResult(0,intent);
//        finish();
    }

    // ----------------------------------------add by xc-----------------------------------------

//    /**
//     * 计时器
//     */
//    TimerHelper timer;
//
//    /**
//     * 一天的秒 24*60*60*1000
//     */
//    private long mOneDaySecond = 86400000;
//
//    /**
//     * 服务器时间
//     */
//    private String mServerTime = "0";
//
//    public void requestServierTime() {
//        RequestParams params = new RequestParams();
//        params.put("sessionId", mSessionId);
//        XCHttpAsyn.postAsyn(true, false, this, AppConfig.getChatUrl(AppConfig.serverTimeAndStatus), params, new XCHttpResponseHandler(null) {
//            @Override
//            public void onSuccess(int code, Header[] headers, byte[] arg2) {
//                super.onSuccess(code, headers, arg2);
//                if (result_boolean) {
//                    // 获取服务器的时间成功
//                    List<XCJsonBean> data = result_bean.getList("data");
//                    if (data != null && data.size() > 0) {
//                        XCJsonBean bean = data.get(0);
//                        mServerTime = bean.getString("sysTime");
//                        startTimer();
//                    }
//                }
//            }
//
//            // 不显示失败的土司
//            @Override
//            public void fail() {
//
//            }
//
//            @Override
//            public void onFinish() {
//                super.onFinish();
//                if (!result_boolean) {
//                    // 如果访问失败了，两秒后继续访问
//                    if (!isQuit) {
//                        new Handler().postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                requestServierTime();
//                            }
//                        }, 2000);
//                    }
//                }
//            }
//        });
//    }
//
//    private void stopTimer() {
//        if (timer != null) {
//            timer.cancel();
//            timer = null;
//        }
//    }
//
//    private void startTimer() {
//        // 确定停止
//        stopTimer();
//
//        long serverTime = UtilString.toLong(mServerTime);
//        long sessionBeginTime = UtilString.toLong(mSessionBeginTime);
//        XCApplication.base_log.i("http","serverTime===========>"+serverTime);
//        XCApplication.base_log.i("http","sessionBeginTime===========>"+sessionBeginTime);
//        long surplusTime = mOneDaySecond - (serverTime - sessionBeginTime);
//        XCApplication.base_log.i("http","surplusTime===========>"+surplusTime);
//
//        if (surplusTime <= 0) {
//            // 超过一天了
//            sx_id_whether_free.setClickable(false);
//            sx_id_whether_free.setBackgroundResource(R.mipmap.sx_d_session_end_bg3);
//            sx_id_immediately_end.setClickable(false);
//            sx_id_immediately_end.setBackgroundResource(R.mipmap.sx_d_session_end_bg3);
//            sx_id_session_end_text.setText("咨询已结束");
//        } else {
//            timer = new TimerHelper(surplusTime, new TimerHelper.CustomTimer() {
//                @Override
//                public void onTick(long millisUntilFinished) {
//                    sx_id_session_end_time.setText(DateUtils.DateFormat(millisUntilFinished + "", UtilDate.FORMAT_SHORT_SHORT) + "");
//                }
//
//                @Override
//                public void onFinish() {
//                    sessionFinish();
//                }
//            });
//            timer.start();
//        }
//    }

    public boolean isQuit;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 防止内存泄露
//        stopTimer();
        isQuit = true;
    }
}
