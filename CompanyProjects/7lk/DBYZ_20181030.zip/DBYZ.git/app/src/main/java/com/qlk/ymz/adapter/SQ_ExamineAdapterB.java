package com.qlk.ymz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.SQ_ExamineBModel;

import java.util.List;

/**
 * @author 赖善琦
 * @description
 */
public class SQ_ExamineAdapterB extends RecyclerView.Adapter<SQ_ExamineAdapterB.ExamineBviewHolder> {
    /**
     * 二级分类数据集
     */
    private List<SQ_ExamineBModel> list;
    private Context mContext;

    public SQ_ExamineAdapterB(Context context) {
        mContext = context;
    }

    @Override
    public ExamineBviewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ExamineBviewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.sq_item_inspect_b, parent, false));
    }

    @Override
    public void onBindViewHolder(ExamineBviewHolder holder, int position) {
        SQ_ExamineBModel model = list.get(position);
        holder.sk_id_tv_inspectBtext.setText(model.getName());
        holder.itemView.setTag(model);
        if ("0".equals(model.getState())) {
            holder.itemView.setEnabled(false);
            holder.sk_id_tv_inspectBtext.setTextColor(mContext.getResources().getColor(R.color.c_gray_bbbbbb));
        } else {
            holder.itemView.setEnabled(true);
            holder.sk_id_tv_inspectBtext.setTextColor(mContext.getResources().getColor(R.color.c_grey_444444));
        }
    }

    public void updateAndNotify(List<SQ_ExamineBModel> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if (list != null) return list.size();
        return 0;
    }

    public interface OnClickAction {
        void OnItemClickAction(View view);
    }

    private OnClickAction onClickAction;

    public void setOnClickAction(OnClickAction onClickAction) {
        this.onClickAction = onClickAction;
    }

    class ExamineBviewHolder extends RecyclerView.ViewHolder {
        private TextView sk_id_tv_inspectBtext;
        private View itemView;

        public ExamineBviewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            sk_id_tv_inspectBtext = (TextView) itemView.findViewById(R.id.sk_id_tv_inspectBtext);
            this.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onClickAction != null) onClickAction.OnItemClickAction(v);
                }
            });
        }
    }

}
