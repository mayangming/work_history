package com.qlk.ymz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.List;

/**
 * SX_OutOfTimeActivity
 * 出诊时间页面
 * Created by xilinch on 2015/6/19.
 *
 * Changed by songxin on 2016/3/29.
 * @version 2.0
 */
public class SX_OutOfTimeActivity extends DBActivity {
    /** 周一*/
    private ImageView sx_id_monday_am_choose;
    private ImageView sx_id_monday_pm_choose;
    private ImageView sx_id_monday_night_choose;
    /** 周二*/
    private ImageView sx_id_tuesday_am_choose;
    private ImageView sx_id_tuesday_pm_choose;
    private ImageView sx_id_tuesday_night_choose;
    /** 周三*/
    private ImageView sx_id_wednesday_am_choose;
    private ImageView sx_id_wednesday_pm_choose;
    private ImageView sx_id_wednesday_night_choose;
    /** 周四*/
    private ImageView sx_id_thursday_am_choose;
    private ImageView sx_id_thursday_pm_choose;
    private ImageView sx_id_thursday_night_choose;
    /** 周五*/
    private ImageView sx_id_friday_am_choose;
    private ImageView sx_id_friday_pm_choose;
    private ImageView sx_id_friday_night_choose;
    /** 周六*/
    private ImageView sx_id_saturday_am_choose;
    private ImageView sx_id_saturday_pm_choose;
    private ImageView sx_id_saturday_night_choose;
    /** 周日*/
    private ImageView sx_id_sunday_am_choose;
    private ImageView sx_id_sunday_pm_choose;
    private ImageView sx_id_sunday_night_choose;
    /** title*/
    private XCTitleCommonLayout titlebar;
    /** 控制变量*/
    private boolean is_monday_am_choose = false,is_monday_pm_choose = false,is_monday_night_choose = false,
    is_tuesday_am_choose = false,is_tuesday_pm_choose = false,is_tuesday_night_choose = false,
    is_wednesday_am_choose = false,is_wednesday_pm_choose = false,is_wednesday_night_choose = false,
    is_thursday_am_choose = false,is_thursday_pm_choose,is_thursday_night_choose = false,
    is_friday_am_choose = false,is_friday_pm_choose = false,is_friday_night_choose = false,
    is_saturday_am_choose = false,is_saturday_pm_choose = false,is_saturday_night_choose = false,
    is_sunday_am_choose = false,is_sunday_pm_choose = false,is_sunday_night_choose = false;
    /** 解析内容实例*/
    private List<XCJsonBean> mOutofTimeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_out_of_time);
        super.onCreate(savedInstanceState);
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleCenter(true, "出诊时间");
        titlebar.setTitleRight2(true, 0, "保存");
        //获取出诊时间
        getOutofTimeList();

        titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    saveWorkTime( createJson());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_OutOfTimeActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        sx_id_monday_am_choose = getViewById(R.id.sx_id_monday_am_choose);
        sx_id_monday_pm_choose = getViewById(R.id.sx_id_monday_pm_choose);
        sx_id_monday_night_choose = getViewById(R.id.sx_id_monday_night_choose);

        sx_id_tuesday_am_choose = getViewById(R.id.sx_id_tuesday_am_choose);
        sx_id_tuesday_pm_choose = getViewById(R.id.sx_id_tuesday_pm_choose);
        sx_id_tuesday_night_choose = getViewById(R.id.sx_id_tuesday_night_choose);

        sx_id_wednesday_am_choose = getViewById(R.id.sx_id_wednesday_am_choose);
        sx_id_wednesday_pm_choose = getViewById(R.id.sx_id_wednesday_pm_choose);
        sx_id_wednesday_night_choose = getViewById(R.id.sx_id_wednesday_night_choose);

        sx_id_thursday_am_choose = getViewById(R.id.sx_id_thursday_am_choose);
        sx_id_thursday_pm_choose = getViewById(R.id.sx_id_thursday_pm_choose);
        sx_id_thursday_night_choose = getViewById(R.id.sx_id_thursday_night_choose);

        sx_id_friday_am_choose = getViewById(R.id.sx_id_friday_am_choose);
        sx_id_friday_pm_choose = getViewById(R.id.sx_id_friday_pm_choose);
        sx_id_friday_night_choose = getViewById(R.id.sx_id_friday_night_choose);

        sx_id_saturday_am_choose = getViewById(R.id.sx_id_saturday_am_choose);
        sx_id_saturday_pm_choose = getViewById(R.id.sx_id_saturday_pm_choose);
        sx_id_saturday_night_choose = getViewById(R.id.sx_id_saturday_night_choose);

        sx_id_sunday_am_choose = getViewById(R.id.sx_id_sunday_am_choose);
        sx_id_sunday_pm_choose = getViewById(R.id.sx_id_sunday_pm_choose);
        sx_id_sunday_night_choose = getViewById(R.id.sx_id_sunday_night_choose);

    }

    @Override
    public void listeners() {
        sx_id_monday_am_choose.setOnClickListener(this);
        sx_id_monday_pm_choose.setOnClickListener(this);
        sx_id_monday_night_choose.setOnClickListener(this);
        //周二
        sx_id_tuesday_am_choose.setOnClickListener(this);
        sx_id_tuesday_pm_choose.setOnClickListener(this);
        sx_id_tuesday_night_choose.setOnClickListener(this);
        //周三
        sx_id_wednesday_am_choose.setOnClickListener(this);
        sx_id_wednesday_pm_choose.setOnClickListener(this);
        sx_id_wednesday_night_choose.setOnClickListener(this);
        //周四
        sx_id_thursday_am_choose.setOnClickListener(this);
        sx_id_thursday_pm_choose.setOnClickListener(this);
        sx_id_thursday_night_choose.setOnClickListener(this);
        //周五
        sx_id_friday_am_choose.setOnClickListener(this);
        sx_id_friday_pm_choose.setOnClickListener(this);
        sx_id_friday_night_choose.setOnClickListener(this);
        //周六
        sx_id_saturday_am_choose.setOnClickListener(this);
        sx_id_saturday_pm_choose.setOnClickListener(this);
        sx_id_saturday_night_choose.setOnClickListener(this);
        //周日
        sx_id_sunday_am_choose.setOnClickListener(this);
        sx_id_sunday_pm_choose.setOnClickListener(this);
        sx_id_sunday_night_choose.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {

    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            //周一上午
            case R.id.sx_id_monday_am_choose:{
                is_monday_am_choose = !is_monday_am_choose;
                if(is_monday_am_choose){
                    sx_id_monday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_monday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周一下午
            case R.id.sx_id_monday_pm_choose:{
                is_monday_pm_choose = !is_monday_pm_choose;
                if(is_monday_pm_choose){
                    sx_id_monday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_monday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周一晚上
            case R.id.sx_id_monday_night_choose:{
                is_monday_night_choose = !is_monday_night_choose;
                if(is_monday_night_choose){
                    sx_id_monday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_monday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周二上午
            case R.id.sx_id_tuesday_am_choose:{
                is_tuesday_am_choose = !is_tuesday_am_choose;
                if(is_tuesday_am_choose){
                    sx_id_tuesday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_tuesday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周二下午
            case R.id.sx_id_tuesday_pm_choose:{
                is_tuesday_pm_choose = !is_tuesday_pm_choose;
                if(is_tuesday_pm_choose){
                    sx_id_tuesday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_tuesday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周二晚上
            case R.id.sx_id_tuesday_night_choose:{
                is_tuesday_night_choose = !is_tuesday_night_choose;
                if(is_tuesday_night_choose){
                    sx_id_tuesday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_tuesday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周三上午
            case R.id.sx_id_wednesday_am_choose:{
                is_wednesday_am_choose = !is_wednesday_am_choose;
                if(is_wednesday_am_choose){
                    sx_id_wednesday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_wednesday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周三下午
            case R.id.sx_id_wednesday_pm_choose:{
                is_wednesday_pm_choose = !is_wednesday_pm_choose;
                if(is_wednesday_pm_choose){
                    sx_id_wednesday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_wednesday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周三晚上
            case R.id.sx_id_wednesday_night_choose:{
                is_wednesday_night_choose = !is_wednesday_night_choose;
                if(is_wednesday_night_choose){
                    sx_id_wednesday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_wednesday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周四上午
            case R.id.sx_id_thursday_am_choose:{
                is_thursday_am_choose = !is_thursday_am_choose;
                if(is_thursday_am_choose){
                    sx_id_thursday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_thursday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周四下午
            case R.id.sx_id_thursday_pm_choose:{
                is_thursday_pm_choose = !is_thursday_pm_choose;
                if(is_thursday_pm_choose){
                    sx_id_thursday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_thursday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周四晚上
            case R.id.sx_id_thursday_night_choose:{
                is_thursday_night_choose = !is_thursday_night_choose;
                if(is_thursday_night_choose){
                    sx_id_thursday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_thursday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周五上午
            case R.id.sx_id_friday_am_choose:{
                is_friday_am_choose = !is_friday_am_choose;
                if(is_friday_am_choose){
                    sx_id_friday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_friday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周五下午
            case R.id.sx_id_friday_pm_choose:{
                is_friday_pm_choose = !is_friday_pm_choose;
                if(is_friday_pm_choose){
                    sx_id_friday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_friday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周五晚上
            case R.id.sx_id_friday_night_choose:{
                is_friday_night_choose = !is_friday_night_choose;
                if(is_friday_night_choose){
                    sx_id_friday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_friday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周六上午
            case R.id.sx_id_saturday_am_choose:{
                is_saturday_am_choose = !is_saturday_am_choose;
                if(is_saturday_am_choose){
                    sx_id_saturday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_saturday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周六下午
            case R.id.sx_id_saturday_pm_choose:{
                is_saturday_pm_choose = !is_saturday_pm_choose;
                if(is_saturday_pm_choose){
                    sx_id_saturday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_saturday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周六晚上
            case R.id.sx_id_saturday_night_choose:{
                is_saturday_night_choose = !is_saturday_night_choose;
                if(is_saturday_night_choose){
                    sx_id_saturday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_saturday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周日上午
            case R.id.sx_id_sunday_am_choose:{
                is_sunday_am_choose = !is_sunday_am_choose;
                if(is_sunday_am_choose){
                    sx_id_sunday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_sunday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周日下午
            case R.id.sx_id_sunday_pm_choose:{
                is_sunday_pm_choose = !is_sunday_pm_choose;
                if(is_sunday_pm_choose){
                    sx_id_sunday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_sunday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
            //周日晚上
            case R.id.sx_id_sunday_night_choose:{
                is_sunday_night_choose = !is_sunday_night_choose;
                if(is_sunday_night_choose){
                    sx_id_sunday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
                }else{
                    sx_id_sunday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
                }
                break;
            }
        }
    }

    /**
     * 获取出诊时间
     */
    private void getOutofTimeList() {
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.workTime_timeList) , new RequestParams(), new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    List<XCJsonBean> jsons = result_bean.getList("data");
                    mOutofTimeList = jsons.get(0).getList("workTime");
                    initOutOfTIme(mOutofTimeList);
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_OutOfTimeActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 初始化出诊时间
     * @param outofTimeList 出诊时间数据集合
     */
    private void initOutOfTIme(List<XCJsonBean> outofTimeList){
        for(XCJsonBean x : outofTimeList){
                String weekIndex = x.getString("weekIndex");
                if(weekIndex.equals("1")){
                    String am = x.getString("am");
                    String pm = x.getString("pm");
                    String night = x.getString("night");
                    if("0".equals(am)){
                        is_monday_am_choose = false;
                    }else if("1".equals(am)){
                        is_monday_am_choose = true;
                    }
                    if("0".equals(pm)){
                        is_monday_pm_choose = false;
                    }else if("1".equals(pm)){
                        is_monday_pm_choose = true;
                    }
                    if("0".equals(night)){
                        is_monday_night_choose = false;
                    }else if("1".equals(night)){
                        is_monday_night_choose = true;
                    }
                }else if(weekIndex.equals("2")){
                    String am = x.getString("am");
                    String pm = x.getString("pm");
                    String night = x.getString("night");
                    if("0".equals(am)){
                        is_tuesday_am_choose = false;
                    }else if("1".equals(am)){
                        is_tuesday_am_choose = true;
                    }
                    if("0".equals(pm)){
                        is_tuesday_pm_choose = false;
                    }else if("1".equals(pm)){
                        is_tuesday_pm_choose = true;
                    }
                    if("0".equals(night)){
                        is_tuesday_night_choose = false;
                    }else if("1".equals(night)){
                        is_tuesday_night_choose = true;
                    }
                }else if(weekIndex.equals("3")){
                    String am = x.getString("am");
                    String pm = x.getString("pm");
                    String night = x.getString("night");
                    if("0".equals(am)){
                        is_wednesday_am_choose = false;
                    }else if("1".equals(am)){
                        is_wednesday_am_choose = true;
                    }
                    if("0".equals(pm)){
                        is_wednesday_pm_choose = false;
                    }else if("1".equals(pm)){
                        is_wednesday_pm_choose = true;
                    }
                    if("0".equals(night)){
                        is_wednesday_night_choose = false;
                    }else if("1".equals(night)){
                        is_wednesday_night_choose = true;
                    }
                }else if(weekIndex.equals("4")){
                    String am = x.getString("am");
                    String pm = x.getString("pm");
                    String night = x.getString("night");
                    if("0".equals(am)){
                        is_thursday_am_choose = false;
                    }else if("1".equals(am)){
                        is_thursday_am_choose = true;
                    }
                    if("0".equals(pm)){
                        is_thursday_pm_choose = false;
                    }else if("1".equals(pm)){
                        is_thursday_pm_choose = true;
                    }
                    if("0".equals(night)){
                        is_thursday_night_choose = false;
                    }else if("1".equals(night)){
                        is_thursday_night_choose = true;
                    }
                }else if(weekIndex.equals("5")){
                    String am = x.getString("am");
                    String pm = x.getString("pm");
                    String night = x.getString("night");
                    if("0".equals(am)){
                        is_friday_am_choose = false;
                    }else if("1".equals(am)){
                        is_friday_am_choose = true;
                    }
                    if("0".equals(pm)){
                        is_friday_pm_choose = false;
                    }else if("1".equals(pm)){
                        is_friday_pm_choose = true;
                    }
                    if("0".equals(night)){
                        is_friday_night_choose = false;
                    }else if("1".equals(night)){
                        is_friday_night_choose = true;
                    }
                }else if(weekIndex.equals("6")){
                    String am = x.getString("am");
                    String pm = x.getString("pm");
                    String night = x.getString("night");
                    if("0".equals(am)){
                        is_saturday_am_choose = false;
                    }else if("1".equals(am)){
                        is_saturday_am_choose = true;
                    }
                    if("0".equals(pm)){
                        is_saturday_pm_choose = false;
                    }else if("1".equals(pm)){
                        is_saturday_pm_choose = true;
                    }
                    if("0".equals(night)){
                        is_saturday_night_choose = false;
                    }else if("1".equals(night)){
                        is_saturday_night_choose = true;
                    }
                }else if(weekIndex.equals("7")){
                    String am = x.getString("am");
                    String pm = x.getString("pm");
                    String night = x.getString("night");
                    if("0".equals(am)){
                        is_sunday_am_choose = false;
                    }else if("1".equals(am)){
                        is_sunday_am_choose = true;
                    }
                    if("0".equals(pm)){
                        is_sunday_pm_choose = false;
                    }else if("1".equals(pm)){
                        is_sunday_pm_choose = true;
                    }
                    if("0".equals(night)){
                        is_sunday_night_choose = false;
                    }else if("1".equals(night)){
                        is_sunday_night_choose = true;
                    }
                }
        }
        //周一上午
        if(is_monday_am_choose){
            sx_id_monday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_monday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周一下午
        if(is_monday_pm_choose){
            sx_id_monday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_monday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周一晚上
        if(is_monday_night_choose){
            sx_id_monday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_monday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周二上午
        if(is_tuesday_am_choose){
            sx_id_tuesday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_tuesday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周二下午
        if(is_tuesday_pm_choose){
            sx_id_tuesday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_tuesday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周二晚上
        if(is_tuesday_night_choose){
            sx_id_tuesday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_tuesday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周三上午
        if(is_wednesday_am_choose){
            sx_id_wednesday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_wednesday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周三下午
        if(is_wednesday_pm_choose){
            sx_id_wednesday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_wednesday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周三晚上
        if(is_wednesday_night_choose){
            sx_id_wednesday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_wednesday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周四上午
        if(is_thursday_am_choose){
            sx_id_thursday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_thursday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周四下午
        if(is_thursday_pm_choose){
            sx_id_thursday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_thursday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周四晚上
        if(is_thursday_night_choose){
            sx_id_thursday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_thursday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周五上午
        if(is_friday_am_choose){
            sx_id_friday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_friday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周五下午
        if(is_friday_pm_choose){
            sx_id_friday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_friday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周五晚上
        if(is_friday_night_choose){
            sx_id_friday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_friday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周六上午
        if(is_saturday_am_choose){
            sx_id_saturday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_saturday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周六下午
        if(is_saturday_pm_choose){
            sx_id_saturday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_saturday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周六晚上
        if(is_saturday_night_choose){
            sx_id_saturday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_saturday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周日上午
        if(is_sunday_am_choose){
            sx_id_sunday_am_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_sunday_am_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周日下午
        if(is_sunday_pm_choose){
            sx_id_sunday_pm_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_sunday_pm_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
        //周日晚上
        if(is_sunday_night_choose){
            sx_id_sunday_night_choose.setImageResource(R.mipmap.sx_d_time_choose);
        }else{
            sx_id_sunday_night_choose.setImageResource(R.mipmap.sx_d_time_no_choose);
        }
    }

    /**
     * 保存出诊时间
     * @param works
     */
    private void saveWorkTime(final String works){
        RequestParams params = new RequestParams();
        params.put("works", works);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.workTime_saveWorkTime), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    //start delete by cyr on 2016/6/29 没用到，注释了
//                    UtilSP.setPaWorktime(works);
                    //end delete by cyr on 2016/6/29 没用到，注释了
                    UtilSP.putDoctorWorkTime(works);
                    myFinish();
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_OutOfTimeActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 创建json
     * @return
     * @throws JSONException
     */
    private String createJson() throws JSONException {
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonMonday = new JSONObject();
        jsonMonday.put("weekIndex", "1");
        JSONObject jsonTuesday = new JSONObject();
        jsonTuesday.put("weekIndex", "2");
        JSONObject jsonWednesday = new JSONObject();
        jsonWednesday.put("weekIndex", "3");
        JSONObject jsonThursday = new JSONObject();
        jsonThursday.put("weekIndex", "4");
        JSONObject jsonFriday = new JSONObject();
        jsonFriday.put("weekIndex", "5");
        JSONObject jsonSaturday = new JSONObject();
        jsonSaturday.put("weekIndex", "6");
        JSONObject jsonSunday = new JSONObject();
        jsonSunday.put("weekIndex", "7");
        //周一上午
        if(is_monday_am_choose){
            jsonMonday.put("am", "1");
        }else{
            jsonMonday.put("am", "0");
        }
        //周一下午
        if(is_monday_pm_choose){
            jsonMonday.put("pm", "1");
        }else{
            jsonMonday.put("pm", "0");
        }
        //周一晚上
        if(is_monday_night_choose){
            jsonMonday.put("night", "1");
        }else{
            jsonMonday.put("night", "0");
        }
        jsonArray.put(jsonMonday);
        //周二上午
        if(is_tuesday_am_choose){
            jsonTuesday.put("am", "1");
        }else{
            jsonTuesday.put("am", "0");
        }
        //周二下午
        if(is_tuesday_pm_choose){
            jsonTuesday.put("pm", "1");
        }else{
            jsonTuesday.put("pm", "0");
        }
        //周二晚上
        if(is_tuesday_night_choose){
            jsonTuesday.put("night", "1");
        }else{
            jsonTuesday.put("night", "0");
        }
        jsonArray.put(jsonTuesday);
        //周三上午
        if(is_wednesday_am_choose){
            jsonWednesday.put("am", "1");
        }else{
            jsonWednesday.put("am", "0");
        }
        //周三下午
        if(is_wednesday_pm_choose){
            jsonWednesday.put("pm", "1");
        }else{
            jsonWednesday.put("pm", "0");
        }
        //周三晚上
        if(is_wednesday_night_choose){
            jsonWednesday.put("night", "1");
        }else{
            jsonWednesday.put("night", "0");
        }
        jsonArray.put(jsonWednesday);
        //周四上午
        if(is_thursday_am_choose){
            jsonThursday.put("am", "1");
        }else{
            jsonThursday.put("am", "0");
        }
        //周四下午
        if(is_thursday_pm_choose){
            jsonThursday.put("pm", "1");
        }else{
            jsonThursday.put("pm", "0");
        }
        //周四晚上
        if(is_thursday_night_choose){
            jsonThursday.put("night", "1");
        }else{
            jsonThursday.put("night", "0");
        }
        jsonArray.put(jsonThursday);
        //周五上午
        if(is_friday_am_choose){
            jsonFriday.put("am", "1");
        }else{
            jsonFriday.put("am", "0");
        }
        //周五下午
        if(is_friday_pm_choose){
            jsonFriday.put("pm", "1");
        }else{
            jsonFriday.put("pm", "0");
        }
        //周五晚上
        if(is_friday_night_choose){
            jsonFriday.put("night", "1");
        }else{
            jsonFriday.put("night", "0");
        }
        jsonArray.put(jsonFriday);
        //周六上午
        if(is_saturday_am_choose){
            jsonSaturday.put("am", "1");
        }else{
            jsonSaturday.put("am", "0");
        }
        //周六下午
        if(is_saturday_pm_choose){
            jsonSaturday.put("pm", "1");
        }else{
            jsonSaturday.put("pm", "0");
        }
        //周六晚上
        if(is_saturday_night_choose){
            jsonSaturday.put("night", "1");
        }else{
            jsonSaturday.put("night", "0");
        }
        jsonArray.put(jsonSaturday);
        //周日上午
        if(is_sunday_am_choose){
            jsonSunday.put("am", "1");
        }else{
            jsonSunday.put("am", "0");
        }
        //周日下午
        if(is_sunday_pm_choose){
            jsonSunday.put("pm", "1");
        }else{
            jsonSunday.put("pm", "0");
        }
        //周日晚上
        if(is_sunday_night_choose){
            jsonSunday.put("night", "1");
        }else{
            jsonSunday.put("night", "0");
        }
        jsonArray.put(jsonSunday);
        printi("http", "json==========>"+jsonArray.toString());
        return jsonArray.toString();
    }

}
