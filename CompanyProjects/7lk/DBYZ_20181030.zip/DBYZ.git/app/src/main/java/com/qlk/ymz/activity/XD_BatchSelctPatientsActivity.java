package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.GroupAdapter;
import com.qlk.ymz.adapter.PatientGroupAdapter;
import com.qlk.ymz.adapter.SelectPatientAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.model.CheckPatientBean;
import com.qlk.ymz.model.ConsultPatientGroupBean;
import com.qlk.ymz.parse.Parse2GroupsBean;
import com.qlk.ymz.parse.Parse2GroupsPatientBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.PinnedHeaderExpandableListView;
import com.qlk.ymz.view.XCSlideBar_V2;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;



/**
 * Created by xiedong on 2017/3/29.
 * 批量选择患者
 */

public class XD_BatchSelctPatientsActivity extends DBActivity {
    /**
     * 取消按钮
     */
    private LinearLayout ll_title_left;
    /**
     * 分组按钮
     */
    private LinearLayout ll_title_center;
    /**
     * 分组名称
     */
    private TextView tv_title_center;
    /**
     * 分组箭头
     */
    private ImageView iv_title_arrow;
    /**
     * 搜素框入口
     */
    private LinearLayout ll_patient_search;
    /**
     * 搜索栏布局
     */
    private RelativeLayout rl_search_edit;
    /**
     * 搜索控件
     */
    private EditText et_search_key;
    /**
     * 搜索取消
     */
    private TextView tv_search_cancle;
    /**
     * 分组下拉框布局
     */
    private LinearLayout ll_group;
    /**
     * 分组下拉布局非遮罩区域
     */
    private LinearLayout ll_group_top;
    /**
     * 全部患者item
     */
    private LinearLayout ll_all_patient;
    /**
     * 全部患者数
     */
    private TextView tv_all_patient_num;
    /**
     * 未分组患者item
     */
    private LinearLayout ll_unGroup_patient;
    /**
     * 未分组患者数目
     */
    private TextView tv_unGroup_patient_num;
    /**
     * 我的分组title
     */
    private TextView tv_group_title;
    /**
     * 我的分组下的分割线
     */
    private View v_myGroup_line;
    /**
     * 分组列表
     */
    private ListView lv_group;
    /**
     * 编辑分组item
     */
    private LinearLayout ll_edit_group;
    /**
     * 分组布局空的区域
     */
    private View v_empty;
    /**
     * 右侧字母滑条
     */
    private XCSlideBar_V2 mSlideBar_v2;
    /**
     * 屏幕中间弹出的字母dialog
     */
    private TextView tv_letter_dialog;
    /**
     * 患者可扩展列表
     */
    private PinnedHeaderExpandableListView mPinnedHeaderExpandableListView;
    /**
     * 患者结果列表
     */
    private ListView lv_patient_result;
    /**
     * 无数据页面
     */
    private LinearLayout in_nodata;
    /**
     * 全选按钮布局
     */
    private LinearLayout ll_all_check;
    /**
     * 全选按钮
     */
    private ImageView iv_all_check;
    /**
     * 选择人数
     */
    private TextView tv_check_num;
    /**
     * 完成按钮
     */
    private TextView tv_complete;
    /**
     * 分组数据集合
     */
    private HashMap<String, ConsultPatientGroupBean> mConsultPatientGroupBeanLinkedHashMap = new LinkedHashMap<>();
    /**
     * 除掉未分组的分组集合
     */
    private List<ConsultPatientGroupBean> mConsultPatientGroupBeanList = new ArrayList<>();
    /**
     * abc字母集合
     */
    private ArrayList<String> mLetters = new ArrayList<>();
    /**
     * abc患者集合
     */
    private List<List<CheckPatientBean>> mABCPatientList = new ArrayList<>();
    /**
     * 当前组id
     */
    private String mCurrentGroupId = "all";//“all”表示全部分组 “0”表示未分组 “-1”表示搜索结果
    /**
     * 上次选择的组id
     */
    private String mLastGroupId = "all";
    /**
     * 当前组的患者数据
     */
    private List<CheckPatientBean> mCurrentPatientList = new ArrayList<>();

    /**
     * 选中的患者id集合
     */
    private ArrayList<String> mCheckPatients = new ArrayList<>();
    /**
     * 存储患者的勾选状态map
     */
    private Map<String, Boolean> mCheckMap = new HashMap<>();
    /**
     * abc患者列表适配器
     */
    private PatientGroupAdapter mPatientGroupAdapter;
    /**
     * 组内患者适配器
     */
    private SelectPatientAdapter mSelectPatientAdapter;
    /**
     * 分组的适配器
     */
    private GroupAdapter mGroupAdapter;
    /**
     * 是否全选
     */
    private boolean isAllCheck = false;
    /**
     * 患者总数
     */
    private int totalNum = 0;
    /**
     * 选择患者集合 tag
     */
    public static final String SELECT_INFO = "select_info";
    /**
     * 解析患者分组
     */
    private Parse2GroupsBean parse2GroupsBean;
    /**
     * 解析指定分组患者
     */
    private Parse2GroupsPatientBean parse2GroupsPatientBean;
    /**
     * 分组布局是否显示
     */
    private boolean isGroupVisible = false;
    /**
     * 记录哪个接口请求失败
     */
    private int failNum = 0;//0表示abc接口  1 分组接口  2 分组患者接口

    /**
     * 开始透明度
     */
    private float fromAlpha = 0;
    /**
     * 结束透明度
     */
    private float toAlpha = 1;
    /**
     * 开始Y位置
     */
    private float fromYDelta = 0;
    /**
     * 结束Y位置
     */
    private float toYDelta = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_batch_select_patients);
        super.onCreate(savedInstanceState);
        initData();
    }

    /**
     * created by songxin,date：2017-4-10,about：bi,begin
     */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_BatchSelctPatientsActivity.class);
    }

    /**
     * created by songxin,date：2016-4-10,about：bi,end
     */


    @Override
    public void initWidgets() {
        ll_title_left = getViewById(R.id.ll_title_left);
        ll_title_center = getViewById(R.id.ll_title_center);
        tv_title_center = getViewById(R.id.tv_title_center);
        iv_title_arrow = getViewById(R.id.iv_title_arrow);

        ll_patient_search = getViewById(R.id.ll_patient_search);
        rl_search_edit = getViewById(R.id.rl_search_edit);
        tv_search_cancle = getViewById(R.id.tv_search_cancle);
        et_search_key = getViewById(R.id.et_search_key);

        ll_group = getViewById(R.id.ll_group);
        ll_group_top = getViewById(R.id.ll_group_top);
        ll_all_patient = getViewById(R.id.ll_all_patient);
        tv_all_patient_num = getViewById(R.id.tv_all_patient_num);
        ll_unGroup_patient = getViewById(R.id.ll_unGroup_patient);
        tv_unGroup_patient_num = getViewById(R.id.tv_unGroup_patient_num);
        tv_group_title = getViewById(R.id.tv_group_title);
        v_myGroup_line = getViewById(R.id.v_myGroup_line);
        lv_group = getViewById(R.id.lv_group);
        ll_edit_group = getViewById(R.id.ll_edit_group);
        v_empty = getViewById(R.id.v_empty);

        mPinnedHeaderExpandableListView = getViewById(R.id.pv_patient_list);
        lv_patient_result = getViewById(R.id.lv_patient_result);
        tv_letter_dialog = getViewById(R.id.tv_letter_dialog);
        mSlideBar_v2 = getViewById(R.id.slideBar);
        in_nodata = getViewById(R.id.in_nodata);

        ll_all_check = getViewById(R.id.ll_all_check);
        iv_all_check = getViewById(R.id.iv_all_check);
        tv_check_num = getViewById(R.id.tv_check_num);
        tv_complete = getViewById(R.id.tv_complete);

        ((TextView) in_nodata.findViewById(R.id.id_zero_data_tv)).setText("没有找到相关患者");
        mSlideBar_v2.setTextView(tv_letter_dialog);
        // 添加悬浮view的布局
        final View mHeaderView = View.inflate(this, R.layout.xc_l_adapter_patient_letter_out_item, null);
        mPinnedHeaderExpandableListView.setHeaderView(mHeaderView);

        // 给悬浮字母View添加数据
        mPinnedHeaderExpandableListView.setPinnedableView(new PinnedHeaderExpandableListView.Pinnedable() {
            @Override
            public void setHeaderData(int groupPosition) {
                if (groupPosition < 0)
                    return;
                String letter = (String) mPatientGroupAdapter.getGroup(groupPosition);
                ((TextView) mHeaderView.findViewById(R.id.xc_id_fragment_search_letter_view)).setText(letter);
            }
        });
    }

    @Override
    public void listeners() {
        //取消监听
        ll_title_left.setOnClickListener(this);
        //分组下拉监听
        ll_title_center.setOnClickListener(this);
        //全部患者点击监听
        ll_all_patient.setOnClickListener(this);
        //未分组患者点击监听
        ll_unGroup_patient.setOnClickListener(this);
        //我的分组点击  此设置为了屏蔽点击
        tv_group_title.setOnClickListener(this);
        //编辑分组点击监听
        ll_edit_group.setOnClickListener(this);
        //分组布局空白点击监听
        v_empty.setOnClickListener(this);
        //搜素监听
        ll_patient_search.setOnClickListener(this);
        //搜索取消监听
        tv_search_cancle.setOnClickListener(this);
        //全选监听
        ll_all_check.setOnClickListener(this);
        //完成监听
        tv_complete.setOnClickListener(this);
        //分组条目点击监听 返回true 点击不会收起
        mPinnedHeaderExpandableListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, final int groupPosition, long id) {
                return true;
            }
        });

        // 右侧字母列表的滑动监听
        mSlideBar_v2.setOnTouchingLetterChangedListener(new XCSlideBar_V2.OnTouchingLetterChangedListener() {

            @Override
            public void onTouchingLetterChanged(String s) {
                //获得手指按压的字母位置，患者列表滑动到相应字母位置
                Integer position = mPatientGroupAdapter.getPositionFromLetter(s);
                if (position != null) {
                    mPinnedHeaderExpandableListView.setSelection(position);
                }
            }
        });
        //我的分组列表条目点击
        lv_group.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // 切换分组
                PackUpGroup();
                cancleSearchUI();
                ConsultPatientGroupBean consultPatientGroupBean = (ConsultPatientGroupBean) parent.getItemAtPosition(position);
                if (!mCurrentGroupId.equals(consultPatientGroupBean.getId())) {//判断是不是原来分组
                    mCurrentGroupId = consultPatientGroupBean.getId();
                    setCenterText(consultPatientGroupBean.getGroupName());
                    ConsultPatientGroupBean PatientGroupBean = mConsultPatientGroupBeanLinkedHashMap.get(mCurrentGroupId);
                    if (PatientGroupBean.getPatientList().size() == 0) {
                        reqGroupPatientsData(PatientGroupBean);
                    } else {
                        mCurrentPatientList.clear();
                        mCurrentPatientList.addAll(PatientGroupBean.getPatientList());
                        refreshUI(false);
                    }
                }
            }
        });
        //点击软件盘搜索按钮
        et_search_key.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    String inputText = et_search_key.getText().toString().trim();
                    if (!TextUtils.isEmpty(inputText)) {
                        UtilInputMethod.hiddenInputMethod(et_search_key,
                                XD_BatchSelctPatientsActivity.this);
                        List<CheckPatientBean> searchPatients = searchPatient(inputText);
                        if (!mCurrentGroupId.equals("-1")) {//记住上次的分组id
                            mLastGroupId = mCurrentGroupId;
                        }
                        mCurrentGroupId = "-1";//"-1"代表搜索
                        mCurrentPatientList.clear();
                        mCurrentPatientList.addAll(searchPatients);
                        refreshUI(false);
                    }
                    return true;
                }
                return false;
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //重新请求分组数据
        reqGroupData();
    }

    /**
     * 搜索患者信息
     *
     * @param inputText 搜索关键字
     * @return List<CheckPatientBean> 患者集合
     */
    private List<CheckPatientBean> searchPatient(String inputText) {
        List<CheckPatientBean> checkPatientBeans = new ArrayList<>();
        List<JS_ChatListModel> chatListModels = JS_ChatListDB.getInstance(getApplicationContext(), UtilSP.getUserId())
                .getSearchPatientInfo(inputText);
        for (JS_ChatListModel bean : chatListModels) {
            CheckPatientBean checkPatientBean = new CheckPatientBean();
            UserPatient userPatient = bean.getUserPatient();
            if (TextUtils.isEmpty(userPatient.getPatientMemoName())) {
                checkPatientBean.setPatientName(userPatient.getPatientName());
            } else {
                checkPatientBean.setPatientName(userPatient.getPatientMemoName());
            }
            checkPatientBean.setPatientId(userPatient.getPatientId());
            checkPatientBean.setPatientGender(userPatient.getPatientGender());
            checkPatientBean.setPatientImgHead(userPatient.getPatientImgHead());
            checkPatientBean.setPatientLetter(userPatient.getPatientLetter());
            checkPatientBean.setPayAmount(userPatient.getPayAmount());
            checkPatientBean.setPatientAge(userPatient.getPatientAge());
            checkPatientBeans.add(checkPatientBean);
        }
        return checkPatientBeans;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_title_left:
                myFinish();
                break;
            case R.id.ll_title_center:
                if(View.VISIBLE == xc_id_model_content.getVisibility()){
                    // 下拉收起分组
                    if (isGroupVisible) {//收起
                        PackUpGroup();
                    } else {//下拉
                        UtilInputMethod.hiddenInputMethod(et_search_key, this);
                        isGroupVisible = true;
                        ll_group.setVisibility(View.VISIBLE);
                        iv_title_arrow.setImageResource(R.mipmap.sx_d_up_arrow);
                        fromYDelta = -ll_group_top.getMeasuredHeight();
                        toYDelta = 0;
                        fromAlpha = 0;
                        toAlpha = 1;
                        startAnimation(false);
                    }
                }

                break;
            case R.id.ll_all_patient:
                // 切换成全部患者
                PackUpGroup();
                cancleSearchUI();
                setCenterText("全部患者");
                if (!mCurrentGroupId.equals("all")) {//判断是不是原来分组
                    mCurrentGroupId = "all";
                    mCurrentPatientList.clear();
                    refreshUI(true);
                }
                break;
            case R.id.ll_unGroup_patient:
                // 切换未分组患者
                PackUpGroup();
                cancleSearchUI();
                if (!mCurrentGroupId.equals("0")) {//判断是不是原来分组
                    mCurrentGroupId = "0";
                    setCenterText("未分组患者");
                    ConsultPatientGroupBean consultPatientGroupBean = mConsultPatientGroupBeanLinkedHashMap.get(mCurrentGroupId);
                    if (consultPatientGroupBean == null) {
                        //  展示无数据页面
                        mCurrentPatientList.clear();
                        refreshUI(false);
                    } else {
                        if (consultPatientGroupBean.getPatientList().size() == 0) {
                            reqGroupPatientsData(consultPatientGroupBean);
                        } else {
                            mCurrentPatientList.clear();
                            mCurrentPatientList.addAll(consultPatientGroupBean.getPatientList());
                            refreshUI(false);
                        }
                    }
                }
                break;
            case R.id.ll_edit_group:
                // 编辑我的分组
                iv_title_arrow.setImageResource(R.mipmap.sx_d_down_arrow);
                isGroupVisible = false;
                ll_group.setVisibility(View.INVISIBLE);
                myStartActivityForResult(YR_PatientGroupManagerActivity.class, 1);
                break;
            case R.id.v_empty:
                //点击空白区域收起分组布局
                PackUpGroup();
                break;
            case R.id.ll_patient_search:
                // 搜索开始
                ll_patient_search.setVisibility(View.GONE);
                rl_search_edit.setVisibility(View.VISIBLE);
                UtilInputMethod.openInputMethod(et_search_key, this);
                break;
            case R.id.tv_search_cancle:
                // 搜索取消
                cancleSearch();
                break;
            case R.id.tv_complete:
                //完成操作
                Intent intent = new Intent();
                intent.putStringArrayListExtra(SELECT_INFO, mCheckPatients);
                setResult(RESULT_OK, intent);
                myFinish();
                break;
            case R.id.ll_all_check:
                //全选操作
                checkAll();
                break;
        }
        super.onClick(v);
    }

    /**
     * 取消搜索
     */
    private void cancleSearch() {
        cancleSearchUI();
        if (mCurrentGroupId.equals("-1")) {
            if (mLastGroupId.equals("all")) {//判断是不是abc
                mCurrentGroupId = "all";
                mCurrentPatientList.clear();
                refreshUI(true);
            } else {
                mCurrentPatientList.clear();
                ConsultPatientGroupBean consultPatientGroupBean = mConsultPatientGroupBeanLinkedHashMap.get(mLastGroupId);
                if (consultPatientGroupBean != null) {//上一次页面的分组数据还存在
                    mCurrentGroupId = mLastGroupId;
                    if (consultPatientGroupBean.getPatientList().size() == 0) {//患者数据已清除情况
                        reqGroupPatientsData(consultPatientGroupBean);
                    } else {
                        mCurrentPatientList.addAll(consultPatientGroupBean.getPatientList());
                        refreshUI(false);
                    }
                } else {//上一次页面的分组数据不存在
                    if (mLastGroupId.equals("0")) {//未分组已被删除的情况显示无数据页面
                        mCurrentGroupId = mLastGroupId;
                        refreshUI(false);
                    } else {//原分组已被删除的情况显示全部患者
                        mCurrentGroupId = "all";
                        setCenterText("全部患者");
                        refreshUI(true);
                    }
                }
            }
        }
    }

    /**
     * 去除搜索栏搜索模式
     */
    private void cancleSearchUI() {
        ll_patient_search.setVisibility(View.VISIBLE);
        rl_search_edit.setVisibility(View.GONE);
        et_search_key.setText("");
        UtilInputMethod.hiddenInputMethod(et_search_key, this);
    }

    /**
     * 动态设置title
     * @param text
     */
    private void setCenterText(String text) {
        tv_title_center.setText(text);
        ViewGroup.LayoutParams layoutParams1 = tv_title_center.getLayoutParams();
        layoutParams1.width = ViewGroup.LayoutParams.WRAP_CONTENT;

        int w = View.MeasureSpec.makeMeasureSpec((1 << 30) - 1, View.MeasureSpec.AT_MOST);

        //获取组名宽
        tv_title_center.measure(w, w);
        int nameWidth = tv_title_center.getMeasuredWidth();
        //获取屏幕宽
        int width = UtilScreen.getScreenSize(this)[1];
        if ((nameWidth) + UtilScreen.dip2px(this, 89) > width) {//超出行宽
            //给组名控件设置剩余的宽度
            layoutParams1.width = width - UtilScreen.dip2px(this, 89);
        }
        tv_title_center.requestLayout();
    }


    /**
     * 收起分组
     */
    private void PackUpGroup() {
        iv_title_arrow.setImageResource(R.mipmap.sx_d_down_arrow);
        isGroupVisible = false;
        fromYDelta = 0;
        toYDelta = -ll_group_top.getMeasuredHeight();
        fromAlpha = 1;
        toAlpha = 0;
        startAnimation(true);
    }

    /**
     * 全选操作
     */
    private void checkAll() {
        if (mCurrentGroupId.equals("all")) {//abc列表
            if (mABCPatientList.size() > 0) {
                for (int i = 0; i < mABCPatientList.size(); i++) {
                    List<CheckPatientBean> patientBeanList = mABCPatientList.get(i);
                    for (CheckPatientBean bean : patientBeanList) {
                        changeCheckStatus(bean);
                    }
                }
                //刷新ui
                mPatientGroupAdapter.notifyDataSetChanged();
            }
        } else {//其他类型列表
            if (mCurrentPatientList.size() > 0) {
                for (CheckPatientBean bean : mCurrentPatientList) {
                    changeCheckStatus(bean);
                }
                //刷新ui
                mSelectPatientAdapter.notifyDataSetChanged();
            }
        }
        //更新底部ui
        updateBottomUI();
    }

    /**
     * 全选按钮操作更改某个bean的逻辑操作
     *
     * @param bean
     */
    private void changeCheckStatus(CheckPatientBean bean) {
        if (!isAllCheck) {//全选
            //判断患者是否已选
            if (mCheckMap.get(bean.getPatientId()) == null || !mCheckMap.get(bean
                    .getPatientId())) {//未选
                mCheckPatients.add(bean.getPatientId());//添加到选中集合
                mCheckMap.put(bean.getPatientId(), true);//更新选中记录
            }
        } else {//全不选
            //判断患者是否已选
            if (mCheckMap.get(bean.getPatientId()) != null && mCheckMap.get(bean
                    .getPatientId())) {//已选
                mCheckPatients.remove(bean.getPatientId());//从选中集合移除
                mCheckMap.put(bean.getPatientId(), false);//更新选中记录
            }
        }
    }

    /**
     * 初始化数据
     */
    private void initData() {
        //获取上个页面带来数据
        if (getIntent() != null && getIntent().getStringArrayListExtra(SELECT_INFO) != null) {
            mCheckPatients = getIntent().getStringArrayListExtra(SELECT_INFO);
            for (int i = 0; i < mCheckPatients.size(); i++) {//保存选中状态
                mCheckMap.put(mCheckPatients.get(i), true);
            }
        }
        reqABC();
    }


    @Override
    public void onNetRefresh() {
        switch (failNum) {
            case 0:
                reqABC();
                break;
            case 1:
                reqGroupData();
                break;
            case 2:
                ConsultPatientGroupBean consultPatientGroupBean = mConsultPatientGroupBeanLinkedHashMap.get(mCurrentGroupId);
                reqGroupPatientsData(consultPatientGroupBean);
                break;
        }
    }


    /**
     * 初始化分组下拉框数据
     */
    private void initGroupLayout() {
        //设置全部患者数目
        tv_all_patient_num.setText("(" + totalNum + ")");
        //设置未分组患者数目
        if (mConsultPatientGroupBeanLinkedHashMap.get("0") == null) {
            tv_unGroup_patient_num.setText("(0)");
        } else {
            tv_unGroup_patient_num.setText("(" + mConsultPatientGroupBeanLinkedHashMap.get("0")
                    .getGroupCount() + ")");
        }

        //动态设置分组列表的高度及显示
        ViewGroup.LayoutParams layoutParams = lv_group.getLayoutParams();
        if (mConsultPatientGroupBeanList.size() < 5 && mConsultPatientGroupBeanList.size() > 0) {
            layoutParams.height = UtilScreen.dip2px(XD_BatchSelctPatientsActivity
                    .this, mConsultPatientGroupBeanList.size() * 40);
            lv_group.setLayoutParams(layoutParams);
            setGroupVisibility(true);
        } else if (mConsultPatientGroupBeanList.size() >= 5) {
            layoutParams.height = UtilScreen.dip2px(XD_BatchSelctPatientsActivity
                    .this, 200);
            lv_group.setLayoutParams(layoutParams);
            setGroupVisibility(true);
        } else {
            setGroupVisibility(false);
        }

        //刷新分组列表ui
        if (mGroupAdapter == null) {
            mGroupAdapter = new GroupAdapter(XD_BatchSelctPatientsActivity.this, mConsultPatientGroupBeanList);
            lv_group.setAdapter(mGroupAdapter);
        } else {
            mGroupAdapter.notifyDataSetChanged();
        }
    }

    /**
     * 设置分组布局是否展示
     *
     * @param isGroupVisible true 展示 false 隐藏
     */
    private void setGroupVisibility(boolean isGroupVisible) {
        if (isGroupVisible) {
            tv_group_title.setVisibility(View.VISIBLE);
            v_myGroup_line.setVisibility(View.VISIBLE);
            lv_group.setVisibility(View.VISIBLE);
        } else {
            tv_group_title.setVisibility(View.GONE);
            v_myGroup_line.setVisibility(View.GONE);
            lv_group.setVisibility(View.GONE);
        }

    }

    /**
     * 切换页面
     *
     * @param isAll 是否为全部患者页
     */
    private void refreshUI(boolean isAll) {
        if (isAll) {
            if (mABCPatientList.size() > 0) {
                if (mPatientGroupAdapter == null) {
                    mPatientGroupAdapter = new PatientGroupAdapter(mABCPatientList, mLetters, this,
                            mCheckPatients, mCheckMap);
                    mPinnedHeaderExpandableListView.setAdapter(mPatientGroupAdapter);
                    allExpandList();
                }
                mSlideBar_v2.setABC(mLetters);
                mPatientGroupAdapter.updateABCPosition();
                in_nodata.setVisibility(View.GONE);
                lv_patient_result.setVisibility(View.GONE);
                mPinnedHeaderExpandableListView.setVisibility(View.VISIBLE);
                mSlideBar_v2.setVisibility(View.VISIBLE);
                mPatientGroupAdapter.notifyDataSetChanged();
            } else {
                mPinnedHeaderExpandableListView.setVisibility(View.GONE);
                mSlideBar_v2.setVisibility(View.GONE);
                lv_patient_result.setVisibility(View.GONE);
                in_nodata.setVisibility(View.VISIBLE);
            }
        } else {
            if (mCurrentPatientList.size() > 0) {
                if (mSelectPatientAdapter == null) {
                    mSelectPatientAdapter = new SelectPatientAdapter(this, mCurrentPatientList,
                            mCheckPatients, mCheckMap);
                    lv_patient_result.setAdapter(mSelectPatientAdapter);
                }
                mPinnedHeaderExpandableListView.setVisibility(View.GONE);
                mSlideBar_v2.setVisibility(View.GONE);
                in_nodata.setVisibility(View.GONE);
                lv_patient_result.setVisibility(View.VISIBLE);
                mSelectPatientAdapter.notifyDataSetChanged();
            } else {
                mPinnedHeaderExpandableListView.setVisibility(View.GONE);
                mSlideBar_v2.setVisibility(View.GONE);
                lv_patient_result.setVisibility(View.GONE);
                in_nodata.setVisibility(View.VISIBLE);
            }
        }

        //初始化底部ui
        updateBottomUI();
    }


    /**
     * 更新选择患者数目 底部条目的ui
     */
    public void updateBottomUI() {
        if (mCheckPatients.size() > 0) {
            tv_check_num.setTextColor(getResources().getColor(R.color.c_e2231a));
            tv_complete.setBackgroundResource(R.drawable.xd_red_button_bg_selector);
            tv_complete.setClickable(true);
        } else {
            tv_check_num.setTextColor(getResources().getColor(R.color.c_7b7b7b));
            tv_complete.setBackgroundResource(R.drawable.xd_gray_round_shape_2);
            tv_complete.setClickable(false);
        }
        tv_check_num.setText(mCheckPatients.size() + "");

        //判断是否为abc列表
        if (mCurrentGroupId.equals("all")) {
            if (mCheckPatients.size() == totalNum && mCheckPatients.size() > 0) {
                //全选
                isAllCheck = true;
                iv_all_check.setImageResource(R.mipmap.sx_d_register_sure);
            } else {
                //未全选
                isAllCheck = false;
                iv_all_check.setImageResource(R.mipmap.sx_d_register_no_sure);
            }
        } else {//不是abc列表
            if (mCurrentPatientList.size() > 0) {
                isAllCheck = true;
            } else {
                isAllCheck = false;
            }
            for (CheckPatientBean bean : mCurrentPatientList) {
                if (mCheckMap.get(bean.getPatientId()) == null || !mCheckMap.get(bean.getPatientId())) {//未选
                    isAllCheck = false;
                    break;
                }
            }
            if (isAllCheck) {
                iv_all_check.setImageResource(R.mipmap.sx_d_register_sure);
            } else {
                iv_all_check.setImageResource(R.mipmap.sx_d_register_no_sure);
            }
        }

    }


    /**
     * 初始化abc患者列表全部展开
     */
    public void allExpandList() {
        int count = mPatientGroupAdapter.getGroupCount();
        for (int i = 0; i < count; i++) {
            if (!mPinnedHeaderExpandableListView.isGroupExpanded(i)) {
                mPinnedHeaderExpandableListView.expandGroup(i);
            }
        }
    }

    /**
     * 创建动画
     *
     * @param isClose 是否收起动画 true 收起
     */
    private void startAnimation(final boolean isClose) {
        AnimationSet animationSet = new AnimationSet(true);
        animationSet.setDuration(300);
        animationSet.setInterpolator(new LinearInterpolator());
        AlphaAnimation alphaAnimation = new AlphaAnimation(fromAlpha, toAlpha);
        TranslateAnimation translateAnimation = new TranslateAnimation(0, 0, fromYDelta, toYDelta);
        animationSet.addAnimation(translateAnimation);
        animationSet.addAnimation(alphaAnimation);
        animationSet.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                if (isClose) {
                    ll_group.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        ll_group_top.startAnimation(animationSet);
    }

    /**
     * 获取指定分组患者数据
     */
    private void reqGroupPatientsData(final ConsultPatientGroupBean consultPatientGroupBean) {
        RequestParams params = new RequestParams();
        params.put("groupId", consultPatientGroupBean.getId());
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.consultPatients), params, new
                XCHttpResponseHandler() {

                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            parse2GroupsPatientBean = new Parse2GroupsPatientBean(consultPatientGroupBean.getPatientList());
                            parse2GroupsPatientBean.parseJsonToGroup(result_bean);
                            //替换当前组数据
                            mCurrentPatientList.clear();
                            mCurrentPatientList.addAll(consultPatientGroupBean.getPatientList());
                            refreshUI(false);
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        failNum = 2;
                        showNoNetLayout();
                    }

                    // 对账户冻结情况的判断处理
                    public void onFinish() {
                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_BatchSelctPatientsActivity.this,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

    /**
     * 获取分组数据
     */
    private void reqGroupData() {
        RequestParams params = new RequestParams();
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.consultPatientGroups), params,
                new XCHttpResponseHandler() {

                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            ArrayList<ConsultPatientGroupBean> mConsultPatientGroupBeens = new ArrayList<>();
                            parse2GroupsBean = new Parse2GroupsBean(mConsultPatientGroupBeens);
                            parse2GroupsBean.parseJson(result_bean);

                            //清空保存的数据
                            mConsultPatientGroupBeanLinkedHashMap.clear();
                            mConsultPatientGroupBeanList.clear();
                            //保存分组数据及处理分组数据
                            for (int i = 0; i < mConsultPatientGroupBeens.size(); i++) {
                                ConsultPatientGroupBean consultPatientGroupBean = mConsultPatientGroupBeens.get(i);
                                mConsultPatientGroupBeanLinkedHashMap.put(consultPatientGroupBean.getId(), consultPatientGroupBean);
                                //剔除未分组数据
                                if (!"0".equals(consultPatientGroupBean.getId())) {
                                    mConsultPatientGroupBeanList.add(consultPatientGroupBean);
                                }
                            }
                            initGroupLayout();
                            if (!mCurrentGroupId.equals("all") && !mCurrentGroupId.equals("-1")) {//不是abc列表和搜索结果页
                                ConsultPatientGroupBean consultPatientGroupBean = mConsultPatientGroupBeanLinkedHashMap.get(mCurrentGroupId);
                                if (consultPatientGroupBean == null) {
                                    mCurrentPatientList.clear();//清空临时数据
                                    if (mCurrentGroupId.equals("0")) {
                                        //  展示无数据页面   此时未分组列表中无数据
                                        refreshUI(false);
                                    } else {//经编辑我的分组后  此分组不存在  展示abc列表
                                        mCurrentGroupId = "all";
                                        setCenterText("全部患者");
                                        refreshUI(true);
                                    }
                                } else {//经编辑我的分组后  此分组还存在  刷新数据展示
                                    reqGroupPatientsData(consultPatientGroupBean);
                                }
                            }
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        failNum = 1;
                        showNoNetLayout();
                    }

                    // 对账户冻结情况的判断处理
                    public void onFinish() {
                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_BatchSelctPatientsActivity.this,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }


    /**
     * 获取全部患者abc列表
     */
    private void reqABC() {
        RequestParams params = new RequestParams();
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.patient_abclist), params, new
                XCHttpResponseHandler() {

                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            Parse2GroupsPatientBean parse2GroupsPatientBean = new
                                    Parse2GroupsPatientBean(mABCPatientList, mLetters);
                            totalNum = parse2GroupsPatientBean.parseJsonToAll(result_bean);
                            mCurrentGroupId = "all";
                            refreshUI(true);
                        }
                        reqGroupData();
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        failNum = 0;
                        showNoNetLayout();
                    }

                    // 对账户冻结情况的判断处理
                    public void onFinish() {
                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_BatchSelctPatientsActivity.this,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }
}
