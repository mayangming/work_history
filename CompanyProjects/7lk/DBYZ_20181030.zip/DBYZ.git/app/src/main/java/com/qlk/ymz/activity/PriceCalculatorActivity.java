package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.CustomPriceBean;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.parse.Parser2CustomPriceBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CashierInputFilter;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.UtilNum;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCKeyBoardLayout;

import java.util.List;


/**
 * description: 调价计算器
 * autour: YM
 * date: 2017/9/15
 * version: 2.9.2
 */

public class PriceCalculatorActivity extends DBActivity{
    private XCKeyBoardLayout keyboard_layout;
    private ScrollView scrollView;
    private XCTitleCommonLayout pcal_title;
    private ImageView pcal_medichine_item_img;//药品图片
    private ImageView pcal_medichine_status;//药品销售状态
    private ImageView pcal_medicine_presell;//药品预售状态
    private TextView pcal_medichine_item_stock_num;//药品库存数量
    private TextView pcal_medicine_name;//药品名
    private TextView pcal_medicine_firm;//药品厂商
    private TextView pcal_medicine_price_platform;//药品平台均价
    private TextView pcal_medicine_price_doctor;//药品其它医生均价
    private EditText pcal_medicine_price_set_edt;//药品价格设置框
    private TextView pcal_medicine_price_platform_show;//药品平台供货价
    private TextView pcal_medicine_price_profit_show;//药品商品积分
    private TextView pcal_custom_price_range;//药品售价范围
    private TextView pcal_medicine_price_profit_rule;//药品商品积分计算规则
    private ImageView backImg;//返回按钮
    private TextView saveTv;//保存按钮
    private String skuId = "";
    private CustomPriceBean customPriceBean = new CustomPriceBean();
    public static final String CUSTOM_PRICE_SKUID = "custom_price_skuId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_price_calculator);
        super.onCreate(savedInstanceState);
        requestMedicineMesage();
    }

    /** created by songxin,date：2017-10-30,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PriceCalculatorActivity.class);
    }

    /** created by songxin,date：2017-10-30,about：bi,end */

    @Override
    public void initWidgets() {
        keyboard_layout = getViewById(R.id.keyboard_layout);
        scrollView = getViewById(R.id.scrollView);
        pcal_title = getViewById(R.id.pcal_title);
        pcal_medichine_item_img = getViewById(R.id.pcal_medichine_item_img);
        pcal_medicine_presell = getViewById(R.id.pcal_medicine_presell);
        pcal_medichine_item_stock_num = getViewById(R.id.pcal_medichine_item_stock_num);
        pcal_medicine_name = getViewById(R.id.pcal_medicine_name);
        pcal_medicine_firm = getViewById(R.id.pcal_medicine_firm);
        pcal_medicine_price_platform = getViewById(R.id.pcal_medicine_price_platform);
        pcal_medicine_price_doctor = getViewById(R.id.pcal_medicine_price_doctor);
        pcal_medicine_price_platform = getViewById(R.id.pcal_medicine_price_platform);
        pcal_medicine_price_set_edt = getViewById(R.id.pcal_medicine_price_set_edt);
        pcal_medicine_price_platform_show = getViewById(R.id.pcal_medicine_price_platform_show);
        pcal_medicine_price_profit_show = getViewById(R.id.pcal_medicine_price_profit_show);
        pcal_custom_price_range = getViewById(R.id.pcal_custom_price_range);
        pcal_medichine_status = getViewById(R.id.pcal_medichine_status);
        pcal_medicine_price_profit_rule = getViewById(R.id.pcal_medicine_price_profit_rule);
        backImg = pcal_title.getXc_id_titlebar_left_imageview();
        saveTv = pcal_title.getXc_id_titlebar_right2_textview();
        pcal_medicine_price_set_edt.setFilters(new InputFilter[]{new CashierInputFilter()});
        initTitle();
        initData();
    }

    @Override
    public void listeners() {
        backImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isModifyCustomPrice()){
                    abandonModifyDialog();
                }else {
                    myFinish();
                }
            }
        });
        pcal_medicine_presell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!UtilString.isBlank(customPriceBean.getPresellInfo()))
                    shortToast(customPriceBean.getPresellInfo());
            }
        });
        saveTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2017-10-30,about：saveInfo,begin
                BiUtil.saveBiInfo(PriceCalculatorActivity.class, "2", "128", "saveTv","", false);
                // created by songxin,date：2017-10-30,about：saveInfo,end
                saveMedicinePrice();
                JS_WebViewActivity.isRefresh = true;
            }
        });
        pcal_medicine_price_set_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                // created by songxin,date：2017-10-30,about：saveInfo,begin
                BiUtil.saveBiInfo(PriceCalculatorActivity.class, "2", "128", "pcal_medicine_price_set_edt","", false);
                // created by songxin,date：2017-10-30,about：saveInfo,end
                updateCustomPrice();
            }
        });

        keyboard_layout.setOnResizeListener(new XCKeyBoardLayout.OnResizeListener() {
            @Override
            public void OnResize(int w, int h, int oldw, int oldh) {
                if (0 != oldw && 0 != oldh) {
                    if (h < oldh) {
                        // 弹起
                        scrollView.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                scrollView.smoothScrollBy(0,1000);
                            }
                        },100);
                    }
                }
            }
        });
    }

    @Override
    public void onNetRefresh() {}

    @Override
    public void myFinish() {
        super.myFinish();
        overridePendingTransition(0, R.anim.xc_anim_alpha);
        dismissDialog();
    }

    private void initTitle(){
        pcal_title.setTitleCenter(true,"调价计算器");
        pcal_title.setTitleRight2(true,-1,"保存");
        pcal_title.setTitleLeft(true,null);
    }

    private void initData(){
        skuId = getIntent().getStringExtra(CUSTOM_PRICE_SKUID);
    }

    private void requestMedicineMesage(){
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("skuId",skuId);
        XCHttpAsyn.postAsyn(this,AppConfig.getHostUrl(AppConfig.price_info),params,new XCHttpResponseHandler(){

            @Override
            public void success() {
                super.success();
                if (result_boolean) {
                    Parser2CustomPriceBean parser2CustomPriceBean = new Parser2CustomPriceBean(customPriceBean);
                    parser2CustomPriceBean.parseJson(result_bean);
                    refreshData();
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                GeneralReqExceptionProcess.checkCode(PriceCalculatorActivity.this, getCode(), getMsg());
            }
        });
    }

    private void saveMedicinePrice(){
        try {
            Double.valueOf(pcal_medicine_price_set_edt.getText().toString().trim());
        }catch (Exception e){
            shortToast("价格输入有误，请重新输入!");
            return;
        }
        if (!isWithinLimits()){
            return;
        }
        RequestParams params = new RequestParams();
        params.put("doctorId",UtilSP.getUserId());
        params.put("skuId",skuId);
        params.put("customPrice",customPrice);//单位为分
        XCHttpAsyn.postAsyn(this,AppConfig.getHostUrl(AppConfig.price_insert),params,new XCHttpResponseHandler(){
            @Override
            public void success() {
                super.success();
                if (result_boolean) {
                    XC_PatientDrugInfo patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
                    if (null != patientDrugInfo){
                        List<DrugBean> drugBeans = patientDrugInfo.getList();
                        for (DrugBean drugBean : drugBeans){//修改存储数据的内容
                            if (skuId.equals(drugBean.getSkuId())){
                                drugBean.setSalePrice(pcal_medicine_price_set_edt.getText().toString().trim());
                            }
                        }
                    }
                    DrugBean.drug_price = StringUtils.getMoneyString(customPrice);
                    myFinish();
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                GeneralReqExceptionProcess.checkCode(PriceCalculatorActivity.this, getCode(), getMsg());
            }
        });
    }

    private boolean isWithinLimits(){
        boolean result = true;
        long max = UtilString.toLong(customPriceBean.getPriceMax());
        long min = UtilString.toLong(customPriceBean.getPriceMin());
        if (customPrice > max || customPrice < min){
            shortToast("当前定价已超出调价范围，请重新定价");
            result = false;
        }
        return result;
    }

    private void refreshData(){
        if (isEmptyStock()){
            pcal_medichine_item_stock_num.setText("剩余0件");
        }else if(Integer.parseInt(customPriceBean.getStockNum()) <= 99) {
            pcal_medichine_item_stock_num.setText("剩余" + customPriceBean.getStockNum() + "件");
        }else{
            pcal_medichine_item_stock_num.setText("剩余99+件");
        }
        if (customPriceBean.isSale()){
            pcal_medichine_status.setVisibility(View.VISIBLE);
            pcal_medichine_status.setBackgroundResource(R.mipmap.sk_d_medicine_sale);
        }else if (customPriceBean.isShort()){
            pcal_medichine_status.setVisibility(View.VISIBLE);
            pcal_medichine_status.setBackgroundResource(R.mipmap.sk_d_medicine_short);
        }else{
            pcal_medichine_status.setVisibility(View.GONE);
        }
//        库存显示规则，优先级为 1 > 2;
//        1、已下架的商品状态
//        2、没有库存且是预售状态则显示预售，否则显示其他状态
        if (!customPriceBean.isSale() && isEmptyStock() && customPriceBean.isPresell()){
            pcal_medichine_item_stock_num.setVisibility(View.INVISIBLE);
            pcal_medicine_presell.setVisibility(View.VISIBLE);
        }else{
            pcal_medichine_item_stock_num.setVisibility(View.VISIBLE);
            pcal_medicine_presell.setVisibility(View.INVISIBLE);
        }

        XCApplication.displayImage(customPriceBean.getIcon(),pcal_medichine_item_img);
        pcal_medicine_price_set_edt.setText(StringUtils.getMoneyString(customPriceBean.getDefaultPrice()));
        pcal_medicine_name.setText(customPriceBean.getProductName());
        pcal_medicine_firm.setText(customPriceBean.getManufacturer());
        pcal_medicine_price_platform.setText("平台标准价 ".concat("¥").concat(StringUtils.getMoneyString(customPriceBean.getNationalPrice())));
        pcal_medicine_price_doctor.setText("其它医生均价 ".concat("¥").concat(StringUtils.getMoneyString(customPriceBean.getAveragePrice())));
        pcal_medicine_price_platform_show.setText("¥".concat(StringUtils.getMoneyString(customPriceBean.getSupplyPrice())));
        pcal_custom_price_range.setText("调价范围 ¥"+StringUtils.getMoneyString(customPriceBean.getPriceMin())+"-"+StringUtils.getMoneyString(customPriceBean.getPriceMax()));
        pcal_medicine_price_profit_rule.setText("= (我的定价-平台供货价) *".concat(customPriceBean.getPointToRMBScale()));
        UtilInputMethod.openInputMethod(pcal_medicine_price_set_edt,this);
        pcal_medicine_price_set_edt.setSelection(pcal_medicine_price_set_edt.getText().toString().length());
    }

    long customPrice;
    private void updateCustomPrice(){
        double customPriceDouble = UtilString.toDouble(pcal_medicine_price_set_edt.getText().toString().trim());
        customPrice = UtilNum.yuan2FenBigDecimal(UtilNum.saveNum(customPriceDouble,2));
        double pointToRMBScale = UtilString.toDouble(customPriceBean.getPointToRMBScale());//RMB 与 积分兑换比例
        double supplyPrice = UtilString.toDouble(StringUtils.getMoneyString(customPriceBean.getSupplyPrice()));
        double sub = UtilNum.sub(customPriceDouble,supplyPrice); // (我的定价 - 平台供货价) * 积分兑换比例
        double goodsDouble = UtilNum.mul(sub,pointToRMBScale);
//        long goodsIntegrate = (long) UtilNum.saveNum(goodsDouble,0);
        if (goodsDouble < 0)
            goodsDouble = 0;
        pcal_medicine_price_profit_show.setText(String.valueOf(goodsDouble));
    }

    /* 库存是否为空 */
    private boolean isEmptyStock(){
        return TextUtils.isEmpty(customPriceBean.getStockNum()) || "0".equals(customPriceBean.getStockNum());
    }

    /* 是否修改过价格 */
    private boolean isModifyCustomPrice(){
        String customPriceContent = String.valueOf(customPrice);
        return !customPriceContent.equals(customPriceBean.getDefaultPrice());
    }
    YR_CommonDialog abandonModifyDialog = null;
    private void abandonModifyDialog(){
        dismissDialog();
        abandonModifyDialog = new YR_CommonDialog(this,"是否放弃修改?","放弃","取消") {
            @Override
            public void confirmBtn() {
                dismissDialog();
            }

            @Override
            public void cancelBtn() {
                super.cancelBtn();
                dismissDialog();
                myFinish();
            }
        };
        abandonModifyDialog.show();
    }

    private void dismissDialog(){
        if (!isFinishing() || !isDestroy ){
            if (null != abandonModifyDialog && abandonModifyDialog.isShowing())
                abandonModifyDialog.dismiss();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (isModifyCustomPrice()){
                abandonModifyDialog();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}
