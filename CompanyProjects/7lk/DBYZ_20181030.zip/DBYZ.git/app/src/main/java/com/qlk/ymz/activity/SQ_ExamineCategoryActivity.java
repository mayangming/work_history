package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SQ_ExamineAdapterA;
import com.qlk.ymz.adapter.SQ_ExamineAdapterB;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.SQ_ExamineAModel;
import com.qlk.ymz.model.SQ_ExamineBModel;
import com.qlk.ymz.model.SQ_InspectSRActivityLaunchModel;
import com.qlk.ymz.parse.Parse2InspectBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 赖善琦
 * @version 2.7.0
 * 检查分类页
 */

public class SQ_ExamineCategoryActivity extends DBActivity {
    /**一级分类列表*/
    private ListView sq_lv_inspect_a;
    /**二级分类列表*/
    private RecyclerView sq_rv_inspect_b;
    /** 一级分类列表adapter*/
    private SQ_ExamineAdapterA inspectAdapterA;
    /** 二级分类列表adapter */
    private SQ_ExamineAdapterB inspectAdapterB;
    /** 一级分类数据集 */
    private List<SQ_ExamineAModel> listA = new ArrayList<>();
    /** 二级分类数据集 */
    private List<SQ_ExamineBModel> listB = new ArrayList<>();
    /** 返回箭头 */
    private ImageView xc_id_titlebar_left_imageview;
    /** 检查单总数布局 */
    private RelativeLayout sq_id_choice_inspect_recommend;
    private XCTitleCommonLayout title_bar;
    /** 检查单数量 */
    private TextView sq_id_choice_inspect_recommend_num;
    /** 传递数据model */
    private SQ_InspectSRActivityLaunchModel inspectSRActivityLaunchModel;
    /** 顶部提示信息 */
    private TextView sq_id_ea_msg;

    public static void launch(Activity activity){
        activity.startActivity(new Intent(activity,SQ_ExamineCategoryActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sq_activity_inspect);
        super.onCreate(savedInstanceState);

        requestData();
        requestConfigData();
    }

    /** created by songxin,date：2017-10-30,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SQ_ExamineCategoryActivity.class);
    }

    /** created by songxin,date：2017-10-30,about：bi,end */

    @Override
    public void initWidgets() {
        inspectSRActivityLaunchModel = new SQ_InspectSRActivityLaunchModel();
        XC_ChatModel chatModel = (XC_ChatModel) getIntent().getSerializableExtra(SQ_InspectSRActivityLaunchModel.LAUNCH_CODE);
        inspectSRActivityLaunchModel.setChatModel(chatModel);

        xc_id_titlebar_left_imageview = getViewById(R.id.xc_id_titlebar_left_imageview);
        title_bar = getViewById(R.id.title_bar);
        sq_id_choice_inspect_recommend_num = getViewById(R.id.sq_id_choice_inspect_recommend_num);
        sq_id_choice_inspect_recommend = getViewById(R.id.sq_id_choice_inspect_recommend);
        sq_lv_inspect_a = getViewById(R.id.sq_lv_inspect_a);
        sq_rv_inspect_b = getViewById(R.id.sq_rv_inspect_b);
        sq_id_ea_msg = getViewById(R.id.sq_id_ea_msg);

        title_bar.setTitleLeft(true,null);
        title_bar.setTitleCenter(true,"选择检查项");

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        sq_rv_inspect_b.setLayoutManager(gridLayoutManager);
        sq_rv_inspect_b.addItemDecoration(new SpaceItemDecoration(UtilScreen.dip2px(this, 5)));

        inspectAdapterA = new SQ_ExamineAdapterA(this,listA);
        inspectAdapterB = new SQ_ExamineAdapterB(this);
        sq_lv_inspect_a.setAdapter(inspectAdapterA);
        sq_rv_inspect_b.setAdapter(inspectAdapterB);
        updataView();

    }

    @Override
    public void listeners() {
        xc_id_titlebar_left_imageview.setOnClickListener(this);

        sq_id_choice_inspect_recommend.setOnClickListener(this);

        sq_lv_inspect_a.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                for (SQ_ExamineAModel model : listA) {
                    model.setCheck(false);
                }

                SQ_ExamineAModel model = (SQ_ExamineAModel) adapterView.getItemAtPosition(i);
                model.setCheck(true);

                inspectAdapterB.updateAndNotify(model.getListB());
                inspectAdapterA.notifyDataSetChanged();
            }
        });

        inspectAdapterB.setOnClickAction(new SQ_ExamineAdapterB.OnClickAction() {
            @Override
            public void OnItemClickAction(View view) {
                SQ_ExamineBModel inspectBModel = (SQ_ExamineBModel) view.getTag();
                inspectSRActivityLaunchModel.setCategoryId(inspectBModel.getId());

                // created by songxin,date：2017-10-30,about：saveInfo,begin
                BiUtil.saveBiInfo(SQ_ExamineCategoryActivity.class, "2", "128", "inspectAdapterB",inspectBModel.getName(), false);
                // created by songxin,date：2016-10-30,abou t：saveInfo,end

                Intent intent = new Intent(SQ_ExamineCategoryActivity.this,SQ_ExamineListActivity.class);
                intent.putExtra(SQ_InspectSRActivityLaunchModel.LAUNCH_CODE,inspectSRActivityLaunchModel);
                myStartActivityForResult(intent,InspectRquestCode);
            }
        });

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){

            case R.id.xc_id_titlebar_left_imageview:
                // created by songxin,date：2017-10-30,about：saveInfo,begin
                BiUtil.saveBiInfo(SQ_ExamineCategoryActivity.class, "2", "128", "xc_id_titlebar_left_imageview","", false);
                // created by songxin,date：2016-10-30,abou t：saveInfo,end
                myFinish();
                break;

            case R.id.sq_id_choice_inspect_recommend:
                if(inspectSRActivityLaunchModel.getExamineBeanList().size() > 0) {
                    InspectOrdonnanceActivity.launch(this, inspectSRActivityLaunchModel);
                }else {
                    shortToast("检查项为空，请选择检查项目");
                }
                break;
        }
    }

    public static int InspectRquestCode = 10;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode != Activity.RESULT_OK){
            return;
        }
        inspectSRActivityLaunchModel =
                (SQ_InspectSRActivityLaunchModel)data
                        .getSerializableExtra(SQ_InspectSRActivityLaunchModel.LAUNCH_CODE);
        updataView();
    }

    /**
     * 更新页面
     */
    public void updataView(){
        sq_id_choice_inspect_recommend_num.setText(
                "检查单\n"+inspectSRActivityLaunchModel.getExamineBeanList().size()+"种");

    }

    @Override
    public void onNetRefresh() {

    }

    /**
     * 二级分类的间隔
     */
    class SpaceItemDecoration extends RecyclerView.ItemDecoration {
        private int space;

        public SpaceItemDecoration(int space) {
            this.space = space;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            outRect.top = space;
            outRect.left = space;
        }
    }

    /**
     * 请求二级分类接口数据
     */
    public void  requestData(){
        RequestParams params = new RequestParams();

        XCHttpAsyn.postAsyn(this, AppConfig.getAeUrl(AppConfig.categroy_list),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){
                    Parse2InspectBean parse2InspectBean = new Parse2InspectBean();
                    listA = parse2InspectBean.parse2InspectModelList(result_bean);
                    if (listA.size() > 0) {
                        for (int i = 0; i < listA.size(); i++) {
                            if ("1".equals(listA.get(i).getState())) {
                                listA.get(i).setCheck(true);
                                inspectAdapterB.updateAndNotify(listA.get(i).getListB());
                                break;
                            }
                        }
                        inspectAdapterA.update(listA);
                    }
                }
            }
        });
    }

    /**
     * 请求顶部提醒信息
     */
    public void  requestConfigData(){
        RequestParams params = new RequestParams();

        XCHttpAsyn.postAsyn(this, AppConfig.getAeUrl(AppConfig.eaConfig),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){
                    sq_id_ea_msg.setText(result_bean.getList("data").get(0).getString("remindInfo"));
                }
            }
        });
    }
}
