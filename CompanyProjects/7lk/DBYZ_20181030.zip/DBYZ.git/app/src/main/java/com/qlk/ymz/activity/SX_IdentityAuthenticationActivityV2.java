package com.qlk.ymz.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.AuthDataInfo;
import com.qlk.ymz.parse.Parse2AuthData;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ArcProgress;
import com.qlk.ymz.view.CircleImageView;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.fragment.XCCameraPhotoFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.io.File;

/**
 * SX_IdentityAuthenticationActivityV2
 * 身份认证2.0
 * @author songxin on 2016/1/8.
 * @version 2.0
 *
 *
 * SX_IdentityAuthenticationActivityV2
 * 身份认证2.9
 * @author songxin change on 2016/1/8.
 * @version 2.0
 */
public class SX_IdentityAuthenticationActivityV2 extends DBActivity implements View.OnClickListener,
        XCCameraPhotoFragment.OnCaremaSelectedFileListener{
    /** 通用标题 */
    XCTitleCommonLayout titlebar;
    /**个人照片上传*/
    private RelativeLayout sx_id_upload_personal_photos_rl;
    /**个人照片上传显示*/
    private CircleImageView sx_id_upload_personal_photos_show;
    /**个人照片删除*/
    private ImageView sx_id_delete_personal_picture;
    /**工作证上传*/
    private RelativeLayout sx_id_upload_emp_card_rl;
    /**工作证待提交提示文字*/
    private TextView sx_id_emp_card_waitting_submit;
    /**执业资格证上传*/
    private RelativeLayout sx_id_upload_vocational_qualification_certificate_rl;
    /**执业资格证待提交提示文字*/
    private TextView sx_id_vocational_qualification_certificate_waitting_submit;
    /**提交认证*/
    private RelativeLayout sx_id_identity_submit_authentication_rl;
    /**调用相机Fragment*/
    private XCCameraPhotoFragment xcCameraPhotoFragment;
    /**个人照片文件，工作证照片文件，执业资格证照片文件*/
    private File mPersonalPhotosImgFile,mEmpCard,mVocationalQC,mOldVocationalQC;
    /**个人照片文件，工作证照片文件，执业资格证照片文件地址，执业资格证号码*/
    private String photoUrl = "",emcardUrl = "",vocatecerUrl = "",doctorPracticeCertificateString = "";
    /**上传文件弹出Dialog*/
    private ConfirmDialog mLoadingDialog;
    /**图片选择弹出Dialog*/
    private ConfirmDialog mUploadDialog;
    /**上传文件弹出Dialog，Loading框*/
    private ArcProgress mArcProgress;
    /**上传文件弹出Dialog，Loading框下方文字*/
    private TextView mLoadingText;
    /**上传文件弹出Dialog，失败时显示图片*/
    private ImageView mUploadFail;
    /**图片选择标记*/
    private int mMarkOnclickEvent = -1;
    /**Intent*/
    private Intent mIntent;
    /**保存文字*/
    private TextView sx_id_save_text;

    private String mAuthStatus = "";
    /** 上传图片*/
    private TextView xc_id_pop_photoUpload;
    /** 从手机相册选择*/
    private TextView xc_id_pop_localAlbum;
    /** 取消*/
    private TextView xc_id_pop_cancel;


    private boolean isNewVocationalQC = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// 设置布局
		setContentView(R.layout.sx_l_activity_identity_authentication_v2);
		super.onCreate(savedInstanceState);
        //dialog初始化
        initDialog();
        //进入身份认证，先获取个人资料状态
        getAuthData();
        //Fragment初始化
        xcCameraPhotoFragment = new XCCameraPhotoFragment();
        xcCameraPhotoFragment.setIsAllowResizeImage(false);
        addFragment(R.id.sx_id_openshop_camera_rl, xcCameraPhotoFragment);
        xcCameraPhotoFragment.setOnCaremaSelectedFileListener(this);
        mIntent = new Intent();
	}

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_IdentityAuthenticationActivityV2.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */


	// 无网络时,点击屏幕后回调的方法
	@Override
	public void onNetRefresh() {
	}

	// 初始化控件
	@Override
	public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleCenter(true, "医生资质");
        titlebar.setTitleRight2(true, 0, "示例");

        sx_id_upload_personal_photos_rl = getViewById(R.id.sx_id_upload_personal_photos_rl);
        sx_id_upload_personal_photos_show  = getViewById(R.id.sx_id_upload_personal_photos_show);
        sx_id_delete_personal_picture  = getViewById(R.id.sx_id_delete_personal_picture);
        sx_id_upload_emp_card_rl = getViewById(R.id.sx_id_upload_emp_card_rl);
        sx_id_emp_card_waitting_submit = getViewById(R.id.sx_id_emp_card_waitting_submit);
        sx_id_upload_vocational_qualification_certificate_rl = getViewById(R.id.sx_id_upload_vocational_qualification_certificate_rl);
        sx_id_vocational_qualification_certificate_waitting_submit = getViewById(R.id.sx_id_vocational_qualification_certificate_waitting_submit);
        sx_id_identity_submit_authentication_rl = getViewById(R.id.sx_id_identity_submit_authentication_rl);
        sx_id_save_text = getViewById(R.id.sx_id_save_text);
    }

	// 设置监听
	@Override
	public void listeners() {
        titlebar.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mIntent.setClass(SX_IdentityAuthenticationActivityV2.this,SX_SampleActivity.class);
                startActivity(mIntent);
                overridePendingTransition(R.anim.pop_up, R.anim.pop_down);//不加的话默认页面从左向右划出
            }
        });

        sx_id_upload_personal_photos_rl.setOnClickListener(this);
        sx_id_upload_personal_photos_show.setOnClickListener(this);
        sx_id_delete_personal_picture.setOnClickListener(this);
        sx_id_upload_emp_card_rl.setOnClickListener(this);
        sx_id_upload_vocational_qualification_certificate_rl.setOnClickListener(this);
        sx_id_identity_submit_authentication_rl.setOnClickListener(this);
	}

    @SuppressLint("WrongConstant")
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            //上传个人照片
            case R.id.sx_id_upload_personal_photos_rl:
                mMarkOnclickEvent = 1;
                uploadDialogShow();
                break;
            //个人照片上传显示
            case R.id.sx_id_upload_personal_photos_show:
                String s = "";
                if(null != mPersonalPhotosImgFile){
                    mIntent.putExtra("toShowPicture","0");
                    s = mPersonalPhotosImgFile.getAbsolutePath();
                }else{
                    s = photoUrl;
                    mIntent.putExtra("toShowPicture","1");
                }
                mIntent.putExtra("FILE_PATH", s);
                mIntent.putExtra("PICTURE_NAME", "个人照片");
                mIntent.setClass(SX_IdentityAuthenticationActivityV2.this,SX_ShowPictureActivity.class);
                myStartActivity(mIntent);
                break;
            //个人照片删除
            case R.id.sx_id_delete_personal_picture:
                mPersonalPhotosImgFile = null;
                sx_id_upload_personal_photos_show.setImageURI(null);
                sx_id_delete_personal_picture.setVisibility(View.GONE);
                sx_id_upload_personal_photos_show.setVisibility(View.GONE);
                sx_id_upload_personal_photos_rl.setBackgroundResource(R.mipmap.sx_d_identity_personal_head_icon_v2);
                checkFile();
                break;
            //跳转到上传工作证
            case R.id.sx_id_upload_emp_card_rl:{
                Intent intent = new Intent();
                if(UtilString.isBlank(emcardUrl)){
                    intent.putExtra("filePath","");
                }else {
                    intent.putExtra("filePath",emcardUrl);
                }
                intent.setClass(SX_IdentityAuthenticationActivityV2.this,SX_EmpCardActivity.class);
                myStartActivityForResult(intent,2000);
                break;
            }
            //跳转到上传执业资格证
            case R.id.sx_id_upload_vocational_qualification_certificate_rl:{
                Intent intent = new Intent();
                intent.putExtra("doctorPracticeCertificateString",doctorPracticeCertificateString);
                intent.putExtra("filePath",vocatecerUrl);
                intent.setClass(SX_IdentityAuthenticationActivityV2.this,SX_QualificationSelectionActivity.class);
                startActivity(intent);
                break;
            }
            //提交认证按钮
            case R.id.sx_id_identity_submit_authentication_rl:
                uploadInfo(doctorPracticeCertificateString,mVocationalQC,mPersonalPhotosImgFile,mEmpCard);
                break;
            //拍照
            case R.id.xc_id_pop_photoUpload:
                xcCameraPhotoFragment.getTakePhoto();
                uploadDialogDismiss();
                break;
            //本地上传
            case R.id.xc_id_pop_localAlbum:
                ToJumpHelp.toJumpSelctImgsActivity(this, 1, YY_SelectImgsActivity.MODE_SINGLE,
                        false, true, false, true);
                uploadDialogDismiss();
                break;
            //取消
            case R.id.xc_id_pop_cancel:
                uploadDialogDismiss();
                break;
            default:
                break;
        }
    }

    private void uploadDialogDismiss(){
        if(null != mUploadDialog && mUploadDialog.isShowing()){
            mUploadDialog.dismiss();
        }
    }

    private void uploadDialogShow(){
        if(null != mUploadDialog && !mUploadDialog.isShowing()){
            mUploadDialog.show();
        }
    }

    /**
     * 检测是否有为三张都有,并且有执业资格证号码，如果不是文字颜色置灰
     * 执业资格证需要判断是新版还是旧版，新版只需要三张+号码，旧版要4张加号码
     */
    private void checkFile(){
        if(null != mPersonalPhotosImgFile && null != mEmpCard && null != mVocationalQC && !UtilString.isBlank(doctorPracticeCertificateString)){
            if(isNewVocationalQC){
                sx_id_save_text.setTextColor(getResources().getColor(R.color.c_e2231a));
            }else {
                if(null != mOldVocationalQC){
                    sx_id_save_text.setTextColor(getResources().getColor(R.color.c_e2231a));
                }else {
                    sx_id_save_text.setTextColor(getResources().getColor(R.color.c_login_text_bg));
                }
            }
        }else {
            sx_id_save_text.setTextColor(getResources().getColor(R.color.c_login_text_bg));
        }
    }

    /**
     * 调用相机fragment返回file文件
     * @param file
     */
    @Override
    public void onCaremaSelectedFile(File file) {
        switch(mMarkOnclickEvent){
            case 1:{
                // add by xjs on 20151214 start
                // 添加进行图片裁剪的处理
                Intent intent = new Intent(SX_IdentityAuthenticationActivityV2.this, JS_ClipImageActivity.class);
                intent.putExtra("file", file);
                startActivityForResult(intent, 1000);
                // add by xjs on 20151214 end
                break;
            }
        }
    }


    /**
     * 获取用户状态
     */
    private void getAuthData(){
        XCHttpAsyn.postAsyn(false, SX_IdentityAuthenticationActivityV2.this, AppConfig.getHostUrl(AppConfig.user_authData), new RequestParams(), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    AuthDataInfo authDataInfo = new AuthDataInfo();
                    Parse2AuthData parse2AuthData = new Parse2AuthData(authDataInfo);
                    parse2AuthData.parseJson(result_bean);
                    photoUrl = authDataInfo.getAvatar();
                    if(!UtilString.isBlank(photoUrl)){
                        sx_id_delete_personal_picture.setVisibility(View.VISIBLE);
                        sx_id_upload_personal_photos_show.setVisibility(View.VISIBLE);
                        XCApplication.displayImage(photoUrl, sx_id_upload_personal_photos_show);
                        mPersonalPhotosImgFile = XCApplication.base_imageloader.getDiscCache().get(photoUrl);
                        sx_id_upload_personal_photos_rl.setBackgroundColor(Color.TRANSPARENT);
                    }
                    mAuthStatus = authDataInfo.getStatus();
                    UtilSP.setAuthStatus(mAuthStatus);
                    if ("0".equals(mAuthStatus)||"3".equals(mAuthStatus)){//认证中和再次认证中都是等待审核不能提交
                        sx_id_upload_personal_photos_rl.setClickable(false);
                        sx_id_upload_emp_card_rl.setClickable(false);
                        sx_id_upload_vocational_qualification_certificate_rl.setClickable(false);
                        sx_id_delete_personal_picture.setVisibility(View.INVISIBLE);
                        sx_id_identity_submit_authentication_rl.setVisibility(View.INVISIBLE);
                        sx_id_emp_card_waitting_submit.setVisibility(View.VISIBLE);
                        sx_id_emp_card_waitting_submit.setText("待审核");
                        sx_id_vocational_qualification_certificate_waitting_submit.setVisibility(View.VISIBLE);
                        sx_id_vocational_qualification_certificate_waitting_submit.setText("待审核");
                    //只有当认证失败的时候需要组织以下内容
                    }else if("2".equals(mAuthStatus)){
                        accordingToStatusChange(authDataInfo);
                    }else if("4".equals(mAuthStatus) || "5".equals(mAuthStatus) ){
                        //如果状态是未认证，已上传状态，需要显示图片
                        if("1".equals(authDataInfo.getUploadStatus())){
                            accordingToStatusChange(authDataInfo);
                        }else{
                            sx_id_identity_submit_authentication_rl.setVisibility(View.VISIBLE);
                        }
                    }else {
                        sx_id_identity_submit_authentication_rl.setVisibility(View.VISIBLE);
                    }

                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_IdentityAuthenticationActivityV2.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }


    /**
     * 根据状态改变显示
     * @param authDataInfo
     */
    private void accordingToStatusChange(AuthDataInfo authDataInfo){
        ImageView vqcImage = new ImageView(this);
        ImageView vqcOldImage = new ImageView(this);
        ImageView empImage = new ImageView(this);
        if("2".equals(authDataInfo.getMedicalLicense().getVersionType())){
            isNewVocationalQC = false;
        }else {
            isNewVocationalQC = true;
        }
        emcardUrl = authDataInfo.getEmcard();
        XCApplication.base_imageloader.displayImage(emcardUrl,empImage, XCImageLoaderHelper.getDisplayImageOptions());
        mEmpCard = XCApplication.base_imageloader.getDiscCache().get(emcardUrl);
        StringBuffer sb = new StringBuffer();
        int size = authDataInfo.getMedicalLicense().getUrls().size();
        if(size > 0){
            for(int i = 0;i <size;i++){
                if(i == size - 1){
                    sb.append(authDataInfo.getMedicalLicense().getUrls().get(i));
                }else {
                    sb.append(authDataInfo.getMedicalLicense().getUrls().get(i) + ",");
                }
            }
            vocatecerUrl = sb.toString();
            if(size == 1){
                XCApplication.base_imageloader.displayImage(authDataInfo.getMedicalLicense().getUrls().get(0),vqcImage, XCImageLoaderHelper.getDisplayImageOptions());
                mVocationalQC = XCApplication.base_imageloader.getDiscCache().get(authDataInfo.getMedicalLicense().getUrls().get(0));
            }else if(size == 2){
                XCApplication.base_imageloader.displayImage(authDataInfo.getMedicalLicense().getUrls().get(0),vqcImage, XCImageLoaderHelper.getDisplayImageOptions());
                mVocationalQC = XCApplication.base_imageloader.getDiscCache().get(authDataInfo.getMedicalLicense().getUrls().get(0));
                XCApplication.base_imageloader.displayImage(authDataInfo.getMedicalLicense().getUrls().get(1),vqcOldImage, XCImageLoaderHelper.getDisplayImageOptions());
                mOldVocationalQC = XCApplication.base_imageloader.getDiscCache().get(authDataInfo.getMedicalLicense().getUrls().get(1));
            }
        }else {
            vocatecerUrl = "";
        }

        printi("http","vocatecerUrl--->"+vocatecerUrl);
        doctorPracticeCertificateString = authDataInfo.getMedicalLicense().getLicenseNumber();
        //显示待提交文字
        sx_id_emp_card_waitting_submit.setVisibility(View.VISIBLE);
        sx_id_vocational_qualification_certificate_waitting_submit.setVisibility(View.VISIBLE);
        //验证是否可以点击提交按钮
        checkFile();
    }

    /**
     * dialog初始化
     */
    private void initDialog(){
        int srceenW =  this.getWindowManager().getDefaultDisplay().getWidth();
        mLoadingDialog = new ConfirmDialog(SX_IdentityAuthenticationActivityV2.this, srceenW,245
                ,R.layout.sx_l_dialog_loading,R.style.xc_s_dialog);
        mLoadingDialog.setCanceledOnTouchOutside(false);
        mArcProgress = (ArcProgress)mLoadingDialog.findViewById(R.id.sx_id_progress);
        mLoadingText = (TextView)mLoadingDialog.findViewById(R.id.sx_id_dialog_text);
        mUploadFail = (ImageView)mLoadingDialog.findViewById(R.id.sx_id_upload_fail);


        mUploadDialog = new ConfirmDialog(SX_IdentityAuthenticationActivityV2.this, srceenW,245
                ,R.layout.xc_l_pop_window_photo,R.style.xc_s_dialog);
        mUploadDialog.setCanceledOnTouchOutside(false);
        Window window = mUploadDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        xc_id_pop_photoUpload = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_photoUpload);
        xc_id_pop_localAlbum = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_localAlbum);
        xc_id_pop_cancel = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_cancel);
        xc_id_pop_photoUpload.setOnClickListener(this);
        xc_id_pop_localAlbum.setOnClickListener(this);
        xc_id_pop_cancel.setOnClickListener(this);
    }


    /**
     * 资质上传接口
     * @param licenseNumber 职业资格证号
     * @param photoPage 职业资格证(如果是旧版本的话,此字段是照片页,如果是新版本的话,使用此字段上传)
     * @param avatar 个人照片
     * @param emCard 工作证
     *
     */
    private void uploadInfo(String licenseNumber,File photoPage,File avatar,File emCard){
        try {
            if(UtilString.isBlank(licenseNumber)){
                shortToast("请输入资格证书编号");
                return;

            }
            if(null == avatar){
                shortToast("请上传个人头像");
                return;
            }
            if(isNewVocationalQC){
                if(null == photoPage){
                    shortToast("你好像还没有上传图片");
                    return;
                }
            }else{
                if(null == photoPage){
                    shortToast("你好像还没有上传图片");
                    return;
                }
                if(null == mOldVocationalQC){
                    shortToast("你好像还没有上传图片");
                    return;
                }
            }

            if(null == emCard){
                shortToast("请上传工作证");
                return;
            }
            mArcProgress.setVisibility(View.VISIBLE);
            mUploadFail.setVisibility(View.GONE);
            mLoadingText.setTextColor(getResources().getColor(R.color.c_orange_fdc953));
            mLoadingText.setText("正在上传，请稍候...");
            mLoadingDialog.setCanceledOnTouchOutside(false);
            mLoadingDialog.show();
            RequestParams params = new RequestParams();
            params.put("number", licenseNumber);
            if(isNewVocationalQC){
                params.put("photoPage", photoPage);
                params.put("versionType", "1");
            }else{
                params.put("photoPage", photoPage);
                params.put("infoPage", mOldVocationalQC);
                params.put("versionType", "2");
            }
            params.put("emCard", emCard);
            params.put("avatar", avatar);
            XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.doctorLicence_upload), params, new XCHttpResponseHandler() {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    dismiss();
                    if (result_boolean) {
                        shortToast("上传成功");
                        UtilSP.setDoctorUploadStatus("1");
                        myFinish();
                    }
                }

                // add by xjs on 20151027 19:48 start
                // 对账户冻结情况的判断处理
                public void onFinish() {
                    super.onFinish();
                    if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_IdentityAuthenticationActivityV2.this,
                            getCode(),
                            getMsg())) {
                        // 接口请求业务成功时的处理
                    }
                }
                // add by xjs on 20151027 19:48 end

                @Override
                public void onProgress(long bytesWritten, long totalSize) {
                    super.onProgress(bytesWritten, totalSize);
                    Float f = Float.valueOf(totalSize > 0 ? (float) bytesWritten * 1.0f / (float) totalSize * 100.0f : -1.0f);
                    mArcProgress.setProgress(f.intValue());
                }

                @Override
                public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                    super.onFailure(code, headers, arg2, e);
                    mArcProgress.setVisibility(View.INVISIBLE);
                    mUploadFail.setVisibility(View.VISIBLE);
                    mLoadingText.setTextColor(getResources().getColor(R.color.c_white_ffffff));
                    mLoadingText.setText("上传失败，请重新上传...");
                    mLoadingDialog.setCanceledOnTouchOutside(true);
                }
            });
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if(null != intent){
            //新执业资格证页面返回
            if("NEW".equals(intent.getAction())){
                isNewVocationalQC = true;
                String filePath = intent.getStringExtra("filePath");
                doctorPracticeCertificateString = intent.getStringExtra("doctorPracticeCertificateString");
                File file = new File(filePath);
                if(file == null || !file.isFile()){
                    return;
                }
                mVocationalQC = file;
                vocatecerUrl = mVocationalQC.getAbsolutePath();
                checkFile();
                sx_id_vocational_qualification_certificate_waitting_submit.setVisibility(View.VISIBLE);
            //旧执业资格证页面返回
            }else if("OLD".equals(intent.getAction())){
                isNewVocationalQC = false;
                String filePath = intent.getStringExtra("filePath");
                doctorPracticeCertificateString = intent.getStringExtra("doctorPracticeCertificateString");
                if(filePath.contains(",")){
                    String filePaths[] = filePath.split(",");
                    File picFile = new File(filePaths[0]);
                    if(picFile == null || !picFile.isFile()){
                        return;
                    }
                    mVocationalQC = picFile;
                    File infoFile = new File(filePaths[1]);
                    if(infoFile == null || !infoFile.isFile()){
                        return;
                    }
                    mOldVocationalQC = infoFile;
                }


                vocatecerUrl = filePath;
                checkFile();
                sx_id_vocational_qualification_certificate_waitting_submit.setVisibility(View.VISIBLE);
            }
        }

    }


    // add by xjs on 20151214 start
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if(1000 == requestCode) {
                if(1 == resultCode) {
                    // 获取裁剪的结果图片
                    File file = new File(UtilFiles.createDirInAndroid(XCConfig.CHAT_PHOTO_DIR, SX_IdentityAuthenticationActivityV2.this),JS_ClipImageActivity.CLIPHEAD_NAME);
                    if(file == null || !file.isFile()){
                        return;
                    }
                    // 显示图片到页面上
                    mPersonalPhotosImgFile = file;
                    sx_id_delete_personal_picture.setVisibility(View.VISIBLE);
                    sx_id_upload_personal_photos_show.setVisibility(View.VISIBLE);
                    Bitmap bm = BitmapFactory.decodeFile(file.getAbsolutePath());
                    sx_id_upload_personal_photos_show.setImageBitmap(bm);
                    sx_id_upload_personal_photos_rl.setBackgroundColor(0);
                    checkFile();
                }
            }
            //工作证选择返回
            else if(2000 == requestCode) {
                if (null != data) {
                    String filePath = data.getStringExtra("filePath");
                    File file = new File(filePath);
                    if (file == null || !file.isFile()) {
                        return;
                    }
                    emcardUrl = filePath;
                    mEmpCard = file;
                    checkFile();
                    sx_id_emp_card_waitting_submit.setVisibility(View.VISIBLE);
                }
            }else if(YY_SelectImgsActivity.REQUEST_IMAGE == requestCode){//相册选完返回 add by xd // 2017/11/27
                if (resultCode == Activity.RESULT_OK) {
                    if (data !=null && data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT) != null) {
                        File file = (File) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
                        if (file != null) {
                            File toUploadFile = UtilFile.ChangeImgsToUploadFile(file);//压缩图片
                            switch(mMarkOnclickEvent){
                                case 1:{
                                    // add by xjs on 20151214 start
                                    // 添加进行图片裁剪的处理
                                    Intent intent = new Intent(SX_IdentityAuthenticationActivityV2.this, JS_ClipImageActivity.class);
                                    intent.putExtra("file", toUploadFile);
                                    startActivityForResult(intent, 1000);
                                    // add by xjs on 20151214 end
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        } catch(OutOfMemoryError e) {
            e.printStackTrace();
        }

    }

    /**
     *  add by 马杨茗 on 20160513
     *  重写该方法解决部分三星手机拍照时屏幕旋转导致activity重新绘制引起无法获取拍照后的数据
     *  AndroidManifest.xml中对此类有相应改变
      * @param newConfig
     */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
    /**
     * add by 马杨茗 on 20160513
     * 关闭dialog
     * 防止页面关闭后再次进行关闭
     */
    public void dismiss() {
        try {
            if (mLoadingDialog != null && mLoadingDialog.isShowing()) {
                mLoadingDialog.dismiss();
            }
        } catch (Exception e) {
        }
    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mLoadingDialog,mUploadDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }
}
