package com.qlk.ymz.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.util.bi.BiUtil;

/**
 * SX_SampleActivity
 * 样例activity
 * @author songxin on 2016/1/9.
 * @version 2.0
 */
public class SX_SampleActivity extends Activity {
    /** 关闭窗口按钮*/
    private ImageView sx_id_close_sample;
    /** 关闭窗口按钮 */
    private TextView tv_closed_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sx_l_activity_sample);
        findViews();
        initData();
        setListener();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_SampleActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    private void findViews(){
        sx_id_close_sample = (ImageView)findViewById(R.id.sx_id_close_sample);
        tv_closed_btn = (TextView) findViewById(R.id.tv_closed_btn);
    }
    private void initData(){

    }
    private void setListener(){
        sx_id_close_sample.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        tv_closed_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    public void finish() {
        super.finish();

        overridePendingTransition(R.anim.pop_up, R.anim.pop_down);//不加的话默认页面从左向右划出
    }
}
