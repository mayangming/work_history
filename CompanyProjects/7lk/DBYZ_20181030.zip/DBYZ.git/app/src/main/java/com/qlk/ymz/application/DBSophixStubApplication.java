package com.qlk.ymz.application;

import android.content.Context;
import android.support.annotation.Keep;
import android.support.multidex.MultiDex;
import android.util.Log;

import com.qlk.ymz.BuildConfig;
import com.taobao.sophix.SophixApplication;
import com.taobao.sophix.SophixEntry;
import com.taobao.sophix.SophixManager;
import com.taobao.sophix.listener.PatchLoadStatusListener;

/**
 * Sophix入口类，专门用于初始化Sophix，不应包含任何业务逻辑。
 * 此类必须继承自SophixApplication，onCreate方法不需要实现。
 * 此类不应与项目中的其他类有任何互相调用的逻辑，必须完全做到隔离。
 * AndroidManifest中设置application为此类，而SophixEntry中设为原先Application类。
 * 注意原先Application里不需要再重复初始化Sophix，并且需要避免混淆原先Application类。
 * 如有其它自定义改造，请咨询官方后妥善处理。
 *
 * @author zhangpengfei.
 * @version 1.0
 */
public class DBSophixStubApplication extends SophixApplication {
    private final String TAG = "DBSophixStubApplication";
    private final String RSA = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC7npwI1h6iHcGFWne1zTzWl3XG4GLsJrqwYaVvgYnIJ0BWijNXeQV+LNWhHaRF18TrphuFvoCkwgKZYF/8sn2Eegx6eyGWcYk/B4WhqeeZOuBaPaVH26MHbGj9B5IVJxfNHND3kcsR1LcsDM4LGJcV4C3vXlhl1G2vYeZZJO76EhOiP7/GtxsnrLjm53nWIsj3Bfn0lcthiXn+/hSDSaE4TGjL92OPEKFu88Ihj+pPaRcuQqKwyiTekTNMX4LLFknkPx95mp4oRxM1fuLL9BmGmk9y1WPSyrr+kLZKwUT3Emzcjt9mO7k/cjAU4NEnD28/6PgbZJexLqRatY+jgzf/AgMBAAECggEATAHniJTl+BtB6PpLgPVSbkURy63fpXfTLd2BHflGjjWIlQaL4iX/GaykJw9RG5JcDnNOtxIEH7sRPn2SpVbSDrc7EuuLId2BEm3Dr0ibsLHvbd+Hc+MA2uMKbWeBwNwDgm7oIUOJFwIr6saNOmWN36jgMxbvjOFQRjrNDNQvlFLIumDPCSy0Rp4mRSqtWJmKEIY3DBbY4NxMY2At9Hur5KsL+7xDdnDCxmh2aVitNKjJCwRr/2aKqO76CkJvkEptrV3vQOsy5COw0+Cp32T8cAc1levGSYW+VPvOz8wjc0hrhQF9Tw3JvVF1x7DUv2bZWDb05Nff3RxAJGVC06/+0QKBgQDjoo+RXgkzd433xItuIqNa7DiiG10CGLxtiat+JcTjyC5pbSSk9vwnTQ2IpXIhq1Tux0mp00Fi+iATjCts0Gq0/cOpm2h9+NHiOJZHaxYzqvHQYz6UGRQkJ0iDZ97H+QWhXFtCGN1mcfUIparP72DRG2zNX7elE4MgKcIXaQNZOwKBgQDS/5O0NDp0boyW8lUUQEjPY5qcMHwPYsjyxk+9Xwa7d7m2aPvT9FCh8YC+BzQ5tirln1OeP/TYf6pP5FZ4ujjSF3LzNUeXT7IVAq33MNI2kpfWns0ObPr+BkvEsv4SeJp4LbZvxD76i/fjcifTlqRou91KppIxiAM1qLZ2HgwQDQKBgAQUywwpKnMQxqvVi0ZrOpCLwawuX2mFNgOkvz1gwfnvgd2EBm8qunSd7gswJC60Wq55RjnUPszefSq8jZ7C0dby4cotrh7sEh9DMnaPVfORMgqxbNLM7E6FocgxWY4uScqN1FkIBxgqHOGNztUxjoPRQQ8hkzJTejteZEt1J4k3AoGBAM5vr5uH3gk8f+DPh94gZxxBX2uhJEAJboHY9PtalcOlB9YoMPrW9mz7U/KYKcitKpsunykdefi4L3Gq/c9wo1cqChVZ84lfN+TGkl5fLcym8FfTVtzeU1Nl5Yu1dE+uH7OlRfFkGBoaB5ZIgh7KLGEsLP50qmQ7pqhBQQOfsj2hAoGAeRqP3IJA7LAMc5YO8Zk3gtV4SynCOWnCJzmyv8wz95zS1U4dsPXtHmeRjeeRkMcZw23bi7tEsjzxarxYGJ+xBpRhX2ENklL+n31QQqbOKcmqPXyqyec+5H8VwgU19htdjpA5TBAjpE6kAN4y4Sp37VF/LgegQhubqcrdJFWow6E=";
    // 此处SophixEntry应指定真正的Application，并且保证RealApplicationStub类名不被混淆。
    @Keep
    @SophixEntry(DBApplication.class)
    static class RealApplicationStub {
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
//         如果需要使用MultiDex，需要在此处调用。
        MultiDex.install(this);
        initSophix();
    }

    private void initSophix() {
        String appVersion = "0.0.0";
        try {
            appVersion = this.getPackageManager()
                    .getPackageInfo(this.getPackageName(), 0)
                    .versionName;
        } catch (Exception e) {
        }
        final SophixManager instance = SophixManager.getInstance();
        instance.setContext(this)
                .setAppVersion(appVersion)
                .setSecretMetaData(BuildConfig.appKey, BuildConfig.AppSecret, RSA)
                .setEnableDebug(false)
                .setEnableFullLog()
                .setPatchLoadStatusStub(new PatchLoadStatusListener() {
                    @Override
                    public void onLoad(final int mode, final int code, final String info, final int handlePatchVersion) {
                        //回调
                        logI("code: " + code + "; info: " + info);
                    }
                }).initialize();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (BuildConfig.releaseTag){
            SophixManager.getInstance().queryAndLoadNewPatch();
        }
    }

    private void logI(String msg){
        if (BuildConfig.releaseTag){
            Log.i(TAG, "" + msg);
        }
    }
}
