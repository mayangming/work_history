package com.qlk.ymz.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.JS_WebViewActivity;
import com.qlk.ymz.activity.SX_MassHistoryActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.MassHistoryBean;
import com.qlk.ymz.model.PatientGroupBean;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.AutoShowTextView;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.ArrayList;
import java.util.List;

/**
 * SX_ChatRecordAdapter
 * 聊天会话adapter
 * @author songxin on 2017/2/22.
 * @version 2.7
 */
public class SX_MassHistoryAdapter extends BaseAdapter {
    /** 上下文*/
    private Context mContext;
    /** 会话记录数据*/
    private List<MassHistoryBean> mMassHistoryBean;
    /** LayoutInflater*/
    private LayoutInflater mLayoutInflater;


    public SX_MassHistoryAdapter(Context context, List<MassHistoryBean> sx_chatRecordInfos){
        this.mContext = context;
        this.mMassHistoryBean = sx_chatRecordInfos;
        this.mLayoutInflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return mMassHistoryBean.size();
    }

    @Override
    public Object getItem(int position) {
        return mMassHistoryBean.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(null == convertView){
            viewHolder = new ViewHolder();
            convertView = mLayoutInflater.inflate(R.layout.sx_l_mass_history_item,null);
//            viewHolder.ll_addressee = (LinearLayout) convertView.findViewById(R.id.ll_addressee);
            viewHolder.tv_addressee = (TextView)convertView.findViewById(R.id.tv_addressee);
            viewHolder.sx_addressee_show_text = (AutoShowTextView)convertView.findViewById(R.id.sx_addressee_show_list);
            viewHolder.sx_id_message_time = (TextView)convertView.findViewById(R.id.sx_id_message_time);
            viewHolder.sx_id_message_content = (TextView)convertView.findViewById(R.id.sx_id_message_content);
            viewHolder.sx_id_send_again = (ImageView) convertView.findViewById(R.id.sx_id_send_again);
            viewHolder.sx_id_doctor_info = (TextView)convertView.findViewById(R.id.sx_id_doctor_info);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)convertView.getTag();
        }

        //type等于1全部患者
        if("1".equals(mMassHistoryBean.get(position).getReceiveType())){
            viewHolder.tv_addressee.setVisibility(View.GONE);
            String[] strings = new String[]{"所有患者"};
            viewHolder.sx_addressee_show_text.setNames(strings,UtilScreen.sp2px(mContext,14),10f,13f,false,R.color.c_7b7b7b);
            //type等于2 能收到分组
        }else if("2".equals(mMassHistoryBean.get(position).getReceiveType())){
            viewHolder.tv_addressee.setVisibility(View.GONE);
//            viewHolder.tv_addressee.setBackgroundColor(mContext.getResources().getColor(R.color.c_trans));
            //组合数据
            List<PatientGroupBean> patientGroupBeenList = new ArrayList<>();
            String[] groupNames = mMassHistoryBean.get(position).getRecipients().split(",");
            String[] groupId = mMassHistoryBean.get(position).getGroupIds().split(",");
            for(int i = 0; i < groupNames.length; i++){
                PatientGroupBean patientGroupBean = new PatientGroupBean();
                patientGroupBean.setChoose(true);
                patientGroupBean.setGroupName(groupNames[i]);
                patientGroupBeenList.add(patientGroupBean);
            }
            if(groupNames.length - groupId.length < 0){
                for(int i = 0; i < groupNames.length; i++){
                    patientGroupBeenList.get(i).setId(groupId[i]);
                }
            }else{
                for(int i = 0; i < groupId.length; i++){
                    patientGroupBeenList.get(i).setId(groupId[i]);
                }
            }
            //把数据放到bean中
            mMassHistoryBean.get(position).setPatientGroupBeanList(patientGroupBeenList);
            Log.e("http","groupNames---->"+groupNames.length);
            viewHolder.sx_addressee_show_text.setNames(groupNames,UtilScreen.sp2px(mContext,14),10f,13f,false,R.color.c_7b7b7b);
        }else if("3".equals(mMassHistoryBean.get(position).getReceiveType())){
            //组合数据
            List<PatientGroupBean> patientGroupBeenList = new ArrayList<>();
            String[] groupNames = mMassHistoryBean.get(position).getRecipients().split(",");
            String[] groupId = mMassHistoryBean.get(position).getGroupIds().split(",");
            for(int i = 0; i < groupNames.length; i++){
                PatientGroupBean patientGroupBean = new PatientGroupBean();
                patientGroupBean.setChoose(true);
                patientGroupBean.setGroupName(groupNames[i]);
                patientGroupBeenList.add(patientGroupBean);
            }
            if(groupNames.length - groupId.length < 0){
                for(int i = 0; i < groupNames.length; i++){
                    patientGroupBeenList.get(i).setId(groupId[i]);
                }
            }else{
                for(int i = 0; i < groupId.length; i++){
                    patientGroupBeenList.get(i).setId(groupId[i]);
                }
            }
            //把数据放到bean中
            mMassHistoryBean.get(position).setPatientGroupBeanList(patientGroupBeenList);
//            viewHolder.tv_addressee.setBackgroundColor(mContext.getResources().getColor(R.color.c_trans));
            viewHolder.tv_addressee.setVisibility(View.VISIBLE);
            viewHolder.tv_addressee.setText("除去");
            viewHolder.sx_addressee_show_text.setNames(groupNames,UtilScreen.sp2px(mContext,14),10f,13f,false,R.color.c_7b7b7b);
            //type等于4 自定义患者
        }else if("4".equals(mMassHistoryBean.get(position).getReceiveType())){
//            viewHolder.tv_addressee.setBackgroundColor(mContext.getResources().getColor(R.color.c_trans));
            viewHolder.tv_addressee.setVisibility(View.VISIBLE);
            viewHolder.tv_addressee.setText("指定");
            List<XC_ChatModel> choosePatientBeanList = new ArrayList<>();
            String[] patientNames = mMassHistoryBean.get(position).getRecipients().split(",");
            String[] patientId = mMassHistoryBean.get(position).getPatientIds().split(",");
            for(int i = 0; i < patientNames.length; i++){
                XC_ChatModel xc_chatModel = new XC_ChatModel();
                xc_chatModel.getUserPatient().setChoose(true);
                xc_chatModel.getUserPatient().setPatientName(patientNames[i]);
                choosePatientBeanList.add(xc_chatModel);
            }
            if(patientNames.length - patientId.length < 0){
                for(int i = 0; i < patientNames.length; i++){
                    choosePatientBeanList.get(i).getUserPatient().setPatientId(patientId[i]);
                }
            }else{
                for(int i = 0; i < patientId.length; i++){
                    choosePatientBeanList.get(i).getUserPatient().setPatientId(patientId[i]);
                }
            }
            //把数据放到bean中
            mMassHistoryBean.get(position).setChoosePatientBeanList(choosePatientBeanList);
            viewHolder.sx_addressee_show_text.setNames(patientNames, UtilScreen.sp2px(mContext,14),10f,13f,false,R.color.c_7b7b7b);
        }

        //消息时间
        viewHolder.sx_id_message_time.setText(mMassHistoryBean.get(position).getMsgTime());
        //医生信息
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("医生："+ mMassHistoryBean.get(position).getName());
        if(!UtilString.isBlank(mMassHistoryBean.get(position).getTitle())){
            stringBuffer.append("-"+mMassHistoryBean.get(position).getTitle());
        }
        if(!UtilString.isBlank(mMassHistoryBean.get(position).getHospital())){
            stringBuffer.append("-"+mMassHistoryBean.get(position).getHospital());
        }
        if(!UtilString.isBlank(mMassHistoryBean.get(position).getDepartment())){
            stringBuffer.append("-"+mMassHistoryBean.get(position).getDepartment());
        }
        viewHolder.sx_id_doctor_info.setText(stringBuffer.toString().trim());

        //消息内容
        setExplain(viewHolder.sx_id_message_content,mMassHistoryBean.get(position).getMsgContent().trim(),mMassHistoryBean.get(position).getEduTitle().trim(),mMassHistoryBean.get(position).getEduUrl());
        //再次发送按钮
        viewHolder.sx_id_send_again.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(SX_MassHistoryActivity.class, "2", "128", "sx_id_send_again","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end
                Intent intent = new Intent();
                intent.putExtra("MassHistoryBean",mMassHistoryBean.get(position));
                if(mContext instanceof SX_MassHistoryActivity){
                    ((SX_MassHistoryActivity) mContext).setResult(2,intent);
                    ((SX_MassHistoryActivity) mContext).finish();
                }
            }
        });
        return convertView;
    }

    static class ViewHolder{
        /** 消息时间*/
        TextView sx_id_message_time;
        /** 消息内容*/
        TextView sx_id_message_content;
        /** 再次发送按钮*/
        ImageView sx_id_send_again;
        /** 医生信息显示*/
        TextView sx_id_doctor_info;
        /** 收件人显示*/
        AutoShowTextView sx_addressee_show_text;
        //        /** 点*/
        TextView tv_addressee;

    }


    private void setExplain(TextView textView,String msgContent,String eduText,final String url) {
        SpannableString msp = null;
        int currentSize = 0;
        if(!UtilString.isBlank(eduText)){
            if(!UtilString.isBlank(msgContent)){
                msp = new SpannableString("医嘱内容："+ msgContent + "-" + eduText);
                currentSize = 6;
            }else {
                msp = new SpannableString("医嘱内容："+ msgContent + eduText);
                currentSize = 5;
            }
            msp.setSpan(new ClickableSpan() {
                @Override
                public void onClick(View widget) {
                    mContext.startActivity(JS_WebViewActivity.newIntent(mContext, new WebviewBean(url)));
                }

                @Override
                public void updateDrawState(TextPaint ds) {
                    //去掉链接的下划线
                    ds.setUnderlineText(false);
                    //设置链接的颜色
                    ds.setColor(mContext.getResources().getColor(R.color.c_e2231a));
                }
            }, msgContent.length()+currentSize, msgContent.length()+currentSize+eduText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            textView.setText(msp);
            textView.setMovementMethod(LinkMovementMethod.getInstance());
        }else {
            textView.setText("医嘱内容："+ msgContent);
        }

    }
}
