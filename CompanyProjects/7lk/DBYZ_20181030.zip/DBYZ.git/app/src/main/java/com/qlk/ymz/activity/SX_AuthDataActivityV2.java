package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.AuthDataInfo;
import com.qlk.ymz.parse.Parse2AuthData;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.CircleImageView;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * SX_AuthDataActivityV2
 * 我的身份认证页面2.0
 * @author songxin on 2016/1/9.
 * @version 2.0
 */
public class SX_AuthDataActivityV2 extends DBActivity implements View.OnClickListener{
    /** 通用标题 */
    XCTitleCommonLayout titlebar;
    /** 认证状态显示*/
    private TextView sx_id_certification_status_show;
    /** 个人头像显示*/
    private CircleImageView sx_id_upload_personal_photos_show;
    /** 医生姓名*/
    private TextView sx_id_name_show;
    /** 医生科室*/
    private TextView sx_id_department_show;
    /** 医生职称*/
    private TextView sx_id_title_show;
    /** 医生工作证*/
    private RelativeLayout sx_id_see_pic_for_my_work_permite_rl;
    /** 医生执业资格证*/
    private RelativeLayout sx_id_see_pic_for_vocational_rl;
    /** 医生信息model*/
    private AuthDataInfo mAuthDataInfo;
    /**Intent*/
    private Intent mIntent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// 设置布局
		setContentView(R.layout.sx_l_activity_auth_my_data_v2);
		super.onCreate(savedInstanceState);
        mIntent = new Intent();
        mAuthDataInfo = new AuthDataInfo();
        getAuthData();

	}

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_AuthDataActivityV2.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

	// 无网络时,点击屏幕后回调的方法
	@Override
	public void onNetRefresh() {
	}

	// 初始化控件
	@Override
	public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleCenter(true, "医生资质");

        sx_id_certification_status_show = getViewById(R.id.sx_id_certification_status_show);
        sx_id_upload_personal_photos_show = getViewById(R.id.sx_id_upload_personal_photos_show);
        sx_id_name_show = getViewById(R.id.sx_id_name_show);
        sx_id_department_show = getViewById(R.id.sx_id_department_show);
        sx_id_title_show = getViewById(R.id.sx_id_title_show);
        sx_id_see_pic_for_my_work_permite_rl = getViewById(R.id.sx_id_see_pic_for_my_work_permite_rl);
        sx_id_see_pic_for_vocational_rl = getViewById(R.id.sx_id_see_pic_for_vocational_rl);
	}

	// 设置监听
	@Override
	public void listeners() {
        sx_id_upload_personal_photos_show.setOnClickListener(this);
        sx_id_see_pic_for_vocational_rl.setOnClickListener(this);
        sx_id_see_pic_for_my_work_permite_rl.setOnClickListener(this);

	}

    @Override
    public void onClick(View v) {
        ArrayList<String> images = new ArrayList<>();
        switch (v.getId()){
            //个人头像显示
            case R.id.sx_id_upload_personal_photos_show:{
                images.clear();
                images.add(mAuthDataInfo.getAvatar());
                ToJumpHelp.toJumpChatImageShowActivity(this,images,0,"个人头像");
                break;
            }
            //工作证显示
            case R.id.sx_id_see_pic_for_my_work_permite_rl:{
                images.clear();
                images.add(mAuthDataInfo.getEmcard());
                ToJumpHelp.toJumpChatImageShowActivity(this,images,0,"工作证");
                break;
            }
            //执业资格证显示
            case R.id.sx_id_see_pic_for_vocational_rl:{
                images.clear();
                images.addAll(mAuthDataInfo.getMedicalLicense().getUrls());
                ToJumpHelp.toJumpChatImageShowActivity(this,images,0,"执业资格证");
                break;
            }
            default:{
                break;
            }
        }
    }

    /**
     * 获取个人状态
     */
    private void getAuthData(){
        XCHttpAsyn.postAsyn(SX_AuthDataActivityV2.this, AppConfig.getHostUrl(AppConfig.user_authData), new RequestParams(), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    Parse2AuthData parse2AuthData = new Parse2AuthData(mAuthDataInfo);
                    parse2AuthData.parseJson(result_bean);
                    initDataFromAuthDataInfo();
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_AuthDataActivityV2.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 数据初始化
     */
    private void initDataFromAuthDataInfo(){
        if(!UtilString.isBlank(mAuthDataInfo.getAvatar())){
            XCApplication.displayImage(mAuthDataInfo.getAvatar(), sx_id_upload_personal_photos_show, XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.sx_d_identity_personal_head_icon_v2));
        }

        if(!UtilString.isBlank(mAuthDataInfo.getStatus())){
            //审核中
            if("0".equals(mAuthDataInfo.getStatus())){
                sx_id_certification_status_show.setText("认证中");
                //已认证
            }else if("1".equals(mAuthDataInfo.getStatus())){
                sx_id_certification_status_show.setText("已认证");
            }
        }
        initData(UtilSP.getUserId());
    }

    /**
     * 获取初始化数据
     * @param doctorId
     */
    private void initData(String doctorId){
        RequestParams params = new RequestParams();
        params.put("id", doctorId);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.user_detail), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                        sx_id_name_show.setText(jsonBeans.get(0).getString("name"));
                        sx_id_department_show.setText(jsonBeans.get(0).getString("department"));
                        sx_id_title_show.setText(jsonBeans.get(0).getString("title"));
                    }
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_AuthDataActivityV2.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

}
