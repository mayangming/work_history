package com.qlk.ymz.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.LT_PubTabGridAdapter;
import com.qlk.ymz.adapter.LT_PublicityAdpter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.db.publicity.LT_PublicityTabModeDb;
import com.qlk.ymz.parse.Parse2PublicityBean;
import com.qlk.ymz.parse.Parse2PublictyTabBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.LT_NavitaitionTitleView;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 李涛
 * @description   我的宣教列表页面
 * @Date 2017/3/28.
 */
public class LT_PublicityActivity extends DBActivity implements View.OnClickListener {
    /**内容list view*/
    private PullToRefreshListView lvContent;
    private ListView mListview;
    private LT_PublicityAdpter publicityAdpter;
    private  ArrayList<Parse2PublicityBean> dataList = new ArrayList();//内容数据
    /**无网络背景布局*/
    private RelativeLayout noNetView;
    private Button xc_id_no_net_button;//重新加载的按钮
    /**无数据页面*/
    View include_data_zero_view;
    /**内容数据 字段*/
    private String  pageNo ="1";  //页数
    private String  nextPage ="1";  //下一页页数
    private String  pageSize = "10"; //页面的条目数
    private String  hasNex; //是否有下一页
    private  String offset= "0";
    /**发送按钮dialog窗口控件*/
    private Dialog sendDialog;
    private TextView sendName;
    private XCRoundedImageView sendHeader;
    private TextView sendUrl;
    private Button sendCancle;
    private Button sendOk;
    /**判断入口*/
    private Intent comeSourec;
    public static final String PUBLICITY_EDUCATION_INTENTCODE = "PublicityEducationIntentCode";
    public static final int  PUBLICITY_INTENT_CHART_CODE=1;//搜索的详情页面返回直接跳转聊天页面 返回的Code
    public static final int  PUBLICITY_SEARCH_INTENT_CODE=2;//搜弹窗返回直接跳转聊天页面
    public static final int  PUBLICITY_SEARCH_INTENT_ISREFRESH=3;//搜索宣教页面删除返回刷新
    public static final String  PUBLIVITY_ISJUDGE_REFRESH="isjudgeRefresh";//搜索宣教页面删除返回刷新
    public static final  String PUBLICITY_DETAIL_BACK = "publicty_detail_back";//详情页面返回数据然后直接携带数据返回聊天页面
    private  int intentCode = 0;//     0首页 1聊天列表
    public static String PATIENT_INFO = "patient_info";//接收其它页面传过来的患者信息
    /**页面缓存列表点击的数据*/
    Parse2PublicityBean  LocaData;
    private XC_ChatModel userData;
    private XCTitleCommonLayout xcTitleCommonLayout;
    private Handler  delayHandler = new Handler(Looper.getMainLooper());
    /**搜索框*/
    private RelativeLayout lt_pub_searchview;
    /**常用*/
    private TextView lt_pub_constantuser;
    /**最新*/
    private TextView lt_pub_newest;
    private LT_NavitaitionTitleView lt_pub_navitation;
    private ImageView lt_pub_list;
    private int defaultlTextColor = Color.parseColor("#999999");
    private int selectTextColor =  Color.parseColor("#F84B62");
    /**防止tab多出点击  1常用 2最新 3标签点击*/
    private int selectFlag =  0;
    /**返回该页面 时刷新数据   1常用 2最新  3 tab标签点击*/
    private int againDataFlag = 1;
    private LinearLayout lt_pub_navitation_view;
    private PopupWindow popupWindow;
    /**是否有最新的宣教红点*/
    private TextView lt_pub_newest_dot;
    /**宣教数据库*/
    private LT_PublicityTabModeDb db;
    private ArrayList<Parse2PublictyTabBean> tabbeanList = new ArrayList<>();
    private String typeID = "2";// 	 搜索类型1关键字搜索2最常使用3最近更新    不能更改 后端用来判断排序
    private String selectLabelID = "";  //选中的搜索标签ID
    /**标签tab数据*/
    private ArrayList<Parse2PublictyTabBean> tabsForSqliteList2 = new ArrayList<>();
    private LT_PubTabGridAdapter gridAdapter;
    /**判断标签是否更新    1更新 0不更新*/
    private String  isExistLabel = "1";
    private String jdugeDot;
    private ArrayList<Parse2PublictyTabBean> tabbeanList2;
    private Parse2PublictyTabBean firstBean;
    private View left_view;
    private View right_view;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setContentView(R.layout.lt_activity_publicity);
        //判断入口 0首页入口 1聊天页
        comeSourec = getIntent();
        intentCode = comeSourec.getIntExtra(PUBLICITY_EDUCATION_INTENTCODE,0);
        userData = (XC_ChatModel) comeSourec.getSerializableExtra(PATIENT_INFO);
        jdugeDot = GlobalConfigSP.getHomePublictyDot();

        //初始化宣教数据库
         db =  new   LT_PublicityTabModeDb(this,LT_PublicityTabModeDb.SQLITE_NAME+"_"+ UtilSP.getUserId(),null,LT_PublicityTabModeDb.SQLITE_TABLE_NAME);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2017-4-10,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(LT_PublicityActivity.class);
    }

    /** created by songxin,date：2016-4-10,about：bi,end */



    @Override
    public void initWidgets() {
        //标题部分
        xcTitleCommonLayout = (XCTitleCommonLayout) findViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonLayout.setTitleLeft( true, "");
        xcTitleCommonLayout.setTitleCenter(true, "我的宣教");
        xcTitleCommonLayout.setTitleRight2(true,0,"新建");
        //搜索和滑动标题部分
        lt_pub_navitation = (LT_NavitaitionTitleView) findViewById(R.id.lt_pub_navitation);
        left_view = findViewById(R.id.lt_view_left);
        right_view = findViewById(R.id.lt_view_right);
        lt_pub_searchview = (RelativeLayout) findViewById(R.id.lt_pub_searchview);
        lt_pub_constantuser = (TextView) findViewById(R.id.lt_pub_constantuser);
        lt_pub_newest = (TextView) findViewById(R.id.lt_pub_newest);
        lt_pub_list = (ImageView) findViewById(R.id.lt_pub_list);
        lt_pub_navitation_view = (LinearLayout) findViewById(R.id.lt_pub_navitation_view);
        lt_pub_newest_dot = (TextView) findViewById(R.id.lt_pub_newest_dot);
        //无网络背景
        noNetView = (RelativeLayout) findViewById(R.id.lt_put_nonetview);
        xc_id_no_net_button = (Button) findViewById(R.id.xc_id_no_net_button);
        //无数据页面
        include_data_zero_view = findViewById(R.id.include_data_zero_view);
        ImageView  xc_id_data_zero_imageview = (ImageView) findViewById(R.id.xc_id_data_zero_imageview);
        xc_id_data_zero_imageview.setImageResource(R.mipmap.js_d_icon_no_data);
        TextView  xc_id_data_zero_hint_textview = (TextView) findViewById(R.id.xc_id_data_zero_hint_textview);
        xc_id_data_zero_hint_textview.setText("没有宣教了,点击右上角新建");
        include_data_zero_view.setVisibility(View.GONE);
        //内容listview
        lvContent = (PullToRefreshListView) findViewById(R.id.lv_pub_content);
        lvContent.setMode(PullToRefreshBase.Mode.PULL_FROM_END);//设置了只有上拉加载
        mListview =  lvContent.getRefreshableView();
        publicityAdpter = new LT_PublicityAdpter(LT_PublicityActivity.this, R.layout.lt_item_publicity,R.layout.js_item_action_chat_list,dataList);
        lvContent.setAdapter(publicityAdpter);

        if(0==intentCode){
            typeID = "3";
            againDataFlag = 2;
        }else if(1==intentCode){
            typeID = "2";
            againDataFlag = 1;
            if("0".equals(jdugeDot)){
                lt_pub_newest_dot.setVisibility(View.GONE);
            }else{
                lt_pub_newest_dot.setVisibility(View.VISIBLE);
            }
        }
        //初始化网络数据
        initData(pageNo,pageSize,offset,true,"",typeID);
        //接口处理标签的数据
        initTabData();
    }



    @Override
    public void listeners() {

        lt_pub_list.setOnClickListener(this);
        lt_pub_constantuser.setOnClickListener(this);
        lt_pub_newest.setOnClickListener(this);
        lt_pub_searchview.setOnClickListener(this);


        //listview内容布局的监听
        publicityAdpter.setOnViewClick(new LT_PublicityAdpter.ContentViewClick() {
            @Override
            public void onclick(Parse2PublicityBean  contendData) {
                LocaData = contendData;
                //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
                Map<String,String> track = new HashMap<>();
                track.put("contentTitle", contendData.getEduTitle());
                GrowingIOUtil.track("knowledgePageView", track);
                //add by songxin,date：2018-3-29,about：GrowingIO banner track,end
                ToJumpHelp.toJumpMyMissionaryActivity(LT_PublicityActivity.this,"1",contendData,intentCode,userData);
            }
        });

        //重新加载数据
        xc_id_no_net_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //无网络数据重新加载时，清除原来数据
                if(dataList!=null&&dataList.size()>0){
                    dataList.clear();
                }
                initData("1",pageSize,"0",true,selectLabelID,typeID);
                initTabData();
            }
        });

        //内容刷新
        lvContent.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            }
            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {

                //延迟0.5秒  PullToRefreshListView 的 onRefreshComplete刷新的问题
                delayHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initData(nextPage,pageSize,offset,false,selectLabelID,typeID);
                    }
                },500);
            }
        });

        //发送按钮的监听
        publicityAdpter.setOnViewSend(new LT_PublicityAdpter.onClickSendButton() {
            @Override
            public void judgeIntent(Parse2PublicityBean sendData) {
                if(0 == intentCode){
                    //首页  群发
                    Intent groupSend = new Intent(LT_PublicityActivity.this,XD_NewGroupSendActivity.class);
                    groupSend.putExtra(XD_NewGroupSendActivity.PRO_EDU,sendData);
                    myStartActivity(groupSend);
                }else if(1==intentCode){
                    //聊天页 针对某个患者
                    SendDalogMsg(sendData);
                }
            }
        });

        //Adapter侧滑删除数据
        publicityAdpter.deleteContentClick(new LT_PublicityAdpter.deleteContent() {
            @Override
            public void delete(int position) {
                judgeDelete(position);
            }
        });


        //新建页面
        xcTitleCommonLayout.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(LT_PublicityActivity.class, "2", "128", "sx_id_title_right_btn_add_new","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end
                //新建
                UtilNativeHtml5.toJumpNativeH5(LT_PublicityActivity.this, UtilNativeHtml5.PUBLICITY);
            }
        });

        //滑动标题tab监听
        lt_pub_navitation.setTabOnlickListener(new LT_NavitaitionTitleView.Ontabonclick() {
            @Override
            public void tabView(View view, Parse2PublictyTabBean parse2PublictyTabBean,int position) {
                firstBean = parse2PublictyTabBean;
                selectFlag =  3;
                againDataFlag = 3;
                lt_pub_constantuser.setTextColor(defaultlTextColor);
                lt_pub_newest.setTextColor(defaultlTextColor);
                selectLabelID = parse2PublictyTabBean.getId();
                initData("1",pageSize,offset,true,parse2PublictyTabBean.getId(),typeID);
            }
        });

        lt_pub_navitation.setOnHsListener(new LT_NavitaitionTitleView.OnHsLitener() {
            @Override
            public void onClick(boolean flag) {
                if(flag ==true){
                    left_view.setVisibility(View.INVISIBLE);
                    right_view.setVisibility(View.VISIBLE);
                }else if (false==false){
                    left_view.setVisibility(View.VISIBLE);
                    right_view.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void up() {
                left_view.setVisibility(View.INVISIBLE);
                right_view.setVisibility(View.INVISIBLE);
            }
        });
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()){
            //常用
            case R.id.lt_pub_constantuser:
                if(selectFlag != 1){
                    selectFlag = 1;
                    againDataFlag = 1;
                    lt_pub_constantuser.setTextColor(selectTextColor);
                    lt_pub_newest.setTextColor(defaultlTextColor);
                    selectLabelID = "";
                    initData("1",pageSize,offset,true,"","2");
                    setTabView();
                }
                break;
            //最新
            case R.id.lt_pub_newest:
                if(selectFlag != 2){
                    selectFlag = 2;
                    againDataFlag = 2;
                    lt_pub_constantuser.setTextColor(defaultlTextColor);
                    lt_pub_newest.setTextColor(selectTextColor);
                    selectLabelID = "";
                    initData("1",pageSize,offset,true,"","3");
                    setTabView();
                    if("1".equals(jdugeDot)){
                        GlobalConfigSP.setHomePublictyDot("0");
                        lt_pub_newest_dot.setVisibility(View.GONE);
                    }
                }
                break;
            //搜索框
            case R.id.lt_pub_searchview:
                Intent intent = new Intent(LT_PublicityActivity.this,LT_PublictySearchActivity.class);
                intent.putExtra(PUBLICITY_EDUCATION_INTENTCODE,intentCode);
                if(1 == intentCode && userData !=null){
                    intent.putExtra(PATIENT_INFO,userData);
                }
                startActivityForResult(intent,0);
                break;
            //标题框选项（弹框）
            case R.id.lt_pub_list:
                initPopup();
                break;
        }
    }


    /***
     * 返回时判断搜索时是否删除该宣教
     */
    private void againJudgeData(){

      if(1 == againDataFlag){
          initData("1",pageSize,offset,true,"","2");
      }else if(2 == againDataFlag){
          initData("1",pageSize,offset,true,"","3");
      }else if(3 == againDataFlag){
          initData("1",pageSize,offset,true,selectLabelID,typeID);
      }

    }


    /**
     * 初始化标签
     */
    private void setTabView(){
        //首页进入直接获取的是本地保存的 或者是网络请求回来的数据
        if(0 == (intentCode)||"1".equals(isExistLabel)){
            lt_pub_navitation.updateTitle(tabbeanList,1);
        }else if(1 == intentCode){
            //聊天业进入考虑医生本地是否本地有关联数据
            if(tabsForSqliteList2!=null&&tabsForSqliteList2.size()>0){
                lt_pub_navitation.updateTitle(tabsForSqliteList2,1);
            }else{
                lt_pub_navitation.updateTitle(tabbeanList,1);
            }
        }
    }


    /***
     * 初始化标签布局
     */
    private void  initTabView(){
        //初始化tab颜色 和tab标签    这里先判断数据库里是否有数据 有 ： 直接适配  无 : 不做处理 等接口
        if(intentCode == 0){
            if(tabbeanList !=null && tabbeanList.size() > 0 && "0".equals(isExistLabel)){
                lt_pub_navitation.setTitleAdapter(LT_PublicityActivity.this, tabbeanList,defaultlTextColor,selectTextColor,-1);
            }
            lt_pub_newest.setTextColor(selectTextColor);
        }else if (intentCode == 1){
            tabsForSqliteList2 = db.queryForPatientID(userData.getUserPatient().getPatientId());
            if(tabsForSqliteList2 != null && tabsForSqliteList2.size() > 0 && "0".equals(isExistLabel)){
                lt_pub_navitation.setTitleAdapter(LT_PublicityActivity.this, tabsForSqliteList2,defaultlTextColor,selectTextColor,-1);
            }else if(tabbeanList !=null && tabbeanList.size() > 0 && "0".equals(isExistLabel)){
                lt_pub_navitation.setTitleAdapter(LT_PublicityActivity.this, tabbeanList,defaultlTextColor,selectTextColor,-1);
            }
            lt_pub_constantuser.setTextColor(selectTextColor);
        }
    }



    /***
     * 初始化数据
     * @param page 当前页面
     * @param num 当前页面数据数量
     * @param offsets
     */
    private void initData(String  page,String num, String offsets,final boolean isShowDialog,String labelIds,String type) {
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("offset", offsets);
        params.put("page",page);
        params.put("type",type);
        if(!TextUtils.isEmpty(labelIds)){
            params.put("labelId",labelIds);
        }
        params.put("num",num);
        XCHttpAsyn.postAsyn(isShowDialog,this, AppConfig.getHostUrl(AppConfig.publicitye_search),params,new XCHttpResponseHandler(){

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);

                if(result_boolean){
                    if(isShowDialog){
                        dataList.clear();
                    }
                    List<XCJsonBean> data =  result_bean.getList("data");
                    if(data!=null){
                        try {
                            noNetView.setVisibility(View.GONE);
                            pageNo = data.get(0).getString("pageNo");
                            pageSize = data.get(0).getString("pageSize");
                            offset = data.get(0).getString("offset");
                            hasNex = data.get(0).getString("hasNext");
                            nextPage = data.get(0).getString("nextPage");
                            List<XCJsonBean>  resultList = data.get(0).getList("result");
                            Parse2PublicityBean.ParseJson(resultList,dataList);
                        }catch (Exception e){
                            e.printStackTrace();
                            Log.e("ParseJsonExcepition","宣教列表数据解析异常");
                        }

                        if(dataList.size()>0){
                            lvContent.setVisibility(View.VISIBLE);
                            include_data_zero_view.setVisibility(View.GONE);
                            publicityAdpter.updateList(dataList);
                            if(isShowDialog){
                                mListview.setSelection(0);
                            }
                            lvContent.onRefreshComplete();
                        }else{
                            lvContent.setVisibility(View.GONE);
                            include_data_zero_view.setVisibility(View.VISIBLE);
                        }
                        //判断是否有下一页数据
                        if("false".equals(hasNex)){
                            lvContent.setMode(PullToRefreshBase.Mode.DISABLED);
                        }else if("true".equals(hasNex)){
                            lvContent.setMode(PullToRefreshBase.Mode.PULL_FROM_END);
                        }
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);

                include_data_zero_view.setVisibility(View.GONE);
                lvContent.setVisibility(View.GONE);
                noNetView.setVisibility(View.VISIBLE);
            }
            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LT_PublicityActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }


    /***
     * 初始化Tab标签
     */
    private  void  initTabData(){
        StringBuilder stringBuilder = new StringBuilder();
        tabbeanList = db.queryForPatientID("1");
        RequestParams params = new RequestParams();
        if(tabbeanList.size() > 0 && tabbeanList != null){
            for ( Parse2PublictyTabBean pubbean : tabbeanList){
                stringBuilder.append(pubbean.getId()+",");
            }
            //这里参数 传入所有的标签ID 后端判断是否有数据的更新
            params.put("labelIds",""+stringBuilder.toString());
        }
        XCHttpAsyn.getAsyn(false,LT_PublicityActivity.this,AppConfig.getHostUrl(AppConfig.publicitye_titlebar),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){
                    List<XCJsonBean> data = result_bean.getList("data");
                    //如果后端数据没有更新 就不会有数据返回
                    if(data!=null&&data.size()>0){
                        //是否有更新
                        isExistLabel  =  data.get(0).getString("isExistLabel");
                        if("1".equals(isExistLabel)){
                            db.deleteTable();
                            tabbeanList.clear();
                            List<XCJsonBean> eduLabelList  = data.get(0).getList("eduLabelList");
                            if(eduLabelList!=null&&eduLabelList.size()>0){
                                try {
                                    for (int i=0;i<eduLabelList.size();i++){
                                        Parse2PublictyTabBean tabBean = new Parse2PublictyTabBean();
                                        tabBean.setLabel(eduLabelList.get(i).getString("label"));
                                        tabBean.setId(eduLabelList.get(i).getString("id"));
                                        tabbeanList.add(tabBean);
                                    }
                                }catch (Exception e){
                                    e.printStackTrace();
                                    Log.e("ParseJsonExcepition","宣教标签数据解析异常");
                                }
                            }
                            //存储到数据库
                            db.insert("0",  tabbeanList);
                            lt_pub_navitation.setTitleAdapter(LT_PublicityActivity.this, tabbeanList,defaultlTextColor,selectTextColor,-1);
                        }
                        initTabView();
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LT_PublicityActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    @Override
    public void onNetRefresh() {}


    /***
     * 初始化 标签弹窗
     */
    public void initPopup(){
        tabbeanList2 = db.queryForPatientID("1");
        View popuView = LayoutInflater.from(LT_PublicityActivity.this).inflate(R.layout.lt_pub_title_dialog,null,false);
        GridView  popuGridView = (GridView) popuView.findViewById(R.id.lt_pub_pupolist);
        if(gridAdapter==null){
            gridAdapter = new LT_PubTabGridAdapter(LT_PublicityActivity.this, tabbeanList2);
        }
        popuGridView.setAdapter(gridAdapter);
        popuGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                firstBean = tabbeanList2.get(position);
                selectLabelID = firstBean.getId();
                selectFlag =  3;
                initData("1",pageSize,offset,true,selectLabelID,typeID);
                if("1".equals(isExistLabel)||0 == intentCode){
                    ArrayList<Parse2PublictyTabBean> tabBeans =    updateTab(firstBean,tabbeanList);
                    lt_pub_navitation.updateTitle(tabBeans,0);
                }else if(1 == intentCode ){
                    if("0".equals(isExistLabel) && tabsForSqliteList2.size()>0){
                        ArrayList<Parse2PublictyTabBean> tabBeans =    updateTab(firstBean,tabsForSqliteList2);
                        lt_pub_navitation.updateTitle(tabBeans,0);
                    }else if(tabbeanList.size()>0){
                        ArrayList<Parse2PublictyTabBean> tabBeans =  updateTab(firstBean,tabbeanList);
                        lt_pub_navitation.updateTitle(tabBeans,0);
                    }
                }
                lt_pub_constantuser.setTextColor(defaultlTextColor);
                lt_pub_newest.setTextColor(defaultlTextColor);
                if(popupWindow.isShowing()){
                    popupWindow.dismiss();
                }
            }
        });

        int srceenW =  this.getWindowManager().getDefaultDisplay().getWidth();
//        int srceenH =  this.getWindowManager().getDefaultDisplay().getHeight();
        //这里控制了下 PopupWindow显示的高度
        int listHeight=   lvContent.getHeight()+20;
        if(popupWindow==null){
            popupWindow = new PopupWindow(popuView,srceenW,listHeight,true);
        }
        popupWindow.setBackgroundDrawable(getResources().getDrawable(R.drawable.default_ptr_rotate2));
        popupWindow.setAnimationStyle(R.style.dialog_from_alpha_up_exit_alpha_in);
        popupWindow.showAsDropDown(lt_pub_navitation_view);
    }

    /***
     * 更新tab标签
     * @param tabBean
     */
    private  ArrayList<Parse2PublictyTabBean> updateTab(Parse2PublictyTabBean tabBean,ArrayList<Parse2PublictyTabBean>  forlist){
        Parse2PublictyTabBean indexBean = null;
        if(forlist!=null){
            for (int i=0;i<forlist.size();i++){
                if (tabBean.toString().equals(forlist.get(i).toString())){
                    indexBean = forlist.get(i);
                }
            }
            if(indexBean!=null){
                forlist.remove(indexBean);
            }
            forlist.add(0,tabBean);
        }
        return forlist;
    }




    /**
     * 删除数据  （Item侧滑）
     * @param position
     */
    private void judgeDelete( final int position){
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("eduId",dataList.get(position).getEduId());
        XCHttpAsyn.postAsyn(LT_PublicityActivity.this, AppConfig.getHostUrl(AppConfig.publicitye_removelist),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);

                if (result_boolean){
                    dataList.remove(position);
                    publicityAdpter.notifyDataSetChanged();
                    //新需求  如果用户删到最后一条的时候会去加载下一页数据
                    if(dataList!=null && dataList.size()==0 && "true".equals(hasNex)){
                        initData(nextPage,pageSize,offset,true,selectLabelID,typeID);
                    }else if(dataList.size()==0&&"false".equals(hasNex)){
                        lvContent.setVisibility(View.GONE);
                        include_data_zero_view.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                include_data_zero_view.setVisibility(View.GONE);
                lvContent.setVisibility(View.GONE);
                noNetView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LT_PublicityActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }



    /***
     * 初始化发送数据的Dialog
     * @param sendData
     */
    public void  SendDalogMsg( final Parse2PublicityBean sendData) {
        if (sendDialog == null) {
            sendDialog = new Dialog(LT_PublicityActivity.this, R.style.xc_s_dialog);
            sendDialog.setCanceledOnTouchOutside(false);
            View dialogView = LayoutInflater.from(LT_PublicityActivity.this).inflate(R.layout.lt_publicity_dialog, null);
            sendName = (TextView) dialogView.findViewById(R.id.tv_pub_name);
            sendHeader = (XCRoundedImageView) dialogView.findViewById(R.id.iv_pub_dialogiv);
            sendUrl = (TextView) dialogView.findViewById(R.id.tv_pub_url);
            sendCancle = (Button) dialogView.findViewById(R.id.bt_pub_cancle);
            sendOk = (Button) dialogView.findViewById(R.id.bt_pub_ok);
            sendDialog.setContentView(dialogView);
            //设置患者姓名头像
            if(userData!=null){
                sendName.setText(userData.getUserPatient().getPatientDisplayName());
                XCApplication.displayImage(userData.getUserPatient().getPatientImgHead(),sendHeader);
            }
        }
        //设置发送内容
        sendUrl.setText("[链接]"+sendData.getEduTitle());
        if(sendDialog!=null&&!sendDialog.isShowing()){
            sendDialog.show();
        }

        //取消
        sendCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDialog.dismiss();
            }
        });
        //确定
        sendOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comeSourec.putExtra(CommonConfig.PUBLICITY_EDUCATION_DATA,sendData);
                setResult(Activity.RESULT_OK,comeSourec);
                sendDialog.dismiss();
                finish();
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //详情页面返回时携带本页面的数据直接返回聊天页面
        if(PUBLICITY_INTENT_CHART_CODE==resultCode){
            Parse2PublicityBean bean  = (Parse2PublicityBean) data.getSerializableExtra(PUBLICITY_DETAIL_BACK);
            if(bean != null){
                comeSourec.putExtra(CommonConfig.PUBLICITY_EDUCATION_DATA,bean);
            }else{
                comeSourec.putExtra(CommonConfig.PUBLICITY_EDUCATION_DATA,LocaData);
            }
            setResult(Activity.RESULT_OK,comeSourec);
            myFinish();
        }else if(PUBLICITY_SEARCH_INTENT_CODE==resultCode){
            Parse2PublicityBean sendData= (Parse2PublicityBean) data.getSerializableExtra(CommonConfig.PUBLICITY_EDUCATION_DATA);
            if(sendData != null){
                comeSourec.putExtra(CommonConfig.PUBLICITY_EDUCATION_DATA,sendData);
                setResult(Activity.RESULT_OK,comeSourec);
            }
            myFinish();
        }else if(PUBLICITY_SEARCH_INTENT_ISREFRESH == resultCode){
           int  isjudgeRefresh = data.getIntExtra(PUBLIVITY_ISJUDGE_REFRESH,0);
           if(isjudgeRefresh == 1){
               againJudgeData();
           }
        }
    }

    /**
     * 只有在聊天页面进入时
     * 退出时保存点击的顺序
     */
    private void saveLabel(){
        if(1 == intentCode){
            if("1".equals(isExistLabel)){
                db.deleteTable();
                db.insert("0",tabbeanList);
            }else {
                if(tabsForSqliteList2.size() > 0 && firstBean!=null){
                    ArrayList<Parse2PublictyTabBean> updateTabs =    updateTab(firstBean,tabsForSqliteList2);
                    db.update(userData.getUserPatient().getPatientId(),updateTabs);
                }else {
                    if(  firstBean!=null){
                        ArrayList<Parse2PublictyTabBean> updateTabs =    updateTab(firstBean,tabbeanList);
                        db.insert(userData.getUserPatient().getPatientId(),updateTabs);
                    }
                }
            }
        }
    }

    @Override
    public void onDestroy() {
        delayHandler.removeCallbacks(null);
        popupWindow = null;
        UtilViewShow.destoryDialogs(sendDialog);
        saveLabel();
        super.onDestroy();
    }

}
