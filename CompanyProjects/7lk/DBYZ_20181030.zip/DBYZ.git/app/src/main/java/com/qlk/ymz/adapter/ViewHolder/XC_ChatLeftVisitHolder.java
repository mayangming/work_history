package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 随访
 */
public class XC_ChatLeftVisitHolder extends XC_ChatLeftBaseHolder {
    public TextView id_left_suifang_title;
    public TextView id_left_suifang_content;
    public RelativeLayout id_left_suifang_layout;

    public XC_ChatLeftVisitHolder(View convertView) {
        super(convertView);
        id_left_suifang_title = (TextView) convertView.findViewById(R.id.id_left_suifang_title);
        id_left_suifang_content = (TextView) convertView.findViewById(R.id.id_left_suifang_content);
        id_left_suifang_layout = (RelativeLayout) convertView.findViewById(R.id.id_left_suifang_layout);
    }
}