package com.qlk.ymz.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.SafeMedicationItemInfo;
import com.qlk.ymz.util.UtilCollection;

import java.util.List;

public class SafeMedicationAdapter extends RecyclerView.Adapter {
    private static final int TYPE_LABEL = 1;
    private static final int TYPE_TITLE = 2;
    private static final int TYPE_CONTENT = 3;
    private static final int TYPE_LINE = 4;
    private Activity context;

    private List<SafeMedicationItemInfo> list;

    public SafeMedicationAdapter(Activity context){
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(viewType == TYPE_LABEL){
            View view = LayoutInflater.from(context).inflate(R.layout.view_item_warning_lable,parent,false);
            return new LabelViewHolder(view);
        }else if(viewType == TYPE_TITLE){
            View view = LayoutInflater.from(context).inflate(R.layout.view_item_warning_title,parent,false);
            return new TitleViewHolder(view);
        }else if(viewType == TYPE_CONTENT){
            View view = LayoutInflater.from(context).inflate(R.layout.view_item_warning_content,parent,false);
            return new ContentViewHolder(view);
        }else if(viewType == TYPE_LINE){
            View view = LayoutInflater.from(context).inflate(R.layout.view_item_warning_line,parent,false);
            return new LineViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        SafeMedicationItemInfo bean = list.get(position);
        if(holder instanceof LabelViewHolder){
            if("1".equals(bean.getLabelType())){
                ((LabelViewHolder)holder).tv_warning.setText("禁用");
                ((LabelViewHolder)holder).tv_warning.setTextColor(context.getResources().getColor(R.color.c_e2231a));
                ((LabelViewHolder)holder).iv_label.setImageDrawable(context.getResources().getDrawable(R.mipmap.iv_disable));
            }else if("2".equals(bean.getLabelType())) {
                ((LabelViewHolder)holder).tv_warning.setText("谨慎");
                ((LabelViewHolder)holder).tv_warning.setTextColor(context.getResources().getColor(R.color.c_F49C0B));
                ((LabelViewHolder)holder).iv_label.setImageDrawable(context.getResources().getDrawable(R.mipmap.iv_cautious));
            }
        }else if(holder instanceof TitleViewHolder){
            ((TitleViewHolder)holder).tv_warning_title.setText(bean.getTitle());
        }else if(holder instanceof ContentViewHolder){
            ((ContentViewHolder)holder).tv_content.setText(bean.getContent());
        }else if(holder instanceof LineViewHolder){
            ((LineViewHolder)holder).tv_line.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        if(!UtilCollection.isBlank(list)) {
            return list.size();
        }
        return 0;
    }

    @Override
    public int getItemViewType(int position) {
        if(!UtilCollection.isBlank(list)) {
            return list.get(position).getType();
        }
        return 0;
    }

    class LabelViewHolder extends RecyclerView.ViewHolder{
        ImageView iv_label;
        TextView tv_warning;
        LabelViewHolder(View itemView) {
            super(itemView);
            iv_label =  itemView.findViewById(R.id.iv_label);
            tv_warning = itemView.findViewById(R.id.tv_warning);
        }
    }
    class TitleViewHolder extends RecyclerView.ViewHolder{
        TextView tv_warning_title;
        TitleViewHolder(View itemView) {
            super(itemView);
            tv_warning_title = itemView.findViewById(R.id.tv_warning_title);
        }
    }
    class ContentViewHolder extends RecyclerView.ViewHolder{
        TextView tv_content;
        ContentViewHolder(View itemView) {
            super(itemView);
            tv_content = itemView.findViewById(R.id.tv_content);
        }
    }
    class LineViewHolder extends RecyclerView.ViewHolder{
        View tv_line;
        LineViewHolder(View itemView) {
            super(itemView);
            tv_line = itemView.findViewById(R.id.line);
        }
    }
    public void update(List<SafeMedicationItemInfo> list){
        this.list = list;
    }
}
