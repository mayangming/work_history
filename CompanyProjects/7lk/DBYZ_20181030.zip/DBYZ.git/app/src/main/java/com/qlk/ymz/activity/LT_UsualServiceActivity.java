package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.LT_UsualServiceAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.ChatModelCustomAdvisory;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 李涛
 * @description  我的常用服务
 * @Date 2017/12/13.
 */
public class LT_UsualServiceActivity  extends DBActivity {

    /**主要内容*/
    private PullToRefreshListView lt_usual_serviec_listview;
    /**布局Title*/
    private XCTitleCommonLayout lt_usual_serviec_title;
    /**正文适配器*/
    private LT_UsualServiceAdapter contentAdapter;
    /**无网络数据页面*/
    private RelativeLayout lt_usual_serviec_nonet;
    private Button xc_id_no_net_button;
    /***无数据页面*/
    private RelativeLayout include_data_zero_view;
    private ImageView xc_id_data_zero_imageview;
    private TextView xc_id_data_zero_hint_textview;
    ArrayList<ChatModelCustomAdvisory> usualData = new ArrayList<>();
    /**是否有下一页*/
    private String haxNext = "false";

    private XC_ChatModel chatMode;
    private Intent intent;
    /**进入详情页是否替换数据*/
    private boolean isUpdateData;
    private YR_CommonDialog updateDialog;
    private String offset = "0";
    private String page = "1";
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lt__usual_service);
        super.onCreate(savedInstanceState);
        initNetData(page,true,offset);
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(LT_UsualServiceActivity.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */

    /**
     *    * 常用服务列表网络请求
     * @param nextPage   当前页码
     * @param isShowDialog  是否展示弹窗
     * @param offsets 后端需要
     */
    private void initNetData(String nextPage,boolean isShowDialog,String offsets) {
        RequestParams requestParams = new RequestParams();
        requestParams.put("num","10");
        requestParams.put("page",nextPage);
        requestParams.put("offset",offsets);
        XCHttpAsyn.getAsyn(isShowDialog,LT_UsualServiceActivity.this ,AppConfig.getHostUrl(AppConfig.my_usual_service),requestParams,new XCHttpResponseHandler(){
            @Override

            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){
                    List<XCJsonBean> data =  result_bean.getList("data");
                    haxNext = data.get(0).getString("hasNext");
                    offset = data.get(0).getString("offset");
                    page = data.get(0).getString("pageNo");
                   ChatModelCustomAdvisory.ParseJson(data,usualData);
                    lt_usual_serviec_listview.onRefreshComplete();
                    if(usualData.size()>0){
                        NetDataShow();
                        contentAdapter.update(usualData);
                    }else{
                        DataNullViewShow();
                    }

                    //判断是否有下一页数据
                    if("false".equals(haxNext)){
                        lt_usual_serviec_listview.setMode(PullToRefreshBase.Mode.DISABLED);//设置了取消加载
                    }

                    if("true".equals(haxNext)){
                        lt_usual_serviec_listview.setMode(PullToRefreshBase.Mode.PULL_FROM_END);//设置了只有上拉加载
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                NoNetViewShow();
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LT_UsualServiceActivity.this,getCode(),getMsg()));
            }
        });
    }

    /**
     * 常用服务删除请求
     * @param position
     */
    private void  deleteUsualService(final int position){
        String  deleteId = usualData.get(position).getCustomAdvisoryId();
        RequestParams requestParams = new RequestParams();
        requestParams.put("id",deleteId);
        XCHttpAsyn.getAsyn(true,LT_UsualServiceActivity.this ,AppConfig.getHostUrl(AppConfig.delete_my_usual_service),requestParams,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);

                usualData.remove(position);
                contentAdapter.update(usualData);
                //保证一个页面有大于十条数据
                if(10>usualData.size()&&"true".equals(haxNext)){
                    int nextPage = Integer.parseInt(page);
                        initNetData( ""+(nextPage+1),true,offset);
                }
                if(usualData.size()==0){
                    DataNullViewShow();
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                NoNetViewShow();
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LT_UsualServiceActivity.this, getCode(),getMsg())) { }
            }
        });
    }


    @Override
    public void initWidgets() {
       PF_IndividuationCostActivity.listSave.add(this);
        intent = getIntent();
        chatMode = (XC_ChatModel) intent.getSerializableExtra("chatModel");
        isUpdateData = intent.getBooleanExtra("isUpdateData",false);
        lt_usual_serviec_title = (XCTitleCommonLayout) findViewById(R.id.lt_usual_serviec_title);
        lt_usual_serviec_title.setTitleCenter(true,"我的常用服务");
        lt_usual_serviec_title.setTitleLeft( true, "");
        lt_usual_serviec_nonet = (RelativeLayout) findViewById(R.id.lt_usual_serviec_nonet);
        xc_id_no_net_button = (Button) findViewById(R.id.xc_id_no_net_button);
        include_data_zero_view = (RelativeLayout) findViewById(R.id.include_data_zero_view);
        lt_usual_serviec_listview = (PullToRefreshListView) findViewById(R.id.lt_usual_serviec_listview);
        lt_usual_serviec_listview.setMode(PullToRefreshBase.Mode.DISABLED);//默认取消刷新功能
        xc_id_data_zero_imageview = (ImageView) findViewById(R.id.xc_id_data_zero_imageview);
        xc_id_data_zero_hint_textview = (TextView) findViewById(R.id.xc_id_data_zero_hint_textview);
        xc_id_data_zero_hint_textview.setText("您还没有常用服务，可在推荐后添加~");
        //因为是卡片新式的Item所以宽度需要重新设置
        int  ContentWidth = (UtilScreen.getScreenWidthPx(LT_UsualServiceActivity.this)- UtilScreen.dip2px(LT_UsualServiceActivity.this,15));
        contentAdapter = new LT_UsualServiceAdapter(LT_UsualServiceActivity.this,R.layout.item_swipe,R.layout.lt_item_usualservice_view,R.layout.lt_usualservice_deleteview,ContentWidth,ContentWidth);
        lt_usual_serviec_listview.setAdapter(contentAdapter);
    }

    @Override
    public void listeners() {
        //进入详情
        contentAdapter.contentClick(new LT_UsualServiceAdapter.OnlickContent() {
            @Override
            public void Onclick(int position) {
                isUpdate(isUpdateData,position);
            }
        });

        //侧滑删除数据
        contentAdapter.deleteItem(new LT_UsualServiceAdapter.DeleteItemInterface() {
            @Override
            public void delete(int position) {
                deleteUsualService(position);
            }
        });


        //上拉加载
        lt_usual_serviec_listview.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {}

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                            //上拉加载数据
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        int nextPage = Integer.parseInt(page);
                        initNetData(""+(nextPage+1),false,offset);
                    }
                },500);

            }
        });

        //无网络数据时重启请求
        xc_id_no_net_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(usualData.size()>0){
                    usualData.clear();
                }
                initNetData(page,true,"0");
            }
        });
    }



    private void isUpdate(boolean isShowDialog, final int  position){
        if(isShowDialog){
            if(updateDialog==null){
                updateDialog = new YR_CommonDialog(LT_UsualServiceActivity.this,"是否替换掉现有服务?","取消","确认") {
                    @Override
                    public void confirmBtn() {
                        ChatModelCustomAdvisory chatModelCustomAdvisory =  usualData.get(position);
                        chatMode.getChatModelCustomAdvisory().setCustomAdvisoryName(chatModelCustomAdvisory.getCustomAdvisoryName());
                        chatMode.getChatModelCustomAdvisory().setCustomAdvisoryId(chatModelCustomAdvisory.getCustomAdvisoryId());
                        chatMode.getChatModelCustomAdvisory().setCustomPrice(chatModelCustomAdvisory.getCustomPrice());
                        chatMode.getChatModelCustomAdvisory().setCustomProductDesc(chatModelCustomAdvisory.getCustomProductDesc());
                        ToJumpHelp.toJumpIndividuationCostActivity(LT_UsualServiceActivity.this,chatMode ,2, CommonConfig.INDIVIDUATION_COST_REQUESED_CODE,"0");
                        updateDialog.dismiss();
                    }

                    @Override
                    public void cancelBtn() {
                        super.cancelBtn();
                        myFinish();
                        updateDialog.dismiss();
                    }
                };
            }
            updateDialog.show();
        }else{
            ChatModelCustomAdvisory chatModelCustomAdvisory =  usualData.get(position);
            chatMode.getChatModelCustomAdvisory().setCustomAdvisoryName(chatModelCustomAdvisory.getCustomAdvisoryName());
            chatMode.getChatModelCustomAdvisory().setCustomAdvisoryId(chatModelCustomAdvisory.getCustomAdvisoryId());
            chatMode.getChatModelCustomAdvisory().setCustomPrice(chatModelCustomAdvisory.getCustomPrice());
            chatMode.getChatModelCustomAdvisory().setCustomProductDesc(chatModelCustomAdvisory.getCustomProductDesc());
            ToJumpHelp.toJumpIndividuationCostActivity(LT_UsualServiceActivity.this,chatMode ,2, CommonConfig.INDIVIDUATION_COST_REQUESED_CODE,"0");
        }
    }



    //展示无数据页面
    private  void DataNullViewShow(){
//        xc_id_data_zero_hint_textview.setText("您还没有常用服务，可在推荐后添加~");
        xc_id_data_zero_imageview.setBackgroundResource(R.mipmap.js_d_icon_no_data);
        lt_usual_serviec_nonet.setVisibility(View.GONE);
        include_data_zero_view.setVisibility(View.VISIBLE);
        lt_usual_serviec_listview.setVisibility(View.GONE);
    }
    //展示无网络页面
    private void NoNetViewShow(){
        lt_usual_serviec_nonet.setVisibility(View.VISIBLE);
        include_data_zero_view.setVisibility(View.GONE);
        lt_usual_serviec_listview.setVisibility(View.GONE);
    }
    //正常展示
    private void NetDataShow(){
        lt_usual_serviec_nonet.setVisibility(View.GONE);
        include_data_zero_view.setVisibility(View.GONE);
        lt_usual_serviec_listview.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        UtilViewShow.destoryDialogs(updateDialog);
    }

    @Override
    public void onNetRefresh() {}
}
