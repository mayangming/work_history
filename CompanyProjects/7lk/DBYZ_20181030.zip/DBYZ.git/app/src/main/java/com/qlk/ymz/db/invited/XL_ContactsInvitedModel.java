package com.qlk.ymz.db.invited;

import android.text.TextUtils;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;

/**
 *
 * @author xiaocoder on 2016/3/23.
 * @modifier xiaocoder 2016/3/23 16:34.
 * @description
 */

public class XL_ContactsInvitedModel implements Serializable{

    /**
     * 已邀请
     */
    public static final String STATUS_INVITIED_YES = "1";

    /**
     * 未邀请
     */
    public static final String STATUS_INVITIED_NO = "0";

    /**
     * 医生id
     */
    public String doctorId = "";
    /**
     * 联系人id
     */
    public String contactId = "";

    /**
     * 电话id
     */
    public String phoneId = "";

    /**
     * 是否邀请的标识符
     */
    public String flag = "";

    /**
     * 电话号码
     */
    public String number = "";

    /**
     * 姓名
     */
    public String display_name = "";

    public String getContactId() {
        return UtilString.f(contactId);
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getNumber() {

        return UtilString.f(number);
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getDisplay_name() {
        return UtilString.f(display_name);
    }
    /**
     * 显示名字
     * @return 显示名字
     * 1.如果没有名字，则空一格。
     * 2.最多显示3位，剩余的用…表示
     */
    public String getDisplay_NameText(){
        String displayNameFormat = " ";
        if(TextUtils.isEmpty(display_name) ){

        } else if(display_name.length() >0 && display_name.length() <= 3){

            displayNameFormat = display_name;

        } else {
            displayNameFormat = display_name.substring(0,3) + "...";

        }
        return displayNameFormat;
    }
    public void setDisplay_name(String display_name) {
        this.display_name = display_name;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    @Override
    public String toString() {
        return "XL_ContactsInvitedModel{" +
                "contactId='" + contactId + '\'' +
                ", doctorId='" + doctorId + '\'' +
                ", phoneId='" + phoneId + '\'' +
                ", flag='" + flag + '\'' +
                ", number='" + number + '\'' +
                ", display_name='" + display_name + '\'' +
                '}';
    }
}
