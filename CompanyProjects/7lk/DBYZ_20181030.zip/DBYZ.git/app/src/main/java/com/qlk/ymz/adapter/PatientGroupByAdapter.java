package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;

import com.qlk.ymz.R;
import com.qlk.ymz.util.ViewHolder;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import java.util.HashMap;
import java.util.List;

/**
 * 患者分组适配器
 *
 * @author WangYong
 * @version 2.8
 */
public class PatientGroupByAdapter extends XCBaseAdapter<XCJsonBean> {
    private LayoutInflater mInflater;

    public HashMap<Integer, Boolean> getIsCheckMap() {
        return isCheckMap;
    }

    private HashMap<Integer, Boolean> isCheckMap = new HashMap<Integer, Boolean>();

    public PatientGroupByAdapter(Context context, List<XCJsonBean> list) {
        super(context, list);
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = mInflater.inflate(R.layout.item_patient_group, null);
        }
        CheckBox group_name_text = ViewHolder.get(view, R.id.tv_group_name_num);
        final ImageView icon = ViewHolder.get(view, R.id.icon);
        View v_bottom_line = ViewHolder.get(view, R.id.v_bottom_line);
        View v_bottom = ViewHolder.get(view, R.id.v_bottom);
        group_name_text.setText(list.get(i).getString("groupName"));
        if (list.size() - 1 == i) {
            v_bottom_line.setVisibility(View.GONE);
            v_bottom.setVisibility(View.VISIBLE);
        } else {
            v_bottom_line.setVisibility(View.VISIBLE);
            v_bottom.setVisibility(View.GONE);
        }
        group_name_text.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (!isCheckMap.containsKey(i)) {
                    isCheckMap.put(i, b);
                    icon.setImageResource(R.mipmap.icon_selectd_group);
                } else {
                    isCheckMap.remove(i);
                    icon.setImageResource(R.mipmap.icon_not_select_group);
                }
            }
        });
        if (isCheckMap.get(i) != null) {
            icon.setImageResource(R.mipmap.icon_selectd_group);
        } else {
            icon.setImageResource(R.mipmap.icon_not_select_group);
        }
        return view;
    }
}
