package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import java.util.List;

/**
 * Created by songxin on 2015/8/25.
 *
 * SX_RightDepartmentAdapter
 * 科室右边adapter
 * @author  Changed by songxin on 2016/3/30.
 * @version 2.3
 */
public class SX_RightDepartmentAdapter extends BaseAdapter {
    /** 上下文*/
    private Context mContext;
    /** 右边科室数据*/
    private List<XCJsonBean> mXcjsonBean;
    /** LayoutInflater*/
    private LayoutInflater mInflater;
    /** ViewHolder*/
    private ViewHolder mViewHolder;

    public SX_RightDepartmentAdapter(Context context, List<XCJsonBean> xcJsonBeans) {
        mInflater = LayoutInflater.from(context);
        this.mXcjsonBean = xcJsonBeans;
        this.mContext = context;
    }

    @Override
    public int getCount() {
        if(null == mXcjsonBean ){
            return 0;
        }
        return mXcjsonBean.size();
    }

    @Override
    public Object getItem(int position) {
        if(null == mXcjsonBean){
            return null;
        }
        return mXcjsonBean.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(null == convertView){
            mViewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.sx_l_adapter_department_item,null);
            mViewHolder.sx_l_adapter_department_show = (TextView) convertView.findViewById(R.id.sx_l_adapter_department_show);
            mViewHolder.sx_id_department_rl = (RelativeLayout)convertView.findViewById(R.id.sx_id_department_rl);
            mViewHolder.view1 = convertView.findViewById(R.id.view1);
            mViewHolder.view2 = convertView.findViewById(R.id.view2);
            convertView.setTag(mViewHolder);
        }else{
            mViewHolder = (ViewHolder)convertView.getTag();
        }
        if(null != mXcjsonBean){
            if(mXcjsonBean.get(position).getBoolean("isChoose")){
                mViewHolder.sx_l_adapter_department_show.setTextColor((mContext.getResources().getColor(R.color.c_e2231a)));
            }else{
                mViewHolder.sx_l_adapter_department_show.setTextColor((mContext.getResources().getColor(R.color.c_7b7b7b)));
            }
            mViewHolder.sx_l_adapter_department_show.setSingleLine(false);
            mViewHolder.sx_id_department_rl.setBackgroundColor(mContext.getResources().getColor(R.color.c_white_ffffff));
            mViewHolder.sx_l_adapter_department_show.setText(mXcjsonBean.get(position).getString("departName"));
            mViewHolder.view1.setVisibility(View.GONE);
            mViewHolder.view2.setVisibility(View.GONE);
        }
        return convertView;
    }

    public void setList(List<XCJsonBean> xcJsonBeans){
        if(null != xcJsonBeans && xcJsonBeans.size() != 0){
            this.mXcjsonBean.clear();
            this.mXcjsonBean.addAll(xcJsonBeans);
            notifyDataSetChanged();
        }
    }

    static class ViewHolder{
        /** 科室显示*/
        TextView sx_l_adapter_department_show;
        /** 科室背景rl*/
        RelativeLayout sx_id_department_rl;
        /** view*/
        View view1;
        /** view*/
        View view2;
    }
}
