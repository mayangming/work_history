package com.qlk.ymz.db.bi;

/**
 * SX_BiUpdateFailModel
 * bi发送失败存储模型
 * @author songxin on 2016/4/27.
 * @version 2.3.0
 */
public class SX_BiUpdateFailModel {
    /** bi统计上传失败内容*/
    private String bi_content = "";
    /** bi失败内容存入时间*/
    private String save_time = "";

    public String getBi_content() {
        return bi_content;
    }

    public void setBi_content(String bi_content) {
        this.bi_content = bi_content;
    }

    public String getSave_time() {
        return save_time;
    }

    public void setSave_time(String save_time) {
        this.save_time = save_time;
    }
}
