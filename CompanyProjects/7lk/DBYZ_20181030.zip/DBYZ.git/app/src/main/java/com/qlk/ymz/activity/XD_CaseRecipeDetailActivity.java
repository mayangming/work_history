package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.fragment.XD_CaseDetailFragment;
import com.qlk.ymz.fragment.XD_RecipeDetailFragment;
import com.qlk.ymz.model.RecommendInfo;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;

/**
 * Created by xiedong on 2018/6/25.
 * 病历处方详情 v2.19
 */

public class XD_CaseRecipeDetailActivity extends DBActivity {
    public static final String DR_RECORD_VOBEAN = "drRecordVOBean";
    public static final String RECOMMEND_INFO = "recommendInfo";
    public static final String USER_PATIENT = "userPatient";//患者信息
    public static final String TAB = "tab";
    public static final String FLAG = "flag";//页面标识 1 im进入 2 病历列表进入  3 续方列表进入
    /** 标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** tab布局*/
    private LinearLayout ll_tab;
    /** 病历tab*/
    private TextView tv_case;
    /** 处方*/
    private TextView tv_recipe;

    private XD_CaseDetailFragment mXD_caseDetailFragment;
    private XD_RecipeDetailFragment mXD_recipeDetailFragment;
    private DrRecordVOBean mDrRecordVOBean = new DrRecordVOBean();
    private RecommendInfo mRecommendInfo = new RecommendInfo();

    private int mCurrentTab =1;//当前显示的tab  1,2
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_case_recipe_detail);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_CaseRecipeDetailActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleLeft(true, "");
        xc_id_model_titlebar.setTitleCenter(true, "病历详情");
        xc_id_model_titlebar.findViewById(R.id.line).setVisibility(View.GONE);

        ll_tab = getViewById(R.id.ll_tab);
        tv_case = getViewById(R.id.tv_case);
        tv_recipe = getViewById(R.id.tv_recipe);
    }

    @Override
    public void listeners() {
        tv_case.setOnClickListener(this);
        tv_recipe.setOnClickListener(this);
    }

    /**
     * 初始化数据ui
     */
    private void initData() {
        mDrRecordVOBean = (DrRecordVOBean) getIntent().getSerializableExtra(DR_RECORD_VOBEAN);
        mRecommendInfo = (RecommendInfo) getIntent().getSerializableExtra(RECOMMEND_INFO);
        UserPatient userPatient = (UserPatient) getIntent().getSerializableExtra(USER_PATIENT);
        String flag = getIntent().getStringExtra(FLAG);
        mCurrentTab = getIntent().getIntExtra(TAB,1);

        mXD_caseDetailFragment = new XD_CaseDetailFragment();
        mXD_caseDetailFragment.setDrRecordVOBean(mDrRecordVOBean);
        addFragment(R.id.xc_id_model_content,mXD_caseDetailFragment);
        mXD_recipeDetailFragment = new XD_RecipeDetailFragment();
        mXD_recipeDetailFragment.setData(mRecommendInfo,mDrRecordVOBean,userPatient,flag);
        addFragment(R.id.xc_id_model_content,mXD_recipeDetailFragment);

        switchTab(mCurrentTab);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_case:
                if(mCurrentTab ==2){
                    switchTab(1);
                    mCurrentTab = 1;
                }
                break;
            case R.id.tv_recipe:
                if(mCurrentTab ==1){
                    switchTab(2);
                    mCurrentTab = 2;
                }
                break;
            case R.id.tv_creat:

                break;
            case R.id.tv_next:
                break;
        }
        super.onClick(v);
    }

    private void switchTab(int tab) {
        switch (tab){
            case 1:
                showFragment(mXD_caseDetailFragment);
                hideFragment(mXD_recipeDetailFragment);
                ll_tab.setBackgroundResource(R.mipmap.case_tag_left_bg);
                tv_case.setTextColor(getResources().getColor(R.color.c_444444));
                tv_recipe.setTextColor(getResources().getColor(R.color.c_7f444444));
                break;
            case 2:
                showFragment(mXD_recipeDetailFragment);
                hideFragment(mXD_caseDetailFragment);
                ll_tab.setBackgroundResource(R.mipmap.case_tag_right_bg);
                tv_recipe.setTextColor(getResources().getColor(R.color.c_444444));
                tv_case.setTextColor(getResources().getColor(R.color.c_7f444444));
                break;
        }
    }

    public void setRecipeInvalid(String invalid){
        mRecommendInfo.setInvalid(invalid);
    }
    public String getRecipeInvalid(){
        return mRecommendInfo.getInvalid();
    }
    public void setCaseInvalid(String invalid){
        ((DrCaseVOBean) mDrRecordVOBean.getMdicalRecordVO()).setInvalid(invalid);
    }
    public String getCaseInvalid(){
        return ((DrCaseVOBean) mDrRecordVOBean.getMdicalRecordVO()).getInvalid();
    }

    public void setImStaus(String staus){
        XCChatModelDb.getInstance(this, UtilSP.getIMDetailDbName
                (UtilSP.getUserId(),mDrRecordVOBean.getPatientId()))
                .updateInvalidForRecommandId(mRecommendInfo.getRecommendId(),staus);
        Intent imIntent = new Intent();
        imIntent.setAction(XC_ChatDetailActivity.UpdateInvalidReceiver.UPDATE_IVALID_ACTION);
        imIntent.putExtra(XC_ChatDetailActivity.UpdateInvalidReceiver
                .UPDATE_IVALID_RECOMMAND_ID,mRecommendInfo.getRecommendId());
        imIntent.putExtra(XC_ChatDetailActivity.UpdateInvalidReceiver
                .UPDATE_IVALID_STATUS,staus);
        sendBroadcast(imIntent);
    }

}
