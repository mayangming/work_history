package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCSwitchButton;

import org.apache.http.Header;


/**
 * 聊天设置
 *
 * @author zhangpengfei
 * @version 1.2
 * v2.8  xd 页面改版
 */
public class PF_ChatSetting extends DBActivity {
    XCTitleCommonLayout titleLayout;
    /**
     * 消息置顶
     */
    private XCSwitchButton pr_id_chat_setting_message_top;
    /**
     * 免消息打扰
     */
    private XCSwitchButton pf_id_chat_setting_no_disturb;
    /**
     * 付费咨询设置
     */
    private LinearLayout pf_id_chat_setting_consulting_fees;

    /**
     * 患者名字
     */
    public static final String PATIENT_NAME = "patientName";
    /**
     * 患者id
     */
    private String patientID = "-1";
    public static final int TO_PATIENT_DETAIL = 232;
    private Intent intent;
    private JS_ChatListModel chatListModel;
    /**
     * 免打扰按钮状态
     */
    private boolean isShie = false;
    private XC_ChatModel xc_chatModel;
    /**
     * 设置价格
     */
    private String price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_activity_chat_setting);
        super.onCreate(savedInstanceState);

        titleLayout.setTitleLeft(true, "");
        titleLayout.setTitleCenter(true, "聊天设置");

    }

    /**
     * created by songxin,date：2016-4-23,about：bi,begin
     */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_ChatSetting.class);
    }

    /**
     * created by songxin,date：2016-4-23,about：bi,end
     */


    @Override
    public void initWidgets() {
        titleLayout = getViewById(R.id.xc_id_model_titlebar);
        pr_id_chat_setting_message_top = getViewById(R.id.pr_id_chat_setting_message_top);
        pf_id_chat_setting_no_disturb = getViewById(R.id.pf_id_chat_setting_no_disturb);
        pf_id_chat_setting_consulting_fees = getViewById(R.id.pf_id_chat_setting_consulting_fees);
        intent = new Intent();
        if (null != getIntent()) {
            xc_chatModel = (XC_ChatModel) getIntent().getSerializableExtra(CommonConfig.CHAT_PARAMS_MODEL);
            if (!UtilString.isBlank(xc_chatModel.getUserPatient().getPatientId())) {
                patientID = xc_chatModel.getUserPatient().getPatientId();
                price = xc_chatModel.getUserPatient().getPayAmount();
            }
            chatListModel = JS_ChatListDB.getInstance(PF_ChatSetting.this, UtilSP.getUserId()).getPatientInfo(patientID);
            if (null != chatListModel) {
                //患者被屏蔽标示（说明：0:不屏蔽，1:屏蔽）
                if ("0".equals(chatListModel.getUserPatient().getIsShield())) {
                    pf_id_chat_setting_no_disturb.setState(false);
                } else if ("1".equals(chatListModel.getUserPatient().getIsShield())) {
                    pf_id_chat_setting_no_disturb.setState(true);
                }
                //患者置顶标示（说明：0:不置顶，1:置顶）
                if ("0".equals(chatListModel.getTopSortTime())) {
                    pr_id_chat_setting_message_top.setState(false);
                } else if ("1".equals(chatListModel.getTopSortTime())) {
                    pr_id_chat_setting_message_top.setState(true);
                }

            }
        }
    }

    @Override
    public void listeners() {
        titleLayout.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        pf_id_chat_setting_consulting_fees.setOnClickListener(this);
        pf_id_chat_setting_no_disturb.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            @Override
            public void open() {
                isShie = true;

                if (!isDestroy) {
                    requestShieldSet("1");
                }
            }

            @Override
            public void close() {
                isShie = false;

                if (!isDestroy) {
                    requestShieldSet("0");
                }
            }
        });
        pr_id_chat_setting_message_top.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            @Override
            public void open() {
                JS_ChatListDB.getInstance(PF_ChatSetting.this, UtilSP.getUserId()).setTopStatus(patientID, true);
            }

            @Override
            public void close() {
                JS_ChatListDB.getInstance(PF_ChatSetting.this, UtilSP.getUserId()).setTopStatus(patientID, false);
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            //付费咨询设置
            case R.id.pf_id_chat_setting_consulting_fees:
                ToJumpHelp.toJumpSetPersonalConsultFeesActivity(this, xc_chatModel,
                        CommonConfig.SET_PERSONAL_CONSULTING_FEES_CODE);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (RESULT_OK == resultCode) {
            switch (requestCode) {
                case CommonConfig.SET_PERSONAL_CONSULTING_FEES_CODE:
                    if (data != null && data.getExtras() != null) {
                        price = data.getStringExtra(CommonConfig.PERSONAL_CONSULTING_FEES);
                        xc_chatModel.getUserPatient().setPayAmount(price);
                    }
                    break;
            }
        }
    }

    /**
     * 请求设置屏蔽接口
     *
     * @param operate 是否开启屏蔽 "0": 取消  "1":开启
     */
    public void requestShieldSet(final String operate) {
        RequestParams params = new RequestParams();
        params.put("shieldId", patientID);
        params.put("operate", operate);
        XCHttpAsyn.postAsyn(this, AppConfig.getChatUrl(AppConfig.shieldSet), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    // "0": 取消  "1":开启
                    if ("0".equals(operate)) {
                        JS_ChatListDB.getInstance(PF_ChatSetting.this, UtilSP.getUserId()).setSilentStatus(patientID, false);
                    } else {
                        JS_ChatListDB.getInstance(PF_ChatSetting.this, UtilSP.getUserId()).setSilentStatus(patientID, true);
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                pf_id_chat_setting_no_disturb.setState(!isShie);
            }
        });
    }

    @Override
    public void onBackPressed() {
        setPFActivityResult();

    }

    /**
     * 监听返回键
     */
    private void setPFActivityResult() {
        Intent intent = new Intent();
        intent.putExtra(CommonConfig.PERSONAL_CONSULTING_FEES, price);
        setResult(RESULT_OK, intent);
        finish();
    }
}
