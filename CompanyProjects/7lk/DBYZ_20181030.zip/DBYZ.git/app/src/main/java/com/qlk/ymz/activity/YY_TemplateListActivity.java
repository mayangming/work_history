package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.YY_TemplateListBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YY_TemplateDetailDialog;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.LinkedList;
import java.util.List;

/**
 * @author shuYanYi on 2016/11/07.
 * @description 随访模板列表
 * @version V2.6.5
 */
public class YY_TemplateListActivity extends DBActivity {
    /** 传递参数：模板id*/
    public static final String INTENT_PARAM_TEMPLETID = "templetId";

    /**标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** 新建模板按钮*/
    private TextView tv_add;
    /** 列表适配器*/
    private TemplateListAdapter adapter;

    private List list = new LinkedList();
    /** 随访模板列表*/
    private XCListViewFragment listViewFragment;
    /** 查看模板详情dialog*/
    private YY_TemplateDetailDialog dialog;

    /** 无数据提示*/
    private String noData_text = "暂无模板";
    /** 无数据背景*/
    private int noData_imgId = R.mipmap.js_d_icon_no_data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yy_l_template_list);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-22,about：saveInfo,begin
        BiUtil.saveBiInfo(YY_TemplateListActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-22,about：saveInfo,end

    }


    /** created by songxin,date：2016-8-16,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YY_TemplateListActivity.class);
    }
    /** created by songxin,date：2016-8-16,about：bi,end */


    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "随访模板");
        xc_id_model_titlebar.setTitleLeft(true, null);
        tv_add = getViewById(R.id.tv_add);
        adapter = new TemplateListAdapter(this,list);
        listViewFragment = new XCListViewFragment();
        listViewFragment.setAdapter(adapter);
        listViewFragment.setMode(XCListViewFragment.MODE_NOT_PULL);//设置不能上下拉
        listViewFragment.setListViewStyleParam(null, 0, false);
        addFragment(R.id.lv_templete_list, listViewFragment);
        dialog = new YY_TemplateDetailDialog(this);
    }

    @Override
    public void listeners() {
        tv_add.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {
        requestTemplateList();

    }

    @Override
    protected void onResume() {
        super.onResume();
        requestTemplateList();
    }

    @Override
    public void onClick(final View v) {
        super.onClick(v);
        Intent intent;
        switch(v.getId()){
            // 增加自定义模板 此版本暂不上
            case R.id.tv_add :
                intent = new Intent(YY_TemplateListActivity.this, YY_TemplateEditActivity.class);
                myStartActivity(intent);
                break;

        }


    }


    private void requestTemplateList() {
        RequestParams params = new RequestParams();
        params.put("page", 1);//现在自定义增加模板需求，暂被砍掉
        params.put("num", 999);
        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.feedback_template_list), params, new XCHttpResponseHandler<YY_TemplateListBean>(this, YY_TemplateListBean.class) {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (!result_boolean) {
                    return;
                }
                List<YY_TemplateListBean.DataBean> objLists = mResultModel.getData();
                if (objLists == null && objLists.size() == 0) {
                    return;
                }
                List templateList = objLists.get(0).getResult();
                listViewFragment.whichShow(templateList == null ? 0 : templateList.size(), noData_text, noData_imgId, "");
               listViewFragment.updateSpecialList(templateList);
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YY_TemplateListActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }

        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        UtilViewShow.destoryDialogs(dialog);
    }

    /**
     * 模板列表适配器
     */
     class TemplateListAdapter extends XCBaseAdapter<YY_TemplateListBean.DataBean.ResultBean> {

        public TemplateListAdapter(Context context, List<YY_TemplateListBean.DataBean.ResultBean> list){
            super(context,list);
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup viewGroup) {
            ViewHolder holder = null;
            if(convertView == null){
                convertView = LayoutInflater.from(context).inflate(R.layout.yy_item_template_list,null);
                holder = new ViewHolder(convertView);
                convertView.setTag(holder);
            }else{
                holder = (ViewHolder) convertView.getTag();
            }
            YY_TemplateListBean.DataBean.ResultBean bean = list.get(position);
            final String templetId = bean.getTempletId();
            holder.tv_name.setText(bean.getTempletTitle());
            // 设置底部分割线，如果是当前字母最后一个则隐藏
            holder.v_line.setVisibility(View.VISIBLE);
            if (list.size() - 1 == position) {
                holder.v_line.setVisibility(View.INVISIBLE);
            }

            holder.tv_name.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    /*Intent intent = new Intent(YY_TemplateListActivity.this,YY_TemplateEditActivity.class);//此版本暂不上自定义编辑/新增模板
                    intent.putExtra(INTENT_PARAM_TEMPLETID,templetId);
                    myStartActivity(intent);*/
                    dialog.show(templetId);
                }
            });


            return convertView;
        }

        private class ViewHolder {
            private TextView tv_name;
            private View v_line;
            public ViewHolder(View convertView){
                tv_name = (TextView)convertView.findViewById(R.id.tv_name);
                v_line = convertView.findViewById(R.id.v_line);
            }
        }

    }
}
