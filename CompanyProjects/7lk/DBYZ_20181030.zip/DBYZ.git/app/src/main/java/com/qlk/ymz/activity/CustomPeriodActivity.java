package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.medicine.MedicineCustomCycleUnitBean;
import com.qlk.ymz.model.medicine.MedicineUsageBean;
import com.qlk.ymz.util.MedicineUsageUtil;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.UsageDialog;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Integer.parseInt;


/**
 * 自定义周期页
 */

public class CustomPeriodActivity extends CustomBaseActivity {
    /**减每次服药时间按钮  */
    private ImageView iv_minus_time_btn;
    /** 时间num */
    private EditText et_time_num;
    /**加每次服药时间按钮  */
    private ImageView iv_plus_time_btn;
    /**服药时间的单位   */
    private TextView tv_time_unit;

    private UsageDialog usageDialog;

    MedicineUsageBean usageBean;

    /** 时间Str*/
    private String timeNumStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_custom_period);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(CustomPeriodActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void initWidgets() {
        title = "自定义周期";
        super.initWidgets();
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        iv_minus_time_btn = getViewById(R.id.iv_minus_time_btn);
        et_time_num = getViewById(R.id.et_time_num);
        iv_plus_time_btn = getViewById(R.id.iv_plus_time_btn);
        tv_time_unit = getViewById(R.id.tv_time_unit);
        tv_time_unit.setText("日");
        iv_plus_time_btn.setTag(et_time_num);
        iv_minus_time_btn.setTag(et_time_num);
        setNumAddClick(iv_plus_time_btn,999,et_time_num,true);
        setNumSubClick(iv_minus_time_btn,0);

        usageBean = (MedicineUsageBean) getIntent().getSerializableExtra(UsageDialog.TAG_USAGE_BEAN);

        usageDialog = new UsageDialog(this);
        usageDialog.hideDiyView();
    }

    @Override
    public void listeners() {
        tv_time_unit.setOnClickListener(this);

        usageDialog.setOnUsageDialogClickListener(new UsageDialog.OnUsageDialogClickListener() {
            @Override
            public void onCustomClick() {

            }

            @Override
            public void onSaveClick(String text) {
                if(TextUtils.isEmpty(text)){
                    shortToast("选择一个周期");
                    return;
                }
                tv_time_unit.setText(text);
                usageBean.setDrugCycleUnit(text);
                usageDialog.dismiss();
            }

            @Override
            public void onItemClick(String text) {

            }
        });

        et_time_num.addTextChangedListener(new TextWatcher() {
            int oneMin = 0;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String temp = s + "";
                String dot = ".";

                //如果"."在起始位置,则起始位置自动补最小值
                if (temp.trim().substring(0).equals(dot)) {
                    temp = "" + oneMin + temp;
                    et_time_num.setText(temp);
                    et_time_num.setSelection(et_time_num.getText().length());
                }

                if (!temp.contains(dot) && temp.length() > 3) {
                    //  如果不包含小数点，并且长度大于三位
                    et_time_num.setText(temp.substring(0,temp.length() - 1));
                    et_time_num.setSelection(et_time_num.getText().length());
                }else if(temp.contains(dot)){
                    //如果包含小数点  删除“.”后面超过2位后的数据
                    if (temp.length() - 1 - temp.indexOf(dot) > 2) {
                        s = temp.subSequence(0,
                                temp.indexOf(dot) + 3);
                        et_time_num.setText(s);
                        et_time_num.setSelection(et_time_num.getText().length()); //光标移到最后
                    }

                }

            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch(v.getId()){
            // 服药时间的单位
            case R.id.tv_time_unit :
                List<String> textList = new ArrayList<>();
                for (MedicineCustomCycleUnitBean bean: MedicineUsageUtil.getMedicineCustomCycleUnitBeanList()){
                    textList.add(bean.getCustomCycleDateUnit());
                }
                usageDialog.getAdapter().checkItem(tv_time_unit.getText().toString());
                usageDialog.updata(textList);
                usageDialog.show();
                break;
            default:

                break;

        }
    }

    /**
     * 设置加号监听
     * @param view 加号view “ + ”
     * @param maxNum 最大值
     * @param isDecimal 是否有小数点 (true:是,false:否)
     */
    public void setNumAddClick(View view,final int maxNum,EditText editText,boolean isDecimal){
        int maxLength = (maxNum + "").length();
        if(isDecimal){
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength + 3)});
        }else {
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        }
        View.OnClickListener numAdd;
        numAdd = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText = (EditText)v.getTag();

                String tempNum = editText.getText().toString().trim();

                // 小数点
                String dot = ".";
                // 小数点后面的数字
                String floatStr = "";
                if(UtilString.isBlank(tempNum)){
                    tempNum = "0";
                }

                try {
                    double aDouble = Double.parseDouble(tempNum);
                }catch (Exception e){
                    e.printStackTrace();
                    return;
                }

                // 检查是否包含小数点 true = 包含
                if(tempNum.contains(dot)){
                    // 保存小数点后面的数字
                    floatStr = tempNum.substring(tempNum.lastIndexOf(dot),tempNum.length());

                    if(tempNum.lastIndexOf(dot) == 0){
                        // 如果小数点在第一位 数字设为 0
                        tempNum = "0";
                    }else{
                        // 否则数字设为小数点前的数字
                        tempNum = tempNum.substring(0 , tempNum.lastIndexOf(dot));
                    }
                }

                int num = parseInt(tempNum);
                if( num < maxNum ){
                    num = num + 1;
                }
                // 结果等于整数 + 小数
                String numStr = num + floatStr;

                editText.setText( numStr);
                editText.setSelection(editText.getText().toString().trim().length());
            }
        };
        view.setOnClickListener(numAdd);
    }

    /**
     * 设置减号监听
     * @param view 减号view “ — ”
     */
    public void setNumSubClick(View view,final int minNumber){
        View.OnClickListener numSub;
        numSub = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText = (EditText)v.getTag();
                String tempNum = editText.getText().toString().trim();
                String dot = ".";       // 小数点
                String floatStr = "";   // 小数点后面的数字
                String result = "";

                try {
                    double aDouble = Double.parseDouble(tempNum);
                }catch (Exception e){
                    e.printStackTrace();
                    return;
                }

                int minNum = minNumber;
                if(UtilString.isBlank(tempNum)){
                    return;
                }

                // 检查是否包含小数点 true = 包含
                if(tempNum.contains(dot)){
                    // 保存小数点后面的数字
                    floatStr = tempNum.substring(tempNum.lastIndexOf(dot),tempNum.length());

                    // 数字设为小数点前的数字
                    tempNum = tempNum.substring(0 , tempNum.lastIndexOf(dot));

                    result = tempNum + floatStr;
                }

                int num = parseInt(tempNum);
                if( num > minNum ){
                    result = (num - 1) + floatStr;
                }

                editText.setText( result );
                editText.setSelection( editText.getText().toString().trim().length() );
            }
        };
        view.setOnClickListener( numSub );
    }

    @Override
    protected void save() {
        super.save();
        timeNumStr = et_time_num.getText().toString().trim();
        usageBean.setDrugCycleUnit(tv_time_unit.getText().toString().trim());
        usageBean.setDrugCycle(timeNumStr);
        if (TextUtils.isEmpty(timeNumStr)
                || "0".equals(timeNumStr)
                || TextUtils.isEmpty(usageBean.getDrugCycleUnit())){
            return;
        }
        UtilInputMethod.hiddenInputMethod(this);
        Intent intent = new Intent();
        intent.putExtra(UsageDialog.TAG_USAGE_BEAN,usageBean);
        setResult(Activity.RESULT_OK,intent);
        finish();
    }
}
