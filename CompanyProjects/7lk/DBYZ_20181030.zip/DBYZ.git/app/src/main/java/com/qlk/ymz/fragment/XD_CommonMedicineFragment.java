package com.qlk.ymz.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.UsageActivityV2;
import com.qlk.ymz.activity.XD_CommonMedicineActivity;
import com.qlk.ymz.activity.XD_RecommendedMedicationActivity;
import com.qlk.ymz.adapter.CommonMedicineAdapter;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.parse.Parse2DrugBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;
import com.xiaocoder.ptrrefresh.XCMaterialListPinRefreshLayout;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2017/12/12.
 */

public class XD_CommonMedicineFragment extends XD_BaseFragment implements CommonMedicineAdapter
        .CommonMedicineActionListener {
    /**
     * 常用药刷新列表
     */
    private XCMaterialListPinRefreshLayout mXCMaterialListPinRefreshLayout;
    /**
     * 处方列表
     */
    private ListView mListView;

    /**
     * 常用药适配器
     */
    private CommonMedicineAdapter mCommonMedicineAdapter;
    /**
     * 宿主
     */
    private XD_RecommendedMedicationActivity mActivity;
    /**
     * 常用药集合
     */
    private List<DrugBean> mCommonMedicineList = new ArrayList<>();

    private int offset;//后台判断
    private int nextPage = 1;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return init(inflater, R.layout.xd_fragment_common_medicine);
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    public void onStart() {
        super.onStart();
        BiUtil.savePid(XD_CommonMedicineFragment.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */

    @Override
    public void initWidgets() {
        super.initWidgets();
        mActivity = (XD_RecommendedMedicationActivity) getActivity();
        mXCMaterialListPinRefreshLayout = getViewById(R.id.rfl_common_medicine);
        mXCMaterialListPinRefreshLayout.setBgZeroHintInfo("无常用药数据", "", R.mipmap
                .js_d_icon_no_data);
        mListView = (ListView) mXCMaterialListPinRefreshLayout.getListView();
        int screenWidthPx = UtilScreen.getScreenWidthPx(getContext());
        mCommonMedicineAdapter = new CommonMedicineAdapter(getContext(), R.layout
                .xd_item_common_medicine, R.layout.xd_item_medicine_delete, screenWidthPx, screenWidthPx, null);
        mCommonMedicineAdapter.setCommonMedicineActionListener(this);
        mCommonMedicineAdapter.setIsRecomend(true);
        mCommonMedicineAdapter.setIsHome(true);
        mCommonMedicineAdapter.setCheckDrugMap(mActivity.getPatientDrugInfo().getCheckDrugMap());
        mListView.setAdapter(mCommonMedicineAdapter);
    }

    @Override
    public void onNetRefresh() {
        refresData();
    }

    @Override
    public void listeners() {
        mXCMaterialListPinRefreshLayout.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {
                return false;
            }

            @Override
            public boolean canLoad() {
                return true;
            }

            @Override
            public void refresh(View view, int request_page) {

            }

            @Override
            public void load(View view, int request_page) {
                getCommonMedicineData(nextPage);
            }
        });

        getCommonMedicineData(nextPage);
    }


    /**
     * 刷新数据
     */
    public void refresData() {
        mXCMaterialListPinRefreshLayout.resetCurrentPageAndList(mCommonMedicineAdapter);
        mCommonMedicineList.clear();
        offset = 0 ;
        nextPage = 1;
        getCommonMedicineData(nextPage);
    }

    /**
     * 删除常用药
     *
     * @param position
     */
    public void deleteCommonMedicine(final int position) {
        RequestParams params = new RequestParams();
        params.put("pid", mCommonMedicineList.get(position).getId());
        XCHttpAsyn.postAsyn(mActivity, AppConfig.getHostUrl(AppConfig.medication_removeBox), params,
                new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        XCHttpAsyn.httpFinish();
                        if (result_boolean) {
                            mCommonMedicineList.remove(position);//从集合中删除
                            mXCMaterialListPinRefreshLayout.updateListNoAdd(mCommonMedicineList,
                                    mCommonMedicineAdapter);
                            if (mCommonMedicineList.size() == 0) {
                                mXCMaterialListPinRefreshLayout.whichShow(0);
                            }else if(!mXCMaterialListPinRefreshLayout.isLastRequestResult()){
                                getCommonMedicineData(nextPage);
                            }else if(mCommonMedicineList.size()<10 && mXCMaterialListPinRefreshLayout
                                    .base_currentPage <mXCMaterialListPinRefreshLayout.base_totalPage){
                                mXCMaterialListPinRefreshLayout.setBase_currentPage(nextPage);
                                getCommonMedicineData(nextPage);
                            }
                        }
                    }

                    // 对账户冻结情况的判断处理
                    public void onFinish() {
//                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(mActivity,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

    /**
     * 获取常用药列表
     *
     * @param page
     */
    private void getCommonMedicineData(int page) {
        RequestParams params = new RequestParams();
        params.put("page", page);
        params.put("offset",offset);
        XCHttpAsyn.postAsyn(mActivity, AppConfig.getHostUrl(AppConfig.commonMedicationList), params,
                new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            List<XCJsonBean> data = result_bean.getList("data");
                            mXCMaterialListPinRefreshLayout.setTotalPage(data.get(0).getInt("totalPages")+"");
                            offset = data.get(0).getInt("offset");
                            nextPage = data.get(0).getInt("nextPage");
                            List<DrugBean> drugBeans = parseDrugBeanList(data.get(0).getList("result"));
                            mCommonMedicineList.addAll(drugBeans);
                            mXCMaterialListPinRefreshLayout.updateListAdd(drugBeans, mCommonMedicineAdapter);
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        if(mXCMaterialListPinRefreshLayout.base_currentPage ==1){
                            showNoNetLayout();
                        }
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        mXCMaterialListPinRefreshLayout.completeRefresh(result_boolean);
                        // 处理code操作
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(mActivity,
                                getCode(),
                                getMsg())) {
                        }
                    }

                });
    }

    /**
     * 解析药品集合
     *
     * @param xcJsonBeans
     * @return
     */
    private List<DrugBean> parseDrugBeanList(List<XCJsonBean> xcJsonBeans) {
        ArrayList<DrugBean> drugBeans = new ArrayList<>();
        Parse2DrugBean parse2DrugBean = new Parse2DrugBean();
        for (XCJsonBean xcJsonBean : xcJsonBeans) {
            DrugBean drugBean = parse2DrugBean.parse(new DrugBean(), xcJsonBean);
            drugBeans.add(drugBean);
        }
        return drugBeans;
    }

    /**
     * 刷新列表
     */
    public void updateUI(){
        mCommonMedicineAdapter.notifyDataSetChanged();
    }

    @Override
    public void delete(int position) {
        deleteCommonMedicine(position);
    }

    @Override
    public void addRecipe(int position) {
        // created by songxin,date：2018-01-09,about：saveInfo,begin
        BiUtil.saveBiInfo(XD_CommonMedicineFragment.class, "2", "128", "E00097","", false);
        // created by songxin,date：2018-01-09,about：saveInfo,end
        UsageActivityV2.launch(mActivity,mCommonMedicineList.get(position), CommonConfig.ALL_MEDICINE_FLAG_2);
    }

    @Override
    public void subRecipe(int position) {
        //移出处方笺
        RecomMedicineHelper.getInstance().removeDrugBean(mCommonMedicineList.get
                (position).getId());
        updateUI();
        mActivity.setMedicineNum();
    }

    @Override
    public void onItemClick(int position) {
        //进入药品详情
        UtilNativeHtml5.toJumpDrugDetail(mActivity, mCommonMedicineList.get(position).getId());
        DrugBean.drug_id = mCommonMedicineList.get(position).getId();
    }

}
