package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshScrollView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.modelflag.XL_PatientBasicBean;
import com.qlk.ymz.parse.Parse2PatientBasicBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.util.List;

public class WY_PatientBasicInfoActivity extends DBActivity {
    /**
     * titlebar
     */
    private XCTitleCommonLayout titlebar;
    /**
     * 婚姻状态
     */
    TextView xc_id_personbasicinfo_tv_marry;
    /**
     * 身高
     */
    TextView xc_id_personbasicinfo_tv_height;
    /**
     * 体重
     */
    TextView xc_id_personbasicinfo_tv_weight;
    /**
     * 过敏史
     */
    TextView xc_id_personbasicinfo_tv_allergy;
    /**
     * 疾病历史
     */
    TextView xc_id_personbasicinfo_tv_anamnesis;
    /**
     * 家庭病史
     */
    TextView xc_id_personbasicinfo_tv_family_history;
    /**
     * 遗传病史
     */
    TextView xc_id_personbasicinfo_tv_genetic_history;
    /**
     * 抽烟
     */
    TextView xc_id_personbasicinfo_tv_smoke;
    /**
     * 是否饮酒
     */
    TextView xc_id_personbasicinfo_tv_drink;
    /**
     * 上下啦刷新
     */
    public PullToRefreshScrollView pullToRefreshScrollView;
    /**
     * 患者id不可少哦
     */
    private String mPatientId = "";
    /**
     * 患者基本信息
     */
    private XL_PatientBasicBean petientBasicBeanFlag = new XL_PatientBasicBean();
    public static final String PATIENT_INFO = "patient_info";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_wy__patient_basic_info);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onStart() {
        super.onStart();
        //created by songxin,date：2017-9-26,about：bi,begin
        BiUtil.savePid(WY_PatientBasicInfoActivity.class);
        //created by songxin,date：2017-9-26,about：bi,end
        BiUtil.savePid(WY_PatientBasicInfoActivity.class);
        if (TextUtils.isEmpty(mPatientId)) {
            pullToRefreshScrollView.setMode(PullToRefreshBase.Mode.DISABLED);
        }
    }

    @Override
    public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "基本病情");
        titlebar.setTitleLeft(true, "");
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));

        if (getIntent() != null && getIntent().getExtras() != null
                && !TextUtils.isEmpty(getIntent().getExtras().getString(CommonConfig.PATIENT_ID))) {
            mPatientId = getIntent().getExtras().getString(CommonConfig.PATIENT_ID);
        }
        xc_id_personbasicinfo_tv_marry = getViewById(R.id.xc_id_personbasicinfo_tv_marry);
        xc_id_personbasicinfo_tv_height = getViewById(R.id.xc_id_personbasicinfo_tv_height);
        xc_id_personbasicinfo_tv_weight = getViewById(R.id.xc_id_personbasicinfo_tv_weight);
        xc_id_personbasicinfo_tv_allergy = getViewById(R.id.xc_id_personbasicinfo_tv_allergy);
        xc_id_personbasicinfo_tv_anamnesis = getViewById(R.id.xc_id_personbasicinfo_tv_anamnesis);
        xc_id_personbasicinfo_tv_family_history = getViewById(R.id.xc_id_personbasicinfo_tv_family_history);
        xc_id_personbasicinfo_tv_genetic_history = getViewById(R.id.xc_id_personbasicinfo_tv_genetic_history);
        xc_id_personbasicinfo_tv_smoke = getViewById(R.id.xc_id_personbasicinfo_tv_smoke);
        xc_id_personbasicinfo_tv_drink = getViewById(R.id.xc_id_personbasicinfo_tv_drink);
        pullToRefreshScrollView = getViewById(R.id.pullToRefreshScrollView);
        pullToRefreshScrollView.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
        xc_id_model_no_net = getViewById(R.id.xc_id_model_no_net);
        requestData();
    }

    @Override
    public void listeners() {
        titlebar.getXc_id_titlebar_left_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });
        pullToRefreshScrollView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                requestData();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {

            }
        });
    }

    @Override
    public void onNetRefresh() {
        requestData();
    }

    /**
     * 请求个人基本信息
     */
    private void requestData() {
        if (TextUtils.isEmpty(mPatientId)) {
            pullToRefreshScrollView.onRefreshComplete();
            return;
        }
        RequestParams params = new RequestParams();
        params.put("patientId", mPatientId);
        XCHttpAsyn.postAsyn(WY_PatientBasicInfoActivity.this, AppConfig.getHostUrl(AppConfig.patient_basic_disease), params, new XCHttpResponseHandler(this) {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    petientBasicBeanFlag = Parse2PatientBasicBean.parsePatientBasic(result_bean, false);
                    List<XCJsonBean> result_list = result_bean.getList(petientBasicBeanFlag.data);
                    showPatientInfo(result_list);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (pullToRefreshScrollView != null) {
                    pullToRefreshScrollView.onRefreshComplete();
                }

                // 对账户冻结情况的判断处理
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(WY_PatientBasicInfoActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }

        });
    }

    /**
     * 显示患者信息界面
     *
     * @param result_list 患者信息
     */
    private void showPatientInfo(List<XCJsonBean> result_list) {
        if (UtilCollection.isBlank(result_list)) {
            shortToast("数据错误!");
            return;
        }
        if (petientBasicBeanFlag != null) {
            String familyHistory = petientBasicBeanFlag.getFamilyHistory();
            if (!TextUtils.isEmpty(familyHistory)) {
                familyHistory = familyHistory.trim();
            }

            String smokeHistory = petientBasicBeanFlag.getSmokeHistory();
            if (!TextUtils.isEmpty(smokeHistory)) {
                smokeHistory = smokeHistory.trim();
            }

            String drinkHstory = petientBasicBeanFlag.getDrinkHstory();
            if (!TextUtils.isEmpty(drinkHstory)) {
                drinkHstory = drinkHstory.trim();
            }

            String pastDisease = petientBasicBeanFlag.getPastDisease();
            if (!TextUtils.isEmpty(pastDisease)) {
                pastDisease = pastDisease.trim();
            }

            // 身高
            String height = petientBasicBeanFlag.getHeight();
            if (!TextUtils.isEmpty(height)) {
                height = height.trim();
            }

            // 体重
            String weight = petientBasicBeanFlag.getWeight();
            if (!TextUtils.isEmpty(weight)) {
                weight = weight.trim();
            }

            String medicationAllergy = petientBasicBeanFlag.getMedicationAllergy();
            if (!TextUtils.isEmpty(medicationAllergy)) {
                medicationAllergy = medicationAllergy.trim();
            }

            String hereditaryDisease = petientBasicBeanFlag.getHereditaryDisease();
            if (!TextUtils.isEmpty(hereditaryDisease)) {
                hereditaryDisease = hereditaryDisease.trim();
            }

            String maritalStatus = petientBasicBeanFlag.getMaritalStatus();
            if ("0".equals(maritalStatus)) {
                xc_id_personbasicinfo_tv_marry.setText("未婚");
            } else if ("1".equals(maritalStatus)) {
                xc_id_personbasicinfo_tv_marry.setText("已婚");
            }
            xc_id_personbasicinfo_tv_height.setText(height);
            xc_id_personbasicinfo_tv_weight.setText(weight);
            xc_id_personbasicinfo_tv_allergy.setText(medicationAllergy);
            xc_id_personbasicinfo_tv_anamnesis.setText(pastDisease);
            xc_id_personbasicinfo_tv_drink.setText(drinkHstory);
            xc_id_personbasicinfo_tv_family_history.setText(familyHistory);
            xc_id_personbasicinfo_tv_genetic_history.setText(hereditaryDisease);
            xc_id_personbasicinfo_tv_smoke.setText(smokeHistory);
        }
    }
}
