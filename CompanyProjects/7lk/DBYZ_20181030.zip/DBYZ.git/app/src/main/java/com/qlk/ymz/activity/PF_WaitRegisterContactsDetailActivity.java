package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.PF_WaitRegisterContactsInfo;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.UtilAppToSystemApp;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.util.UtilString;


/**
 * 等待注册患者详情
 * @author zhangpengfei.
 * @version 2.5
 */
public class PF_WaitRegisterContactsDetailActivity extends DBActivity{
    /**联系人详情key*/
    public static final String CONTACTS_DETAIL = "contactsDetail";

    private XCTitleCommonLayout xc_id_model_titlebar;
    /**姓名*/
    private TextView pf_id_wait_register_contacts_detail_name;
    /**电话*/
    private TextView pf_id_wait_register_contacts_detail_phone;
    /**基本信息*/
    private RelativeLayout xl_patientinfo_rl_basic;
    /**病例档案*/
    private RelativeLayout xl_patientinfo_rl_record;

    private Intent intent;
    /**联系人信息*/
    private PF_WaitRegisterContactsInfo info = new PF_WaitRegisterContactsInfo();
    /**传到诊疗记录的model*/
    private XC_ChatModel chatModel = new XC_ChatModel();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 设置布局
        setContentView(R.layout.pf_activity_wait_register_contact_detail);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-6-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_WaitRegisterContactsDetailActivity.class);
    }

    /** created by songxin,date：2016-6-29,about：bi,end */

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "详细资料");
        xc_id_model_titlebar.setTitleLeft(true, "");
        xc_id_model_titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));

        pf_id_wait_register_contacts_detail_name = getViewById(R.id.pf_id_wait_register_contacts_detail_name);
        pf_id_wait_register_contacts_detail_phone = getViewById(R.id.pf_id_wait_register_contacts_detail_phone);
        xl_patientinfo_rl_basic = getViewById(R.id.xl_patientinfo_rl_basic);
        xl_patientinfo_rl_record = getViewById(R.id.xl_patientinfo_rl_record);
        if (null != getIntent()){
            info = (PF_WaitRegisterContactsInfo) getIntent().getSerializableExtra(CONTACTS_DETAIL);
            if (null != info){
                pf_id_wait_register_contacts_detail_name.setText(UtilString.f(info.getName()));
                pf_id_wait_register_contacts_detail_phone.setText(UtilString.f(info.getPhone()));
            }
        }
    }

    @Override
    public void listeners() {
        xl_patientinfo_rl_basic.setOnClickListener(this);
        xl_patientinfo_rl_record.setOnClickListener(this);
        pf_id_wait_register_contacts_detail_phone.setOnClickListener(this);
        xc_id_model_titlebar.getXc_id_titlebar_left_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch(v.getId()){
            // 基本信息
            case R.id.xl_patientinfo_rl_basic :
                intent = new Intent(this, WY_PatientBasicInfoActivity.class);
                myStartActivity(intent);
                break;
            // 病例档案
            case R.id.xl_patientinfo_rl_record :
                intent = new Intent(this, JS_MedicalRecordActivity.class);
                intent.putExtra(CommonConfig.PATIENT_ID, "");
                myStartActivity(intent);
                break;
            // 电话
            case R.id.pf_id_wait_register_contacts_detail_phone :
                UtilAppToSystemApp.toPhone(this, UtilString.f(info.getPhone()));
                break;
            default:

                break;

        }
    }
}
