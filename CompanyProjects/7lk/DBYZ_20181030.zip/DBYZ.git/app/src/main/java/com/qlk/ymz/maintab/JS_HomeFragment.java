package com.qlk.ymz.maintab;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.design.widget.AppBarLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.jude.rollviewpager.RollPagerView;
import com.jude.rollviewpager.hintview.IconHintView;
import com.loopj.android.http.RequestParams;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.LT_PublicityActivity;
import com.qlk.ymz.activity.PF_AdvertisementActivity;
import com.qlk.ymz.activity.PF_Html5UpdateActivity;
import com.qlk.ymz.activity.PF_PaActivity;
import com.qlk.ymz.activity.PF_SignInResultActivity;
import com.qlk.ymz.activity.SX_DisturbModeActivity;
import com.qlk.ymz.activity.XC_ChatDetailActivity;
import com.qlk.ymz.activity.XD_HomeMenuActivity;
import com.qlk.ymz.activity.XD_PharmacyActivity;
import com.qlk.ymz.activity.XD_ServiceChatActivity;
import com.qlk.ymz.activity.XD_SystemMessageActivity;
import com.qlk.ymz.adapter.PF_BannerAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.db.noticeRecord.NoticeRecordDB;
import com.qlk.ymz.db.noticeRecord.NoticeRecordModel;
import com.qlk.ymz.model.BannerInfoBean_V2;
import com.qlk.ymz.model.HomeBaseInfoBean;
import com.qlk.ymz.model.SystemMessageBean;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.parse.Parse2HomeInfoBean;
import com.qlk.ymz.receiver.XC_PushReceiver;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.SystemMessageUtil;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.NoticeView;
import com.qlk.ymz.view.SwipeLayout.SwipeRecyclerViewAdapter;
import com.qlk.ymz.view.upgrade.YR_UpgradeDialogActivity_v2;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

;

/**
 * 首页Fragment
 * @author 徐金山
 * @version 2.3.0
 */
public class JS_HomeFragment extends DBFragment implements View.OnClickListener{
    // ==========页面控件==========
    /** 滚动的头部控件*/
    private AppBarLayout appBar;
    /** 展开状态下toolbar显示的背景，遮罩层*/
    private View bg_open;
    /** 展开状态下toolbar显示的内容*/
    private View toolbarOpen;
    /** 展开状态下toolbar的遮罩层*/
    private View bgToolbarOpen;
    /** 收缩状态下toolbar显示的内容*/
    private View toolbarClose;
    /** 收缩状态下toolbar的遮罩层*/
    private View bgToolbarClose;

    /** 菜单控件*/
    private ImageView iv_menu_open;
    private ImageView iv_menu_close;
    /** 收起来时邀请患者布局*/
    private LinearLayout ll_invite_patient_close;
    /** 收起来时群发布局*/
    private LinearLayout ll_group_send_close;
    /** 收起来时宣教布局*/
    private LinearLayout ll_publicity_close;
    /** 收起来时我的药房布局*/
    private LinearLayout ll_pharmacy_close;
    /** 收起来时宣教小红点*/
    private ImageView iv_publicity_dot_close;

    /** 邀请患者布局*/
    private LinearLayout ll_invite_patient;
    /** 群发布局*/
    private LinearLayout ll_group_send;
    /** 宣教布局*/
    private RelativeLayout rl_publicity;
    /** 我的药房布局*/
    private LinearLayout ll_pharmacy;
    /** 宣教小红点*/
    private ImageView iv_publicity_dot;

    /** 页面内容布局 */
    private RecyclerView mRecyclerView;
    /** 播报控件*/
    private NoticeView nv_message;
    /** 更多*/
    private TextView tv_more;
    /** 更多小红点*/
    private ImageView iv_more_dot;
    /** banner控件 */
    private RollPagerView viewPagerLayout_banner;
    /** list头部的我的消息布局*/
    private TextView tv_message_title_list;
    /** 无咨询信息的显示视图 */
    private LinearLayout ll_noChatContent;

    /** 悬浮布局*/
    private TextView tv_message_title;

    // ==========适配数据==========
    /** 咨询列表数据适配器 */
    private SwipeRecyclerViewAdapter mSwipeRecyclerViewAdapter;
    /** 首页信息BEAN */
    private HomeBaseInfoBean homeBaseInfoBean = new HomeBaseInfoBean();
    /** banner适配器 */
    private PF_BannerAdapter bannerAdapter;
    /** banner数据 */
    private ArrayList<BannerInfoBean_V2> bannerInfoBean;

    // ==========变量==========
    /** 是否可以发起请求首页接口信息的标识（true：可以；false：不可以；默认值：true） */
    private static boolean refreshBannerInfoFlag = true;
    /**是否显示未认证对话框 默认显示*/
    private boolean isShowIdentyfyDialog = true;
    /** 当客户端收到认证状态的push消息后，发送广播，将所有需要更新的页面 */
    public static String  UPDATE_AUTHSTATUS_ACTION = "update.authstatus.action";
    /** 未读系统消息集合*/
    private List<SystemMessageBean> mSystemMessageBeanList;
    /** 轮播控件数据集*/
    private  List<String> notices = new ArrayList<>();
    /** 签到逻辑handler */
    private Handler signHandler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            // 签到逻辑判断
            if(checkSignIn()){
                // 请求自动签到接口
                requestAutoSign();
            }

        }
    };


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // add by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(JS_HomeFragment.class,"1","","","",false);
        // add by songxin,date：2016-4-25,about：saveInfo,end
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return init(inflater, R.layout.js_fragment_home);
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        processBiz();
    }

    /** 业务处理 */
    private void processBiz() {
        // 请求首页接口数据
        getHomeData(true);
        // 刷新咨询列表数据
        mSwipeRecyclerViewAdapter.notifyDataSetChanged();
        //设置未读系统消息的红点
        setNoticeUnReadNum();
    }

    /**
     * 设置未读系统消息的红点
     */
    private void setNoticeUnReadNum() {
        int sysMessageUnreadRecordCount = JS_ChatListDB.getInstance(getActivity(), UtilSP.getUserId()).getSysMessageUnreadRecordCount();
        if(UtilSP.isNoticeDot()&&sysMessageUnreadRecordCount>0){
            iv_more_dot.setVisibility(View.VISIBLE);
        }else {
            iv_more_dot.setVisibility(View.GONE);
        }
    }

    /**
     * 更新未读系统消息并轮播
     */
    private void updateNotice() {
        notices.clear();
        if(nv_message.getCurrentView()!=null){
            nv_message.getCurrentView().clearAnimation();
        }
        mSystemMessageBeanList = SystemMessageUtil.getSystemMessageList(UtilSP.getSystemMessage());
        if(UtilCollection.isBlank(mSystemMessageBeanList)){
            SystemMessageBean systemMessageBean = SystemMessageUtil.getSystemMessageBean(UtilSP.getLateTitle());
            if(systemMessageBean!=null){
                mSystemMessageBeanList.add(systemMessageBean);
            }
        }
        mSystemMessageBeanList = SystemMessageUtil.sort(mSystemMessageBeanList);//排序
        for(SystemMessageBean messageBean:mSystemMessageBeanList){
            notices.add(messageBean.getTitle());
        }
        nv_message.addNotice(notices);
        if(notices.size()>1&&!isHidden()){
            if(!nv_message.isFlipping()){
                startFlipping();
            }
        }else {
            nv_message.stopFlipping();
        }
    }

    public void onStart() {
        super.onStart();

        // add by songxin,date：2016-4-23,about：bi,begin
        // BI信息记录
        BiUtil.savePid(JS_HomeFragment.class);
        // add by songxin,date：2016-4-23,about：bi,end
    }

    public void onResume() {
        super.onResume();
        // banner开始自动轮播
        viewPagerLayout_banner.resume();
        // 是否刷新Banner信息
        refreshBannerInfo();
        // 更新咨询列表信息
        updateInfoListData();
        // 医生头像
        setDoctorHeadImg();
        //判断宣教红点是否显示  add by litao
        setJudgePublictyDot();
    }

    public void onPause() {
        super.onPause();
        nv_message.stopFlipping();//停止轮播
        if(nv_message.getCurrentView()!=null){
            nv_message.getCurrentView().clearAnimation();
        }

    }

    /** 刷新首页Banner显示 */
    public void refreshBannerInfo() {
        // 请求首页接口数据
        getHomeData(false);
    }

    public boolean isBodyFragment() {
        return true;
    }

    public void initWidgets() {
        appBar = getViewById(R.id.app_bar);
        bg_open = getViewById(R.id.bg_open);
        toolbarOpen = getViewById(R.id.include_toolbar_open);
        bgToolbarOpen = getViewById(R.id.bg_title_open);
        toolbarClose = getViewById(R.id.include_toolbar_close);
        bgToolbarClose = getViewById(R.id.bg_title_close);

        iv_menu_close = getViewById(R.id.iv_menu_close);
        iv_menu_open = getViewById(R.id.iv_menu_open);

        ll_group_send = getViewById(R.id.ll_group_send);
        ll_invite_patient = getViewById(R.id.ll_invite_patient);
        rl_publicity = getViewById(R.id.rl_publicity);
        ll_pharmacy = getViewById(R.id.ll_pharmacy);
        iv_publicity_dot = getViewById(R.id.iv_publicity_dot);

        ll_group_send_close = getViewById(R.id.ll_group_send_close);
        ll_invite_patient_close = getViewById(R.id.ll_invite_patient_close);
        ll_publicity_close = getViewById(R.id.ll_publicity_close);
        ll_pharmacy_close = getViewById(R.id.ll_pharmacy_close);
        iv_publicity_dot_close = getViewById(R.id.iv_publicity_dot_close);

        tv_message_title = getViewById(R.id.tv_message_title);

        mRecyclerView = getViewById(R.id.rv_content);
        mRecyclerView.setHasFixedSize(true);
        //设置recyclerview的布局方式
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        View home_rv_head = LayoutInflater.from(getActivity()).inflate(R.layout.home_rv_head, mRecyclerView,false);
        tv_more = home_rv_head.findViewById(R.id.tv_more);
        iv_more_dot =  home_rv_head.findViewById(R.id.iv_more_dot);
        nv_message = home_rv_head.findViewById(R.id.nv_message); //// 快报控件
        viewPagerLayout_banner = home_rv_head.findViewById(R.id.viewPagerLayout_banner); // banner控件
        tv_message_title_list = home_rv_head.findViewById(R.id.tv_message_title_list); // 我的消息
        ll_noChatContent = home_rv_head.findViewById(R.id.ll_noChatContent); // 无咨询信息的显示视图

        //初始化适配器
        int itemWidth = UtilScreen.getScreenWidthPx(getContext()) - UtilScreen.dip2px(getContext(), 20);
        mSwipeRecyclerViewAdapter = new SwipeRecyclerViewAdapter(getActivity(),itemWidth,itemWidth, getLocalContactsMessageList());
        mSwipeRecyclerViewAdapter.addHeadView(home_rv_head);
        mSwipeRecyclerViewAdapter.setHomeChatListActionProcess(new SwipeRecyclerViewAdapter.HomeChatListActionProcess() {
            // “内容区”布局点击事件的处理
            public void contentLayoutActionProcess(View v, JS_ChatListModel chatListModel) {
                if (null != chatListModel) {
                    String recoder_click_patient_id = chatListModel.getUserPatient().getPatientId();
                    // 更新列表中点击的item的未读数量为0，以及更新首页咨询上的那个红点的本地存储的数量
                    updatePatientChatListUnReadNum2Zero(chatListModel);
                    //add by cyr on 2016-7-22 更新“首页频道icon”上的气泡值: 修复进入聊天页快速返回后，底部气泡数量不减少的bug
                    ((JS_MainActivity)getActivity()).setUnreadRecordCount();

                    // 显示公告通知页面
                    if(JS_ChatListModel.NOTICE_ID.equals(recoder_click_patient_id)) {
                        String targetUrl = chatListModel.getLinkUrl();
                        if(TextUtils.isEmpty(targetUrl)) {
                            targetUrl = "";
                        }
                        NativeHtml5.newInstance((JS_MainActivity) getActivity()).webToAppPage(targetUrl);

                        // 清除“系统类”通知
                        XC_PushReceiver.clearAPSButChat(getActivity());
                    }
                    // 显示系统通知页面
                    else if(JS_ChatListModel.ACCOUNT_ID.equals(recoder_click_patient_id)) {
                        myStartActivity(PF_PaActivity.class);

                        // 清除“系统类”通知
                        XC_PushReceiver.clearAPSButChat(getActivity());
                    }
                    // add by tengfei 显示客服聊天详情
                    else
                    if(JS_ChatListModel.SERVICE_ID.equals(recoder_click_patient_id)){
                            myStartActivity(new Intent(getActivity(),XD_ServiceChatActivity.class));
                    }
                    // 显示聊天详情页面，update by 崔毅然 on 2016-8-11  修复当sessionid为空时进入聊天页请求异常的bug
                    else {
                        if (chatListModel != null && !TextUtils.isEmpty(chatListModel.getUserPatient().getPatientId())) {
                            if (!TextUtils.isEmpty(chatListModel.getSessionId())) {
                                myStartActivity(XC_ChatDetailActivity.class, new String[]{CommonConfig.CHAT_PARAMS_MODEL}, new Object[]{chatListModel});
                            } else {//当sessionid为空时重新请求下接口
                                UtilChat.launchChatDetail((DBActivity) getActivity(), chatListModel.getUserPatient().getPatientId(), null);
                            }
                        }
                    }
                }
            }

            // “置顶/取消置顶”按钮点击事件的处理
            public void topBtnActionProcess(View v, JS_ChatListModel chatListModel) {
                if(!"0".equals(chatListModel.getTopSortTime())){
                    chatListModel.setTopSortTime("0");
                    JS_ChatListDB.getInstance(getActivity(), UtilSP.getUserId()).setTopStatusOrSilentStatus(chatListModel);
                }else {
                    chatListModel.setTopSortTime(System.currentTimeMillis() + "");
                    JS_ChatListDB.getInstance(getActivity(), UtilSP.getUserId()).setTopStatusOrSilentStatus(chatListModel);
                }
                updateInfoListData();
            }

            // “免打扰/取消免打扰”按钮点击事件的处理
            public void noDisturbingBtnActionProcess(View v, JS_ChatListModel chatListModel) {
                if("0".equals(chatListModel.getUserPatient().getIsShield())){ // 消息提醒屏蔽标示（说明：0:不屏蔽，1:屏蔽）
                    // 取消免打扰
                    requestShieldSet(chatListModel, "1");
                }else {
                    // 开启免打扰
                    requestShieldSet(chatListModel, "0");
                }
            }

            // “删除”按钮点击事件的处理
            public void deleteBtnActionProcess(View v, JS_ChatListModel chatListModel) {
                // 删除记录
                JS_ChatListDB.getInstance(getActivity(), UtilSP.getUserId()).removeRecord(chatListModel);
                Toast.makeText(getActivity(), "删除成功", Toast.LENGTH_SHORT).show();

                // 清除“草稿”内容
//                RoughDraftUtils.putRoughtDraft(chatListModel.getUserPatient().getPatientId(),"");


                // 更新“首页频道icon”上的气泡值
                ((JS_MainActivity)getActivity()).setUnreadRecordCount();

                // 刷新咨询列表的信息
                updateInfoListData();
                //------------zhangpengfei 1016-05-11 add------------
                //更新公告操作信息,为了在下次进入的时候刷新公告信息
                if ((XC_ChatModel.MSG_SENDER_TYPE_PUB_NOTICE + "").equals(chatListModel.getSender())){
                    NoticeRecordModel model = new NoticeRecordModel();
                    model.setState(NoticeRecordModel.NOTICE_RECORE_DELETE);
                    model.setTopic(chatListModel.getTopic());
                    model.setDoctorSelfId(UtilSP.getUserId());
                    NoticeRecordDB.getInstance(getActivity()).updateNoticeState(model);
                }
                //------------zhangpengfei 1016-05-11 end------------
            }
        });
        mRecyclerView.setAdapter(mSwipeRecyclerViewAdapter);

        // 初始化banner控件
        initBannerView();

        getViewById(R.id.xc_id_model_no_net_main).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // 判断手机操作系统的版本（API大于10就是SDK3.0或以上版本）
                if(android.os.Build.VERSION.SDK_INT > 10) {
                    // 3.0以上打开设置界面，也可以直接用ACTION_WIRELESS_SETTINGS打开到wifi界面
                    startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
                } else {
                    startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS));
                }
            }
        });
        //判断宣教红点是否显示  add by litao
        setJudgePublictyDot();

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            /*case R.id.imageView_disturbmode: //点击“勿扰icon”的监听
                // add by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(JS_HomeFragment.class, "2", "128", "ll_setDisturbMode","", false);
                // add by songxin,date：2016-4-25,about：saveInfo,end

                myStartActivity(SX_DisturbModeActivity.class);
                break;
            case R.id.imageView_doctorIcon: //点击“医生头像”的监听
                // add by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(JS_HomeFragment.class, "2", "128", "imageView_doctorIcon","", false);
                // add by songxin,date：2016-4-25,about：saveInfo,end

                // 显示个人资料页
                myStartActivity(YY_PersonalDataActivityV2.class);
                break;*/
            case R.id.ll_invite_patient: //邀请患者
                // add by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(JS_HomeFragment.class, "2", "128", "rel_invitePatient","", false);
                // add by songxin,date：2016-4-25,about：saveInfo,end

                UtilNativeHtml5.toJumpQRcode(getActivity(), "0");
                break;
            case R.id.ll_pharmacy: //我的药房
                RecomMedicineHelper.getInstance().setFlag("1");
                RecomMedicineHelper.getInstance().setXC_patientDrugInfo(new XC_PatientDrugInfo());
                myStartActivity(XD_PharmacyActivity.class);
                break;
            case R.id.rl_publicity: //宣教
                GlobalConfigSP.setHomePublictyDot("0");
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(JS_HomeFragment.class, "2", "128", "ll_missionary","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end
                Intent intent1 = new Intent(getActivity(),LT_PublicityActivity.class);
                intent1.putExtra(LT_PublicityActivity.PUBLICITY_EDUCATION_INTENTCODE, 0);
                myStartActivity(intent1);
                break;
            case R.id.ll_group_send: //群发
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(JS_HomeFragment.class, "2", "128", "ll_groupSend","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end
                ToJumpHelp.toJumpNewGroupSendActivity(getActivity(),null);
                break;
            case R.id.ll_invite_patient_close: //邀请患者（收起时）
                ll_invite_patient.performClick();
                break;
            case R.id.ll_pharmacy_close: //我的药房（收起时）
                ll_pharmacy.performClick();
                break;
            case R.id.ll_publicity_close: //宣教（收起时）
                rl_publicity.performClick();
                break;
            case R.id.ll_group_send_close: //群发（收起时）
                ll_group_send.performClick();
                break;
            case R.id.iv_menu_close:
            case R.id.iv_menu_open:
                //首页菜单页
                startActivity(new Intent(getActivity(),XD_HomeMenuActivity.class));
                break;
            case R.id.tv_more:
                //更多进入系统消息页
                UtilSP.setNoticeDot(false);
                myStartActivity(XD_SystemMessageActivity.class);
                break;
            default:
                break;
        }

    }

    public void listeners() {
        //公告轮播控件设置点击监听
        nv_message.setOnNoticeClickListener(new NoticeView.OnNoticeClickListener() {
            @Override
            public void onNotieClick(int position, String notice) {
                String noticeType = mSystemMessageBeanList.get(position).getNoticeType();
                SystemMessageUtil.deleteSystemMessage(noticeType);
                myStartActivity(XD_SystemMessageActivity.class);
                if("4".equals(noticeType)){
                    JS_ChatListDB.getInstance(getActivity(),UtilSP.getUserId()).setUnReadMessageNum2Zero(JS_ChatListModel.ACCOUNT_ID);
                    myStartActivity(PF_PaActivity.class);
                }else {
                    JS_ChatListDB.getInstance(getActivity(),UtilSP.getUserId()).setNoticeUnReadMessageNum2Zero(noticeType);
                    String targetUrl = mSystemMessageBeanList.get(position).getLinkUrl();
                    if(TextUtils.isEmpty(targetUrl)) {
                        targetUrl = "";
                    }
                    NativeHtml5.newInstance((JS_MainActivity)getActivity()).webToAppPage(targetUrl);
                }
                UtilSP.setNoticeDot(false);
                // 清除“系统类”通知
                XC_PushReceiver.clearAPSButChat(getActivity());
            }
        });
        //设置滚动监听  当到一定位置我的消息悬浮
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int[] location = new int[2];
                tv_message_title_list.getLocationOnScreen(location);
                if(location[1]<=getStatusHeight()+dip2px(getContext(),54)){
                    tv_message_title.setVisibility(View.VISIBLE);
                }else {
                    tv_message_title.setVisibility(View.GONE);
                }
            }
        });
        appBar.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                //垂直方向偏移量
                int offset = Math.abs(verticalOffset);
                //最大偏移距离
                int scrollRange = appBarLayout.getTotalScrollRange();
                if (offset <= scrollRange / 2) {//当滑动没超过一半，展开状态下toolbar显示内容，根据收缩位置，改变透明值
                    toolbarOpen.setVisibility(View.VISIBLE);
                    toolbarClose.setVisibility(View.GONE);
                    //根据偏移百分比 计算透明值
                    float scale2 = (float) offset / (scrollRange / 2);
                    int alpha2 = (int) (255 * scale2);
                    bgToolbarOpen.setBackgroundColor(Color.argb(alpha2, 255, 255, 255));
                } else {//当滑动超过一半，收缩状态下toolbar显示内容，根据收缩位置，改变透明值
                    toolbarClose.setVisibility(View.VISIBLE);
                    toolbarOpen.setVisibility(View.GONE);
                    float scale3 = (float) (scrollRange  - offset) / (scrollRange / 2);
                    int alpha3 = (int) (255 * scale3);
                    bgToolbarClose.setBackgroundColor(Color.argb(alpha3, 255, 255, 255));
                }
                //根据偏移百分比计算邀请患者这块布局的透明度值
                float scale = (float) offset / scrollRange;
                int alpha = (int) (255 * scale);
                bg_open.setBackgroundColor(Color.argb(alpha, 255, 255, 255));
            }
        });

        tv_more.setOnClickListener(this);

        iv_menu_open.setOnClickListener(this);
        iv_menu_close.setOnClickListener(this);
        ll_invite_patient.setOnClickListener(this);
        ll_group_send.setOnClickListener(this);
        rl_publicity.setOnClickListener(this);
        ll_pharmacy.setOnClickListener(this);

        ll_group_send_close.setOnClickListener(this);
        ll_pharmacy_close.setOnClickListener(this);
        ll_publicity_close.setOnClickListener(this);
        ll_invite_patient_close.setOnClickListener(this);

    }

    /**
     * 点击后，更新患者的未读信息数为“0”
     * @param chatListModel 咨询信息对象
     */
    private void updatePatientChatListUnReadNum2Zero(JS_ChatListModel chatListModel) {
        JS_ChatListDB.getInstance(getActivity(), UtilSP.getUserId()).setUnReadMessageNum2Zero(chatListModel);
    }

    /**
     * 获取消息列表，以及每个患者未读消息数量，以及更新首页的总的未读消息数量
     * @return 总记录集
     */
    public ArrayList<JS_ChatListModel> getLocalContactsMessageList() {
        ArrayList<JS_ChatListModel> chatListModelList;
        // 获取所有记录
        chatListModelList = JS_ChatListDB.getInstance(getActivity(), UtilSP.getUserId()).getImRecord();
        return chatListModelList;
    }

    /**
     * 更新咨询列表数据并进行重新适配处理
     */
    public void updateInfoListData() {
        ArrayList<JS_ChatListModel> chatListModelList = getLocalContactsMessageList();
        mSwipeRecyclerViewAdapter.update(chatListModelList);
        // 若咨询记录数为0，则显示“无咨询信息的显示视图”，否则不显示
        if(chatListModelList.size() == 0) {
            tv_message_title_list.setVisibility(View.GONE);
            ll_noChatContent.setVisibility(View.VISIBLE);
        }else {
            tv_message_title_list.setVisibility(View.VISIBLE);
            ll_noChatContent.setVisibility(View.GONE);
        }
        mSwipeRecyclerViewAdapter.notifyDataSetChanged();
        updateNotice();
        setNoticeUnReadNum();
    }

    /**
     * 设置医生头像及认证状态
     */
    public void setDoctorHeadImg() {
        // 如果医生的认证状态为“已认证”，则显示医生上传的头像
        String doctorAuthenticationStatus = UtilSP.getAuthStatus();
        // 认证状态
        showAuthShowIcon();
    }

    /**
     * 请求设置屏蔽接口
     * @param bean 业务bean
     * @param operate 是否开启屏蔽的标识（"0":取消；"1":开启）
     */
    public void requestShieldSet(final JS_ChatListModel bean, final String operate) {
        RequestParams params = new RequestParams();
        params.put("shieldId", bean.getUserPatient().getPatientId());
        params.put("operate",operate);
        XCHttpAsyn.postAsyn(getActivity(), AppConfig.getChatUrl(AppConfig.shieldSet),params,new XCHttpResponseHandler(){
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){
                    bean.getUserPatient().setIsShield(operate);
                    JS_ChatListDB.getInstance(context, UtilSP.getUserId()).setTopStatusOrSilentStatus(bean);

                    // "0": 取消  "1":开启
                    if("0".equals(operate)) {
                        Toast.makeText(context, "已取消免打扰", Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(context, "已开启免打扰", Toast.LENGTH_SHORT).show();
                    }
                    updateInfoListData();
                }
            }
        });
    }

    /***
     * 判断宣教红点是否显示
     */
    public void setJudgePublictyDot(){
        //判断宣教红点是否显示   0表示无 1表示有
        if("0".equals(GlobalConfigSP.getHomePublictyDot())){
            iv_publicity_dot.setVisibility(View.GONE);
            iv_publicity_dot_close.setVisibility(View.GONE);
        }else{
            iv_publicity_dot.setVisibility(View.VISIBLE);
            iv_publicity_dot_close.setVisibility(View.VISIBLE);
        }
    }

    /**
     * add by cyr on 2016-4-18
     * 根据时间判断当前
     * 时间格式  {"beginTime":"00:00","endTime":"17:00"}
     * @return  true 勿扰中 ; false 没有设置勿扰或不在勿扰时间内
     */
    public boolean getDisturbStatus() {
        String beginTime = UtilSP.getDistrubBeginTime();
        String endTime = UtilSP.getDistrubEndTime();
        if (!UtilSP.getDistrubSetting()|| TextUtils.isEmpty(beginTime) || TextUtils.isEmpty(endTime)) {
            return false;
        }
        // 获得 "yyyy-MM-dd"格式的当前时间字符串
        String todayStr = DateUtils.getTime(DateUtils.FORMAT_YYYYMMDD_STRIPING);
        if ( TextUtils.isEmpty(todayStr)) {
            return false;
        }
        // 根据今天的日期，拼接开始时间的long值
        long begin = DateUtils.dateToLong(todayStr + " " + beginTime,
                DateUtils.FORMAT_YYYYMMDD_STRIPING + " HH" + SX_DisturbModeActivity.RISK + "mm");
        // 根据今天的日期，拼接结束时间的long值
        long end = DateUtils.dateToLong(todayStr + " " + endTime,
                DateUtils.FORMAT_YYYYMMDD_STRIPING + " HH" + SX_DisturbModeActivity.RISK + "mm");
        // 获得当前时间的long值
        long thisTime = new Date().getTime();

        // 当前时间和开始、结束时间比较
        boolean status = false;
        if (begin > end) {
            if (thisTime < end || thisTime >= begin)
                status = true;
        } else if (begin < end) {
            if (thisTime < end && thisTime >= begin)
                status = true;
        }
        return status;
    }

    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        // 底部tab切换显示后调用
        if (!hidden) {
            UtilSP.setDelFrom(JS_MainActivity.TAB_HOME);
        }
        if(notices.size()>1&&!isHidden()){
            if(!nv_message.isFlipping()){
                nv_message.startFlipping();
            }
        }else {
            if(nv_message.getCurrentView()!=null){
                nv_message.getCurrentView().clearAnimation();
            }
            nv_message.stopFlipping();
        }
    }

    /**
     * 该方法用于判断是否可以进行签到逻辑，若返回false，则不能请求签到接口，不能弹出签到窗口
     *
     * 判断逻辑如符合以下任何一条则返回false，否则为true ：
     * 不是阳光化医生
     * 若日期小于等于今天
     * 或html5升级页正在显示
     * 或app升级页正在显示
     * 或新手引导正在显示
     * 或去认证页正在显示
     *
     * @return true 可以，false 不可以, 默认 true
     */
    public boolean checkSignIn(){
        boolean result = true;

        try {

            if (null == getBaseActivity()) {
                result = false;
            }

            String date = UtilDate.getNow(UtilDate.FORMAT_yyyyMMdd);

            if(Integer.parseInt(date) <= Integer.parseInt(UtilSP.getSignAuto())
                    || !"2".equals(UtilSP.getDoctorSunshine())
                    || XCApplication.isActivityTop(PF_Html5UpdateActivity.class)
                    || XCApplication.isActivityTop(YR_UpgradeDialogActivity_v2.class)
                    || XCApplication.isActivityExist(PF_AdvertisementActivity.class)
                    || ((JS_MainActivity)getActivity()).identifyDialogIsShow()
                    || !isShowIdentyfyDialog
                    || ((JS_MainActivity)getActivity()).isShowRecommendDialog
                    ) {

                result = false;
                // 保存当天日期，表示当天已经不能签到
                UtilSP.setSignAuto(date);
            }
            // 不是通过登录页启动首页 并且 不是通过h5升级页启动首页
            if(!JS_MainActivity.FROM_LOGIN.equals(getActivity().getIntent().getStringExtra(JS_MainActivity.FROM_PAGE))
                    && !JS_MainActivity.FROM_H5UPDATE.equals(getActivity().getIntent().getStringExtra(JS_MainActivity.FROM_PAGE))){
                result = false;
            }
            // 判断首页是被创建的还是重新打开的
            if(!((JS_MainActivity)getActivity()).isCreate()){
                result = false;
            }

        }catch (Exception e){
            e.printStackTrace();
            result = false;
        }

        return result;

    }

    /**
     * dp转px的工具方法
     * @param context 上下文对象
     * @param dipValue dp值
     * @return dp值对应的px值
     */
    public int dip2px(Context context, float dipValue) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (scale * dipValue + 0.5f);
    }

    /**
     * 请求首页接口数据
     * @param isShowDialog 是否显示网络加载的dialog（true：显示；false：不显示）
     */
    public void getHomeData(boolean isShowDialog) {
            if(refreshBannerInfoFlag) {
            refreshBannerInfoFlag = false;

            // 发送接口请求获取首页数据
            XCHttpAsyn.postAsyn(isShowDialog, getActivity(), AppConfig.getHostUrl(AppConfig.INDEX_BASE_INFO),  new RequestParams(), new XCHttpResponseHandler() {
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if (result_boolean) {
                        Parse2HomeInfoBean.parse(result_bean,homeBaseInfoBean);
                    }
                    if(UtilCollection.isBlank(SystemMessageUtil.getSystemMessageList(UtilSP.getSystemMessage()))){//无轮播消息时
                        updateNotice();
                    }
                    setData2Views();
                }

                // 对账户冻结情况的判断处理
                public void onFinish() {
                    super.onFinish();
                    if (null != result_bean && GeneralReqExceptionProcess.checkCode(getActivity(),
                            getCode(),
                            getMsg())) {
                        // 接口请求业务成功时的处理
                    }
                    refreshBannerInfoFlag = true;
                }
            });
        }
    }

    /**
     * 请求自动签到接口
     */
    public void requestAutoSign(){
        // 发送自动签到请求
        XCHttpAsyn.postAsyn(false,getActivity(),AppConfig.getHostUrl(AppConfig.oneKeySign),new RequestParams(),new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){

                    if(!checkSignIn()){
                        // 保存当天日期，表示当天已经不能签到
                        UtilSP.setSignAuto(UtilDate.getNow(UtilDate.FORMAT_yyyyMMdd));
                        return;
                    }

                    try {

                        String signPoint = result_bean.getList("data").get(0).getString("signPoint");

                        if(Integer.parseInt(signPoint) > 0){
                            PF_SignInResultActivity.launch(getActivity(),signPoint,PF_SignInResultActivity.AUTO);
                            // 保存签到日期
                            UtilSP.setSignToday(System.currentTimeMillis() + "");
//                            iv_sign_btn.clearAnimation();
                        }
                        //自动签到日期
                        UtilSP.setSignAuto(UtilDate.getNow(UtilDate.FORMAT_yyyyMMdd));
                    }catch (Exception e){e.printStackTrace();}
                }

            }
        });
    }

    /**
     * 将数据设置到页面控件上
     */
    public void setData2Views() {
        //-------------默认显示未认证对话框 zhangpengfei 2016-06-30 add-------------
        isShowIdentyfyDialog = true;
        //-------------zhangpengfei 2016-06-30 end-------------
        // 刷新banner数据
        bannerAdapter.setBannerInfoBean(homeBaseInfoBean.getBannerArrayList());
        if(UtilCollection.isBlank(homeBaseInfoBean.getBannerArrayList())){
            viewPagerLayout_banner.setVisibility(View.GONE);
        }else {
            viewPagerLayout_banner.setVisibility(View.VISIBLE);
        }
        // 医生的头像及认证状态icon
        setDoctorHeadImg();
        // 显示浮层图片
        if(null != homeBaseInfoBean.getLayerArrayList() && homeBaseInfoBean.getLayerArrayList().size() > 0) {
            String imgUrl = homeBaseInfoBean.getLayerArrayList().get(0).getImageUrl();
            String imageId = homeBaseInfoBean.getLayerArrayList().get(0).getVersionCode();
            // 浮层图片是否被看过的标识（true：看过；false：没看过；默认值：false）
            boolean lookedFlag = GlobalConfigSP.getLookedLayerCode().equals(imageId);
            //-----------zhangpengfei 2016-06-30 update-------------------
            // 当浮层图片没被看过时，才进行显示
            if(!UtilString.isBlank(imgUrl) && !lookedFlag && !UtilString.isBlank(imageId)) {
                isShowIdentyfyDialog = false; //有广告图不显示未认证对话框
                XCApplication.base_imageloader.loadImage(imgUrl, XCImageLoaderHelper.getDisplayImageOptions(), new ImageLoadingListener() {
                    public void onLoadingStarted(String s, View view) {
                    }

                    public void onLoadingFailed(String s, View view, FailReason failReason) {
                    }

                    public void onLoadingComplete(String s, View view, Bitmap bitmap) {
                        //如果当前有h5升级和app升级界面,就不弹出浮层
                        if (null != getBaseActivity()
                                && !XCApplication.isActivityTop(PF_Html5UpdateActivity.class)
                                && !XCApplication.isActivityExist(YR_UpgradeDialogActivity_v2.class)
                                ){
                            PF_AdvertisementActivity.launch(getActivity(), homeBaseInfoBean.getLayerArrayList().get(0));
                        }
                    }

                    public void onLoadingCancelled(String s, View view) {
                    }
                });
            }
        }
        if(getActivity() != null && isShowIdentyfyDialog){
            ((JS_MainActivity)getActivity()).showAuthDialog(signHandler);
        }
        //-----------zhangpengfei 2016-06-30 end-------------------


    }
    //-------------zhangpengfei 2016-05-10 add-----------
    /**
     * 初始化banner
     */
    private void initBannerView() {
        //初始化数据
        bannerInfoBean = new ArrayList<>();
        bannerAdapter = new PF_BannerAdapter(getActivity(), viewPagerLayout_banner, bannerInfoBean);
        //设置时间间隔
        viewPagerLayout_banner.setPlayDelay(4000);
        //设置过场动画时间
        viewPagerLayout_banner.setAnimationDurtion(500);
        viewPagerLayout_banner.setAdapter(bannerAdapter);
        //设置指示器颜色
        viewPagerLayout_banner.setHintView(new IconHintView(getActivity(), R.mipmap.vp_focus, R.mipmap.vp_unfocus, UtilScreen.dip2px(getActivity(), 30)));
        // banner停止自动轮播
        viewPagerLayout_banner.pause();
        if(UtilCollection.isBlank(bannerInfoBean)){
            viewPagerLayout_banner.setVisibility(View.GONE);
        }else {
            viewPagerLayout_banner.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 医生的认证状态icon显示的判断处理
     */
    private void showAuthShowIcon() {
        String authStatus = UtilSP.getAuthStatus();
        if (getActivity() != null){//add by cyr on 2016/7/14 修复退出登录时空指针闪退的bug
            getActivity().sendBroadcast(new Intent(UPDATE_AUTHSTATUS_ACTION));
        }
    }

    /**
     * 获取状态栏高度
     * @return
     */
    public int getStatusHeight(){
        DisplayMetrics dm = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
        //应用区域
        Rect outRect1 = new Rect();
        getActivity().getWindow().getDecorView().getWindowVisibleDisplayFrame(outRect1);
        int statusBar = dm.heightPixels - outRect1.height();
        return statusBar;
    }

    /**
     * 开始公告轮播
     */
    private void startFlipping(){
        try {
            Field userPresent = ViewFlipper.class.getDeclaredField("mUserPresent");
            userPresent.setAccessible(true);
            userPresent.set(nv_message, true);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        nv_message.startFlipping();
    }

}
