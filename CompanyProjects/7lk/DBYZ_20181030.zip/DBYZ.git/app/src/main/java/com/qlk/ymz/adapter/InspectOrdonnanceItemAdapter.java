package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.ExamineBean;
import com.qlk.ymz.util.ViewHolder;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;

import java.util.List;

/**
 * 推荐检查单-检查项目
 *
 * @author WuPuquan WangYong
 * @version 1.0
 */
public class InspectOrdonnanceItemAdapter extends XCBaseAdapter {
    private Context mContext;
    private List<ExamineBean> mList;
    private LayoutInflater mInflater;
    private boolean isShowDelete;

    public InspectOrdonnanceItemAdapter(Context context, List<ExamineBean> list) {
        super(context, list);
        this.mContext = context;
        this.mList = list;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.item_inspect_ordonnance, parent, false);
        }
        TextView tv_inspect_name = ViewHolder.get(convertView, R.id.tv_inspect_name);
        TextView iv_delete = ViewHolder.get(convertView, R.id.iv_delete);
        tv_inspect_name.setText((position + 1) + "、" + mList.get(position).getName());
        iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mOnInspectItemListener.onItemDeleted(position);
            }
        });
        if (isShowDelete) {
            iv_delete.setVisibility(View.VISIBLE);
        } else {
            iv_delete.setVisibility(View.GONE);
        }
        return convertView;
    }

    public void showDelete() {
        isShowDelete = true;
        notifyDataSetChanged();
    }

    public void hideDelete() {
        isShowDelete = false;
        notifyDataSetChanged();
    }

    public interface OnInspectItemListener {
        /**
         * 删除
         */
        void onItemDeleted(int pos);
    }

    private OnInspectItemListener mOnInspectItemListener;

    public void setOnInspectItemListener(OnInspectItemListener onInspectItemListener) {
        this.mOnInspectItemListener = onInspectItemListener;
    }
}
