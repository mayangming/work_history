package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.hyphenate.easeui.controller.EaseUI;
import com.qlk.ymz.BuildConfig;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.fragment.XD_ServiceChatFragment;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.util.qlkserivce.QlkServiceConstant;

/**
 * Created by xiedongtd on 2016/7/8.
 * 客服聊天界面
 */
public class XD_ServiceChatActivity extends DBActivity {

    public static XD_ServiceChatActivity activityInstance;
    private XD_ServiceChatFragment chatFragment;
    //聊天人群或者ID 在客服功能中为客服的IM服务号
    String toChatUsername;
    protected InputMethodManager inputMethodManager;
    private String tag;
    /**
     * 用于区别如果是当前正在聊天的用户且在前台
     */
    public static boolean isShowing;

    @Override
    protected void onCreate(Bundle arg0) {
        setContentView(R.layout.xd_activity_service_chat);
        super.onCreate(arg0);
        //http://stackoverflow.com/questions/4341600/how-to-prevent-multiple-instances-of-an-activity-when-it-is-launched-with-differ/
        // should be in launcher activity, but all app use this can avoid the problem
        if (!isTaskRoot()) {
            Intent intent = getIntent();
            String action = intent.getAction();
            if (intent.hasCategory(Intent.CATEGORY_LAUNCHER) && action.equals(Intent.ACTION_MAIN)) {
                finish();
                return;
            }
        }
        inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        activityInstance = this;
        toChatUsername = QlkServiceConstant.DEFAULT_COSTOMER_ACCOUNT + BuildConfig.DOCTORASSTANTKEY;
        // 可以直接new EaseChatFratFragment使用
        chatFragment = new XD_ServiceChatFragment();
        Intent intent = getIntent();
        intent.putExtra(QlkServiceConstant.EXTRA_USER_ID, toChatUsername);
        intent.putExtra(QlkServiceConstant.EXTRA_SHOW_USERNICK, true);
        tag = intent.getStringExtra(JS_MainActivity.TAB_TAG);
        // 传入参数
        chatFragment.setArguments(intent.getExtras());
        getSupportFragmentManager().beginTransaction().add(R.id.container, chatFragment).commit();
    }

    @Override
    protected void onStart() {
        super.onStart();
        UtilSP.putDoctorAsstantNum(0);
        // created by songxin,date：2018-10-29,about：bi,begin
        BiUtil.savePid(XD_ServiceChatActivity.class);
        // created by songxin,date：2018-10-29,about：bi,end
    }

    @Override
    public void initWidgets() {

    }

    @Override
    public void listeners() {

    }

    public void hideSoftKeyboard() {
        if (getCurrentFocus() != null) {
            if (getCurrentFocus().getWindowToken() != null) {
                // 先隐藏键盘
                inputMethodManager.hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }

    /**
     * back
     *
     * @param view
     */
    public void back(View view) {
        hideSoftKeyboard();
        finish();
    }

    @Override
    protected void onResume() {
        // cancel the notification
        EaseUI.getInstance().getNotifier().reset();
        super.onResume();
        isShowing = true;
        //add by cyr on 2017-9-4 start 关掉页面时候，清下手机助手的未读消息数  （从医生助手页切换到后台，在后台收到消息，返回医生助手页，会出现红点不清掉的问题）
        JS_ChatListDB.getInstance(this, UtilSP.getUserId()).setUnReadMessageNum2Zero(JS_ChatListModel.SERVICE_ID);
        //add by cyr on 2017-9-4 end
    }

    @Override
    protected void onPause() {
        super.onPause();
        isShowing = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        activityInstance = null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        // 点击notification bar进入聊天页面，保证只有一个聊天页面
        String username = intent.getStringExtra("userId");
        if (toChatUsername.equals(username))
            super.onNewIntent(intent);
        else {
            finish();
            startActivity(intent);
        }
    }

    public void sendRobotMessage(String txtContent, String menuId) {
        chatFragment.sendRobotMessage(txtContent, menuId);
    }

    @Override
    public void onNetRefresh() {

    }
}
