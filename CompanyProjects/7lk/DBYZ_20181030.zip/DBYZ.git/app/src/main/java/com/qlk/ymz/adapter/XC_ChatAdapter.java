package com.qlk.ymz.adapter;

import android.content.Context;
import android.graphics.Color;
import android.text.Html;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.emoji.util.EmojiSpanUtils;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.XC_ChatDetailActivity;
import com.qlk.ymz.adapter.ViewHolder.ChatMedicineRecordHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatLeftBaseHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatLeftBuyMedicineHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatLeftMovieHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatLeftPhotoHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatLeftQuesitionaryHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatLeftSelfTestHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatLeftTextHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatLeftVisitHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatLeftVoiceHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRighMedicalRecordHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRightBaseHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRightCheckHealthHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRightIndividuationCostHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRightMedicineRecommandHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRightPhotoHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRightPublicityEducationHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRightTextAssistantHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRightTextHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRightVisitHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatRightVoiceHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatSystemCheckReportHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatSystemHolder;
import com.qlk.ymz.adapter.ViewHolder.XC_ChatSystemMedicineTimeLimitHolder;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.ChatModelMedicalRecord;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.ReBuyNotic;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.ExamineBean;
import com.qlk.ymz.model.XC_SendMessageBackModel;
import com.qlk.ymz.model.YM_PushModel;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.UtiDoctorCheck;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilChatPhoto;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.UtilPackMsg;
import com.qlk.ymz.util.UtilScreen;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilImage;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jingyu on 2016/3/26.
 * 聊天页面的聊天详情列表adapter
 * V2.14.0后患者消息中全部多一种 启事消息 的数据内容
 * update: 2018/1/9
 */
public class XC_ChatAdapter extends XCBaseAdapter<XC_ChatModel> {

    public interface OnItemActionListener {
        /**
         * 长按提示信息
         */
        void onHintLongClickAction(XC_ChatModel model);

        /**
         * 医生视图 文本长按复制
         */
        void onRightLongClickTextAction(View view, XC_ChatModel model);

        /**
         * 患者视图 文本长按复制
         */
        void onLeftLongClickTextAction(View view, XC_ChatModel model);

        /**
         * 医生视图 重复推荐用药(续方)
         */
        void onRightClickRecommandAction(XC_ChatModel model);

        /**
         * 医生视图 长按音频
         */
        void onRightLongClickVoiceAction(TextView textView, ImageView imageview, XC_ChatModel model);

        /**
         * 患者视图 长按音频
         */
        void onLeftLongClickVoiceAction(TextView textView, ImageView imageview, XC_ChatModel model);

        /**
         * 医生视图 长按图片
         */
        void onRightLongClickPhotoAction(XC_ChatModel model);

        /**
         * 患者视图 长按图片
         */
        void onLeftLongClickPhotoAction(XC_ChatModel model);

        /**
         * 医生视图 点击关键字，跳转到推荐用药的搜索界面
         *
         * @param medicineKey 药品名
         */
        void onRightClickAssistantKeyAction(String medicineKey);

        /**
         * 医生视图 点击发送失败的按钮重发
         *
         * @param view 有tag是model
         */
        void onRightClickResendMsgAction(View view, XC_ChatModel model);

        /**
         * 医生视图 点击头像
         */
        void onRightClickHeadImgAction(View view, XC_ChatModel model);

        /**
         * 患者视图 点击头像
         */
        void onLeftClickHeadImgAction(View view, XC_ChatModel model);

        /**
         * 医生视图 点击音频
         */
        void onRightClickVoiceAction(TextView textView, ImageView imageview, XC_ChatModel model);

        /**
         * 患者视图 点击音频
         */
        void onLeftClickVoiceAction(TextView textView, ImageView imageview, ImageView point, XC_ChatModel model);

        /**
         * 医生视图 点击图片
         */
        void onRightClickPhotoAction(View view, XC_ChatModel model);

        /**
         * 医生视图 宣教功能
         */
        void onRightClickPublicityEducationAction(View view, XC_ChatModel model);
        /**
         * 医生视图 个性化服务功能
         */
        void onRightClickIndividuationCostAction(View view, XC_ChatModel model);
        /**
         * 医生视图 个性化服务功能 保存为常用服务
         */
        void onRightClickIndividuationCostSave(View view, XC_ChatModel model);
        /**
         * 医生视图 个性化服务功能 再次推荐常用服务
         */
        void onRightClickIndividuationCostAgain(View view, XC_ChatModel model);

        /**
         * 患者视图 点击图片
         */
        void onLeftClickPhotoAction(View view, XC_ChatModel model);

        /**
         * 患者视图 点击视频
         */
        void onLeftClickMovieAction(View view, XC_ChatModel model);

        /**
         * 患者视图 点击确认用药
         */
        void onLeftClickComfirmMedicineAction(View view, XC_ChatModel model);

        /**
         * 患者视图 点击药品item
         */
        void onLeftClickDrugItemAction(String drugId, XC_ChatModel model);

        /**
         * 点击查看处方详情
         */
        void onRightClickShowAction(XC_ChatModel model);
        /**
         * 点击查看健康检查详情
         */
        void onRightClickShowCheckHealthAction(XC_ChatModel model);

        /**
         * 医生视图 点击随访item
         */
        void onRightClickVisitAction(XC_ChatModel model);

        /**
         * 患者视图 点击随访item
         */
        void onLeftClickVisitAction(XC_ChatModel model);

        /**
         * 患者视图 图文咨询收费
         */
        void onLeftClickPaientPaid(XC_ChatModel model);

        /**
         * 患者视图 点击自测表item
         */
        void onLeftClickScleTestAction(XC_ChatModel model);

        /**
         * 患者视图点击调查表item
         */
        void onLeftClickScleSurveyAction(XC_ChatModel model);
        /**
         * 系统视图 药品消息时间限制
         */
        void onClickMedicineTimeLimitAction(XC_ChatModel model);
        /**
         * 查看病历详情
         */
        void onClickMedicalShowAction(XC_ChatModel model);
        /**
         * 查看病历详情中的处方消息
         */
        void onClickMedicalShowPreserctionAction(XC_ChatModel model);

        /**
         * 病历详情卡片中续方事件
         */
        void onClickMedicalAgainSendAction(XC_ChatModel model);
    }

    private OnItemActionListener mOnItemActionListener;

    public void setOnItemActionListener(OnItemActionListener onItemActionListener) {
        mOnItemActionListener = onItemActionListener;
    }

    @Override
    public int getViewTypeCount() {
        return UtilChat.UI_TYPE_COUNT;
    }

    @Override
    public int getItemViewType(int position) {
        XC_ChatModel model = list.get(position);

        return UtilChat.getChatViewType(model);
    }

    @SuppressWarnings("unchecked")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final XC_ChatModel model = list.get(position);
        int type = getItemViewType(position);
        UserPatient oldUserPatient = model.getUserPatient();
        UserPatient newUserPatient = patientInfo.getUserPatient();

        //把最新的患者信息更新到model里
        if(patientInfo!=null) {
            oldUserPatient.setPatientName(newUserPatient.getPatientName());
            oldUserPatient.setCityName(newUserPatient.getCityName());
            oldUserPatient.setPatientMemoName(newUserPatient.getPatientMemoName());
            oldUserPatient.setPatientNickName(newUserPatient.getPatientNickName());
            oldUserPatient.setPatientGender(newUserPatient.getPatientGender());
            oldUserPatient.setPatientAge(newUserPatient.getPatientAge());
            oldUserPatient.setPatientPhone(newUserPatient.getPatientPhone());
        }
        // 医生
        switch (type) {
            case UtilChat.UI_DOCTOR_TEXT:
                XC_ChatRightTextHolder rightTextHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_right_text, parent, false);
                    rightTextHolder = new XC_ChatRightTextHolder(convertView);
                    convertView.setTag(rightTextHolder);
                } else {
                    rightTextHolder = (XC_ChatRightTextHolder) convertView.getTag();
                }

                rightTextHolder.xc_id_adapter_right_content_text.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightLongClickTextAction(v, model);
                        }
                        return false;
                    }
                });

                rightCommon(model, rightTextHolder, position);
                adjustTextContentSizeAndClear(rightTextHolder.xc_id_adapter_right_content_text, null);
                setFaceText(rightTextHolder.xc_id_adapter_right_content_text, model.getMessageText());
                break;
            case UtilChat.UI_DOCTOR_TEXT_ASSISTANT:
                XC_ChatRightTextAssistantHolder rightTextAssistantHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_right_text_assistantkey, parent, false);
                    rightTextAssistantHolder = new XC_ChatRightTextAssistantHolder(convertView);
                    convertView.setTag(rightTextAssistantHolder);
                } else {
                    rightTextAssistantHolder = (XC_ChatRightTextAssistantHolder) convertView.getTag();
                }

                rightTextAssistantHolder.xc_id_adapter_right_content_text.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightLongClickTextAction(v, model);
                        }
                        return false;
                    }
                });

                rightCommon(model, rightTextAssistantHolder, position);
                checkMedicineAssistant(rightTextAssistantHolder, model);
                adjustTextContentSizeAndClear(rightTextAssistantHolder.xc_id_adapter_right_content_text, null);
                setFaceText(rightTextAssistantHolder.xc_id_adapter_right_content_text, model.getMessageText());
                break;
            case UtilChat.UI_DOCTOR_MEDICINE_RECOMMAND:
                XC_ChatRightMedicineRecommandHolder rightMedicinRecommandHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_right_medicinelink, parent, false);
                    rightMedicinRecommandHolder = new XC_ChatRightMedicineRecommandHolder(convertView);
                    convertView.setTag(rightMedicinRecommandHolder);
                } else {
                    rightMedicinRecommandHolder = (XC_ChatRightMedicineRecommandHolder) convertView.getTag();
                }
                rightMedicinRecommandHolder.id_right_patient_medicine_show.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickShowAction(model);
                        }
                    }
                });

                rightMedicinRecommandHolder.id_right_patient_medicine_recommend_again.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickRecommandAction(model);
                        }
                    }
                });
                if (model.isMedicineChecking()) {
                    medicineStatus(rightMedicinRecommandHolder, R.mipmap.checking_s, "七乐康药师正对处方审核中，请稍候", R.mipmap.checking_b, Color.parseColor("#F8834A"));
                } else if (model.isMedicineCheckFail()) {
                    medicineStatus(rightMedicinRecommandHolder, R.mipmap.check_fail_s, model.getAuditDesc(), R.mipmap.check_fail_b, Color.parseColor("#EE534B"));
                } else if (model.isMedicineCheckSuccess()) {
                    medicineStatus(rightMedicinRecommandHolder, R.mipmap.check_success_s, model.getAuditDesc(), R.mipmap.check_success_b, Color.parseColor("#6BAE30"));
                } else {
                    rightMedicinRecommandHolder.check_layout.setVisibility(View.GONE);
                }
                updateMedicineInvalidMsg(rightMedicinRecommandHolder,model);
                rightCommon(model, rightMedicinRecommandHolder, position);
                setRightMedicineLink(rightMedicinRecommandHolder, model);
                break;
            case UtilChat.UI_DOCTOR_VOICE:
                XC_ChatRightVoiceHolder rightVoiceHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_right_voice, parent, false);
                    rightVoiceHolder = new XC_ChatRightVoiceHolder(convertView);
                    convertView.setTag(rightVoiceHolder);
                } else {
                    rightVoiceHolder = (XC_ChatRightVoiceHolder) convertView.getTag();
                }

                final TextView textview = rightVoiceHolder.xc_id_adapter_right_content_text;
                final ImageView imageview = rightVoiceHolder.xc_id_adapter_right_voice_imageview;

                rightVoiceHolder.xc_id_adapter_right_voice_imageview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickVoiceAction(textview, imageview, model);
                        }
                    }
                });

                rightVoiceHolder.xc_id_adapter_right_voice_imageview.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightLongClickVoiceAction(textview, imageview, model);
                        }
                        return false;
                    }
                });

                rightVoiceHolder.xc_id_adapter_right_content_text.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickVoiceAction(textview, imageview, model);
                        }
                    }
                });

                rightVoiceHolder.xc_id_adapter_right_content_text.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightLongClickVoiceAction(textview, imageview, model);
                        }
                        return false;
                    }
                });

                rightCommon(model, rightVoiceHolder, position);
                // 设置喇叭向左开的图片
                setVoiceImageView(rightVoiceHolder.xc_id_adapter_right_voice_imageview, R.drawable.xc_d_chat_voice_for_greenbg_launch3);
                // 把文本清空 ，然后根据语音时长，动态的计算文本控件的长度
                adjustTextContentSizeAndClear(rightVoiceHolder.xc_id_adapter_right_content_text, model.getMediaDuration());
                // 设置录音时间，如果时间0，则不会显示
                setVoiceTime(rightVoiceHolder.xc_id_adapter_right_content_voice_time, model);
                break;
            case UtilChat.UI_DOCTOR_PHOTO:
                XC_ChatRightPhotoHolder rightPhotoHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_right_photo, parent, false);
                    rightPhotoHolder = new XC_ChatRightPhotoHolder(convertView);
                    convertView.setTag(rightPhotoHolder);
                } else {
                    rightPhotoHolder = (XC_ChatRightPhotoHolder) convertView.getTag();
                }
                rightPhotoHolder.xc_id_adapter_right_photo_imageview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickPhotoAction(v, model);
                        }
                    }
                });

                rightPhotoHolder.xc_id_adapter_right_photo_imageview.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightLongClickPhotoAction(model);
                        }
                        return true;
                    }
                });

                rightCommon(model, rightPhotoHolder, position);
                displayImagePlus(model, rightPhotoHolder.xc_id_adapter_right_photo_imageview, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_photo_default));
                break;
            case UtilChat.UI_DOCTOR_VISIT:
                XC_ChatRightVisitHolder chatRightSuiFangHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_right_suifang, parent, false);
                    chatRightSuiFangHolder = new XC_ChatRightVisitHolder(convertView);
                    convertView.setTag(chatRightSuiFangHolder);
                } else {
                    chatRightSuiFangHolder = (XC_ChatRightVisitHolder) convertView.getTag();
                }

                rightCommon(model, chatRightSuiFangHolder, position);
                chatRightSuiFangHolder.id_right_suifang_title.setText("疗效随访表");
//                疗效随访表自2.7版本后改为固定内容 "用于医生了解治疗效果"
//                chatRightSuiFangHolder.id_right_suifang_content.setText(model.getViewMessage().replace("\n", ""));
                chatRightSuiFangHolder.id_right_suifang_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickVisitAction(model);
                        }
                    }
                });
                break;

            case UtilChat.UI_DOCTOR_PUBLICITY_EDUCATION:
                XC_ChatRightPublicityEducationHolder rightPublicityEducationHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_right_publicity_education, parent, false);
                    rightPublicityEducationHolder = new XC_ChatRightPublicityEducationHolder(convertView);
                    convertView.setTag(rightPublicityEducationHolder);
                } else {
                    rightPublicityEducationHolder = (XC_ChatRightPublicityEducationHolder) convertView.getTag();
                }
                rightCommon(model, rightPublicityEducationHolder, position);
                rightPublicityEducationHolder.xc_id_right_publicity_education_read_status.setText(UtilChat.getReadStatusContent(model.getChatModelEdu().getEduReadStatus()));
                rightPublicityEducationHolder.xc_id_right_publicity_education_read_status.setTextColor(UtilChat.getReadStatusColor(model.getChatModelEdu().getEduReadStatus()));
                rightPublicityEducationHolder.xc_id_right_publicity_education_content.setText(model.getChatModelEdu().getEduTitle());//title是固定为“宣教字样”，标题显示在这里
                rightPublicityEducationHolder.id_right_publicity_education_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickPublicityEducationAction(v, model);
                        }
                    }
                });
                break;
            case UtilChat.UI_DOCTOR_INDIVIDUATION_COST:
                XC_ChatRightIndividuationCostHolder rightIndividuationCostHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_right_individuation_cost, parent, false);
                    rightIndividuationCostHolder = new XC_ChatRightIndividuationCostHolder(convertView);
                    convertView.setTag(rightIndividuationCostHolder);
                } else {
                    rightIndividuationCostHolder = (XC_ChatRightIndividuationCostHolder) convertView.getTag();
                }
                rightCommon(model, rightIndividuationCostHolder, position);
                rightIndividuationCostHolder.id_right_individuation_cost_title.setText(model.getUserDoctor().getDoctorSelfName().concat("医生推荐您关注以下服务"));
                rightIndividuationCostHolder.id_right_individuation_cost_date.setText(DateUtils.DateFormat(model.getMsgTime(),DateUtils.FORMAT_MMDD_STRIPING));
                rightIndividuationCostHolder.id_right_individuation_cost_price_name.setText(model.getChatModelCustomAdvisory().getCustomAdvisoryName());
                rightIndividuationCostHolder.id_right_individuation_cost_price.setText(StringUtils.getMoney(model.getChatModelCustomAdvisory().getCustomPrice()).concat("元"));
                rightIndividuationCostHolder.id_right_individuation_cost_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickIndividuationCostAction(v, model);
                        }
                    }
                });
                rightIndividuationCostHolder.id_right_save_cost.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickIndividuationCostSave(v, model);
                        }
                    }
                });
                rightIndividuationCostHolder.id_right_cost_recommend_again.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickIndividuationCostAgain(v, model);
                        }
                    }
                });
                break;
            case UtilChat.UI_DOCTOR_CHECK_HEALTH:
                XC_ChatRightCheckHealthHolder rightCheckHealthHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_right_check_health, parent, false);
                    rightCheckHealthHolder = new XC_ChatRightCheckHealthHolder(convertView);
                    convertView.setTag(rightCheckHealthHolder);
                } else {
                    rightCheckHealthHolder = (XC_ChatRightCheckHealthHolder) convertView.getTag();
                }
                rightCheckHealthHolder.id_right_check_bill_show.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onRightClickShowCheckHealthAction(model);
                        }
                    }
                });
                rightCommon(model, rightCheckHealthHolder, position);
                setRightCheckHealth(rightCheckHealthHolder,model);
                break;
            case UtilChat.UI_DOCTOR_MEDICAL_RECORD:
                XC_ChatRighMedicalRecordHolder recordIncludePrescriptionHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_right_medical_record, parent, false);
                    recordIncludePrescriptionHolder = new XC_ChatRighMedicalRecordHolder(convertView);
                    convertView.setTag(recordIncludePrescriptionHolder);
                } else {
                    recordIncludePrescriptionHolder = (XC_ChatRighMedicalRecordHolder) convertView.getTag();
                }
                rightCommon(model, recordIncludePrescriptionHolder, position);

                ChatModelMedicalRecord medicalRecordIncludePrescription = model.getChatModelMedicalRecord();
                String patientInfo = medicalRecordIncludePrescription.getPatientName().concat(" ").concat(medicalRecordIncludePrescription.getGender()).concat(" ").concat(medicalRecordIncludePrescription.getAge());
                recordIncludePrescriptionHolder.medical_record_name.setText(patientInfo);
                recordIncludePrescriptionHolder.medical_record_main_complaint.setText(medicalRecordSpan("主诉: ",medicalRecordIncludePrescription.getMainComplaint()));
                recordIncludePrescriptionHolder.medical_record_diagnosis.setText(medicalRecordSpan("诊断: ",medicalRecordIncludePrescription.getDiagnosis()));
                recordIncludePrescriptionHolder.medical_record_doctor_advice.setText(medicalRecordSpan("医嘱小结: ",medicalRecordIncludePrescription.getDoctorsSummary()));
                UtilViewShow.setGone(!UtilString.isBlank(medicalRecordIncludePrescription.getMainComplaint()),recordIncludePrescriptionHolder.medical_record_main_complaint);
                UtilViewShow.setGone(!UtilString.isBlank(medicalRecordIncludePrescription.getDoctorsSummary()),recordIncludePrescriptionHolder.medical_record_doctor_advice);
                UtilViewShow.setGone(!UtilString.isBlank(medicalRecordIncludePrescription.getDiagnosis()),recordIncludePrescriptionHolder.medical_record_diagnosis);
                UtilViewShow.setGone(!UtilString.isBlank(model.getRecommandId()),recordIncludePrescriptionHolder.medical_record_operation);

                if (medicalRecordIncludePrescription.isMedicineChecking()) {
                    medicineStatus(recordIncludePrescriptionHolder, R.mipmap.checking_s, "七乐康药师正对处方审核中，请稍候", Color.parseColor("#F8834A"));
                } else if (medicalRecordIncludePrescription.isMedicineCheckFail()) {
                    medicineStatus(recordIncludePrescriptionHolder, R.mipmap.check_fail_s, medicalRecordIncludePrescription.getAuditDesc(), Color.parseColor("#EE534B"));
                } else if (medicalRecordIncludePrescription.isMedicineCheckSuccess()) {
                    medicineStatus(recordIncludePrescriptionHolder, R.mipmap.check_success_s, medicalRecordIncludePrescription.getAuditDesc(), Color.parseColor("#6BAE30"));
                } else {
                    recordIncludePrescriptionHolder.check_layout.setVisibility(View.GONE);
                }
                updateMedicalInvalidMsg(recordIncludePrescriptionHolder,model);
                recordIncludePrescriptionHolder.sk_id_medical_rl.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onClickMedicalShowAction(model);
                        }
                    }
                });
                recordIncludePrescriptionHolder.id_right_patient_medicine_show.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onClickMedicalShowPreserctionAction(model);
                        }
                    }
                });
                recordIncludePrescriptionHolder.id_right_patient_medicine_recommend_again.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onClickMedicalAgainSendAction(model);
                        }
                    }
                });
                break;
            case UtilChat.UI_PATIENT_TEXT:
                XC_ChatLeftTextHolder leftTextHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_left_text, parent, false);
                    leftTextHolder = new XC_ChatLeftTextHolder(convertView);
                    convertView.setTag(leftTextHolder);
                } else {
                    leftTextHolder = (XC_ChatLeftTextHolder) convertView.getTag();
                }

                leftTextHolder.xc_id_adapter_left_content_text.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftLongClickTextAction(v, model);
                        }
                        return false;
                    }
                });

                leftCommon(model, leftTextHolder, position);
                leftTextHolder.xc_id_adapter_left_content_text.setTag(model);
                adjustTextContentSizeAndClear(leftTextHolder.xc_id_adapter_left_content_text, null);
                setFaceText(leftTextHolder.xc_id_adapter_left_content_text, model.getMessageText());
                break;
            case UtilChat.UI_PATIENT_PHOTO:
                XC_ChatLeftPhotoHolder leftPhotoHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_left_photo, parent, false);
                    leftPhotoHolder = new XC_ChatLeftPhotoHolder(convertView);
                    convertView.setTag(leftPhotoHolder);
                } else {
                    leftPhotoHolder = (XC_ChatLeftPhotoHolder) convertView.getTag();
                }

                leftPhotoHolder.xc_id_adapter_left_photo_imageview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftClickPhotoAction(v, model);
                        }
                    }
                });

                leftPhotoHolder.xc_id_adapter_left_photo_imageview.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftLongClickPhotoAction(model);
                        }
                        return true;
                    }
                });

                leftCommon(model, leftPhotoHolder, position);
                displayImagePlus(model, leftPhotoHolder.xc_id_adapter_left_photo_imageview, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_photo_default));
                break;
            case UtilChat.UI_PATIENT_VOICE:
                XC_ChatLeftVoiceHolder leftVoiceHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_left_voice, parent, false);
                    leftVoiceHolder = new XC_ChatLeftVoiceHolder(convertView);
                    convertView.setTag(leftVoiceHolder);
                } else {
                    leftVoiceHolder = (XC_ChatLeftVoiceHolder) convertView.getTag();
                }

                final TextView textview2 = leftVoiceHolder.xc_id_adapter_left_content_text;
                final ImageView imageview2 = leftVoiceHolder.xc_id_adapter_left_voice_imageview;
                final ImageView imagepoint = leftVoiceHolder.xc_id_adapter_left_voice_point;

                leftVoiceHolder.xc_id_adapter_left_voice_imageview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftClickVoiceAction(textview2, imageview2, imagepoint, model);
                            UtilViewShow.setGone(false, imagepoint);
                        }
                    }
                });

                leftVoiceHolder.xc_id_adapter_left_voice_imageview.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftLongClickVoiceAction(textview2, imageview2, model);
                        }
                        return false;
                    }
                });

                leftVoiceHolder.xc_id_adapter_left_content_text.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftClickVoiceAction(textview2, imageview2, imagepoint, model);
                            UtilViewShow.setGone(false, imagepoint);
                        }
                    }
                });

                leftVoiceHolder.xc_id_adapter_left_content_text.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftLongClickVoiceAction(textview2, imageview2, model);
                        }
                        return false;
                    }
                });

                leftCommon(model, leftVoiceHolder, position);
                // 设置喇叭向左开的图片
                setVoiceImageView(leftVoiceHolder.xc_id_adapter_left_voice_imageview, R.drawable.xc_d_chat_voice_for_whitebg_launch3);
                // 先把文本清空 ，然后根据语音时长，动态的计算文本控件的长度
                adjustTextContentSizeAndClear(leftVoiceHolder.xc_id_adapter_left_content_text, model.getMediaDuration());
                // 设置录音时间，如果时间0，则不会显示
                setVoiceTime(leftVoiceHolder.xc_id_adapter_left_voice_time, model);
                // 声音信息如果未读，有小红点
                if (XC_ChatModel.UN_READED.equals(model.getIsRead())) {
                    leftVoiceHolder.xc_id_adapter_left_content_text.setTag(R.id.imageview_voice_point, leftVoiceHolder.xc_id_adapter_left_voice_point);
                    leftVoiceHolder.xc_id_adapter_left_voice_imageview.setTag(R.id.imageview_voice_point, leftVoiceHolder.xc_id_adapter_left_voice_point);
                    UtilViewShow.setVisible(true, leftVoiceHolder.xc_id_adapter_left_voice_point);
                } else {
                    UtilViewShow.setVisible(false, leftVoiceHolder.xc_id_adapter_left_voice_point);
                }
                break;
            case UtilChat.UI_PATIENT_MOVIE:
                XC_ChatLeftMovieHolder leftMovieHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_left_moive, parent, false);
                    leftMovieHolder = new XC_ChatLeftMovieHolder(convertView);
                    convertView.setTag(leftMovieHolder);
                } else {
                    leftMovieHolder = (XC_ChatLeftMovieHolder) convertView.getTag();
                }

                leftMovieHolder.xc_id_adapter_left_moive_content_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftClickMovieAction(v, model);
                        }
                    }
                });

                leftCommon(model, leftMovieHolder, position);
                //leftMovieHolder.xc_id_adapter_left_moive_content_imageview.setImageResource(R.mipmap.xc_d_chat_videoplay_bg);
                leftMovieHolder.xc_id_adapter_left_moive_content_imageview.setImageResource(R.mipmap.moive_bg);
                // 第一帧
                UtilChatPhoto.setMovieFirstFrame(leftMovieHolder.xc_id_adapter_left_moive_content_imageview, model);
                break;
            case UtilChat.UI_PATIENT_BUY_MEDICINE:
                XC_ChatLeftBuyMedicineHolder leftBuyMedicineHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_left_buy_medicine, parent, false);
                    leftBuyMedicineHolder = new XC_ChatLeftBuyMedicineHolder(convertView);
                    convertView.setTag(leftBuyMedicineHolder);
                } else {
                    leftBuyMedicineHolder = (XC_ChatLeftBuyMedicineHolder) convertView.getTag();
                }
                leftBuyMedicineHolder.id_left_patient_medicine_confirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftClickComfirmMedicineAction(v, model);
                        }
                    }
                });

                leftCommon(model, leftBuyMedicineHolder, position);
                setLeftMedicineLink(leftBuyMedicineHolder, model);
                break;
            case UtilChat.UI_PAIENT_VISIT:
                XC_ChatLeftVisitHolder chatLeftSuiFangHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_left_suifang, parent, false);
                    chatLeftSuiFangHolder = new XC_ChatLeftVisitHolder(convertView);
                    convertView.setTag(chatLeftSuiFangHolder);
                } else {
                    chatLeftSuiFangHolder = (XC_ChatLeftVisitHolder) convertView.getTag();
                }
                leftCommon(model, chatLeftSuiFangHolder, position);
                chatLeftSuiFangHolder.id_left_suifang_title.setText("疗效随访表反馈");
                chatLeftSuiFangHolder.id_left_suifang_content.setText(model.getViewMessage().replace("\n", ""));
                chatLeftSuiFangHolder.id_left_suifang_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftClickVisitAction(model);
                        }
                    }
                });

                break;
            case UtilChat.UI_PAIENT_SCALE_SELF_TEST:
                XC_ChatLeftSelfTestHolder chatLeftSelfTestHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_left_self_test, parent, false);
                    chatLeftSelfTestHolder = new XC_ChatLeftSelfTestHolder(convertView);
                    convertView.setTag(chatLeftSelfTestHolder);
                } else {
                    chatLeftSelfTestHolder = (XC_ChatLeftSelfTestHolder) convertView.getTag();
                }
                leftCommon(model, chatLeftSelfTestHolder, position);
                chatLeftSelfTestHolder.id_left_self_test_title.setText(model.getChatModelScale().getScaleTitle());
                chatLeftSelfTestHolder.id_left_self_test_content.setText("评估分：".concat(model.getChatModelScale().getScalePoint()));
                chatLeftSelfTestHolder.id_left_self_test_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftClickScleTestAction(model);
                        }
                    }
                });
                break;
            case UtilChat.UI_PAIENT_SCALE_QUESITIONARY:
                XC_ChatLeftQuesitionaryHolder chatLeftQuesitionaryHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_left_quesitionary, parent, false);
                    chatLeftQuesitionaryHolder = new XC_ChatLeftQuesitionaryHolder(convertView);
                    convertView.setTag(chatLeftQuesitionaryHolder);
                } else {
                    chatLeftQuesitionaryHolder = (XC_ChatLeftQuesitionaryHolder) convertView.getTag();
                }
                leftCommon(model, chatLeftQuesitionaryHolder, position);
                chatLeftQuesitionaryHolder.id_left_quesitionary_title.setText(model.getChatModelScale().getScaleTitle());
                chatLeftQuesitionaryHolder.id_left_quesitionary_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftClickScleSurveyAction(model);
                        }
                    }
                });
                break;
            case UtilChat.UI_PAIENT_SCALE_NEW:
                XC_ChatLeftQuesitionaryHolder scaleNewHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_left_quesitionary, parent, false);
                    scaleNewHolder = new XC_ChatLeftQuesitionaryHolder(convertView);
                    convertView.setTag(scaleNewHolder);
                } else {
                    scaleNewHolder = (XC_ChatLeftQuesitionaryHolder) convertView.getTag();
                }
                leftCommon(model, scaleNewHolder, position);
                scaleNewHolder.id_left_quesitionary_title.setText(model.getChatModelScaleNew().getTitle());
                scaleNewHolder.id_left_quesitionary_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftClickScleSurveyAction(model);
                        }
                    }
                });
                break;
            case UtilChat.UI_SYSTEM_MEDICIEN_TIME_LIMIT:
                XC_ChatSystemMedicineTimeLimitHolder medicineTimeLimitHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.chat_system_medicine_time_limit, parent,false);
                    medicineTimeLimitHolder = new XC_ChatSystemMedicineTimeLimitHolder(convertView);
                    convertView.setTag(medicineTimeLimitHolder);
                } else {
                    medicineTimeLimitHolder = (XC_ChatSystemMedicineTimeLimitHolder) convertView.getTag();
                }

                // 高亮器
                ForegroundColorSpan color_span = new ForegroundColorSpan(Color.parseColor("#2A97F5"));

                ClickableSpan click_span = new ClickableSpan() {
                    @Override
                    public void onClick(View widget) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onClickMedicineTimeLimitAction(model);
                        }
                    }

                    @Override
                    public void updateDrawState(TextPaint ds) {
                        super.updateDrawState(ds);
                        ds.setUnderlineText(false);//设置取消下划线
                    }
                };
                ReBuyNotic reBuyNotic = model.getReBuyNotic();
                String medicineNameAndSpec = reBuyNotic.getMedicationName();
                String dateTime = UtilDate.convertChatDetailTimeFormatFinalMethed(UtilString.toLong(reBuyNotic.getRecommandTime()));
                int endDay = UtilString.toInt(reBuyNotic.getEndDay(),0);
                String endDayString;
//                当 ReBuyNotic.getEndDay() 时间为正数时候，显示为 “还有*天将服用完”。时间显示为负数的时候，显示为"于*天前已服用完"
//                患者还有3天将服用完，请及时与患者沟通康复情况。
//                患者于3天前已服用完，请及时与患者沟通康复情况。
                if (endDay < 0){
                    String endDayAbs = String.valueOf(Math.abs(endDay));
                    endDayString = "于".concat(endDayAbs).concat("天前已");
                }else {
                    endDayString = "还有".concat(String.valueOf(endDay)).concat("天将");
                }
                final String str = context.getResources().getString(R.string.re_buy_notic,dateTime,reBuyNotic.getMedicationName(),endDayString);
                int index = str.indexOf(medicineNameAndSpec);
                int length = medicineNameAndSpec.length();
                SpannableString spanString = new SpannableString(str);
                spanString.setSpan(click_span, index, index+length, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE);
                spanString.setSpan(color_span, index, index+length, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE);
                medicineTimeLimitHolder.textview.setText(spanString);
                medicineTimeLimitHolder.textview.setMovementMethod(LinkMovementMethod.getInstance());
                medicineTimeLimitHolder.textview.setLongClickable(false);
                //设置点击事件是因为TextView部分文字设置点击事件的时候，再对TextView进行长按会在部分手机出现崩溃问题
                medicineTimeLimitHolder.textview.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        return true;
                    }
                });
                break;
            case UtilChat.UI_SYSTEM_MEDICIEN_RECORD:
                ChatMedicineRecordHolder medicineRecord;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.chat_system_medicine_record, parent,false);
                    medicineRecord = new ChatMedicineRecordHolder(convertView);
                    convertView.setTag(medicineRecord);
                } else {
                    medicineRecord = (ChatMedicineRecordHolder) convertView.getTag();
                }
                final String content = model.getChatModelMedicineRecord().getText();
                medicineRecord.textview.setText(Html.fromHtml(content));
                medicineRecord.textview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        patternContent(content,model);
                    }
                });
                break;
            case UtilChat.UI_SYSTEM_MEDICIEN_RECORD_LAST:
                ChatMedicineRecordHolder medicineRecordLast;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.chat_system_medicine_record, parent,false);
                    medicineRecordLast = new ChatMedicineRecordHolder(convertView);
                    convertView.setTag(medicineRecordLast);
                } else {
                    medicineRecordLast = (ChatMedicineRecordHolder) convertView.getTag();
                }
                final String contentLast = model.getChatModelMedicineRecord().getText();
                medicineRecordLast.textview.setText(Html.fromHtml(contentLast));
                medicineRecordLast.textview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        patternContent(contentLast,model);
                    }
                });
                break;
            case UtilChat.UI_SYSTEM_MEDICIEN_RECORD_REMIND:
                ChatMedicineRecordHolder medicineRecordRemind;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.chat_system_medicine_record, parent,false);
                    medicineRecordRemind = new ChatMedicineRecordHolder(convertView);
                    convertView.setTag(medicineRecordRemind);
                } else {
                    medicineRecordRemind = (ChatMedicineRecordHolder) convertView.getTag();
                }
                final String contentRemind = model.getChatModelMedicineRecord().getText();
                medicineRecordRemind.textview.setText(Html.fromHtml(contentRemind));
                medicineRecordRemind.textview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        patternContent(contentRemind,model);
                    }
                });
                break;
            case UtilChat.UI_SYSTEM:
                XC_ChatSystemHolder holder_system;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_system_item, parent,false);
                    holder_system = new XC_ChatSystemHolder(convertView);
                    convertView.setTag(holder_system);
                } else {
                    holder_system = (XC_ChatSystemHolder) convertView.getTag();
                }

                // 本地模拟系统提示消息
                if (UtilPackMsg.isPatientBuyCome(model) || UtilPackMsg.isPatientBuyEnd(model)) {
                    holder_system.textview.setText(model.getMessageText());
                }else if ("1".equals(model.getCancelFlag())){
                    holder_system.textview.setText(XC_ChatModel.CANCEL_TIP);
                }else {
                    // ui视图更改了，结束消息的提示 不显示在消息的后面，改为显示在聊天界面的底部，
                    // 所以session_end_hint类型的消息从集合移除了(查库的时候就已经删除了)，adapter不走下面的代码
                    holder_system.textview.setText("");
                }
                holder_system.textview.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onHintLongClickAction(model);
                        }
                        return true;
                    }
                });
                break;
            case UtilChat.UI_SYSTEM_PAID:
                XC_ChatSystemHolder patientIndividuationCost;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_system_item, parent, false);
                    patientIndividuationCost = new XC_ChatSystemHolder(convertView);
                    convertView.setTag(patientIndividuationCost);
                } else {
                    patientIndividuationCost = (XC_ChatSystemHolder) convertView.getTag();
                }
                patientIndividuationCost.textview.setText(model.getChatModelPaid().getPaidDetail());
                patientIndividuationCost.textview.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemActionListener != null) {
                            mOnItemActionListener.onLeftClickPaientPaid(model);
                        }
                        return true;
                    }
                });
                break;
            case UtilChat.UI_PSYSTEM_CHECK_REPORT:
                XC_ChatSystemCheckReportHolder checkReportHolder;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.chat_system_check_report, parent,false);
                    checkReportHolder = new XC_ChatSystemCheckReportHolder(convertView);
                    convertView.setTag(checkReportHolder);
                } else {
                    checkReportHolder = (XC_ChatSystemCheckReportHolder) convertView.getTag();
                }
                final String checkReportContent = model.getChatModelMedicineRecord().getText();
                // 设置时间
                setDateTime(checkReportHolder.sysTime, position);
                checkReportHolder.textview.setText(Html.fromHtml(checkReportContent));
                checkReportHolder.textview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        patternContent(checkReportContent,model);
                    }
                });
                break;
            case UtilChat.UI_DEFAULT:
                XC_ChatSystemHolder defaultUI;
                if (convertView == null) {
                    convertView = layoutInflater.inflate(R.layout.xc_l_adapter_chat_system_item, parent, false);
                    defaultUI = new XC_ChatSystemHolder(convertView);
                    convertView.setTag(defaultUI);
                } else {
                    defaultUI = (XC_ChatSystemHolder) convertView.getTag();
                }
                defaultUI.textview.setText("当前版本暂不支持查看此类消息，请更新APP至最新版本查看!");
                break;
            default:
                break;
        }
        return convertView;
    }

    private void medicineStatus(XC_ChatRightMedicineRecommandHolder rightMedicineLinkHolder, int checking_s, String text, int checking_b, int color) {
        rightMedicineLinkHolder.check_img.setImageResource(checking_s);
        rightMedicineLinkHolder.check_text.setText(text);
        rightMedicineLinkHolder.check_text.setTextColor(color);
        rightMedicineLinkHolder.check_layout.setVisibility(View.VISIBLE);
    }
    private void medicineStatus(XC_ChatRighMedicalRecordHolder medicalRecordHolder, int checking_s, String text, int color) {
        medicalRecordHolder.check_img.setImageResource(checking_s);
        medicalRecordHolder.check_text.setText(text);
        medicalRecordHolder.check_text.setTextColor(color);
        medicalRecordHolder.check_layout.setVisibility(View.VISIBLE);
    }

    private void leftCommon(final XC_ChatModel model, XC_ChatLeftBaseHolder holder, int position) {
        holder.xc_id_adapter_left_head.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnItemActionListener != null) {
                    mOnItemActionListener.onLeftClickHeadImgAction(v, model);
                }
            }
        });
        String noticDetail = model.getAdditionalNoticeModel().getDetail();
        holder.chat_adapter_patient_notice_head.setText(noticDetail);//设置患者消息提示文案
        if (UtilString.isBlank(noticDetail)){
            UtilViewShow.setGone(false,holder.chat_adapter_patient_notice_head);
        }else {
            UtilViewShow.setGone(true,holder.chat_adapter_patient_notice_head);
        }
        // 设置时间
        setDateTime(holder.xc_id_adapter_left_time, position);
        // 设置头像
        XCApplication.displayImage(model.getUserPatient().getPatientImgHead(), holder.xc_id_adapter_left_head, XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default));
    }

    private void rightCommon(final XC_ChatModel model, XC_ChatRightBaseHolder holder, int position) {

        holder.xc_id_adapter_right_head.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnItemActionListener != null) {
                    mOnItemActionListener.onRightClickHeadImgAction(v, model);
                }
            }
        });

        holder.xc_id_chat_right_net_fail_hint_imageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnItemActionListener != null) {
                    mOnItemActionListener.onRightClickResendMsgAction(v, model);
                }
            }
        });

        // 发送进行中的dialog
        checkNetStatus(model, holder);

        // 设置信息发送时间
        setDateTime(holder.xc_id_adapter_right_time, position);

        // 设置头像
        showDoctorHead(holder);
    }

    /**
     * 录音视图的最小长度，时间越长，视图越长
     */
    private int voice_in_textview_content_least_size;
    /**
     * 录音视图的最大长度，时间越长，视图越长
     */
    private int voice_in_textview_content_most_size;

    private LayoutInflater layoutInflater;
    private static final String TAG_CHAT = XC_ChatDetailActivity.TAG_CHAT;

    /**
     * 两次信息时间间隔多少秒内，不显示时间，毫秒单位
     */
    private static final int DATE_SHOW_GAP = 120000;
    /**
     * 患者信息
     */
    private JS_ChatListModel patientInfo;

    /**
     * 通过患者id查询最新的患者信息
     * @param patientId 患者ID
     */
    public void setPatientInfo(String patientId) {
        patientInfo = JS_ChatListDB.getInstance(context,UtilSP.getUserId()).getPatientInfo(patientId);
    }

    /**
     * @param list    如果传null 则用默认的imageloader， 该默认的为universal imageloader框架
     */
    public XC_ChatAdapter(Context context, List<XC_ChatModel> list) {
        super(context, list);
        if (context != null) {
            voice_in_textview_content_least_size = UtilImage.dip2px(context, 45);
            voice_in_textview_content_most_size = (int) (UtilScreen.getScreenWidthPx(context) * 0.48);
            layoutInflater = LayoutInflater.from(context);
        }
    }

    /**
     * 显示发送时间， 默认120秒内的再次发送不会显示时间
     *
     * @param textview message上方显示时间的ui
     * @param position 该条消息的位置
     */

    private void setDateTime(TextView textview, int position) {

        XC_ChatModel model = (XC_ChatModel) getItem(position);
        Long times = UtilString.toLong(model.getMsgTime());

        if (position == 0) {
            // 第一条信息是一定会显示发送时间的
            showDateTime(textview, times);
            UtilViewShow.setGone(true, textview);
            return;
        }

        // 非第一条信息的情况
        XC_ChatModel model_1 = (XC_ChatModel) getItem(position - 1);
        Long times_1 = UtilString.toLong(model_1.getMsgTime());

        // 对比前一条信息和后一条信息的时间差
        if (times - times_1 > DATE_SHOW_GAP) {
            showDateTime(textview, times);
            UtilViewShow.setGone(true, textview);
        } else {
            textview.setText("");
            UtilViewShow.setGone(false, textview);
        }
    }

    /**
     * 格式化发送信息的时间
     *
     * @param textview message上方显示时间的ui
     * @param times    消息时间毫秒值
     */
    private void showDateTime(TextView textview, Long times) {
        textview.setText(UtilDate.convertChatDetailTimeFormatFinalMethed(times));
    }

    /**
     * 设置声音的喇叭图片，左右的item是不同的颜色图片
     *
     * @param voiceImageView 喇叭控件
     * @param drawable_id    喇叭图片id
     */
    private void setVoiceImageView(ImageView voiceImageView, int drawable_id) {
        voiceImageView.setImageResource(drawable_id);
    }

    /**
     * 设置声音消息的时长即该条声音信息有多少秒
     *
     * @param textview 声音时长的控件
     * @param model    消息的model
     */
    private void setVoiceTime(TextView textview, XC_ChatModel model) {
        try {
            String time = model.getMediaDuration();

            if (UtilString.isBlank(time) || !(XC_ChatModel.VOICE + "").equals(model.getMsgType())) {
                textview.setText("");
                UtilViewShow.setGone(false, textview);
                return;
            }

            if (Integer.parseInt(time) > 0) {
                textview.setText(time.concat(" \'\'"));
                UtilViewShow.setGone(true, textview);
            } else {
                textview.setText("");
                UtilViewShow.setGone(false, textview);
            }

        } catch (Exception e) {
            e.printStackTrace();
            textview.setText("");
            UtilViewShow.setGone(false, textview);
            XCApplication.base_log.i(TAG_CHAT, "setVoiceTime()异常了");
        }
    }

    /**
     * 如果是声音消息，音频的时长越长， text的框框的长度越长
     * 如果是文本消息，wrap宽度
     *
     * @param text_content_view 文本控件
     * @param duration          声音的时长
     */
    private void adjustTextContentSizeAndClear(TextView text_content_view, String duration) {

        // 清空文本
        if (text_content_view != null) {
            text_content_view.setText("");
        } else {
            return;
        }

        int time = -1;
        try {
            if (!UtilString.isBlank(duration)) {
                time = Integer.parseInt(duration);
            }
        } catch (Exception e) {
            e.printStackTrace();
            XCApplication.base_log.i(TAG_CHAT, "adjustTextContentSizeAndClear()---解析voice duration 失败--传来的time为-" + time);
        }

        if (time <= 0) {
            // 表示是文本，则用文本的wrap大小
            ViewGroup.LayoutParams vl = text_content_view.getLayoutParams();
            vl.width = ViewGroup.LayoutParams.WRAP_CONTENT;
            vl.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            text_content_view.setMaxWidth(voice_in_textview_content_most_size + voice_in_textview_content_least_size);
            text_content_view.setLayoutParams(vl);
            return;
        }

        // 大于18秒的话直接显示最大的宽度，最长是录制60秒
        double rate = time / 17.0;

        if (rate >= 1) {
            ViewGroup.LayoutParams vl = text_content_view.getLayoutParams();
            vl.width = voice_in_textview_content_most_size + voice_in_textview_content_least_size;
            vl.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            text_content_view.setLayoutParams(vl);
        } else {
            ViewGroup.LayoutParams vl = text_content_view.getLayoutParams();
            vl.width = (int) (rate * voice_in_textview_content_most_size) + voice_in_textview_content_least_size;
            vl.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            text_content_view.setLayoutParams(vl);
        }
    }

    /**
     * 解析带有表情的文本，咱应用里目前不做表情
     */
    private void setFaceText(TextView textview, String text) {
        textview.setText(EmojiSpanUtils.getSmiledText(context,text,textview));
    }

    /**
     * 设置推荐用药的药品列表的视图
     *
     * @param chatRightMedicineRecommandHolder 推荐用药列表的视图
     * @param model                    消息model
     */
    private void setRightMedicineLink(XC_ChatRightMedicineRecommandHolder chatRightMedicineRecommandHolder, final XC_ChatModel model) {
        // ---------------  2016/1/30 sk 修改 ----------------------------------- ↓↓↓↓
        List<DrugBean> drugBeanList = UtilIMCreateJson.recommandMedicineMsg2Drugs(model);

        if (drugBeanList == null) {
            return;
        }
        chatRightMedicineRecommandHolder.details.setText("处方详情如下 共"+drugBeanList.size()+"种:");
        // jira 3198，最多只可显示两个药品
        if (drugBeanList.size() > 2) {
            drugBeanList = drugBeanList.subList(0, 2);
            chatRightMedicineRecommandHolder.right_show_ellipsis.setVisibility(View.VISIBLE);
        }else {
            chatRightMedicineRecommandHolder.right_show_ellipsis.setVisibility(View.GONE);
        }

        chatRightMedicineRecommandHolder.sk_id_medichine_listview.setAdapter(new SK_ChatMedichineAdapter(context, drugBeanList));
        // ---------------  2016/1/30 sk 修改 ----------------------------------- ↑↑↑↑
    }

    private void setLeftMedicineLink(XC_ChatLeftBuyMedicineHolder leftBuyMedicineHolder, final XC_ChatModel model) {
        // ---------------  2016/1/30 sk 修改 ----------------------------------- ↓↓↓↓
        List<DrugBean> drugBeanList = UtilIMCreateJson.recommandMedicineMsg2Drugs(model);

        if (drugBeanList == null) {
            return;
        }

        List<DrugBean> subList;

        if (drugBeanList.size() > 2) {
            subList = drugBeanList.subList(0, 2);
            leftBuyMedicineHolder.left_show_ellipsis.setVisibility(View.VISIBLE);
        } else {
            subList = drugBeanList;
            leftBuyMedicineHolder.left_show_ellipsis.setVisibility(View.GONE);
        }

        leftBuyMedicineHolder.id_left_medichine_patient_listview.setAdapter(new SK_ChatLeftMedichineAdapter(context, subList));
        leftBuyMedicineHolder.id_left_medichine_patient_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DrugBean drugBean = (DrugBean) parent.getItemAtPosition(position);
                if (mOnItemActionListener != null) {
                    mOnItemActionListener.onLeftClickDrugItemAction(drugBean.getId(), model);
                }
            }
        });

        if (drugBeanList.size() > 2) {
            leftBuyMedicineHolder.totalNum.setText("申请购买以下药品 共" + drugBeanList.size() + "种");
            leftBuyMedicineHolder.totalNum.setVisibility(View.VISIBLE);
        } else {
            leftBuyMedicineHolder.totalNum.setVisibility(View.GONE);
        }
        // ---------------  2016/1/30 sk 修改 ----------------------------------- ↑↑↑↑
    }
    /**
     * 设置健康检查的列表视图
     *
     * @param chatRightCheckHealthHolder 推荐健康检查列表的视图
     * @param model                    消息model
     */
    private void setRightCheckHealth(XC_ChatRightCheckHealthHolder chatRightCheckHealthHolder, final XC_ChatModel model) {
        List<ExamineBean> examineBeanList = UtilIMCreateJson.checkHealthItems(model);
        if (examineBeanList == null) {
            return;
        }
        chatRightCheckHealthHolder.check_health_count.setText("检查单详情如下 共"+examineBeanList.size()+"种:");
        if (examineBeanList.size() > 2) {
            examineBeanList = examineBeanList.subList(0, 2);
        }
        chatRightCheckHealthHolder.sk_id_check_health_listview.setAdapter(new CheckHealthAdapter(context, examineBeanList));
    }
    /**
     * 可以获取小图,和 监听图片的加载
     */
    private void displayImagePlus(XC_ChatModel model, ImageView xc_id_adapter_left_photo_content_imageview, DisplayImageOptions options) {
        XCApplication.displayImage(UtilChatPhoto.getSmallUrl(model), xc_id_adapter_left_photo_content_imageview, options);
    }

    /**
     * 以前版本用到了UNCHECK_HINT UNCHECK_HINT_MEDICINE，后期的版本没用到
     */
    private static final String UNCHECK_HINT = "您尚未通过身份认证审核。如果您还没有进行过身份认证，请尽快提交认证资料，以避免医疗咨询风险。";
    private static final String UNCHECK_HINT_MEDICINE = "由于没有通过身份认证，为减少用户的用药风险，暂无法使用推荐用药功能。如果您还没有进行过身份认证，请进入身份认证页面提交认证。";

    private static final String ASSISTANT_HINT = "您是否需要推荐用药给患者 , 点击推荐 ";

    /**
     * 检查该条信息是否有推荐用药的关键字
     */
    private void checkMedicineAssistant(XC_ChatRightTextAssistantHolder holder, XC_ChatModel model) {
        if (model.getMessageTextRecommand() != null && model.getMessageTextRecommand().contains(UtiDoctorCheck.TO_CHECK)) {
            // 显示去认证的信息
            if (model.getMessageTextRecommand().equals(UtiDoctorCheck.TO_CHECK + XC_SendMessageBackModel.MEDICINE_ASSISTANT_SPLIT)) {
                holder.xc_id_adapter_right_recommand_medicine.setText(UNCHECK_HINT);
            } else if (model.getMessageTextRecommand().equals(UtiDoctorCheck.TO_CHECK + XC_SendMessageBackModel.MEDICINE_ASSISTANT_SPLIT + XC_SendMessageBackModel.MEDICINE_ASSISTANT_SPLIT)) {
                holder.xc_id_adapter_right_recommand_medicine.setText(UNCHECK_HINT_MEDICINE);
            }
            appendMedicineAssistantSpan(holder.xc_id_adapter_right_recommand_medicine, model.getMessageTextRecommand());
        } else {
            if (UtiDoctorCheck.isVertify()) {
                // 显示用药助手的信息
                holder.xc_id_adapter_right_recommand_medicine.setText(ASSISTANT_HINT);
                appendMedicineAssistantSpan(holder.xc_id_adapter_right_recommand_medicine, model.getMessageTextRecommand());
            } else {
                // 这里改了很多个版本，以前这里if else的逻辑是不同的
                holder.xc_id_adapter_right_recommand_medicine.setText(ASSISTANT_HINT);
                appendMedicineAssistantSpan(holder.xc_id_adapter_right_recommand_medicine, model.getMessageTextRecommand());
            }
        }
    }

    /**
     * 给推荐用药的关键字添加点击的监听span
     *
     * @param xc_id_adapter_right_recommand_medicine 显示关键字的控件
     * @param messageTextRecommand                   后端返回的搜索关键字串
     */
    private void appendMedicineAssistantSpan(TextView xc_id_adapter_right_recommand_medicine, String messageTextRecommand) {
        String[] strs = messageTextRecommand.split(XC_SendMessageBackModel.MEDICINE_ASSISTANT_SPLIT);

        int size = strs.length;
        for (final String str : strs) {

            SpannableString spanString = new SpannableString(str);
            // 高亮器
            ForegroundColorSpan color_span = new ForegroundColorSpan(Color.parseColor("#2A97F5"));

            ClickableSpan click_span = new ClickableSpan() {
                @Override
                public void onClick(View widget) {
                    if (mOnItemActionListener != null) {
                        mOnItemActionListener.onRightClickAssistantKeyAction(str);
                    }
                }
            };

            spanString.setSpan(click_span, 0, (str).length(), SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE);
            spanString.setSpan(color_span, 0, (str).length(), SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE);
            xc_id_adapter_right_recommand_medicine.append(spanString);
            if (size-- != 1) {
                xc_id_adapter_right_recommand_medicine.append("     ");
            }
        }
        xc_id_adapter_right_recommand_medicine.setMovementMethod(LinkMovementMethod.getInstance());
        xc_id_adapter_right_recommand_medicine.setLongClickable(false);
        xc_id_adapter_right_recommand_medicine.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return true;
            }
        });
    }

    /**
     * 检查每条信息发送的网络结果
     * 如果没有成功，显示感叹号
     * 如果是没有发送，则会发送，并把SEND_NOT 更新为SEND_ING
     *
     * @param model 该条消息
     *              xc_id_chat_right_net_layout              显示网络状态的布局
     *              xc_id_chat_right_net_fail_hint_imageview 无网的提示控件，在xc_id_chat_right_net_layout里
     *              xc_id_chat_right_net_progress_bar        进度dialog，在xc_id_chat_right_net_layout里
     */
    private void checkNetStatus(XC_ChatModel model, XC_ChatRightBaseHolder holder) {
        RelativeLayout xc_id_chat_right_net_layout = holder.xc_id_chat_right_net_layout;
        ImageView xc_id_chat_right_net_fail_hint_imageview = holder.xc_id_chat_right_net_fail_hint_imageview;
        ProgressBar xc_id_chat_right_net_progress_bar = holder.xc_id_chat_right_net_progress_bar;
        if (XC_ChatModel.SEND_NOT.equals(model.getIsSendSuccess())) {
            // 未发送，仅之前从未发送过的信息有一次这样的状态
            UtilViewShow.setGone(true, xc_id_chat_right_net_layout);
            UtilViewShow.setGone(true, xc_id_chat_right_net_progress_bar);
            UtilViewShow.setGone(false, xc_id_chat_right_net_fail_hint_imageview);
            model.setIsSendSuccess(XC_ChatModel.SEND_ING);
        } else if (XC_ChatModel.SEND_ING.equals(model.getIsSendSuccess())) {
            // 发送中的状态
            UtilViewShow.setGone(true, xc_id_chat_right_net_layout);
            UtilViewShow.setGone(true, xc_id_chat_right_net_progress_bar);
            UtilViewShow.setGone(false, xc_id_chat_right_net_fail_hint_imageview);
        } else if (XC_ChatModel.SEND_SUCCESS.equals(model.getIsSendSuccess())) {
            // 发送成功
            UtilViewShow.setGone(false, xc_id_chat_right_net_layout);
            UtilViewShow.setGone(false, xc_id_chat_right_net_progress_bar);
            UtilViewShow.setGone(false, xc_id_chat_right_net_fail_hint_imageview);
        } else if (XC_ChatModel.SEND_FAIL.equals(model.getIsSendSuccess())) {
            // 发送失败
            UtilViewShow.setGone(true, xc_id_chat_right_net_layout);
            UtilViewShow.setGone(false, xc_id_chat_right_net_progress_bar);
            UtilViewShow.setGone(true, xc_id_chat_right_net_fail_hint_imageview);
        }
    }
    /**
     * 显示医生头像，根据医生的认证状态设置
     */
    private void showDoctorHead(XC_ChatRightBaseHolder holder) {
        if (UtiDoctorCheck.isVertify()) {
            // 认证了，显示上传的头像
            String url = UtilSP.getUserHeaderImage();
            if (UtilString.isBlank(url)) {
                holder.xc_id_adapter_right_head.setImageResource(R.mipmap.sx_d_identity_personal_head_icon_v2);
            } else {
                XCApplication.displayImage(url, holder.xc_id_adapter_right_head, XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.sx_d_identity_personal_head_icon_v2));
            }
        } else {
            // 未认证，显示本地的默认图像
            holder.xc_id_adapter_right_head.setImageResource(R.mipmap.sx_d_identity_personal_head_icon_v2);
        }
    }

    /* 更改宣教阅读状态 */
    public void updateEduReadStatus(YM_PushModel updateEduModel){
        for (XC_ChatModel chatModel : getList()){
            if (updateEduModel.getMessageId().equals(chatModel.getMessageId())){
                chatModel.getChatModelEdu().setEduReadStatus(XC_ChatModel.READED);
                break;
            }
        }
        notifyDataSetChanged();
    }
    private static final int COMPARE_NUM = 7;
    /** 比较是否是同一个model */
    public boolean containsSameModel(XC_ChatModel checkModel) {

        if (checkModel != null && getList() != null) {

            String msgUnique = checkModel.getMsgUnique();

            if (!UtilString.isBlank(msgUnique)) {
                // 如果msgUnique不为空
                List<XC_ChatModel> list = getList();

                int size = list.size();

                if (size <= COMPARE_NUM) {
                    for (XC_ChatModel model : list) {
                        if (msgUnique.equals(model.getMsgUnique())) {
                            return true;
                        }
                    }
                } else {
                    for (int index = size - 1; index > size - COMPARE_NUM; index--) {
                        XC_ChatModel model = list.get(index);
                        if (msgUnique.equals(model.getMsgUnique())) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /** 更改撤销状态 */
    public void updateCancelStatus(XC_ChatModel model){
        model.setCancelFlag("1");
        notifyDataSetChanged();
    }

    /**
     * 匹配带有链接的字符串
     * @param content
     */
    private void patternContent(String content,XC_ChatModel chatModel){
        String url = "";
        String startStr = "href='";
        String endStr = "'>";
        Pattern pattern = Pattern.compile("<a(?: [^>]*)+href=([^ >]*)(?: [^>]*)*>");
        Matcher matcher = pattern.matcher(content);
        while (matcher.find()){
            String string = matcher.group();
            int index_start = string.indexOf(startStr) + startStr.length();
            int index_end = string.indexOf(endStr);
            url = string.substring(index_start,index_end);
            if (context instanceof XCBaseActivity){
                NativeHtml5.newInstance((XCBaseActivity)context).webToAppPage(url,1,chatModel);
            }
        }

    }

    /**
     * 病历页卡片针对部分文字颜色进行修改
     * @param part1 需要改变颜色的文字
     * @param part2 不需要改变颜色的文字
     */
    private SpannableString medicalRecordSpan(String part1, String part2){
        String content = part1.concat(part2);
        SpannableString spanString = new SpannableString(content);
        // 高亮器
        ForegroundColorSpan color_span = new ForegroundColorSpan(Color.parseColor("#7B7B7B"));
        spanString.setSpan(color_span, 0, part1.length(), SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spanString;
    }

    /** 动态修改病历处方作废的信息 */
    private void updateMedicalInvalidMsg(XC_ChatRighMedicalRecordHolder holder, XC_ChatModel model){
        String content = "";
        int w = 0;
        int h = UtilScreen.dip2px(context,23);
        String again;
        String type = model.getInvalid();
        ChatModelMedicalRecord medicalRecord = model.getChatModelMedicalRecord();
        switch (type){
            case "0":
                again = "续方";
                break;
            case "1"://处方作废
                content = "已作废处方";
                again = "重新修改处方";
                w = UtilScreen.dip2px(context,83);
                break;
            case "2"://病历作废
                content = "已作废病历";
                again = "续方";
                w = UtilScreen.dip2px(context,83);
                break;
            case "3"://处方病历作废
                content = "已作废病历和处方";
                again = "重新修改处方";
                w = UtilScreen.dip2px(context,120);
                break;
            default:
                again = "续方";
        }
        holder.medicine_invalid_tv.getLayoutParams().width = w;
        holder.medicine_invalid_tv.getLayoutParams().height = h;
        holder.medicine_invalid_tv.setText(content);
        holder.id_right_patient_medicine_recommend_again.setText(again);

        if ("1".equals(type) || "2".equals(type) || "3".equals(type)){
            UtilViewShow.setGone(true,holder.medicine_invalid_tv);
        }else {
            UtilViewShow.setGone(false,holder.medicine_invalid_tv);
        }
        //当处方作废时候不显示审核信息，当没有审核信息时候也不显示
        if ("1".equals(type) || "2".equals(type) || "3".equals(type) || UtilString.isBlank(medicalRecord.getCheckingStatus()) || medicalRecord.isMedicineStatusDefault()){
            UtilViewShow.setGone(false,holder.check_layout);
        }else {
            UtilViewShow.setGone(true,holder.check_layout);
        }
    }
    /** 动态修改处方作废的信息 */
    private void updateMedicineInvalidMsg(XC_ChatRightMedicineRecommandHolder holder, XC_ChatModel model){
        String content = "";
        int w = 0;
        int h = UtilScreen.dip2px(context,23);
        String again;
        String type = model.getInvalid();
        switch (type){
            case "0":
                again = "续方";
                break;
            case "1"://处方作废
                content = "已作废处方";
                again = "重新修改处方";
                w = UtilScreen.dip2px(context,83);
                break;
            case "2"://病历作废
                content = "已作废病历";
                again = "续方";
                w = UtilScreen.dip2px(context,83);
                break;
            case "3"://处方病历作废
                content = "已作废病历和处方";
                again = "重新修改处方";
                w = UtilScreen.dip2px(context,120);
                break;
            default:
                again = "续方";
        }
        holder.medicine_invalid_tv.getLayoutParams().width = w;
        holder.medicine_invalid_tv.getLayoutParams().height = h;
        holder.medicine_invalid_tv.setText(content);
        holder.id_right_patient_medicine_recommend_again.setText(again);

        if ("1".equals(type) || "2".equals(type) || "3".equals(type)){
            UtilViewShow.setGone(true,holder.medicine_invalid_tv);
        }else {
            UtilViewShow.setGone(false,holder.medicine_invalid_tv);
        }
        //当处方作废时候不显示审核信息，当没有审核信息时候也不显示
        if ("1".equals(type) || "2".equals(type) || "3".equals(type)|| UtilString.isBlank(model.getRecommandStatus()) || model.isMedicineStatusDefault()){
            UtilViewShow.setGone(false,holder.check_layout);
        }else {
            UtilViewShow.setGone(true,holder.check_layout);
        }
    }

}