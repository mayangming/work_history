package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.R;
import com.qlk.ymz.model.SX_MedicalRecordsInfo;
import com.qlk.ymz.util.ToJumpHelp;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.ArrayList;

/**
 * SX_PatientChatPhotoShowAdapter
 * 聊天图片显示
 * @author songxin on 2016/5/3.
 * @version 2.5.0
 */
public class SX_MedicalRecirdsPhotoShowAdapter extends BaseAdapter {
    private ArrayList<String> mPictures;
    /** 上下文*/
    private Context mContext;
    /** LayoutInflater*/
    private LayoutInflater mInflater;
    private SX_MedicalRecordsInfo info = new SX_MedicalRecordsInfo();
    private DisplayImageOptions options_big;

    public void setInfo(SX_MedicalRecordsInfo info) {
        if (null == info){
            info = new SX_MedicalRecordsInfo();
        }
        this.info = info;
    }

    public SX_MedicalRecirdsPhotoShowAdapter(Context context, ArrayList<String> pictures){
        this.mPictures = pictures;
        this.mContext = context;
        mInflater = LayoutInflater.from(context);
        options_big = XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.bg_pic_default);
    }
    @Override
    public int getCount() {
        return mPictures.size();
    }

    @Override
    public Object getItem(int position) {
        return mPictures.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (null == viewHolder) {
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.xl_item_pic, null);
            viewHolder.iv = (ImageView) convertView.findViewById(R.id.iv);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        //(0:为医生添加，1：为患者上传 ,2：系统处方添加)
        if ("2".equals(info.getSource())){
            //防止处方图片出现显示不全(这个图片底色也是白的)
            viewHolder.iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        }else{
            viewHolder.iv.setScaleType(ImageView.ScaleType.CENTER);
        }
        XCApplication.base_imageloader.displayImage(mPictures.get(position), viewHolder.iv, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.bg_pic_default)); // edit by xjs on 20151105-11:33

        viewHolder.iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //(0:为医生添加，1：为患者上传 ,2：系统处方添加)
                if ("2".equals(info.getSource()) && !UtilString.isBlank(info.getRecommandId()) && !UtilString.isBlank(info.getPatientId())){
                    ToJumpHelp.toJumpRecommendDetailActivity(mContext, info.getRecommandId(), info.getPatientId());
                }else{
                    ToJumpHelp.toJumpChatImageShowActivity(mContext, mPictures, position);
                }
            }
        });
        return convertView;
    }

    static class ViewHolder{
        /** 图片显示*/
        ImageView iv;
    }

}
