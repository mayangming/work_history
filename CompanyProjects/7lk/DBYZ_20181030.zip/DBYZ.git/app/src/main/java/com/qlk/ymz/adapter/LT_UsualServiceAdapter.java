package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.db.im.chatmodel.ChatModelCustomAdvisory;
import com.qlk.ymz.view.SwipeLayout.SwipeLayoutAdapter;
import com.qlk.ymz.view.SwipeLayout.SwipeOnTouchListener;
import com.qlk.ymz.view.SwipeLayout.SwipeViewHolder;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import java.util.ArrayList;

/**
 * @author 李涛
 * @description  我的常用服务适配
 * @Date 2017/12/13.
 */


public class LT_UsualServiceAdapter extends SwipeLayoutAdapter {

    /**删除的接口 在Activity页面调用*/
    private  DeleteItemInterface  deleteItemInterface;
    /**正文内容点击的接口 在Activity页面调用*/
    private  OnlickContent onlickContent;
    ArrayList<ChatModelCustomAdvisory>  beanData = new ArrayList<>();
    public LT_UsualServiceAdapter(Context context, int parentResourceId, int contentViewResourceId, int actionViewResourceId, int contentWidth, int itemWidth) {
        super(context, parentResourceId, contentViewResourceId, actionViewResourceId, contentWidth, itemWidth);
    }

    public void update(ArrayList<ChatModelCustomAdvisory>  beanData){
        this.beanData = beanData;
        notifyDataSetChanged();
    }

    @Override
    public void setContentView(View contentView, int position, HorizontalScrollView parent) {}

    @Override
    public void setContentView(View contentView, final int position, HorizontalScrollView parent, SwipeViewHolder holder, SwipeOnTouchListener swipeOnTouchListener) {
          ContentHodler hodler;
        hodler = (ContentHodler) contentView.getTag();
        if(hodler==null){
            hodler = new ContentHodler();
            hodler.lt_item_usual_serviec_content = (LinearLayout) contentView.findViewById(R.id.lt_item_usual_serviec_content);
            hodler.lt_item_usual_serviec_name  = (TextView) contentView.findViewById(R.id.lt_item_usual_serviec_name);
            hodler.lt_item_usual_serviec_price  = (TextView) contentView.findViewById(R.id.lt_item_usual_serviec_price);
            hodler.lt_item_usual_serviec_about  = (TextView) contentView.findViewById(R.id.lt_item_usual_serviec_about);
            contentView.setTag(hodler);
        }else {
            hodler = (ContentHodler) contentView.getTag();
        }
        hodler.lt_item_usual_serviec_name.setText(beanData.get(position).getCustomAdvisoryName());
        long price = UtilString.toLong(beanData.get(position).getCustomPrice())/100;
        hodler.lt_item_usual_serviec_price.setText(price+"元");
        if(!TextUtils.isEmpty(beanData.get(position).getCustomProductDesc())){
            UtilViewShow.setGone(true,hodler.lt_item_usual_serviec_about);
            hodler.lt_item_usual_serviec_about.setText("服务简介："+beanData.get(position).getCustomProductDesc());
        }else{
            UtilViewShow.setGone(false,hodler.lt_item_usual_serviec_about);
        }

        hodler.lt_item_usual_serviec_content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onlickContent.Onclick(position);
            }
        });
    }

    @Override
    public void setActionView(View actionView, final int position, HorizontalScrollView parent) {
        ActionHolder actionholder;
        actionholder = (ActionHolder) actionView.getTag();
        if(actionholder==null){
            actionholder = new ActionHolder();
            actionholder.tv_deleteBtn = (TextView) actionView.findViewById(R.id.lt_tv_deleteBtn);
            actionView.setTag(actionholder);
        }else{
            actionholder = (ActionHolder) actionView.getTag();
        }
        //删除按钮
        actionholder.tv_deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItemInterface.delete(position);
            }
        });
    }



    /**正文内点击效果*/
    public void contentClick(OnlickContent onlickContent){
                    this.onlickContent = onlickContent;
    }

    /**侧滑删除*/
    public  void deleteItem(DeleteItemInterface  deleteItemInterface){
        this.deleteItemInterface = deleteItemInterface;
    }

    public interface  DeleteItemInterface{
        void  delete(int position);
    }


    public interface OnlickContent{
        void Onclick(int position);
    }


    @Override
    public int getCount() {
        return beanData.size()>0?beanData.size():0;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    /**正文内容*/
    public     class ContentHodler{
        private LinearLayout lt_item_usual_serviec_content;
        private TextView lt_item_usual_serviec_name;
        private   TextView lt_item_usual_serviec_price;
        private TextView lt_item_usual_serviec_about;
    }

    /**侧滑列表*/
    public class ActionHolder{
        //删除按钮
        TextView tv_deleteBtn;
    }

}
