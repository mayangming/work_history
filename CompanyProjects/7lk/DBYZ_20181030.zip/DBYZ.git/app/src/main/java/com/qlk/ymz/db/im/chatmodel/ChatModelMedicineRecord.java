package com.qlk.ymz.db.im.chatmodel;

import java.io.Serializable;


/**
 * description: 存储链接消息的类型
 * autour: YM
 * date: 2018/5/28
 * version:
 * 注释:
 * 返回的数据是一个集合类型。但是集合里面的内容会显示在一个消息里面。
 * 由 displayNum 决定集合中的数据显示顺序，数字越小，显示越靠前
 * 示例：
 * content =     {
 text = "\U67e5\U8be2\U5230\U60a3\U8005\U6700\U8fd1\U7684\U4e00\U4efd\U75c5\U5386\U8bb0\U5f55(2018\U5e7407\U670803\U65e5)<br><a href=‘{\”K\”:\”待定\”,\”V\”:\”待定\”,\”params\”:[{待定]}’><font color='#33b5e5'>\U70b9\U51fb\U8fd9\U91cc\U7acb\U5373\U67e5\U770b</font></a>";
 };
 *
 */

public class ChatModelMedicineRecord implements Serializable, Cloneable {
    private String text = "";//消息文本
    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
