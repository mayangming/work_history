package com.qlk.ymz.db.im.chatmodel;

import com.qlk.ymz.model.ExamineBean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * description: 健康体检
 * autour: YM
 * date: 2017/10/19
 */

public class ChatModelCheckHealth implements Serializable,Cloneable{
    private List<ExamineBean> examineBeanList = new ArrayList<>();
    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<ExamineBean> getExamineBeanList() {
        return examineBeanList;
    }

    public void setExamineBeanList(List<ExamineBean> examineBeanList) {
        this.examineBeanList = examineBeanList;
    }
}