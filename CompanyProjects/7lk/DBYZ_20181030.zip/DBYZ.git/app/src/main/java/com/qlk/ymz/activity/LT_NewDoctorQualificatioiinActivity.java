package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.fragment.XCCameraPhotoFragment;

import java.io.File;
/**
 * @author 李涛
 * @description 新版医生资格证页面
 * @Date 2017/11/21.
 */
public class LT_NewDoctorQualificatioiinActivity extends DBActivity implements XCCameraPhotoFragment.OnCaremaSelectedFileListener {

    private XCTitleCommonLayout lt_id_dq_titlebar;
    /**
     * 医生合法备案状态（0 未申请备案; 1 备案审核中;2 备案成功; 3 备案失败; 4 要求备案）
     */
    private String viewFlag;
    /**证书展示*/
    private RelativeLayout lt_id_upload_doctor_practice_certificate_new_rl;
    private ImageView lt_image_show;
    /**证书删除*/
    private ImageView lt_image_delete;
    /**提交布局*/
    private RelativeLayout lt_commit_view;
    /**提交布局文本*/
    private TextView lt_commit_text;
    private XCCameraPhotoFragment cameraPhotoFragment;
    //相册相机或者是上页面传来的返的照片File
    private File imageFile;

    /**
     * 上传文件弹出Dialog
     */
    private ConfirmDialog mUploadDialog;
    private TextView xc_id_pop_photoUpload;//照相机
    private TextView xc_id_pop_localAlbum;//图库
    private TextView xc_id_pop_cancel;//取消
    //跳转大图页面
    private Intent intent;
    private Intent backintent;

    private Handler handler =   new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lt__new_doctor_qualificatioiin);
        super.onCreate(savedInstanceState);
        initView();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(LT_NewDoctorQualificatioiinActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */


    private void initView() {
        //获取上页传来的数据
        backintent = getIntent();
        imageFile = (File) backintent.getSerializableExtra("newfile");

        //刚进入该页面的时候 如果携带数据我们就让他底部提交按钮置灰  修改完数据后变得可点击操作   （使用延迟操作是应为该页面有一个Editext的监听）
        //(如果数据不为空说明 1 有后台操作上传一部分数据  2是审核状态    3是审核失败状态  提交按钮都是置灰不可点击的)
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(imageFile!=null){
                    lt_commit_text.setTextColor(getResources().getColor(R.color.c_login_text_bg));
                    lt_commit_view.setEnabled(false);
                }
            }
        },100);


        initDialog();
        viewFlag = UtilSP.getDoctorStatus();
        if("4".equals(viewFlag)){
            viewFlag ="0";
        }
        switch (viewFlag){
            //未审核
            case "0":
            if(imageFile!=null){
                lt_image_show.setImageURI(Uri.fromFile(imageFile));
                lt_image_show.setVisibility(View.VISIBLE);
                lt_image_delete.setVisibility(View.VISIBLE);
            }

             break;
                //审核中
            case "1":
                //提交按钮失去焦点
                if(imageFile!=null){
                    lt_commit_view.setEnabled(false);
                    lt_commit_text.setTextColor(getResources().getColor(R.color.c_login_text_bg));
                    lt_image_show.setVisibility(View.VISIBLE);
                    lt_image_delete.setVisibility(View.GONE);
                    lt_image_show.setImageURI(Uri.fromFile(imageFile));
                }

                break;
                //审核失败
            case "3":
                if(imageFile!=null){
                    lt_commit_view.setEnabled(false);
                    lt_commit_text.setTextColor(getResources().getColor(R.color.c_login_text_bg));
                    lt_image_show.setVisibility(View.VISIBLE);
                    lt_image_show.setImageURI(Uri.fromFile(imageFile));
                    lt_image_delete.setVisibility(View.VISIBLE);
                }
                break;
        }


    }

    @Override
    public void initWidgets() {
        intent = new Intent();
        //设置Title
        lt_id_dq_titlebar = (XCTitleCommonLayout) findViewById(R.id.lt_newdoctorqf_titlebar);
        lt_id_dq_titlebar.setTitleLeft(true,"");
        lt_id_dq_titlebar.setTitleCenter(true,"新版医师资格证");

        //添加相机相册布局
        cameraPhotoFragment = new XCCameraPhotoFragment();
        addFragment(R.id.lt_id_openshop_camera_rl, cameraPhotoFragment);

        lt_id_upload_doctor_practice_certificate_new_rl = (RelativeLayout) findViewById(R.id.lt_id_upload_doctor_practice_certificate_new_rl);
        lt_image_show = (ImageView) findViewById(R.id.lt_id_upload_doctor_practice_certificate_new_show);
        lt_image_delete = (ImageView) findViewById(R.id.lt_id_delete_doctor_practice_certificate_new);
        lt_commit_view = (RelativeLayout) findViewById(R.id.lt_id_doctor_practice_certificate_new_submit_authentication_rl);
        lt_commit_text = (TextView) findViewById(R.id.lt_id_save_text);
    }

    @Override
    public void listeners() {
        lt_id_upload_doctor_practice_certificate_new_rl.setOnClickListener(this);
        lt_image_show.setOnClickListener(this);
        lt_image_delete.setOnClickListener(this);
        lt_commit_view.setOnClickListener(this);

        cameraPhotoFragment.setOnCaremaSelectedFileListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            //图片布局
            case  R.id.lt_id_upload_doctor_practice_certificate_new_rl:
                uploadDialogShow();
                break;
            //图片点击
            case  R.id.lt_id_upload_doctor_practice_certificate_new_show:
                startShowPictureActivity(imageFile.getAbsolutePath(),"医师资格证",0);
                break;
                //删除图片点击
            case  R.id.lt_id_delete_doctor_practice_certificate_new:
                imageFile = null;
                lt_image_show.setImageURI(null);
                lt_image_delete.setVisibility(View.GONE);
                lt_image_show.setVisibility(View.GONE);
                //控制提交按钮的可点击事件
                lt_commit_view.setEnabled(true);
                CheckButton();
                break;
                //提交按钮
            case  R.id.lt_id_doctor_practice_certificate_new_submit_authentication_rl:
                CheckData();
                break;
                //相机
            case  R.id.xc_id_pop_photoUpload:
                uploadDialogDismiss();
                cameraPhotoFragment.getTakePhoto();
                break;
                //相册
            case  R.id.xc_id_pop_localAlbum:
                uploadDialogDismiss();
                ToJumpHelp.toJumpSelctImgsActivity(this, 1, YY_SelectImgsActivity.MODE_SINGLE,
                        false, true, false, true);
                break;
                //取消z
            case  R.id.xc_id_pop_cancel:
                uploadDialogDismiss();
                break;
        }

    }

    /**
     * 相机返回照片
     * @param file
     */
    @Override
    public void onCaremaSelectedFile(File file) {
            if(file!=null){
                imageFile = file;
                lt_image_show.setVisibility(View.VISIBLE);
                lt_image_delete.setVisibility(View.VISIBLE);
                lt_image_show.setImageURI(Uri.fromFile(file));
                CheckButton();
            }
    }

    private void CheckData(){
        if(imageFile==null){
            shortToast("你好像还没有上传图片");
            return;
         } else{
                backintent.putExtra("backNewImage",imageFile);
                setResult(RESULT_OK,backintent);
                finish();
            }
        }

    //修改提交按钮状态
    private void CheckButton(){
        lt_commit_view.setEnabled(true);
        if(imageFile!=null){
            lt_commit_text.setTextColor(getResources().getColor(R.color.c_e2231a));
        }else{
            lt_commit_text.setTextColor(getResources().getColor(R.color.c_login_text_bg));
        }
    }




    private void uploadDialogDismiss(){
        if(null != mUploadDialog && mUploadDialog.isShowing()){
            mUploadDialog.dismiss();
        }
    }

    private void uploadDialogShow(){
        if(null != mUploadDialog && !mUploadDialog.isShowing()){
            mUploadDialog.show();
        }
    }



    /**
     * 显示大图页
     * @param filepath  图片路径
     * @param filename 图片标题
     * @param flag 显示的方式（网络1、本地0）
     */
    private void startShowPictureActivity(String filepath,String filename,int  flag){
        intent.setFlags(flag);
        intent.putExtra("FILE_PATH", filepath);
        intent.putExtra("PICTURE_NAME", filename);
        intent.setClass(LT_NewDoctorQualificatioiinActivity.this,SX_ShowPictureActivity.class);
        myStartActivity(intent);
    }


    /**
     * dialog初始化
     */
    private void initDialog(){
        int srceenW =  this.getWindowManager().getDefaultDisplay().getWidth();
        mUploadDialog = new ConfirmDialog(LT_NewDoctorQualificatioiinActivity.this, srceenW,245
                , R.layout.xc_l_pop_window_photo,R.style.xc_s_dialog);
        mUploadDialog.setCanceledOnTouchOutside(false);
        Window window = mUploadDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        xc_id_pop_photoUpload = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_photoUpload);
        xc_id_pop_localAlbum = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_localAlbum);
        xc_id_pop_cancel = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_cancel);
        xc_id_pop_photoUpload.setOnClickListener(this);
        xc_id_pop_localAlbum.setOnClickListener(this);
        xc_id_pop_cancel.setOnClickListener(this);
    }




    @Override
    public void onNetRefresh() {}


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        //用户选择图片完成 add by xd 2017/11/27
        if (requestCode == YY_SelectImgsActivity.REQUEST_IMAGE) {
            if (data == null || data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT) == null) {
                return;
            }
            File file = (File) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
            if (file != null) {
                File toUploadFile = UtilFile.ChangeImgsToUploadFile(file);//压缩图片
                imageFile = toUploadFile;
                lt_image_show.setVisibility(View.VISIBLE);
                lt_image_delete.setVisibility(View.VISIBLE);
                lt_image_show.setImageURI(Uri.fromFile(toUploadFile));
                CheckButton();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(null);
    }
}
