package com.qlk.ymz.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.qlk.ymz.R;
import com.qlk.ymz.parse.Parse2PublicityBean;
import com.qlk.ymz.view.SwipeLayout.SwipeLayoutAdapter;
import com.qlk.ymz.view.SwipeLayout.SwipeOnTouchListener;
import com.qlk.ymz.view.SwipeLayout.SwipeViewHolder;
import java.util.ArrayList;

/**
 * @author 李涛
 * @description   我的宣教列表适配器
 * @Date 2017/3/28.
 */


public class LT_PublicityAdpter extends SwipeLayoutAdapter {
    private  Context context;
    /**列表数据*/
    private ArrayList<Parse2PublicityBean> dataList = new ArrayList<>();
    /**内容监听*/
    public  ContentViewClick contentViewClick;
    /**发送按钮*/
    public onClickSendButton sendButton;
    /**删除监听*/
    public deleteContent deletecontent;

    public LT_PublicityAdpter(Context context,int contentView,int actionView,ArrayList<Parse2PublicityBean> dataList) {
        super(context,contentView,actionView,dataList);
        this.context = context;
        this.dataList = dataList;
    }

    public void updateList(ArrayList<Parse2PublicityBean> dataList){
         this.dataList = dataList;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return dataList.size()>0? dataList.size():0;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public void setContentView(View contentView, int position, HorizontalScrollView parent) {}

    @Override
    public void setContentView(View contentView, final int position, HorizontalScrollView parent, final SwipeViewHolder holder, final SwipeOnTouchListener swipeOnTouchListener) {
        ContentHolder contentholder;
        contentholder = (ContentHolder) contentView.getTag();
        if(contentholder==null){
            contentholder = new ContentHolder();
            contentholder.ll_content = (LinearLayout) contentView.findViewById(R.id.ll_content_view);
            contentholder.title = (TextView) contentView.findViewById(R.id.tv_advocate_title);
            contentholder.source = (TextView) contentView.findViewById(R.id.tv_advocate_source);
            contentholder.send = (Button) contentView.findViewById(R.id.iv_advocate_send);
            contentView.setTag(contentholder);
        }else{
            contentholder = (ContentHolder) contentView.getTag();
        }

        contentholder.title.setText(dataList.get(position).getEduTitle());
        contentholder.source.setText(dataList.get(position).getEduOrigin());
        contentholder.send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //初始化侧滑布局的位置
                holder.hSView.smoothScrollTo(0,0);
                sendButton.judgeIntent(dataList.get(position));
            }
        });
            //内容布局的监听
        contentholder.ll_content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //初始化侧滑布局的位置
                holder.hSView.smoothScrollTo(0,0);
                contentViewClick.onclick(dataList.get(position));
            }
        });
    }

    @Override
    public void setActionView(final View actionView, final int position, HorizontalScrollView parent) {
         ActionHolder  actionholder;
        actionholder = (ActionHolder) actionView.getTag();
        if(actionholder==null){
            actionholder = new ActionHolder();
            actionholder.tv_deleteBtn = (TextView) actionView.findViewById(R.id.tv_deleteBtn);
            actionholder.tv_topBtn = (TextView) actionView.findViewById(R.id.tv_topBtn);
            actionholder.tv_noDisturbingBtn = (TextView) actionView.findViewById(R.id.tv_noDisturbingBtn);
            actionView.setTag(actionholder);
            }else{
            actionholder = (ActionHolder) actionView.getTag();
        }
        //gone掉不需要的控件
        actionholder.tv_noDisturbingBtn.setVisibility(View.GONE);
        actionholder.tv_topBtn.setVisibility(View.GONE);
        //删除按钮
        actionholder.tv_deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deletecontent.delete(position);
            }
        });

    }


    /**正文内容*/
    class ContentHolder{
        //最外层布局
        LinearLayout ll_content;
        //标题
        TextView  title;
        //来源
        TextView  source;
        //发送按钮
        Button  send;
    }

    /**侧滑列表*/
    class ActionHolder{
        //置顶按钮（未用）
        TextView tv_topBtn;
        //免打扰按钮（未用）
        TextView tv_noDisturbingBtn;
        //删除按钮
        TextView tv_deleteBtn;
    }
    //删除按钮的监听
    public  void  deleteContentClick(deleteContent deletecontent){
        this.deletecontent = deletecontent;
    };

    //Item内容的监听
    public  void setOnViewClick(ContentViewClick contentViewClick){
        this.contentViewClick = contentViewClick;
    }

    //发送按钮  在activity里处理  send按钮的逻辑
    public  void setOnViewSend(onClickSendButton sendButton){
        this.sendButton = sendButton;
    }

    public   interface  onClickSendButton{
        void judgeIntent(Parse2PublicityBean sendData);
    }

    public interface ContentViewClick{
        void onclick(Parse2PublicityBean  contendData);
    }

    public  interface  deleteContent{
        void delete(int position);
    }

}
