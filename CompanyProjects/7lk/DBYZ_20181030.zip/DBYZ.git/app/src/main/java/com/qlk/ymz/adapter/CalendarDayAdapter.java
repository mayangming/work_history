package com.qlk.ymz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.XD_SignRecordActivity;
import com.qlk.ymz.model.PF_SignInBean;
import com.qlk.ymz.parse.Parse2MonthSignInBean;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.SP.UtilSP;

import java.util.List;

import static com.qlk.ymz.model.PF_SignInBean.DAY_TODAY;
import static com.qlk.ymz.model.PF_SignInBean.SIGNIN_NO;
import static com.qlk.ymz.model.PF_SignInBean.SIGNIN_OVER;
import static com.qlk.ymz.model.PF_SignInBean.SIGNIN_YEW;

/**
 * Created by xiedongtd on 2016/11/7.
 * 一个月每天的适配器
 */

public class CalendarDayAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context mContext;
    /** 签到数据*/
    private Parse2MonthSignInBean mParse2MonthSignInBean;
    /** 星期item*/
    public static final int WEEK = 1;
    /** 日历item*/
    public static final int DAY = 2;
    /** 当前年份*/
    private int currentYear;
    /** 当前月份*/
    private int currentMonth ;
    /** 第一天一周中的第几天*/
    private int weekday;
    private int showDays;
    private String[] weekString = new String[]{"一","二","三","四","五","六","日"};
    public CalendarDayAdapter(Context context){
        this.mContext = context;
    }

    @Override
    public int getItemViewType(int position) {
        if (position <7) {
            return WEEK;//星期title 类型
        } else {
            return DAY;//日历天类型
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(viewType == WEEK){
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.xd_item_calendar_week, parent,
                    false);
            return new WeekViewHolder(view);
        }else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.xd_item_calendar_day, parent, false);
            return new ViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        //星期几展示
        if(position<7){
            WeekViewHolder viewHolder = (WeekViewHolder) holder;
            viewHolder.tv_week.setText(weekString[position]);
        }else {
            //日历天展示
            ViewHolder viewHolder = (ViewHolder) holder;
            if(position<weekday-1+7||position>showDays+7-1){//1号前和月末后的空格
                viewHolder.tv_sign_date.setText("");
                viewHolder.tv_sign_data.setText("");
                viewHolder.itemView.setBackgroundResource(R.color.c_white_ffffff);
                viewHolder.itemView.setClickable(false);
            }else {//1号到月末
                viewHolder.tv_sign_date.setText(""+(position-weekday+2-7));
                if(mParse2MonthSignInBean!=null){//有签到数据
                    List<PF_SignInBean> signInBeanList = mParse2MonthSignInBean.getSignInBeanList();
                    final PF_SignInBean pf_signInBean = signInBeanList.get(position-weekday+1-7);
                    viewHolder.tv_sign_data.setText(pf_signInBean.getShowText());
                    viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            boolean isToday = false;
                            //如果签到的是今天,就关闭首页签到动画
                            if (PF_SignInBean.DAY_TODAY.equals(pf_signInBean.getIsToday())){
                                isToday = true;
                            }
                            //点击进行签到
                            XD_SignRecordActivity xd_signRecordActivity = (XD_SignRecordActivity) mContext;
                            xd_signRecordActivity.signIn(pf_signInBean.getDate(), isToday);
                        }
                    });
                    if(SIGNIN_YEW.equals(pf_signInBean.getType())){
                        //可签到
                        viewHolder.itemView.setClickable(true);
                        if (DAY_TODAY.equals(pf_signInBean.getIsToday())){
                            //是今天
                            viewHolder.itemView.setBackgroundResource(R.drawable.xd_dd_item_today_bg_selector);
                            viewHolder.tv_sign_date.setTextColor(mContext.getResources()
                                    .getColor(R.color.c_white_ffffff));
                            viewHolder.tv_sign_data.setTextColor(mContext.getResources()
                                    .getColor(R.color.c_white_ffffff));
                        }else {
                            viewHolder.itemView.setBackgroundResource(R.drawable.xd_dd_item_bg_selector);
                            viewHolder.tv_sign_date.setTextColor(mContext.getResources()
                                    .getColor(R.color.c_e2231a));
                            viewHolder.tv_sign_data.setTextColor(mContext.getResources()
                                    .getColor(R.color.c_e2231a));
                        }
                    }else if(SIGNIN_NO.equals(pf_signInBean.getType())){
                        //不可签到
                        viewHolder.itemView.setClickable(false);
                        viewHolder.itemView.setBackgroundResource(R.color.c_white_ffffff);
                        if(TextUtils.isEmpty(pf_signInBean.getShowText())){
                            viewHolder.tv_sign_date.setTextColor(mContext.getResources()
                                    .getColor(R.color.c_444444));
                        }else {
                            viewHolder.tv_sign_date.setTextColor(mContext.getResources()
                                    .getColor(R.color.c_gray_bbbbbb));
                            viewHolder.tv_sign_data.setTextColor(mContext.getResources()
                                    .getColor(R.color.c_gray_bbbbbb));
                        }
                    }else if(SIGNIN_OVER.equals(pf_signInBean.getType())){
                        //已签到
                        viewHolder.itemView.setClickable(false);
                        viewHolder.itemView.setBackgroundResource(R.color.c_gray_eeeeee);
                        viewHolder.tv_sign_date.setTextColor(mContext.getResources()
                                .getColor(R.color.c_444444));
                        viewHolder.tv_sign_data.setTextColor(mContext.getResources()
                                .getColor(R.color.c_7b7b7b));
                    }
                }else {//无签到数据
                    viewHolder.tv_sign_data.setText("");
                    viewHolder.itemView.setBackgroundResource(R.color.c_white_ffffff);
                }

            }

        }

    }

    /**
     * 给适配器绑定数据
     * @param currentYear 当前年份
     * @param currentMonth 当前月份
     * @param parse2MonthSignInBean 月份签到记录
     */
    public void bindData(int currentYear, int currentMonth, Parse2MonthSignInBean parse2MonthSignInBean){
        this.currentYear = currentYear;
        this.currentMonth = currentMonth;
        if(parse2MonthSignInBean!=null){
            this.mParse2MonthSignInBean = parse2MonthSignInBean;
        }
        notifyDataSetChanged();
    }


    @Override
    public int getItemCount() {
        //该月的天数
        int monthDays = DateUtils.getDateNum(currentYear, currentMonth);
        //第一天是周几
        weekday = DateUtils.getFirstDayOfWeek(currentYear,currentMonth);
        showDays = monthDays + weekday-1;
        int showRows = (int) Math.ceil(showDays / 7.0)+1;
        return showRows*7;
    }



    static class WeekViewHolder extends RecyclerView.ViewHolder {
        /** 星期数据*/
        TextView tv_week;

        public WeekViewHolder(View itemView) {
            super(itemView);
            tv_week = (TextView) itemView.findViewById(R.id.tv_week);
        }
    }
    static class ViewHolder extends RecyclerView.ViewHolder {
        /** 签到日期*/
        TextView tv_sign_date;
        /** 签到数据*/
        TextView tv_sign_data;

        View itemView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            tv_sign_date = (TextView) itemView.findViewById(R.id.tv_sign_date);
            tv_sign_data = (TextView) itemView.findViewById(R.id.tv_sign_data);
        }

    }


}
