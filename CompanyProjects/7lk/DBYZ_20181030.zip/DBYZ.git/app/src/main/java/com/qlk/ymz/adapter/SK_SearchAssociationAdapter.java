package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.SearchModel;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * @description 搜索关键词联想列表的适配器
 * @author      赖善琦
 * @version     2.0.0
 */
public class SK_SearchAssociationAdapter extends XCBaseAdapter<SearchModel> {

    /**
     * 构造器
     * @param context 上下文
     * @param list 数据集
     */
    public SK_SearchAssociationAdapter(Context context, List<SearchModel> list) {
        super(context, list);
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        SearchModel bean = list.get(i);
        ViewHolder viewHolder;
        if (view == null) {
            viewHolder = new ViewHolder();
            view = LayoutInflater.from(context).inflate(R.layout.sk_l_adapter_pop_search_item, null);
            viewHolder.sk_id_pop_search_tv = (TextView) view.findViewById(R.id.sk_id_pop_search_tv);
            viewHolder.sk_id_medicine_target_name = (TextView) view.findViewById(R.id.sk_id_medicine_target_name);
            viewHolder.sk_id_medicine_drcommission = (TextView) view.findViewById(R.id.sk_id_medicine_target_value);
            viewHolder.sk_id_medicine_drcommission_ll = (LinearLayout)view.findViewById(R.id.sk_id_medicine_drcommission_ll);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        if(!UtilString.isBlank(bean.getName())) {
            viewHolder.sk_id_pop_search_tv.setText(bean.getName());
        }

        if ("1".equals(bean.getShowCommission())){
            viewHolder.sk_id_medicine_target_name.setText("小七指数:");
            // 小七指数
            if(!TextUtils.isEmpty(bean.getDrCommission()) && !"0".equals(bean.getDrCommission())){
                viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.VISIBLE);
                viewHolder.sk_id_medicine_drcommission.setText(bean.getDrCommission());
            }else{
                viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.GONE);
            }
        }else if ("2".equals(bean.getShowCommission())){
            viewHolder.sk_id_medicine_target_name.setText("市场积分:");
            // 市场积分
            if(!TextUtils.isEmpty(bean.getMarketPoint())){
                viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.VISIBLE);
                viewHolder.sk_id_medicine_drcommission.setText(bean.getMarketPoint());
            }else{
                viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.GONE);
            }
        }else{
            viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.GONE);
        }
        return view;
    }

    class ViewHolder {
        TextView sk_id_pop_search_tv;
        TextView sk_id_medicine_target_name;
        TextView sk_id_medicine_drcommission;
        LinearLayout sk_id_medicine_drcommission_ll;
    }
}