package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.maintab.YR_PatientFragment;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.receiver.XC_ChatReceiver;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * description: 显示聊天设置的页面，现在里面有聊天图片、聊天记录、聊天设置三个功能
 * author: YM
 * date: 2017/5/9
 * update: $date$
 * version: 2.8
 * update: 2018/6/22
 * version: 2.19
 * description:添加删除患者功能
 */

public class YM_ChatSettingActivity extends DBActivity{
    private View chat_setting_root,chat_setting_photo,chat_setting_record,chat_setting,chat_patient_info,chat_del;
    private View chat_setting_window;//气泡框
    private XC_ChatModel patientInfo;//患者信息
    private String fromTag;//如果是聊天页面显示患者病历，如果是病历详情则隐藏病历
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.ym_activity_chat_setting);
        initData();
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YM_ChatSettingActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */

    @Override
    public void initWidgets() {
        chat_setting_root = getViewById(R.id.chat_setting_root);
        chat_setting_photo = getViewById(R.id.chat_setting_photo);
        chat_setting_record = getViewById(R.id.chat_setting_record);
        chat_setting = getViewById(R.id.chat_setting);
        chat_patient_info = getViewById(R.id.chat_patient_info);
        chat_setting_window = getViewById(R.id.chat_setting_window);
        chat_del = getViewById(R.id.chat_del);
        UtilViewShow.setGone(CommonConfig.CHAT_SETTING_FROM_CHAT.equals(fromTag),chat_patient_info);
        setSettingWindow();
    }

    /* 设置窗口大小 */
    private void setSettingWindow(){
        chat_setting_window.getLayoutParams().height = CommonConfig.CHAT_SETTING_FROM_CHAT.equals(fromTag) ? UtilScreen.dip2px(this,220): UtilScreen.dip2px(this,170);
    }

    @Override
    public void listeners() {
        chat_setting_root.setOnClickListener(this);
        chat_setting_photo.setOnClickListener(this);
        chat_setting_record.setOnClickListener(this);
        chat_setting.setOnClickListener(this);
        chat_patient_info.setOnClickListener(this);
        chat_del.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {

    }

    /* 初始化数据 */
    private void initData(){
        patientInfo = (XC_ChatModel) getIntent().getSerializableExtra(CommonConfig.CHAT_SETTING_PATIENT_INFO);
        fromTag =  getIntent().getStringExtra(CommonConfig.CHAT_SETTING_FROM);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.chat_setting_root:
                myFinish();
                break;
            case R.id.chat_setting_photo:
                ToJumpHelp.toJumpChatPhotoActivity(this,patientInfo.getUserPatient().getPatientId());
                myFinish();
                break;
            case R.id.chat_setting_record:
                ToJumpHelp.toJumpChatRecordActivity(this,patientInfo);
                myFinish();
                break;
            case R.id.chat_setting:
                ToJumpHelp.toJumpChatSettingActivity(this,patientInfo);
                break;
            case R.id.chat_patient_info:
                ToJumpHelp.toJumpChatPatientInfoActivity(this,patientInfo);
                myFinish();
                break;
            case R.id.chat_del:
                initDeletePatientDialog();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(0, R.anim.xc_anim_alpha);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        // 快捷回复
        if (requestCode == CommonConfig.REQUEST_CODE_CHAT_SETTING) {
            setNewPrice(data);
        }
        myFinish();
    }

    /* 设置新的咨询价格 */
    private void setNewPrice(Intent intent){
        setResult(RESULT_OK,intent);
    }

    /**
     * 删除患者
     * 先请求服务器删除患者，成功后再删除本地患者数据，
     * 服务器删除失败，本地不删除
     */
    private void delPatient(){
        final String patientId = patientInfo.getUserPatient().getPatientId();

        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("patientId", patientId);

        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.DELETE_PATIENT), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                    if (result_boolean) {
                        shortToast("删除成功");
                        int raw = JS_ChatListDB.getInstance(getApplicationContext(), UtilSP.getUserId()).delPatientByPatientId(patientId);
                        if (raw > 0) {
                            int patientCount = UtilString.toInt(UtilSP.getPatientSum(), 1);
                            patientCount -= 1;//每次删除一个患者
                            UtilSP.setPatientSum(patientCount + "");
                        }
                        reset(patientId);//删除新患者sp中相应的id
                        //发送广播给患者列表页，刷新页面
                        Intent intent = new Intent();
                        intent.setAction(YR_PatientFragment.REFRESH_ACTION);
                        sendBroadcast(intent);
                        ToJumpHelp.toJumpHomeFragment(YM_ChatSettingActivity.this,UtilSP.getDelFrom());
//                        ToJumpHelp.toJumpHomeFragment(YM_ChatSettingActivity.this);
                        //遵循原则是从哪来回哪去
//                        setResult(CommonConfig.CHAT_SETTING_DEL);
//                        myFinish();
//                        Intent delReceiver = new Intent();
//                        delReceiver.setAction(CommonConfig.DEL_PATIENT_ACTION);
//                        getApplicationContext().sendBroadcast(delReceiver);

                    }
            }

            @Override
            public void fail() {

            }
        });

    }

    @Override
    public void myFinish() {
        super.myFinish();
        overridePendingTransition(0, R.anim.xc_anim_alpha);
    }


    /** 确认删除患者dialog
     * 备注:文字后面要加一个空白，让点击的文字处于所有文字中间
     * */
    public void initDeletePatientDialog(){
        String contentStr = "患者所有对话记录及病历将全部删除，确认删除吗？\n删除后如何恢复？ ";
        int start = "患者所有对话记录及病历将全部删除，确认删除吗？\n".length();
        SpannableString spannableString = new SpannableString(contentStr);
        spannableString.setSpan(click_span, start, contentStr.length()-1, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new ForegroundColorSpan(Color.parseColor("#395998")), start, contentStr.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        YR_CommonDialog dialog  = new YR_CommonDialog(this,spannableString ,"取消","确认删除") {
            @Override
            public void confirmBtn() {
                dismiss();
                delPatient();
            }
        };
        dialog.show();
    }

    /**
     * 每次将原有数据中的id减去，并把总数目减一
     * @param patientId  删除的患者Id
     * */
    public void reset(String patientId) {
        String origin = UtilSP.getNewPatientIds();
        ArrayList<String> ids = new ArrayList<>(Arrays.asList(origin.split(XC_ChatReceiver.PATIENT_IDS_SPLIT)));
        if (UtilCollection.isBlank(ids))
            return;
        if (!ids.contains(patientId))
            return;
        ids.remove(patientId);
        String result = ids.toString().replace(" ", "");
        result = result.substring(1, result.length() - 1);
        UtilSP.putNewPatientNum(ids.size());
        UtilSP.putNewPatientIds(result);
    }

    ClickableSpan click_span = new ClickableSpan() {
        @Override
        public void onClick(View widget) {
            String url = AppConfig.getH5Url(AppConfig.RECOVER_DELETE_PATIENT);
            Context context = widget.getContext();
            if (context instanceof XCBaseActivity){
                ((XCBaseActivity)widget.getContext()).myStartActivity(JS_WebViewActivity.newIntent(context, new WebviewBean(url)));
            }else {
                startActivity(JS_WebViewActivity.newIntent(context, new WebviewBean(url)));
            }
        }

        @Override
        public void updateDrawState(TextPaint ds) {
            super.updateDrawState(ds);
            ds.setUnderlineText(false);//设置取消下划线
        }
    };

}