package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.AbsListView;
import android.widget.ImageView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.UtilChatPhoto;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCIMMenuDialog;
import com.qlk.ymz.view.zoomimageview.XCViewPagerFragment;
import com.qlk.ymz.view.zoomimageview.XCZoomImageView;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by syy.
 * @description 放大缩小动画打开大图片，从原图片位置放大、缩小回到原图片位置，未优化完。崩溃情况暂未能复现，不用在公用页
 */
public class YY_ZoomImageActivity extends DBActivity {

    /**
     * 上一个界面传递过来数据的key值
     */
    public static String PICTURES_KEY = "picture";
    /**
     * 点击的图片位置
     */
    public static String INDEX = "index";

    private XCIMMenuDialog dialog;

    private ArrayList<String> urls;

    //传入图片的位置
    private int imageIndex;
    /** 缩放动画时间*/
    private long zoomTime = 300;

    public static final String SAVE_PHOTO = "保存图片";

    /** 被点击的图片在原先activity的位置 传递参数key*/
    public static String LOCATIONS = "locations";
    /** 传入原图片的定位坐标*/
    private List<int[]> locations;
    /** 缩放动画*/
    ScaleAnimation scaleAnimation;
    /** 是否通过关闭此大图activity而返回的，用于控制前一个activity不刷新等*/
    public static boolean IS_CLOSE_FROM_SHOWIMG = false;
    /** 被点击的imageview*/
    private ImageView clickImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xc_l_activity_chat_images_show);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YY_ZoomImageActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        urls = getIntent().getStringArrayListExtra(PICTURES_KEY);
        imageIndex = getIntent().getIntExtra(INDEX, 0);
        locations = (List)getIntent().getSerializableExtra(LOCATIONS);
        final int imageIndex_f = imageIndex;
        XCViewPagerFragment fragment = new XCViewPagerFragment();
        fragment.setData(urls);
        fragment.setDefaultSelectedIndex(imageIndex);
        fragment.setOnLoadImageListener(new XCViewPagerFragment.OnLoadImage() {
            @Override
            public void onLoadImage(final ImageView imageview, String url) {
                XCApplication.displayImage(url, imageview, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_photo_default));
                //打开时，如果有设置locations，进行从原图片位置投射出的放大动画
                if(((Integer)imageview.getTag()) == imageIndex_f && locations != null){
                    int[] location = locations.get(imageIndex_f);
                    scaleAnimation = new ScaleAnimation(0.1f, 1f,0.1f,1f,location[0],location[1]);
                    scaleAnimation.setDuration(zoomTime);
                    imageview.startAnimation(scaleAnimation);
                }


                if (imageview instanceof XCZoomImageView) {
                    //设置长按事件
                    ((XCZoomImageView) imageview).setOnLongPressListener(new XCZoomImageView.OnLongPressListener() {
                        @Override
                        public void onLongPress() {
                            if (dialog == null) {
                                dialog = new XCIMMenuDialog(YY_ZoomImageActivity.this);
                                dialog.update("", new String[]{SAVE_PHOTO});
                            }

                            dialog.setOnDialogItemClickListener(new XCIMMenuDialog.OnDialogItemClickListener() {
                                @Override
                                public void onClick(View view, String hint) {
                                    if (SAVE_PHOTO.equals(hint)) {
                                        Integer position = (Integer) (imageview.getTag());
                                        UtilChatPhoto.saveFileToSystem(YY_ZoomImageActivity.this, urls.get(position));
                                    }
                                    shortToast("已保存到系统相册");
                                    dialog.cancel();
                                }
                            });
                            dialog.show();
                        }
                    });

                    imageview.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            clickImageView = (ImageView) v;
                            closeAct();
                        }
                    });
                }

            }
        });

        addFragment(R.id.xc_id_images_show, fragment);
    }

    @Override
    public void showPage() {
        showTitleLayout(false);
        showContentLayout();
    }

    @Override
    public void listeners() {

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        closeAct();
    }

    /**
     * 关闭activity动画
     */
    public void closeAct(){
        IS_CLOSE_FROM_SHOWIMG = true;
        //jira3702 与设计沟通，优化体验，所有进入大图片都进行直接打开、直接关闭，不做移动关闭。后期做仿微信的获取原图位置的放大缩小式打开/关闭。
        if(locations == null){
            //没传图片原始位置信息，直接无效果关闭
            YY_ZoomImageActivity.this.myFinish();
            overridePendingTransition(0,0);
        }else{
            //有图片原始位置信息，缩小到原图片位置再关闭
            int clickIndex = ((Integer)clickImageView.getTag());
            int[] location = locations.get(clickIndex);
            if(location[0] >= 0 && location[1] >= 0){// TODO: 2016/8/11 图片可能在边界只见一部分，就为负数，以后优化
                //原图可见，缩放到原图位置
                scaleAnimation = new ScaleAnimation(1f, 0.1f,1f,0.1f,location[0],location[1]);// TODO: 2016/8/11 以后要做成与缩放时回到原图尺寸，合体
            }else{
                //原图不可见缩放到父布局中间
                scaleAnimation = new ScaleAnimation(1f, 0.1f,1f,0.1f,Animation.RELATIVE_TO_PARENT,0.5f,Animation.RELATIVE_TO_PARENT,0.5f);
            }

            scaleAnimation.setDuration(zoomTime);
            scaleAnimation.setFillAfter(true);
            clickImageView.startAnimation(scaleAnimation);
            scaleAnimation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {

                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    YY_ZoomImageActivity.this.myFinish();
                    overridePendingTransition(0,0);
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
        }
    }
    /**
     * 以缩放模式打开大图片
     * @param context
     * @param index 图片索引
     * @param picList 图片地址list
     * @param locations 被点击图片集合的原始坐标
     * @param listView 图片listview
     */
    public static void showPic(Context context, int index, List<String> picList,List<int[]> locations,AbsListView listView) {
        setLocations(locations,listView);
        Intent intent = new Intent(context, YY_ZoomImageActivity.class);
        intent.putExtra(YY_ZoomImageActivity.PICTURES_KEY, (Serializable)picList);
        intent.putExtra(YY_ZoomImageActivity.INDEX, index);
        intent.putExtra(YY_ZoomImageActivity.LOCATIONS, (Serializable)locations);
        context.startActivity(intent);
        ((Activity)context).overridePendingTransition(0,0);
    }


    /**
     * 设置被点击图片所在集合的位置信息
     * @param locations adapter里放原图位置信息的集合
     * @param listView 图片listview
     */
    public static void setLocations(List locations, AbsListView listView){
        if(listView == null){
            return;
        }
        //保存所有图片的位置坐标
        if(locations == null){
            locations = new LinkedList();
        }
        locations.clear();
        for(int i=0; i<listView.getChildCount();i++){
            int[] location = new int[2];
            listView.getChildAt(i).getLocationInWindow(location);
            locations.add(location);
        }
    }

}
