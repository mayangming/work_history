package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * 签到结果
 * @author zhangpengfei.
 * @version 1.0
 */

public class PF_SignInResultActivity extends DBActivity {
    /**添加积分tag*/
    public static final String ADD_SCORE = "addScore";
    /**成功背景*/
    private View pf_id_sign_in_result_success_bg;
    /**失败页面*/
    private LinearLayout pf_id_sign_in_result_fail;
    /**成功页面*/
    private RelativeLayout pf_id_sign_in_result_success;
    private ImageView imageView;
    /**获得积分*/
    private TextView pf_id_sign_in_result_score;
    /**增加积分*/
    private TextView pf_id_sign_in_result_score_get;
    /**积分说明*/
    private TextView pf_id_sign_in_result_score_explain;
    /**关闭*/
    private ImageView pf_id_sign_in_result_close;
    /** 获得积分title */
    private TextView tv_sign_score_title;
    /**增加积分数*/
    private String score = "";
    // 手动签到标识
    public static String MANUAL = "manual";
    // 自动签到标识
    public static String AUTO = "auto";
    // 自动还是手动的tag
    public static String TAG = "type";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_activity_signin_result);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2017-4-10,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_SignInResultActivity.class);
    }

    /** created by songxin,date：2016-4-10,about：bi,end */

    public static void launch(Context context,String signPoint,String tag){
        Intent intent = new Intent(context, PF_SignInResultActivity.class);
        intent.putExtra(PF_SignInResultActivity.ADD_SCORE, signPoint);
        intent.putExtra(PF_SignInResultActivity.TAG, tag);
        context.startActivity(intent);
        ((Activity)context).overridePendingTransition(R.anim.xc_anim_alpha_in, R.anim.xc_anim_alpha_in);
    }

    @Override
    public void initWidgets() {
        pf_id_sign_in_result_success_bg = getViewById(R.id.pf_id_sign_in_result_success_bg);
        pf_id_sign_in_result_fail = getViewById(R.id.pf_id_sign_in_result_fail);
        pf_id_sign_in_result_success = getViewById(R.id.pf_id_sign_in_result_success);
        imageView = getViewById(R.id.imageView);
        pf_id_sign_in_result_score = getViewById(R.id.pf_id_sign_in_result_score);
        pf_id_sign_in_result_score_get = getViewById(R.id.pf_id_sign_in_result_score_get);
        pf_id_sign_in_result_score_explain = getViewById(R.id.pf_id_sign_in_result_score_explain);
        pf_id_sign_in_result_close = getViewById(R.id.pf_id_sign_in_result_close);
        tv_sign_score_title = getViewById(R.id.tv_sign_score_title);
        //设置显示过
        GlobalConfigSP.setSignResultDialog(System.currentTimeMillis() + "");
        if (null != getIntent() && !UtilString.isBlank(getIntent().getStringExtra(ADD_SCORE))){
            score = getIntent().getStringExtra(ADD_SCORE);
        }

        if (AUTO.equals(getIntent().getStringExtra(TAG))){
            tv_sign_score_title.setText("签到鼓励积分");
        }else if(MANUAL.equals(getIntent().getStringExtra(TAG))){
            tv_sign_score_title.setText("获得积分");
        }

        if (UtilString.toLong(score) > 0){
            //成功
            pf_id_sign_in_result_success_bg.setVisibility(View.VISIBLE);
            pf_id_sign_in_result_success.setVisibility(View.VISIBLE);
            pf_id_sign_in_result_score.setText(score);
            pf_id_sign_in_result_score_get.setText("恭喜！您已获得" + score +"积分");
        } else {
            //失败
            pf_id_sign_in_result_success_bg.setVisibility(View.INVISIBLE);
            pf_id_sign_in_result_success.setVisibility(View.GONE);
            pf_id_sign_in_result_fail.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public void listeners() {
        pf_id_sign_in_result_close.setOnClickListener(this);
        pf_id_sign_in_result_score_explain.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.pf_id_sign_in_result_close:
                //关闭
                myFinish();
                overridePendingTransition(R.anim.xc_anim_alpha_in, R.anim.xc_anim_alpha);
                break;
            case R.id.pf_id_sign_in_result_score_explain:
                myFinish();
                //查看详情(积分规则)
                WebviewBean bean = new WebviewBean(AppConfig.getH5Url(AppConfig.doctor_integral_rule));
                bean.title = getString(R.string.point_rule_titile);
                myStartActivity(JS_WebViewActivity.newIntent(this, bean));
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.xc_anim_alpha_in, R.anim.xc_anim_alpha);
    }
}
