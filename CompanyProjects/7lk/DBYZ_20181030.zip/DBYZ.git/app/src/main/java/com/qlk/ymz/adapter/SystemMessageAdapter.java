package com.qlk.ymz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.PF_PaActivity;
import com.qlk.ymz.activity.XD_SystemMessageActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.model.SystemMessageBean;
import com.qlk.ymz.receiver.XC_PushReceiver;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.SystemMessageUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * Created by xiedong on 2018/8/1.
 */

public class SystemMessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context mContext;
    private List<SystemMessageBean> mSystemMessageBeanList;


    public SystemMessageAdapter(Context context,List<SystemMessageBean> systemMessageBeans){
        this.mContext = context;
        this.mSystemMessageBeanList = systemMessageBeans;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_system_message, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        final ViewHolder viewHolder = (ViewHolder) holder;
        final SystemMessageBean systemMessageBean = mSystemMessageBeanList.get(position);
        if(systemMessageBean!=null){
            XCApplication.base_imageloader.displayImage(systemMessageBean.getLogo(), viewHolder.iv_logo, XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default));
            int unreadCount = 0;
            if("4".equals(systemMessageBean.getNoticeType())){
                unreadCount = JS_ChatListDB.getInstance(mContext, UtilSP.getUserId()).getNoticeUnreadRecordCount();
                viewHolder.tv_lastChatMsg.setText(Html.fromHtml(systemMessageBean.getTitle()));
            }else {
                unreadCount = JS_ChatListDB.getInstance(mContext, UtilSP.getUserId()).getUnreadRecordCount(systemMessageBean.getNoticeType());
                viewHolder.tv_lastChatMsg.setText(systemMessageBean.getTitle());
            }
            if(unreadCount>0){
                viewHolder.iv_dot.setVisibility(View.VISIBLE);
            }else {
                viewHolder.iv_dot.setVisibility(View.GONE);
            }
            viewHolder.tv_name.setText(systemMessageBean.getName());
            viewHolder.tv_chatStartTime.setText(UtilDate.convertTimeToFormat(UtilString.toLong(systemMessageBean.getSendTime())));
            if(position == getItemCount()-1){
                viewHolder.v_line.setVisibility(View.GONE);
            }else {
                viewHolder.v_line.setVisibility(View.VISIBLE);
            }
            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    viewHolder.iv_dot.setVisibility(View.GONE);
                    SystemMessageUtil.deleteSystemMessage(systemMessageBean.getNoticeType());
                    if("4".equals(systemMessageBean.getNoticeType())){//系统通知
                        ((XD_SystemMessageActivity)mContext).myStartActivity(PF_PaActivity.class);
                        JS_ChatListDB.getInstance(mContext, UtilSP.getUserId()).setUnReadMessageNum2Zero(JS_ChatListModel.ACCOUNT_ID);
                    }else {//公告类
                        String targetUrl = systemMessageBean.getLinkUrl();
                        if(TextUtils.isEmpty(targetUrl)) {
                            targetUrl = "";
                        }
                        NativeHtml5.newInstance((XD_SystemMessageActivity)mContext).webToAppPage(targetUrl);
                        JS_ChatListDB.getInstance(mContext,UtilSP.getUserId()).setNoticeUnReadMessageNum2Zero(systemMessageBean.getNoticeType());
                    }
                    // 清除“系统类”通知
                    XC_PushReceiver.clearAPSButChat(mContext);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        if(mSystemMessageBeanList!=null){
            return mSystemMessageBeanList.size();
        }
        return 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_logo;
        /** name*/
        TextView tv_name;
        /** 开始时间*/
        TextView tv_chatStartTime;
        /** 最新一条消息*/
        TextView tv_lastChatMsg;
        /** 红点*/
        ImageView iv_dot;
        /** 分割线*/
        View v_line;
        View itemView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            iv_logo = (ImageView) itemView.findViewById(R.id.iv_logo);
            tv_name = (TextView) itemView.findViewById(R.id.tv_name);
            tv_chatStartTime = (TextView) itemView.findViewById(R.id.tv_chatStartTime);
            tv_lastChatMsg = (TextView) itemView.findViewById(R.id.tv_lastChatMsg);
            v_line = itemView.findViewById(R.id.v_line);
            iv_dot = (ImageView) itemView.findViewById(R.id.iv_dot);
        }

    }
}
