package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;

import java.io.File;

/**
 * @author 李涛
 * @description   医师资格证页面
 * @Date 2017/11/21.
 */
public class LT_DoctorqualificationActivity extends DBActivity {

    private XCTitleCommonLayout lt_id_dq_titlebar;
    /**新版*/
    private RelativeLayout lt_id_dq_newview;
    /**旧版*/
    private RelativeLayout lt_id_dq_oldview;
    /**新版数据*/
    private File newfile;
    /**旧版数据*/
    private File oldupimage;
    private File olddownimage;
    private Intent intent;
    /**审核中判断那个页面有数据显示那个页面*/
    private String versionType;
    /**
     * 医生合法备案状态（0 未申请备案; 1 备案审核中;2 备案成功; 3 备案失败; 4 要求备案）
     */
    private String viewFlag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lt_doctorqualification_layout);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(LT_DoctorqualificationActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    private void initData() {
        intent = getIntent();
        newfile = (File) intent.getSerializableExtra("newfile");
        oldupimage = (File) intent.getSerializableExtra("oldupimage");
        olddownimage = (File) intent.getSerializableExtra("olddownimage");
        versionType = intent.getStringExtra("versionType");

        viewFlag = UtilSP.getDoctorStatus();
        //审核中判断时才判断 新旧版数据显示
        if("1".equals(viewFlag)){

            if("1".equals(versionType)){
                lt_id_dq_newview.setVisibility(View.VISIBLE);
                lt_id_dq_oldview.setVisibility(View.GONE);
            }

            if("2".equals(versionType)){
                lt_id_dq_oldview.setVisibility(View.VISIBLE);
                lt_id_dq_newview.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void initWidgets() {
        //设置Title
        lt_id_dq_titlebar = (XCTitleCommonLayout) findViewById(R.id.lt_id_dq_titlebar);
        lt_id_dq_titlebar.setTitleLeft(true,"");
        lt_id_dq_titlebar.setTitleCenter(true,"医师资格证");

        lt_id_dq_newview = (RelativeLayout) findViewById(R.id.lt_id_dq_newview);
        lt_id_dq_oldview = (RelativeLayout) findViewById(R.id.lt_id_dq_oldview);
    }

    @Override
    public void listeners() {
        lt_id_dq_newview.setOnClickListener(this);
        lt_id_dq_oldview.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {}


    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()){
            case R.id.lt_id_dq_newview:
                ToJumpHelp.toJumpNewDoctorQualificatioiinActivity(LT_DoctorqualificationActivity.this,newfile);
                break;
            case R.id.lt_id_dq_oldview:
                 ToJumpHelp.tojumpOldDoctorQualificationActivity(LT_DoctorqualificationActivity.this,oldupimage,olddownimage);
                break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK){
            switch (requestCode){
                case 0:
                    newfile = (File) data.getSerializableExtra("backNewImage");
                    intent.putExtra("backNewImage",newfile);
                    intent.putExtra("backImageCommit","待提交");
                    setResult(RESULT_OK,intent);
                    finish();
                    break;
                case 1:
                    oldupimage = (File) data.getSerializableExtra("backOldUpImage");
                    olddownimage = (File) data.getSerializableExtra("backOldDownImage");
                    intent.putExtra("backImageCommit","待提交");
                    intent.putExtra("backOldUpImage",oldupimage);
                    intent.putExtra("backOldDownImage",olddownimage);
                    setResult(RESULT_OK,intent);
                    finish();
                    break;
            }
        }

    }
}
