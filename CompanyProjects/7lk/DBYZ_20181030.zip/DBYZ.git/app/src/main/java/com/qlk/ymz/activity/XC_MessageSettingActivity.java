package com.qlk.ymz.activity;

import android.os.Bundle;
import android.view.View;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.view.XCSwitchButton;

/**
 * Created by jingyu.
 *
 * @description 消息通知设置页
 */
public class XC_MessageSettingActivity extends DBActivity {
    /**
     * 新消息是否通知
     */
    private XCSwitchButton xc_id_setting_receiver_message_button;
    /**
     * 通知是否有声音
     */
    private XCSwitchButton xc_id_setting_voice_button;
    /**
     * 通知是否震动
     */
    private XCSwitchButton xc_id_setting_vibrate_button;

    private boolean isRestore = true;
    /**
     * title
     */
    private XCTitleCommonLayout titlebar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 设置布局
        setContentView(R.layout.xc_l_activity_message_setting);
        super.onCreate(savedInstanceState);

        // 该方法在initwidgets 与 listener之后运行
        restoreSetting();

    }
    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XC_MessageSettingActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    // 初始化控件
    @Override
    public void initWidgets() {

        xc_id_setting_receiver_message_button = getViewById(R.id.xc_id_setting_receiver_message_button);
        xc_id_setting_voice_button = getViewById(R.id.xc_id_setting_voice_button);
        xc_id_setting_vibrate_button = getViewById(R.id.xc_id_setting_vibrate_button);

        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "新消息通知");
        titlebar.setTitleLeft(true, "");
        titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });

    }

    // 设置监听
    @Override
    public void listeners() {

        xc_id_setting_receiver_message_button.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            @Override
            public void open() {
                //一开全开
                GlobalConfigSP.putIMNoticeSetting(true);
                GlobalConfigSP.putIMSoundSetting(true);
                GlobalConfigSP.putIMVibrateSetting(true);
                // 区别 第一次恢复初始状态 与 手动设置状态
                /*if (isRestore) {
                    isRestore = false;
                } else {
                    xc_id_setting_voice_button.setState(true);
                    xc_id_setting_vibrate_button.setState(true);
                }*/
                xc_id_setting_voice_button.setState(true);
                xc_id_setting_vibrate_button.setState(true);
                xc_id_setting_voice_button.setSlideable(true);
                xc_id_setting_vibrate_button.setSlideable(true);
            }

            @Override
            public void close() {
                //一关全关
                GlobalConfigSP.putIMNoticeSetting(false);
                GlobalConfigSP.putIMSoundSetting(false);
                GlobalConfigSP.putIMVibrateSetting(false);
                //isRestore = false;

                xc_id_setting_voice_button.setState(false);
                xc_id_setting_vibrate_button.setState(false);

                xc_id_setting_voice_button.setSlideable(false);
                xc_id_setting_vibrate_button.setSlideable(false);

            }
        });

        xc_id_setting_vibrate_button.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            @Override
            public void open() {
                GlobalConfigSP.putIMVibrateSetting(true);
            }

            @Override
            public void close() {
                GlobalConfigSP.putIMVibrateSetting(false);
            }
        });
        xc_id_setting_voice_button.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            @Override
            public void open() {
                GlobalConfigSP.putIMSoundSetting(true);
            }

            @Override
            public void close() {
                GlobalConfigSP.putIMSoundSetting(false);
            }
        });

    }

    /**
     * 恢复之前的视图
     * setStatus()里会调用监听方法
     */
    public void restoreSetting() {
        xc_id_setting_receiver_message_button.setState(GlobalConfigSP.getIMNoticeSetting());
        xc_id_setting_voice_button.setState(GlobalConfigSP.getIMSoundSetting());
        xc_id_setting_vibrate_button.setState(GlobalConfigSP.getIMVibrateSetting());
        //通知没开，声音和震动不允许设置
        if(GlobalConfigSP.getIMNoticeSetting()){
            xc_id_setting_voice_button.setSlideable(true);
            xc_id_setting_vibrate_button.setSlideable(true);
        }else{
            xc_id_setting_voice_button.setSlideable(false);
            xc_id_setting_vibrate_button.setSlideable(false);
        }

    }

}
