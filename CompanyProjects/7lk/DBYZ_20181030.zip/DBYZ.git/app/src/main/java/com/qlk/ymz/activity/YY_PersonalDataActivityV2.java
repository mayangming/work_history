package com.qlk.ymz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.maintab.JS_HomeFragment;
import com.qlk.ymz.model.AuthDataInfo;
import com.qlk.ymz.model.YY_DoctorlInfoBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.HospitalBackupsBeanSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilBroadcast;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.List;

/**
 * YY_PersonalDataActivityV2
 * 医生认证
 * @author songxin on 2016/2/24 changed.
 * @version 2.2.0
 */
public class YY_PersonalDataActivityV2 extends DBActivity {
    /** 真是姓名*/
    private RelativeLayout sx_id_true_name_rl;
    /** 真是姓名显示*/
    private TextView sx_id_true_name_show;
    /** 性别*/
    private RelativeLayout sx_id_sex_rl;
    /** 性别显示*/
    private TextView sx_id_sex_show;
    /** 医院*/
    private RelativeLayout sx_id_hospital_rl;
    /** 医院显示*/
    private TextView sx_id_hospital_show;
    /** 科室*/
    private RelativeLayout sx_id_department_rl;
    /** 科室显示*/
    private TextView sx_id_department_show;
    /** 职称*/
    private RelativeLayout sx_id_professional_ranks_and_titles_rl;
    /** 职称显示*/
    private TextView sx_id_professional_ranks_and_show;
    /** 认证文字*/
    private TextView yy_id_auth_tv;
    /** 认证*/
    private RelativeLayout yy_id_auth_rl;
    /** 更多*/
    private RelativeLayout sx_id_more_rl;
    /** 保存按钮*/
    private TextView sx_id_confirm_button;
    /** 右箭头*/
    private ImageView sx_id_arrow1;
    private ImageView sx_id_arrow2;
    private ImageView sx_id_arrow4;
    private ImageView sx_id_arrow5;
    private ImageView sx_id_arrow6;
    /** 失败原因显示*/
    private TextView sx_id_fail_text;
    private Listener mListener;
    private String mAuthStatus = "",mUpdateStatus = "";
    public static final String REFRESH_HOSPITAL_NAME = "com.qlk.ymz.REFRESH_HOSPITAL_NAME";
    private XCTitleCommonLayout titlebar;
    /** 底部医生助手布局 */
    private RelativeLayout bottom_layout;
    private TextView bottom_feldsher_tv;
    /**提交完成弹出Dialog*/
    private YR_CommonDialog mConfirmDialog;
    private YR_CommonDialog mConfirmBackDialog;

    private YY_DoctorlInfoBean.DataEntity mDoctorlInfoBean;
    /** 认证失败原因 */
    private String mFailText = "";
    /** 医生状态更新接收器 */
    private UpdateAuthStatusReceiver update_auth_status_receiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 设置布局
        setContentView(R.layout.yy_l_activity_personal_data_v2);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(YY_PersonalDataActivityV2.class,"1","","","",false);
        // created by songxin,date：2016-4-25,about：saveInfo,end

        //dialog初始化
//        initDialog();

        // 注册“更新认证状态广播接收器”
        update_auth_status_receiver = new UpdateAuthStatusReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000, JS_HomeFragment.UPDATE_AUTHSTATUS_ACTION, update_auth_status_receiver);

        mListener = new Listener();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(REFRESH_HOSPITAL_NAME);
        registerReceiver(mListener, intentFilter);
        initAuthInfo(AuthDataInfo.AUTH_STATUS_OK);
        getUserDetail(UtilSP.getUserId());

    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YY_PersonalDataActivityV2.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    protected void onResume() {
        super.onResume();
        if("1".equals(UtilSP.getDoctorUploadStatus())){
            yy_id_auth_tv.setTextColor(getResources().getColor(R.color.c_e2231a));
            yy_id_auth_tv.setText("已上传");
        }
    }

    /**
     * 认证相关文字、tv、箭头控制等
     */
    public void initAuthInfo(String mAuthStatus) {
        if (UtilString.isBlank(mAuthStatus)) {
            return;
        }
        //5是什么？
        if (AuthDataInfo.AUTH_STATUS_OK.equals(mAuthStatus) || AuthDataInfo.AUTH_STATUS_AUTHING.equals(mAuthStatus) || AuthDataInfo.AUTH_STATUS_AGAIN.equals(mAuthStatus)
                ||"5".equals(mAuthStatus)) {
            sx_id_true_name_rl.setClickable(false);
            sx_id_arrow1.setVisibility(View.GONE);
            sx_id_sex_rl.setClickable(false);
            sx_id_arrow2.setVisibility(View.GONE);
            sx_id_hospital_rl.setClickable(false);
            sx_id_arrow4.setVisibility(View.GONE);
            sx_id_department_rl.setClickable(false);
            sx_id_arrow5.setVisibility(View.GONE);
            sx_id_professional_ranks_and_titles_rl.setClickable(false);
            sx_id_arrow6.setVisibility(View.GONE);
            titlebar.setTitleCenter(true, "医生认证");
        }else{
            sx_id_true_name_rl.setClickable(true);
            sx_id_arrow1.setVisibility(View.VISIBLE);
            sx_id_sex_rl.setClickable(true);
            sx_id_arrow2.setVisibility(View.VISIBLE);
            sx_id_hospital_rl.setClickable(true);
            sx_id_arrow4.setVisibility(View.VISIBLE);
            sx_id_department_rl.setClickable(true);
            sx_id_arrow5.setVisibility(View.VISIBLE);
            sx_id_professional_ranks_and_titles_rl.setClickable(true);
            sx_id_arrow6.setVisibility(View.VISIBLE);
            titlebar.setTitleCenter(true, "医生认证");
        }
        //验证，填写完必填信息
        checkDoctorInfo(mAuthStatus);
    }

    /**
     * dialog初始化
     */
    private void showDialog() {
        if (mConfirmDialog == null) {
            mConfirmDialog = new YR_CommonDialog(this, "资料已提交，我们会尽量为您审核通过", "", "确定") {
                @Override
                public void confirmBtn() {
                    dismiss();
                    Intent intent = new Intent(YY_PersonalDataActivityV2.this, JS_MainActivity.class);
                    intent.putExtra(JS_MainActivity.TAB_TAG, JS_MainActivity.TAB_HOME);
                    YY_PersonalDataActivityV2.this.startActivity(intent);
                    finish();
                }
            };
            mConfirmDialog.setCanceledOnTouchOutside(false);
        }
        if (mConfirmDialog != null && !mConfirmDialog.isShowing()) {
            mConfirmDialog.show();
        }
    }

    YR_CommonDialog recordDialog;
    private void showRecordDialog(){
        if(recordDialog == null){
            recordDialog = new YR_CommonDialog(this,"网上行医建议您进行互联网医院备案","以后再说","继续备案"){
                @Override
                public void confirmBtn() {
                    // 跳转备案页
                    UtilNativeHtml5.toJumpNativeH5(YY_PersonalDataActivityV2.this, UtilNativeHtml5.INTERNET_HOSPITAL_RECORD);
                    dismiss();
                }

                @Override
                public void cancelBtn() {
                    if(JS_MainActivity.FORM_REGISTER.equals(getIntent().getStringExtra(JS_MainActivity.FROM_PAGE))){
                        Intent intent = new Intent(YY_PersonalDataActivityV2.this,JS_MainActivity.class);
                        intent.putExtra(JS_MainActivity.FROM_PAGE,JS_MainActivity.FROM_LOGIN);
                        if(NativeHtml5.DOCTOR_MINE.equals(HospitalBackupsBeanSP.TO_ACTIVITY)) {
                            intent.putExtra(JS_MainActivity.TAB_TAG, JS_MainActivity.TAB_MY);
                        }
                        intent.putExtra(JS_MainActivity.IS_SHOWN_IDENTYFY_DIALOG, true);
                        startActivity(intent);
                    }else {
                        finish();
                    }
                }
            };
        }
        recordDialog.setCancelable(false);
        recordDialog.setTitle("提交成功");
        recordDialog.show();
    }


    // 无网络时,点击屏幕后回调的方法
    @Override
    public void onNetRefresh () {
        getUserDetail(UtilSP.getUserId());
    }


    // 初始化控件
    @Override
    public void initWidgets () {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "个人资料");
        titlebar.setTitleLeft(true, "");


        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        sx_id_true_name_rl = getViewById(R.id.sx_id_true_name_rl);
        sx_id_true_name_show = getViewById(R.id.sx_id_true_name_show);
        sx_id_sex_rl = getViewById(R.id.sx_id_sex_rl);
        sx_id_sex_show = getViewById(R.id.sx_id_sex_show);
        sx_id_hospital_rl = getViewById(R.id.sx_id_hospital_rl);
        sx_id_hospital_show = getViewById(R.id.sx_id_hospital_show);
        sx_id_department_rl = getViewById(R.id.sx_id_department_rl);
        sx_id_department_show = getViewById(R.id.sx_id_department_show);
        sx_id_professional_ranks_and_titles_rl = getViewById(R.id.sx_id_professional_ranks_and_titles_rl);
        sx_id_professional_ranks_and_show = getViewById(R.id.sx_id_professional_ranks_and_show);

        sx_id_arrow1 = getViewById(R.id.sx_id_arrow1);
        sx_id_arrow2 = getViewById(R.id.sx_id_arrow2);
        sx_id_arrow4 = getViewById(R.id.sx_id_arrow4);
        sx_id_arrow5 = getViewById(R.id.sx_id_arrow5);
        sx_id_arrow6 = getViewById(R.id.sx_id_arrow6);

        sx_id_more_rl = getViewById(R.id.sx_id_more_rl);
        sx_id_confirm_button = getViewById(R.id.sx_id_confirm_button);
        sx_id_fail_text = getViewById(R.id.sx_id_fail_text);

        sx_id_true_name_show = getViewById(R.id.sx_id_true_name_show);
        sx_id_sex_show = getViewById(R.id.sx_id_sex_show);
        sx_id_hospital_show = getViewById(R.id.sx_id_hospital_show);
        sx_id_department_show = getViewById(R.id.sx_id_department_show);
        sx_id_professional_ranks_and_show = getViewById(R.id.sx_id_professional_ranks_and_show);

        yy_id_auth_rl = getViewById(R.id.yy_id_auth_rl);
        yy_id_auth_tv = getViewById(R.id.yy_id_auth_tv);

        bottom_layout = getViewById(R.id.bottom_layout);
        bottom_feldsher_tv = getViewById(R.id.bottom_feldsher_tv);
        bottom_layout.setVisibility(View.GONE);
    }


    // 设置监听
    @Override
    public void listeners () {
        sx_id_true_name_rl.setOnClickListener(this);
        sx_id_sex_rl.setOnClickListener(this);
        sx_id_hospital_rl.setOnClickListener(this);
        sx_id_department_rl.setOnClickListener(this);
        sx_id_professional_ranks_and_titles_rl.setOnClickListener(this);
        sx_id_more_rl.setOnClickListener(this);
        sx_id_confirm_button.setOnClickListener(this);
        yy_id_auth_rl.setOnClickListener(this);
        bottom_feldsher_tv.setOnClickListener(this);
    }

    @Override
    public void onClick (View v){
        super.onClick(v);
        Intent intent = new Intent();
        switch (v.getId()) {
            //真实姓名
            case R.id.sx_id_true_name_rl:
                intent.putExtra("TRUE_NAME", sx_id_true_name_show.getText().toString().trim());
                myStartActivityForResult(intent, SX_ChangePersonalDataActivity.class, 0, 0);
                break;
            //性别
            case R.id.sx_id_sex_rl:
                intent.putExtra("SEX", sx_id_sex_show.getText().toString().trim());
                myStartActivityForResult(intent, SX_ChangePersonalDataActivity.class, 1, 1);
                break;
            //医院
            case R.id.sx_id_hospital_rl:
//                    intent.putExtra("HOSPITAL", sx_id_hospital_show.getText().toString().trim());
//                    myStartActivityForResult(intent, SX_HosptialActivity.class, 3, 3);
                UtilNativeHtml5.toJumpSelectHospital(this);
                break;
            //科室
            case R.id.sx_id_department_rl:
                intent.putExtra("DEPARTMENT", sx_id_department_show.getText().toString().trim());
                myStartActivityForResult(intent, SX_DepartmentActivity.class, 4, 4);
                break;
            //职称
            case R.id.sx_id_professional_ranks_and_titles_rl:
                intent.putExtra("PROFESSIONAL_RANKS", sx_id_professional_ranks_and_show.getText().toString().trim());
                myStartActivityForResult(intent, SX_ProfessionalRanksActivity.class, 5, 5);
                break;
            //医生认证
            case R.id.yy_id_auth_rl:
                 if("1".equals(mAuthStatus)){  //已认证
                    intent.setClass(this, SX_AuthDataActivityV2.class);
                    startActivity(intent);
                }else if("2".equals(mAuthStatus) || "4".equals(mAuthStatus)){
                     intent.setClass(this, SX_IdentityAuthenticationActivityV2.class);
                     startActivity(intent);
                     if(checkValue()){
                        requestSave();
                     }
                }else {//2 未认证，4认证失败  0 审核中，3 再次审核中，5资料提交待认证
                     intent.setClass(this, SX_IdentityAuthenticationActivityV2.class);
                     startActivity(intent);
                 }

                break;
            //更多
            case R.id.sx_id_more_rl:
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(SX_SetLoginActivity.class,"2","128","sx_id_more_rl","",false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                intent.putExtra("DoctorlInfoBean", mDoctorlInfoBean);
                myStartActivityForResult(intent, SX_PersonalDataMoreActivity.class, 6, 6);
                break;
            //保存按钮
            case R.id.sx_id_confirm_button:
                //如果信息完整
                if(UtilString.isAllNotBlank(sx_id_true_name_show.getText().toString().trim(),
                        sx_id_sex_show.getText().toString().trim(),
                        sx_id_hospital_show.getText().toString().trim(),
                        sx_id_department_show.getText().toString().trim(),
                        sx_id_professional_ranks_and_show.getText().toString().trim())){

                    if("0".equals(mDoctorlInfoBean.getDepartmentId()) && UtilString.isBlank(mDoctorlInfoBean.getCustomDepartmentName())){
                        shortToast("请填写自定义科室");
                        return;
                    }
                    newChangeInfo();
                }
                break;
            case R.id.bottom_feldsher_tv:
                //医生助手跳转
                Intent mIntent = new Intent(this,XD_ServiceChatActivity.class);
                myStartActivity(mIntent);
                break;
        }

    }

    @Override
    protected void onDestroy () {
        UtilBroadcast.myUnregisterReceiver(this, update_auth_status_receiver);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mConfirmDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
        //注销广播
        try {
            if (null != mListener) {
                unregisterReceiver(mListener);
                mListener = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * add by cyr on 2016/5/16 和ios一致，修改按键颜色
     *
     * 给认证Button设置颜色变化监听,如果个人资料都不为空，按键为红色，否则为浅红色
     * @param view 需要设置文字的控件
     *  @param  content 要设置的文字内容
     * */
    public void setTextViewChangeListener(TextView view, String content){
        if (view != null ) {
            view.setText(content);
        }
        String trueName = sx_id_true_name_show.getText().toString().trim();
        String sex = sx_id_sex_show.getText().toString().trim();
        String hospital = sx_id_hospital_show.getText().toString().trim();
        String department = sx_id_department_show.getText().toString().trim();
        String professional = sx_id_professional_ranks_and_show.getText().toString().trim();


        if(UtilString.isAllNotBlank(trueName,sex,hospital,department,professional)) {
            sx_id_confirm_button.setClickable(true);
            sx_id_confirm_button.setTextColor(getResources().getColor(R.color.c_e2231a));
        } else {
            sx_id_confirm_button.setClickable(false);
            sx_id_confirm_button.setTextColor(getResources().getColor(R.color.c_login_text_bg));
        }
    }

    @Override
    protected void onActivityResult ( int requestCode, int resultCode, Intent data){
        printi("http", "============onActivityResult================");
        switch (requestCode) {
            case 0: {
                if (null != data) {
                    YY_DoctorlInfoBean.DataEntity currentData = (YY_DoctorlInfoBean.DataEntity)data.getSerializableExtra("TRUE_NAME");
                    if(null != currentData && null != mDoctorlInfoBean){
                        mDoctorlInfoBean.setName(currentData.getName());
                        setTextViewChangeListener(sx_id_true_name_show,currentData.getName());
//                            sx_id_true_name_show.setText(currentData.getName());
                    }
                }
                checkDoctorInfo(mAuthStatus);
                break;
            }
            case 1: {
                if (null != data) {
                    YY_DoctorlInfoBean.DataEntity currentData = (YY_DoctorlInfoBean.DataEntity)data.getSerializableExtra("SEX");
                    if(null != currentData && null != mDoctorlInfoBean){
                        mDoctorlInfoBean.setGender(currentData.getGender());
                        UtilSP.setDoctorSex(currentData.getGender());
                        if("0".equals(currentData.getGender())){
                            setTextViewChangeListener(sx_id_sex_show,"女");
//                                sx_id_sex_show.setText("女");
                        }else if("1".equals(currentData.getGender())){
                            setTextViewChangeListener(sx_id_sex_show,"男");
//                                sx_id_sex_show.setText("男");
                        }
                    }
                }
                checkDoctorInfo(mAuthStatus);
                break;
            }
            case 3: {
                if (null != data) {
                    YY_DoctorlInfoBean.DataEntity currentData = (YY_DoctorlInfoBean.DataEntity)data.getSerializableExtra("HOSPITAL");
                    if(null != currentData && null != mDoctorlInfoBean){
                        mDoctorlInfoBean.setCityId(currentData.getCityId());
                        mDoctorlInfoBean.setHospitalId(currentData.getHospitalId());
                        mDoctorlInfoBean.setHospital(currentData.getHospital());
                        setTextViewChangeListener(sx_id_hospital_show,currentData.getHospital());
//                            sx_id_hospital_show.setText(currentData.getHospital());
                    }
                }
                checkDoctorInfo(mAuthStatus);
                break;
            }
            case 4: {
                if (null != data) {
                    YY_DoctorlInfoBean.DataEntity currentData = (YY_DoctorlInfoBean.DataEntity)data.getSerializableExtra("DEPARTMENT");
                    if(null != currentData && null != mDoctorlInfoBean){
                        if(UtilString.isBlank(currentData.getCustomDepartmentName())){
                            mDoctorlInfoBean.setDepartmentId(currentData.getDepartmentId());
                            mDoctorlInfoBean.setDepartment(currentData.getDepartment());
                            setTextViewChangeListener(sx_id_department_show,currentData.getDepartment());
//                                sx_id_department_show.setText(currentData.getDepartment());
                        }else {
                            mDoctorlInfoBean.setDepartmentId("0");
                            mDoctorlInfoBean.setCustomDepartmentName(currentData.getCustomDepartmentName());
                            setTextViewChangeListener(sx_id_department_show,currentData.getCustomDepartmentName());
//                                sx_id_department_show.setText(currentData.getCustomDepartmentName());
                        }
                    }
                }
                checkDoctorInfo(mAuthStatus);
                break;
            }
            case 5: {
                if (null != data) {
                    YY_DoctorlInfoBean.DataEntity currentData = (YY_DoctorlInfoBean.DataEntity)data.getSerializableExtra("PROFESSIONAL_RANKS");
                    if(null != currentData && null != mDoctorlInfoBean){
                        mDoctorlInfoBean.setTitle(currentData.getTitle());
                        mDoctorlInfoBean.setTitleId(currentData.getTitleId());
                        printi("http", "mDoctorlInfoBean.getTitleId()------>" + mDoctorlInfoBean.getTitleId());
                        setTextViewChangeListener(sx_id_professional_ranks_and_show,mDoctorlInfoBean.getTitle());
//                            sx_id_professional_ranks_and_show.setText(mDoctorlInfoBean.getTitle());
                    }
                }
                checkDoctorInfo(mAuthStatus);
                break;
            }
            case 6: {
                if (null != data) {
                    String currentExpertise = data.getStringExtra("BE_GOOD_AT");
                    String currentIntroduction = data.getStringExtra("PERSONAL_PROFILE");
                    if(null != mDoctorlInfoBean){
                        mDoctorlInfoBean.setExpertise(currentExpertise);
                        mDoctorlInfoBean.setIntroduction(currentIntroduction);
                    }
                }
                break;
            }
        }
    }

    /**
     * 获得医生信息
     * @param doctorId 医生id
     */
    private void getUserDetail(final String doctorId) {
        RequestParams params = new RequestParams();
        params.put("id", doctorId);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.user_detail), params, new XCHttpResponseHandler<YY_DoctorlInfoBean>(this, YY_DoctorlInfoBean.class) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<YY_DoctorlInfoBean.DataEntity> objLists = mResultModel.getData();
                    if (objLists != null && objLists.size() > 0) {
                        mDoctorlInfoBean = objLists.get(0);
                        if (null == mDoctorlInfoBean) {
                            mDoctorlInfoBean = new YY_DoctorlInfoBean.DataEntity();
                        }
                        if ("女".equals(mDoctorlInfoBean.getGender())) {
                            mDoctorlInfoBean.setGender("0");
                        } else if ("男".equals(mDoctorlInfoBean.getGender())) {
                            mDoctorlInfoBean.setGender("1");
                        }
                        UtilSP.setDoctorSex(mDoctorlInfoBean.getGender());
                        if ("0".equals(mDoctorlInfoBean.getDepartmentId())){//自定义科室的时候复制一份，临近上线改的，以后有空把这个代码改正下..
                            mDoctorlInfoBean.setCustomDepartmentName(mDoctorlInfoBean.getDepartment());
                        }
                        sx_id_true_name_show.setText(mDoctorlInfoBean.getName());
                        if("0".equals(mDoctorlInfoBean.getGender())){
                            sx_id_sex_show.setText("女");
                        }else if("1".equals(mDoctorlInfoBean.getGender())){
                            sx_id_sex_show.setText("男");
                        }

                        mUpdateStatus = mDoctorlInfoBean.getUploadStatus();
                        UtilSP.setDoctorUploadStatus(mUpdateStatus);
                        if ("0".equals(mUpdateStatus)) {
                            yy_id_auth_tv.setText("");
                        } else if ("1".equals(mUpdateStatus)) {
                            yy_id_auth_tv.setTextColor(getResources().getColor(R.color.c_e2231a));
                            yy_id_auth_tv.setText("已上传");
                        }

                        sx_id_hospital_show.setText(mDoctorlInfoBean.getHospital());
                        sx_id_department_show.setText(mDoctorlInfoBean.getDepartment());
                        sx_id_professional_ranks_and_show.setText(mDoctorlInfoBean.getTitle());
                        mFailText = mDoctorlInfoBean.getFailReason();

                        setTextViewChangeListener(null,"");
                        mAuthStatus = mDoctorlInfoBean.getStatus();
                        initAuthInfo(mDoctorlInfoBean.getStatus());
                        if("1".equals(mAuthStatus)) {
                            bottom_layout.setVisibility(View.VISIBLE);
                        }else{
                            bottom_layout.setVisibility(View.GONE);
                        }
                    }
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YY_PersonalDataActivityV2.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理

                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /** 验证，填写完必填信息,根据医生认证状态显示不同的UI
     * update by cyr on 2016/4/19 修改认证状态UI,去掉真实姓名后面的认证logo,调整底部认证btn的位置和颜色
     * */
    private void checkDoctorInfo(String mAuthStatus) {
        String trueName = sx_id_true_name_show.getText().toString().trim();
        String sex = sx_id_sex_show.getText().toString().trim();
        String hospital = sx_id_hospital_show.getText().toString().trim();
        String department = sx_id_department_show.getText().toString().trim();
        String professional = sx_id_professional_ranks_and_show.getText().toString().trim();
        sx_id_confirm_button.setVisibility(View.VISIBLE);
        sx_id_confirm_button.setClickable(false);
        sx_id_fail_text.setVisibility(View.GONE);
        //未认证
        if(AuthDataInfo.AUTH_STATUS_INIT.equals(mAuthStatus)){
            sx_id_confirm_button.setText("提交认证");
            if(UtilString.isAllNotBlank(trueName,sex,hospital,department,professional)){
                sx_id_confirm_button.setClickable(true);
                sx_id_confirm_button.setTextColor(getResources().getColor(R.color.c_e2231a));
            }
            //认证中 (这个状态5是什么鬼？)
        }else if(AuthDataInfo.AUTH_STATUS_AGAIN.equals(mAuthStatus)||AuthDataInfo.AUTH_STATUS_AUTHING.equals(mAuthStatus) ||"5".equals(mAuthStatus)){
            sx_id_confirm_button.setText("认证中...");
            sx_id_confirm_button.setTextColor(getResources().getColor(R.color.c_42bd05));
            sx_id_fail_text.setVisibility(View.VISIBLE);
            sx_id_fail_text.setTextColor(getResources().getColor(R.color.c_42bd05));
            sx_id_fail_text.setText(mFailText);
            //认证失败
        }else if(AuthDataInfo.AUTH_STATUS_FAIL.equals(mAuthStatus)){
            sx_id_confirm_button.setText("重新提交认证");
            if(!UtilString.isBlank(mFailText)){
                sx_id_fail_text.setTextColor(getResources().getColor(R.color.c_e2231a));
                sx_id_fail_text.setVisibility(View.VISIBLE);
                sx_id_fail_text.setText(mFailText);
            }
            if(UtilString.isAllNotBlank(trueName,sex,hospital,department,professional)){
                sx_id_confirm_button.setClickable(true);
                sx_id_confirm_button.setTextColor(getResources().getColor(R.color.c_e2231a));
            }
            //认证通过
        }else if(AuthDataInfo.AUTH_STATUS_OK.equals(mAuthStatus)){
            sx_id_confirm_button.setVisibility(View.GONE);
        }else{
            sx_id_confirm_button.setTextColor(getResources().getColor(R.color.c_e2231a));
            sx_id_confirm_button.setVisibility(View.GONE);
        }
    }

    /**
     * 广播接收器
     */
    class Listener extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(REFRESH_HOSPITAL_NAME)) {
                YY_DoctorlInfoBean.DataEntity currentData = (YY_DoctorlInfoBean.DataEntity)intent.getSerializableExtra("HOSPITAL");
                if(null != currentData && null != mDoctorlInfoBean) {
                    mDoctorlInfoBean.setHospitalId(currentData.getHospitalId());
                    mDoctorlInfoBean.setHospital(currentData.getHospital());
                    setTextViewChangeListener(sx_id_hospital_show, currentData.getHospital());
//                    sx_id_hospital_show.setText(currentData.getHospital());
                }
                //如果信息完整
                checkDoctorInfo(mAuthStatus);
            }
        }
    }

    /**
     * 个人资料提交（2.2.0版本启用）
     */
    private void newChangeInfo(){
        if(null != mDoctorlInfoBean){

            RequestParams params = new RequestParams();
            params.put("id", UtilSP.getUserId());
            params.put("name", mDoctorlInfoBean.getName());
            params.put("gender", mDoctorlInfoBean.getGender());
            params.put("cityId", mDoctorlInfoBean.getCityId());
            params.put("hospitalId", mDoctorlInfoBean.getHospitalId());
            params.put("hospitalName", mDoctorlInfoBean.getHospital());
            params.put("departmentId", mDoctorlInfoBean.getDepartmentId());
            if("0".equals(mDoctorlInfoBean.getDepartmentId())){
                params.put("customDepartment", mDoctorlInfoBean.getCustomDepartmentName());
            }
            params.put("titleId", mDoctorlInfoBean.getTitleId());

            XCHttpAsyn.postAsyn(YY_PersonalDataActivityV2.this, AppConfig.getHostUrl(AppConfig.user_saveBase), params, new XCHttpResponseHandler() {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if(result_boolean){
                        if(JS_MainActivity.FORM_REGISTER.equals(getIntent().getStringExtra(JS_MainActivity.FROM_PAGE))){
                            showRecordDialog();
                            return;
                        }
                        if("0".equals(UtilSP.getDoctorStatus()) || "3".equals(UtilSP.getDoctorStatus()) || "4".equals(UtilSP.getDoctorStatus())) {
                            showRecordDialog();
                        }else {
                            showDialog();
                        }

                    }
                }

                // add by xjs on 20151027 19:48 start
                // 对账户冻结情况的判断处理
                public void onFinish() {
                    super.onFinish();
                    if (null != result_bean && GeneralReqExceptionProcess.checkCode(YY_PersonalDataActivityV2.this,
                            getCode(),
                            getMsg())) {
                        // 接口请求业务成功时的处理
                    }
                }
                // add by xjs on 20151027 19:48 end
            });
        }
    }

    /**
     * 个人资料提交
     */
    private void requestSave() {
        if (null == mDoctorlInfoBean) {
            return;
        }
        RequestParams params = new RequestParams();
        params.put("name", mDoctorlInfoBean.getName());
        params.put("gender", mDoctorlInfoBean.getGender());
        params.put("cityId", mDoctorlInfoBean.getCityId());
        params.put("hospitalId", mDoctorlInfoBean.getHospitalId());
        params.put("hospitalName", mDoctorlInfoBean.getHospital());
        params.put("departmentId", mDoctorlInfoBean.getDepartmentId());
        if ("0".equals(mDoctorlInfoBean.getDepartmentId())) {
            params.put("customDepartment", mDoctorlInfoBean.getCustomDepartmentName());
        }
        params.put("titleId", mDoctorlInfoBean.getTitleId());

        XCHttpAsyn.postAsyn(false, YY_PersonalDataActivityV2.this, AppConfig.getHostUrl(AppConfig.user_save), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {

                }
            }
        });
    }


    private String name = "";
    private String sex = "";
    private String hospital = "";
    private String department = "";
    private String professional = "";

    /**
     * 是否允许请求修改资料接口
     * @return true ：允许，false：不允许
     */
    public boolean checkValue(){

        if(UtilString.isAllBlank(sx_id_true_name_show.getText().toString().trim(),
                sx_id_sex_show.getText().toString().trim(),
                sx_id_hospital_show.getText().toString().trim(),
                sx_id_department_show.getText().toString().trim(),
                sx_id_professional_ranks_and_show.getText().toString().trim())
                && "0".equals(mDoctorlInfoBean.getDepartmentId()) && UtilString.isBlank(mDoctorlInfoBean.getCustomDepartmentName())){
            return false;
        }

        // 判断缓存的值和页面上的是否相同
        if(!name.equals(sx_id_true_name_show.getText().toString().trim())
                ||!sex.equals(sx_id_sex_show.getText().toString().trim())
                ||!hospital.equals(sx_id_hospital_show.getText().toString().trim())
                ||!department.equals(sx_id_department_show.getText().toString().trim())
                ||!professional.equals(sx_id_professional_ranks_and_show.getText().toString().trim())
        ) {
            // 缓存
            name = sx_id_true_name_show.getText().toString().trim();
            sex = sx_id_sex_show.getText().toString().trim();
            hospital = sx_id_hospital_show.getText().toString().trim();
            department = sx_id_department_show.getText().toString().trim();
            professional = sx_id_professional_ranks_and_show.getText().toString().trim();
            return true;
        }

        return true;
    }

    /**  add by cyr on 2016/6/30 接受JS_HomeFragment发送的广播，更新医生状态 */
    public class UpdateAuthStatusReceiver extends BroadcastReceiver {

        public void onReceive(Context context, Intent intent) {
            //页面已关闭finish 但未onDestory解绑广播，再接收到广播，引起下面方法的空指针？
            if(isFinishing()){
                return;
            }
            //如果是认证失败，此处重新请求认证信息，获取认证失败原因
            mAuthStatus = UtilSP.getAuthStatus();
            if (AuthDataInfo.AUTH_STATUS_FAIL.equals(mAuthStatus) || AuthDataInfo.AUTH_STATUS_AUTHING.equals(mAuthStatus)) {
                getUserDetail(UtilSP.getUserId());
            } else {
                initAuthInfo(mAuthStatus);
            }

        }
    }

    @Override
    public void onBackPressed() {
        if(AuthDataInfo.AUTH_STATUS_INIT.equals(mAuthStatus)){//未认证
            showBackDialog();
        }else {
            close();
        }
    }

    /**
     * 关闭页面逻辑
     */
    private void close() {
        if(JS_MainActivity.FORM_REGISTER.equals(getIntent().getStringExtra(JS_MainActivity.FROM_PAGE))){
            Intent intent = new Intent(YY_PersonalDataActivityV2.this,JS_MainActivity.class);
            intent.putExtra(JS_MainActivity.FROM_PAGE,JS_MainActivity.FROM_LOGIN);
            intent.putExtra(JS_MainActivity.IS_SHOWN_IDENTYFY_DIALOG, true);
            startActivity(intent);
        }else {
           super.onBackPressed();
        }
    }

    @Override
    public void myFinish() {
        onBackPressed();
    }

    /**
     * 显示离开的dialog
     */
    private void showBackDialog(){
        if(mConfirmBackDialog == null){
            mConfirmBackDialog = new YR_CommonDialog(this,"完成医生认证才能完整体验石榴云医，确定现在退出吗?","退出",
                    "继续") {
                @Override
                public void confirmBtn() {
                    dismiss();
                }

                @Override
                public void cancelBtn() {
                    super.cancelBtn();
                    close();
                }
            };
            mConfirmBackDialog.setCanceledOnTouchOutside(false);
        }
        if(mConfirmBackDialog != null && !mConfirmBackDialog.isShowing()){
            mConfirmBackDialog.show();
        }
    }
}
