package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.fragment.XL_PersonBasicInfoFragment;
import com.qlk.ymz.modelflag.XL_PatientBasicBean;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;

/**
 * Created by xilinch on 2015/9/1.
 * @version 1.0
 * @description 患者基本资料
 *
 * @author cyr on 2016-4-28
 * @version 2.3 修改bug
 *
 * @author wangyong on 2016-6-9
 * @version 2.8 添加一些控件
 */
public class XL_PatientInfoBasicActivity extends DBActivity {
    /** titlebar */
    private XCTitleCommonLayout titlebar;
    /** 患者基本信息 */
    private XL_PersonBasicInfoFragment personBasicInfoFragment;
    /** 患者id */
    private String mPatientId = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 设置布局
        setContentView(R.layout.xl_activity_patientinfo_basic);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_PatientInfoBasicActivity.class);
        if (TextUtils.isEmpty(mPatientId)) {
            personBasicInfoFragment.pullToRefreshScrollView.setMode(PullToRefreshBase.Mode.DISABLED);
        }
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "基本病情");
        titlebar.setTitleLeft(true, "");
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));

        if (getIntent() != null && getIntent().getExtras() != null
                && !TextUtils.isEmpty(getIntent().getExtras().getString(CommonConfig.PATIENT_ID))) {
            mPatientId = getIntent().getExtras().getString(CommonConfig.PATIENT_ID);
        }
        personBasicInfoFragment = new XL_PersonBasicInfoFragment();
        personBasicInfoFragment.setPatientId(mPatientId);
        addFragment(R.id.xc_id_model_content,personBasicInfoFragment);
    }

    @Override
    public void listeners() {
        titlebar.getXc_id_titlebar_left_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }

    public void setResultForEditPatientBasicInfo(XL_PatientBasicBean patientInfo){
        Intent intent = new Intent();
        intent.putExtra(XL_PersonBasicInfoFragment.PATIENT_INFO,patientInfo);
        setResult(RESULT_OK, intent);
        finish();
    }
}


