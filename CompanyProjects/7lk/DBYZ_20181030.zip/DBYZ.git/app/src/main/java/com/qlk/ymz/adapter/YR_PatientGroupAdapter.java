package com.qlk.ymz.adapter;

import android.app.Activity;
import android.content.Context;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.webkit.URLUtil;
import android.widget.BaseExpandableListAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.flexbox.FlexboxLayout;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.qlk.ymz.R;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.Utils;
import com.qlk.ymz.view.SwipeLayout.SwipeOnTouchListener;
import com.qlk.ymz.view.SwipeLayout.SwipeViewHolder;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * 患者首页list
 *
 * @author 崔毅然
 * @version 2.0
 */
public class YR_PatientGroupAdapter extends BaseExpandableListAdapter {
    private List<List<XC_ChatModel>> childrenData;
    private List<String> groupData;
    private Context context;
    private LayoutInflater inflater;
    /** 显示患者信息不全的对话框 */
    private YR_CommonDialog commonInfoDialog;


    public YR_PatientGroupAdapter(List<List<XC_ChatModel>> childrenData, List<String> groupData , int itemWidth, Activity activity) {
        this.groupData = groupData;
        this.childrenData = childrenData;
        this.context = activity;
        this._itemWidth = itemWidth;
        inflater = LayoutInflater.from(this.context);
    }

    /** PinnedHeaderExpandableListView页需要调用 */
    public List<String> getGroupDate() {
        return groupData;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return childrenData.get(groupPosition).get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return 0;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        if (groupPosition < 0)
            return 0;
        return childrenData.get(groupPosition).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return groupData.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return groupData.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    class GroupViewHolder {
        TextView xc_id_fragment_search_letter_view;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupViewHolder groupViewHolder;
        if (convertView != null) {
            groupViewHolder = (GroupViewHolder) convertView.getTag();
        } else {
            convertView = inflater.inflate(R.layout.xc_l_adapter_patient_letter_out_item, null);
            groupViewHolder = new GroupViewHolder();
            groupViewHolder.xc_id_fragment_search_letter_view = (TextView) convertView.findViewById(R.id.xc_id_fragment_search_letter_view);
            convertView.setTag(groupViewHolder);
        }
        if (groupViewHolder.xc_id_fragment_search_letter_view != null) {
            groupViewHolder.xc_id_fragment_search_letter_view.setText(groupData.get(groupPosition));
        }
        return convertView;
    }

    /** item的宽度 */
    private int _itemWidth = 0;

    class ChildViewHolder extends SwipeViewHolder{

        RelativeLayout rl_patient_layout;//左侧患者布局，点击跳转患者详情页
        ImageView iv_patient_icon;//患者头像
        TextView tv_patient_name;//患者姓名
        TextView tv_patient_gender_and_age;//患者性别和年龄
        View v_bottom_line;//行间底部分割线
        LinearLayout ll_patient_info;//姓名的父布局

        LinearLayout ll_attention;//特别关注/取消关注按钮
        TextView tv_attention;//特别关注/取消关注
        TextView tv_consult_fee;//图文咨询价格标识

        TextView tv_diagnosis;//诊断
        TextView tv_group;//我的分组

        TextView tv_cancel_attention;//已取消关注
        TextView tv_revisit;//x天后复诊
        TextView tv_no_medicine;//x天后无药
        TextView tv_repurchase;//高复购
        TextView tv_loyal;//忠实

        LinearLayout ll_right;//右边布局
        FlexboxLayout ll_ai_sign;//智能标签父控件

    }

    @Override
    public View getChildView(final int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        final ChildViewHolder childViewHolder;
        final XC_ChatModel bean = childrenData.get(groupPosition).get(childPosition);

        if (convertView != null) {
            childViewHolder = (ChildViewHolder) convertView.getTag();
            childViewHolder.hSView.scrollTo(0, 0);
        } else {
            childViewHolder = new ChildViewHolder();
            //获取Item
            convertView = LayoutInflater.from(context).inflate(R.layout.item_patient_swipe, parent, false);
            //获取内容显示区域的View
            View contentView = inflater.inflate(R.layout.xc_l_adapter_patientlist_item, null);
            childViewHolder.ll_right = (LinearLayout) contentView.findViewById(R.id.ll_right);
            childViewHolder.ll_patient_info = (LinearLayout) contentView.findViewById(R.id.ll_patient_info);
            childViewHolder.iv_patient_icon = (XCRoundedImageView) contentView.findViewById(R.id.iv_patient_icon);
            childViewHolder.tv_patient_name = (TextView) contentView.findViewById(R.id.tv_patient_name);
            childViewHolder.tv_patient_gender_and_age = (TextView) contentView.findViewById(R.id.tv_patient_gender_and_age);
            childViewHolder.v_bottom_line = contentView.findViewById(R.id.v_bottom_line);
            childViewHolder.rl_patient_layout = (RelativeLayout) contentView.findViewById(R.id.rl_patient_layout);
            childViewHolder.tv_consult_fee = (TextView) contentView.findViewById(R.id.tv_consult_fee);

            childViewHolder.tv_diagnosis = (TextView) contentView.findViewById(R.id.tv_diagnosis);
            childViewHolder.tv_group = (TextView) contentView.findViewById(R.id.tv_group);

            childViewHolder.tv_cancel_attention = (TextView) contentView.findViewById(R.id.tv_cancel_attention);
            childViewHolder.tv_revisit = (TextView) contentView.findViewById(R.id.tv_revisit);
            childViewHolder.tv_no_medicine = (TextView) contentView.findViewById(R.id.tv_no_medicine);
            childViewHolder.tv_repurchase = (TextView) contentView.findViewById(R.id.tv_repurchase);
            childViewHolder.tv_loyal = (TextView) contentView.findViewById(R.id.tv_loyal);
            childViewHolder.ll_ai_sign = (FlexboxLayout) contentView.findViewById(R.id.ll_ai_sign);

            //获取操作区的View
            View actionView = LayoutInflater.from(context).inflate(R.layout.yr_adapter_attention_item, parent, false);
            childViewHolder.ll_attention = (LinearLayout) actionView.findViewById(R.id.ll_attention);
            childViewHolder.tv_attention = (TextView) actionView.findViewById(R.id.tv_attention);

            //获取item组件
            childViewHolder.hSView = (HorizontalScrollView) convertView.findViewById(R.id.hsv);
            childViewHolder.viewContainer = (LinearLayout) convertView.findViewById(R.id.item_view_container);
            childViewHolder.viewContainer.addView(contentView);
            childViewHolder.viewContainer.addView(actionView);
            convertView.setTag(childViewHolder);
            childViewHolder.hSView.setTag(childViewHolder);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        childViewHolder.ll_patient_info.setLayoutParams(lp);

        //获取item的宽度
        ViewTreeObserver vto = childViewHolder.hSView.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (_itemWidth == 0) {
                    _itemWidth = childViewHolder.hSView.getMeasuredWidth();
                    notifyDataSetChanged();
                }
            }
        });
        //设置默认宽度
        ViewGroup.LayoutParams lpContent = childViewHolder.viewContainer.getChildAt(0).getLayoutParams();
        lpContent.width = _itemWidth;
        //设置默认宽度
        final ViewGroup.LayoutParams lpAction = childViewHolder.viewContainer.getChildAt(1).getLayoutParams();
        lpAction.width = (_itemWidth / 4);
        SwipeOnTouchListener swipeOnTouchListener = new SwipeOnTouchListener();
        //设置滑动事件监听
        childViewHolder.hSView.setOnTouchListener(swipeOnTouchListener);


//      设置行间底部分割线，如果是当前字母最后一个则隐藏
        if (childrenData.get(groupPosition).size() - 1 == childPosition) {
            childViewHolder.v_bottom_line.setVisibility(View.INVISIBLE);
        }else {
            childViewHolder.v_bottom_line.setVisibility(View.VISIBLE);
        }
        childViewHolder.ll_right.getMeasuredWidth();

//      update by cyr on 2018/7/30 性别和年龄
        String gender = bean.getUserPatient().getPatientGender();
        String genderStr = "";
        if (CommonConfig.GENDER_MALE.equals(bean.getUserPatient().getPatientGender())) {
            genderStr = "男";
        } else if (CommonConfig.GENDER_FEMALE.equals(bean.getUserPatient().getPatientGender())) {
            genderStr = "女";
        }


        //性别|年龄（三种情况宽度固定，判断出控件宽度）
        int screenWidth = UtilScreen.getScreenWidthPx(context);
        int rightWidth = 0;

        String age = bean.getUserPatient().getPatientAge();
        if (!TextUtils.isEmpty(gender) && !TextUtils.isEmpty(age)) {
            childViewHolder.tv_patient_gender_and_age.setText(genderStr + " | " + age + "岁");
            rightWidth = 174;
        } else if (TextUtils.isEmpty(gender) && !TextUtils.isEmpty(age)) {
            childViewHolder.tv_patient_gender_and_age.setText(age + "岁");
            rightWidth = 105;
        } else if (!TextUtils.isEmpty(gender) && TextUtils.isEmpty(age)) {
            childViewHolder.tv_patient_gender_and_age.setText(genderStr);
            rightWidth = 39;
        } else {
            childViewHolder.tv_patient_gender_and_age.setText("");
        }

//      姓名
        childViewHolder.tv_patient_name.setText(Utils.getPatientDisplayName(bean.getUserPatient().getPatientMemoName()
                , bean.getUserPatient().getPatientName()));

        //设置最大宽度
        int maxWidth = screenWidth - UtilScreen.dip2px(context,10*2 + 70 + 10 + 10) - rightWidth;
        childViewHolder.tv_patient_name.setMaxWidth(maxWidth);

//      图文咨询价格
        long consultCost ;
        try {
            consultCost = Long.parseLong(bean.getUserPatient().getPayAmount());
        }catch (Exception e){
            consultCost = 0;
        }
        if (consultCost >= 100) {
            childViewHolder.tv_consult_fee.setText("咨询费" + consultCost/100 + "元");
            childViewHolder.tv_consult_fee.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.tv_consult_fee.setVisibility(View.GONE);
        }


        //    设置智能标签
        if ("1".equals(bean.getUserPatient().getSubscribe())) {
            childViewHolder.tv_cancel_attention.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.tv_cancel_attention.setVisibility(View.GONE);
        }

        if (TextUtils.isEmpty(bean.getUserPatient().getXdayRevisit())) {
            childViewHolder.tv_revisit.setVisibility(View.GONE);
        } else if ("0".equals(bean.getUserPatient().getXdayRevisit())) {
            childViewHolder.tv_revisit.setVisibility(View.VISIBLE);
            childViewHolder.tv_revisit.setText("应今天复诊");
        } else {
            childViewHolder.tv_revisit.setVisibility(View.VISIBLE);
            childViewHolder.tv_revisit.setText(bean.getUserPatient().getXdayRevisit() + "天后复诊");
        }

        if (TextUtils.isEmpty(bean.getUserPatient().getXdayNoMedicine())) {
            childViewHolder.tv_no_medicine.setVisibility(View.GONE);
        } else if ("0".equals(bean.getUserPatient().getXdayNoMedicine())) {
            childViewHolder.tv_no_medicine.setText("今天无药了");
            childViewHolder.tv_no_medicine.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.tv_no_medicine.setText(bean.getUserPatient().getXdayNoMedicine() + "天后无药");
            childViewHolder.tv_no_medicine.setVisibility(View.VISIBLE);
        }

        if ("1".equals(bean.getUserPatient().getRepurchase())) {
            childViewHolder.tv_repurchase.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.tv_repurchase.setVisibility(View.GONE);
        }

        if ("1".equals(bean.getUserPatient().getLoyalCustomers())) {
            childViewHolder.tv_loyal.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.tv_loyal.setVisibility(View.GONE);
        }

        if (!"1".equals(bean.getUserPatient().getSubscribe()) && TextUtils.isEmpty(bean.getUserPatient().getXdayRevisit())
                && TextUtils.isEmpty(bean.getUserPatient().getXdayNoMedicine()) && !"1".equals(bean.getUserPatient().getRepurchase())
                && !"1".equals(bean.getUserPatient().getLoyalCustomers()) && childViewHolder.tv_consult_fee.getVisibility() == View.GONE) {
            childViewHolder.ll_ai_sign.setVisibility(View.GONE);
        } else {
            childViewHolder.ll_ai_sign.setVisibility(View.VISIBLE);
        }

        if (!TextUtils.isEmpty(bean.getUserPatient().getMyGroup())) {
            childViewHolder.tv_group.setText(Html.fromHtml("<font color= '#7f848d'>我的分组：</font>" + bean.getUserPatient().getMyGroup()));
            childViewHolder.tv_group.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.tv_group.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(bean.getUserPatient().getDiagnosis())) {
            childViewHolder.tv_diagnosis.setText(Html.fromHtml("<font color= '#7f848d'>诊断：</font>" + bean.getUserPatient().getDiagnosis()));
            childViewHolder.tv_diagnosis.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.tv_diagnosis.setVisibility(View.GONE);
        }

//      加载患者头像
        //显式的将checkActualViewSize设为false, 这样图片的缓存也将只会保存一个副本,保证第二次查询时可以直接命中
        //具体原因可以参考这个链接 http://www.cnblogs.com/wuxilin/p/4333241.html
        ImageAware imageAware = new ImageViewAware(childViewHolder.iv_patient_icon, false);
        String patientIcon = bean.getUserPatient().getPatientImgHead();
        if (!TextUtils.isEmpty(patientIcon) && URLUtil.isValidUrl(patientIcon)) {
            XCApplication.displayImage(patientIcon, childViewHolder.iv_patient_icon, XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default));
        } else {
            XCApplication.base_imageloader.displayImage("drawable://" + R.mipmap.xc_d_chat_patient_default, imageAware, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_patient_default));
        }

        //右侧划出按钮的样式设置：特别关注的患者显示“取消关注”，非特别关注的患者显示“特别关注”
        if ("true".equals(bean.getUserPatient().getIsAttention())) {
            if (!TextUtils.isEmpty(bean.getUserPatient().getPatientId())) {
                childViewHolder.tv_attention.setText("取消关注");
                childViewHolder.tv_attention.setBackgroundColor(context.getResources().getColor(R.color.c_gray_999999));
            } else{//V2.5暂不处理小七助手

            }
        } else {
            childViewHolder.tv_attention.setText("特别关注");
            childViewHolder.tv_attention.setBackgroundColor(context.getResources().getColor(R.color.c_orange_ff9000));
        }
        //V2.5需求 ：医生首次登陆的时候，列表中的第一项有展开
        if (UtilSP.getAttention()) {
            UtilSP.setAttention(false);
            if (groupPosition == 0 && childPosition == 0) {
                if ("false".equals(bean.getUserPatient().getIsAttention())) {
                    convertView.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            childViewHolder.hSView.smoothScrollTo(lpAction.width, 0);
                        }
                    },100);
                    convertView.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            childViewHolder.hSView.smoothScrollTo(0, 0);
                        }
                    },1000);
                }
            }
        }

        childViewHolder.ll_attention.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onClickItemBtn != null)
                    onClickItemBtn.onClickAttention(bean, groupPosition,childPosition);
            }
        });

        childViewHolder.rl_patient_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNextActivity(bean);
            }
        });

        childViewHolder.tv_cancel_attention.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onClickItemBtn != null)
                    onClickItemBtn.onClickSign(v, bean.getUserPatient().getSubscribeMsg());
            }
        });
        childViewHolder.tv_revisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onClickItemBtn != null)
                    onClickItemBtn.onClickSign(v, bean.getUserPatient().getXdayRevisitMsg());
            }
        });
        childViewHolder.tv_no_medicine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onClickItemBtn != null)
                    onClickItemBtn.onClickSign(v, bean.getUserPatient().getXdayNoMedicineMsg());
            }
        });
        childViewHolder.tv_repurchase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onClickItemBtn != null)
                    onClickItemBtn.onClickSign(v, bean.getUserPatient().getRepurchaseMsg());
            }
        });
        childViewHolder.tv_loyal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onClickItemBtn != null)
                    onClickItemBtn.onClickSign(v, bean.getUserPatient().getLoyalCustomersMsg());
            }
        });

        return convertView;
    }

    /** 进入患者详细资料页
     * @param bean*/
    private void startNextActivity(XC_ChatModel bean) {
        if (TextUtils.isEmpty(bean.getUserPatient().getPatientName())) {
            //提示患者资料不全
            if (commonInfoDialog == null) {
                commonInfoDialog = new YR_CommonDialog(context, "患者资料不全!", "", "我知道了") {

                    @Override
                    public void confirmBtn() {
                        dismiss();
                    }
                };
            }
            commonInfoDialog.show();
            return;
        }
        ToJumpHelp.toJumpChatPatientInfoActivity((Activity) context,bean);
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }


    LinkedHashMap<String, Integer> sava_letter_position_map = new LinkedHashMap<>();

    // 获取字母的位置
    public Integer getPositionFromLetter(String letter) {
        return sava_letter_position_map.get(letter);
    }

    /** 和患者列表中的字母位置对应：右侧按住哪个字母，列表就滑动到相应位置 */
    public LinkedHashMap<String, Integer> initLettersPosition(List<String> listParent, List<List<XC_ChatModel>> listChild) {
        String record_last_letter = null;
        for (int i = 0; i < listParent.size(); i++) {
            String letter = listParent.get(i);
            if (!letter.equals(record_last_letter)) {
                if (listChild.size() > 0 && listChild.get(i) != null) {
                    if (i == 0) {
                        sava_letter_position_map.put(letter, 0);
                    } else {
                        // position等于上一个字母的位置+改字母的子项的数量
                        int position = 1 + sava_letter_position_map.get(record_last_letter) + listChild.get(i - 1).size();
                        sava_letter_position_map.put(letter, position);
                    }
                }
            }
            record_last_letter = letter;
        }
        return sava_letter_position_map;
    }

    public void updateABCPosition() {
        sava_letter_position_map.clear();
            if (groupData != null && groupData.size() > 0 && childrenData != null && childrenData.size() == groupData.size()) {
            initLettersPosition(groupData, childrenData);
        }
    }

    /**
     * 监听的回调接口
     * */
    public interface OnClickItemBtn {
        /**
         * 特别关注的切换的调用方法
         *
         * @param patientBean   设置或取消设置选中的患者bean
         * @param groupPosition 选中患者的字母位置
         * @param groupPosition 选中患者的在对应字母的患者列表中的位置
         */
        void onClickAttention(XC_ChatModel patientBean, int groupPosition, int childPositon);

        /**
         * 点击智能标签调用方法
         *
         * @param view    点击的控件
         * @param content 智能标签说明文字
         */
        void onClickSign(View view, String content);
    }

    /**
     * 设置按钮的监听
     *
     * @param onClickItemBtn 监听
     */
    public void setOnClickItemBtn(OnClickItemBtn onClickItemBtn) {
        this.onClickItemBtn = onClickItemBtn;
    }

    /** 按钮的回调接口 */
    private OnClickItemBtn onClickItemBtn;



}