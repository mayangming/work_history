package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.SQ_ExamineAModel;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.util.List;

/**
 * @author 赖善琦
 * @version 2.7.0
 */

public class SQ_ExamineAdapterA extends XCBaseAdapter<SQ_ExamineAModel> {

    public SQ_ExamineAdapterA(Context context, List<SQ_ExamineAModel> list) {
        super(context, list);
    }

    @Override
    public boolean isEnabled(int position) {
        return !"0".equals(list.get(position).getState()) && super.isEnabled(position);
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        SQ_ExamineAModel model = list.get(position);
        ExamineAHolder holder;
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.sq_item_inspect_a, null);
            holder = new ExamineAHolder(view);
            view.setTag(holder);

        } else {
            holder = (ExamineAHolder) view.getTag();
        }

        if (isEnabled(position)) {
            // 若被选中
            if (model.isCheck()) {
                XCApplication.base_imageloader.displayImage(model.getImageChoosed(), holder.sk_id_iv_inspectAimg, XCImageLoaderHelper.getDisplayImageOptions());
                view.setBackgroundResource(R.color.c_gray_eeeeee);
                holder.sk_id_tv_inspectAtext.setTextColor(context.getResources().getColor(R.color.c_red_ff3b30));
            } else {
                XCApplication.base_imageloader.displayImage(model.getImage(), holder.sk_id_iv_inspectAimg, XCImageLoaderHelper.getDisplayImageOptions());
                holder.sk_id_tv_inspectAtext.setTextColor(context.getResources().getColor(R.color.c_grey_444444));
                view.setBackgroundResource(R.color.c_white_ffffff);
            }
        } else {
            XCApplication.base_imageloader.displayImage(model.getImage(), holder.sk_id_iv_inspectAimg, XCImageLoaderHelper.getDisplayImageOptions());
            holder.sk_id_tv_inspectAtext.setTextColor(context.getResources().getColor(R.color.c_gray_bbbbbb));
            view.setBackgroundResource(R.color.c_white_ffffff);
        }
        // 分类名称
        holder.sk_id_tv_inspectAtext.setText(model.getName());

        return view;
    }

    public class ExamineAHolder {
        /**
         * 一级分类图片
         */
        ImageView sk_id_iv_inspectAimg;
        /**
         * 一级分类名称
         */
        TextView sk_id_tv_inspectAtext;

        ExamineAHolder(View convertView) {

            sk_id_iv_inspectAimg = convertView.findViewById(R.id.sk_id_iv_inspectAimg);
            sk_id_tv_inspectAtext = convertView.findViewById(R.id.sk_id_tv_inspectAtext);
        }
    }

}
