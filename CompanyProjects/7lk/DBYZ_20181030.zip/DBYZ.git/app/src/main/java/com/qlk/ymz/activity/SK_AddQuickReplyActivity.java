package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

/**
 * @version 2.0.0
 * @description 新增快捷回复界面
 * Created by 赖善琦 on 2015/6/17.
 */
public class SK_AddQuickReplyActivity extends DBActivity {
    /**
     * 输入新增快捷回复的控件
     */
    private EditText sk_id_add_reply_content_tv;

    private int maxLength;

    private int minLength;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sk_l_activity_add_reply);
        super.onCreate(savedInstanceState);

        getLimitValue();
        delayOpen();
    }

    public void getLimitValue() {

        maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.QUICK_REPLY, 0, 300);
        minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.QUICK_REPLY, 1, 1);

        sk_id_add_reply_content_tv.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});

    }

    /**
     * created by songxin,date：2016-4-23,about：bi,begin
     */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SK_AddQuickReplyActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    /**
     * 初始化title
     */
    public void initTitle() {
        findViewById(R.id.sx_id_title_left).setOnClickListener(this);
        TextView sx_id_title_right_btn = (TextView) findViewById(R.id.sx_id_title_right_btn);
        sx_id_title_right_btn.setText("保存");
        sx_id_title_right_btn.setOnClickListener(this);
        sx_id_title_right_btn.setVisibility(View.VISIBLE);
        ((TextView) findViewById(R.id.sx_id_title_center)).setText("添加快捷回复");
    }

    /**
     * 初始化控件
     */
    @Override
    public void initWidgets() {
        initTitle();

        sk_id_add_reply_content_tv = getViewById(R.id.sk_id_add_reply_content_tv);
    }

    /**
     * 点击监听
     */
    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.sx_id_title_left://左侧返回按钮
                delayClose();
                break;
            case R.id.sx_id_title_right_btn://右侧保存按钮
                String content = sk_id_add_reply_content_tv.getText().toString().trim();
                if (minLength > 0 && UtilString.isBlank(content)) {
                    shortToast("请填写内容");
                    return;
                }
                if (content.length() < minLength) {
                    shortToast("文本的长度不可小于" + minLength);
                    return;
                }
                requestQuickReplyAdd(content);
                break;
        }
    }

    @Override
    public void listeners() {
    }

    /**
     * 请求新增快捷回复的接口
     *
     * @param content 快捷回复的内容
     */
    public void requestQuickReplyAdd(String content) {
        RequestParams params = new RequestParams();
        params.put("content", content);

        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.quickreply_add), params, new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    myFinish();
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                // 处理code操作
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SK_AddQuickReplyActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }

        });
    }

    /**
     * 无网络背景这里不做处理
     */
    @Override
    public void onNetRefresh() {

    }

    @Override
    public void finish() {
        super.finish();
//      关闭页面动画
        overridePendingTransition(R.anim.activity_no_move, R.anim.activity_close_down);
    }

    /** 延迟弹出软键盘 */
    public void delayOpen(){
        getWindow().getDecorView().postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(sk_id_add_reply_content_tv, 0);
            }
        }, 300);
    }

    /** 延迟关闭页面，先关闭键盘，防止返回的页面出现抖动 */
    public void delayClose(){
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(sk_id_add_reply_content_tv.getWindowToken(), 0);
        getWindow().getDecorView().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        },100);
    }
}
