package com.qlk.ymz.db.im.chatmodel;

/**
 * 咨询列表信息BEAN
 * @author 徐金山
 * @version 1.5.0
 */
public class JS_ChatListModel extends XC_ChatModel {
    //==========常量==========
    /** 因“公告通知”类型的信息是没有patientId值的，故使用预设值对“公告通知”类型的信息进行patientId值的定义 */
    public static final String NOTICE_ID = "noticeId";
    /** 因“系统公告”类型的信息是没有patientId值的，故使用预设值对“系统公告”类型的信息进行patientId值的定义 */
    public static final String ACCOUNT_ID = "accountId";
    //add by tengfei 2016/09/07
    /**因客服发来的消息没有patientId的，故使用预设值对客服发来的消息进行设置*/
    public static final String SERVICE_ID="serviceId";
    /** 此记录被逻辑删除的标识（0:未被逻辑删除；1:已被逻辑删除） */
    public static final String FLAG_VISIBLE = "0";
    /** 此记录被逻辑删除的标识（0:未被逻辑删除；1:已被逻辑删除） */
    public static final String FLAG_GONE = "1";

    //==========变量==========
    /** 【置顶】排序时间（T2）,精确到毫秒 */
    private String topSortTime = "0";
    /** 此记录被逻辑删除的标识（0:未被逻辑删除；1:已被逻辑删除；默认值：0） */
    private String deletedflag = "0";

    /**
     * 特别的消息类型
     * <p>说明：因业务上对“购药咨询”类型消息的处理有个性化逻辑，为支持对“购药咨询”类型消息的个性化逻辑，特别建立此属性支持。
     * <p>消息类型信息参看JS_ChatListDB.F_MSG_TYPE。
     * <p>（消息类型：64表示：购药咨询[患者自主购药申请]）
     */
    private String msgTypeBuyMedicineRequire = "";
    /** 购药咨询信息 */
    private String buyMedicineRequireMsg = "";

    public String getDeletedflag() {
        return deletedflag;
    }

    public void setDeletedflag(String deletedflag) {
        this.deletedflag = deletedflag;
    }

    public String getTopSortTime() {
        if(null == topSortTime || topSortTime.trim().length() == 0 || "null".equalsIgnoreCase(topSortTime.trim())) {
            topSortTime = "0";
        }
        return topSortTime;
    }

    public void setTopSortTime(String topSortTime) {
        if(null != topSortTime) {
            this.topSortTime = topSortTime;
        }
    }

    public String getMsgTypeBuyMedicineRequire() {
        return msgTypeBuyMedicineRequire;
    }

    public void setMsgTypeBuyMedicineRequire(String msgTypeBuyMedicineRequire) {
        this.msgTypeBuyMedicineRequire = msgTypeBuyMedicineRequire;
    }

    public String getBuyMedicineRequireMsg() {
        return buyMedicineRequireMsg;
    }

    public void setBuyMedicineRequireMsg(String buyMedicineRequireMsg) {
        this.buyMedicineRequireMsg = buyMedicineRequireMsg;
    }

    public String toString() {
        return "XC_ChatModel{" +
                ", topSortTime='" + topSortTime + '\'' +
                '}';
    }

    /**
     * 将本对象与传入对象进行比较，比较规则为：<p>
     * （1）若“患者图像”,“患者名称”,“患者性别(0：男；1：女)”,“患者年龄”,“屏蔽此患者消息的状态标示”都相同，则返回true
     * （2）若“患者图像”,“患者名称”,“患者性别(0：男；1：女)”,“患者年龄”,“屏蔽此患者消息的状态标示”不都相同，则返回false
     * @param obj 要比较的对象
     * @return 比较结果（true：要比较的字段的值都相等；false：要比较的字段的值不都相等）
     */
    public boolean equalsObj(XC_ChatModel obj) {
        // 两个对象要比较的相应字段的值是否都相等的标识（true：要比较的字段的值都相等；false：要比较的字段的值不都相等；默认值：true）
        boolean flag;
        UserPatient thisUserPaitent = this.getUserPatient();
        String patientId_01 = thisUserPaitent.getPatientId();
        String patientImgHead_01 = thisUserPaitent.getPatientImgHead();
        String patientName_01 = thisUserPaitent.getPatientName();
        String patientGender_01 = thisUserPaitent.getPatientGender();
        String patientAge_01 = thisUserPaitent.getPatientAge();
        String isShield_01 = thisUserPaitent.getIsShield();
        String cityName01 = thisUserPaitent.getCityName();
        String isAttention01 = thisUserPaitent.getIsAttention();
        String createTime01 = thisUserPaitent.getCreateTime();
        String payAmount01 = thisUserPaitent.getPayAmount();

        UserPatient objUserPaitent = obj.getUserPatient();
        String patientId_02 = objUserPaitent.getPatientId();
        String patientImgHead_02 = objUserPaitent.getPatientImgHead();
        String patientName_02 = objUserPaitent.getPatientName();
        String patientGender_02 = objUserPaitent.getPatientGender();
        String patientAge_02 = objUserPaitent.getPatientAge();
        String isShield_02 = objUserPaitent.getIsShield();
        String cityName02 = objUserPaitent.getCityName();
        String isAttention02 = objUserPaitent.getIsAttention();
        String createTime02 = objUserPaitent.getCreateTime();
        String payAmount02 = objUserPaitent.getPayAmount();

        if(patientId_01.equals(patientId_02) && patientImgHead_01.equals(patientImgHead_02)
                && patientName_01.equals(patientName_02) && patientGender_01.equals(patientGender_02)
                && patientAge_01.equals(patientAge_02) && isShield_01.equals(isShield_02) && cityName01.equals(cityName02)
                && isAttention01.equals(isAttention02) && createTime01.equals(createTime02)
                && payAmount01.equals(payAmount02)) {
            flag = true;
        }else {
            flag = false;
        }

        return flag;
    }
}
