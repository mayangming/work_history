package com.qlk.ymz.activity;

import android.os.Bundle;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.view.XCSwitchButton;

/**
 * 通用页
 * @author 徐金山
 * @version 1.4.0
 */
public class JS_GeneralSettingActivity extends DBActivity {
    /**
     * 标题
     */
    private XCTitleCommonLayout title;
    /**
     * 使用听筒播放语音按钮
     */
    private XCSwitchButton switchBtn_switch;

    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.js_activity_general_setting);
        super.onCreate(savedInstanceState);

    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(JS_GeneralSettingActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    public void initWidgets() {
        // update by jingyu start
        title = getViewById(R.id.xc_id_model_titlebar);
        title.setTitleCenter(true, "通用");
        title.setTitleLeft(true, "");
        // update by jingyu end

        switchBtn_switch = getViewById(R.id.switchBtn_switch);

        if (UtilSP.getIsSpeakLoud()) {
            switchBtn_switch.setState(false);
        } else {
            switchBtn_switch.setState(true);
        }
    }

    public void listeners() {
        switchBtn_switch.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            public void open() {
                dShortToast("open");
                UtilSP.setIsSpeakLoud(false);
            }

            public void close() {
                dShortToast("close");
                UtilSP.setIsSpeakLoud(true);
            }
        });
    }

    public void onNetRefresh() {

    }
}
