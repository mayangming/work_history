package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.SK_MedicineClassificationAModel;
import com.qlk.ymz.model.SK_MedicineClassificationBModel;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by smile on 2017/12/13
 * 全科一级分类适配器
 */

public class YR_AllMedicineClassAdapter extends XCBaseAdapter<SK_MedicineClassificationAModel> {
    private LayoutInflater mInflater;
    private ArrayList<SK_MedicineClassificationAModel> list;

    public YR_AllMedicineClassAdapter(Context context, List<SK_MedicineClassificationAModel> list) {
        super(context, list);
        this.list = (ArrayList<SK_MedicineClassificationAModel>) list;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        SK_MedicineClassificationAModel model = list.get(position);
        ViewHolder viewHolder;
        if (view == null) {
            view = mInflater.inflate(R.layout.yr_item_allmedicineclass, null);

            viewHolder = new ViewHolder();
            viewHolder.iv_type_icon = (ImageView) view.findViewById(R.id.iv_type_icon);
            viewHolder.tv_second_name = (TextView) view.findViewById(R.id.tv_second_name);
            viewHolder.tv_type_name = (TextView) view.findViewById(R.id.tv_type_name);

           view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }

        XCApplication.base_imageloader.displayImage(model.getImage(), viewHolder.iv_type_icon, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.bg_pic_default));
        if (model.getListB() != null && model.getListB().size() > 0) {
            SK_MedicineClassificationBModel modelB = model.getListB().get(0);
            if (modelB != null) {
                viewHolder.tv_second_name.setText(modelB.getName());
            }
        }
        viewHolder.tv_type_name.setText(model.getName());

        return view;
    }


    class ViewHolder {
        TextView tv_type_name;
        TextView tv_second_name;
        ImageView iv_type_icon;
    }



}
