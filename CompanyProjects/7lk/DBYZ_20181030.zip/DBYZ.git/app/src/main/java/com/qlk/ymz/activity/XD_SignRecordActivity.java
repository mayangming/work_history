package com.qlk.ymz.activity;

import android.media.AudioManager;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.CalendarAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.parse.Parse2MonthSignInBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.WrapContentHeightViewPager;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilMedia;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.HashMap;
import java.util.LinkedHashMap;


/**
 * Created by xiedongtd on 2016/11/3.
 * 阳光化签到记录页
 */

public class XD_SignRecordActivity extends DBActivity {

    /**
     * 标题栏
     */
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**
     * 切换月份向前
     */
    private LinearLayout ll_change_month_left;
    /**
     * 向前切换图标
     */
    private ImageView iv_change_month_left;
    /**
     * 切换月份 向后
     */
    private LinearLayout ll_change_month_right;
    /**
     * 向后图标
     */
    private ImageView iv_change_month_right;
    /**
     * 月份
     */
    private TextView tv_month;
    /**
     * 月份容器
     */
    private WrapContentHeightViewPager vp_calendar_change;
    /**
     * 切换月份适配器
     */
    private CalendarAdapter mCalendarAdapter;
    /**
     * 保存签到记录
     * key 是年份加月份 例如 201611
     */
    private HashMap<String, Parse2MonthSignInBean> mMonthSignInBeanHashMap = new
            LinkedHashMap<String, Parse2MonthSignInBean>();
    /**
     * 签到的月数
     */
    private int monthNum;
    /**
     * 签到开始年份
     */
    private int startYear;
    /**
     * 签到开始月份
     */
    private int startMonth;
    /**
     * 未签到天数
     */
    private TextView tv_unSign_num;
    /**
     * 是否有签到成功的操作
     */
    private boolean isSign = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_sign_record);
        super.onCreate(savedInstanceState);
        //进来请求当月签到记录
        requestMonthRecord("");
    }

    /** created by songxin,date：2017-4-10,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_SignRecordActivity.class);
    }

    /** created by songxin,date：2016-4-10,about：bi,end */

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "签到");
        xc_id_model_titlebar.setTitleRight2(true,0,"规则说明");
        xc_id_model_titlebar.setTitleLeft(true, "");
        ll_change_month_left = getViewById(R.id.ll_change_month_left);
        iv_change_month_left = getViewById(R.id.iv_change_month_left);
        ll_change_month_right = getViewById(R.id.ll_change_month_right);
        iv_change_month_right = getViewById(R.id.iv_change_month_right);
        tv_month = getViewById(R.id.tv_month);
        vp_calendar_change = getViewById(R.id.vp_calendar_change);
        tv_unSign_num = getViewById(R.id.tv_unSign_num);
    }

    @Override
    public void listeners() {
        xc_id_model_titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isSign) {
                    setResult(RESULT_OK);
                }
                myFinish();
            }
        });
        xc_id_model_titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WebviewBean bean = new WebviewBean(AppConfig.getH5Url(AppConfig.sign_explain));
                bean.title = "规则说明";
                myStartActivity(JS_WebViewActivity.newIntent(XD_SignRecordActivity.this, bean));
            }
        });
        //切换月份设置监听
        ll_change_month_left.setOnClickListener(this);
        ll_change_month_right.setOnClickListener(this);
        //viewpager添加滑动监听
        vp_calendar_change.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                //调整viewpager高度
                vp_calendar_change.resetHeight(position);
                //调整切换图标
                if (position == 0) {
                    iv_change_month_left.setImageResource(R.mipmap.xd_d_change_month_left_unclick);
                } else {
                    iv_change_month_left.setImageResource(R.mipmap.xd_d_change_month_left_click);
                }
                if (position == monthNum - 1) {
                    iv_change_month_right.setBackgroundResource(R.mipmap.xd_d_change_month_right_unclick);
                } else {
                    iv_change_month_right.setBackgroundResource(R.mipmap.xd_d_change_month_right_click);
                }
                //计算滑动到的年月份
                int currentYear = startYear +(startMonth+position-1)/12;
                int currentMonth = (startMonth+position-1) % 12+1;
                tv_month.setText(currentYear + "年" + currentMonth + "月");
                //拿到滑动当前月的签到记录
                Parse2MonthSignInBean parse2MonthSignInBean = mMonthSignInBeanHashMap.get(currentYear + "" + currentMonth);
                if (parse2MonthSignInBean == null) {
                    //未请求过此月数据
                    String key = "";
                    if (currentMonth < 10) {
                        key = currentYear + "-0" + currentMonth;
                    } else {
                        key = currentYear + "-" + currentMonth;
                    }
                    requestMonthRecord(key);
                } else {
                    //请求过此月数据
                    tv_unSign_num.setText(parse2MonthSignInBean.getDescription());
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }

    @Override
    public void showPage() {
        showTitleLayout(true);
    }

    @Override
    public void onNetRefresh() {
        requestMonthRecord("");
    }

    @Override
    public void onBackPressed() {
        if (isSign) {
            setResult(RESULT_OK);
        }
        super.onBackPressed();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_change_month_left:
                // 向前切换
                vp_calendar_change.setCurrentItem(vp_calendar_change.getCurrentItem() - 1);
                break;
            case R.id.ll_change_month_right:
                //  向后切换
                vp_calendar_change.setCurrentItem(vp_calendar_change.getCurrentItem() + 1);
                break;
        }
        super.onClick(v);
    }

    /**
     * 请求每月的签到记录
     *
     * @param requestMonth 查看那个月的数据yyyy-MM  ""默认当月
     */
    public void requestMonthRecord(String requestMonth) {
        RequestParams params = new RequestParams();
        params.add("date", requestMonth);
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.get_month_sign_info), params,
                new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            Parse2MonthSignInBean parse2MonthSignInBean = new Parse2MonthSignInBean();
                            parse2MonthSignInBean.parseJson(result_bean);
                            String key = parse2MonthSignInBean.getYear() + UtilString.toInt(parse2MonthSignInBean.getMonth());
                            mMonthSignInBeanHashMap.put(key, parse2MonthSignInBean);
                            if (mCalendarAdapter == null) {
                                //计算显示几个月
                                monthNum = (UtilString.toInt(parse2MonthSignInBean.getYear())
                                        - UtilString.toInt(parse2MonthSignInBean.getOpenYear())) * 12 +
                                        UtilString.toInt(parse2MonthSignInBean.getMonth())
                                        - UtilString.toInt(parse2MonthSignInBean.getOpenMonth()) + 1;
                                //计算显示的最早月份
                                startYear = UtilString.toInt(parse2MonthSignInBean.getOpenYear());
                                startMonth = UtilString.toInt(parse2MonthSignInBean.getOpenMonth());
                                //给viewpager设置适配器
                                mCalendarAdapter = new CalendarAdapter(XD_SignRecordActivity.this, vp_calendar_change,
                                        mMonthSignInBeanHashMap, monthNum, key);
                                vp_calendar_change.setAdapter(mCalendarAdapter);
                                //初始化年月UI显示
                                tv_month.setText(startYear + "年" + startMonth + "月");
                                //切换到当前月份
                                vp_calendar_change.setCurrentItem(monthNum - 1);
                            } else {
                                //刷新ui
                                mCalendarAdapter.notifyDataSetChanged();
                            }
                            //刷新未签到天数UI
                            tv_unSign_num.setText(parse2MonthSignInBean.getDescription());
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        if (mCalendarAdapter == null) {
                            //当第一次拿不到月数据时显示无网页
                            showNoNetLayout();
                        } else {
                            tv_unSign_num.setText("");
                        }
                    }

                    public void onFinish() {
                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_SignRecordActivity.this,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

    /**
     * 签到
     *
     * @param date    签到或者补签日期yyyy-MM-dd
     * @param isToday 是否今天
     */
    public void signIn(String date, final boolean isToday) {
        RequestParams params = new RequestParams();
        params.add("date", date);
        params.add("type", "1");
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.replenish_sign), params, new
                XCHttpResponseHandler() {

                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (result_boolean) {
                            isSign = true;      //记录有签到成功的操作
                            Parse2MonthSignInBean parse2MonthSignInBean = new Parse2MonthSignInBean();
                            parse2MonthSignInBean.parseJson(result_bean);
                            String key = parse2MonthSignInBean.getYear() + UtilString.toInt(parse2MonthSignInBean.getMonth());
                            mMonthSignInBeanHashMap.put(key, parse2MonthSignInBean);
                            //刷新UI
                            mCalendarAdapter.notifyDataSetChanged();
                            tv_unSign_num.setText(parse2MonthSignInBean.getDescription());
                            //判断当前设备是否弹出过签到成功或者失败对话框,false就弹出,true不弹(一个设备只弹出一个)
                            if (!UtilDate.isToday(UtilString.toLong(GlobalConfigSP.getSignResultDialog()))) {
                                PF_SignInResultActivity.launch(XD_SignRecordActivity.this,parse2MonthSignInBean.getSignPoint(),PF_SignInResultActivity.MANUAL);
                            }else{
                                shortToast("已签到成功");
                            }
                            //如果签到的是今天,就关闭首页签到动画
                            if (isToday) {
                                UtilSP.setSignToday(System.currentTimeMillis() + "");
                            }
                            //播放声音
                            AudioManager mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
                            int current_system = mAudioManager.getStreamVolume(AudioManager.STREAM_SYSTEM);
                            int current_ring = mAudioManager.getStreamVolume(AudioManager.STREAM_RING);
                            int current_music = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                            if (current_system == 0 || current_ring == 0 || current_music == 0) {
                                // 什么都不做
                            } else {
                                if (0 < UtilString.toInt(parse2MonthSignInBean.getSignPoint())) {
                                    UtilMedia.openVoice(XD_SignRecordActivity.this, R.raw.sign_success);
                                } else if (0 == UtilString.toInt(parse2MonthSignInBean.getSignPoint())) {
                                    UtilMedia.openVoice(XD_SignRecordActivity.this, R.raw.sign_fail);
                                }
                            }
                        }
                    }

                    public void onFinish() {
                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_SignRecordActivity.this,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

}
