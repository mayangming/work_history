package com.qlk.ymz.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.CheckPatientBean;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * 恢复删除患者列表
 * Created by ${litao} on 2018/10/15.
 */

public class PatientsRecoverAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<CheckPatientBean> list = new ArrayList<>();
    private   Drawable drawable_man;
    private   Drawable drawable_woman;
    private ArrayList<CheckPatientBean> checkList = new ArrayList<>();
    private OnclickCheckListener onclickCheckListener;

    public PatientsRecoverAdapter(Context context, ArrayList<CheckPatientBean> list) {
        this.context = context;
        this.list = list;
        drawable_man = context.getResources().getDrawable(R.mipmap.icon_patient_man);
        drawable_woman = context.getResources().getDrawable(R.mipmap.icon_patient_women);
        drawable_man.setBounds(0, 0, drawable_man.getMinimumWidth(), drawable_man.getMinimumHeight());
        drawable_woman.setBounds(0, 0, drawable_man.getMinimumWidth(), drawable_man.getMinimumHeight());
    }

    public void update(ArrayList<CheckPatientBean> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return list.size()>0?list.size():0;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final Holder holder;
        if (convertView == null) {
            holder = new Holder();
            convertView = LayoutInflater.from(context).inflate(R.layout.item_patient_recover, null);
            holder.iv_patient_recover_head = convertView.findViewById(R.id.iv_patient_recover_head);
            holder.tv_patient_recover_name = convertView.findViewById(R.id.tv_patient_recover_name);
            holder.tv_patient_recover_age = convertView.findViewById(R.id.tv_patient_recover_age);
            holder.iv_patient_recover_check = convertView.findViewById(R.id.iv_patient_recover_check);
            holder.rl_check_item = convertView.findViewById(R.id.rl_check_item);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        final CheckPatientBean patientBean = list.get(position);
        XCApplication.displayImage(patientBean.getPatientImgHead(), holder.iv_patient_recover_head, XCImageLoaderHelper
                .getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default));
        holder.tv_patient_recover_name.setText(patientBean.getPatientName());

        if(!TextUtils.isEmpty(patientBean.getPatientAge()) && patientBean.getPatientAge()!=null){
            holder.tv_patient_recover_age.setText(patientBean.getPatientAge()+"岁");
        }else{
            holder.tv_patient_recover_age.setText("");
        }
        if ("1".equals(patientBean.getPatientGender())) {
            holder.tv_patient_recover_age.setCompoundDrawablePadding(30);
            holder.tv_patient_recover_age.setCompoundDrawables(drawable_man, null, null, null);
        } else if("0".equals(patientBean.getPatientGender())) {
            holder.tv_patient_recover_age.setCompoundDrawablePadding(30);
            holder.tv_patient_recover_age.setCompoundDrawables(drawable_woman, null, null, null);
        }else{
            holder.tv_patient_recover_age.setCompoundDrawables(null, null, null, null);
        }
        if(checkList.contains(patientBean)){
            holder.iv_patient_recover_check.setBackgroundResource(R.mipmap.sx_d_register_sure);
        }else{
            holder.iv_patient_recover_check.setBackgroundResource(R.mipmap.sx_d_register_no_sure);
        }


        holder.rl_check_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!checkList.contains(patientBean)){
                    checkList.add(patientBean);
                }else{
                    checkList.remove(patientBean);
                }
                onclickCheckListener.onClick(checkList);
                notifyDataSetChanged();
            }
        });


        return convertView;
    }


    public interface OnclickCheckListener {
        void onClick(ArrayList<CheckPatientBean> checkList);
    }

    public void setOnclickCheckListener(OnclickCheckListener onclickCheckListener) {
        this.onclickCheckListener = onclickCheckListener;
    }


    class Holder {
        //患者头像
        private XCRoundedImageView iv_patient_recover_head;
        //患者姓名
        private TextView tv_patient_recover_name;
        //患者年龄
        private TextView tv_patient_recover_age;
        //患者被选中
        private ImageView iv_patient_recover_check;
        //item点击事件
        private RelativeLayout rl_check_item;
    }
}
