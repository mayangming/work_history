package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.ConsultPatientGroupBean;
import com.qlk.ymz.util.UtilScreen;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;

import java.util.List;


/**
 * Created by xiedong on 2017/6/8.
 * 分组的适配器
 */

public class GroupAdapter extends XCBaseAdapter<ConsultPatientGroupBean> {


    public GroupAdapter(Context context, List<ConsultPatientGroupBean> list) {
        super(context, list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView != null) {
            viewHolder = (ViewHolder) convertView.getTag();
        } else {
            convertView =  LayoutInflater.from(context).inflate(R.layout.xd_item_group,
                    null);
            viewHolder = ViewHolder.getViewHolder(convertView);
        }

        //分组信息
        ConsultPatientGroupBean consultPatientGroupBean = list.get(position);

        //设置分组名称
        viewHolder.tv_group_name.setText(consultPatientGroupBean.getGroupName());

       //设置分组患者数目
        viewHolder.tv_group_patient_num.setText("("+consultPatientGroupBean.getGroupCount()+")");


        ViewGroup.LayoutParams layoutParams1 = viewHolder.tv_group_name.getLayoutParams();
        layoutParams1.width = ViewGroup.LayoutParams.WRAP_CONTENT;

        int w = View.MeasureSpec.makeMeasureSpec((1<<30)-1,View.MeasureSpec.AT_MOST);
        //获取组内数量宽
        viewHolder.tv_group_patient_num.measure(w,w);
        int numWidth = viewHolder.tv_group_patient_num.getMeasuredWidth();
        //获取组名宽
        viewHolder.tv_group_name.measure(w,w);
        int nameWidth = viewHolder.tv_group_name.getMeasuredWidth();
        //获取屏幕宽
        int width = UtilScreen.getScreenSize(context)[1];
        if((numWidth+nameWidth)>width){//超出行宽
            //给组名控件设置剩余的宽度
            layoutParams1.width = width-numWidth;
        }
        return convertView;
    }


     static class ViewHolder {
        //分组名称
        TextView tv_group_name;
      //组内患者数目
        TextView tv_group_patient_num;


        public ViewHolder(View convertView) {
            tv_group_name = (TextView) convertView.findViewById(R.id.tv_group_name);
            tv_group_patient_num = (TextView) convertView.findViewById(R.id.tv_group_patient_num);
        }

        public static ViewHolder getViewHolder(View convertview) {
            ViewHolder holder = (ViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new ViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }

}
