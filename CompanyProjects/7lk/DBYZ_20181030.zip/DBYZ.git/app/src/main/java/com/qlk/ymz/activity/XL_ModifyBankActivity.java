package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.UserBankBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.Utils;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import org.apache.http.Header;

/**
 * 修改银行卡
 *
 * @author cyr on 2017-2-13
 * @describe 无开户行支行信息的处理页面
 */
public class XL_ModifyBankActivity extends DBActivity {
    /** 添加银行卡布局 */
    private RelativeLayout sk_id_add_bank_card_rl;
    /** 银行名称 */
    private TextView sk_id_add_bank_tv;
    /** 说明内容 */
    private TextView xl_add_bank_tv_note;
    /** 依次银行卡卡号输入框、名字输入框、开户行输入框 */
    private EditText xl_add_bank_et_card,xl_add_bank_et_name,xl_add_bank_et_openCard;
    /** 编辑的银行卡对象 */
    private UserBankBean bankCardEntity;
    /** 固定值key */
    public static final String BANKBEAN = "bankbean";
    private static final String TIPS = "<font color='#666666'>开户行名称需填写省市，我们才能够划款成功哦，如：</font><font color='#2B98F6'>广东省广州增城支行。</font>";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        bankCardEntity = getIntent().getParcelableExtra(BANKBEAN);

        setContentView(R.layout.sk_l_activity_add_bank_card);
        super.onCreate(savedInstanceState);

        initTitle();
    }

    /** 初始化title */
    public void initTitle(){
        findViewById(R.id.sx_id_title_left).setOnClickListener(this);
        ((TextView)findViewById(R.id.sx_id_title_center)).setText("编辑银行卡");
        TextView sx_id_title_right_btn = (TextView) findViewById(R.id.sx_id_title_right_btn);
        sx_id_title_right_btn.setText("保存");
        sx_id_title_right_btn.setOnClickListener(this);
        sx_id_title_right_btn.setVisibility(View.VISIBLE);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_ModifyBankActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        sk_id_add_bank_card_rl = (RelativeLayout) findViewById(R.id.sk_id_add_bank_card_rl);
        sk_id_add_bank_tv = (TextView) findViewById(R.id.sk_id_add_bank_tv);
        xl_add_bank_et_card = (EditText) findViewById(R.id.xl_add_bank_et_card);
        xl_add_bank_et_name = (EditText) findViewById(R.id.xl_add_bank_et_name);
        xl_add_bank_et_openCard = (EditText) findViewById(R.id.xl_add_bank_et_openCard);
        xl_add_bank_tv_note = (TextView) findViewById(R.id.xl_add_bank_tv_note);

        //不可以修改银行信息
        sk_id_add_bank_card_rl.setEnabled(false);
        //不可以修改银行卡信息
        xl_add_bank_et_card.setEnabled(false);
//      // update by cyr on 2017-2-13 不可修改
        xl_add_bank_et_name.setEnabled(false);

        if(bankCardEntity != null){
            String bankName = bankCardEntity.bankName;
            String branch = bankCardEntity.branch;

            if (TextUtils.isEmpty(bankCardEntity.shortNum)) {
                shortToast("银行卡信息有误");
            }
            if(TextUtils.isEmpty(branch)){
                branch = "";
            }
            xl_add_bank_tv_note.setText(Html.fromHtml(TIPS));
            Utils.bankCardNumAddSpace(xl_add_bank_et_card);
            xl_add_bank_et_card.setText(bankCardEntity.longNum);
            xl_add_bank_et_openCard.setText(branch);
            sk_id_add_bank_tv.setText(bankName);
        }
    }

    @Override
    public void listeners() {
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.sx_id_title_right_btn:
                String openCard = xl_add_bank_et_openCard.getText().toString().trim();
                if (TextUtils.isEmpty(openCard)) {
                    shortToast("请输入开户行!");
                    return;
                }
                requestData();
                break;
            case R.id.sx_id_title_left:
                myFinish();
                break;
        }
    }

    @Override
    public void onNetRefresh() {
    }

    /** 银行卡编辑的请求  */
    private void requestData() {
        final String branch = xl_add_bank_et_openCard.getText().toString().trim();

        RequestParams params = new RequestParams();
        params.put("userBankId", bankCardEntity.userBankId);
        params.put("userType", "1");//0商务代表，1医生
        params.put("branch", branch);
        params.put("bankCardNum", bankCardEntity.longNum);
        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.updateBankCard), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    shortToast("银行卡编辑成功！");
                    bankCardEntity.branch = branch;
                    Intent intent = new Intent();
                    intent.putExtra(XL_ApplyCashBackActivityV2.BANK, bankCardEntity);
                    setResult(RESULT_OK, intent);
                    myFinish();
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(XL_ModifyBankActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

}
