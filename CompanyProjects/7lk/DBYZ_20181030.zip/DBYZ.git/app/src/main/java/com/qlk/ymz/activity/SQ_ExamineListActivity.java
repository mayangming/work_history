package com.qlk.ymz.activity;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SQ_InspectSearchResultAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.ExamineBean;
import com.qlk.ymz.model.SQ_InspectSRActivityLaunchModel;
import com.qlk.ymz.parse.Parse2ExamineBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilImage;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;
import com.xiaocoder.ptrrefresh.XCMaterialListPinRefreshLayout;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author sq
 *
 * 检查列表页
 */

public class SQ_ExamineListActivity extends DBActivity{
    private XCTitleCommonLayout title_bar;
    /** 检查列表*/
    private XCMaterialListPinRefreshLayout sq_id_inspect_search_result_list;
    /** 检查列表适配器 */
    private SQ_InspectSearchResultAdapter adapter;
    /** 检查列表数据集合 */
    private List<ExamineBean> dataList = new ArrayList<>();
    /** 检查列表数据集合 */
    private List<ExamineBean> checkList = new ArrayList<>();
    /** 检查单数量 */
    private TextView sk_id_choice_inspect_recommend_num;
    private RelativeLayout sq_id_choice_inspect_recommend;
    /** 传递数据model */
    private SQ_InspectSRActivityLaunchModel inspectSRActivityLaunchModel;
    private Map<String,Boolean> checkMap = new HashMap<>();
    /** 顶部提示信息 */
    private TextView sq_id_ea_msg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sq_activity_inspect_search_result);
        super.onCreate(savedInstanceState);

        requestSearch(inspectSRActivityLaunchModel.getCategoryId(),"1");
        requestConfigData();
    }

    /** created by songxin,date：2017-10-30,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SQ_ExamineListActivity.class);
    }

    /** created by songxin,date：2017-10-30,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        inspectSRActivityLaunchModel = (SQ_InspectSRActivityLaunchModel)
                getIntent().getSerializableExtra(SQ_InspectSRActivityLaunchModel.LAUNCH_CODE);
        checkMap = inspectSRActivityLaunchModel.getCheckMap();
        checkList = inspectSRActivityLaunchModel.getExamineBeanList();

        title_bar = getViewById(R.id.title_bar);
        sq_id_inspect_search_result_list = getViewById(R.id.sq_id_inspect_search_result_list);

        sk_id_choice_inspect_recommend_num = getViewById(R.id.sk_id_choice_inspect_recommend_num);

        sq_id_choice_inspect_recommend = getViewById(R.id.sq_id_choice_inspect_recommend);
        sq_id_ea_msg = getViewById(R.id.sq_id_ea_msg);

        title_bar.setTitleLeft(true,null);
        title_bar.setTitleCenter(true,"选择检查项");

        sq_id_inspect_search_result_list.setBgZeroHintInfo("没有数据哟", "", R.mipmap.js_d_icon_no_data);
        adapter = new SQ_InspectSearchResultAdapter(this, dataList);
        sq_id_inspect_search_result_list.updateListAdd(dataList,adapter);
        sq_id_inspect_search_result_list.getListView().setAdapter(adapter);

        // title返回键监听
        title_bar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                back();
            }
        });

        adapter.setCheckBoxOnClick(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                    ExamineBean bean = ((ExamineBean) v.getTag());
                    if (bean.isCheck()) {
                        // 取消选中
                        uncheckDrugs(bean);
                    } else {
                        // 选中
                        bean.setCheck(true);
                        checkMap.put(bean.getId(),true);
                        checkList.add(bean);
                        createAnimator((ImageView) v.getTag(R.id.sk_id_medichine_img));
                    }
                    updataView();
            }

            /**
             * 取消选中
             */
            private void uncheckDrugs(ExamineBean jsonBean) {
                if (checkList == null) return;

                for (ExamineBean bean : checkList) {
                    if (jsonBean.getId().equals(bean.getId())) {
                        checkList.remove(bean);
                        checkMap.put(bean.getId(),false);
                        break;
                    }
                }
                jsonBean.setCheck(false);
            }
        });


        updataView();
    }

    @Override
    public void listeners() {
        sq_id_choice_inspect_recommend.setOnClickListener(this);

        sq_id_inspect_search_result_list.getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // 跳转详情
                ExamineBean model = (ExamineBean) adapterView.getItemAtPosition(i);
                UtilNativeHtml5.toJumpInspectDetail(SQ_ExamineListActivity.this, model.getId());

            }
        });

        sq_id_inspect_search_result_list.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {
                return false;
            }

            @Override
            public boolean canLoad() {
                return true;
            }

            @Override
            public void refresh(View view, int request_page) {

            }

            @Override
            public void load(View view, int request_page) {
                requestSearch(inspectSRActivityLaunchModel.getCategoryId(),String.valueOf(request_page));
            }
        });


    }

    @Override
    public void onBackPressed() {
        back();
    }

    public void back(){
        Intent intent = new Intent();
        intent.putExtra(SQ_InspectSRActivityLaunchModel.LAUNCH_CODE,inspectSRActivityLaunchModel);
        setResult(Activity.RESULT_OK,intent);
        finish();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch(v.getId()){
            case R.id.sq_id_choice_inspect_recommend:
                if(inspectSRActivityLaunchModel.getExamineBeanList().size() > 0) {
                    // created by songxin,date：2017-10-30,about：saveInfo,begin
                    BiUtil.saveBiInfo(SQ_ExamineListActivity.class, "2", "128", "sq_id_choice_inspect_recommend","", false);
                    // created by songxin,date：2016-10-30,abou t：saveInfo,end
                    InspectOrdonnanceActivity.launch(this, inspectSRActivityLaunchModel);
                }else {
                    shortToast("检查项为空，请选择检查项目");
                }
                break;
        }
    }

    /**
     * 更新页面
     */
    public void updataView(){
        sk_id_choice_inspect_recommend_num.setText("检查单\n"+checkList.size()+"种");
        adapter.setCheckMap(checkMap);
        adapter.notifyDataSetChanged();
    }

    /**
     * 请求列表接口
     *
     * @param categoryId     类别id
     * @param page    页数
     */
    public void requestSearch(String categoryId, String page) {
        // 设置请求参数
        RequestParams params = new RequestParams();
        params.put("categoryId",categoryId);
        params.put("page", page);
        params.put("num","10");
        XCHttpAsyn.postAsyn(this, AppConfig.getAeUrl(AppConfig.examine_search), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && ! isDestroy) {
                    try {

                        List<XCJsonBean> bean = result_bean.getList("data");
                        sq_id_inspect_search_result_list.setTotalPage(bean.get(0).getString("totalPages"));
                        Parse2ExamineBean parse2ExamineBean = new Parse2ExamineBean();
                        dataList = parse2ExamineBean.parse2ExamineBeanModelList(bean.get(0));
                        sq_id_inspect_search_result_list.updateListAdd(dataList,adapter);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                sq_id_inspect_search_result_list.completeRefresh(result_boolean);
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SQ_ExamineListActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }


    /**
     * 创建动画并启动
     *
     * @param
     */
    private void createAnimator(ImageView medicine_img) {
        int[] startLocation = new int[2];
        int[] endLocation = new int[2];
        sq_id_choice_inspect_recommend.getLocationInWindow(endLocation);
        medicine_img.getLocationInWindow(startLocation);
        final ImageView imageView = new ImageView(this);
        imageView.setImageDrawable(medicine_img.getDrawable());

        imageView.setBackgroundResource(R.mipmap.sk_d_medicine_bg);
        imageView.setPadding(3, 3, 3, 3);
        createAnimLayout().addView(imageView);
        addViewToAnimLayout(imageView, startLocation);
        long time = 1500;
        // x坐标位移
        ObjectAnimator p1 = ObjectAnimator.ofFloat(imageView, "translationX", 0, endLocation[0] - startLocation[0]);
        p1.setDuration(time);
        // p1.setInterpolator(new AccelerateInterpolator(0.25f));
        // y坐标位移
        ObjectAnimator p2 = ObjectAnimator.ofFloat(imageView, "translationY", 0, endLocation[1] - startLocation[1]);
        p2.setDuration(time);
        // p2.setInterpolator(new AccelerateInterpolator(0.10f));
        // 旋转
        ObjectAnimator p3 = ObjectAnimator.ofFloat(imageView, "rotation", 0f, -360f);
        p3.setDuration(time);
        // 透明度
        ObjectAnimator p4 = ObjectAnimator.ofFloat(imageView, "alpha", 0.8f, 0f);
        p4.setDuration(time);
        // x缩放
        ObjectAnimator p5 = ObjectAnimator.ofFloat(imageView, "scaleX", 1f, 0.5f);
        p5.setDuration(time);
        // y缩放
        ObjectAnimator p6 = ObjectAnimator.ofFloat(imageView, "scaleY", 1f, 0.5f);
        p6.setDuration(time);

        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(p1, p2, p3, p4, p5, p6);
        animatorSet.start();
        animatorSet.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                imageView.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationCancel(Animator animation) {
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
            }
        });
    }

    /**
     * 创建动画层
     */
    private ViewGroup createAnimLayout() {
        ViewGroup rootView = (ViewGroup) this.getWindow().getDecorView();
        LinearLayout animLayout = new LinearLayout(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        animLayout.setLayoutParams(lp);
        animLayout.setBackgroundResource(android.R.color.transparent);
        rootView.addView(animLayout);
        return animLayout;
    }

    /**
     * 把view添加到动画层
     *
     * @param view     药品图片
     * @param location 位置
     */
    private void addViewToAnimLayout(final View view, int[] location) {
        int x = location[0];
        int y = location[1];
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = x;
        lp.topMargin = y;
        lp.width = UtilImage.dip2px(this, 80);
        lp.height = UtilImage.dip2px(this, 80);
        view.setLayoutParams(lp);
    }


    /**
     * 请求顶部提醒信息
     */
    public void  requestConfigData(){
        RequestParams params = new RequestParams();

        XCHttpAsyn.postAsyn(this, AppConfig.getAeUrl(AppConfig.eaConfig),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){
                    sq_id_ea_msg.setText(result_bean.getList("data").get(0).getString("remindInfo"));
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == Activity.RESULT_OK){
            inspectSRActivityLaunchModel = (SQ_InspectSRActivityLaunchModel) data.getSerializableExtra(SQ_InspectSRActivityLaunchModel.LAUNCH_CODE);
            checkMap = inspectSRActivityLaunchModel.getCheckMap();
            checkList = inspectSRActivityLaunchModel.getExamineBeanList();
            updataView();
        }
    }
}
