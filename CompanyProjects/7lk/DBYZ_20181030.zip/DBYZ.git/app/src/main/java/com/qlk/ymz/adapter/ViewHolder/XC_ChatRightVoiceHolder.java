package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 聊天详情  医生 声音消息
 */
public class XC_ChatRightVoiceHolder extends XC_ChatRightBaseHolder {

    public TextView xc_id_adapter_right_content_text;
    public ImageView xc_id_adapter_right_voice_imageview;
    public TextView xc_id_adapter_right_content_voice_time;

    public XC_ChatRightVoiceHolder(View convertView) {
        super(convertView);
        xc_id_adapter_right_content_text = (TextView) convertView.findViewById(R.id.xc_id_adapter_right_content_text);
        xc_id_adapter_right_voice_imageview = (ImageView) convertView.findViewById(R.id.xc_id_adapter_right_voice_imageview);
        xc_id_adapter_right_content_voice_time = (TextView) convertView.findViewById(R.id.xc_id_adapter_right_content_voice_time);
    }
}