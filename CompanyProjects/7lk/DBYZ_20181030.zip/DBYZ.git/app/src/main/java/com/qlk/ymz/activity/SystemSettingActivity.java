package com.qlk.ymz.activity;

import android.os.Environment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.service.XC_MqttService;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCClearEditText;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 设置系统信息
 * @author zhangpengfei.
 * @version 1.0
 */
public class SystemSettingActivity extends DBActivity {
    /**内容*/
    private RecyclerView content_rv;
    private SystemSettingRecycleAdapter recycleAdapter;
    /**搜索框*/
    private XCClearEditText search_edit_et;
    /**搜索按钮*/
    private TextView search_tv;
    /**数据*/
    private List<String> list;
    @Override
    public void initWidgets() {
        setContentView(R.layout.activity_system_setting);
        content_rv = getViewById(R.id.content_rv);
        search_edit_et = getViewById(R.id.search_edit_et);
        search_tv = getViewById(R.id.search_tv);
        LinearLayoutManager mLayoutManage=new LinearLayoutManager(this);
        mLayoutManage.setOrientation(OrientationHelper.VERTICAL);//设置滚动方向
        content_rv.setLayoutManager(mLayoutManage);
        list = new ArrayList<>();
        list.add("开启log");
        list.add("检测友盟是否开启");
        list.add("复制数据库");
        list.add("切换http和https");
        File file = new File(GlobalConfigSP.getHtml5NativePath());
        File[] tempList = file.listFiles();
        for (int i = 0; i < tempList.length; i++) {
            String fileName = tempList[i].getName();
            if (UtilString.f(fileName).startsWith("time")){
                list.add("h5包版本: " + fileName);
            }
        }

        recycleAdapter = new SystemSettingRecycleAdapter(list);
        content_rv.setAdapter(recycleAdapter);

    }

    @Override
    public void listeners() {
        search_tv.setOnClickListener(this);
        search_edit_et.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    searchStart();
                    return true;
                }
                return false;
            }
        });
        recycleAdapter.setOnItemClickListener(new OnRecycleViewItemClickListener() {
            @Override
            public void OnItemClick(View view, int position) {
                String content = list.get(position);
                switch (UtilString.f(content)){
                    case "开启log":
                        XCConfig.initDebug(true);
                        XC_MqttService.actionOpenLog(SystemSettingActivity.this);
                        shortToast("开启log");
                        break;
                    case "检测友盟是否开启":
                        String umeng = AppConfig.IS_OPEN_UMENG ? "打开" : "关闭";
                        shortToast("友盟状态： " + umeng);
                        break;
                    case "复制数据库":
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                String fromUrl = getFilesDir().getParent() + "/databases";
                                String toUrl = Environment.getExternalStorageDirectory() + "/" + XCConfig.DB_DIR + "/" + UtilDate.getNow("yyyy-MM-dd_HH:mm");
                                try {
                                    UtilFiles.copyDirAndFile(fromUrl, toUrl);
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            shortToast("复制成功");
                                        }
                                    });
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }).start();
                        break;
                    case "切换http和https":
                        String urlType = GlobalConfigSP.getUrlType();
                        if ("0".equals(urlType)){
                            GlobalConfigSP.setUrlType("1");
                            shortToast("切换http成功");
                        }else if ("1".equals(urlType)){
                            GlobalConfigSP.setUrlType("0");
                            shortToast("切换https成功");
                        }
                        break;
                    case "h5包版本":
                        break;
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.search_tv:
                //搜索
                searchStart();
                break;
        }
    }

    @Override
    public void onNetRefresh() {

    }

    /**
     * 搜索地址跳转
     */
    private void searchStart(){
        String url =  search_edit_et.getText().toString().trim();
        if (url.startsWith("http")) {
            WebviewBean bean = new WebviewBean(url);
            myStartActivity(JS_WebViewActivity.newIntent(SystemSettingActivity.this, bean));
        } else {
            String htmlName = UtilNativeHtml5.splitString(url);
            String pointPath = GlobalConfigSP.getHtml5NativePath() + "/html/" + htmlName;
            if (UtilFiles.fileIsExists(pointPath)) {
                myStartActivity(JS_WebViewActivity.newIntent(SystemSettingActivity.this, new WebviewBean("file://" + GlobalConfigSP.getHtml5NativePath() + "/html/" + url)));
            }else {
                shortToast("本地没有这个文件");
            }
        }
    }

    class SystemSettingRecycleAdapter extends RecyclerView.Adapter<SystemSettingRecycleAdapter.ViewHolder> implements View.OnClickListener {
        private List<String> mList;
        private OnRecycleViewItemClickListener mOnItemClickListener;


        public SystemSettingRecycleAdapter(List<String> mList) {
            this.mList = mList;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(SystemSettingActivity.this).inflate(R.layout.item_system_setting, null);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            if (holder != null) {
                holder.content_tv.setTag(position);
                holder.content_tv.setOnClickListener(this);
                if (null != mList && null != mList.get(position)) {
                    holder.content_tv.setText(UtilString.f(mList.get(position)));
                }
            }
        }

        public void setList(List<String> mList) {
            if (null != mList && mList.size() > 0) {
                this.mList = mList;
                notifyDataSetChanged();
            }
        }

        @Override
        public int getItemCount() {
            return mList.size();
        }

        public void setOnItemClickListener(OnRecycleViewItemClickListener listener) {
            this.mOnItemClickListener = listener;
        }

        @Override
        public void onClick(View v) {
            if (mOnItemClickListener != null) {
                mOnItemClickListener.OnItemClick(v, (int) v.getTag());
            }
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            /**
             * 姓名
             */
            private TextView content_tv;

            public ViewHolder(View convertView) {
                super(convertView);
                content_tv = convertView.findViewById(R.id.content_tv);

            }
        }
    }

    interface OnRecycleViewItemClickListener {
        void OnItemClick(View view, int position);
    }
}
