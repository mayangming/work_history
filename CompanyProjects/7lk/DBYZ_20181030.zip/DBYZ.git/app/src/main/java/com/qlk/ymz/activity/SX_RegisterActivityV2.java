package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.TextChangedListenerUtil;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.SX_ClearEditText;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilMd5;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.List;


/**
 * SX_RegisterActivityV2
 * 注册页面(获取验证码)
 * @author songxin on 2016/1/7.
 * @version 2.0
 */
public class SX_RegisterActivityV2 extends DBActivity implements View.OnClickListener{
    /** title左边按钮*/
    private ImageView sx_id_title_left;
    /** title中间文字*/
    private TextView sx_id_title_center;
    /** 注册页面手机号输入框*/
    private SX_ClearEditText sx_l_register_phone_edit;
    /** 注册页面获取验证码按钮*/
    private Button sx_l_get_verification_code_button;
    /** 跳转标记*/
    private int mFlag = -1;
    /** 弹出自定义dialog*/
    private ConfirmDialog mCustomDialog;
    /** 弹出自定义dialog 取消按钮*/
    private TextView sx_id_cancel_button;
    /** 弹出自定义dialog 确定按钮*/
    private TextView sx_id_confirm_button;
    /** 弹出自定义dialog text*/
    private TextView sx_id_custom_text;
    /** 用户名临时变量*/
    private String mUserName = "";

    @Override
	protected void onCreate(Bundle savedInstanceState) {
		// 设置布局
		setContentView(R.layout.sx_l_activity_doctor_register);
		super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(SX_RegisterActivityV2.class,"1","","","",false);
        // created by songxin,date：2016-4-25,about：saveInfo,end
        mFlag = getIntent().getIntExtra("toRegister",0);
        if(mFlag == 0){
            sx_id_title_center.setText("医生注册");
        }else if(mFlag == 1){
            sx_id_title_center.setText("忘记密码");
        }
        mUserName = getIntent().getStringExtra("USERNAME");
        sx_l_register_phone_edit.setText(mUserName);
	}

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_RegisterActivityV2.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

	// 无网络时,点击屏幕后回调的方法i
	@Override
	public void onNetRefresh() {
	}

	// 初始化控件
	@Override
	public void initWidgets() {
        sx_id_title_left = getViewById(R.id.sx_id_title_left);
        sx_id_title_center = getViewById(R.id.sx_id_title_center);
        sx_l_register_phone_edit = getViewById(R.id.sx_l_register_phone_edit);
        sx_l_get_verification_code_button = getViewById(R.id.sx_l_get_verification_code_button);
        getViewById(R.id.pf_title_rl).setBackgroundColor(getResources().getColor(R.color.c_trans));
        getViewById(R.id.line).setVisibility(View.GONE);

        int srceenW = this.getWindowManager().getDefaultDisplay().getWidth();
        mCustomDialog = new ConfirmDialog(SX_RegisterActivityV2.this, srceenW, 180
                , R.layout.sx_l_custom_dialog, R.style.xc_s_dialog);
        mCustomDialog.setCanceledOnTouchOutside(false);
        sx_id_cancel_button = (TextView) mCustomDialog.findViewById(R.id.sx_id_cancel_button);
        sx_id_confirm_button = (TextView) mCustomDialog.findViewById(R.id.sx_id_confirm_button);
        sx_id_custom_text = (TextView) mCustomDialog.findViewById(R.id.sx_id_custom_text);
        sx_id_cancel_button.setText("不了");
        sx_id_confirm_button.setText("好的");
        sx_id_custom_text.setText("该手机号已被注册，是否立即登录？");

	}

	// 设置监听
	@Override
	public void listeners() {
        sx_id_title_left.setOnClickListener(this);
        sx_id_cancel_button.setOnClickListener(this);
        sx_id_confirm_button.setOnClickListener(this);
        sx_l_get_verification_code_button.setOnClickListener(this);
        //监听输入框变化，控制登录按钮颜色，是否可点击
        TextChangedListenerUtil.textChanged(sx_l_register_phone_edit,SX_RegisterActivityV2.this,sx_l_get_verification_code_button);
	}

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            //返回按钮
            case R.id.sx_id_title_left:{
                onBackPressed();
                break;
            }
            //获取验证码
            case R.id.sx_l_get_verification_code_button:{
                if(UtilString.isBlank(sx_l_register_phone_edit.getText().toString().trim())){
                    XCApplication.base_log.shortToast("请输入手机号码后重试！");
                    return;
                }
                getCurtentTime();
                break;
            }
            //dialog取消按钮
            case R.id.sx_id_cancel_button:{
                if(null != mCustomDialog){
                    mCustomDialog.dismiss();
                }
                break;
            }
            //dialog确定按钮
            case R.id.sx_id_confirm_button:{
                if(null != mCustomDialog){
                    mCustomDialog.dismiss();
                }
                Intent intent = new Intent();
                intent.putExtra("USERNAME",sx_l_register_phone_edit.getText().toString().trim());
                setResult(0,intent);
                finish();
                break;
            }
        }
    }

    /**
     * 请求验证码
     * @param phoneNumber :医生输入手机号码
     * @param actionType ：功能类型(1/注册；2/忘记密码；3/修改手机号)
     */
    private void requestVcode(final String phoneNumber,String actionType,String currentTime){
        //发送请求
        RequestParams params = new RequestParams();
        params.put("phoneNum", phoneNumber);
        params.put("actionType", actionType);
        params.put("t", currentTime);
        params.put("sign", UtilMd5.MD5Encode("actionType="+actionType+"&phoneNum="+phoneNumber+"&t="+currentTime+AppConfig.SECRET_KEY));

        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.sendSms), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    //成功进入下一步
                    Intent intent = new Intent();
                    intent.putExtra("toConfirmationCode",mFlag);
                    intent.putExtra("USERNAME",phoneNumber);
                    intent.setClass(SX_RegisterActivityV2.this,SX_ConfirmationCodeActivity.class);
                    myStartActivity(intent);
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && "30102".equals(getCode())){
                    if(mFlag == 0){
                        if(null != mCustomDialog){
                            mCustomDialog.show();
                        }
                    }

                } else if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_RegisterActivityV2.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    private void getCurtentTime(){
        try {
            //发送请求
            RequestParams params = new RequestParams();
            XCHttpAsyn.postAsyn(false, SX_RegisterActivityV2.this, AppConfig.getHostUrl(AppConfig.get_time), params, new XCHttpResponseHandler() {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if(result_boolean){
                        long time = ((List<Long>)result_bean.get("data")).get(0);
                        if(mFlag == 0){
                            requestVcode(sx_l_register_phone_edit.getText().toString().trim(), "1",time+"");
                        }else if(mFlag == 1){
                            requestVcode(sx_l_register_phone_edit.getText().toString().trim(),"2",time+"");
                        }
                    }
                }
            });
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        UtilInputMethod.hiddenInputMethod(SX_RegisterActivityV2.this);
        finish();
    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mCustomDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }
}
