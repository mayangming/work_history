package com.qlk.ymz.db.im.chatmodel;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;

/**
 * description: 聊天信息中的病历内容
 * autour: YM
 * date: 2018/6/27
 * update: $date$
 * version: $version$
 */
public class ChatModelMedicalRecord  implements Serializable,Cloneable{
    private String patientName = "";//患者姓名
    private String gender = "";//患者性别
    private String age = "";//患者年龄
    private String mainComplaint = "";//主诉
    private String diagnosis = "";//诊断
    private String doctorsSummary = "";//医嘱小结
    private String medicalRecordId = "";//病历ID
    private String auditDesc = "";//推荐用药审核描述

    /**
     * 新增推荐用药审核状态
     * 0：默认（不需要审核）
     * 1：审核中
     * 2：审核通过
     * 3：审核不通过
     */
    private String checkingStatus = "";//处方审核状态
    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getMainComplaint() {
        return mainComplaint;
    }

    public void setMainComplaint(String mainComplaint) {
        this.mainComplaint = mainComplaint;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getDoctorsSummary() {
        return doctorsSummary;
    }

    public void setDoctorsSummary(String doctorsSummary) {
        this.doctorsSummary = doctorsSummary;
    }

    public String getMedicalRecordId() {
        return medicalRecordId;
    }

    public void setMedicalRecordId(String medicalRecordId) {
        this.medicalRecordId = medicalRecordId;
    }

    public String getAuditDesc() {
        return auditDesc;
    }

    public void setAuditDesc(String auditDesc) {
        this.auditDesc = auditDesc;
    }

    public String getCheckingStatus() {
        return checkingStatus;
    }

    public void setCheckingStatus(String checkingStatus) {
        this.checkingStatus = checkingStatus;
    }
    public boolean isMedicineChecking() {
        return "1".equals(getCheckingStatus());
    }

    public boolean isMedicineCheckSuccess() {
        return "2".equals(getCheckingStatus());
    }

    public boolean isMedicineCheckFail() {
        return "3".equals(getCheckingStatus());
    }

    public boolean isMedicineStatusDefault() {
        return "0".equals(getCheckingStatus());
    }

}