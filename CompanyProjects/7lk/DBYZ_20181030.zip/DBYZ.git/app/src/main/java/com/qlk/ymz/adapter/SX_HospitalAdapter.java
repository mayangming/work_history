package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.adapter.XLBaseExpandableListViewAdapter;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import java.util.List;

/**
 * Created by songxin on 2015/6/18.
 *
 * SX_HospitalAdapter
 * 医院列表adapter
 * @author  Changed by songxin on 2016/3/29.
 * @version 2.3
 */
public class SX_HospitalAdapter extends XCBaseAdapter<XCJsonBean> {

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        XCJsonBean bean = list.get(position);
        ViewHolder holder = null;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.sx_l_adapter_hospital_item, null);
            holder = new ViewHolder();
            holder.sx_l_adapter_hospital_show = (TextView) convertView.findViewById(R.id.sx_l_adapter_hospital_show);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.sx_l_adapter_hospital_show.setText(list.get(position).getString("name"));
        return convertView;
    }

    public SX_HospitalAdapter(Context context, List<XCJsonBean> list) {
        super(context, list);
    }

    class ViewHolder {
        TextView sx_l_adapter_hospital_show;
    }
}
