package com.qlk.ymz.activity;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PF_SearchWaitRegisterContactsAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.PF_WaitRegisterContactsInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCClearEditText;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * 等待注册联系人搜索页
 * update author zhangpengfei
 * @version 2.5.0
 */
public class PF_WaitRegisterContactSearchActivity extends DBActivity {
    public static final String TO_CONTACTSEARCH_INFO = "toContactsSearchInfo";
    /** 搜索关键字 */
    public static String SEARCH_KEY = "search_key";
    /** 联想结果列表 */
    private XCListViewFragment listViewFragment;
    /** 联想结果适配器 */
    private PF_SearchWaitRegisterContactsAdapter searchContactsAdapter;
    /** 联系人信息 */
    private List<PF_WaitRegisterContactsInfo> mAllContactsList;
    /** 联想结果信息 */
    private List<PF_WaitRegisterContactsInfo> mResultList;
    /** 搜索关键字 */
    private XCClearEditText sk_id_search_edit;
    /**没有数据提示*/
    private LinearLayout pf_no_date;
    /** 是否正在获取短信模板*/
    private boolean isGetingSMSModel = false;
    /**输入的最大长度*/
    private int maxLength = 0;
    /**输入的最小长度*/
    private int minLength = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_l_activity_wait_register_contacts_search);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-6-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_WaitRegisterContactSearchActivity.class);
    }

    /** created by songxin,date：2016-6-29,about：bi,end */

    /** 无网络时,点击屏幕后回调的方法 */
    @Override
    public void onNetRefresh() {
    }

    /** 初始化控件 */
    @Override
    public void initWidgets() {
        pf_no_date = getViewById(R.id.pf_no_date);
        ((TextView)getViewById(R.id.id_zero_data_tv)).setText("没有找到相关的联系人，更改关键字试试");

        mResultList = new ArrayList<>();
        mAllContactsList = new ArrayList<>();
        searchContactsAdapter = new PF_SearchWaitRegisterContactsAdapter(this, mResultList);
        sk_id_search_edit = (XCClearEditText) findViewById(R.id.sk_id_search_edit);
        sk_id_search_edit.requestFocus();
        sk_id_search_edit.setFocusable(true);
        sk_id_search_edit.setHint("请输入联系人关键字");
        sk_id_search_edit.setHintTextColor(getResources().getColor(R.color.c_gray_bbbbbb));
        findViewById(R.id.xc_id_titlebar_right2_textview).setOnClickListener(this);
        listViewFragment = new XCListViewFragment();
        listViewFragment.setMode(XCListViewFragment.MODE_NOT_PULL);//不可上下拉的listview
        listViewFragment.setBgZeroHintInfo("抱歉，没有匹配的联系人", "重新加载", R.mipmap.js_d_icon_no_data);
        listViewFragment.setAdapter(searchContactsAdapter);
        ColorDrawable colorDrawable = new ColorDrawable(0xFFBEBEBE);
        listViewFragment.setListViewStyleParam(colorDrawable, 1, false);
        addFragment(R.id.xc_id_model_content, listViewFragment);
        //格式化数据
        List<List<PF_WaitRegisterContactsInfo>> rawContactModels = PF_WaitRegisterContactsActivity.WAIT_REGISTER_CONTACTS_INFO;
        if (null != rawContactModels && rawContactModels.size() > 0){
            for (int i = 0; i < rawContactModels.size(); i ++){
                List<PF_WaitRegisterContactsInfo> contactsInfoList = rawContactModels.get(i);
                if (null != contactsInfoList && contactsInfoList.size() > 0){
                    for (int j = 0; j < contactsInfoList.size(); j ++){
                        mAllContactsList.add(contactsInfoList.get(j));
                    }
                }
            }
        }
        //获取sp的极限值
        maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PHONE_CONTACT_SEARCH, 0, 19);
        minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PHONE_CONTACT_SEARCH, 1, 0);
        sk_id_search_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        requestContactsSMSModel();
    }

    @Override
    public void listeners() {
        //点击软件盘搜索按钮跳转搜索结果页
        sk_id_search_edit.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    String keyWord = sk_id_search_edit.getText().toString().trim();
                    if (UtilString.isBlank(keyWord) || keyWord.length() < minLength){
//                        shortToast("请输入联系人姓名");
                        return true;
                    }
                    UtilInputMethod.hiddenInputMethod(PF_WaitRegisterContactSearchActivity.this);
                    searchAssociation(keyWord);
                    if (mResultList.size() == 0){
                        pf_no_date.setVisibility(View.VISIBLE);
                    }else{
                        pf_no_date.setVisibility(View.GONE);
                    }
                    return true;
                }
                return false;
            }
        });
        // 搜索标题编辑框的关键字联想功能的监听
        sk_id_search_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchAssociation(s + "");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.xc_id_titlebar_right2_textview:
                myFinish();
                break;
        }
    }

    /**
     * 搜索结果
     * @param key 关键字
     */
    private void searchAssociation(String key){
        pf_no_date.setVisibility(View.GONE);
        mResultList.clear();
        if (!UtilString.isBlank(key.toString().trim())){
            for (int i = 0; i < mAllContactsList.size(); i ++){
                if (mAllContactsList.get(i).getName().toLowerCase().contains(key.toLowerCase())){
                    mResultList.add(mAllContactsList.get(i));
                }
            }
        }
        listViewFragment.updateSpecialList(mResultList);

    }
    /**
     * 获取邀请联系人的短信模板
     */
    public void requestContactsSMSModel() {
        //每次进入联系人页会都会进行请求短信模板或者短信模板为空的时候才进行请求
        if (UtilString.isBlank(GlobalConfigSP.getInvitedMsg())){
            if(isGetingSMSModel){
                return;
            }
            isGetingSMSModel = true;
            XCHttpAsyn.postAsyn(false, false, this, AppConfig.getHostUrl(AppConfig.model_contacts_sms), new RequestParams(), new XCHttpResponseHandler() {
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if(result_boolean){
                        List<XCJsonBean> jsonBeans = result_bean.getList("data");
                        if (jsonBeans != null && jsonBeans.size() > 0) {
                            XCJsonBean obj = jsonBeans.get(0);
                            String messageContent = obj.getString("messageContent");
                            if(!UtilString.isBlank(messageContent)){
                                GlobalConfigSP.setInvitedMsg(messageContent);
                            }
                        }
                    }
                }

                @Override
                public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                    super.onFailure(code, headers, arg2, e);
                }

                @Override
                public void fail() {
                }

                @Override
                public void onFinish() {
                    super.onFinish();
                    isGetingSMSModel = false;
                }
            });
        }
    }


}
