package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.nostra13.universalimageloader.core.assist.PauseOnScrollListener;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_GroupManagementAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.parse.Parse2PatientBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.Utils;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by songxin on 2015/6/22.
 *
 * 编辑分组患者页
 * update by cyr on 2016-1-7
 * @version 2.0
 *
 */
public class YR_EditPatientGroupActivity extends DBActivity {
	/** 患者列表 */
	private GridView sx_id_date_show_gridview;
	/** 编辑分组名称 */
	private EditText et_group_name;
	/** 最成员数量统计 */
	private TextView tv_group_num;
	/** 分组名称，可从跳转页面获得 */
	private String mGroupName;
	/** 患者list */
	private ArrayList<XC_ChatModel> mXCJsonBean = new ArrayList<>();
	/** 分组id，可从上个页面获得 */
	private String mGroupId;
	/** 拼接待删除的患者id */
	private List<String> mDeleteId = new ArrayList<>();
	/** 患者adapter */
	private SX_GroupManagementAdapter sx_groupManagementAdapter;
	/** 点击删除时，弹出确认对话框 */
	private YR_CommonDialog mYR_commonDialog;
	/** 显示患者信息不全的对话框 */
	private YR_CommonDialog commonInfoDialog;
	/** 设置gridview的item是否可点击 */
	public static String IS_CLICKABLE = "isClickable";
//	/** 设置gridView的患者item是否是删除状态 */
//	public static String IS_DELETE = "isDelete";
	/** 分组名最大长度 */
	int maxLength = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		mGroupId = getIntent().getStringExtra(YR_PatientGroupManagerActivity.GROUP_ID);
		mGroupName = getIntent().getStringExtra(YR_PatientGroupManagerActivity.GROUP_NAME);

		setContentView(R.layout.sx_l_activity_group_management);
		super.onCreate(savedInstanceState);
		initTitle();
		getPatientList();
	}

	@Override
	protected void onStart() {
		super.onStart();
		BiUtil.savePid(YR_EditPatientGroupActivity.class);
	}

	/** 初始化title */
	public void initTitle(){
		findViewById(R.id.sx_id_title_left).setOnClickListener(this);
		((TextView)findViewById(R.id.sx_id_title_center)).setText("编辑分组");
		TextView sx_id_title_right_btn = (TextView) findViewById(R.id.sx_id_title_right_btn);
		sx_id_title_right_btn.setVisibility(View.VISIBLE);
		sx_id_title_right_btn.setText("保存");
		sx_id_title_right_btn.setOnClickListener(this);
		findViewById(R.id.sx_id_title_right).setVisibility(View.GONE);
	}

	@Override
	public void onNetRefresh() {
		getPatientList();
	}

	/** 初始化控件 */
	@Override
	public void initWidgets() {
		tv_group_num = (TextView) findViewById(R.id.tv_group_num);
		findViewById(R.id.tv_delete_group).setOnClickListener(this);
		et_group_name = (EditText) findViewById(R.id.et_group_name);

		maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_GROUP_NAME, 0, 19);
		et_group_name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
		et_group_name.setText(mGroupName);
		et_group_name.setSelection(mGroupName.length());//设置光标在文字后面

		sx_id_date_show_gridview = (GridView) findViewById(R.id.sx_id_date_show_gridview);
		sx_groupManagementAdapter = new SX_GroupManagementAdapter(YR_EditPatientGroupActivity.this, mXCJsonBean, mDeleteId);
		sx_id_date_show_gridview.setAdapter(sx_groupManagementAdapter);

		//add by 马杨茗,date：2016-6-8,about：页面滑动卡顿问题,begin
		//第一个参数就是我们的图片加载对象ImageLoader, 第二个是控制是否在滑动过程中暂停加载图片(传true表示暂停加载),第三个参数控制猛的滑动界面的时候图片是否加载(传true表示不加载)
		sx_id_date_show_gridview.setOnScrollListener(new PauseOnScrollListener(XCApplication.base_imageloader,true,true));
		//add by 马杨茗,date：2016-6-8,about：页面滑动卡顿问题,end
	}

	@Override
	public void listeners() {
		// 0表示添加按钮，1表示删除按钮，其他表示患者
		sx_id_date_show_gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
				if (position == 0) {// 进入添加患者页面
					if (!mXCJsonBean.get(0).getUserPatient().isClickStatus) {// 当删除按钮处于点击状态时，不进行处理
						shortToast("请先保存，再添加患者");
						return;
					}
					Intent intent = new Intent();
					intent.putExtra(YR_PatientGroupManagerActivity.GROUP_ID, mGroupId);
					intent.setClass(YR_EditPatientGroupActivity.this, YR_AddPatientActivity.class);
					myStartActivityForResult(intent, 1);
				} else if (position == 1) {// 进入删除患者状态
					if (mXCJsonBean.size() == 2) {// 当只有添加、删除按钮，无分组成员时，不进行处理
						shortToast("分组中没有患者");
						return;
					}
					for (int i = 2; i < mXCJsonBean.size(); i++) {
						mXCJsonBean.get(i).getUserPatient().isDeleteStatus = true;
					}
					mXCJsonBean.get(0).getUserPatient().isClickStatus = false;// 处于删除状态，添加按钮不可点击
					sx_groupManagementAdapter.notifyDataSetChanged();
				} else {// 其他为患者
					XC_ChatModel bb = mXCJsonBean.get(position);
					if (!bb.getUserPatient().isDeleteStatus) {// 当患者设置成未删除状态时，才能进入患者详情页
						if (TextUtils.isEmpty(bb.getUserPatient().getPatientName())) {// 患者资料不全，弹出提示框
							if (commonInfoDialog == null) {
								commonInfoDialog = new YR_CommonDialog(YR_EditPatientGroupActivity.this, "患者资料不全!", "", "我知道了") {

									@Override
									public void confirmBtn() {
										dismiss();
									}
								};
							}
							commonInfoDialog.show();
							return;
						}
						ToJumpHelp.toJumpWithIdPatientInfoActivity(YR_EditPatientGroupActivity.this,bb.getUserPatient().getPatientId());
					}
				}
			}
		});

	}

	@Override
	protected void onDestroy() {
		UtilViewShow.destoryDialogs(commonInfoDialog, mYR_commonDialog);
		super.onDestroy();
	}

	@Override
	public void onClick(View v) {
		super.onClick(v);

		switch (v.getId()){
			case R.id.sx_id_title_left:
				delayClose();
				break;
			case R.id.sx_id_title_right_btn:
				//请求服务器，保存分组名称和分组成员设置（目前只有删除分组成员功能，添加成员功能在添加成员页处理）
				requestUpdateGroupName();
				break;
			case R.id.tv_delete_group:
				initDialog();
				break;
		}
	}

	/** 点击删除按钮弹出确定提示框 */
	public void initDialog(){
		if(mYR_commonDialog == null) {
			mYR_commonDialog = new YR_CommonDialog(YR_EditPatientGroupActivity.this, "请确认是否删除？", "取消", "确认") {
				@Override
				public void confirmBtn() {
					requestPatientGroupDelete(mGroupId);
				}

			};
			mYR_commonDialog.setCanceledOnTouchOutside(true);
		}
		mYR_commonDialog.show();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {//进行添加分组成员操作
			if (requestCode == 1) {//从添加分组成员页返回
				getPatientList();
			}
		}
	}

	/** 获得分组列表 */
	private void getPatientList(){
		RequestParams params = new RequestParams();
		params.put("groupId",mGroupId);
		XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.patientGroup_listUser), params, new XCHttpResponseHandler(this) {
			@Override
			public void onSuccess(int code, Header[] headers, byte[] arg2) {
				super.onSuccess(code, headers, arg2);
				mXCJsonBean.clear();
				if (result_boolean) {
					if (result_bean != null) {
						mXCJsonBean.add(new XC_ChatModel());//设置添加按钮
						mXCJsonBean.add(new XC_ChatModel());//设置删除按钮
						Parse2PatientBean.parseGroupList(mXCJsonBean, result_bean);
						tv_group_num.setText("组成员 (" + (mXCJsonBean.size() - 2) + ")");
					}
				}
				sx_groupManagementAdapter.notifyDataSetChanged();
			}

			public void onFinish() {
				super.onFinish();
				if (null != result_bean && GeneralReqExceptionProcess.checkCode(YR_EditPatientGroupActivity.this,
						getCode(),
						getMsg())) {
				}
			}
		});
	}

	/** 批量删除患者 */
	private void deletePatient(String patientIds){
		RequestParams params = new RequestParams();
		params.put("groupId", mGroupId);
		params.put("patientIds", patientIds);
		XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.patientGroup_removeUser), params, new XCHttpResponseHandler() {
			public void onSuccess(int code, Header[] headers, byte[] arg2) {
				super.onSuccess(code, headers, arg2);
				if (result_boolean) {
					tv_group_num.setText("组成员 (" +( mXCJsonBean.size() -2) + ")");
					resumeStatus();
				}
			}

			public void onFinish() {
				super.onFinish();
				if(null != result_bean && GeneralReqExceptionProcess.checkCode(YR_EditPatientGroupActivity.this,
						getCode(),
						getMsg())) {
				}
			}
		});
	}

	/** 保存分组名称 */
	private void requestUpdateGroupName(){
		final String name = et_group_name.getText().toString().trim();
		int minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_GROUP_NAME, 1, 1);
		if (minLength > 0 && TextUtils.isEmpty(name)) {
			shortToast("分组名字不能为空");
			return;
		}
		if (name.length() < minLength) {
			shortToast("分组名称的长度范围：" + minLength + "~" + maxLength);
			return;
		}
		if(!Utils.isLetterDigitOrChinese(name)){
			shortToast("请勿输入特殊字符");
			return;
		}
		RequestParams params = new RequestParams();
		params.put("id",mGroupId);
		params.put("name",name);
		XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.modify), params, new XCHttpResponseHandler() {
			@Override
			public void onSuccess(int code, Header[] headers, byte[] arg2) {
				super.onSuccess(code, headers, arg2);
				if (result_boolean) {
					if (mDeleteId.size() > 0) {//拼接待删除的患者id
						StringBuilder sb = new StringBuilder();
						for (int i = 0; i < mDeleteId.size(); i++) {
							if (i == mDeleteId.size() - 1) {
								sb.append(mDeleteId.get(i));
							} else {
								sb.append(mDeleteId.get(i)).append(",");
							}
						}
						deletePatient(sb.toString());
					} else {
						resumeStatus();
					}
				}
			}

			public void onFinish() {
				super.onFinish();
				if(null != result_bean && GeneralReqExceptionProcess.checkCode(YR_EditPatientGroupActivity.this,
						getCode(),
						getMsg())) {
				}
			}
		});
	}

	/** 点击保存后，恢复患者成员为未删除状态 */
	public void resumeStatus(){
		for (XC_ChatModel x : mXCJsonBean) {
			x.getUserPatient().isDeleteStatus = false;
		}
		mXCJsonBean.get(0).getUserPatient().isClickStatus = true;
		sx_groupManagementAdapter.notifyDataSetChanged();
		shortToast("保存成功");
	}

	/** 删除分组 */
	public void requestPatientGroupDelete(String id) {
		RequestParams params = new RequestParams();
		params.put("ids",id);
		XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.patient_group_remove),params,new XCHttpResponseHandler(){
			@Override
			public void onSuccess(int code, Header[] headers, byte[] arg2) {
				super.onSuccess(code, headers, arg2);
				if (result_boolean){
					setResult(RESULT_OK);
					myFinish();
				}
			}
			@Override
			public void onFinish() {
				super.onFinish();
				if (null != result_bean && GeneralReqExceptionProcess.checkCode(YR_EditPatientGroupActivity.this,
						getCode(),
						getMsg())) {
				}
			}

		});

	}

	/** 延迟关闭页面，先关闭键盘，防止返回的页面出现抖动 */
	public void delayClose(){
		InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(et_group_name.getWindowToken(), 0);
		new Timer().schedule(new TimerTask() {
			@Override
			public void run() {
				myFinish();
			}
		}, 100);
	}

}
