package com.qlk.ymz.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.SQ_RecommendActivity;
import com.qlk.ymz.activity.XD_RecommendedMedicationActivity;
import com.qlk.ymz.adapter.ContinueRecipeAdapter;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.model.RecipeBean;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.parse.Parse2ContinueRecipeBean;
import com.qlk.ymz.parse.Parse2PatientDrugInfoModel;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;
import com.xiaocoder.ptrrefresh.XCMaterialListPinRefreshLayout;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2017/12/12.
 * 续方
 */

public class XD_ContinueRecipeFragment extends XD_BaseFragment implements ContinueRecipeAdapter
        .ContinueRecipeActionListener {
    /**
     * 续方列表上拉加载
     */
    private XCMaterialListPinRefreshLayout mXCMaterialListPinRefreshLayout;
    /**
     * 续方列表
     */
    private ListView mListView;
    /**
     * 续方adapter
     */
    private ContinueRecipeAdapter mContinueRecipeAdapter;
    /**
     * 续方集合
     */
    private ArrayList<RecipeBean> mRecipeBeans = new ArrayList<>();
    /**
     * 宿主
     */
    private XD_RecommendedMedicationActivity mActivity;
    /**
     * 正大天晴对话框
     */
    private YR_CommonDialog mMedicineFifterDialog;

    /**
     * 待替换处方数据
     */
    private XC_PatientDrugInfo patientDrugInfo;
    private int offset;//后台添加为了判断删除
    private int nextPage = 1;//下一页

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return init(inflater, R.layout.xd_fragment_contintue_recipe);
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    public void onStart() {
        super.onStart();
        BiUtil.savePid(XD_ContinueRecipeFragment.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */

    @Override
    public void initWidgets() {
        super.initWidgets();

        mActivity = (XD_RecommendedMedicationActivity) getActivity();

        mXCMaterialListPinRefreshLayout = getViewById(R.id.rfl_contintue_recipe);
        mXCMaterialListPinRefreshLayout.setBgZeroHintInfo("该患者没有开过处方", "", R.mipmap
                .js_d_icon_no_data);
        mListView = (ListView) mXCMaterialListPinRefreshLayout.getListView();
        int itemWidth = UtilScreen.getScreenWidthPx(getContext()) - UtilScreen.dip2px(getContext(),
                10);
        mContinueRecipeAdapter = new ContinueRecipeAdapter(getContext(), R.layout.xd_item_continue_recipe, R.layout.xd_item_recipe_delete, itemWidth, itemWidth, null);
        mContinueRecipeAdapter.setContinueRecipeActionListener(this);
        mListView.setAdapter(mContinueRecipeAdapter);
    }

    @Override
    public void onNetRefresh() {
        refresData();
    }

    @Override
    public void listeners() {
        mXCMaterialListPinRefreshLayout.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {
                return false;
            }

            @Override
            public boolean canLoad() {
                return true;
            }

            @Override
            public void refresh(View view, int request_page) {
            }

            @Override
            public void load(View view, int request_page) {
                getRecipeData(nextPage);
            }
        });

        getRecipeData(nextPage);

    }

    /**
     * 请求续方接口
     *
     * @param position
     */
    private void reqContinueRecipe(int position) {
        RequestParams params = new RequestParams();
        params.put("patientId", mActivity.getPatientDrugInfo().getChatModel().getUserPatient().getPatientId());
        params.put("recommendId", mRecipeBeans.get(position).getRecommendId());
        XCHttpAsyn.postAsyn(true, mActivity, AppConfig.getTuijianUrl(AppConfig.repeatRecommand), params,
                new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (CommonConfig.MEDICINE_FIFTER_CODE.equals(getCode())) {//假如符合正大天晴项目规则，则弹出对话框并终止下一步操作
                            showMedicineFifterDialog(getMsg());
                            return;
                        }
                        if (result_boolean) {
                            patientDrugInfo = Parse2PatientDrugInfoModel.parse(result_bean, mActivity.getPatientDrugInfo().getChatModel());
                            if (RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size() > 0
                                    || RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getDiagnoseBeanList().size() > 0) {//药箱中有药品
                                showOverRecipeDialog();
                            } else {
                                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setList(patientDrugInfo.getList());
                                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setDiagnoseBeanList(patientDrugInfo.getDiagnoseBeanList());
                                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setRecommendInfo(patientDrugInfo.getRecommendInfo());
                                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setCheckInventoryInfo(true);
                                SQ_RecommendActivity.launch(mActivity);
                            }
                        }
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        GeneralReqExceptionProcess.checkCode(mActivity, getCode(), getMsg());
                    }
                }
        );
    }

    /**
     * 刷新数据
     */
    public void refresData() {
        mXCMaterialListPinRefreshLayout.resetCurrentPageAndList(mContinueRecipeAdapter);
        mRecipeBeans.clear();
        offset = 0 ;
        nextPage = 1;
        getRecipeData(nextPage);
    }

    /**
     * 获取续方列表
     *
     * @param pageNum
     */
    private void getRecipeData(int page) {
        RequestParams params = new RequestParams();
        params.put("patientId", mActivity.getPatientDrugInfo().getChatModel().getUserPatient().getPatientId());
        if (page != 1) {
            params.put("page", page);
        }
        params.put("offset",offset);
        XCHttpAsyn.postAsyn(mActivity, AppConfig.getTuijianUrl(AppConfig.recomList), params, new
                XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            List<XCJsonBean> data = result_bean.getList("data");
                            mXCMaterialListPinRefreshLayout.setTotalPage( data.get(0).getInt("totalPages") + "");
                            offset = data.get(0).getInt("offset");
                            nextPage = data.get(0).getInt("nextPage");
                            ArrayList<RecipeBean> recipeBeans = new ArrayList<>();
                            Parse2ContinueRecipeBean parse2ContinueRecipeBean = new Parse2ContinueRecipeBean(recipeBeans);
                            parse2ContinueRecipeBean.parseJson(data.get(0));
                            mRecipeBeans.addAll(recipeBeans);
                            mXCMaterialListPinRefreshLayout.updateListAdd(recipeBeans, mContinueRecipeAdapter);
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        if(mXCMaterialListPinRefreshLayout.base_currentPage ==1){
                            showNoNetLayout();
                        }
                    }

                    // 对账户冻结情况的判断处理
                    public void onFinish() {
                        super.onFinish();
                        mXCMaterialListPinRefreshLayout.completeRefresh(result_boolean);
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(mActivity,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

    /**
     * 删除续方
     *
     * @param position
     */
    public void deleteRecipe(final int position) {
        RequestParams params = new RequestParams();
        params.put("recommendId", mRecipeBeans.get(position).getRecommendId());
        XCHttpAsyn.postAsyn(mActivity, AppConfig.getTuijianUrl(AppConfig.deleteRecom), params, new
                XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        XCHttpAsyn.httpFinish();
                        if (result_boolean) {
                            mRecipeBeans.remove(position);//从集合中删除
                            mXCMaterialListPinRefreshLayout.updateListNoAdd(mRecipeBeans, mContinueRecipeAdapter);
                            if (mRecipeBeans.size() == 0) {
                                mXCMaterialListPinRefreshLayout.whichShow(0);
                            }else if(!mXCMaterialListPinRefreshLayout.isLastRequestResult()){
                                getRecipeData(nextPage);
                            }else if(mRecipeBeans.size()<10 && mXCMaterialListPinRefreshLayout
                                    .base_currentPage <mXCMaterialListPinRefreshLayout.base_totalPage){
                                mXCMaterialListPinRefreshLayout.setBase_currentPage(nextPage);
                                getRecipeData(nextPage);
                            }
                        }
                    }

                    // 对账户冻结情况的判断处理
                    public void onFinish() {
//                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(mActivity,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

    /**
     * 显示正大天晴对话框
     *
     * @param medicines
     */
    private void showMedicineFifterDialog(String medicines) {
        if (mMedicineFifterDialog == null) {
            mMedicineFifterDialog = new YR_CommonDialog(mActivity, medicines, "", "我知道了") {
                @Override
                public void confirmBtn() {
                    mMedicineFifterDialog.dismiss();
                }
            };
            mMedicineFifterDialog.setCanceledOnTouchOutside(false);
        }
        mMedicineFifterDialog.show();
    }

    @Override
    public void delete(int position) {
        deleteRecipe(position);//删除续方
    }

    @Override
    public void continueRecipe(int position) {
        reqContinueRecipe(position);//续方
    }

    @Override
    public void onItemClick(int position) {
        // 处方详情
        ToJumpHelp.toJumpRecommendDetailActivity(mActivity, mRecipeBeans.get(position)
                .getRecommendId(), mActivity.getPatientDrugInfo().getChatModel().getUserPatient().getPatientId());
    }

    /**
     * 显示覆盖处方的对话框
     */
    private void showOverRecipeDialog() {
        YR_CommonDialog mOverRecipeDialog = new YR_CommonDialog(mActivity,
                "当前已有编辑中的处方，使用“续方”功能将覆盖当前编辑中的处方，是否继续？", "取消", "继续") {
            @Override
            public void confirmBtn() {
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setList(patientDrugInfo.getList());
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setDiagnoseBeanList(patientDrugInfo.getDiagnoseBeanList());
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setRecommendInfo(patientDrugInfo.getRecommendInfo());
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setCheckInventoryInfo(true);
                SQ_RecommendActivity.launch(mActivity);
                dismiss();
            }
        };
        mOverRecipeDialog.setCanceledOnTouchOutside(false);
        mOverRecipeDialog.show();
    }

}
