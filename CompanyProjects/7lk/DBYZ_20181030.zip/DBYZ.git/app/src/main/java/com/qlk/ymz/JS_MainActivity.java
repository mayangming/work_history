package com.qlk.ymz;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gdca.sdk.casign.model.GdcaCertModel;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.activity.LoginAndRegisterActivity;
import com.qlk.ymz.activity.XC_ChatDetailActivity;
import com.qlk.ymz.activity.XD_ServiceChatActivity;
import com.qlk.ymz.activity.XD_SetPersonalConsultingFeesActivity;
import com.qlk.ymz.activity.YY_PersonalDataActivityV2;
import com.qlk.ymz.application.DBApplication;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.maintab.JS_HomeFragment;
import com.qlk.ymz.maintab.MyFragment;
import com.qlk.ymz.maintab.YR_PatientFragment;
import com.qlk.ymz.parse.Parse2PatientBean;
import com.qlk.ymz.service.XC_MqttProcess;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.ElectronicSignatureHelper;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.HomeWatcher;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UmengProxy;
import com.qlk.ymz.util.UtilLoginOut;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.util.qlkserivce.QlkServiceHelper;
import com.qlk.ymz.view.YR_CommonDialog;
import com.tencent.callsdk.ILVCallConfig;
import com.tencent.callsdk.ILVCallManager;
import com.tencent.callsdk.ILVCallNotification;
import com.tencent.callsdk.ILVCallNotificationListener;
import com.tencent.qcloud.presenters.LoginHelper;
import com.tencent.qcloud.utils.Constants;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilBroadcast;
import com.xiaocoder.android.fw.general.util.UtilMd5;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;
import org.json.JSONObject;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

/**
 * 一级频道框架页
 * @author 徐金山
 * @version 2.3.0
 */
public class JS_MainActivity extends DBActivity implements ILVCallNotificationListener {
    //---------zhangpengfei 2016-05-09 add--------------
    /**跳转key,push过来的*/
    public static final String LINK_KEY = "linkKey";
    /**
     * 区分通知点过来的是push还是chat
     * 1.push(除了聊天以外的所有通知)  2.chat(聊天)
     * 3.客服聊天//add by xiedong
     */
    public static final String NOTIFICATION_TYPE = "notificationType";
    //---------zhangpengfei 2016-05-09 end--------------
    // ==========控件==========
    /** 第一个tab控件 */
    private LinearLayout js_id_tab_item1;
    private TextView tv_home_tab_item1;
    private ImageView iv_home_tab_item1;
    /** 第一个tab标识数目 */
    private TextView js_id_tab_item1_number;
    /** 第二个tab控件 */
    private LinearLayout js_id_tab_item2;
    private TextView tv_patient_tab_item2;
    private ImageView iv_patient_tab_item2;
    /** 第二个tab标识数目 */
    private TextView js_id_tab_item2_number;
    /** 第三个tab控件 */
    private LinearLayout js_id_tab_item3;
    private TextView tv_myspace_tab_item3;
    private ImageView iv_myspace_tab_item3;
    /** 第三个tab标识数目 */
    private ImageView js_id_tab_item3_number;

    // ==========常量==========
    /** 两次收到聊天咨询信息时间差（单位：毫秒） */
    private final int timeGap = 700;
    /** tab标识  1 首页  2 患者  3 个人中心 */
    public static final String TAB_TAG = "tabTag";
    /** 首页tab */
    public static final String TAB_HOME = "1";
    /** 患者tab */
    public static final String TAB_PATIENT = "2";
    /** 个人中心tab */
    public static final String TAB_MY = "3";
    //---------zhangpengfei 2016-07-13 add--------------
    /**来自页面标记*/
    public static final String FROM_PAGE = "fromPage";
    /**来自登录页*/
    public static final String FROM_LOGIN = "fromLogin";
    /**来自注册页*/
    public static final String FORM_REGISTER = "form_register";
    /** 登录页面患者列表请求成功与失败的标识 */
    public static final String PATIENT_REQUEST = "patient_request";
    /** 登录页患者列表请求失败 */
    public static final String PATIENT_REQUEST_ERRO = "patient_request_erro";
    //---------zhangpengfei 2016-07-13 end--------------
    /**来自h5升级页*/
    public static final String FROM_H5UPDATE = "fromHtml5Update";
    //add by tengfei date 2016:10:17  start
    public static final String PUSH_TO_H5 = "1";
    public static final String PUSH_TO_CHATDETAIL = "2";
    public static final String PUSH_TO_QLKSERVICE = "3";
    //add by tengfei date 2016:10:17   end
    // ==========变量==========
    /** mqtt处理对象 */
    private XC_MqttProcess mqttProcess;
    /** 聊天消息广播接收器 */
    private ChatDetailReceiver chat_detail_receiver;
    /** 有新患者广播接收器 */
    private ChatNewPatientReceiver new_patient_receiver;
    /** 医生状态更新接收器 */
    private UpdateAuthStatusReceiver update_auth_status_receiver;
    /** 新视频消息的接收器 */
    private NewVideoReceiver new_video_receiver;
    /** 医生助手消息接收器 */
    private NewDoctorAsstantReceiver new_doctor_asstant_receiver;
    /** 记录上一次收到咨询push消息的时间（单位：毫秒） */
    private long last_message_time;
    /** 去认证对话框 */
    private YR_CommonDialog identifyDialog;
    /** 是否显示过了去认证对话框（true：显示了；false：未显示） */
    private boolean isShownIdentyfyDialog = false;
    /** home监听类实例 */
    private HomeWatcher mHomeWatcher;
    // add by songxin,date：2016-7-26,about：腾讯IM登录,begin
    /** 腾讯相关广播接收器 */
    private TencentIMAboutReceiver tencentIMAboutReceiver;
    // add by songxin,date：2016-7-26,about：腾讯IM登录,end

    /** add by cyr on 2016-11-7 V2.6.5  底部tab切换动画效果的标记，表示上次点击的位置，1 首页；2 患者；3 个人中心*/
    private int fragmentNum = 1;
    /** add by cyr on 2017-4-12 广播接收的患者列表刷新类型 （0 添加新患者；1 修改图文咨询价格）*/
    public String patientListRefreshType = "0";


    /** add by cyr on 2017-4-18 判断是否为系统公告push的标识  */
    public static boolean isPubNotice = false;
    /** add by lsq on 2017-6-14 判断是否被创建 */
    private boolean isCreate = false;
    /** add by cyr on 2017-8-21 判断备案dialog是否弹出 */
    public boolean isShowRecommendDialog = false;
    // 控制是否显示去认证对话框的key
    public static String IS_SHOWN_IDENTYFY_DIALOG = "isShownIdentyfyDialog";


    /**
     * update by cyr on 2017-4-12
     * 1、接收添加新患者的广播，更新患者数量的sp
     * 2、接收单个患者图文咨询价格修改的广播
     * 3、接收患者图文咨询价格批量修改的广播
     *
     * 策略：1、单个修改图文咨询价格：更新本地数据库，并刷新患者列表
     *      2、批量修改图文咨询价格和添加新患者：请求患者列表接口，更新数据库，并刷新患者列表
     * 原因：批量修改图文咨询价格时，有时无法获得群组患者的patientId，所以无法本地更新，只能请求接口
     *
     * update by cyr on 2017-6-23 V2.8 修改患者信息，逻辑同“单个修改图文咨询价格”
     */
    public class ChatNewPatientReceiver extends BroadcastReceiver {
        public final static String CHAT_NEW_PATIENT_ACTION = "new_patient_action";
        /** 刷新类型，（0 添加新患者；1 修改图文咨询价格/修改患者基本信息） */
        public final static String REFRESH_TYPE = "refresh_type";

        public void onReceive(Context context, Intent intent) {
            XC_ChatModel chatModel = null;
            if (intent != null) {
                patientListRefreshType =  intent.getStringExtra(REFRESH_TYPE);
                chatModel = (XC_ChatModel) intent.getSerializableExtra(XD_SetPersonalConsultingFeesActivity.PATIENT_INGO);
            }
            if (TextUtils.isEmpty(patientListRefreshType)) {
                patientListRefreshType = "0";
            }
            if (chatModel == null) {//1、添加新患者；2、批量修改患者的图文咨询价格
                //刷新YR_PatientFragment页的患者列表数据
                updatePatientInfo();
            }else {//单个修改患者图文咨询价格/患者基本信息，只更新数据库，不请求网络
                YR_PatientFragment patientFragment = getFragmentByTag(YR_PatientFragment.class.getSimpleName());
                if (null != patientFragment) {
                    patientFragment.updateConsultCastRefreshPatientList(chatModel);
                }
            }

        }
    }

    /** 接受新视频消息的广播，在底部个人中心标签和个人中心的视频咨询显示数量 */
    public class NewVideoReceiver extends BroadcastReceiver {
        public final static String NEW_VIDEO_ACTION = "new_video_action";
        public final static String NEW_VIDEO_KEY = "new_video_key";

        public void onReceive(Context context, Intent intent) {
            setCenterNum();
        }
    }

    /** 接收客服发送新消息的广播，在底部个人中心标签和个人中心的视频咨询显示数量 */
    public class NewDoctorAsstantReceiver extends BroadcastReceiver {
        public final static String NEW_DOCTOR_ASSTANT_MSG_ACTION = "new_doctor_asstant_msg_action";

        public void onReceive(Context context, Intent intent) {
            setCenterNum();
            setUnreadRecordCount();//add by cyr on 2017-9-1 更新首页底部小红点
            updataHomeFragmentData();
        }
    }

    /**  add by cyr on 2016/6/30 接受JS_HomeFragment发送的广播，更新医生状态 */
    public class UpdateAuthStatusReceiver extends BroadcastReceiver {

        public void onReceive(Context context, Intent intent) {
            MyFragment myFragment = getFragmentByTag(MyFragment.class.getSimpleName());
            if(null != myFragment) {
                myFragment.setAuthStatus(UtilSP.getUserHeaderImage(), UtilSP.getAuthStatus());
                myFragment.setRecordStatus(UtilSP.getDoctorStatus());
            }
        }
    }

    /** 更新首页底部消息总数 */
    public void setUnreadRecordCount(){
        int unreadRecordCount = JS_ChatListDB.getInstance(JS_MainActivity.this, UtilSP.getUserId()).getUnreadRecordCount();
//        JS_ChatListModel js_chatListModel = JS_ChatListDB.getInstance(JS_MainActivity.this,UtilSP.getUserId()).getPatientInfo(JS_ChatListModel.SERVICE_ID);
//        if(!UtilString.isBlank(js_chatListModel.getUnReadMessageNum())){
//            int doctorAsstantUnNum = Integer.valueOf(js_chatListModel.getUnReadMessageNum());
//            unreadRecordCount -= doctorAsstantUnNum;
//        }
        setBubbleNum(js_id_tab_item1_number,unreadRecordCount);
    }

    /** 添加新患者后，刷新底部患者tab的显示数量，同时更新患者列表页新患者气泡数，并刷新患者列表 */
    private void updatePatientInfo() {
        setBubbleNum(js_id_tab_item2_number,UtilSP.getNewPatientNum());
        YR_PatientFragment patientFragment = getFragmentByTag(YR_PatientFragment.class.getSimpleName());
        if (null != patientFragment) {
            patientFragment.setNewPatientCount();
        }
        updateABCList(true);
    }

    /** 有新视频预约时，底部个人中心tab的显示数量，同时刷新个人中心页面的视频咨询的气泡数 */
    public void setCenterNum(){
        //将视频预约与医生助手未读消息添加在个人中心tab上
        int videoNum = UtilSP.getNewVideoNum();
        int doctorAsstantNum = UtilSP.getDoctorAsstantNum();
        if((videoNum+doctorAsstantNum)>0){
            js_id_tab_item3_number.setVisibility(View.VISIBLE);
        }else {
            js_id_tab_item3_number.setVisibility(View.GONE);
        }
        MyFragment myFragment = getFragmentByTag(MyFragment.class.getSimpleName());
        if(null != myFragment) {
            myFragment.showVideoConsultNum();
            myFragment.showDoctorAsstantNum();
        }
    }

    /** 显设气泡显示数量（适用所有地方） */
    public void setBubbleNum(TextView num_view, int num) {
        if (num_view != null) {
            if (num == 0) {
                num_view.setVisibility(View.INVISIBLE);
            } else if (num > 0 && num <= 99) {
                num_view.setVisibility(View.VISIBLE);
                num_view.setText(String.valueOf(num));
            } else {
                num_view.setVisibility(View.VISIBLE);
                num_view.setText("99+");
            }
        }
    }



    /**
     * 几种情况走这里：
     * 1、如果有新患者push通知或患者备注名修改：（1）患者列表页已经存在，刷新患者列表页数据，并更新入库
     *                                          （2）如果没有进入过患者列表页，在首页请求患者列表，并更新数据库
     * 2、如果登录时请求患者列表失败：此时进入首页，会重新请求患者列表，更新数据库
     * 3、除登陆、安装、清缓存外，版本更新时，刚进入首页，需要刷新一次患者列表，以解决患者数据库更新造成的问题，如果请求失败，强制登出
     */
    private void updateABCList(boolean isReceiver) {
        YR_PatientFragment patient_fragment = getFragmentByTag(YR_PatientFragment.class.getSimpleName());
        if (patient_fragment != null) {
            //添加新患者时清空患者列表sp，以防止有可能的数据相同，导致不能更新数据库
            if ("0".equals(patientListRefreshType)) {
                GlobalConfigSP.putMD5PatientListJson("");
                UtilSP.putContactsList("");
            }
            handler.sendEmptyMessageDelayed(2,500);
        } else if (isReceiver) {
            handler.sendEmptyMessageDelayed(3,500);
        } else if (PATIENT_REQUEST_ERRO.equals(getIntent().getStringExtra(PATIENT_REQUEST))) {//此判断可以去掉登陆和首次安装，以及清缓存的情况
            requestPatientABC(true);
        } else if (GlobalConfigSP.getIsVersionUpdate()) {
            requestPatientABC(true);
        }
        GlobalConfigSP.setISVersionUpdate(false);
    }

    /**
     * 创建首页时刷新一次患者列表，此处不进行患者列表MD5比对
     * @param isUpgrade 是否是版本升级 true，是
     * */
    private void requestPatientABC(final boolean isUpgrade) {
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.patient_my),  new RequestParams(), new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, final byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean != null) {
                        String byteStr = null;
                        try {
                            byteStr = new String(arg2, "utf-8");
                        } catch (Exception e) {
                        }
                        final String newJson = UtilMd5.MD5Encode(byteStr);
                        //从sp中获得已经存储的加密字符串
                        String oldJson = GlobalConfigSP.getMD5PatientListJson();
                        //比对上次患者列表json和新获得的患者列表json数据,不相等进行下面操作
                        if (!newJson.equals(oldJson)) {
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    //比对上次患者列表json和新获得的患者列表json数据,相等不进行存库操作
                                    ArrayList<XC_ChatModel> xc_chatModels = new ArrayList();
                                    Parse2PatientBean.parse(xc_chatModels,result_bean);
                                    GlobalConfigSP.putMD5PatientListJson(newJson);
                                    //更新数据库
                                    JS_ChatListDB.getInstance(JS_MainActivity.this, UtilSP.getUserId()).insertAllChatInfo(xc_chatModels);
                                    UtilSP.setPatientSum(xc_chatModels.size() + "");

                                    //TODO add　by cyr on 2018/4/21  start修复
                                    if (handler != null && "0".equals(patientListRefreshType)) {
                                        handler.sendEmptyMessage(1);
                                    }
                                    //TODO add　by cyr on 2018/4/21  end修复


                                    //更新聊天详情数据库的患者信息
                                    UserPatient userPatient = null;
                                    for (XC_ChatModel chatModel : xc_chatModels){
                                        boolean isUpdate = false;//数据库是否被更改过了
                                        String tableName = UtilSP.getIMDetailDbName(UtilSP.getUserId(), chatModel.getUserPatient().getPatientId());
                                        if (XCChatModelDb.map.containsKey(tableName)){
                                            XCChatModelDb chat_dao = XCChatModelDb.getInstance(getApplicationContext(),tableName);
                                            isUpdate = chat_dao.updateMsgHisttory(chatModel);
                                        }
                                        if (isUpdate && XC_ChatDetailActivity.recoder_which_patient_id.equals(chatModel.getUserPatient().getPatientId())){
                                            userPatient = chatModel.getUserPatient();
                                            sendUpdatePatientMsgReceiver(userPatient);
                                        }
                                    }
                                }
                                /* 发送更新患者的通知 */
                                private void sendUpdatePatientMsgReceiver(UserPatient userPatient){
                                    Intent model_intent = new Intent();
                                    model_intent.setAction(XC_ChatDetailActivity.UpdatePatientReceiver.UPDATE_PATIENT_ACTION);
                                    model_intent.putExtra(XC_ChatDetailActivity.UpdatePatientReceiver.UPDATE_PATIENT, userPatient);
                                    getApplicationContext().sendBroadcast(model_intent);
                                }
                            }).start();
                        }
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                if (isUpgrade){//如果是更新版本后第一次进入首页，请求数据失败，强制踢出登陆
                    GlobalConfigSP.putMD5PatientListJson("");
                    UtilSP.putContactsList("");
                    UtilLoginOut.loginOut(JS_MainActivity.this);
                    XCApplication.finishAllActivity();
                    myStartActivity(LoginAndRegisterActivity.class);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                // 处理code操作
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(JS_MainActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    private Runnable temp = new Runnable() {
        public void run() {
            setUnreadRecordCount();
            updataHomeFragmentData();
        }
    };

    public  Handler handler = new Handler(Looper.getMainLooper()){
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what){
                case 1:
                    updataHomeFragmentData();
                    break;
                case 2:
                    YR_PatientFragment patientFragment = getFragmentByTag(YR_PatientFragment.class.getSimpleName());
                    if (patientFragment != null) {
                        patientFragment.requestPatientABC(true);
                    }
                    break;
                case 3:
                    requestPatientABC(false);
                    break;
            }

        }
    };

    /**
     * ChatDetailReceiver中每收到一个消息，就会发出一条广播
     * （首页接收该广播更新所有患者的未读消息数量，联系人列表页注册了该广播，聊天详情页接收该广播更新一个患者的未读消息数为0）
     */
    public class ChatDetailReceiver extends BroadcastReceiver {
        public void onReceive(Context context, Intent intent) {
            if (System.currentTimeMillis() - last_message_time > timeGap) {
                setUnreadRecordCount();
                updataHomeFragmentData();
            } else {
                handler.removeCallbacks(temp);
                handler.postDelayed(temp, timeGap);
            }

            last_message_time = System.currentTimeMillis();
        }
    }

    /** 刷新首页咨询列表信息 */
    private void updataHomeFragmentData() {
        JS_HomeFragment home_fragment = getFragmentByTag(JS_HomeFragment.class.getSimpleName());
        if(null != home_fragment) {
            home_fragment.updateInfoListData();
            // start by cyr on 2017/7/18  来了系统公告，如果是医生认证的公告，需要实时刷新医生认证状态
            if(isPubNotice){
//                home_fragment.getHomeData(false);
                home_fragment.setData2Views();
                isPubNotice = false;
            }
            // end by cyr on 2017/7/18
        }
    }

    public void initWidgets() {
        js_id_tab_item1 = getViewById(R.id.js_id_tab_item1);
        js_id_tab_item1_number = getViewById(R.id.js_id_tab_item1_number);
        tv_home_tab_item1 = getViewById(R.id.tv_home_tab_item1);
        iv_home_tab_item1 = getViewById(R.id.iv_home_tab_item1);

        js_id_tab_item2 = getViewById(R.id.js_id_tab_item2);
        js_id_tab_item2_number = getViewById(R.id.js_id_tab_item2_number);
        tv_patient_tab_item2 = getViewById(R.id.tv_patient_tab_item2);
        iv_patient_tab_item2 = getViewById(R.id.iv_patient_tab_item2);

        js_id_tab_item3 = getViewById(R.id.js_id_tab_item3);
        js_id_tab_item3_number = getViewById(R.id.js_id_tab_item3_number);
        tv_myspace_tab_item3 = getViewById(R.id.tv_myspace_tab_item3);
        iv_myspace_tab_item3 = getViewById(R.id.iv_myspace_tab_item3);

        addFragment(R.id.js_id_model_content, new JS_HomeFragment());

        // 获得勿扰时间段
        getDisturb();
    }

    /**
     * 获得勿扰时间段
     */
    public void getDisturb() {
        XCHttpAsyn.postAsyn(this, AppConfig.getChatUrl(AppConfig.disturb_get), new RequestParams(), new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans != null && jsonBeans.size() > 0) {
                        // 存储时间
                        List beans = result_bean.getList("data");
                        if (beans != null && beans.size() > 0) {
                            if (beans.get(0) instanceof JSONObject || beans.get(0) instanceof XCJsonBean) {
                                if (!UtilString.isBlank(jsonBeans.get(0).getString("beginTime"))
                                        && !UtilString.isBlank(jsonBeans.get(0).getString("endTime"))) {
                                    UtilSP.setDistrubBeginTime(jsonBeans.get(0).getString("beginTime"));
                                    UtilSP.setDistrubEndTime(jsonBeans.get(0).getString("endTime"));
                                    UtilSP.setDistrubSetting(true);
                                }
                            }
                        }
                    } else {
                        UtilSP.setDistrubBeginTime("");
                        UtilSP.setDistrubEndTime("");
                        UtilSP.setDistrubSetting(false);
                    }
                    getAutoReplyInfo();
                }
            }

            public void fail() {
            }
        });
    }

    /**
     * 获得自动回复信息
     */
    public void getAutoReplyInfo() {
        RequestParams params = new RequestParams();
        params.put("operate", 2);
        XCHttpAsyn.postAsyn(this, AppConfig.getChatUrl(AppConfig.disturb_auto_reply), params, new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans != null && jsonBeans.size() > 0) {
                        // 存储时间
                        List beans = result_bean.getList("data");
                        if (beans.get(0) instanceof JSONObject || beans.get(0) instanceof XCJsonBean) {
                            UtilSP.setDistrubAutoReplyContent(jsonBeans.get(0).getString("content"));
                            UtilSP.setDistrubAutoReply("1".equals(jsonBeans.get(0).getString("status")) ? true : false);
                        }
                    } else {
                        UtilSP.setDistrubAutoReplyContent("");
                        UtilSP.setDistrubAutoReply(false);
                    }
                    updateABCList(false);
                }
            }

            public void fail() {
            }
        });
    }

    public void listeners() {
        js_id_tab_item1.setOnClickListener(this);
        js_id_tab_item2.setOnClickListener(this);
        js_id_tab_item3.setOnClickListener(this);
        js_id_tab_item1.setClickable(false);//setClickable(false)方法一定要在setOnClickListener()方法之后

//        js_id_tab_item1.setPressed(new Process());
    }

    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.js_activity_main);
        super.onCreate(savedInstanceState);
        setCreate(true);
        //create by ：songxin date:2016/8/11 about:视频时接受push消息问题修改 begin
        //设置显示push信息
        GlobalConfigSP.setSendNotice(true);
        //create by ：songxin date:2016/8/11 about:视频时接受push消息问题修改 end
        // 注册“mqtt广播接收器”
        mqttProcess = XC_MqttProcess.getInstance(this);
        mqttProcess.registerWhenMainActivityOnCreate();
        // 注册“聊天消息广播接收器”
        chat_detail_receiver = new ChatDetailReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000, XC_ChatDetailActivity.ChatDetailReceiver.CHAT_DETAIL_ACTION, chat_detail_receiver);
        // 注册“有新患者广播接收器”
        new_patient_receiver = new ChatNewPatientReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000, ChatNewPatientReceiver.CHAT_NEW_PATIENT_ACTION, new_patient_receiver);
        // 注册“更新认证状态广播接收器”
        update_auth_status_receiver = new UpdateAuthStatusReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000, JS_HomeFragment.UPDATE_AUTHSTATUS_ACTION, update_auth_status_receiver);
        // V2.6注册“新视频消息的广播接收器”
        new_video_receiver = new NewVideoReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000,   NewVideoReceiver.NEW_VIDEO_ACTION, new_video_receiver);
        // V2.6.2注册”医生消息的广播接收器“
        new_doctor_asstant_receiver = new NewDoctorAsstantReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000,   NewDoctorAsstantReceiver.NEW_DOCTOR_ASSTANT_MSG_ACTION, new_doctor_asstant_receiver);
        // 获取医生的坐诊时间
        getOutCallTimeList();

        // 友盟统计
        UmengProxy.onProfileSignIn(UtilSP.getUserId());
        // add by songxin,date：2018-3-8,about：GrowingIO,begin
        //绑定 GrowingIO用户id
        GrowingIOUtil.bindUserId();
        // add by songxin,date：2018-3-8,about：GrowingIO,end

        // add by songxin,date：2016-4-27,about：saveInfo,begin
        // home监听，发送bi
        onHomePressedListener();
        // add by songxin,date：2016-4-27,about：saveInfo,end

        // -------------zhangpengfei 2016-05-09 add----------------
        pushToApp();
        //--------------zhangpengfei 2016-05-09 end----------------

        // add by songxin,date：2016-7-26,about：腾讯IM登录,begin
        tencentIMAboutReceiver = new TencentIMAboutReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000, Constants.ACTION_TENCENT_IM_LOGIN_SUCCESS, tencentIMAboutReceiver);
        UtilBroadcast.myRegisterReceiver(this, 1000, Constants.ACTION_TENCENT_IM_LOGIN_FAIL, tencentIMAboutReceiver);
        IMLogin();
        // add by songxin,date：2016-7-26,about：腾讯IM登录,end
        //add by tengfei date 2016/10/10 about:环信接收新消息监听 begin
        //登录环信客服系统
        doctorAsstantLogin();
        //add by songxin,date：2018-4-2,about：GrowingIO banner track,begin
        GrowingIOUtil.setPeopleVariable();
        //add by songxin,date：2018-4-2,about：GrowingIO banner track,end
        isShownIdentyfyDialog = getIntent().getBooleanExtra(IS_SHOWN_IDENTYFY_DIALOG,false);

//        //开启debug日志数据
//        XGPushConfig.enableDebug(this,true);
//        XGPushManager.registerPush(this, new XGIOperateCallback() {
//            @Override
//            public void onSuccess(Object data, int flag) {
//            //token在设备卸载重装的时候有可能会变
//                Log.d("TPush", "注册成功，设备token为：" + data.toString());
//            }
//            @Override
//            public void onFail(Object data, int errCode, String msg) {
//                Log.d("TPush", "注册失败，错误码：" + errCode + ",错误信息：" + msg);
//                if (errCode >= 10101){
//                    shortToast("信鸽注册失败,请切换网络重试!");
//                }
//            }
//        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        setCreate(false);
    }

    protected void onStart() {
        super.onStart();

        // 设置未读消息数（在首页频道icon上显示的未读消息数）
        setUnreadRecordCount();
        // 设置新增患者数（在患者频道icon上显示的新增患者数）
        setBubbleNum(js_id_tab_item2_number,UtilSP.getNewPatientNum());
        // 设置新增视频数 （在个人中心icon上显示的新视频信息数）
        setCenterNum();

        // 启动mqtt的连接
        mqttProcess.connectWhenMainActivityOnStart();

//        // add by songxin,date：2016-4-22,about：bi,begin
//        // 如果当前页面id != pid 保存pid
//        if(!BiPageAndElementMap.getCurrentPageId(JS_MainActivity.class).equals(GlobalConfigSP.getPid())) {
//            GlobalConfigSP.setPid(BiPageAndElementMap.getCurrentPageId(JS_MainActivity.class));
//            printi("http","UtilSP.getPid()==JS_MainActivity====>"+ GlobalConfigSP.getPid());
//        }
////         add by songxin,date：2016-4-22,about：bi,end
    }
    // add by tengfei,date：2016-10-10,about：医生助手,begin
    @Override
    protected void onResume() {
        super.onResume();
        QlkServiceHelper.getInstance().pushActivity(this);

        //add by cyr on 2018/8/20  修复安装器安装，打开进入聊天页，按home建返回桌面，再按桌面图标，直接启动应用患者发送消息无小红点提示的bug
        XC_ChatDetailActivity.recoder_which_patient_id = "0";

    }

    @Override
    protected void onPause() {
        super.onPause();
        QlkServiceHelper.getInstance().popActivity(this);
    }

    // add by tengfei,date：2016-10-10,about：医生助手,end
    protected void onDestroy() {
        // 注销本页面和子Fragment注册的广播接收器
        // add by cyr on 2016-3-22 start
        // 因在activity中super.onDestroy之前加的方法，在Fragment的ondestroy方法之前
        // 在activity中super.onDestroy之后加的方法；在fragment的onDestroy执行完成后执行
        YR_PatientFragment patient_fragment = getFragmentByTag(YR_PatientFragment.class.getSimpleName());
        if (patient_fragment != null) {
            UtilBroadcast.myUnregisterReceiver(this, patient_fragment.noNetBroadCastReceiver);
        }
        // add by cyr on 2016-3-22 end

        UtilBroadcast.myUnregisterReceiver(this, chat_detail_receiver);
        UtilBroadcast.myUnregisterReceiver(this, new_patient_receiver);
        UtilBroadcast.myUnregisterReceiver(this, update_auth_status_receiver);
        UtilBroadcast.myUnregisterReceiver(this,new_video_receiver);
        UtilBroadcast.myUnregisterReceiver(this, new_doctor_asstant_receiver);
        // add by songxin,date：2016-7-27,about：腾讯IM相关,begin
        UtilBroadcast.myUnregisterReceiver(this, tencentIMAboutReceiver);
        // add by songxin,date：2016-7-27,about：腾讯IM相关,end
        mqttProcess.unregisterWhenMainActivityOnDestroy();
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(identifyDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();

        // add by songxin on 20160427 start
        if(null != mHomeWatcher){
            mHomeWatcher.stopWatch();
        }
        // add by songxin on 20160427 end
    }

    /**
     * 获取医生的坐诊时间
     */
    private void getOutCallTimeList() {
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.workTime_timeList), new RequestParams(), new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                try {
                    List<XCJsonBean> jsons = result_bean.getList("data");
                    List<XCJsonBean> workTimeJsons = jsons.get(0).getList("workTime");
                    UtilSP.putDoctorWorkTime(workTimeJsons.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            public void fail() {
            }
        });
    }

    /**
     * 显示去认证对话框
     */
    public void showAuthDialog(final Handler signHandler) {
        // 0 已提交处于审核中；
        // 1 认证通过；
        // 2 认证失败；
        // 3 再次认证处于审核中；
        // 4 是初始状态，没有提交认证资料。
        String status = UtilSP.getAuthStatus();
        if ("2".equals(status) || "4".equals(status) && !isShownIdentyfyDialog) {
            //只要是认证失败，则弹出去认证对话框
            showIdentifyDialog();
        }else {
            //----------设置为弹过对话框 zhangpengfei 2016-06-30 add----------------
            isShownIdentyfyDialog = true;
            isShowRecommendDialog = false;
            //---------- zhangpengfei 2016-06-30 end----------------

            // V2.9 by cyr on 2017-8-4 设置电子签名dialog 已认证，且在首页
            JS_HomeFragment home_fragment = getFragmentByTag(JS_HomeFragment.class.getSimpleName());
            if ("1".equals(status) && home_fragment.isVisible()) {
                // 已备案未签名医生，显示dialog
                String doctorStatus = UtilSP.getDoctorStatus();
                if ("2".equals(doctorStatus) && UtilSP.getGoSign()) {//备案成功,判断是否设置过电子签名
                    ElectronicSignatureHelper.getInstance().getCertInfo(false,this, new ElectronicSignatureHelper.CertInfoListener() {
                        @Override
                        public void onCertInfo(GdcaCertModel var1) {
                            signHandler.sendEmptyMessage(0);
                        }

                        @Override
                        public void onFail(String msg, int code) {
                            if(code== ElectronicSignatureHelper.UNSET_CERT){
                                if (UtilSP.getGoSign()) {
                                    UtilSP.setGoSign(false);
                                    showSignatureDialog();
                                    isShowRecommendDialog = true;
                                    signHandler.sendEmptyMessage(0);
                                }
                            }
                        }
                    });

                    return;
                }
                if ("4".equals(doctorStatus) && UtilSP.getGoFiling()) {//要求备案
                    showFilingDialog("根据卫健委要求，也是为了保障您的处方行为真实有效，请提交互联网医院备案资料");
                    UtilSP.setGoFiling(false);
                    isShowRecommendDialog = true;
                }
                if ("3".equals(doctorStatus) && UtilSP.getGoFilingAgain()) {//备案失败
                    showFilingDialog("抱歉，您的互联网医院备案审核未通过，请重新提交。");
                    UtilSP.setGoFilingAgain(false);
                    isShowRecommendDialog = true;
                }

            }
        }
        signHandler.sendEmptyMessage(0);

    }

    /**
     * 显示去进行身份认证对话框
     */
    private void showIdentifyDialog() {
        if (identifyDialog == null) {
            identifyDialog = new YR_CommonDialog(JS_MainActivity.this,"通过身份认证后可体验更多功能哦~","暂不认证","去认证") {
                @Override
                public void confirmBtn() {
                    identifyDialog.dismiss();
                    Intent intent = new Intent(JS_MainActivity.this, YY_PersonalDataActivityV2.class);
                    JS_MainActivity.this.startActivity(intent);
                }
            };
        }

        if (identifyDialog != null && !identifyDialog.isShowing() && !isShownIdentyfyDialog) {
            identifyDialog.show();
            isShownIdentyfyDialog = true;
        }
    }

    /**
     * 显示设置电子签名dialog
     * add by cyr on 2017-7-24
     */
    private void showSignatureDialog() {
        YR_CommonDialog signatureDialog =  new YR_CommonDialog(JS_MainActivity.this,"恭喜您互联网医院已经备案成功！\n马上安装数字证书，开启处方电子签名吧","取消","设置电子签名") {
            @Override
            public void confirmBtn() {
                dismiss();
                ToJumpHelp.toJumpHospitalBackupsActivity(JS_MainActivity.this);
            }

            @Override
            public void cancelBtn() {
                super.cancelBtn();
                showCancelDialog(CommonConfig.SIGN_PATH);
            }
        };
        signatureDialog.setCancelable(false);
        signatureDialog.show();
    }

    /**
     *1 显示要求备案dialog
     *2 显示备案失败dialog
     * add by cyr on 2017-8-2
     */
    private void showFilingDialog(String contentStr) {
        YR_CommonDialog filingDialog = new YR_CommonDialog(JS_MainActivity.this, contentStr, "取消", "马上备案") {
            @Override
            public void confirmBtn() {
                dismiss();
                onClickTabCheck(js_id_tab_item3,MyFragment.class);
                fragmentNum = 3;
            }

            @Override
            public void cancelBtn() {
                super.cancelBtn();
                showCancelDialog(CommonConfig.RECOMMEND_PATH);
            }
        };
        filingDialog.setCancelable(false);
        filingDialog.show();
    }

    /**
     * 1 显示取消电子签名dialog
     * 2 显示取消备案dialog
     * add by cyr on 2017-8-2
     */
    private void showCancelDialog(String contentStr) {
        new YR_CommonDialog(JS_MainActivity.this, contentStr, "", "知道了") {
            @Override
            public void confirmBtn() {
                dismiss();
            }
        }.show();
    }

    public boolean identifyDialogIsShow(){
        if(identifyDialog == null){
            return false;
        }
        return identifyDialog.isShowing();
    }

    // 双击两次返回键退出应用
    private long back_quit_time;
    public void onBackPressed() {
        long this_quit_time = System.currentTimeMillis();
        if (this_quit_time - back_quit_time <= 1000) {
            // add by songxin,date：2016-4-25,about：saveInfo,begin
            BiUtil.saveBiInfo(JS_MainActivity.class,"1","","","",true);
            // add by songxin,date：2016-4-25,about：saveInfo,end

            // 修改退出应用的方式，改为finish退出，不使用System.exit(0)退出 不要修改,就用这种方式
            XCApplication.AppExit(); //6.0手机会跳到登录页

//            // add by jingyu ,2016-11-17 ,start
//            // V2.6.5 改为 双击回退模拟homg键的效果
//            Intent i= new Intent(Intent.ACTION_MAIN);
//            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            i.addCategory(Intent.CATEGORY_HOME);
//            startActivity(i);
//            // add by jingyu ,2016-11-17 ,end

        } else {
            back_quit_time = this_quit_time;
            shortToast("快速再按一次退出");
        }
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        // -------------zhangpengfei 2016-05-09 add----------------
        pushToApp();
        // -------------zhangpengfei 2016-05-09 end----------------
        Intent intent_tag = getIntent();
        if (null != intent_tag){
            String tag = intent_tag.getStringExtra(TAB_TAG);
            if(tag == null){
                return;
            }
            switch (tag){
                case TAB_HOME:
                    jumpToMain(js_id_tab_item1,JS_HomeFragment.class);
                    JS_HomeFragment home_fragment = getFragmentByTag(JS_HomeFragment.class.getSimpleName());
                    home_fragment.setDoctorHeadImg();
                    home_fragment.refreshBannerInfo();
                    fragmentNum = 1;
                    break;
                case TAB_PATIENT:
                    jumpToMain(js_id_tab_item2,YR_PatientFragment.class);
                    fragmentNum = 2;
                    break;
                case TAB_MY:
                    jumpToMain(js_id_tab_item3,MyFragment.class);
                    fragmentNum = 3;
                    break;
                default:
            }
        }
    }

    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.js_id_tab_item1:
                onClickTabCheck(js_id_tab_item1,JS_HomeFragment.class);
                JS_HomeFragment home_fragment = getFragmentByTag(JS_HomeFragment.class.getSimpleName());
                home_fragment.setDoctorHeadImg();
                //delete by cyr on 2016-11-10  解决底部状态栏切换卡顿的现象
//                home_fragment.refreshBannerInfo();

                fragmentNum = 1;
                break;
            case R.id.js_id_tab_item2:
                onClickTabCheck(js_id_tab_item2,YR_PatientFragment.class);

                fragmentNum = 2;
                break;
            case R.id.js_id_tab_item3:
                onClickTabCheck(js_id_tab_item3,MyFragment.class);

                fragmentNum = 3;
                break;
        }
    }


    private void resetTab(LinearLayout isClickedView, Class mClass){
        js_id_tab_item1.setClickable(true);
        js_id_tab_item2.setClickable(true);
        js_id_tab_item3.setClickable(true);
        isClickedView.setClickable(false);

        tv_home_tab_item1.setTextColor(this.getResources().getColor(R.color.c_7f848d));
        tv_home_tab_item1.setVisibility(View.VISIBLE);
        ViewGroup.LayoutParams layoutParams = iv_home_tab_item1.getLayoutParams();
        layoutParams.height = UtilScreen.dip2px(this,29);
        layoutParams.width = UtilScreen.dip2px(this,29);
        iv_home_tab_item1.setImageResource(R.mipmap.js_d_home_normal);

        tv_patient_tab_item2.setTextColor(this.getResources().getColor(R.color.c_7f848d));
        iv_patient_tab_item2.setImageResource(R.mipmap.js_d_patient_normal);

        tv_myspace_tab_item3.setTextColor(this.getResources().getColor(R.color.c_7f848d));
        iv_myspace_tab_item3.setImageResource(R.mipmap.js_d_myspace_normal);

        if (mClass.getSimpleName().equals(JS_HomeFragment.class.getSimpleName())) {
            tv_home_tab_item1.setVisibility(View.GONE);
            layoutParams.height = UtilScreen.dip2px(this,49);
            layoutParams.width = UtilScreen.dip2px(this,49);
            iv_home_tab_item1.setImageResource(R.mipmap.js_d_home_pressed);
        } else if (mClass.getSimpleName().equals(YR_PatientFragment.class.getSimpleName())) {
            tv_patient_tab_item2.setTextColor(this.getResources().getColor(R.color.c_dd0031));
            iv_patient_tab_item2.setImageResource(R.mipmap.js_d_patient_pressed);
        } else {
            tv_myspace_tab_item3.setTextColor(this.getResources().getColor(R.color.c_dd0031));
            iv_myspace_tab_item3.setImageResource(R.mipmap.js_d_myspace_pressed);
        }
    }


    /**
     *   V2.7优化
     * 　点击底部tab标签选项的处理（有切换动画）
     *   @param isClickedView  点击的tab按钮
     *   @param mClass 切换的fragment
     * */
    private void onClickTabCheck( LinearLayout isClickedView, Class mClass){
        resetTab(isClickedView,mClass);

        if (fragmentNum == 1) {
            JS_HomeFragment fragment = getFragmentByTag(JS_HomeFragment.class.getSimpleName());
            hideFragment(fragment, 1);
            showFragmentByClass(mClass, R.id.js_id_model_content, 2);
        } else if (fragmentNum == 2) {
            YR_PatientFragment fragment = getFragmentByTag(YR_PatientFragment.class.getSimpleName());
            if (mClass.getSimpleName().equals(JS_HomeFragment.class.getSimpleName())) {
                hideFragment(fragment, 2);
                showFragmentByClass(mClass, R.id.js_id_model_content, 1);
            } else if (mClass.getSimpleName().equals(MyFragment.class.getSimpleName())) {
                hideFragment(fragment, 1);
                showFragmentByClass(mClass, R.id.js_id_model_content, 2);
            }
        } else if (fragmentNum == 3) {
            MyFragment fragment = getFragmentByTag(MyFragment.class.getSimpleName());
            hideFragment(fragment, 2);
            showFragmentByClass(mClass, R.id.js_id_model_content, 1);
        }
    }

    /**
     * V2.9
     *  跳转首页时的处理（无动画）
     * */
    private void jumpToMain(LinearLayout isClickedView, Class mClass){
        resetTab(isClickedView,mClass);

        Fragment fragment = null;
        if (fragmentNum == 1) {
            fragment = getFragmentByTag(JS_HomeFragment.class.getSimpleName());
        } else if (fragmentNum == 2) {
            fragment = getFragmentByTag(YR_PatientFragment.class.getSimpleName());
        } else if (fragmentNum == 3) {
            fragment = getFragmentByTag(MyFragment.class.getSimpleName());
        }
        super.hideFragment(fragment);
        super.showFragmentByClass(mClass, R.id.js_id_model_content);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void showPage() {
        showContentLayout();
        showTitleLayout(true);
    }

    // add by songxin,date：2016-4-27,about：按home的时候执行,begin
    private void onHomePressedListener(){
        try {
            mHomeWatcher = new HomeWatcher(this);
            mHomeWatcher.setOnHomePressedListener(new HomeWatcher.OnHomePressedListener() {
                public void onHomePressed() {
                    printi("http","onHomePressed");
                    BiUtil.saveBiInfo(JS_MainActivity.class,"1","","","",true);
                }

                public void onHomeLongPressed() {
                    printi("http","onHomeLongPressed");
                }
            });
            mHomeWatcher.startWatch();
        } catch(Exception e) {
            e.printStackTrace();
            mHomeWatcher.stopWatch();
        }
    }
    // add by songxin,date：2016-4-27,about：按home的时候执行,end

    // -----------zhangpengfei 2016-05-09 add----------
    /**
     * 分发push过来的linkKey,进行跳转
     */
    private void pushToApp(){
        if (null != getIntent()){
            String linkKey = getIntent().getStringExtra(LINK_KEY);
            String notificationType = getIntent().getStringExtra(NOTIFICATION_TYPE);
            XC_ChatModel bean = (XC_ChatModel) getIntent().getSerializableExtra(CommonConfig.CHAT_PARAMS_MODEL);
            if (!UtilString.isBlank(notificationType)){
                if (PUSH_TO_H5.equals(notificationType) && !UtilString.isBlank(linkKey)){
                    NativeHtml5.newInstance(this).webToAppPage(linkKey);
                }else if (PUSH_TO_CHATDETAIL.equals(notificationType) && null != bean){
                    Intent intent = new Intent(this,XC_ChatDetailActivity.class);
                    intent.putExtra(CommonConfig.CHAT_PARAMS_MODEL, bean);
                    startActivity(intent);
                }else if(PUSH_TO_QLKSERVICE.equals(notificationType)){
                    Intent intent = new Intent(this,XD_ServiceChatActivity.class);
                    startActivity(intent);
                }
            }
        }
//        if(QlkServiceHelper.isNotifaIn){
//            QlkServiceHelper.isNotifaIn = false;
//            Intent intent = new Intent();
//            intent.setClass(this,XD_ServiceChatActivity.class);
//            startActivity(intent);
//        }
    }


    // ------------zhangpengfei 2016-05-09 end----------

//    /**
//     * 隐藏翻页控件
//     */
//    public void gonePageCurlyView() {
//        JS_HomeFragment home_fragment = getFragmentByTag(JS_HomeFragment.class.getSimpleName());
//        home_fragment.gonePageCurlyView();
//    }

    // add by songxin,date：2016-7-26,about：腾讯IM登录,begin

    public boolean isCreate() {
        return isCreate;
    }

    public void setCreate(boolean create) {
        isCreate = create;
    }

    /**
     * 腾讯 IM登录
     */
    private void IMLogin(){
        //判断userSig是否存在
        if(!UtilString.isBlank(UtilSP.getUserSig())){
            //如果返回值为当前登陆的用户名说明IM已登录
            printi("http","==========no===========");
            LoginHelper.getLoginHelper(DBApplication.getInstance()).imLogin("dr_" + UtilSP.getUserId(),UtilSP.getUserSig());
        }else{
            printi("http","==========null===========");
            qcloudTLSGetUserSig();
        }
    }

    /**
     * 自主账号独立模式管理
     * 获取userSig
     */
    private void qcloudTLSGetUserSig(){
        //发送请求
        RequestParams params = new RequestParams();
        params.put("userId", "dr_" + UtilSP.getUserId());
        params.put("appId", Constants.SDK_APPID);

        XCHttpAsyn.postAsyn(false, this, AppConfig.getChatUrl(AppConfig.get_sig), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if(result_boolean){
                    final List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                        //登录腾讯IM模块
                        LoginHelper.getLoginHelper(DBApplication.getInstance()).imLogin("dr_" + UtilSP.getUserId(),jsonBeans.get(0).getString("sig"));
                        //登录成功之后存usersig
                        UtilSP.setUserSig(jsonBeans.get(0).getString("sig"));
                    }
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(JS_MainActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    public class TencentIMAboutReceiver extends BroadcastReceiver {

        public void onReceive(Context context, Intent intent) {
            //IM登录成功
            if (Constants.ACTION_TENCENT_IM_LOGIN_SUCCESS.equals(intent.getAction())) {
                UtilSP.setAVSDKStatus(true);
                ILVCallManager.getInstance().init(new ILVCallConfig()
                        .setNotificationListener(JS_MainActivity.this)
                        .setAutoBusy(true).setTimeOut(30));
                //IM登录失败
            } else if (Constants.ACTION_TENCENT_IM_LOGIN_FAIL.equals(intent.getAction())) {
                UtilSP.setAVSDKStatus(false);
            }
        }
    }
    @Override
    public void onRecvNotification(int callid, ILVCallNotification notification) {
        Log.i("http","onRecvNotification->notify id:"+notification.getNotifId()+"|"+notification.getUserInfo()+"/"+notification.getSender());
    }

    /**
     * 环信IM登录与消息监听
     */
    private void doctorAsstantLogin() {
        QlkServiceHelper.getInstance().loginHuanXin(null);
    }

    // add by songxin,date：2016-7-26,about：腾讯IM登录,end

    // 无网络时,点击屏幕后回调的方法
    public void onNetRefresh() {
    }


    /**
     * 首页和患者页fragment无网提示设置
     * @param hasNet 是否有网
     */
    public void noNetChangeInFragment(boolean hasNet){
        JS_HomeFragment home_fragment = getFragmentByTag(JS_HomeFragment.class.getSimpleName());
        if(home_fragment != null) {
            View view = home_fragment.getViewById(R.id.xc_id_model_no_net_main);
            UtilViewShow.setGone(!hasNet,view);
        }
        YR_PatientFragment patientFragment = getFragmentByTag(YR_PatientFragment.class.getSimpleName());
        if(patientFragment != null) {
            View view = patientFragment.getViewById(R.id.xc_id_model_no_net_main);
            UtilViewShow.setGone(!hasNet,view);
        }
    }



    // V2.6.5  tab加入切换动画效果
    /**
     * @param direction 专场方向 （1 左进；右进）
     * */
    public void hideFragment(Fragment fragment, int direction) {
        if (fragment != null) {
            FragmentTransaction ft = base_fm.beginTransaction();
            anim(ft, direction);
            ft.hide(fragment);
            ft.commitAllowingStateLoss();
        }
    }

    public void showFragment(Fragment fragment, int direction) {
        if (fragment != null) {
            FragmentTransaction ft = base_fm.beginTransaction();
            anim(ft, direction);
            ft.show(fragment);
            ft.commitAllowingStateLoss();
        }
    }

    public void addFragment(int layout_id, Fragment fragment, String tag, boolean isToBackStack, int direction) {
        FragmentTransaction ft = base_fm.beginTransaction();
        anim(ft, direction);
        ft.add(layout_id, fragment, tag);
        if (isToBackStack) {
            ft.addToBackStack(tag);
        }
        ft.commitAllowingStateLoss();
        base_fm.executePendingTransactions();
    }

    /**
     * 显示一个fragment
     *
     * @param fragment_class fragment的字节码
     * @param layout_id      布局id
     * @return
     */
    public Fragment showFragmentByClass(Class<? extends Fragment> fragment_class, int layout_id, int direction) {
        // 显示点击的哪个fragment
        Fragment fragment = getFragmentByTag(fragment_class.getSimpleName());
        if (fragment == null) {
            try {
                Constructor<? extends Fragment> cons = fragment_class.getConstructor();
                fragment = cons.newInstance();
                addFragment(layout_id, fragment, fragment.getClass().getSimpleName(), false, direction);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            showFragment(fragment, direction);
        }
        return fragment;
    }

    /**
     * fragment切换动画
     *
     * @param direction 专场方向 （1 左进；2 右进）
     * */
    public void anim(FragmentTransaction ft, int direction) {
        switch (direction) {
            case 1:
                ft.setCustomAnimations(
                        R.anim.push_left_in,
                        R.anim.push_left_out,
                        R.anim.push_left_in,
                        R.anim.push_left_out);
                break;
            case 2:
                ft.setCustomAnimations(
                        R.anim.push_right_in,
                        R.anim.push_right_out,
                        R.anim.push_right_in,
                        R.anim.push_right_out);
                break;
        }
    }



}
