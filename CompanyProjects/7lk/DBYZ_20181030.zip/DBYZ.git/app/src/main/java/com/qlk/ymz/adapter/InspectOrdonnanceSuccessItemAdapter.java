package com.qlk.ymz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.ExamineList;

import java.util.List;

/**
 * 推荐成功-检查项目
 * @author WuPuquan
 * @version 1.0
 */
public class InspectOrdonnanceSuccessItemAdapter extends RecyclerView.Adapter<InspectOrdonnanceSuccessItemAdapter.ViewHolder>{

    private Context mContext;
    private List<ExamineList> mList;

    public InspectOrdonnanceSuccessItemAdapter(Context context, List<ExamineList> list) {
        this.mContext = context;
        this.mList = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_inspect_ordonnance_success, parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (null == mList || mList.isEmpty()) return;
        holder.tv_inspect_name.setText((position + 1) + "、" +  mList.get(position).getExamineName());
    }

    @Override
    public int getItemCount() {
        return null == mList? 0 : mList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        /** 检查项目名称 */
        TextView tv_inspect_name;

        public ViewHolder(View itemView) {
            super(itemView);

            tv_inspect_name = (TextView) itemView.findViewById(R.id.tv_inspect_name);

        }
    }
}
