package com.qlk.ymz.db.im.chatmodel;

import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * description: 聊天消息中的个性化咨询
 * autour: YM
 * date: 2017/7/11
 * update: $date$
 * version: $version$
 */

public class ChatModelCustomAdvisory implements Serializable,Cloneable {
    private String customAdvisoryId = "";//个性化咨询id
    private String customAdvisoryName = "";//咨询产品名称
    private String customAdvisImageUrl = "";//咨询产品描述图片地址
    private String customPrice = "";//个性化咨询价格
    private String customProductDesc = "";//简介内容

    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
    public String getCustomAdvisoryId() {
        return UtilString.f(customAdvisoryId);
    }

    public void setCustomAdvisoryId(String customAdvisoryId) {
        this.customAdvisoryId = customAdvisoryId;
    }

    public String getCustomAdvisoryName() {
        return UtilString.f(customAdvisoryName);
    }

    public void setCustomAdvisoryName(String customAdvisoryName) {
        this.customAdvisoryName = customAdvisoryName;
    }

    public String getCustomAdvisImageUrl() {
        return UtilString.f(customAdvisImageUrl);
    }

    public void setCustomAdvisImageUrl(String customAdvisImageUrl) {
        this.customAdvisImageUrl = customAdvisImageUrl;
    }

    public String getCustomPrice() {
        return UtilString.f(customPrice);
    }

    public void setCustomPrice(String customPrice) {
        this.customPrice = customPrice;
    }

    public String getCustomProductDesc() {
        return UtilString.f(customProductDesc);
    }

    public void setCustomProductDesc(String customProductDesc) {
        this.customProductDesc = customProductDesc;
    }



    public static void ParseJson(List<XCJsonBean> data, ArrayList<ChatModelCustomAdvisory> beanList){

        List<XCJsonBean> resultdata  = data.get(0).getList("result");
        for (int i=0;i<resultdata.size();i++){
            ChatModelCustomAdvisory bean = new ChatModelCustomAdvisory();
            bean.setCustomAdvisoryId(resultdata.get(i).getString("id"));
            bean.setCustomPrice(resultdata.get(i).getString("price"));
            bean.setCustomAdvisoryName(resultdata.get(i).getString("productName"));
            bean.setCustomProductDesc(resultdata.get(i).getString("synopsis"));
            beanList.add(bean);
        }

    }
}
