package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 聊天详情  医生 纯文本消息 + 用药助手的关键字
 */
public class XC_ChatRightTextAssistantHolder extends XC_ChatRightBaseHolder {

    public TextView xc_id_adapter_right_content_text;
    public RelativeLayout xc_id_adapter_right_recommand_hint_layout;
    public TextView xc_id_adapter_right_recommand_medicine;

    public XC_ChatRightTextAssistantHolder(View convertView) {
        super(convertView);
        xc_id_adapter_right_content_text = (TextView) convertView.findViewById(R.id.xc_id_adapter_right_content_text);
        xc_id_adapter_right_recommand_hint_layout = (RelativeLayout) convertView.findViewById(R.id.xc_id_adapter_right_recommand_hint_layout);
        xc_id_adapter_right_recommand_medicine = (TextView) convertView.findViewById(R.id.xc_id_adapter_right_recommand_medicine);
    }
}