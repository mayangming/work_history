package com.qlk.ymz.activity;

import android.os.Bundle;
import android.view.View;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.fragment.YY_FeedbackSettingFragment;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;

/**
 * @author shuYanYi on 2016/11/17.
 * @description 疗效随访
 * @version V2.6.5
 */

public class YY_FeedbackVisitActivity extends DBActivity {
    /** 内容fragment（疗效随访首页，原先是tab切换的展现，后来变回放到个人中心首页，预防以后ui还会改，保留此fragment形式）*/
    private YY_FeedbackSettingFragment feedbackVisitFragment;
    /**标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yy_l_feedback_visit);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-22,about：saveInfo,begin
        BiUtil.saveBiInfo(YY_FeedbackVisitActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-22,about：saveInfo,end
    }

    @Override
    public void onStart() {
        super.onStart();
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(YY_FeedbackVisitActivity.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "疗效随访");
        xc_id_model_titlebar.setTitleLeft(true, null);
        feedbackVisitFragment = new YY_FeedbackSettingFragment();
        addFragment(R.id.ll_fragment_body,feedbackVisitFragment);
    }

    @Override
    public void listeners() {
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
    }
    @Override
    public void onNetRefresh() {

    }
}
