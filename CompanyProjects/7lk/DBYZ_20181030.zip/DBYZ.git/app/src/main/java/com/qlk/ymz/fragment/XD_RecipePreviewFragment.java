package com.qlk.ymz.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.SQ_PreviewRecommendInfoActivity;
import com.qlk.ymz.adapter.SK_PrescriptionDetailAdapter;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.RecommendInfo;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.UtilNativeHtml5;

/**
 * Created by xiedong on 2018/10/17.
 * 处方预览
 */

public class XD_RecipePreviewFragment extends DBFragment {
    /** 时间 */
    private TextView tv_prescription_time;
    /** 编号 */
    private TextView sk_id_pdetail_serialNum;
    /** 患者名 */
    private TextView tv_prescription_name;
    /** 性别 */
    private TextView sk_id_pdetail_sex;
    /** 年龄 */
    private TextView tv_prescription_age;
    /** 临床诊断 */
    private TextView tv_prescription_diagnosis;
    /** 药品列表 */
    private ListView lv_prescription_drug_list;
    /** 医生名字 */
    private TextView tv_prescription_doctorName;
    /** 医生科室title*/
    private TextView sk_id_pdetail_t6;
    /** 医生科室 */
    private TextView tv_prescription_department;
    /** 有效期描述 */
    private TextView tv_expireDesc;
    /** 药品总金额 */
    private TextView tv_total_price;
    /** 处方笺title */
    private TextView tv_titleName;

    private RecommendInfo mRecommendInfo = new RecommendInfo();
    private SK_PrescriptionDetailAdapter mSK_prescriptionDetailAdapter;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return init(inflater, R.layout.xd_fragment_recipe_preview);
    }

    @Override
    public void initWidgets() {
        View headView = LayoutInflater.from(getActivity()).inflate(R.layout.layout_recommend_preview_head, null);
        View footView = LayoutInflater.from(getActivity()).inflate(R.layout.layout_recommend_preview_foot, null);

        tv_prescription_time = (TextView) headView.findViewById(R.id.tv_prescription_time);
        sk_id_pdetail_serialNum = (TextView) headView.findViewById(R.id.sk_id_pdetail_serialNum);
        tv_prescription_name = (TextView) headView.findViewById(R.id.tv_prescription_name);
        sk_id_pdetail_sex = (TextView) headView.findViewById(R.id.sk_id_pdetail_sex);
        tv_prescription_age = (TextView) headView.findViewById(R.id.tv_prescription_age);
        tv_titleName = (TextView) headView.findViewById(R.id.tv_titleName);
        sk_id_pdetail_t6 = (TextView) headView.findViewById(R.id.sk_id_pdetail_t6);
        tv_prescription_diagnosis = (TextView) headView.findViewById(R.id.tv_prescription_diagnosis);
        tv_prescription_department = (TextView) headView.findViewById(R.id.tv_prescription_department);
        tv_prescription_doctorName = (TextView) footView.findViewById(R.id.tv_prescription_doctorName);
        tv_expireDesc = (TextView) footView.findViewById(R.id.tv_expireDesc);
        tv_total_price = (TextView) footView.findViewById(R.id.tv_total_price);
        lv_prescription_drug_list = getViewById(R.id.lv_prescription_drug_list);

        lv_prescription_drug_list.addHeaderView(headView);
        lv_prescription_drug_list.addFooterView(footView);

        mSK_prescriptionDetailAdapter = new SK_PrescriptionDetailAdapter(getActivity(),true, mRecommendInfo.drugInfoBean);
        lv_prescription_drug_list.setAdapter(mSK_prescriptionDetailAdapter);

        setDate(mRecommendInfo);
    }

    @Override
    public void listeners() {
        lv_prescription_drug_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DrugBean bean = (DrugBean) parent.getItemAtPosition(position);
                if (bean != null) {
                    UtilNativeHtml5.toJumpDrugDetail(getActivity(), bean.getId());
                }
            }
        });
    }

    /** 设置页面数据 */
    public void setDate(RecommendInfo recommendInfo){
        try {
            String hospital = TextUtils.isEmpty(recommendInfo.getTitle()) ? "鼎康慈桦互联网医院处方笺" : recommendInfo.getTitle();
            tv_titleName.setText(hospital);

            if(!TextUtils.isEmpty(recommendInfo.getDepartmentName())) {
                sk_id_pdetail_t6.setVisibility(View.VISIBLE);
                tv_prescription_department.setVisibility(View.VISIBLE);
                tv_prescription_department.setText(recommendInfo.getDepartmentName());
            }
            tv_prescription_doctorName.setText("医生：" + recommendInfo.getDoctorName());
            if (!TextUtils.isEmpty(recommendInfo.getExpireDesc())) {
                tv_expireDesc.setVisibility(View.VISIBLE);
                tv_expireDesc.setText("注：" + recommendInfo.getExpireDesc());
            }
            sk_id_pdetail_serialNum.setText(recommendInfo.getSerialNumber());
            if(!TextUtils.isEmpty(recommendInfo.getRecomTime())) {
                String time = DateFormat.format("yyyy/MM/dd", Long.parseLong(recommendInfo.getRecomTime())).toString();
                tv_prescription_time.setText(time);
            }
            String ageContent = "";
            if (!TextUtils.isEmpty(recommendInfo.getPatientAge())){
                ageContent = ageContent.concat(recommendInfo.getPatientAge());
            }
            if (!TextUtils.isEmpty(recommendInfo.getPatientAgeUnit())){
                ageContent = ageContent.concat(recommendInfo.getPatientAgeUnit());
            }
            tv_prescription_age.setText(ageContent);
            tv_prescription_name.setText(recommendInfo.getPatientName());
            if (CommonConfig.GENDER_MALE.equals(recommendInfo.getPatientGender())) {
                sk_id_pdetail_sex.setText("男");
            } else if (CommonConfig.GENDER_FEMALE.equals(recommendInfo.getPatientGender())) {
                sk_id_pdetail_sex.setText("女");
            } else {
                sk_id_pdetail_sex.setText("");
            }
            tv_prescription_diagnosis.setText(recommendInfo.getDiagnosis());

            tv_total_price.setText("总金额：￥" + recommendInfo.getTotalPrice());

            //更新药品列表
            mSK_prescriptionDetailAdapter.update(recommendInfo.getDrugInfoBean());
            mSK_prescriptionDetailAdapter.notifyDataSetChanged();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void setRecommendInfo(RecommendInfo recommendInfo) {
        mRecommendInfo = recommendInfo;
    }
}
