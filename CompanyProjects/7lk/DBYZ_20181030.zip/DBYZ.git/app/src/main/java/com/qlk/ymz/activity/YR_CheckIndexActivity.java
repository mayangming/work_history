package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.util.EditsChangeCheckUtil;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.EditLinearLayout;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 *
 * 保存按钮规则
 * 进入页面时：
 * 1、如果传入的相关数据全为空，则页面edit全为空时，保存按钮不能点击
 * 2、其他情况都能点击
 *
 *
 * 取消按钮规则
 * 进入页面时：
 * 1、如果传入的相关数据全为空，则页面edit全为空时，点击取消按钮不拦截
 * 2、其他情况都拦截
 * */
public class YR_CheckIndexActivity extends DBActivity {

    private XCTitleCommonLayout xcTitleCommonLayout;
    /** 依次为：体温、体重、心率、收缩压、舒张压、更多检查 */
    private EditText et_body_temperature,et_body_weight,et_heart_rate,et_systolic_pressure,et_diastolic_pressure,et_more_check_result;
    private EditLinearLayout ll__more_check_result;
    private ScrollView sv;
    /** 更多检查的计数：默认0/1000 */
    private TextView tv_more_index_num;

    EditsChangeCheckUtil.textChangeListener textChangeListener;

    /** 上个页面传过来的检查数据model ，第一次进入数据为空，第二次以后进入传入第一次保存的数据，然后显示 */
    DrCaseVOBean mDrCaseVOBean;
    /** 判断从上个页面进入时是否有当前页面数据的标识（如果一个都没有，保存按钮不能点击） */
    boolean isHasData = false;
    /** 判断是否全部控件为空的标识 (true 全空)*/
    boolean isAllEmpty = false;
    /** 更多检查最大输入限制 */
    int moreMax;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_check_index);
        super.onCreate(savedInstanceState);

        initData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_CheckIndexActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    public void initData(){
        mDrCaseVOBean = (DrCaseVOBean) getIntent().getSerializableExtra(XD_EditMedicalRecordActivity.DR_CASE_VO_BEAN);
       if (mDrCaseVOBean != null) {
           et_body_temperature.setText(mDrCaseVOBean.getTemperature());
           et_body_temperature.requestFocus();
           et_body_weight.setText(mDrCaseVOBean.getWeight());
           et_heart_rate.setText(mDrCaseVOBean.getHeartRete());
           et_systolic_pressure.setText(mDrCaseVOBean.getSystolic());
           et_diastolic_pressure.setText(mDrCaseVOBean.getDiastole());
           et_more_check_result.setText(mDrCaseVOBean.getMoreExamin());
       }
       //判断上个页面传过来是否有数据，如果没有，保存按钮默认不能点击
        if (TextUtils.isEmpty(mDrCaseVOBean.getTemperature()) && TextUtils.isEmpty(mDrCaseVOBean.getWeight())
                && TextUtils.isEmpty(mDrCaseVOBean.getHeartRete()) && TextUtils.isEmpty(mDrCaseVOBean.getSystolic())
                && TextUtils.isEmpty(mDrCaseVOBean.getDiastole()) && TextUtils.isEmpty(mDrCaseVOBean.getMoreExamin())) {
            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_cccccc));
            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setEnabled(false);
            isHasData = false;
        } else {
            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setEnabled(true);
            isHasData = true;
        }

    }



    @Override
    public void initWidgets() {
        xcTitleCommonLayout = getViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonLayout.setTitleCenter(true, "检查指标");
        xcTitleCommonLayout.setTitleRight2(true, 0, "保存");
        xcTitleCommonLayout.setTitleLeft(-1, "取消");


        et_body_temperature = (EditText) findViewById(R.id.et_body_temperature);
        et_body_weight = (EditText) findViewById(R.id.et_body_weight);
        et_heart_rate = (EditText) findViewById(R.id.et_heart_rate);
        et_systolic_pressure = (EditText) findViewById(R.id.et_systolic_pressure);
        et_diastolic_pressure = (EditText) findViewById(R.id.et_diastolic_pressure);
        et_more_check_result = (EditText) findViewById(R.id.et_more_check_result);
        sv = (ScrollView) findViewById(R.id.sv);
        ll__more_check_result = (EditLinearLayout) findViewById(R.id.ll__more_check_result);
        ll__more_check_result.setParentScrollview(sv);
        ll__more_check_result.setEditText(et_more_check_result);

        tv_more_index_num = (TextView) findViewById(R.id.tv_more_index_num);

        //设置HBV-DNA最大字符上限
        moreMax =  GlobalConfigSP.getLimitValue(GlobalConfigSP.MORE_EXAMIN, 0, 1000);
        InputFilter[] filters = {new InputFilter.LengthFilter(moreMax)};
        et_more_check_result.setFilters(filters);
        tv_more_index_num.setText("0/" + moreMax);

    }

    @Override
    public void listeners() {
        //右侧保存按钮
        xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();

            }
        });

        et_more_check_result.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                tv_more_index_num.setText(et_more_check_result.getText().length() + "/" + moreMax);
            }
        });


        //保存按钮
        textChangeListener =
                new EditsChangeCheckUtil.textChangeListener(xcTitleCommonLayout.getXc_id_titlebar_right2_textview()){

                    @Override
                    public boolean btnChange() {
                        isAllEmpty = super.btnChange();
                                if (!isHasData && !isAllEmpty) {
                                    xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_cccccc));
                                    xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setEnabled(false);
                                } else {
                                    xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
                                    xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setEnabled(true);
                                }

                        return isAllEmpty;
                    }
                };

        textChangeListener.addAllEditText(et_body_temperature,et_body_weight,et_heart_rate,et_systolic_pressure,et_diastolic_pressure,et_more_check_result);


        xcTitleCommonLayout.getXc_id_titlebar_left_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isHasData && !isAllEmpty) {
                    myFinish();
                } else {
                    showDialog();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {//手机返回键阻止
        if (!isHasData && !isAllEmpty) {
            super.onBackPressed();
        } else {
            showDialog();
        }
    }


    @Override
    public void onNetRefresh() {

    }

    /** 点击取消按钮，如果输入框有数据，弹出阻止dialog */
    private void showDialog() {
        YR_CommonDialog dialog = new YR_CommonDialog(this, "放弃保存吗？", "放弃", "取消") {
            @Override
            public void confirmBtn() {
                dismiss();

            }

            @Override
            public void cancelBtn() {
                super.cancelBtn();
                YR_CheckIndexActivity.this.finish();
            }
        };
        dialog.setCancelable(false);
        dialog.show();
    }

    /**
     * 点击保存按钮，需要判断取值范围
     * 按edit顺序依次判断
     * */
    public void save() {
        String temperature = et_body_temperature.getText().toString();
        String weight = et_body_weight.getText().toString();
        String heartRate = et_heart_rate.getText().toString();
        String systolic = et_systolic_pressure.getText().toString();
        String diastolic = et_diastolic_pressure.getText().toString();
        String more = et_more_check_result.getText().toString();


        if (!TextUtils.isEmpty(temperature)) {
            double dTemperature = UtilString.toDouble(temperature);
            long temperatureMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.TEMPERATURE, 0, 45);
            long temperatureMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.TEMPERATURE, 1, 1);

            if (dTemperature < temperatureMin || dTemperature > temperatureMax || !chk(temperature)) {
                shortToast("请输入真实体温");
                return;
            }
        }

        if (!TextUtils.isEmpty(weight)) {
            double dWeight = UtilString.toDouble(weight);
            long weightMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.WEIGHT, 0, 1000);
            long weightMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.WEIGHT, 1, 1);

            if (dWeight < weightMin || dWeight > weightMax || !chk(weight)) {
                shortToast("请输入真实体重");
                return;
            }
        }

        if (!TextUtils.isEmpty(heartRate)) {
            long iHeartRate = UtilString.toInt(heartRate);
            long heartRateMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.HEART_RATE, 0, 300);
            long heartRateMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.HEART_RATE, 1, 1);

            if (iHeartRate < heartRateMin || iHeartRate > heartRateMax || !chkOther(heartRate)) {
                shortToast("请输入真实心率");
                return;
            }
        }

        if (!TextUtils.isEmpty(systolic)) {
            long iSystolic = UtilString.toInt(systolic);
            long systolicMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.SYSTOLIC_PRESSURE, 0, 300);
            long systolicMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.SYSTOLIC_PRESSURE, 1, 1);

            if (iSystolic < systolicMin || iSystolic > systolicMax || !chkOther(systolic)) {
                shortToast("请输入真实收缩压");
                return;
            }
        }

        if (!TextUtils.isEmpty(diastolic)) {
            long iDiastolic = UtilString.toInt(diastolic);
            long diastolicMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.DIASTOLE_PRESSURE, 0, 300);
            long diastolicMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.DIASTOLE_PRESSURE, 1, 1);

            if (iDiastolic < diastolicMin || iDiastolic > diastolicMax || !chkOther(diastolic)) {
                shortToast("请输入真实舒张压");
                return;
            }
        }

        if (StringUtils.containsEmoji(more)) {
            shortToast("检查结果中不能包含表情");
            return;
        }

        shortToast("保存成功");
        if (mDrCaseVOBean == null) {
            mDrCaseVOBean = new DrCaseVOBean();
        }
        mDrCaseVOBean.setTemperature(temperature);
        mDrCaseVOBean.setWeight(weight);
        mDrCaseVOBean.setHeartRete(heartRate);
        mDrCaseVOBean.setSystolic(systolic);
        mDrCaseVOBean.setDiastole(diastolic);
        mDrCaseVOBean.setMoreExamin(more);

        Intent intent = new Intent();
        intent.putExtra(XD_EditMedicalRecordActivity.DR_CASE_VO_BEAN, mDrCaseVOBean);
        setResult(RESULT_OK, intent);
        myFinish();
    }

    /** 这则匹配填入数据的正确性 */
    private boolean  chk(String str) {
        String  patrn = "([1-9]|[1-9]\\d*\\.?\\d)|(0\\.\\d)";
        try{
            if(str.matches(patrn)){
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            return false;
        }

    }

    /** 这则匹配填入数据的正确性 */
    private boolean  chkOther(String str) {
        String  patrn = "0|([1-9]\\d*)";

        try{
            if(str.matches(patrn)){
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }


}
