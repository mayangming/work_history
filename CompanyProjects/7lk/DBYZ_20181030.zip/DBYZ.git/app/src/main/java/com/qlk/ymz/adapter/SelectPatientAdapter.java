package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.XD_BatchSelctPatientsActivity;
import com.qlk.ymz.model.CheckPatientBean;
import com.qlk.ymz.util.CommonConfig;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.qlk.ymz.R.id.iv_check;

/**
 * Created by xiedong on 2017/6/8.
 * 某个分组内患者适配器
 */

public class SelectPatientAdapter extends XCBaseAdapter<CheckPatientBean> {
    //选中的患者id集合
    private List<String> mCheckPatients = new ArrayList<>();
    //存储患者的勾选状态map
    private Map<String, Boolean> mCheckMap = new HashMap<>();

    public SelectPatientAdapter(Context context, List<CheckPatientBean> list,List<String>
            mCheckPatients,Map<String, Boolean> mCheckMap) {
        super(context, list);
        this.mCheckPatients = mCheckPatients;
        this.mCheckMap = mCheckMap;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView != null) {
            viewHolder = (ViewHolder) convertView.getTag();
        } else {
            convertView =  LayoutInflater.from(context).inflate(R.layout.xd_item_patient_group_child,
                    null);
            viewHolder = ViewHolder.getViewHolder(convertView);
        }

        //患者信息
        final CheckPatientBean checkPatientBean = list.get(position);
        //加载患者头像
        ImageAware imageAware = new ImageViewAware(viewHolder.iv_patient_head, false);
        String patientIcon = checkPatientBean.getPatientImgHead();
        if (!TextUtils.isEmpty(patientIcon) && URLUtil.isValidUrl(patientIcon)) {
            XCApplication.displayImage(patientIcon, viewHolder.iv_patient_head, XCImageLoaderHelper
                    .getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default));
        } else {
            XCApplication.base_imageloader.displayImage("drawable://" + R.mipmap.xc_d_chat_patient_default, imageAware, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_patient_default));
        }
        //判断是否已选
        if (mCheckMap.get(checkPatientBean.getPatientId()) == null || !mCheckMap.get(checkPatientBean
                .getPatientId())) {//未选
            viewHolder.iv_check.setBackgroundResource(R.mipmap.sx_d_register_no_sure);
        }else {//已选
            viewHolder.iv_check.setBackgroundResource(R.mipmap.sx_d_register_sure);
        }

        //设置患者名称
        viewHolder.tv_patient_name.setText(checkPatientBean.getPatientName());
        //设置患者性别
        if (CommonConfig.GENDER_MALE.equals(checkPatientBean.getPatientGender())) {
            viewHolder.iv_patient_gender.setBackgroundResource(R.mipmap.icon_patient_man);
            viewHolder.iv_patient_gender.setVisibility(View.VISIBLE);
        } else if (CommonConfig.GENDER_FEMALE.equals(checkPatientBean.getPatientGender())) {
            viewHolder.iv_patient_gender.setBackgroundResource(R.mipmap.icon_patient_women);
            viewHolder.iv_patient_gender.setVisibility(View.VISIBLE);
        } else {
            viewHolder.iv_patient_gender.setVisibility(View.GONE);
        }
        //设置患者年龄
        if (!TextUtils.isEmpty(checkPatientBean.getPatientAge())) {
            viewHolder.tv_patient_age.setText(checkPatientBean.getPatientAge() + "岁");
        } else {
            viewHolder.tv_patient_age.setText("");
        }

        //设置咨询费价格
        long price = UtilString.toLong(checkPatientBean.getPayAmount()) / 100;
        if (price > 0) {
            viewHolder.tv_consult_fee.setText("咨询费" + price+"元");
            viewHolder.tv_consult_fee.setVisibility(View.VISIBLE);
        } else {
            viewHolder.tv_consult_fee.setVisibility(View.GONE);
        }
        //分割线设置
        viewHolder.line.setVisibility(View.VISIBLE);
        if (position ==list.size() - 1) {
            viewHolder.line.setVisibility(View.GONE);

        }
        //条目点击监听
        viewHolder.rl_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCheckMap.get(checkPatientBean.getPatientId()) == null || !mCheckMap.get(checkPatientBean.getPatientId())) {//未选
                    mCheckPatients.add(checkPatientBean.getPatientId());//添加到选中集合
                    mCheckMap.put(checkPatientBean.getPatientId(), true);//更新选中记录
                }else {
                    mCheckPatients.remove(checkPatientBean.getPatientId());//从选中集合移除
                    mCheckMap.put(checkPatientBean.getPatientId(), false);//更新选中记录
                }
                //刷新ui
                notifyDataSetChanged();
                ((XD_BatchSelctPatientsActivity) context).updateBottomUI();
            }
        });
        return convertView;
    }


     static class ViewHolder {
        //选择的图标
        ImageView iv_check;
        //患者头像
        XCRoundedImageView iv_patient_head;
        //患者名称
        TextView tv_patient_name;
        //患者性别
        ImageView iv_patient_gender;
        //患者年龄
        TextView tv_patient_age;
        //咨询费
        TextView tv_consult_fee;
        //子布局条目
        RelativeLayout rl_item;
        //分割线
        View line;


        public ViewHolder(View convertView) {
            iv_check = (ImageView) convertView.findViewById(R.id.iv_check);
            tv_patient_name = (TextView) convertView.findViewById(R.id.tv_patient_name);
            iv_patient_head = (XCRoundedImageView) convertView.findViewById(R.id.iv_patient_head);
            iv_patient_gender = (ImageView) convertView.findViewById(R.id.iv_patient_gender);
            tv_patient_age = (TextView) convertView.findViewById(R.id.tv_patient_age);
            tv_consult_fee = (TextView) convertView.findViewById(R.id.tv_consult_fee);
            rl_item = (RelativeLayout) convertView.findViewById(R.id.rl_item);
            line = convertView.findViewById(R.id.line);
        }

        public static ViewHolder getViewHolder(View convertview) {
            ViewHolder holder = (ViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new ViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }

}
