package com.qlk.ymz.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.fragment.XD_CommonRecipeFragment;
import com.qlk.ymz.fragment.XD_PharmacyCommonMedicineFragment;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;

/**
 * Created by xiedong on 2017/12/11.
 * 药房首页
 */

public class XD_PharmacyActivity extends DBActivity {
    /**
     * 标题栏
     */
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**
     * 搜索
     */
    private LinearLayout ll_search;
    /**
     * 常用药tab
     */
    private RelativeLayout rl_common_medicine;
    /**
     * 常用处方tab
     */
    private RelativeLayout rl_common_recipe;

    /**
     * 常用药
     */
    private TextView tv_common_medicine;
    /**
     * 常用处方
     */
    private TextView tv_common_recipe;
    /**
     * 常用药指示
     */
    private View v_common_medicine_indicate;
    /**
     * 常用处方指示
     */
    private View v_common_recipe_indicate;
    /**
     * 全科用药
     */
    private RelativeLayout rl_general_medicine;
    /**
     * 正在展示的fragment标识
     */
    private int mCurrentPageNum = 1;// 1 2

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_pharmacy);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_PharmacyActivity.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */


    @Override
    protected void onRestart() {
        super.onRestart();
        if (RecomMedicineHelper.getInstance().isUpdateCommonRecipe()) {//需要刷新常用处方列表
            XD_CommonRecipeFragment fragment = getFragmentByTag(XD_CommonRecipeFragment.class.getSimpleName());
            if (fragment != null) {
                fragment.refresData();  //刷新常用处方列表
            }
        }
        XD_PharmacyCommonMedicineFragment pharmacyCommonMedicineFragment = getFragmentByTag(XD_PharmacyCommonMedicineFragment.class.getSimpleName());
        if(pharmacyCommonMedicineFragment!=null){
            //刷新常用药列表
            if(RecomMedicineHelper.getInstance().isUpdateCommonMedicine()){
                pharmacyCommonMedicineFragment.refresData();
            }else {
                pharmacyCommonMedicineFragment.updateUI();//只更新价格
            }
        }

    }

    private void initData() {
        showFragmentByClass(XD_PharmacyCommonMedicineFragment.class, R.id.xc_id_model_content);
        switchTabUI(1);
        mCurrentPageNum = 1;
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "我的药房");
        xc_id_model_titlebar.setTitleLeft(true, "");
        xc_id_model_titlebar.setTitleRight2(true, 0, "用药记录");
        xc_id_model_titlebar.findViewById(R.id.line).setVisibility(View.GONE);
        ll_search = getViewById(R.id.ll_search);
        rl_common_medicine = getViewById(R.id.rl_common_medicine);
        rl_common_recipe = getViewById(R.id.rl_common_recipe);
        rl_general_medicine = getViewById(R.id.rl_general_medicine);
        tv_common_medicine = getViewById(R.id.tv_common_medicine);
        tv_common_recipe = getViewById(R.id.tv_common_recipe);
        v_common_medicine_indicate = getViewById(R.id.v_common_medicine_indicate);
        v_common_recipe_indicate = getViewById(R.id.v_common_recipe_indicate);
    }

    @Override
    public void listeners() {
        xc_id_model_titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });
        xc_id_model_titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 用药记录
                UtilNativeHtml5.toJumpNativeH5(XD_PharmacyActivity.this, UtilNativeHtml5.NATIVE_MEDICATION_RECORD);
            }
        });
        ll_search.setOnClickListener(this);
        rl_common_medicine.setOnClickListener(this);
        rl_common_recipe.setOnClickListener(this);
        rl_general_medicine.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_search:
                // 搜索
                ToJumpHelp.toJumpMedicineSearchActivity(this,CommonConfig.ALL_MEDICINE_FLAG_0,"");
                break;
            case R.id.rl_common_medicine:
                if(mCurrentPageNum!=1){
                    switchTab(XD_PharmacyCommonMedicineFragment.class,1);
                }
                // created by songxin,date：2018-01-09,about：saveInfo,begin
                BiUtil.saveBiInfo(XD_PharmacyActivity.class, "2", "128", "E00101","", false);
                // created by songxin,date：2018-01-09,about：saveInfo,end
                break;
            case R.id.rl_common_recipe:
                if(mCurrentPageNum!=2){
                    switchTab(XD_CommonRecipeFragment.class,2);
                }
                // created by songxin,date：2018-01-09,about：saveInfo,begin
                BiUtil.saveBiInfo(XD_PharmacyActivity.class, "2", "128", "E00102","", false);
                // created by songxin,date：2018-01-09,about：saveInfo,end
                break;
            case R.id.rl_general_medicine:
                // 全科药品
                ToJumpHelp.toJumpAllMedicineClassActivity(this, CommonConfig.ALL_MEDICINE_FLAG_0);
                break;
        }
        super.onClick(v);
    }

    /**
     * 切换tab
     * @param mClass
     * @param switchPageNum
     */
    private void switchTab(Class mClass, int switchPageNum) {
        Fragment mCurrentFragment = null;
        switch (mCurrentPageNum) {
            case 1:
                mCurrentFragment = getFragmentByTag(XD_PharmacyCommonMedicineFragment.class.getSimpleName());
                break;
            case 2:
                mCurrentFragment = getFragmentByTag(XD_CommonRecipeFragment.class.getSimpleName());
                break;
        }
        hideFragment(mCurrentFragment);//隐藏当前显示fragment
        showFragmentByClass(mClass,R.id.xc_id_model_content);//显示要展示fragment
        switchTabUI(switchPageNum);
        mCurrentPageNum = switchPageNum;
    }

    /**
     * 切换tab的ui
     * @param switchPageNum
     */
    private void switchTabUI(int switchPageNum) {
        if (mCurrentPageNum == 1){
            tv_common_medicine.setTextColor(getResources().getColor(R.color.c_7b7b7b));
            v_common_medicine_indicate.setVisibility(View.GONE);
        }else if(mCurrentPageNum == 2){
            tv_common_recipe.setTextColor(getResources().getColor(R.color.c_7b7b7b));
            v_common_recipe_indicate.setVisibility(View.GONE);
        }
        switch (switchPageNum){
            case 1:
                tv_common_medicine.setTextColor(getResources().getColor(R.color.c_f84b62));
                v_common_medicine_indicate.setVisibility(View.VISIBLE);
                break;
            case 2:
                tv_common_recipe.setTextColor(getResources().getColor(R.color.c_f84b62));
                v_common_recipe_indicate.setVisibility(View.VISIBLE);
                break;
        }
    }

}
