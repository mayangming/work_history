package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.YR_MedicalRecordAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCClearEditText;

import org.apache.http.Header;

import java.util.List;

/**
 * 用药记录搜索页
 *
 * @author 崔毅然
 * @version 2.2
 */
public class YR_MedicationRecordSearchActivity extends DBActivity {

    /** 用药记录list */
    private XCListViewFragment listViewFragment;
    /** 用药记录adapter */
    private YR_MedicalRecordAdapter medicalRecordAdapter;
    /** 搜索关键字 */
    private XCClearEditText sk_id_search_edit;

    /** 搜索关键字 */
    private String keyStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yr_activity_medicationrecord_search);
        super.onCreate(savedInstanceState);

    }

    @Override
    public void initWidgets() {
        sk_id_search_edit = (XCClearEditText) findViewById(R.id.sk_id_search_edit);
        sk_id_search_edit.setHint("输入姓名搜索");
        sk_id_search_edit.setHintTextColor(getResources().getColor(R.color.c_gray_bbbbbb));
        findViewById(R.id.xc_id_titlebar_right2_textview).setOnClickListener(this);

//      用药记录列表设置
        medicalRecordAdapter = new YR_MedicalRecordAdapter(this,null);
        listViewFragment = new XCListViewFragment();
        listViewFragment.setAdapter(medicalRecordAdapter);
        listViewFragment.setMode(XCListViewFragment.MODE_UP);//设置不能下拉
        listViewFragment.setBgZeroHintInfo("无搜索结果!", "", R.mipmap.js_d_icon_no_data);//无数据遮罩
        listViewFragment.setListViewStyleParam(null, 20, false);
        addFragment(R.id.xc_d_rl_medical_record, listViewFragment);
    }

    @Override
    public void listeners() {
        listViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                // 跳转到用药详情页（只传递用药单号id）
                XCJsonBean xcJsonBean = (XCJsonBean) (arg0.getItemAtPosition(arg2));
                Intent intent = new Intent();
                intent.setClass(YR_MedicationRecordSearchActivity.this, PF_MedicationDetailActivity.class);
                intent.putExtra(YR_MedicationRecordActivity.ORDERID, xcJsonBean.getString("id"));
                myStartActivity(intent);
            }
        });

        //点击软件盘搜索按钮显示搜索结果列表
        sk_id_search_edit.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    listViewFragment.reset();
                    requestMedicalRecordList(keyStr = sk_id_search_edit.getText().toString().trim(),1);
                    return true;
                }
                return false;
            }
        });


        listViewFragment.setOnRefreshNextPageListener(new XCBaseAbsListFragment.OnRefreshNextPageListener() {
            @Override
            public void onRefreshNextPageListener(int current_page) {
                if (current_page == 1) {
                    listViewFragment.base_refresh_abs_listview.setMode(PullToRefreshBase.Mode.BOTH);
                }
                requestMedicalRecordList(keyStr,current_page);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        listViewFragment.base_abs_listview.setOverScrollMode(View.OVER_SCROLL_NEVER);//去掉listView拉动时的边框
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(YR_MedicationRecordSearchActivity.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    @Override
    public void onNetRefresh() {
        listViewFragment.reset();
        requestMedicalRecordList(keyStr,1);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.xc_id_titlebar_right2_textview:
                myFinish();
                break;
        }
    }

    /** 请求用药记录列表 */
    public void  requestMedicalRecordList(String key,int page){
        if (UtilString.isBlank(key)) {
            shortToast("搜索关键字不能为空");
            return;
        }
        RequestParams params = new RequestParams();
        params.put("page", page);
        params.put("num", YR_MedicationRecordActivity.PAGE_NUM);
        params.put("key",key);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.medicationRecomSearch), params, new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if(!listViewFragment.checkGoOn()){
                        listViewFragment.base_refresh_abs_listview.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
                        return;
                    }
                    List<XCJsonBean> result_list = result_bean.getList("data");
                    if (result_list != null && result_list.size() > 0 && result_list.get(0) != null) {//更新listView数据
                        List<XCJsonBean> medicationList = result_list.get(0).getList("result");
                        listViewFragment.updateList(medicationList);
                        listViewFragment.setTotalPage(result_list.get(0).getString("totalPages"));

                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if(listViewFragment != null){
                    listViewFragment.doRefreshComplete();
                }
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YR_MedicationRecordSearchActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });

    }
}
