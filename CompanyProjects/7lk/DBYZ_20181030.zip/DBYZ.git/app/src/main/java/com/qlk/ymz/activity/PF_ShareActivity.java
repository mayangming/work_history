package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.BuildConfig;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.PF_ShareInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ShareToast;
import com.qlk.ymz.util.UtilShare;
import com.qlk.ymz.util.bi.BiUtil;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilSystem;

import org.apache.http.Header;

import java.util.HashMap;
import java.util.Map;

/**
 * 分享对话框
 * @author zhangpengfei.
 * @version 1.0
 *
 * update by 崔毅然 on 2016/7/26  因项目过大，去掉shareSDK,改用原生的SDK
 */
public class PF_ShareActivity extends DBActivity {
    /**占位布局*/
    private View pf_id_empty;
    /**分享布局*/
    private LinearLayout pf_id_share_ll;
    /**取消*/
    private TextView sk_id_share_cancel_tv;
    /**微信*/
    private LinearLayout pf_id_share_wx_ll;
    /**朋友圈*/
    private LinearLayout pf_id_share_wx_friends_ll;
    /**QQ*/
    private LinearLayout pf_id_share_qq_ll;
    /**保存宣教*/
    private LinearLayout pf_id_share_publicity_ll;
    /** 分享内容的model */
    private PF_ShareInfo info = new PF_ShareInfo();
    private UtilShare utilShare;
    public QQListener qqListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_activity_share);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_ShareActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    /**
     * 启动页面
     * @param context 上下文对象
     * @param info 分享数据
     */
    public static void launch(Activity context, PF_ShareInfo info) {
        Intent intent = new Intent(context, PF_ShareActivity.class);
        intent.putExtra("info",info);
        context.startActivity(intent);
//        context.overridePendingTransition(R.anim.xc_anim_pop_enter, 0);
    }

    /**
     * 初始化数据
     */
    private void initData(){
        Intent intent = getIntent();
        if (null != intent){
            info = (PF_ShareInfo) intent.getSerializableExtra("info");
        }
        if (info == null){
            info = new PF_ShareInfo();
        }
        qqListener = new QQListener();
        utilShare = new UtilShare(this, info, qqListener);
        Boolean wxIsInstall = UtilSystem.checkAppInstall(this, UtilSystem.WEIXIN_PACKAGE_NAME);
        Boolean qqIsInstall = UtilSystem.checkAppInstall(this, UtilSystem.MOBILEQQ_PACKAGE_NAME);
        IWXAPI wxApi = WXAPIFactory.createWXAPI(this, BuildConfig.wxKey);
        if (!UtilString.isBlank(info.getShareType())){
            pf_id_share_ll.setVisibility(View.GONE);
            if (!wxIsInstall && !wxApi.isWXAppInstalled()){
                Toast.makeText(PF_ShareActivity.this,"你好像还没装微信",Toast.LENGTH_SHORT).show();
                finish();
            }else if("1".equals(info.getShareType())){
                //微信分享
                pf_id_share_wx_ll.performClick();
            }else if("2".equals(info.getShareType())){

                //朋友圈分享
                pf_id_share_wx_friends_ll.performClick();
            }
            return;
        }
        if ("1".equals(info.getIsShowSavePublicity()) && UtilSP.isLogin()){
            pf_id_share_publicity_ll.setVisibility(View.VISIBLE);
        }else{
            pf_id_share_publicity_ll.setVisibility(View.GONE);
        }
        if (!wxIsInstall && !qqIsInstall && pf_id_share_publicity_ll.getVisibility() == View.GONE){
            finish();
            return;
        }
        if (!wxIsInstall){
            //隐藏微信和朋友圈选项
            pf_id_share_wx_ll.setVisibility(View.GONE);
            pf_id_share_wx_friends_ll.setVisibility(View.GONE);
        }
        if (!qqIsInstall){
            pf_id_share_qq_ll.setVisibility(View.GONE);
        }
    }
    @Override
    public void initWidgets() {
        pf_id_share_ll = getViewById(R.id.pf_id_share_ll);
        pf_id_empty = getViewById(R.id.pf_id_empty);
        sk_id_share_cancel_tv = getViewById(R.id.sk_id_share_cancel_tv);
        pf_id_share_wx_ll = getViewById(R.id.pf_id_share_wx_ll);
        pf_id_share_wx_friends_ll = getViewById(R.id.pf_id_share_wx_friends_ll);
        pf_id_share_qq_ll = getViewById(R.id.pf_id_share_qq_ll);
        pf_id_share_publicity_ll = getViewById(R.id.pf_id_share_publicity_ll);
    }

    @Override
    public void listeners() {
        pf_id_empty.setOnClickListener(this);
        sk_id_share_cancel_tv.setOnClickListener(this);
        pf_id_share_wx_ll.setOnClickListener(this);
        pf_id_share_wx_friends_ll.setOnClickListener(this);
        pf_id_share_qq_ll.setOnClickListener(this);
        pf_id_share_publicity_ll.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
        Map<String,String> track = new HashMap<>();
        String currentTitle;
        //add by songxin,date：2018-3-29,about：GrowingIO banner track,end
        switch (v.getId()){
            //空白处
            case R.id.pf_id_empty:
                onBackPressed();
                break;
            //取消
            case R.id.sk_id_share_cancel_tv:
                onBackPressed();
                break;
            //微信
            case R.id.pf_id_share_wx_ll:
                // created by songxin,date：2017-12-07,about：saveInfo,begin
                BiUtil.saveBiInfo(JS_WebViewActivity.class, "2", "128", "E00087","", false);
                // created by songxin,date：2017-12-07,about：saveInfo,end

                //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
                track.clear();
                if(!UtilString.isBlank(info.getTitle())){
                    currentTitle = info.getTitle();
                }else {
                    currentTitle = "石榴云医";
                }
                track.put("contentTitle", currentTitle);
                track.put("shareType", "微信");
                GrowingIOUtil.track("pageShare", track);
                //add by songxin,date：2018-3-29,about：GrowingIO banner track,end

                pf_id_share_ll.setVisibility(View.GONE);
                utilShare.showShare(UtilShare.WEIXIN);
                finish();
                break;
            //朋友圈
            case R.id.pf_id_share_wx_friends_ll:
                // created by songxin,date：2017-12-07,about：saveInfo,begin
                BiUtil.saveBiInfo(JS_WebViewActivity.class, "2", "128", "E00088","", false);
                // created by songxin,date：2017-12-07,about：saveInfo,end

                //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
                track.clear();
                if(!UtilString.isBlank(info.getTitle())){
                    currentTitle = info.getTitle();
                }else {
                    currentTitle = "石榴云医";
                }
                track.put("contentTitle", currentTitle);
                track.put("shareType", "朋友圈");
                GrowingIOUtil.track("pageShare", track);
                //add by songxin,date：2018-3-29,about：GrowingIO banner track,end

                pf_id_share_ll.setVisibility(View.GONE);
                utilShare.showShare(UtilShare.PYQ);
                finish();
                break;
            //QQ
            case R.id.pf_id_share_qq_ll:
                // created by songxin,date：2017-12-07,about：saveInfo,begin
                BiUtil.saveBiInfo(JS_WebViewActivity.class, "2", "128", "E00086","", false);
                // created by songxin,date：2017-12-07,about：saveInfo,end

                //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
                track.clear();
                if(!UtilString.isBlank(info.getTitle())){
                    currentTitle = info.getTitle();
                }else {
                    currentTitle = "石榴云医";
                }
                track.put("contentTitle", currentTitle);
                track.put("shareType", "QQ");
                GrowingIOUtil.track("pageShare", track);
                //add by songxin,date：2018-3-29,about：GrowingIO banner track,end

                pf_id_share_ll.setVisibility(View.GONE);
                utilShare.showShare(UtilShare.QQ);
                break;
            //保存宣教
            case R.id.pf_id_share_publicity_ll:
                // created by songxin,date：2017-12-07,about：saveInfo,begin
                BiUtil.saveBiInfo(JS_WebViewActivity.class, "2", "128", "E00089","", false);
                // created by songxin,date：2017-12-07,about：saveInfo,end
                pf_id_share_ll.setVisibility(View.GONE);
                requestSavePublicity();
                break;
        }
    }

    /**
     * 请求保存宣教接口
     *
     */
    public void requestSavePublicity() {
        RequestParams params = new RequestParams();
        params.put("eduTitle", info.getTitle());
//        params.put("eduOrigin", info.getEduOrigin());
        params.put("eduUrl", info.getSpreadUrl());
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.savePublicitye), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    ShareToast.showToast(PF_ShareActivity.this,"保存成功", R.mipmap.share_success);
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (getCode().equals("-1") || getCode().equals("100")){
                    ShareToast.showToast(PF_ShareActivity.this,"保存失败", R.mipmap.share_fail);
                }else if (getCode().equals("31231")){
                    ShareToast.showToast(PF_ShareActivity.this,"宣教已存在", R.mipmap.share_exist);
                }else if (GeneralReqExceptionProcess.checkCode(PF_ShareActivity.this,
                        getCode(),
                        getMsg())) ;
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(0, R.anim.xc_anim_alpha);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // 官方文档没这句代码, 但是很很很重要, 不然不会回调!
        Tencent.onActivityResultData(requestCode, resultCode, data, qqListener);
    }

    public class QQListener implements IUiListener {

        @Override
        public void onCancel() {
            ShareToast.showToast(PF_ShareActivity.this,"分享失败", R.mipmap.share_fail);
            finish();
        }

        @Override
        public void onComplete(Object arg0) {
            ShareToast.showToast(PF_ShareActivity.this,"分享成功", R.mipmap.share_success);
            finish();
        }

        @Override
        public void onError(UiError arg0) {
            ShareToast.showToast(PF_ShareActivity.this,"分享失败", R.mipmap.share_fail);
            finish();
        }
    }

}
