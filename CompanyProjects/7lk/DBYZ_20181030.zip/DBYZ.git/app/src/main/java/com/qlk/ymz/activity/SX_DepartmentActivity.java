package com.qlk.ymz.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_LeftDepartmentAdapter;
import com.qlk.ymz.adapter.SX_RightDepartmentAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.YY_DoctorlInfoBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by songxin on 2015/6/18.
 *
 * SX_DepartmentActivity
 * 科室页面
 * @author  Changed by songxin on 2016/3/29.
 * @version 2.3
 */
public class SX_DepartmentActivity extends DBActivity {
    /** Title*/
    private XCTitleCommonLayout titlebar;
    /** intent*/
    private Intent mIntent;
    /** flag*/
    private int mIntentFlags;
    /** 左边数据，右边数据*/
    private List<XCJsonBean> xcJsonBeans,xcRightJsonBean;
    /** 科室临时变量*/
    private String mCurrentDepartment;
    /** 科室id临时变量*/
    private String mCurrentDepartmentId;
    /** 左边adapter*/
    private SX_LeftDepartmentAdapter mSX_LeftDepartmentAdapter;
    /** 右边adapter*/
    private SX_RightDepartmentAdapter mSX_RightDepartmentAdapter;
    /** 左边list*/
    private ListView sx_id_left_list;
    /** 右边list*/
    private ListView sx_id_right_list;
    /** 其他外框*/
    private RelativeLayout sx_id_item_department_other_rl;
    /** dialog*/
    private ConfirmDialog mOtherDialog;
    /** 下方其他输入框rl*/
    private RelativeLayout sx_id_department_other_rl;
    /** 下方输入框*/
    private EditText sx_id_department_other_edit;
    /** 确定按钮*/
    private TextView sx_id_confirm_text;
//    /** 去认证对dialog*/
//    private YR_CommonDialog mToCheckDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_department);
        super.onCreate(savedInstanceState);
        mIntent = new Intent();
        mIntentFlags = getIntent().getFlags();
        mCurrentDepartment = "";
        printi("songxin","mIntentFlags======>"+mIntentFlags);
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleCenter(true, "选择科室");
        titlebar.setTitleRight2(true, 0, "确定");
        //获取科室
        getDepartmentList();
        //title右侧按钮事件
        titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(mCurrentDepartmentId)) {
                    shortToast("请选择具体科室");
                    return;
                }
//                if(UtilString.isBlank(mCurrentDepartmentId) || UtilString.isBlank(mCurrentDepartment)){
//                    showCheckingDialog("请选择完整的科室");
//                    return;
//                }
                YY_DoctorlInfoBean.DataEntity currentData = new YY_DoctorlInfoBean.DataEntity();
                currentData.setDepartmentId(mCurrentDepartmentId);
                currentData.setDepartment(mCurrentDepartment);
                mIntent.putExtra("DEPARTMENT", currentData);
                SX_DepartmentActivity.this.setResult(4, mIntent);
                SX_DepartmentActivity.this.myFinish();
            }
        });
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_DepartmentActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        sx_id_left_list = getViewById(R.id.sx_id_left_list);
        View otherFoot = LayoutInflater.from(this).inflate(R.layout.sx_l_adapter_department_item_other,null);
        sx_id_left_list.addFooterView(otherFoot);
        sx_id_item_department_other_rl = (RelativeLayout)otherFoot.findViewById(R.id.sx_id_item_department_other_rl);
        sx_id_right_list = getViewById(R.id.sx_id_right_list);
        int srceenW =  this.getWindowManager().getDefaultDisplay().getWidth();
        int srceenH =  this.getWindowManager().getDefaultDisplay().getHeight();
        mOtherDialog = new ConfirmDialog(SX_DepartmentActivity.this, srceenW,55
                ,R.layout.sx_l_dialog_department_item_other,R.style.xc_s_dialog);
        mOtherDialog.setCanceledOnTouchOutside(true);
        Window window = mOtherDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        sx_id_department_other_rl = (RelativeLayout)mOtherDialog.findViewById(R.id.sx_id_department_other_rl);
        sx_id_department_other_edit = (EditText)mOtherDialog.findViewById(R.id.sx_id_department_other_edit);
        sx_id_confirm_text =(TextView)mOtherDialog.findViewById(R.id.sx_id_confirm_text);
    }

    @Override
    public void listeners() {
        //左侧list点击事件
        sx_id_left_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                for (int i = 0; i < xcJsonBeans.size(); i++) {
                    if (i == position) {
                        xcJsonBeans.get(i).setBoolean("isChoose", true);
                    } else {
                        xcJsonBeans.get(i).setBoolean("isChoose", false);
                    }
                }
//                mCurrentDepartment = ((XCJsonBean)parent.getAdapter().getItem(position)).getString("departName");
//                mCurrentDepartmentId = ((XCJsonBean)parent.getAdapter().getItem(position)).getString("departId");
                mSX_LeftDepartmentAdapter.notifyDataSetChanged();
                //二级列表
                if(null != xcRightJsonBean){
                    xcRightJsonBean.clear();
                }
                xcRightJsonBean.addAll(((XCJsonBean)parent.getItemAtPosition(position)).getList("secondDepart"));
                if (null != xcRightJsonBean && xcRightJsonBean.size() > 0) {
                    for (XCJsonBean x : xcRightJsonBean) {
                        x.setBoolean("isChoose", false);
                    }
                }
                if (null != mSX_RightDepartmentAdapter) {
                    mSX_RightDepartmentAdapter.notifyDataSetChanged();
                }
            }
        });
        //右侧list点击事件
        sx_id_right_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                for (int i = 0; i < xcRightJsonBean.size(); i++) {
                    if (i == position) {
                        xcRightJsonBean.get(i).setBoolean("isChoose", true);
                    } else {
                        xcRightJsonBean.get(i).setBoolean("isChoose", false);
                    }
                }
                mCurrentDepartment = ((XCJsonBean)parent.getAdapter().getItem(position)).getString("departName");
                mCurrentDepartmentId = ((XCJsonBean)parent.getAdapter().getItem(position)).getString("departId");
                mSX_RightDepartmentAdapter.notifyDataSetChanged();
            }
        });
        //list其他点击事件
        sx_id_item_department_other_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mOtherDialog.show();

                sx_id_department_other_edit.setFocusableInTouchMode(true);
                sx_id_department_other_edit.requestFocus();
                UtilInputMethod.openInputMethod(sx_id_department_other_edit, SX_DepartmentActivity.this);
            }
        });
        //dialog消失事件监听
        mOtherDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).
                        hideSoftInputFromWindow(SX_DepartmentActivity.this.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

            }
        });


        sx_id_confirm_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentDepartment = sx_id_department_other_edit.getText().toString().trim();
                int maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.CUSTOMDEPARTMENT,0,19);
                int minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.CUSTOMDEPARTMENT,1,1);
                if(mCurrentDepartment.length() < minLength || mCurrentDepartment.length() > maxLength){
                    shortToast("您输入的内容不符合条件，请重新输入");
                    return;
                }
                mCurrentDepartmentId = "0";
                YY_DoctorlInfoBean.DataEntity currentData = new YY_DoctorlInfoBean.DataEntity();
                currentData.setDepartmentId(mCurrentDepartmentId);
                currentData.setCustomDepartmentName(mCurrentDepartment);
                mIntent.putExtra("DEPARTMENT", currentData);
                SX_DepartmentActivity.this.setResult(4, mIntent);
                SX_DepartmentActivity.this.myFinish();
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }


    /**
     * 获取科室
     */
    private void getDepartmentList() {
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.doctorInfo_departmentAndTitle), new RequestParams(), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    xcJsonBeans = result_bean.getList("data").get(0).getList("departmentList");
                    String intentData = getIntent().getStringExtra("DEPARTMENT");
                    for (XCJsonBean x : xcJsonBeans) {
                        x.setBoolean("isChoose", false);
                    }
                    mSX_LeftDepartmentAdapter = new SX_LeftDepartmentAdapter(SX_DepartmentActivity.this, xcJsonBeans);
                    sx_id_left_list.setAdapter(mSX_LeftDepartmentAdapter);
                    if (xcJsonBeans.size() > 0) {
                        xcRightJsonBean = new ArrayList<>();
                        mSX_RightDepartmentAdapter = new SX_RightDepartmentAdapter(SX_DepartmentActivity.this, xcRightJsonBean);
                        sx_id_right_list.setAdapter(mSX_RightDepartmentAdapter);
                    }

                }
            }
        });
    }

//    /**
//     * 显示认证中对话框
//     *
//     * @param hint message中显示文字
//     */
//    private void showCheckingDialog(String hint) {
//        mToCheckDialog = new YR_CommonDialog(SX_DepartmentActivity.this, hint, "", "我知道了") {
//            @Override
//            public void confirmBtn() {
//                mToCheckDialog.dismiss();
//            }
//        };
//        mToCheckDialog.show();
//    }



    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mOtherDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }
}
