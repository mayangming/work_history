package com.qlk.ymz.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;

import java.util.List;

/**
 * Recycler列表适配器
 */
public class ListDialogRecyclerAdapter extends RecyclerView.Adapter<ListDialogRecyclerAdapter.ListDialogViewHolder> {
    List<String> list;
    OnItemClickListener onItemClickListener;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public ListDialogViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ListDialogViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.sk_item_list_dialog, parent, false));
    }

    @Override
    public void onBindViewHolder(ListDialogViewHolder holder, int position) {

        // if (position == 0) {
        //     holder.sk_id_listdialog_centent_tv.getPaint().setFakeBoldText(true);
        // } else {
        //     holder.sk_id_listdialog_centent_tv.getPaint().setFakeBoldText(false);
        // }

        holder.sk_id_listdialog_centent_tv.setTag(list.get(position));
        holder.sk_id_listdialog_centent_tv.setText("" + list.get(position));

    }

    public void updateAndNotify(List<String> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if (list != null) return list.size();
        return 0;
    }

    public interface OnItemClickListener {
        void onItemClick(View view);
    }

    class ListDialogViewHolder extends RecyclerView.ViewHolder {
        public TextView sk_id_listdialog_centent_tv;

        public ListDialogViewHolder(View itemView) {
            super(itemView);
            sk_id_listdialog_centent_tv = (TextView) itemView.findViewById(R.id.sk_id_listdialog_centent_tv);
            sk_id_listdialog_centent_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (onItemClickListener != null) onItemClickListener.onItemClick(view);
                }
            });
        }
    }
}