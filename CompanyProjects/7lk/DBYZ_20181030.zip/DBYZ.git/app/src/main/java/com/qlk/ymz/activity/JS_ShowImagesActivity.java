package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;

import com.qlk.ymz.R;
import com.qlk.ymz.adapter.ShowImagePagerAdapter;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;

import java.util.ArrayList;

/**
 * @description 显示大图页
 * @author 徐金山
 * @version 1.2.0
 */
public class JS_ShowImagesActivity extends Activity {
    // ============适配数据============
    /** 图片URL列表 */
    private ArrayList<String> imageList = new ArrayList<String>();
    /** 起始显示的图片下标值（默认值：0） */
    private int index = 0;

    // ============页面控件============
    /** 显示图片的ViewPater容器 */
    private ViewPager vp_showImages;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.js_activity_show_images);

        initData();
        findViews();
        processBiz();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(JS_ShowImagesActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    /**
     * 获取初始化数据
     */
    private void initData() {
        Intent intent = getIntent();
        imageList = (ArrayList<String>) intent.getSerializableExtra("imageUrlList");
        index = intent.getIntExtra("index", 1);
    }

    /**
     * 获取控件对象
     */
    private void findViews() {
        vp_showImages = (ViewPager) findViewById(R.id.vp_showImages);
    }

    /**
     * 业务处理
     */
    private void processBiz() {
        ArrayList<View> views = new ArrayList<View>();
        LayoutInflater inflater = LayoutInflater.from(this);

        for(int i = 0; i < imageList.size() ; i++){
            View view = inflater.inflate(R.layout.js_item_show_image, null);
            ImageView pv_showImage = (ImageView) view.findViewById(R.id.pv_showImage);
            XCApplication.base_imageloader.displayImage(imageList.get(i), pv_showImage);

//            pv_showImage.setOnClickListener(new View.OnClickListener() {
//                public void onClick(View v) {
//                    finish();
//                }
//            });

            views.add(view);
        }

        //填充ViewPager的数据适配器
        PagerAdapter showImagePagerAdapter = new ShowImagePagerAdapter(views);
        vp_showImages.setAdapter(showImagePagerAdapter);
        vp_showImages.setCurrentItem(index);
    }
}

