package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.parse.Parse2PublictyTabBean;

import java.util.ArrayList;

/**
 * @author 李涛
 * @description
 * @Date 2018/3/21.
 */


public class LT_PubTabGridAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Parse2PublictyTabBean> list;

    public LT_PubTabGridAdapter(Context context, ArrayList<Parse2PublictyTabBean> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size() > 0 ? list.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if(convertView == null){
            holder = new Holder();
            convertView = LayoutInflater.from(context).inflate(R.layout.lt_item_pubtabgridview,null,false);
            holder.lt_item_pubtab_text = (TextView) convertView.findViewById(R.id.lt_item_pubtab_text);
            convertView.setTag(holder);
        }else{
            holder = (Holder) convertView.getTag();
        }

        holder.lt_item_pubtab_text.setText(list.get(position).getLabel());
        return convertView;
    }

    class  Holder{
        TextView lt_item_pubtab_text;
    }
}
