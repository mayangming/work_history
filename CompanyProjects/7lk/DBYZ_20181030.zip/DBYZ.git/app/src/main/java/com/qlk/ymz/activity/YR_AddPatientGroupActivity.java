package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

/**
 * 新建患者分组页
 *
 * @author 崔毅然
 * @version 2.0
 */
public class YR_AddPatientGroupActivity extends DBActivity {
    /** 分组名称 */
    private EditText et_group_name;
    /** title左侧返回按钮 */
    private ImageView sx_id_title_left;
    /** title右侧保存按钮 */
    private TextView sx_id_title_right_btn;
    /** 分组名最大长度 */
    int maxLength = 0;
    /** 保存添加分组内容对话框 */
    public YR_CommonDialog mGroupDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yr_activity_addgroup);
        super.onCreate(savedInstanceState);

        initTitle();
        delayOpen();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_AddPatientGroupActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    /** 初始化title */
    public void initTitle() {
        sx_id_title_left = (ImageView) findViewById(R.id.sx_id_title_left);
        sx_id_title_left.setImageResource(R.mipmap.sk_d_medicine_cencel);
        sx_id_title_left.setOnClickListener(this);
        findViewById(R.id.sx_id_title_right).setVisibility(View.GONE);
        sx_id_title_right_btn = (TextView) findViewById(R.id.sx_id_title_right_btn);
        sx_id_title_right_btn.setVisibility(View.VISIBLE);
        sx_id_title_right_btn.setText("保存");
        sx_id_title_right_btn.setOnClickListener(this);
        ((TextView)findViewById(R.id.sx_id_title_center)).setText("添加分组");
    }

    @Override
    public void initWidgets() {
        maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_GROUP_NAME, 0, 19);
        et_group_name = (EditText) findViewById(R.id.et_group_name);
        et_group_name.setSelection(et_group_name.getText().toString().length());
        et_group_name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        initGroupDiaolog();
    }

    @Override
    public void listeners() {
    }

    @Override
    public void onNetRefresh() {
    }

    /** 请求添加分组 */
    public void requestPatientGroupAdd(String name) {
        if (!isLetterDigitOrChinese(name)) {
            shortToast("请勿输入特殊字符");
            return;
        }
        RequestParams params = new RequestParams();
        params.put("name", name);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.patient_group_add), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    setResult(RESULT_OK);
                    myFinish();
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YR_AddPatientGroupActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }

        });
    }

    /** 文字匹配，特殊字符检验 */
    public boolean isLetterDigitOrChinese(String str) {
        String regex = "^[a-z0-9A-Z\u4e00-\u9fa5]+$";
        return str.matches(regex);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.sx_id_title_right_btn:
                String nameStr = et_group_name.getText().toString().trim();
                int minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_GROUP_NAME, 1, 1);
                if (minLength > 0 && TextUtils.isEmpty(nameStr)) {
                    shortToast("分组名字不能为空");
                    return;
                }
                if (nameStr.length() < minLength) {
                    shortToast("分组名称的长度范围：" + minLength + "~" + maxLength);
                    return;
                }
                requestPatientGroupAdd(nameStr);
                break;
            case R.id.sx_id_title_left:
                //create by wangyong, 判断是否显示保存添加分组内容的对话框 start
                String groupname = et_group_name.getText().toString().trim();
                if(!TextUtils.isEmpty(groupname)){
                    mGroupDialog.show();
                    return;
                }
                //create by wangyong ,判断是否显示保存添加分组内容的对话框 end
                delayClose();
                break;
        }
    }

    @Override
    public void finish() {
        super.finish();
//      关闭页面动画
        overridePendingTransition(R.anim.activity_no_move, R.anim.activity_close_down);
    }

    /** 延迟弹出软键盘 */
    public void delayOpen(){
        getWindow().getDecorView().postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(et_group_name, 0);
            }
        }, 300);
    }

    /** 延迟关闭页面，先关闭键盘，防止返回的页面出现抖动 */
    public void delayClose(){
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(et_group_name.getWindowToken(), 0);
        getWindow().getDecorView().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        },100);
    }

    /**
     * 是否保存分组名称对话框
     */
    private void initGroupDiaolog() {
        if (mGroupDialog == null) {
            mGroupDialog = new YR_CommonDialog(YR_AddPatientGroupActivity.this, "还没有保存", "放弃", "取消") {
                @Override
                public void confirmBtn() {
                    mGroupDialog.dismiss();
                }

                @Override
                public void cancelBtn() {
                    super.cancelBtn();
                    delayClose();
                }
            };
            mGroupDialog.setCanceledOnTouchOutside(true);
        }
    }

    @Override
    public void onBackPressed() {
        String groupname = et_group_name.getText().toString().trim();
        if(!TextUtils.isEmpty(groupname)){
            mGroupDialog.show();
            return;
        }
        delayClose();
    }
}
