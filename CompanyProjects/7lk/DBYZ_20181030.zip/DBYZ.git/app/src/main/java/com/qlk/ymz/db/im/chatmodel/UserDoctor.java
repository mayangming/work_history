package com.qlk.ymz.db.im.chatmodel;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;

/**
 * description: 医生用户基本信息资料
 * autour: YM
 * date: 2017/7/6
 * version:
 */

public class UserDoctor implements Serializable, Cloneable {
    protected String doctorSelfId = "";//医生id
    protected String doctorSelfName = "";//医生名
    protected String doctorSelfImgHead = "";//医生头像
    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getDoctorSelfId() {
        return UtilString.f(doctorSelfId);
    }

    public void setDoctorSelfId(String doctorSelfId) {
        this.doctorSelfId = doctorSelfId;
    }

    public String getDoctorSelfName() {
        return UtilString.f(doctorSelfName);
    }

    public void setDoctorSelfName(String doctorSelfName) {
        this.doctorSelfName = doctorSelfName;
    }

    public String getDoctorSelfImgHead() {
        return UtilString.f(doctorSelfImgHead);
    }

    public void setDoctorSelfImgHead(String doctorSelfImgHead) {
        this.doctorSelfImgHead = doctorSelfImgHead;
    }

}
