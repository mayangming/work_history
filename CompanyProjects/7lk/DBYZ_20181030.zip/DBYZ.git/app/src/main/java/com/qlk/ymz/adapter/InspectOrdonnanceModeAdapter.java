package com.qlk.ymz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;

import java.util.List;

/**
 * 推荐检查单-检查方式
 * @author WuPuquan
 * @version 1.0
 */
public class InspectOrdonnanceModeAdapter extends RecyclerView.Adapter<InspectOrdonnanceModeAdapter.ViewHolder>{

    private Context mContext;
    private List mList;

    public InspectOrdonnanceModeAdapter(Context context, List list) {
        this.mContext = context;
        this.mList = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_inspect_ordonnance_mode, parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (null == mList || mList.isEmpty()) return;
        holder.tv_inspect_mode.setText((String) mList.get(position));
    }

    @Override
    public int getItemCount() {
        return null == mList? 0 : mList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        /** 检查方式 */
        TextView tv_inspect_mode;

        public ViewHolder(View itemView) {
            super(itemView);

            tv_inspect_mode = (TextView) itemView.findViewById(R.id.tv_inspect_mode);

        }
    }
}
