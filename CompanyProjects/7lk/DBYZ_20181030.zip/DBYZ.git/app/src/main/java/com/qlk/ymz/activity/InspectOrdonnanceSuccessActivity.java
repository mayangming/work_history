package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.text.Html;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.InspectOrdonnanceSuccessItemAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.ExamineInfo;
import com.qlk.ymz.model.ExamineList;
import com.qlk.ymz.parse.Parser2ExamineInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.MyRecyclerView;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;


/**
 * 推荐成功
 *
 * @author WuPuquan.
 * @version 1.0
 */

public class InspectOrdonnanceSuccessActivity extends DBActivity {

    /**
     * 检查方式3列显示
     */
    public static final int INSPECT_MODE_SPAN_COUNT = 3;
    /**
     * 编号
     */
    private TextView tv_number;
    /**
     * 时间
     */
    private TextView tv_date;
    /**
     * 姓名
     */
    private TextView tv_patient_name;
    /**
     * 性别
     */
    private TextView tv_patient_sex;
    /**
     * 年龄
     */
    private TextView tv_patient_age;
    /**
     * 既往病史
     */
    private TextView tv_medical_history;
    /**
     * 病理及体征
     */
    private TextView tv_pathology;
    /**
     * 相关检查结果
     */
    private TextView tv_inspection_result;
    /**
     * 临床诊断
     */
    private TextView tv_diagnose;
    /**
     * 检查项目
     */
    private MyRecyclerView rv_inspect_item;
    /** 检查方式 */
    //private MyRecyclerView rv_inspect_mode;
    /**
     * 医师
     */
    private TextView tv_doctor;
    /**
     * 科室
     */
    private TextView tv_department;
    //推荐单ID
    public static final String RECOMMEND_ID = "recommend_id";
    private String mRecommendId = "";
    ExamineInfo mExamineInfo = new ExamineInfo();
    // 检查项目
    private InspectOrdonnanceSuccessItemAdapter mItemAdapter;
    private List<ExamineList> mItemList = new ArrayList<>();
    private XCTitleCommonLayout title_common_layout;

    public static void launch(Context context, String recommendId) {
        Intent intent = new Intent(context, InspectOrdonnanceSuccessActivity.class);
        intent.putExtra(RECOMMEND_ID, recommendId);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_inspect_ordonnance_success);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2017-10-30,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(InspectOrdonnanceSuccessActivity.class);
    }

    /** created by songxin,date：2017-10-30,about：bi,end */

    /**
     * 初始化title
     */
    public void initTitle() {
        title_common_layout = getViewById(R.id.title_common_layout);
        title_common_layout.getXc_id_titlebar_center_textview().setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        title_common_layout.setTitleLeft(true, null);
        title_common_layout.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public void initWidgets() {
        initTitle();
        mRecommendId = getIntent().getStringExtra(RECOMMEND_ID);
        tv_number = getViewById(R.id.tv_number);
        tv_date = getViewById(R.id.tv_date);
        tv_patient_name = getViewById(R.id.tv_patient_name);
        tv_patient_sex = getViewById(R.id.tv_patient_sex);
        tv_patient_age = getViewById(R.id.tv_patient_age);
        tv_medical_history = getViewById(R.id.tv_medical_history);
        tv_pathology = getViewById(R.id.tv_pathology);
        tv_inspection_result = getViewById(R.id.tv_inspection_result);
        tv_diagnose = getViewById(R.id.tv_diagnose);
        rv_inspect_item = getViewById(R.id.rv_inspect_item);
        tv_doctor = getViewById(R.id.tv_doctor);
        tv_department = getViewById(R.id.tv_department);

        // 检查项目
        rv_inspect_item.setLayoutManager(new LinearLayoutManager(this));
        mItemAdapter = new InspectOrdonnanceSuccessItemAdapter(this, mItemList);
        rv_inspect_item.setAdapter(mItemAdapter);
        requestRecommendInfo();
    }

    @Override
    public void listeners() {

    }

    /**
     * 请求检查单info
     */
    public void requestRecommendInfo() {
        if (TextUtils.isEmpty(mRecommendId)) {
            return;
        }
        RequestParams params = new RequestParams();
        params.put("recomId", mRecommendId);
        params.put("doctorId", UtilSP.getUserId());
        XCHttpAsyn.postAsyn(this, AppConfig.getTuijianUrl(AppConfig.inspectDetail), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean != null) {
                        Parser2ExamineInfo parser2ExamineInfo = new Parser2ExamineInfo(mExamineInfo);
                        parser2ExamineInfo.parseJson(result_bean);
                        initData(mExamineInfo);
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
            }

            @Override
            public void onFinish() {
                super.onFinish();
            }
        });
    }

    private void initData(ExamineInfo recommendInfo) {
        String hospital = TextUtils.isEmpty(recommendInfo.title) ? "荔湾七乐康互联网医院检查申请单" : recommendInfo.title;
        title_common_layout.setTitleCenter(true,hospital);
        // 编号
        tv_number.setText(fromHtml("编号：", recommendInfo.serialNumber));
        // 时间
        String time = DateFormat.format("yyyy/MM/dd", Long.parseLong(recommendInfo.recomTime)).toString();
        tv_date.setText(fromHtml("时间：", time));
        // 姓名
        tv_patient_name.setText("姓名：" + recommendInfo.patientName);
        // 性别
        if (CommonConfig.GENDER_MALE.equals(recommendInfo.patientGender)) {
            tv_patient_sex.setText(fromHtml("性别：", "男"));
        } else if (CommonConfig.GENDER_FEMALE.equals(recommendInfo.patientGender)) {
            tv_patient_sex.setText(fromHtml("性别：", "女"));
        } else {
            tv_patient_sex.setText(fromHtml("性别：", ""));
        }
        // 年龄
        tv_patient_age.setText(fromHtml("年龄：", recommendInfo.patientAge + recommendInfo.patientAgeUnit));
        // 医师
        tv_doctor.setText("医生："+ recommendInfo.doctorName);
        // 科室
        tv_department.setText("科室：" + recommendInfo.departmentName);
        String anamnesis = recommendInfo.anamnesis;
        if(TextUtils.isEmpty(anamnesis)){
            anamnesis = "无";
        }
        // 既往病史
        tv_medical_history.setText("既往病史：" + anamnesis);
        String symptoms = recommendInfo.symptoms;
        if(TextUtils.isEmpty(symptoms)){
            symptoms = "无";
        }
        // 病理及体征
        tv_pathology.setText("病理及体征：" + symptoms);
        String relatedExamine = recommendInfo.relatedExamine;
        if(TextUtils.isEmpty(relatedExamine)){
            relatedExamine = "无";
        }
        // 相关检查结果
        tv_inspection_result.setText("相关检查结果：" + relatedExamine);
        String diagnosis = recommendInfo.diagnosis;
        if(TextUtils.isEmpty(diagnosis)){
            diagnosis = "无";
        }
        // 临床诊断
        tv_diagnose.setText("临床诊断：" + diagnosis);

        mItemList.addAll(recommendInfo.item);
        mItemAdapter.notifyDataSetChanged();
    }

    /**
     * 改变部分字体颜色
     *
     * @param prefix 前半部分，如：编号
     * @param target 后半部分，如：编号value
     */
    private Spanned fromHtml(String prefix, String target) {
        return Html.fromHtml("<font color='#444444'>" + prefix + "</font><font color='#444444'>" + target + "</font>");
    }

    @Override
    public void onNetRefresh() {

    }

}

