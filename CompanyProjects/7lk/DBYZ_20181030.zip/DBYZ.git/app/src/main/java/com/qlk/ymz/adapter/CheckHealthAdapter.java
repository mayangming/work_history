package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.ExamineBean;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;

import java.util.List;

/**
 * description: $todo$
 * autour: YM
 * date: $date$ $time$
 * update: $date$
 * version: $version$
 */

public class CheckHealthAdapter extends XCBaseAdapter<ExamineBean> {

    public CheckHealthAdapter(Context context, List<ExamineBean> list) {
        super(context, list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        CheckHealthItemViewHolder checkHealthViewHolder = null;
        ExamineBean checkHealthItem = list.get(position);
        if (null == convertView){
            convertView = LayoutInflater.from(context).inflate(R.layout.ym_check_health_item,null);
            checkHealthViewHolder = new CheckHealthItemViewHolder(convertView);
            convertView.setTag(checkHealthViewHolder);
        }else {
            checkHealthViewHolder = (CheckHealthItemViewHolder)convertView.getTag();
        }
        checkHealthViewHolder.tv_chat_check_health_name.setText(checkHealthItem.getName());
        return convertView;
    }

    class CheckHealthItemViewHolder{
        TextView tv_chat_check_health_name;
        public CheckHealthItemViewHolder(View converView) {
            this.tv_chat_check_health_name = (TextView) converView.findViewById(R.id.tv_chat_check_health_name);
        }
    }

}