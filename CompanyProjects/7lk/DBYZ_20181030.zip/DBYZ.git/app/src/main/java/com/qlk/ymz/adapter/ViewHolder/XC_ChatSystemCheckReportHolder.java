package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * @author YM on 2018/3/21 14:21
 * @description 检查报告
 */
public class XC_ChatSystemCheckReportHolder {
    /**
     * 本地模拟系统消息提示视图
     */
    public TextView textview;
    public TextView sysTime;//系统时间

    public XC_ChatSystemCheckReportHolder(View convertView) {
        this.textview = (TextView) convertView.findViewById(R.id.chat_system_check_record);
        this.sysTime = (TextView) convertView.findViewById(R.id.xc_id_adapter_left_time);
    }
}