package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * @author YM on 2018/3/21 14:21
 * @description 医生提醒患者填写病历
 */

public class ChatMedicineRecordHolder {
    /**
     * 本地模拟系统消息提示视图
     */
    public TextView textview;

    public ChatMedicineRecordHolder(View convertView) {
        this.textview = (TextView) convertView.findViewById(R.id.chat_system_medicine_record);
    }
}