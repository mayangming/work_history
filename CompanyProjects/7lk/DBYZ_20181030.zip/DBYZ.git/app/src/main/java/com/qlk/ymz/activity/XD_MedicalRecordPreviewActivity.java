package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.ImageAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.drCase.DrCaseVOBeanDb;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.ChatModelMedicalRecord;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.RecommendMedicineResultBean;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.ImgListBean;
import com.qlk.ymz.parse.Parser2RecomMedResultBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.UtilInsertMsg2JsDb;
import com.qlk.ymz.util.UtilPackMsg;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2018/5/29.
 * 病历预览
 */

public class XD_MedicalRecordPreviewActivity extends DBActivity {
    /** 标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** 患者基本信息*/
    private RelativeLayout rl_patient_base_info;
    /** 患者姓名*/
    private TextView tv_patient_name;
    /** 患者年龄*/
    private TextView tv_patient_age;
    /** 患者性别*/
    private TextView tv_patient_sex;
    /** 时间*/
    private TextView tv_time;
    /** 医生填写基本病情*/
    private LinearLayout ll_doctor_edit;
    /** 主诉布局*/
    private LinearLayout ll_suit;
    /** 主诉*/
    private TextView tv_suit;
    /** 既往史布局*/
    private LinearLayout ll_history;
    /** 既往史*/
    private TextView tv_history;
    /** 检查指标布局*/
    private LinearLayout ll_check;
    /** 检查指标*/
    private TextView tv_check;
    /** 其它检查布局*/
    private LinearLayout ll_other_check;
    /** 其它检查*/
    private TextView tv_other_check;
    /** 诊断布局*/
    private LinearLayout ll_diagnosis;
    /** 诊断*/
    private TextView tv_diagnosis;
    /** 医嘱小结布局*/
    private LinearLayout ll_doctor_advice;
    /** 医嘱小结*/
    private TextView tv_doctor_advice;
    /** 图片布局*/
    private LinearLayout ll_doctor_pic;
    /** 图片列表*/
    private RecyclerView rv_doctor_pic;
    /** 医生科室布局*/
    private LinearLayout ll_department;
    private TextView tv_department;
    /** 医生姓名*/
    private LinearLayout ll_doctor_name;
    private TextView tv_doctor_name;
    /** 医院*/
    private LinearLayout ll_hospital;
    private TextView tv_hospital;
    /** 保存*/
    private TextView tv_save;
    /** 发送*/
    private TextView tv_send;
    /** 图片适配器*/
    private ImageAdapter mImageAdapter;
    /** 医生填写的病历*/
    private DrCaseVOBean mDrCaseVOBean;
    /** 图片地址集合*/
    private ArrayList<String> mImageList = new ArrayList<>();
    /** 加file的图片地址集合*/
    private ArrayList<String> urls = new ArrayList<>();
    /** 上传图片返回集合*/
    private List<String> mLineUrls = new ArrayList<>();
    /** 是否有基本病情*/
    private boolean haveBaseRecord = false;
    /** 控制按钮*/
    private boolean clickable = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_medical_record_preview);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_MedicalRecordPreviewActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "病历预览");
        xc_id_model_titlebar.setTitleLeft(true, "");

        rl_patient_base_info = getViewById(R.id.rl_patient_base_info);
        tv_patient_name = getViewById(R.id.tv_patient_name);
        tv_patient_age = getViewById(R.id.tv_patient_age);
        tv_patient_sex = getViewById(R.id.tv_patient_sex);
        tv_time = getViewById(R.id.tv_time);
        ll_doctor_edit = getViewById(R.id.ll_doctor_edit);
        ll_suit = getViewById(R.id.ll_suit);
        tv_suit = getViewById(R.id.tv_suit);
        ll_history = getViewById(R.id.ll_history);
        tv_history = getViewById(R.id.tv_history);
        ll_check = getViewById(R.id.ll_check);
        tv_check = getViewById(R.id.tv_check);
        ll_other_check = getViewById(R.id.ll_other_check);
        tv_other_check = getViewById(R.id.tv_other_check);
        ll_diagnosis = getViewById(R.id.ll_diagnosis);
        tv_diagnosis = getViewById(R.id.tv_diagnosis);
        ll_doctor_advice = getViewById(R.id.ll_doctor_advice);
        tv_doctor_advice = getViewById(R.id.tv_doctor_advice);
        ll_doctor_pic = getViewById(R.id.ll_doctor_pic);
        rv_doctor_pic = getViewById(R.id.rv_doctor_pic);
        ll_department = getViewById(R.id.ll_department);
        tv_department = getViewById(R.id.tv_department);
        ll_doctor_name = getViewById(R.id.ll_doctor_name);
        tv_doctor_name = getViewById(R.id.tv_doctor_name);
        ll_hospital = getViewById(R.id.ll_hospital);
        tv_hospital = getViewById(R.id.tv_hospital);
        tv_save = getViewById(R.id.tv_save);
        tv_send = getViewById(R.id.tv_send);
        //此设置优化recyclerview
        rv_doctor_pic.setHasFixedSize(true);
        //设置recyclerview的布局方式
        rv_doctor_pic.setLayoutManager(new GridLayoutManager(this, 4));
        //设置适配器
        mImageAdapter = new ImageAdapter(this,mImageList);
        mImageAdapter.setOnItemClickListener(new ImageAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                ToJumpHelp.toJumpChatImageShowActivity(XD_MedicalRecordPreviewActivity.this, urls,position);
            }
        });
        rv_doctor_pic.setAdapter(mImageAdapter);

    }

    @Override
    public void listeners() {
        tv_save.setOnClickListener(this);
        tv_send.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_save:
                if(clickable){
                    uploadCaseImg(false);
                }
                break;
            case R.id.tv_send:
                if(clickable){
                    uploadCaseImg(true);
                }
                break;
            default:
                break;
        }
        super.onClick(v);
    }

    private void initData() {
        mDrCaseVOBean = (DrCaseVOBean) getIntent().getSerializableExtra(XD_EditMedicalRecordActivity.DR_CASE_VO_BEAN);
        List<ImgListBean> imgList = mDrCaseVOBean.getImgList();
        if(imgList!=null&&imgList.size()>0){
            ll_doctor_pic.setVisibility(View.VISIBLE);
            for (ImgListBean imgListBean:imgList){
                mImageList.add(imgListBean.getImgUrl());
                if(!imgListBean.getImgUrl().startsWith("http")){//不是网络图片
                    urls.add("file://"+imgListBean.getImgUrl());
                }else {
                    urls.add(imgListBean.getImgUrl());
                }
            }
            mImageAdapter.notifyDataSetChanged();
        }else {
            ll_doctor_pic.setVisibility(View.GONE);
        }
        //展示患者信息
        tv_patient_name.setText("姓名："+mDrCaseVOBean.getName());
        tv_patient_age.setText("年龄："+mDrCaseVOBean.getAge()+mDrCaseVOBean.getAgeUnit());
        tv_time.setText("时间："+DateUtils.getTime("yyyy/MM/dd"));
        if("0".equals(mDrCaseVOBean.getGender())){
            tv_patient_sex.setText("性别：女");
        }else if("1".equals(mDrCaseVOBean.getGender())){
            tv_patient_sex.setText("性别：男");
        }
        //展示基本病情
        if(UtilString.isAllBlank(mDrCaseVOBean.getMainComplaint(),mDrCaseVOBean.getPresentDisease())){
            ll_suit.setVisibility(View.GONE);
        }else {
            haveBaseRecord = true;
            ll_suit.setVisibility(View.VISIBLE);
            String suitStr = "";
            if (!TextUtils.isEmpty(mDrCaseVOBean.getMainComplaint())) {
                suitStr = getTrimStr("",mDrCaseVOBean.getMainComplaint(),"") +"\n"+
                          getTrimStr("现病史：", mDrCaseVOBean.getPresentDisease(),"");
            }else {
                suitStr = getTrimStr("现病史：", mDrCaseVOBean.getPresentDisease(),"");
            }
            tv_suit.setText(clearEnd(suitStr));
        }

        fillWidget(ll_history,tv_history,mDrCaseVOBean.getPastHistory());

        if(UtilString.isAllBlank(mDrCaseVOBean.getTemperature(), mDrCaseVOBean.getWeight(),
                                 mDrCaseVOBean.getHeartRete(),mDrCaseVOBean.getDiastole(),
                                 mDrCaseVOBean.getSystolic(),mDrCaseVOBean.getMoreExamin())){
            ll_check.setVisibility(View.GONE);
        }else {
            haveBaseRecord = true;
            ll_check.setVisibility(View.VISIBLE);
            String str = getTrimStr("体温：",mDrCaseVOBean.getTemperature(),"度")+
                    getTrimStr("体重：", mDrCaseVOBean.getWeight(),"kg")+
                    getTrimStr("心率：",mDrCaseVOBean.getHeartRete(),"bpm")+
                    getTrimStr("收缩压：", mDrCaseVOBean.getSystolic(),"mmhg")+
                    getTrimStr("舒张压：",mDrCaseVOBean.getDiastole(),"mmhg")+
                    getTrimStr("",mDrCaseVOBean.getMoreExamin(),"");
            tv_check.setText(clearEnd(str));
        }

        if("1".equals(mDrCaseVOBean.getTemplateType())||UtilString.isAllBlank(mDrCaseVOBean.getAlt(), mDrCaseVOBean.getAst(), mDrCaseVOBean.getHbvDna())){
            ll_other_check.setVisibility(View.GONE);
        }else {
            haveBaseRecord = true;
            ll_other_check.setVisibility(View.VISIBLE);
            String str = getTrimStr("谷丙转氨酶(ALT)：",mDrCaseVOBean.getAlt(),"IU/ml")+
                         getTrimStr("谷草转氨酶(AST)：",mDrCaseVOBean.getAst(),"IU/ml")+
                         getTrimStr("HBV-DNA：",mDrCaseVOBean.getHbvDna(),"IU/ml");
            tv_other_check.setText(clearEnd(str));
        }

        fillWidget(ll_diagnosis,tv_diagnosis,mDrCaseVOBean.getDiagnosis());

        if(TextUtils.isEmpty(mDrCaseVOBean.getDoctorOrder())&&"2".equals(mDrCaseVOBean.getRevisitFalg())){
            ll_doctor_advice.setVisibility(View.GONE);
        }else {
            haveBaseRecord = true;
            ll_doctor_advice.setVisibility(View.VISIBLE);
            String str = "";
            if("2".equals(mDrCaseVOBean.getRevisitFalg())){
                str= mDrCaseVOBean.getDoctorOrder();
            }else {
                if("月".equals(mDrCaseVOBean.getRevisitDateUnit())){
                    str= getTrimStr("下次复诊时间：",mDrCaseVOBean.getRevisitNumber() +"个"+mDrCaseVOBean.getRevisitDateUnit(),"后")+
                         getTrimStr( "", mDrCaseVOBean.getDoctorOrder(),"");
                }else {
                    str= getTrimStr("下次复诊时间：",mDrCaseVOBean.getRevisitNumber() +mDrCaseVOBean.getRevisitDateUnit(),"后")+
                         getTrimStr( "", mDrCaseVOBean.getDoctorOrder(),"");
                }
            }
            tv_doctor_advice.setText(clearEnd(str));
        }
        if(haveBaseRecord){
            ll_doctor_edit.setVisibility(View.VISIBLE);
        }else {
            ll_doctor_edit.setVisibility(View.GONE);
        }

        fillWidget(ll_department,tv_department,UtilSP.getFirstDepartmentName());
        fillWidget(ll_doctor_name,tv_doctor_name,UtilSP.getUserName());
        fillWidget(ll_hospital,tv_hospital,UtilSP.getHospitalName());
        if(isEmpty()){//都为空  按钮置灰
            tv_save.setBackgroundResource(R.drawable.xd_gray_white_red_shape_2);
            tv_send.setBackgroundResource(R.drawable.xd_gray_red_round_shape_2);
            tv_send.setTextColor(getResources().getColor(R.color.c_7fffffff));
            tv_save.setTextColor(getResources().getColor(R.color.c_7fe2231a));
        }else {
            tv_save.setBackgroundResource(R.drawable.xd_white_red_shape_2);
            tv_send.setBackgroundResource(R.drawable.xd_red_round_shape_2);
            tv_send.setTextColor(getResources().getColor(R.color.c_white_ffffff));
            tv_save.setTextColor(getResources().getColor(R.color.c_e2231a));
        }
    }

    /**
     * 上传图片
     */
    private void uploadCaseImg(final boolean send) {
        clickable = false;
        if(isEmpty()){
            shortToast("你好像啥都没写啊");
            clickable = true;
            return;
        }
        if (UtilCollection.isBlank(mLineUrls)&&!UtilCollection.isBlank(mImageList)) {
            try {
            List<File> imageList = new ArrayList<>();
            for (String s:mImageList){
                if(!s.startsWith("http")){
                    imageList.add(new File(s));
                }else {
                    mLineUrls.add(s);
                }
            }
            if(UtilCollection.isBlank(imageList)){
                saveRecord(send);
                return;
            }
            List<File> uploadFiles = UtilFile.ChangeImgsToUploadFiles(imageList);
            File[] pics = new File[uploadFiles.size()];
            RequestParams params = new RequestParams();
            params.put("file", uploadFiles.toArray(pics));
            XCHttpAsyn.postAsyn(this, AppConfig.getRecordUrl(AppConfig.UPLOAD_CASE_IMG), params, new XCHttpResponseHandler() {
                        @Override
                        public void onSuccess(int code, Header[] headers, byte[] arg2) {
                            super.onSuccess(code, headers, arg2);
                            if (result_boolean) {
                                mLineUrls.addAll(result_bean.getStringList("data"));
                                saveRecord(send);
                            }else {
                                clickable = true;
                            }
                        }

                        @Override
                        public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                            clickable = true;
                            super.onFailure(code, headers, arg2, e);
                        }

                        @Override
                        public void onFinish() {
                            super.onFinish();
                            // 处理code操作
                            if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_MedicalRecordPreviewActivity.this,
                                    getCode(), getMsg())) {
                            }
                        }
                    });
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                clickable = true;
            }
        }else {
            saveRecord(send);
        }
    }

    private boolean isEmpty() {
        return UtilString.isAllBlank(mDrCaseVOBean.getAlt(),mDrCaseVOBean.getAst(), mDrCaseVOBean.getDiagnosis(),
                mDrCaseVOBean.getDiastole(), mDrCaseVOBean.getDoctorOrder(),mDrCaseVOBean.getHbvDna(),
                mDrCaseVOBean.getHeartRete(),mDrCaseVOBean.getMainComplaint(),mDrCaseVOBean.getMoreExamin(),
                mDrCaseVOBean.getPastHistory(),mDrCaseVOBean.getPresentDisease(),mDrCaseVOBean.getRevisitDateUnit(),
                mDrCaseVOBean.getRevisitNumber(),mDrCaseVOBean.getSystolic(), mDrCaseVOBean.getTemperature(),
                mDrCaseVOBean.getWeight())&& UtilCollection.isBlank(mDrCaseVOBean.getImgList());
    }

    /**
     * 保存病历
     * @param send 是否发送
     */
    private void saveRecord(final boolean send) {
        RequestParams params = new RequestParams();
        if(mLineUrls !=null&& mLineUrls.size()>0){
            params.put("imgList", mLineUrls.toArray());
        }
        params.put("patientId",mDrCaseVOBean.getPatientId());
        params.put("patientName",mDrCaseVOBean.getName());
        params.put("patientGender",mDrCaseVOBean.getGender());
        params.put("age",mDrCaseVOBean.getAge());
        params.put("ageUnit",mDrCaseVOBean.getAgeUnit());
        if(!TextUtils.isEmpty(mDrCaseVOBean.getMainComplaint())){
            params.put("mainComplaint",mDrCaseVOBean.getMainComplaint());
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getPresentDisease())){
            params.put("presentDisease",mDrCaseVOBean.getPresentDisease());
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getPastHistory())){
            params.put("pastHistory",mDrCaseVOBean.getPastHistory());
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getTemperature())){
           params.put("temperature",mDrCaseVOBean.getTemperature());
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getWeight())){
            params.put("weight",mDrCaseVOBean.getWeight());
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getHeartRete())){
           params.put("heartRete",mDrCaseVOBean.getHeartRete());
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getSystolic())){
            params.put("systolic",mDrCaseVOBean.getSystolic());
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getDiastole())){
            params.put("diastole",mDrCaseVOBean.getDiastole());
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getMoreExamin())){
           params.put("moreExamin",mDrCaseVOBean.getMoreExamin());
        }
        if("2".equals(mDrCaseVOBean.getTemplateType())){
            if(!TextUtils.isEmpty(mDrCaseVOBean.getHbvDna())){
                params.put("hbvDna",mDrCaseVOBean.getHbvDna());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getAlt())){
                params.put("alt",mDrCaseVOBean.getAlt());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getAst())){
                params.put("ast",mDrCaseVOBean.getAst());
            }
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getDiagnosis())){
            params.put("diagnosis",mDrCaseVOBean.getDiagnosis());
        }
        if(!UtilCollection.isBlank(mDrCaseVOBean.getDiagnosisList())){
            params.put("diagnosisList",mDrCaseVOBean.getDiagnosisList().toArray());
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getTemplateType())){
            params.put("templateType",mDrCaseVOBean.getTemplateType());
        }
        if(!TextUtils.isEmpty(mDrCaseVOBean.getDoctorOrder())){
            params.put("doctorOrder",mDrCaseVOBean.getDoctorOrder());
        }
        if("1".equals(mDrCaseVOBean.getRevisitFalg())){
            params.put("revisitNumber",mDrCaseVOBean.getRevisitNumber());
            params.put("revisitDateUnit",mDrCaseVOBean.getRevisitDateUnit());
        }
        params.put("revisitFalg",mDrCaseVOBean.getRevisitFalg());
        if(send){
            params.put("send","true");
        }
        XCHttpAsyn.postAsyn(this, AppConfig.getRecordUrl(AppConfig.SAVE_DR_CASE), params,
                new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (result_boolean) {
                            new DrCaseVOBeanDb(XD_MedicalRecordPreviewActivity.this).deleteById(mDrCaseVOBean.getPatientId(),UtilSP.getUserId());
                            //通知患者病例页刷新诊疗记录
                            Intent intent = new Intent();
                            intent.setAction(XL_PatientInfoAActivity.NewMedicalReceiver.NEW_MEDICAL_ACTION);
                            context.sendBroadcast(intent);

                            if(send){
                                RecommendMedicineResultBean resultBean = new RecommendMedicineResultBean();
                                Parser2RecomMedResultBean parser2RecomMedResultBean = new Parser2RecomMedResultBean(resultBean);
                                parser2RecomMedResultBean.parseJson(result_bean);
                                ChatModelMedicalRecord medicalRecord = new ChatModelMedicalRecord();
                                medicalRecord.setPatientName(mDrCaseVOBean.getName());
                                medicalRecord.setAge(mDrCaseVOBean.getAge()+mDrCaseVOBean.getAgeUnit());
                                medicalRecord.setDiagnosis(mDrCaseVOBean.getDiagnosis());
                                medicalRecord.setDoctorsSummary(UtilChat.doctorAdvice(mDrCaseVOBean,false));
                                medicalRecord.setGender(UtilChat.parserGender(mDrCaseVOBean.getGender()));
                                medicalRecord.setMainComplaint(mDrCaseVOBean.getMainComplaint());
                                medicalRecord.setMedicalRecordId(resultBean.getRecordId());
                                XC_ChatModel chatBase = new XC_ChatModel();
                                chatBase.getUserPatient().setPatientId(mDrCaseVOBean.getPatientId());
                                chatBase.setChatModelMedicalRecord(medicalRecord);
                                chatBase.setMessageId(resultBean.getMessageId());
                                chatBase.setSessionId(resultBean.getSessionId());
                                chatBase.setSessionBeginTime(resultBean.getBeginTime());
                                chatBase.getUserPatient().setConsultPayType(resultBean.getConsultPayType());
                                chatBase.getChatSession().setConsultSourceType(resultBean.getConsultSourceType());
                                chatBase.setSessionJson(UtilIMCreateJson.createSessionJson(chatBase));
                                String content = UtilIMCreateJson.createMedicalJson(chatBase);
                                XC_ChatModel chatModel = UtilPackMsg.packMedicalRecordMsg(content,chatBase);
                                chatModel.setMsgTime(resultBean.getSendTime());
                                XCChatModelDb.getInstance(getApplicationContext(), UtilSP.getIMDetailDbName(UtilSP.getUserId(), mDrCaseVOBean.getPatientId())).insert(chatModel);
                                UtilInsertMsg2JsDb.insert(getApplicationContext(), chatModel);
                            }
                            Boolean remarkFlag = result_bean.getList("data").get(0).getBoolean("remarkFlag");
                            if(remarkFlag){//本地需要返写
                                requestPatientSimple(send);
                            }else {
                                shortToast(send?"发送成功":"保存成功");
                                setResult(RESULT_OK);
                                myFinish();
                                if(send && getIntent().getIntExtra(XD_EditMedicalRecordActivity.PAGE_FLAG,1)==1){
                                    UtilChat.launchChatDetail(XD_MedicalRecordPreviewActivity.this,mDrCaseVOBean.getPatientId(), null);
                                }
                            }
                        }else {
                            clickable = true;
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        clickable = true;
                        super.onFailure(code, headers, arg2, e);
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        // 处理code操作
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_MedicalRecordPreviewActivity.this,
                                getCode(), getMsg())) {
                        }
                    }
                });
    }


    /**
     * 2.9版本需求
     * 获取患者姓名更新患者数据库
     */
    public void requestPatientSimple(final boolean send) {
        RequestParams params = new RequestParams();
        params.put("patientId",mDrCaseVOBean.getPatientId());

        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.patientSimple), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !XD_MedicalRecordPreviewActivity.this.isDestroy) {
                    try {
                        // id (integer),
                        // name (string): 患者姓名或昵称 ,
                        // remarkName (string): 患者备注名

                        JS_ChatListModel chatListModel = JS_ChatListDB.getInstance(context, UtilSP.getUserId()).getPatientInfo(mDrCaseVOBean.getPatientId());
                        chatListModel.getUserPatient().setPatientName(result_bean.getList("data").get(0).getString("name"));
                        chatListModel.getUserPatient().setPatientMemoName(result_bean.getList("data").get(0).getString("remarkName"));
                        JS_ChatListDB.getInstance(context, UtilSP.getUserId()).updatePatientInfo(chatListModel);
                        shortToast(send?"发送成功":"保存成功");
                        setResult(RESULT_OK);
                        myFinish();
                        if(send && getIntent().getIntExtra(XD_EditMedicalRecordActivity.PAGE_FLAG,1)==1){
                            UtilChat.launchChatDetail(XD_MedicalRecordPreviewActivity.this, mDrCaseVOBean.getPatientId(), null);
                        }

                    } catch (Exception e) {
                        clickable = true;
                        e.printStackTrace();
                    }
                }else {
                    clickable = true;
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                clickable = true;
                super.onFailure(code, headers, arg2, e);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_MedicalRecordPreviewActivity.this, getCode(), getMsg())) {
                }
            }
        });
    }

    private void fillWidget(ViewGroup viewGroup, TextView textView, String str){
        if(TextUtils.isEmpty(str)){
            viewGroup.setVisibility(View.GONE);
        }else {
            haveBaseRecord = true;
            viewGroup.setVisibility(View.VISIBLE);
            textView.setText(str);
        }
    }

    private String getTrimStr(String str,String values,String unit){
        String s ="";
        s +=TextUtils.isEmpty(values)? "":str+values+unit+"\n";
        return s;
    }

    private String clearEnd(String str){
        while (str.endsWith("\n")){
            str = UtilString.getStringWithoutLast(str,"\n");
        }
        return str;
    }

    /**
     * 记录点击时候的时间
     */
    private long lastClickTime;

    /**
     * 防止1000毫秒内重复点击的方法
     *
     * @return true：重复点击，false：不是重复点击
     */
    public boolean isFastClick() {
        long time = System.currentTimeMillis();
        if (time - lastClickTime < 1000) {
            return true;
        }
        lastClickTime = time;
        return false;
    }
}
