package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.LT_CustomDivisionEditext;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.fragment.XCCameraPhotoFragment;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import java.io.File;

/**
 * @author 李涛
 * @description   互联网医院备案----身份证页面的编辑
 * @Date 2017/7/18.
 */
public class LT_IDCardEditorActivity extends DBActivity implements  XCCameraPhotoFragment.OnCaremaSelectedFileListener {


    /**
     * 照相机
     */
    private XCCameraPhotoFragment cameraPhotoFragment;
    /**
     * 上传身份证正面
     */
    private ImageView lt_idcard_front;
    private RelativeLayout lt_idcard_front_rl;
    /**
     * 上传身份证反面
     */
    private ImageView lt_idcard_reverse;
    private RelativeLayout lt_idcard_reverse_rl;
    /**
     * 相册返回的图片标记
     */
    private int mPhotoFlag = 0;
    /**
     * 上传文件弹出Dialog
     */
    private ConfirmDialog mUploadDialog;
    private TextView xc_id_pop_photoUpload;//照相机
    private TextView xc_id_pop_localAlbum;//图库
    private TextView xc_id_pop_cancel;//取消
    /**
     * 正反面删除按钮
     */
    private ImageView lt_hospital_deletefront;
    private ImageView lt_hospital_deletereverse;
    /**
     * 正反身份证file
     */
    private File mFrontIdCardFile = null;
    private File mReverseIdCardFile = null;
    private Intent intent;
    /**
     * 确认按钮
     */
    private Button lt_idcard_ok;
    /**
     * 身份证号输入
     * */
    private LT_CustomDivisionEditext lt_idcard_input;
    private String fileIDCardNum = "";
    private Intent backIntent;
    /**
     * 医生合法备案状态（0 未申请备案; 1 备案审核中;2 备案成功; 3 备案失败; 4 要求备案）
     */
    private String viewFlag;


   Handler handler =  new Handler(Looper.getMainLooper());
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lt__idcard_editor);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(LT_IDCardEditorActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */

    /**
     * 初始化数据
     */
    private  void initData(){
       viewFlag = UtilSP.getDoctorStatus();
      //  viewFlag = "3";
        backIntent = getIntent();
        //获取备案信息页传来的网络数据
        mFrontIdCardFile = (File) backIntent.getSerializableExtra("frontImage");
        mReverseIdCardFile =  (File) backIntent.getSerializableExtra("reverseImage");
        fileIDCardNum = backIntent.getStringExtra("idCardNum");
        //刚进入该页面的时候 如果携带数据我们就让他底部提交按钮置灰  修改完数据后变得可点击操作   （使用延迟操作是应为该页面有一个Editext的监听）
        //(如果数据不为空说明 1 有后台操作上传一部分数据  2是审核状态    3是审核失败状态  提交按钮都是置灰不可点击的)
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(mFrontIdCardFile!=null&&mReverseIdCardFile!=null&&!TextUtils.isEmpty(fileIDCardNum)){
                    lt_idcard_ok.setTextColor(getResources().getColor(R.color.c_login_text_bg));
                    lt_idcard_ok.setEnabled(false);
                }
            }
        },100);
        if("4".equals(viewFlag)){
            viewFlag ="0";
        }
        //判断是否备案状态
        switch(viewFlag){
            //未备案状态
            case "0":
                checkDdataShow();
                break;
                //备案审核
            case "1" :
                if(mFrontIdCardFile!=null&&mReverseIdCardFile!=null&&!TextUtils.isEmpty(fileIDCardNum)){
                    lt_idcard_front.setImageURI(Uri.fromFile(mFrontIdCardFile));
                    lt_idcard_reverse.setImageURI(Uri.fromFile(mReverseIdCardFile));
                    lt_idcard_input.setText(fileIDCardNum);
                    lt_idcard_input.setFocusable(false);
                    lt_idcard_input.setTextColor(getResources().getColor(R.color.c_gray_7f7f7f));
                    lt_idcard_front.setVisibility(View.VISIBLE);
                    lt_idcard_reverse.setVisibility(View.VISIBLE);
                    lt_hospital_deletereverse.setVisibility(View.GONE);
                    lt_hospital_deletefront.setVisibility(View.GONE);
                }
                break;
                //备案失败
            case "3" :
                if(mFrontIdCardFile!=null&&mReverseIdCardFile!=null&&!TextUtils.isEmpty(fileIDCardNum)){
                    lt_idcard_front.setImageURI(Uri.fromFile(mFrontIdCardFile));
                    lt_idcard_reverse.setImageURI(Uri.fromFile(mReverseIdCardFile));
                    lt_idcard_input.setText(fileIDCardNum);
                    lt_idcard_front.setVisibility(View.VISIBLE);
                    lt_idcard_reverse.setVisibility(View.VISIBLE);
                    lt_hospital_deletereverse.setVisibility(View.VISIBLE);
                    lt_hospital_deletefront.setVisibility(View.VISIBLE);
                }
                break;
        }

    }

    //判断数据是否展示
    public  void checkDdataShow(){
        if(mFrontIdCardFile!=null){
            lt_idcard_front.setVisibility(View.VISIBLE);
            lt_hospital_deletefront.setVisibility(View.VISIBLE);
            lt_idcard_front.setImageURI(Uri.fromFile(mFrontIdCardFile));
        }
        if(mReverseIdCardFile!=null){
            lt_idcard_reverse.setVisibility(View.VISIBLE);
            lt_hospital_deletereverse.setVisibility(View.VISIBLE);
            lt_idcard_reverse.setImageURI(Uri.fromFile(mReverseIdCardFile));
        }
        if(!TextUtils.isEmpty(fileIDCardNum)){
            lt_idcard_input.setText(fileIDCardNum);
        }
    }


    @Override
    public void initWidgets() {
        intent = new Intent();
        initDialog();
        //标题部分
        XCTitleCommonLayout xcTitleCommonLayout = (XCTitleCommonLayout) findViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonLayout.setTitleLeft(true, "");
        xcTitleCommonLayout.setTitleCenter(true, "身份证");
        //添加相机相册视图
        cameraPhotoFragment = new XCCameraPhotoFragment();
        addFragment(R.id.lt_idcard_camera, cameraPhotoFragment);
        //输入的身份证号
        lt_idcard_input = (LT_CustomDivisionEditext) findViewById(R.id.lt_idcard_input);
        lt_idcard_input.setContextType(LT_CustomDivisionEditext.IDCARD);
        //上传身份证的正反面
        lt_idcard_reverse_rl = (RelativeLayout) findViewById(R.id.lt_idcard_reverse_rl);
        lt_idcard_front_rl = (RelativeLayout) findViewById(R.id.lt_idcard_front_rl);
        lt_idcard_front = (ImageView) findViewById(R.id.lt_idcard_front);
        lt_idcard_reverse = (ImageView) findViewById(R.id.lt_idcard_reverse);
        //删除按钮
        lt_hospital_deletefront = (ImageView) findViewById(R.id.lt_hospital_deletefront);
        lt_hospital_deletereverse = (ImageView) findViewById(R.id.lt_hospital_deletereverse);
        //确认按钮
        lt_idcard_ok = (Button) findViewById(R.id.lt_idcard_ok);

    }

    @Override
    public void listeners() {
        lt_idcard_front.setOnClickListener(this);
        lt_idcard_reverse.setOnClickListener(this);
        lt_idcard_front_rl.setOnClickListener(this);
        lt_idcard_reverse_rl.setOnClickListener(this);
        cameraPhotoFragment.setOnCaremaSelectedFileListener(this);
        lt_hospital_deletefront.setOnClickListener(this);
        lt_hospital_deletereverse.setOnClickListener(this);
        lt_idcard_ok.setOnClickListener(this);

        lt_idcard_input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
            @Override
            public void afterTextChanged(Editable s) {
                if(s==null){
                    return;
                }
                checkButton();
            }});
    }

    @Override
    public void onNetRefresh() { }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.lt_idcard_front:
                //显示 “正面” 大图
                    startShowPictureActivity(mFrontIdCardFile.getAbsolutePath(),"身份证正面",0);
                break;
            case R.id.lt_idcard_reverse:
                //显示 ”背面“ 大图
                  startShowPictureActivity(mReverseIdCardFile.getAbsolutePath(),"身份证背面",0);
                break;
            case R.id.xc_id_pop_photoUpload:
                //跳转---》相机
                uploadDialogDismiss();
                cameraPhotoFragment.getTakePhoto();
                break;
            case R.id.xc_id_pop_localAlbum:
                //跳转--》相册
                uploadDialogDismiss();
                ToJumpHelp.toJumpSelctImgsActivity(this, 1, YY_SelectImgsActivity.MODE_SINGLE,
                        false, true, false, true);
                break;
            case R.id.xc_id_pop_cancel:
                //取消--》弹窗
                uploadDialogDismiss();
                break;
            case R.id.lt_idcard_front_rl:
                //正面照片
                mPhotoFlag = 0;
                uploadDialogShow();
                break;
            case R.id.lt_idcard_reverse_rl:
                //反面照片
                mPhotoFlag = 1;
                uploadDialogShow();
                break;
            case R.id.lt_hospital_deletefront:
                //删除照片（正面）
                mFrontIdCardFile = null;
                lt_idcard_front.setImageURI(null);
                lt_idcard_front.setVisibility(View.GONE);
                lt_hospital_deletefront.setVisibility(View.GONE);
                //控制提交按钮的可点击事件
                lt_idcard_ok.setEnabled(true);
                checkButton();
                break;
            case R.id.lt_hospital_deletereverse:
                //删除照片（反面）
                mReverseIdCardFile = null;
                lt_idcard_reverse.setImageURI(null);
                lt_idcard_reverse.setVisibility(View.GONE);
                lt_hospital_deletereverse.setVisibility(View.GONE);
                //控制提交按钮的可点击事件
                lt_idcard_ok.setEnabled(true);
                checkButton();
                break;
            case R.id.lt_idcard_ok:
                    //确认按钮 -----》 两个文件不为空就返回给上一页数据
                backDdata();
                break;
        }
    }

    /**
     * 将照片和身份证号存返回到上一个页面
     */
    private void backDdata(){

        if(mFrontIdCardFile==null&&mReverseIdCardFile==null){
            shortToast("请提交真实身份证图片");
        }

        if(lt_idcard_input.getText().toString().replace(" ","").length()<18){
            shortToast("请提交真实身份证号码");
        }

        if(mFrontIdCardFile!=null&&mReverseIdCardFile!=null&&lt_idcard_input.getText().toString().replace(" ","").length()>=18){
            backIntent.putExtra("frontImage",mFrontIdCardFile);
            backIntent.putExtra("reverseImage",mReverseIdCardFile);
            backIntent.putExtra("idCardNum",lt_idcard_input.getText().toString().replace(" ",""));
            backIntent.putExtra("idCardwaitCommit","待提交");
            setResult(RESULT_OK,backIntent);
            finish();
        }
    }



    /**
     * 获取相机返回照片
     * @param file
     */
    @Override
    public void onCaremaSelectedFile(File file) {
        if(file!=null){
            switch (mPhotoFlag){
                case 0:
                    mFrontIdCardFile = file;
                    lt_idcard_front.setVisibility(View.VISIBLE);
                    lt_idcard_front.setImageURI(Uri.fromFile(file));
                    lt_hospital_deletefront.setVisibility(View.VISIBLE);
                    checkButton();
                    break;
                case 1:
                    mReverseIdCardFile = file;
                    lt_idcard_reverse.setVisibility(View.VISIBLE);
                    lt_idcard_reverse.setImageURI(Uri.fromFile(file));
                    lt_hospital_deletereverse.setVisibility(View.VISIBLE);
                    checkButton();
                    break;
            }
        }
    }

    /**
     * 显示大图页
     * @param filepath  图片路径
     * @param filename 图片标题
     * @param flag 显示的方式（网络1、本地0）
     */
    private void startShowPictureActivity(String filepath,String filename,int  flag){
        intent.setFlags(flag);
        intent.putExtra("FILE_PATH", filepath);
        intent.putExtra("PICTURE_NAME", filename);
        intent.setClass(LT_IDCardEditorActivity.this,SX_ShowPictureActivity.class);
        myStartActivity(intent);
    }

    /**
     * dialog初始化
     */
    private void initDialog(){
        int srceenW =  this.getWindowManager().getDefaultDisplay().getWidth();
        mUploadDialog = new ConfirmDialog(LT_IDCardEditorActivity.this, srceenW,245
                , R.layout.xc_l_pop_window_photo,R.style.xc_s_dialog);
        mUploadDialog.setCanceledOnTouchOutside(false);
        Window window = mUploadDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        xc_id_pop_photoUpload = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_photoUpload);
        xc_id_pop_localAlbum = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_localAlbum);
        xc_id_pop_cancel = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_cancel);
        xc_id_pop_photoUpload.setOnClickListener(this);
        xc_id_pop_localAlbum.setOnClickListener(this);
        xc_id_pop_cancel.setOnClickListener(this);
    }


    private void checkButton(){
        lt_idcard_ok.setEnabled(true);
        String newIdcardnum = lt_idcard_input.getText().toString().replace(" ","");
        if(lt_idcard_front.getVisibility()==View.VISIBLE&&lt_idcard_reverse.getVisibility()==View.VISIBLE && newIdcardnum.length()>=18){
            lt_idcard_ok.setTextColor(getResources().getColor(R.color.c_e2231a));
        }else {
            lt_idcard_ok.setTextColor(getResources().getColor(R.color.c_login_text_bg));
        }
    }
    private void uploadDialogDismiss(){
        if(null != mUploadDialog && mUploadDialog.isShowing()){
            mUploadDialog.dismiss();
        }
    }

    private void uploadDialogShow(){
        if(null != mUploadDialog && !mUploadDialog.isShowing()){
            mUploadDialog.show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(null);
        UtilViewShow.destoryDialogs(mUploadDialog);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        //用户选择图片完成 add by xd 2017/11/27
        if (requestCode == YY_SelectImgsActivity.REQUEST_IMAGE) {
            if (data == null || data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT) == null) {
                return;
            }
            File file = (File) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
            if (file != null) {
                File toUploadFile = UtilFile.ChangeImgsToUploadFile(file);//压缩图片
                switch (mPhotoFlag){
                    case 0:
                        mFrontIdCardFile = toUploadFile;
                        lt_idcard_front.setVisibility(View.VISIBLE);
                        lt_idcard_front.setImageURI(Uri.fromFile(toUploadFile));
                        lt_hospital_deletefront.setVisibility(View.VISIBLE);
                        checkButton();
                        break;
                    case 1:
                        mReverseIdCardFile = toUploadFile;
                        lt_idcard_reverse.setVisibility(View.VISIBLE);
                        lt_idcard_reverse.setImageURI(Uri.fromFile(toUploadFile));
                        lt_hospital_deletereverse.setVisibility(View.VISIBLE);
                        checkButton();
                        break;
                }
            }
        }
    }
}
