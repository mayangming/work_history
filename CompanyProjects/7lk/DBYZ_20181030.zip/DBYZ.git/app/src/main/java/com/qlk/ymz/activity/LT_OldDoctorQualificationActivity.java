package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.fragment.XCCameraPhotoFragment;

import java.io.File;
/**
 * @author 李涛
 * @description 旧版医生资格证页面
 * @Date 2017/11/21.
 */
public class LT_OldDoctorQualificationActivity extends DBActivity implements XCCameraPhotoFragment.OnCaremaSelectedFileListener{
    /**
     * 医生合法备案状态（0 未申请备案; 1 备案审核中;2 备案成功; 3 备案失败; 4 要求备案）
     */
    private String viewFlag;
    private XCTitleCommonLayout lt_id_dq_titlebar;
    /** 资格证正面View布局*/
    private RelativeLayout lt_image_up_view;
    /** 资格证正面照片*/
    private ImageView lt_image_up;
    /** 资格证背面View布局*/
    private RelativeLayout lt_image_down_view;
    /** 资格证背面照片*/
    private ImageView lt_image_down;
    /** 资格证提交按钮布局*/
    private RelativeLayout lt_commit_bt_view;
    /** 资格证提交按钮文案*/
    private TextView lt_commit_text;
    private XCCameraPhotoFragment cameraPhotoFragment;
    /**
     * 相机相册返回的图片标记
     */
    private int mPhotoFlag = 0;
    /**
     * 上传文件弹出Dialog
     */
    private ConfirmDialog mUploadDialog;
    private TextView xc_id_pop_photoUpload;//照相机
    private TextView xc_id_pop_localAlbum;//图库
    private TextView xc_id_pop_cancel;//取消
    /**删除正面照片*/
    private ImageView lt_delete_up;
    /**删除背面照片*/
    private ImageView lt_delete_down;
    /**相册相机返回照片*/
    private File upFile;
    private File downFile;
    /**跳转大图页*/
    private Intent intent;
    private Intent backIntent;

    private Handler handler =  new Handler(Looper.getMainLooper());
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lt__old_doctor_qualification);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(LT_OldDoctorQualificationActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    private void initData() {
          backIntent = getIntent();
           upFile = (File) backIntent.getSerializableExtra("oldupimage");
           downFile = (File) backIntent.getSerializableExtra("olddownimage");

        //刚进入该页面的时候 如果携带数据我们就让他底部提交按钮置灰  修改完数据后变得可点击操作   （使用延迟操作是应为该页面有一个Editext的监听）
        //(如果数据不为空说明 1 有后台操作上传一部分数据  2是审核状态    3是审核失败状态  提交按钮都是置灰不可点击的)
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(upFile!=null&&downFile!=null){
                    lt_commit_text.setTextColor(getResources().getColor(R.color.c_login_text_bg));
                    lt_commit_bt_view.setEnabled(false);
                }
            }
        },100);

        viewFlag = UtilSP.getDoctorStatus();
        //未备案
        if("4".equals(viewFlag)){
            viewFlag ="0";
        }
        switch (viewFlag){
            case "0":
             if(upFile!=null){
                 lt_image_up.setVisibility(View.VISIBLE);
                 lt_delete_up.setVisibility(View.VISIBLE);
                 lt_image_up.setImageURI(Uri.fromFile(upFile));
             }
             if(downFile!=null){
                 lt_image_down.setVisibility(View.VISIBLE);
                 lt_delete_down.setVisibility(View.VISIBLE);
                 lt_image_down.setImageURI(Uri.fromFile(downFile));
             }

                break;
             //审核中
            case "1":
                if(upFile!=null&&downFile!=null){
                    lt_image_up.setVisibility(View.VISIBLE);
                    lt_image_up.setImageURI(Uri.fromFile(upFile));
                    lt_delete_up.setVisibility(View.VISIBLE);
                    lt_image_down.setVisibility(View.VISIBLE);
                    lt_image_down.setImageURI(Uri.fromFile(downFile));
                    lt_delete_up.setVisibility(View.GONE);
                    lt_delete_down.setVisibility(View.GONE);
                    lt_commit_bt_view.setEnabled(false);
                    lt_commit_text.setTextColor(getResources().getColor(R.color.c_login_text_bg));
                }
                break;
                //审核失败
            case "3":
                if(upFile!=null&&downFile!=null){
                    lt_image_up.setVisibility(View.VISIBLE);
                    lt_image_up.setImageURI(Uri.fromFile(upFile));
                    lt_image_down.setVisibility(View.VISIBLE);
                    lt_image_down.setImageURI(Uri.fromFile(downFile));
                    lt_commit_bt_view.setEnabled(false);
                    lt_delete_up.setVisibility(View.VISIBLE);
                    lt_delete_down.setVisibility(View.VISIBLE);
                    lt_commit_text.setTextColor(getResources().getColor(R.color.c_login_text_bg));
                }
                break;
        }
    }

    @Override
    public void initWidgets() {
        initDialog();
        intent = new Intent();
        cameraPhotoFragment = new XCCameraPhotoFragment();
        addFragment(R.id.lt_id_openshop_camera_rl, cameraPhotoFragment);

        //设置Title
        lt_id_dq_titlebar = (XCTitleCommonLayout) findViewById(R.id.lt_old_doctorqf_titlebar);
        lt_id_dq_titlebar.setTitleLeft(true,"");
        lt_id_dq_titlebar.setTitleCenter(true,"旧版医师资格证");


        lt_image_up_view = (RelativeLayout) findViewById(R.id.lt_id_upload_doctor_practice_certificate_old_pic_rl);
        lt_image_up = (ImageView) findViewById(R.id.lt_id_upload_doctor_practice_certificate_old_pic_show);
        lt_delete_up = (ImageView) findViewById(R.id.lt_id_delete_doctor_practice_certificate_old_pic);
        lt_image_down_view = (RelativeLayout) findViewById(R.id.lt_id_upload_doctor_practice_certificate_old_info_rl);
        lt_image_down = (ImageView) findViewById(R.id.lt_id_upload_doctor_practice_certificate_old_info_show);
        lt_delete_down = (ImageView) findViewById(R.id.lt_id_delete_doctor_practice_certificate_old_info);
        lt_commit_bt_view = (RelativeLayout) findViewById(R.id.lt_id_doctor_practice_certificate_old_submit_authentication_rl);
        lt_commit_text = (TextView) findViewById(R.id.lt_id_save_text);

    }

    @Override
    public void listeners() {
        lt_image_up_view.setOnClickListener(this);
        lt_image_up.setOnClickListener(this);
        lt_image_down_view.setOnClickListener(this);
        lt_image_down.setOnClickListener(this);
        lt_commit_bt_view.setOnClickListener(this);
        lt_delete_up.setOnClickListener(this);
        lt_delete_down.setOnClickListener(this);
        cameraPhotoFragment.setOnCaremaSelectedFileListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()){
            //正面布局View
            case R.id.lt_id_upload_doctor_practice_certificate_old_pic_rl:
                mPhotoFlag = 0;
                uploadDialogShow();
                break;
            //正面布局ImageView
            case R.id.lt_id_upload_doctor_practice_certificate_old_pic_show:
                String upFilePath = upFile.getAbsolutePath();
                startShowPictureActivity(upFilePath,"旧版医师执业证",0);
                break;
                //删除正面照片
            case R.id.lt_id_delete_doctor_practice_certificate_old_pic:
                    upFile=null;
                    lt_image_up.setVisibility(View.GONE);
                    lt_delete_up.setVisibility(View.GONE);
                    lt_image_up.setImageURI(null);
                    checkButton();
                break;

            //背面布局View
            case R.id.lt_id_upload_doctor_practice_certificate_old_info_rl:
                mPhotoFlag = 1;
                uploadDialogShow();
                break;
            //背面布局ImageView
            case R.id.lt_id_upload_doctor_practice_certificate_old_info_show:
                String downFilePath = downFile.getAbsolutePath();
                startShowPictureActivity(downFilePath,"旧版医师执业证",0);
                break;
            //删除背面照片
            case R.id.lt_id_delete_doctor_practice_certificate_old_info:
                lt_delete_down.setVisibility(View.GONE);
                lt_image_down.setVisibility(View.GONE);
                lt_image_down.setImageURI(null);
                checkButton();
                break;
            //提交按钮
            case R.id.lt_id_doctor_practice_certificate_old_submit_authentication_rl:
                checkData();
                break;
            case R.id.xc_id_pop_photoUpload:
                //跳转---》相机
                uploadDialogDismiss();
                cameraPhotoFragment.getTakePhoto();
                break;
            case R.id.xc_id_pop_localAlbum:
                //跳转--》相册
                uploadDialogDismiss();
                ToJumpHelp.toJumpSelctImgsActivity(this, 1, YY_SelectImgsActivity.MODE_SINGLE,
                        false, true, false, true);
                break;
            case R.id.xc_id_pop_cancel:
                //取消--》弹窗
                uploadDialogDismiss();
                break;
        }
    }



    @Override
    public void onCaremaSelectedFile(File file) {
                if(file!=null){
                    switch (mPhotoFlag){
                        case 0:
                            upFile = file;
                            lt_image_up.setVisibility(View.VISIBLE);
                            lt_delete_up.setVisibility(View.VISIBLE);
                            lt_image_up.setImageURI(Uri.fromFile(file));
                            checkButton();
                            break;
                        case 1:
                            downFile = file;
                            lt_image_down.setVisibility(View.VISIBLE);
                            lt_delete_down.setVisibility(View.VISIBLE);
                            lt_image_down.setImageURI(Uri.fromFile(file));
                            checkButton();
                            break;
                    }
                }
    }

    /***
     * 检测提交按钮的状态
     */
    private void checkButton(){
        lt_commit_bt_view.setEnabled(true);
        if(upFile!=null&&downFile!=null){
            lt_commit_text.setTextColor(getResources().getColor(R.color.c_e2231a));
        }else{
            lt_commit_text.setTextColor(getResources().getColor(R.color.c_login_text_bg));
        }
    }


    private void checkData(){
        if(upFile==null||downFile==null){
            shortToast("你好像还没有上传图片");
            return;
        }  if(upFile!=null&&downFile!=null){
            backIntent.putExtra("backOldUpImage",upFile);
            backIntent.putExtra("backOldDownImage",downFile);
            setResult(RESULT_OK,backIntent);
            finish();
        }
    }


    /**
     * 显示大图页
     * @param filepath  图片路径
     * @param filename 图片标题
     * @param flag 显示的方式（网络1、本地0）
     */
    private void startShowPictureActivity(String filepath,String filename,int  flag){
        intent.setFlags(flag);
        intent.putExtra("FILE_PATH", filepath);
        intent.putExtra("PICTURE_NAME", filename);
        intent.setClass(LT_OldDoctorQualificationActivity.this,SX_ShowPictureActivity.class);
        myStartActivity(intent);
    }


    @Override
    public void onNetRefresh() {}


    /**
     * dialog初始化
     */
    private void initDialog(){
        int srceenW =  this.getWindowManager().getDefaultDisplay().getWidth();
        mUploadDialog = new ConfirmDialog(LT_OldDoctorQualificationActivity.this, srceenW,245
                , R.layout.xc_l_pop_window_photo,R.style.xc_s_dialog);
        mUploadDialog.setCanceledOnTouchOutside(false);
        Window window = mUploadDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        xc_id_pop_photoUpload = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_photoUpload);
        xc_id_pop_localAlbum = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_localAlbum);
        xc_id_pop_cancel = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_cancel);
        xc_id_pop_photoUpload.setOnClickListener(this);
        xc_id_pop_localAlbum.setOnClickListener(this);
        xc_id_pop_cancel.setOnClickListener(this);
    }

    private void uploadDialogDismiss(){
        if(null != mUploadDialog && mUploadDialog.isShowing()){
            mUploadDialog.dismiss();
        }
    }

    private void uploadDialogShow(){
        if(null != mUploadDialog && !mUploadDialog.isShowing()){
            mUploadDialog.show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        //用户选择图片完成 add by xd 2017/11/27
        if (requestCode == YY_SelectImgsActivity.REQUEST_IMAGE) {
            if (data == null || data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT) == null) {
                return;
            }
            File file = (File) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
            if (file != null) {
                File toUploadFile = UtilFile.ChangeImgsToUploadFile(file);//压缩图片
                switch (mPhotoFlag){
                    case 0:
                        upFile = toUploadFile;
                        lt_image_up.setVisibility(View.VISIBLE);
                        lt_delete_up.setVisibility(View.VISIBLE);
                        lt_image_up.setImageURI(Uri.fromFile(toUploadFile));
                        checkButton();
                        break;
                    case 1:
                        downFile = toUploadFile;
                        lt_image_down.setVisibility(View.VISIBLE);
                        lt_delete_down.setVisibility(View.VISIBLE);
                        lt_image_down.setImageURI(Uri.fromFile(toUploadFile));
                        checkButton();
                        break;
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(null);
    }
}
