package com.qlk.ymz.adapter;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.YY_SelectImgsActivity;
import com.qlk.ymz.util.ToJumpHelp;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2018/5/28.
 */

public class ImageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private OnItemClickListener mOnItemClickListener;
    /** 图片集合*/
    private List<String> mImageList = new ArrayList<>();

    public ImageAdapter(Context context, List<String> mImageList){
        this.mContext = context;
        this.mImageList = mImageList;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_image, parent,
                false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        ViewHolder viewHolder = (ViewHolder) holder;
        if(mImageList.get(position).toLowerCase().startsWith("http")){
            XCApplication.displayImage(mImageList.get(position),viewHolder.iv_image);
        }else {
            XCApplication.displayImage("file://" +mImageList.get(position), viewHolder.iv_image);
        }
        viewHolder.iv_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mOnItemClickListener!=null){
                    mOnItemClickListener.onItemClick(position);
                }
            }
        });

    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        mOnItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener{
        void onItemClick(int position);
    }

    @Override
    public int getItemCount() {
        return mImageList.size();
    }


    static class ViewHolder extends RecyclerView.ViewHolder {
        /** 图片*/
        ImageView iv_image;

        public ViewHolder(View itemView) {
            super(itemView);
            iv_image = (ImageView) itemView.findViewById(R.id.iv_image);
        }
    }
}
