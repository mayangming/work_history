package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;

public class ExamineHolder {
    /**
     * 检查缩略图
     */
    public ImageView sk_id_examine_item_img;
    /**
     * 检查名称
     */
    public TextView sk_id_examine_name;
    /**
     * 价格
     */
    public TextView sk_id_examine_item_pprice;
    /**
     * 选择按钮
     */
    public Button sk_id_examine_cb;
    /**
     * 小七指数
     */
    public TextView sk_id_medicine_drcommission;
    /**
     * 底部布局
     */
    public LinearLayout sk_id_examine_item_footerView;

    public ExamineHolder(View convertView) {
        sk_id_examine_item_footerView = (LinearLayout) convertView.findViewById(R.id.sk_id_examine_item_footerView);
        sk_id_examine_item_img = (ImageView) convertView.findViewById(R.id.sk_id_examine_item_img);
        sk_id_examine_name = (TextView) convertView.findViewById(R.id.sk_id_examine_name);
        sk_id_examine_item_pprice = (TextView) convertView.findViewById(R.id.sk_id_examine_item_pprice);
        sk_id_examine_cb = (Button) convertView.findViewById(R.id.sk_id_examine_cb);
        sk_id_medicine_drcommission = (TextView) convertView.findViewById(R.id.sk_id_medicine_drcommission);

    }
}
