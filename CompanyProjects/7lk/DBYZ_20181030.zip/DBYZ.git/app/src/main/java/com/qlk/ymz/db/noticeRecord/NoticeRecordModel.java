package com.qlk.ymz.db.noticeRecord;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;

/**
 * 公告操作记录数据库BEAN
 * @author zhangpengfei
 * @version 2.3.0
 */
public class NoticeRecordModel implements Serializable {
    /**删除公告*/
    public static final String NOTICE_RECORE_DELETE = "1";
    /**公告正常*/
    public static final String NOTICE_RECORE_NORMAL = "0";
    /** 医生id */
    public String doctorSelfId = "";
    /** 公告类型 */
    public String topic = "";
    /** 最新时间 */
    public String time = "";
    /** 删除时间 */
    public String deleteTime = "";
    /** 公告状态 0 正常 1删除 */
    public String state = "0";
    /** 弹性域1 */
    public String back1 = "";
    /** 弹性域2 */
    public String back2 = "";
    /** 弹性域3 */
    public String back3 = "";
    /** 弹性域4 */
    public String back4 = "";
    /** 弹性域5 */
    public String back5 = "";
    /** 弹性域6 */
    public String back6 = "";
    /** 弹性域7 */
    public String back7 = "";
    /** 弹性域8 */
    public String back8 = "";
    /** 弹性域9 */
    public String back9 = "";
    /** 弹性域10 */
    public String back10 = "";
    /** 弹性域11 */
    public String back11 = "";
    /** 弹性域12 */
    public String back12 = "";
    /** 弹性域13 */
    public String back13 = "";
    /** 弹性域14 */
    public String back14 = "";
    /** 弹性域15 */
    public String back15 = "";
    /** 弹性域16 */
    public String back16 = "";
    /** 弹性域17 */
    public String back17 = "";
    /** 弹性域18 */
    public String back18 = "";
    /** 弹性域19 */
    public String back19 = "";
    /** 弹性域20 */
    public String back20 = "";

    public String getDeleteTime() {
        return deleteTime;
    }

    public void setDeleteTime(String deleteTime) {
        this.deleteTime = deleteTime;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        if (!UtilString.isBlank(state)){
            this.state = state;
        }
    }

    public String getDoctorSelfId() {
        return doctorSelfId;
    }

    public void setDoctorSelfId(String doctorSelfId) {
        this.doctorSelfId = doctorSelfId;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        if (!UtilString.isBlank(time)){
            this.time = time;
        }
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        if (!UtilString.isBlank(topic)){
            this.topic = topic;
        }
    }

    public String getBack1() {
        return back1;
    }

    public void setBack1(String back1) {
        this.back1 = back1;
    }

    public String getBack2() {
        return back2;
    }

    public void setBack2(String back2) {
        this.back2 = back2;
    }

    public String getBack3() {
        return back3;
    }

    public void setBack3(String back3) {
        this.back3 = back3;
    }

    public String getBack4() {
        return back4;
    }

    public void setBack4(String back4) {
        this.back4 = back4;
    }

    public String getBack5() {
        return back5;
    }

    public void setBack5(String back5) {
        this.back5 = back5;
    }

    public String getBack6() {
        return back6;
    }

    public void setBack6(String back6) {
        this.back6 = back6;
    }

    public String getBack7() {
        return back7;
    }

    public void setBack7(String back7) {
        this.back7 = back7;
    }

    public String getBack8() {
        return back8;
    }

    public void setBack8(String back8) {
        this.back8 = back8;
    }

    public String getBack9() {
        return back9;
    }

    public void setBack9(String back9) {
        this.back9 = back9;
    }

    public String getBack10() {
        return back10;
    }

    public void setBack10(String back10) {
        this.back10 = back10;
    }

    public String getBack11() {
        return back11;
    }

    public void setBack11(String back11) {
        this.back11 = back11;
    }

    public String getBack12() {
        return back12;
    }

    public void setBack12(String back12) {
        this.back12 = back12;
    }

    public String getBack13() {
        return back13;
    }

    public void setBack13(String back13) {
        this.back13 = back13;
    }

    public String getBack14() {
        return back14;
    }

    public void setBack14(String back14) {
        this.back14 = back14;
    }

    public String getBack15() {
        return back15;
    }

    public void setBack15(String back15) {
        this.back15 = back15;
    }

    public String getBack16() {
        return back16;
    }

    public void setBack16(String back16) {
        this.back16 = back16;
    }

    public String getBack17() {
        return back17;
    }

    public void setBack17(String back17) {
        this.back17 = back17;
    }

    public String getBack18() {
        return back18;
    }

    public void setBack18(String back18) {
        this.back18 = back18;
    }

    public String getBack19() {
        return back19;
    }

    public void setBack19(String back19) {
        this.back19 = back19;
    }

    public String getBack20() {
        return back20;
    }

    public void setBack20(String back20) {
        this.back20 = back20;
    }

    @Override
    public String toString() {
        return "NoticeRecordModel{" +
                "deleteTime='" + deleteTime + '\'' +
                ", doctorSelfId='" + doctorSelfId + '\'' +
                ", state='" + state + '\'' +
                ", time='" + time + '\'' +
                ", topic='" + topic + '\'' +
                '}';
    }
}
