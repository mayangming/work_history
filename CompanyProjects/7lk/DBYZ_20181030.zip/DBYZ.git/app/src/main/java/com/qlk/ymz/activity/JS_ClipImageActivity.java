package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.qlk.ymz.R;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.clipimageview.ClipImageLayout;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.util.UtilFiles;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * 裁剪图片页
 * @author 徐金山
 * @version 1.5.0
 */
public class JS_ClipImageActivity extends Activity {
    public static String CLIPHEAD_NAME = "clipHead.jpg";
    /** 要裁剪的图片（对应的byte数组类型内容） */
    private byte[] clipImageByteData = null;
    /** 要裁剪的图片（对应的file类型内容） */
    private File clipImageFile = null;

    /** 显示裁剪图片的布局 */
    private ClipImageLayout clLayout_clipImageLayout;
    /** 取消按钮 */
    private RelativeLayout rel_cancel;
    /** 选取按钮 */
    private RelativeLayout rel_select;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.js_activity_clip_image);

        getInitData();
        findViews();
        setListener();
        processBiz();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(JS_ClipImageActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    private void getInitData() {
        Intent intent = getIntent();
        clipImageByteData = intent.getByteArrayExtra("bitmap");
        clipImageFile = (File)(intent.getSerializableExtra("file"));

    }

    private void findViews() {
        clLayout_clipImageLayout = (ClipImageLayout) findViewById(R.id.clLayout_clipImageLayout);
        rel_cancel = (RelativeLayout) findViewById(R.id.rel_cancel);
        rel_select = (RelativeLayout) findViewById(R.id.rel_select);
    }

    private void setListener() {
        // 点击“取消”按钮的监听
        rel_cancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

        // 点击“选取”按钮的监听
        rel_select.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Bitmap bitmap = clLayout_clipImageLayout.clip();

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] datas = baos.toByteArray();


                //截取头像后改为存放在本地
                if(null != datas) {
                    try {
                        Bitmap clipBitmap = BitmapFactory.decodeByteArray(datas, 0, datas.length);
                        File file = UtilFiles.createFileInAndroid(XCConfig.CHAT_PHOTO_DIR, JS_ClipImageActivity.CLIPHEAD_NAME, JS_ClipImageActivity.this);
                        saveImage2File(file,clipBitmap);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                /*Intent intent = new Intent();
                intent.putExtra("bitmap", datas);
                setResult(1, intent);*/
                setResult(1);
                finish();

                // 以下是测试时用的代码
//                Intent intent = new Intent(JS_ClipImageActivity.this, JS_ShowImageActivity.class);
//                intent.putExtra("bitmap", datas);
//                startActivity(intent);
            }
        });
    }

    private void processBiz() {
        Bitmap clipImageBitmap = null;

//        Bitmap temp_clipImageBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.img01);
//        clLayout_clipImageLayout.setClipImage(temp_clipImageBitmap);

        // 尝试读取图片
        if(null != clipImageByteData) {
            clipImageBitmap = BitmapFactory.decodeByteArray(clipImageByteData, 0, clipImageByteData.length);
            clLayout_clipImageLayout.setClipImage(clipImageBitmap);
        }else if(null != clipImageFile) {
            clipImageBitmap = BitmapFactory.decodeFile(clipImageFile.getAbsolutePath());
            clLayout_clipImageLayout.setClipImage(clipImageBitmap);
        }else {
            // 设置默认图片
            Toast.makeText(JS_ClipImageActivity.this, "获取图片失败", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void saveImage2File(File file,Bitmap bitmap) {
        FileOutputStream fos = null;
        try {
            if(null != bitmap) {
                fos = new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            }
        }catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != fos) {
                try {
                    fos.close();
                    if(null != bitmap){
                        bitmap.recycle();
                        bitmap = null;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }




        }
    }

}
