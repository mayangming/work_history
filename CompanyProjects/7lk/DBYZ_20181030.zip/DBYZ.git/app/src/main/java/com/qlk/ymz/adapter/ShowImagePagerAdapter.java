package com.qlk.ymz.adapter;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;

import java.util.ArrayList;

/**
 * @description 显示大图页适配器
 * @author 徐金山
 * @version 1.2.0
 */
public class ShowImagePagerAdapter extends PagerAdapter {
    private ArrayList<View> views;

    /**
     * 构造方法
     * @param views 控件
     */
    public ShowImagePagerAdapter(ArrayList<View> views) {
        this.views = views;
    }

    public int getCount() {
        return views.size();
    }

    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    public void destroyItem(View container, int position, Object object) {
        ((ViewPager) container).removeView(views.get(position));
    }

    // 页面view
    public Object instantiateItem(View container, int position) {
        ((ViewPager) container).addView(views.get(position));
        return views.get(position);
    }
}
