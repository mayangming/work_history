package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.List;

/**
 * @description 快捷回复列表页面
 * @author 赖善琦
 * @version 2.0.0
 */
public class SK_QuickReplyActivity extends SK_BaseChoiceAllActivityV2 {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onStart() {
        super.onStart();
        setBeanId("id");
        requestQuickReplyList();
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(SK_QuickReplyActivity.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    /**
     * 初始化快捷回复列表项的点击事件
     */
    @Override
    public void initChioseItemListenr() {
        listViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                XCJsonBean bean = (XCJsonBean) arg0.getItemAtPosition(arg2);
                Intent it = new Intent();
                it.putExtra(CommonConfig.QUICK_REPLY_KEY, bean.getString("content"));
                setResult(Activity.RESULT_OK, it);
                myFinish();

            }
        });
    }

    /**
     * 初始化适配器
     */
    @Override
    public void initAdapter() {
        adapter = new QuickAdapter(this,dataList);
    }


    /**
     * 初始化选择状态的标题栏
     */
    @Override
    public void initChioseTitle() {
        titleCommonFragment.setTitleCenter(true,"快捷回复");
        if(dataList == null || dataList.size() < 1){
            titleCommonFragment.setTitleRight2(false,0,"编辑");
        }else{
            titleCommonFragment.setTitleRight2(true,0,"编辑");
        }
        sk_id_choise_add_tv.setText("添加快捷回复");
    }

    /**
     * 初始化编辑状态的标题
     */
    @Override
    public void initEditTitle() {
        titleCommonFragment.setTitleCenter(true,"编辑");
        titleCommonFragment.setTitleRight2(true, 0, "保存");

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.sk_id_add_rl:
                myStartActivity(SK_AddQuickReplyActivity.class);
                break;
        }
    }

    /**
     * 无网络背景的点击回调，重新请求数据
     */
    @Override
    public void onNetRefresh() {
        requestQuickReplyList();
    }

    /**
     * 请求快捷回复的列表数据接口
     */
    public void requestQuickReplyList(){
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.quickreply_list),  new RequestParams(), new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    listViewFragment.setBgZeroHintInfo("无快捷回复记录","",R.mipmap.js_d_icon_no_data);
                    initData(result_bean.getList("data"));
                    initChioseTitle();
                }
            }
            @Override
            public void onFinish() {
                super.onFinish();
                if (listViewFragment != null) {
                    listViewFragment.doRefreshComplete();
                }
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SK_QuickReplyActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });

    }

    /**
     * 点击完删除按钮会调此方法，请求删除接口
     */
    @Override
    public void requestCommit() {
        // 检查有没有选择一项
        if(UtilString.isBlank(ids)) {
            shortToast("请选择删除至少一个的分组");
            return;
        }
        ids = ids.substring(0,ids.length()-1) + "";
        requestQuickReplyDelete(ids + "");
    }

    /**
     * 请求删除快捷回复的接口
     * @param id 要删除的id
     */
    public void requestQuickReplyDelete(String id){
        RequestParams params = new RequestParams();
        params.put("ids",id);

        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.quickreply_remove),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean){
                    shortToast("删除成功");
                    SK_QuickReplyActivity.super.requestCommit();
                    requestQuickReplyList();
                    initChioseTitle();
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SK_QuickReplyActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }

        });

    }

    /**
     * 快捷回复列表的适配器
     */
    class QuickAdapter extends SK_BaseChoiseAdapter {

        public QuickAdapter(Context context, List<XCJsonBean> list) {
            super(context, list);
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            XCJsonBean bean = list.get(i);
            ViewHolder holder = null;

            if(view == null){
                view = LayoutInflater.from(context).inflate(R.layout.sk_l_adapter_reply_item,null);
                holder = new ViewHolder();
                holder.contentTv = (TextView)view.findViewById(R.id.sk_id_reply_content_tv);
                holder.checkBox = (CheckBox)view.findViewById(R.id.sk_id_reply_cb);
                holder.v_bottom_line = view.findViewById(R.id.v_bottom_line);
                holder.v_bottom = view.findViewById(R.id.v_bottom);
                view.setTag(holder);
            }else{
                holder = (ViewHolder) view.getTag();
            }
            // 设置底部分割线，如果是当前字母最后一个则隐藏,最后一个底部加一块，防止按钮挡住
            if (list.size() - 1 == i) {
                holder.v_bottom_line.setVisibility(View.GONE);
                holder.v_bottom.setVisibility(View.VISIBLE);
            } else {
                holder.v_bottom_line.setVisibility(View.VISIBLE);
                holder.v_bottom.setVisibility(View.GONE);
            }

            holder.contentTv.setText(bean.getString("content"));
            holder.checkBox.setVisibility(View.VISIBLE);

            initCheckBox(bean,holder.checkBox);

            return view;
        }


    }
}
