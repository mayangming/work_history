package com.qlk.ymz.db.selfdomInfo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.qlk.ymz.model.DoctorSelfdomInfoBean;

/**
 * 医生相关的个性化信息数据库
 * @author 徐金山
 * @version 2.5.0
 */
public class DoctorSelfdomInfoDB {
    /** 上下文对象 */
    private Context context = null;
    /** 数据库对象 */
    private SQLiteDatabase db = null;
    /** 数据库处理对象 */
    private static DoctorSelfdomInfoDB dbProcessObj = null;

    // ==========数据库表结构相关数据==========
    /** 数据库版本号 */
    private final int DB_VERSION = 1;
    /** 数据库名 */
    private final static String DATABASE_NAME = "db_doctorSelfdomInfo";

    // 病情备注信息表
    /** 病情备注信息表名 */
    private static final String TB_NAME_DOCTOR_SELFDOM_INFO = "table_doctorSelfdomInfo";
    /** 主键 */
    private static final String F_ID = "_id";
    /** 医生id */
    public static final String F_DOCTOR_ID = "doctorId";
    /** 医生已经看过的浮层图id信息（各id间使用","分隔） */
    public static final String F_LOOKED_LAYER_IMAGE = "lookedLayerImage";

    /**
     * 数据库助手类
     */
    private class DbHelper extends SQLiteOpenHelper {
        /**
         * 构造方法
         * @param context 上下文对象
         */
        public DbHelper(Context context) {
            super(context, DATABASE_NAME, null, DB_VERSION);
        }

        /**
         * 初始化数据库
         * @param db 数据库对象
         */
        public void onCreate(SQLiteDatabase db) {
            // sql文
            String sql = new String();

            // 创建“咨询列表信息表”
            sql = "create table " + TB_NAME_DOCTOR_SELFDOM_INFO +
                    "(" +
                    F_ID + " integer primary key AUTOINCREMENT," +
                    F_DOCTOR_ID + " text, " +
                    F_LOOKED_LAYER_IMAGE + " text" +
                    ")";
            db.execSQL(sql);
        }

        /**
         * 更新数据库
         * @param db 数据库对象
         * @param oldVersion 数据库的旧版本号
         * @param newVersion 数据库的新版本号
         */
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            if(newVersion > oldVersion) {
                db.execSQL("drop table if exists " + TB_NAME_DOCTOR_SELFDOM_INFO);
                onCreate(db);
            }
        }
    }

    /**
     * 构造方法
     * @param context 上下文
     */
    private DoctorSelfdomInfoDB(Context context) {
        this.context = context;
    }

    /**
     * 获取数据库适配器对象
     * @param context 上下文对象
     * @return 数据库处理对象
     */
    public static DoctorSelfdomInfoDB getInstance(Context context) {
        if(null == dbProcessObj) {
            dbProcessObj = new DoctorSelfdomInfoDB(context);
        }
        return dbProcessObj.openDataBase(context);
    }

    /**
     * 获取数据库操作权限
     * @param context 上下文对象
     * @return 数据库操作操作对象
     */
    private DoctorSelfdomInfoDB openDataBase(Context context) {
        DbHelper dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
        return dbProcessObj;
    }

    /**
     * 关闭数据库
     */
    private void closeDataBase() {
        try {
            if(null != db && db.isOpen()) {
                db.close();
            }
        }catch(Exception e) {
            System.out.println("---close database happened exception---");
            e.printStackTrace();
        }
    }

    /**
     * 保存医生看过的浮层图片的ID
     * @param doctorId 医生ID
     * @param layerImageId 浮层图片ID
     * @return 被操作记录的主键。当发生错误时，返回-1。
     */
    public long insertLookedLayerImage(String doctorId, String layerImageId) {
        // 行记录的主键值
        long rowId = -1;
        // 查询旧值信息的游标
        Cursor queryCursor = null;

        try {
            if(null == doctorId || null == layerImageId) {
                return rowId;
            }

            String[] columns = new String[]{F_ID, F_LOOKED_LAYER_IMAGE};
            String queryClause = F_DOCTOR_ID + "=?"; // 查询条件
            String[] queryClauseParamStrings = new String[]{doctorId}; // 查询条件的参数值
            queryCursor = db.query(TB_NAME_DOCTOR_SELFDOM_INFO, columns, queryClause, queryClauseParamStrings, null, null, null);

            // 已看过的浮层图片的id信息
            String lookedLayerImage = "";
            // 判断数据库中是否有医生个性化记录的标识（true：有；false：没有）
            boolean flag = queryCursor.moveToNext();
            if(flag) {
                rowId = queryCursor.getLong(queryCursor.getColumnIndex(F_ID));
                lookedLayerImage = queryCursor.getString(queryCursor.getColumnIndex(F_LOOKED_LAYER_IMAGE)).trim();
                if(lookedLayerImage.length() == 0) {
                    lookedLayerImage = layerImageId;
                }else {
                    lookedLayerImage = lookedLayerImage + "," + layerImageId;
                }
            }else {
                lookedLayerImage = layerImageId;
            }

            if(flag) {
                String updateClause;
                String[] updateClauseParamStrings;
                ContentValues contentValues  = new ContentValues();

                updateClause = F_DOCTOR_ID + "=?"; // 更新条件
                updateClauseParamStrings = new String[]{doctorId}; // 更新条件的参数值
                contentValues.put(F_LOOKED_LAYER_IMAGE, lookedLayerImage);

                int numberOfRowsAffected = db.update(TB_NAME_DOCTOR_SELFDOM_INFO, contentValues, updateClause, updateClauseParamStrings);
                if(numberOfRowsAffected == 0) {
                    rowId = -1;
                }
            }else {
                ContentValues contentValuesObj = new ContentValues();
                contentValuesObj.put(F_DOCTOR_ID, doctorId);
                contentValuesObj.put(F_LOOKED_LAYER_IMAGE, lookedLayerImage);
                rowId = db.insert(TB_NAME_DOCTOR_SELFDOM_INFO, F_ID, contentValuesObj);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            if(null != queryCursor) {
                queryCursor.close();
            }
            closeDataBase();
            return rowId;
        }
    }

    /**
     * 查询医生的个性化信息
     * @param doctorId 医生ID
     * @return 医生的个性化信息对象
     */
    public DoctorSelfdomInfoBean queryDoctorSelfdomInfo(String doctorId) {
        // 医生个性化信息对象
        DoctorSelfdomInfoBean doctorSelfdomInfoBeanObj = new DoctorSelfdomInfoBean();
        // 查询医生个性化信息的游标
        Cursor cursor = null;

        try {
            if(null == doctorId) {
                return doctorSelfdomInfoBeanObj;
            }

            String[] columns = null;
            String selection = F_DOCTOR_ID + "=?";
            String[] selectionArgs = new String[]{doctorId};
            cursor = db.query(TB_NAME_DOCTOR_SELFDOM_INFO, columns, selection, selectionArgs, null, null, null);

            if(cursor.moveToNext()) {
                doctorSelfdomInfoBeanObj = cursor2DoctorSelfdomInfoBean(cursor);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            if(null != cursor) {
                cursor.close();
            }

            closeDataBase();
            return doctorSelfdomInfoBeanObj;
        }
    }

    /**
     * 将cursor转化为业务信息bean
     * @param cursor 医生个性化信息游标对象
     * @return 医生个性化信息对象
     */
    private DoctorSelfdomInfoBean cursor2DoctorSelfdomInfoBean(Cursor cursor) {
        DoctorSelfdomInfoBean beanObj = new DoctorSelfdomInfoBean();
        beanObj.setDoctorId(cursor.getString(cursor.getColumnIndex(F_DOCTOR_ID))); // 医生ID
        beanObj.setLookedLayerImage(cursor.getString(cursor.getColumnIndex(F_LOOKED_LAYER_IMAGE))); // 医生已经看过的浮层图id信息（各id间使用","分隔）
        return beanObj;
    }
}
