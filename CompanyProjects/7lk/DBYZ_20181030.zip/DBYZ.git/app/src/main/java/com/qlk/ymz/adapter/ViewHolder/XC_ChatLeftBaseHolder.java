package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

/**
 * @author jingyu on 2016/6/24 15:34
 * @description
 */
public class XC_ChatLeftBaseHolder {
    /**
     * 患者头像
     */
    public XCRoundedImageView xc_id_adapter_left_head;
    /**
     * 时间
     */
    public TextView xc_id_adapter_left_time;

    public TextView chat_adapter_patient_notice_head;
    public XC_ChatLeftBaseHolder(View convertView) {
        xc_id_adapter_left_head = (XCRoundedImageView) convertView.findViewById(R.id.xc_id_adapter_left_head);
        xc_id_adapter_left_time = (TextView) convertView.findViewById(R.id.xc_id_adapter_left_time);
        chat_adapter_patient_notice_head = (TextView) convertView.findViewById(R.id.chat_adapter_patient_notice_head);
    }
}
