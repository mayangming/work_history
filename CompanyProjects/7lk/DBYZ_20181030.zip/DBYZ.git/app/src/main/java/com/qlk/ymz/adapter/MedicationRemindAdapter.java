package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.ReBuyNotic;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilChat;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import java.util.List;

/**
 * Created by xiedong on 2018/3/21.
 * 患者用药提醒适配器
 */

public class MedicationRemindAdapter extends XCBaseAdapter<ReBuyNotic> {

    public MedicationRemindAdapter(Context context, List<ReBuyNotic> list) {
        super(context, list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView != null) {
            viewHolder = (ViewHolder) convertView.getTag();
        } else {
            convertView =  LayoutInflater.from(context).inflate(R.layout.xd_item_patient_medication_remind,
                    null);
            viewHolder = ViewHolder.getViewHolder(convertView);
        }

        final ReBuyNotic reBuyNotic = list.get(position);
        //显示患者名字
        viewHolder.tv_patient_name.setText(reBuyNotic.getPatientName());
        //加载患者头像
        ImageAware imageAware = new ImageViewAware(viewHolder.iv_patient_head, false);
        String patientIcon = reBuyNotic.getHeadUrl();
        if (!TextUtils.isEmpty(patientIcon) && URLUtil.isValidUrl(patientIcon)) {
            XCApplication.displayImage(patientIcon, viewHolder.iv_patient_head, XCImageLoaderHelper
                    .getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default));
        } else {
            XCApplication.base_imageloader.displayImage("drawable://" + R.mipmap.xc_d_chat_patient_default, imageAware, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_patient_default));
        }
        //显示提醒信息
        viewHolder.tv_remind_msg.setText(reBuyNotic.getMedicationName()+" "
                +"将服用完");
        //v2.19  添加查询数据库判断患者是否已删除的逻辑
        viewHolder.tv_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                XC_ChatModel chatModel = JS_ChatListDB.getInstance(context, UtilSP.getUserId()).getPatientInfo(reBuyNotic.getPatientId());
                if (chatModel == null || chatModel.getUserPatient() == null || TextUtils.isEmpty(chatModel.getUserPatient().getPatientId())) {
                    Toast.makeText(context, "该患者已删除", Toast.LENGTH_SHORT).show();
                } else {
                    UtilChat.launchChatDetail((DBActivity) context,reBuyNotic.getPatientId(),reBuyNotic,null);
                }
            }
        });
        return convertView;
    }


    static class ViewHolder{
        //患者姓名
        TextView tv_patient_name;
        //患者头像
        XCRoundedImageView iv_patient_head;
        //发送消息按钮
        TextView tv_send;
        //提醒信息
        TextView tv_remind_msg;

        public ViewHolder(View convertView) {
            tv_patient_name = (TextView) convertView.findViewById(R.id.tv_patient_name);
            tv_send = (TextView) convertView.findViewById(R.id.tv_send);
            tv_remind_msg = (TextView) convertView.findViewById(R.id.tv_remind_msg);
            iv_patient_head = (XCRoundedImageView) convertView.findViewById(R.id.iv_patient_head);
        }

        public static ViewHolder getViewHolder(View convertview) {
            ViewHolder holder = (ViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new ViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }
}
