package com.qlk.ymz.fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.db.search.XCSearchRecordModel;
import com.qlk.ymz.db.search.XCSearchRecordModelDb;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;
import java.util.List;

/**
 * Created by songxin on 2015/6/18.
 *
 * SXTitleSearchFragment
 * 医院列表页面
 * @author  Changed by songxin on 2016/4/1.
 * @version 2.3
 */
public class SXTitleSearchFragment extends DBFragment {
    /** title左边图片*/
    private ImageView xc_id_titlebar_left_imageview;
    /** title输入框*/
    private EditText sx_id_search_hospital_edit;
    /** title右边文字*/
    private TextView xc_id_titlebar_right2_textview;
    /** 数据库实例*/
    private XCSearchRecordModelDb db;
    /** 设置数据库名字*/
    private String tabName;
    /** 监听器实例*/
    private OnClickCancleButtonListener canclelistener;
    /** 监听器实例*/
    private LeftListener left_listener;
    /** 监听器实例*/
    private OnEditTextClickedListener clicklistener;
    /** 监听器实例*/
    private OnKeyBoardSearchListener searchlistener;
    private int item_layout_id;
    private String hint;
    private TextWatcher textWatcher;

    /**
     * 设置表名
     * @param tabName 表名
     */
    public void setTabName(String tabName) {
        this.tabName = tabName;
    }

    // 点击取消按钮时（有时可能不是取消，而是搜索）

    /**
     * 取消监听接口
     */
    public interface OnClickCancleButtonListener {
        void clicked(String key_word);
    }

    /**
     * 设置取消监听接口
     */
    public void setOnClickCancleButtonListener(OnClickCancleButtonListener canclelistener) {
        this.canclelistener = canclelistener;
    }

    /**
     * 当eidttext整个被点击的时候
     */
    public interface OnEditTextClickedListener {
        void clicked();
    }

    /**
     * 当键盘的搜索的按钮点击时
     */
    public interface OnKeyBoardSearchListener {
        void searchKeyDown(String key_word);
    }

    /**
     * 设置点击事件监听器
     * @param clicklistener 监听器对象
     */
    public void setOnClicklistener(OnEditTextClickedListener clicklistener) {
        this.clicklistener = clicklistener;
    }

    /**
     * 设置搜索事件监听器
     * @param searchlistener 监听器对象
     */
    public void setOnSearchlistener(OnKeyBoardSearchListener searchlistener) {
        this.searchlistener = searchlistener;
    }

    /**
     * 左侧监听事件
     */
    public interface LeftListener {
        void leftClick();
    }


    public void setLeft_listener(LeftListener left_listener) {
        this.left_listener = left_listener;
    }
//    //右侧监听事件
//    public interface Right2TextViewClickListener {
//        void onRight2TextViewClick();
//    }
//    Right2TextViewClickListener right2TextViewClickListener;
//
//    public void setOnRight2TextViewClickListener(Right2TextViewClickListener right2TextViewClickListener) {
//        this.right2TextViewClickListener = right2TextViewClickListener;
//    }

    public void setItem_layout_id(int item_layout_id) {
        this.item_layout_id = item_layout_id;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        if (item_layout_id == 0) {
            return init(inflater, R.layout.sx_l_fragment_title_search_history);
        } else {
            return init(inflater, item_layout_id);
        }
    }


    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.xc_id_titlebar_left_imageview) {
            if (left_listener != null) {
                // 自定义逻辑
                left_listener.leftClick();
            } else {
                // 默认的
                myFinish();
            }
        }
//        if (id == R.id.xc_id_titlebar_right2_textview) {
//            if (right2TextViewClickListener != null) {
//                right2TextViewClickListener.onRight2TextViewClick();
//            }
//        }

        if (id == R.id.xc_id_titlebar_right2_textview) {
            if (getActivity().getCurrentFocus() != null) {
                if (getActivity().getCurrentFocus().getWindowToken() != null) {
                    // 先隐藏键盘
                    ((InputMethodManager) sx_id_search_hospital_edit.getContext().getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getActivity().getCurrentFocus()
                            .getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }
            }
            if (canclelistener != null) {
                String keyword = sx_id_search_hospital_edit.getText().toString().trim();
                if ("".equals(keyword)) {
                    shortToast("关键字不能为空");
                    return;
                }

                if ("搜索".equals(xc_id_titlebar_right2_textview.getText().toString().trim())) {
                    save(keyword);
                }
                canclelistener.clicked(keyword);
            } else {
                myFinish();
            }
        } else if (id == R.id.sx_id_search_hospital_edit) {
            if (clicklistener != null) {
                clicklistener.clicked();
            }
        }
    }

    /**
     * 存入数据方法
     * @param keyword 输入内容
     */
    public void save(String keyword) {
        if (UtilString.isBlank(keyword)) {
            return;
        }

        List<XCSearchRecordModel> xcSearchRecordModels1 = db.queryAllByDESC();
        boolean is_exist = false;
        for (XCSearchRecordModel model : xcSearchRecordModels1) {
            if (keyword.equals(model.getKey_word())) {
                is_exist = true;
                break;
            }
        }

        // 记录存入数据库
        if (!is_exist) {
            db.insert(new XCSearchRecordModel(keyword, System.currentTimeMillis() + ""));
        }

        int count = db.queryCount();

        if (count > 10) {
            List<XCSearchRecordModel> xcSearchRecordModels = db.queryAllByDESC();
            for (int i = 10; i < count; i++) {
                XCSearchRecordModel model = xcSearchRecordModels.get(i);
                if (model != null) {
                    db.deleteByTime(model.getTime());
                }
            }
        }


    }

    /**
     * 设置text内容
     * @param keyword 输入内容
     */
    public void setText(String keyword) {
        if (sx_id_search_hospital_edit != null) {
            sx_id_search_hospital_edit.setText(keyword);
            sx_id_search_hospital_edit.setSelection(sx_id_search_hospital_edit.getText().toString().trim().length());
        }
    }

    @Override
    public void initWidgets() {
        xc_id_titlebar_left_imageview = getViewById(com.qlk.ymz.R.id.xc_id_titlebar_left_imageview);
        sx_id_search_hospital_edit = getViewById(com.qlk.ymz.R.id.sx_id_search_hospital_edit);
        xc_id_titlebar_right2_textview = getViewById(com.qlk.ymz.R.id.xc_id_titlebar_right2_textview);
//        xc_id_fragment_search_edittext = getViewById(R.id.xc_id_fragment_search_edittext);
//        xc_id_fragment_search_cancle = getViewById(R.id.xc_id_fragment_search_cancle);

        db = new XCSearchRecordModelDb(getActivity(), XCSearchRecordModelDb.SEARCH_DB_NAME, XCSearchRecordModelDb.SEARCH_DB_VERSION, tabName);
        if (hint != null) {
            sx_id_search_hospital_edit.setHint(hint);
        }
        UtilInputMethod.openInputMethod(sx_id_search_hospital_edit, getActivity());
    }

    /**
     * 设置edittext hint提示
     * @param hint 提示
     */
    public void setHint(String hint) {
        this.hint = hint;
    }


    public void setSearchTextWatcher(TextWatcher textWatcher) {
        this.textWatcher = textWatcher;

    }

    public void addSearchTextWatcher(TextWatcher textWatcher) {
        if (sx_id_search_hospital_edit != null)
            sx_id_search_hospital_edit.addTextChangedListener(textWatcher);
        this.textWatcher = textWatcher;
    }

    public void removeSearchTextWatcher() {
        if (sx_id_search_hospital_edit != null)
            sx_id_search_hospital_edit.removeTextChangedListener(textWatcher);
    }

    @Override
    public void listeners() {
        xc_id_titlebar_left_imageview.setOnClickListener(this);
        xc_id_titlebar_right2_textview.setOnClickListener(this);
        sx_id_search_hospital_edit.setOnClickListener(this);
        sx_id_search_hospital_edit.addTextChangedListener(textWatcher);
        sx_id_search_hospital_edit.setOnEditorActionListener(new OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

                if (actionId == EditorInfo.IME_ACTION_SEARCH) {

                    String keyword = sx_id_search_hospital_edit.getText().toString().trim();
                    if ("".equals(keyword)) {
                        XCApplication.base_log.shortToast("关键字不能为空");
                        return false;
                    }
                    if (getActivity().getCurrentFocus() != null) {
                        if (getActivity().getCurrentFocus().getWindowToken() != null) {
                            // 先隐藏键盘
                            ((InputMethodManager) sx_id_search_hospital_edit.getContext().getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getActivity().getCurrentFocus()
                                    .getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                        }
                    }
                    save(keyword);
                    // 进入搜索结果页面
                    if (searchlistener != null) {
                        searchlistener.searchKeyDown(keyword);
                    }
                    return true;
                }
                return false;
            }
        });
    }
}
