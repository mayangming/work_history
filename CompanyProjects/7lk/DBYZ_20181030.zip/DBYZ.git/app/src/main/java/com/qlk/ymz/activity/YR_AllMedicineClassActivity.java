package com.qlk.ymz.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.emoji.util.UtilScreen;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.YR_AllMedicineClassAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.SK_MedicineClassificationAModel;
import com.qlk.ymz.model.SK_MedicineClassificationBModel;
import com.qlk.ymz.parse.Parse2ClassificationBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.android.fw.general.view.XCNoScrollGridView;

import org.apache.http.Header;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by smile on 2017/12/13.
 * 全科药品页面
 */

public class YR_AllMedicineClassActivity extends DBActivity {

    /** 标题布局 */
    private XCTitleCommonLayout xcTitleCommonLayout;
    /** 页面标题内容 */
    private String title = "全科药品";
    /** 标题右边按钮文字 */
    private String titleRight = "明星药品";
    /** 搜索药品布局 */
    private LinearLayout sk_id_medicine_search;
    /** 药品分类列表 */
    private XCNoScrollGridView gv_medicine_type;
    /** 常用药 */
    private LinearLayout ll_medicine_normal;
    /** 处方笺入口 */
    private RelativeLayout rl_recipe_cart;
    /** 处方笺数字 */
    private TextView tv_medicine_num;
    /** 处方笺数字布局 */
    private LinearLayout ll_medicine_num;

    /** 一级分类列表 */
    private List<SK_MedicineClassificationAModel> listA = new ArrayList();
    /** 一级分类适配器 */
    private YR_AllMedicineClassAdapter adapterA;

    /** 明星药品列表 */
    private List<SK_MedicineClassificationBModel> starMedicineList = new ArrayList<>();

    /**
     * 进入页标识，会带入药品列表页
     * 0：全科药品（我的药房）；1：常用处方详情添加药品（我的药房）；
     * 2：全科药品（推荐用药，显示处方笺icon）；3：常用处方详情添加药品（推荐用药）；4：处方笺添加药品（推荐用药）
     */
    public static String INTER_FLAG = "interFlag";

    /** 进入页标识 */
    private int flag;
    /** 处方药品数量 (数据里读)*/
    private int num;

    /** 常用处方详情标识值 */
    private String commonStr = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yr_activity_allmedicineclass);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_AllMedicineClassActivity.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */

    @Override
    public void initWidgets() {
        flag = getIntent().getIntExtra(INTER_FLAG,0);
        commonStr = getIntent().getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION);

        sk_id_medicine_search = getViewById(R.id.sk_id_medicine_search);
        xcTitleCommonLayout = getViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonLayout.setTitleCenter(true, title);
        xcTitleCommonLayout.setTitleRight2(true, 0, titleRight);
        xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        xcTitleCommonLayout.setTitleLeft(true, null);

        rl_recipe_cart = getViewById(R.id.rl_recipe_cart);
        tv_medicine_num = getViewById(R.id.tv_medicine_num);
        ll_medicine_num = getViewById(R.id.ll_medicine_num);
        //显示处方笺按钮
        if (flag == 2) {
            rl_recipe_cart.setVisibility(View.VISIBLE);
        } else {
            rl_recipe_cart.setVisibility(View.GONE);
        }

        ll_medicine_normal = getViewById(R.id.ll_medicine_normal);
        //显示常用药按钮
        if (flag ==0 || flag == 2) {
            ll_medicine_normal.setVisibility(View.GONE);
        } else {
            ll_medicine_normal.setVisibility(View.VISIBLE);
        }

        gv_medicine_type = getViewById(R.id.gv_medicine_type);
        gv_medicine_type.setFocusable(false);//解决进入页面时，scrollview不在顶部的问题

        adapterA = new YR_AllMedicineClassAdapter(this,listA);
        gv_medicine_type.setAdapter(adapterA);
        requestData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //1、首次进入页面时
        //2、处方笺设置药品返回时
        try {
            num = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size();
        }catch (Exception e){
            num = 0;
        }

        tv_medicine_num.setText(num + "");
        ll_medicine_num.setVisibility(num == 0 ? View.GONE : View.VISIBLE);
    }

    @Override
    public void listeners() {
        xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(YR_AllMedicineClassActivity.this, YR_StarMedicineActivity.class);
                intent.putExtra(SK_MedicineClassificationResultActivity.CLASSIFICATIONRESULT_KEY, (Serializable) starMedicineList);
                intent.putExtra(INTER_FLAG, flag);
                intent.putExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION, commonStr);

                myStartActivity(intent);
            }
        });

        ll_medicine_normal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(YR_AllMedicineClassActivity.this,
                        XD_CommonMedicineActivity.class);
                intent.putExtra(INTER_FLAG,flag);
                intent.putExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION,getIntent()
                        .getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION));
                myStartActivity(intent);
            }
        });

        sk_id_medicine_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ToJumpHelp.toJumpMedicineSearchActivity(YR_AllMedicineClassActivity.this,flag,commonStr);
            }
        });

        gv_medicine_type.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                showDialog((ArrayList<SK_MedicineClassificationBModel>) listA.get(position).getListB());
            }
        });

        //跳到处方笺页面
        rl_recipe_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (num <= 0 && UtilCollection.isBlank(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getDiagnoseBeanList())) {
                    Toast.makeText(YR_AllMedicineClassActivity.this, "请选择药品", Toast.LENGTH_SHORT).show();
                } else {
                    SQ_RecommendActivity.launch(YR_AllMedicineClassActivity.this);
                }

            }
        });
    }

    public void requestData(){

        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.patCategories),new RequestParams(),new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){
                    Parse2ClassificationBean parse2ClassificationBean = new Parse2ClassificationBean();
                    listA.addAll(parse2ClassificationBean.parse2ClassificationModelList(result_bean));
                    if (listA !=null) {
                        for (SK_MedicineClassificationAModel medicineClass: listA) {
                            if (medicineClass != null && "1".equals(medicineClass.getDiffFalg())) {
                                starMedicineList = medicineClass.getListB();
                                listA.remove(medicineClass);
                                break;
                            }
                        }
                    }
                    adapterA.notifyDataSetChanged();
                }
            }
        });
    }

    /** 二级分类列表弹框 */
    private SecondDialog secondDialog;

    public void showDialog (ArrayList<SK_MedicineClassificationBModel> secondTypeList) {
        if (secondDialog == null) {
            secondDialog = new SecondDialog(this, secondTypeList);
        } else {
            secondDialog.setDate(secondTypeList);
        }
        if (secondDialog != null && !secondDialog.isShowing()) {
            secondDialog.show();
        }
    }


   class SecondDialog extends Dialog {

        View view;
       /** 取消按钮 */
       TextView tv_cancel;
       /** 二级药品分类列表 */
       RecyclerView gv_secondMedicineType;
       /** 分类列表的父控件 */
       LinearLayout ll_medicinetype;

       /** 二级药品分类列表 */
       ArrayList<SK_MedicineClassificationBModel> secondTypeList = new ArrayList<>();
       /** 二级药品适配器 */
       RecyclerViewAdapter adapter;

       public SecondDialog(Context context, ArrayList<SK_MedicineClassificationBModel> secondTypeList) {
           super(context, R.style.xc_s_dialog);

           this.secondTypeList = secondTypeList;

           view = LayoutInflater.from(context).inflate(R.layout.yr_activity_secondmedicinetype,null);

           initDialog();

           setListener();

           setContentView(view);

           WindowManager.LayoutParams lp = getWindow().getAttributes();
           getWindow().setGravity(Gravity.BOTTOM);
           lp.width = ViewGroup.LayoutParams.MATCH_PARENT;
           getWindow().setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
       }

       public void initDialog(){
           tv_cancel = (TextView) view.findViewById(R.id.tv_cancel);
           gv_secondMedicineType = (RecyclerView) view.findViewById(R.id.rv_layout);

           GridLayoutManager gridLayoutManager = new GridLayoutManager(YR_AllMedicineClassActivity.this, 3);
           gv_secondMedicineType.setLayoutManager(gridLayoutManager);

           adapter = new RecyclerViewAdapter();
           gv_secondMedicineType.setAdapter(adapter);

           ll_medicinetype = (LinearLayout) view.findViewById(R.id.ll_medicinetype);

           gv_secondMedicineType.addItemDecoration(new RecyclerView.ItemDecoration() {

               int mSpace;

               @Override
               public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                   super.getItemOffsets(outRect, view, parent, state);
                   mSpace = UtilScreen.dip2px(YR_AllMedicineClassActivity.this, 5);
                   outRect.left = mSpace;
                   outRect.bottom = mSpace;
                   if (parent.getChildAdapterPosition(view) % 3 == 2) {
                       outRect.right = mSpace;
                   }
               }
           });
       }

       public void setListener(){
           tv_cancel.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                  dismiss();
               }
           });
       }

       /** 设置list数据 */
       public void setDate (ArrayList<SK_MedicineClassificationBModel> secondTypeList) {
           this.secondTypeList = secondTypeList;
           adapter.notifyDataSetChanged();
       }

       class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {


           @Override
           public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

               View view = LayoutInflater.from(YR_AllMedicineClassActivity.this).inflate(R.layout.yr_item_secondmedicinetype, null);
               ViewHolder viewHolder = new ViewHolder(view);
               return viewHolder;
           }

           @Override
           public void onBindViewHolder(ViewHolder holder, int position) {
               final SK_MedicineClassificationBModel bean = secondTypeList.get(position);
               holder.tv_medicineName.setText(bean.getName());
               holder.itemView.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {
                       Intent intent = new Intent(YR_AllMedicineClassActivity.this, SK_MedicineClassificationResultActivity.class);
                       intent.putExtra(YR_AllMedicineClassActivity.INTER_FLAG, flag);
                       intent.putExtra(SK_MedicineClassificationResultActivity.CLASSIFICATIONRESULT_KEY, bean);
                       intent.putExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION, commonStr);
                       myStartActivity(intent);
                       dismiss();
                   }
               });
           }

           @Override
           public int getItemCount() {
               return secondTypeList.size();
           }

           class ViewHolder extends RecyclerView.ViewHolder {

               TextView tv_medicineName;

               public ViewHolder(View itemView) {
                   super(itemView);
                   tv_medicineName = (TextView) itemView.findViewById(R.id.tv_medicineName);
               }
           }
       }


   }

    @Override
    public void onNetRefresh() {

    }

    @Override
    protected void onDestroy() {
        UtilViewShow.destoryDialogs(secondDialog);
        super.onDestroy();
    }
}
