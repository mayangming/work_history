package com.qlk.ymz.db.mqttlog;

/**
 * @author jingyu on 2016/10/31 13:40
 * @description mqtt日志统计
 */
public class MqttLogModel {

    private String _id = "";

    private String msg = "";

    private String time = "";

    private String back1 = "";

    private String back2 = "";

    private String back3 = "";

    private String back4 = "";

    private String back5 = "";

    private String back6 = "";

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getBack1() {
        return back1;
    }

    public void setBack1(String back1) {
        this.back1 = back1;
    }

    public String getBack2() {
        return back2;
    }

    public void setBack2(String back2) {
        this.back2 = back2;
    }

    public String getBack3() {
        return back3;
    }

    public void setBack3(String back3) {
        this.back3 = back3;
    }

    public String getBack4() {
        return back4;
    }

    public void setBack4(String back4) {
        this.back4 = back4;
    }

    public String getBack5() {
        return back5;
    }

    public void setBack5(String back5) {
        this.back5 = back5;
    }

    public String getBack6() {
        return back6;
    }

    public void setBack6(String back6) {
        this.back6 = back6;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    @Override
    public String toString() {
        return "MqttLogModel{" +
                "msg='" + msg + '\'' +
                ", time='" + time + '\'' +
                ", back1='" + back1 + '\'' +
                ", back2='" + back2 + '\'' +
                ", back3='" + back3 + '\'' +
                ", back4='" + back4 + '\'' +
                ", back5='" + back5 + '\'' +
                ", back6='" + back6 + '\'' +
                '}';
    }
}
