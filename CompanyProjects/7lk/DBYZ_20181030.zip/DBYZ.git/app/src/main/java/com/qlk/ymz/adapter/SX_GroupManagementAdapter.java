package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.qlk.ymz.R;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.Utils;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * 编辑分组页的患者列表adapter
 * Created by songxin on 2015/6/21.
 *
 */
public class SX_GroupManagementAdapter extends BaseAdapter{
    private LayoutInflater mInflate;
    /** 全部患者list */
    private ArrayList<XC_ChatModel> patientList;
    /** 要删除患者id的list */
    private List<String> mDeleteId;

    public SX_GroupManagementAdapter(Context context, ArrayList<XC_ChatModel> patientList, List<String> deleteId){
        mInflate =  LayoutInflater.from(context);
        this.patientList = patientList;
        this.mDeleteId = deleteId;
    }

    @Override
    public int getCount() {
        return patientList.size();
    }

    @Override
    public Object getItem(int position) {
        return patientList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
       final XC_ChatModel patientBean =  patientList.get(position);
        ViewHolder mViewHolder;
        if (null == convertView) {
            mViewHolder = new ViewHolder();
            convertView = mInflate.inflate(R.layout.sx_l_adapter_group_management_item, null);
            mViewHolder.deleteHead = (ImageView) convertView.findViewById(R.id.sx_id_adapter_delete_head_date);
            mViewHolder.showHeadIcon = (ImageView) convertView.findViewById(R.id.sx_id_adapter_show_head);
            mViewHolder.showHeadName = (TextView) convertView.findViewById(R.id.sx_l_adapter_name_show);

            convertView.setTag(mViewHolder);
        } else {
            mViewHolder = (ViewHolder) convertView.getTag();
        }
        //显式的将checkActualViewSize设为false, 这样图片的缓存也将只会保存一个副本,保证第二次查询时可以直接命中
        //具体原因可以参考这个链接 http://www.cnblogs.com/wuxilin/p/4333241.html
        ImageAware imageAware = new ImageViewAware(mViewHolder.showHeadIcon, false);
        // update by cyr on 2017-2-15 修改imageloader本地加载的icon地址从mipmap变为drawable
        if (position == 0) {//第一个位置是添加按钮item
            XCApplication.base_imageloader.displayImage("drawable://" + R.drawable.pf_i_add_patient, imageAware, XCImageLoaderHelper.getDisplayNoCacheImageOptions(R.drawable.pf_i_add_patient));
            mViewHolder.showHeadName.setText("");
            mViewHolder.deleteHead.setVisibility(View.INVISIBLE);
        } else if (position == 1) {//第二个位置是刪除按鈕item
            XCApplication.base_imageloader.displayImage("drawable://" + R.drawable.pf_i_delete_patient, imageAware, XCImageLoaderHelper.getDisplayNoCacheImageOptions(R.drawable.pf_i_delete_patient));
            mViewHolder.showHeadName.setText("");
            mViewHolder.deleteHead.setVisibility(View.INVISIBLE);
        } else {//其他为患者item
            if (patientBean.getUserPatient().isDeleteStatus) {
                mViewHolder.deleteHead.setVisibility(View.VISIBLE);
            } else {
                mViewHolder.deleteHead.setVisibility(View.INVISIBLE);
            }
            //等后端最新接口增加各种name后 修改字段名
            String patientDisplayName = Utils.getPatientDisplayName(patientBean.getUserPatient().getPatientMemoName(), patientBean.getUserPatient().getPatientName());
            mViewHolder.showHeadName.setText(patientDisplayName);

            XCApplication.base_imageloader.displayImage(patientBean.getUserPatient().getPatientImgHead(), imageAware, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_patient_default));
        }

        mViewHolder.deleteHead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDeleteId.add(patientBean.getUserPatient().getPatientId());
                patientList.remove(position);
                notifyDataSetChanged();
            }
        });
        return convertView;
    }

    static class ViewHolder{
        ImageView deleteHead;
        ImageView showHeadIcon;
        TextView showHeadName;
    }

}
