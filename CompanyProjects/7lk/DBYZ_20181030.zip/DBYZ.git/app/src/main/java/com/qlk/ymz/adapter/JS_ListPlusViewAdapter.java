package com.qlk.ymz.adapter;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.emoji.util.EmojiSpanUtils;
import com.qlk.ymz.R;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.maintab.JS_HomeFragment;
import com.qlk.ymz.util.RoughDraftUtils;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.SwipeLayout.SwipeLayoutAdapter;
import com.qlk.ymz.view.SwipeLayout.SwipeOnTouchListener;
import com.qlk.ymz.view.SwipeLayout.SwipeViewHolder;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import java.util.ArrayList;

/**
 * 首页信息列表内容适配器
 * @author 徐金山
 * @version 2.0
 */
public class JS_ListPlusViewAdapter extends SwipeLayoutAdapter {
    /** 上下文对象 */
    private Context context;
    /** push信息列表 */
    private ArrayList<JS_ChatListModel> dataList;

    /**
     * 构造方法
     * @param context 上下文对象
     * @param contentViewResourceId 列表项：内容区布局资源ID
     * @param actionViewResourceId 列表项：菜单区布局资源ID
     * @param dataList push信息列表
     */
    public JS_ListPlusViewAdapter(Context context, int contentViewResourceId, int actionViewResourceId, ArrayList<JS_ChatListModel> dataList) {
        super(context, contentViewResourceId, actionViewResourceId, dataList);
        this.context = context;
        this.dataList = dataList;
    }

    public JS_ListPlusViewAdapter(Context context,int contentViewResourceId,int actionViewResourceId,int contentWidth,int itemWidth,ArrayList<JS_ChatListModel> dataList){
        super(context,R.layout.item_swipe,contentViewResourceId,actionViewResourceId, contentWidth,itemWidth);
        this.context = context;
        this.dataList = dataList;
    }
    public void update(ArrayList<JS_ChatListModel> list) {
        this.dataList = list;
    }

    public int getCount() {
        int count = 0;
        if(null != dataList) {
            count = dataList.size();
        }
        return count;
    }

    public Object getItem(int position) {
        if (dataList != null) {
            return dataList.get(position);
        } else {
            return null;
        }
    }

    public long getItemId(int position) {
        return 0;
    }

    /**
     * 设置未读消息数e
     * @param tv_noReadNumber 列表项控件持有对象
     * @param bean 咨询列表信息BEAN对象
     */
    private void setNoReadNumber(TextView tv_noReadNumber, JS_ChatListModel bean) {
        String unReadMessageNum = bean.getUnReadMessageNum();
        long long_unReadMessageNum = Long.valueOf(unReadMessageNum);

        if (0 == long_unReadMessageNum) {
            tv_noReadNumber.setVisibility(View.GONE);
        } else if(long_unReadMessageNum > 0 && long_unReadMessageNum < 100) {
            tv_noReadNumber.setVisibility(View.VISIBLE);
            tv_noReadNumber.setText(unReadMessageNum);
        } else {
            tv_noReadNumber.setVisibility(View.VISIBLE);
            tv_noReadNumber.setText("99+");
        }
    }

    /**
     * 设置免打扰icon
     * @param iv_chatTroubleFree 未打扰icon控件对象
     * @param bean 咨询列表信息BEAN对象
     */
    private void setIsShield(ImageView iv_chatTroubleFree, JS_ChatListModel bean) {
        if("0".equals(bean.getUserPatient().getIsShield())) {
            iv_chatTroubleFree.setVisibility(View.GONE);
        }else{
            iv_chatTroubleFree.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 设置会话的生命周期状态
     * @param iv_lifeCycle 会话生命周期状态显示控件对象（0：咨询中；1：已结束）
     * @param bean 咨询列表信息对象
     */
    private void setLifeCycle(ImageView iv_lifeCycle, JS_ChatListModel bean) {
        if ("1".equals(bean.getSessionLifeCycle())) {
            iv_lifeCycle.setVisibility(View.GONE);

        } else {
            iv_lifeCycle.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 获取最后的聊天信息
     * @param contentViewHolder 列表项控件持有类对象
     * @param bean 咨询列表信息对象
     */
//    TODO 需要添加两种状态
    private void setLastMsg(ContentViewHolder contentViewHolder, JS_ChatListModel bean) {
        // 先判断是否有自主购药咨询，有的话显示自主购药咨询的信息
        String roughtDraft = RoughDraftUtils.getRoughtDraftByPatientId(bean.getUserPatient().getPatientId());
        if(!TextUtils.isEmpty(roughtDraft)){
            contentViewHolder.tv_lastChatMsg.setText(Html.fromHtml("<font color= '#e2231a'>[草稿]</font> " + roughtDraft));
            contentViewHolder.tv_lastChatMsg.setVisibility(View.VISIBLE);
        }
        // update by cyr 2018/4/25  首页列表添加显示类型，患者付费咨询第一条显示付费信息，不显示
        else if (!TextUtils.isEmpty(bean.getSummary())) {
            contentViewHolder.tv_lastChatMsg.setText("[" + bean.getSummary() + "]");
            contentViewHolder.tv_lastChatMsg.setVisibility(View.VISIBLE);
        }
        else{
//            String hasBuyMedicineRequire = bean.getMsgTypeBuyMedicineRequire();
//            if(!(TextUtils.isEmpty(hasBuyMedicineRequire)) && "64".equals(hasBuyMedicineRequire)) {
//                contentViewHolder.tv_lastChatMsg.setText(Html.fromHtml(bean.getBuyMedicineRequireMsg()));
//            }else {
            int flag;
            try{
                flag = Integer.valueOf(bean.getMsgType());
            }catch (Exception e){
                e.getStackTrace();
                flag = XC_ChatModel.TEXT;
            }
            //update by cyr on 2017-6-15 提出公共部分
            contentViewHolder.tv_lastChatMsg.setVisibility(View.VISIBLE);
            switch (flag) {
                case XC_ChatModel.TEXT:
                    if (TextUtils.isEmpty(bean.getMessageText())) {
                        contentViewHolder.tv_lastChatMsg.setText("");
                        contentViewHolder.tv_lastChatMsg.setVisibility(View.INVISIBLE);
                        break;
                    }
                    contentViewHolder.tv_lastChatMsg.setText(EmojiSpanUtils.getPatternEmojiMean(bean.getMessageText()));
                    break;
                case XC_ChatModel.PATIENT_BUY://TODO add by cyr on 2018/6/25 自主购药统一用msgType判断
                    contentViewHolder.tv_lastChatMsg.setText(Html.fromHtml(bean.getMessageText()));
                    break;
                case XC_ChatModel.ASSISTANT_MEDICINE:
                    if (TextUtils.isEmpty(bean.getMessageText())) {
                        contentViewHolder.tv_lastChatMsg.setText("");
                        contentViewHolder.tv_lastChatMsg.setVisibility(View.INVISIBLE);
                        break;
                    }
                    contentViewHolder.tv_lastChatMsg.setText(Html.fromHtml(bean.getMessageText()));
                    break;
                case XC_ChatModel.PHOTO:
                    contentViewHolder.tv_lastChatMsg.setText("[图片消息]");
                    break;
                case XC_ChatModel.VOICE:
                    contentViewHolder.tv_lastChatMsg.setText("[语音消息]");
                    break;
                case XC_ChatModel.MOVIE:
                    contentViewHolder.tv_lastChatMsg.setText("[小视频]");
                    break;
                case XC_ChatModel.RECOMMAND_MEDICINE:
                    contentViewHolder.tv_lastChatMsg.setText("[药品信息]");
                    break;
                // add by jingyu 20161119
                case XC_ChatModel.VISIT:
                    if ((XC_ChatModel.DOCTOR + "").equals(bean.getSender())) {
                        contentViewHolder.tv_lastChatMsg.setText("[疗效随访]");
                    } else if ((XC_ChatModel.PATIENT + "").equals(bean.getSender())) {
                        contentViewHolder.tv_lastChatMsg.setText("[疗效随访反馈]");
                    } else {
                        contentViewHolder.tv_lastChatMsg.setText("[]");
                    }
                    break;
                //add by cyr on 2017-3-31 新增图文咨询、宣教、个性化三个type
                case XC_ChatModel.PAID:
                    contentViewHolder.tv_lastChatMsg.setText("[患者发起付费咨询]");
                    break;
                case XC_ChatModel.PUBLICITY_EDUCATION:
                    contentViewHolder.tv_lastChatMsg.setText("[宣教]");
                    break;
                case XC_ChatModel.INDIVIDUATION_COST:
                    contentViewHolder.tv_lastChatMsg.setText("[已推荐个性化服务付费]");
                    break;
                //add by cyr on 2017-6-15 新增type: "量表"
                case XC_ChatModel.SCALE:
                    contentViewHolder.tv_lastChatMsg.setText("[量表]");
                    break;
                case XC_ChatModel.CHECK_HEALTH:
                    contentViewHolder.tv_lastChatMsg.setText("[检查信息]");
                    break;
                case XC_ChatModel.MEDICINE_RECORD:
                    contentViewHolder.tv_lastChatMsg.setText(Html.fromHtml(bean.getChatModelMedicineRecord().getText()));
                    break;
                case XC_ChatModel.MEDICINE_RECORD_LAST:
                    contentViewHolder.tv_lastChatMsg.setText(Html.fromHtml(bean.getChatModelMedicineRecord().getText()));
                    break;
                case XC_ChatModel.MEDICINE_RECORD_REMIND:
                    contentViewHolder.tv_lastChatMsg.setText(Html.fromHtml(bean.getChatModelMedicineRecord().getText()));
                    break;
                case XC_ChatModel.MEDICAL_RECORD:
                    if (UtilString.isBlank(bean.getRecommandId())){//如果推荐处方ID不为null，则表示有处方
                        contentViewHolder.tv_lastChatMsg.setText("[病历]");
                    }else {
                        contentViewHolder.tv_lastChatMsg.setText("[病历处方]");
                    }
                    break;
                case XC_ChatModel.SCALE_NEW:
                    if ("0".equals(bean.getUnReadMessageNum())){
                        contentViewHolder.tv_lastChatMsg.setText(Html.fromHtml("<font color= '#7b7b7b'>"+"填写了["+  bean.getChatModelScaleNew().getTitle() +"]"+"</font>"));
                    }else {
                        contentViewHolder.tv_lastChatMsg.setText(Html.fromHtml("<font color= '#FF0000'>"+"填写了["+  bean.getChatModelScaleNew().getTitle() +"]"+"</font>"));
                    }
                    break;
                case XC_ChatModel.CHECK_REPORT:
                    contentViewHolder.tv_lastChatMsg.setText(Html.fromHtml("<font color= '#444444'>[检查报告]</font>"+bean.getChatModelMedicineRecord().getText()));
                    break;
                default:
                    contentViewHolder.tv_lastChatMsg.setText("当前版本暂不支持查看此类消息，请更新APP至最新版本查看!");
                    break;
            }

//            }
        }

    }

    /**
     * 列表项内容区控件持有类
     */
    private class ContentViewHolder {
        /** 项布局 */
        private RelativeLayout rel_contentLayout;
        /** 患者头像（复用于：云诊公告，客服回复，账户动态） */
        private XCRoundedImageView iv_headImage;
        /** 未读信息数 */
        private TextView tv_noReadNumber;
        /** 患者名称（当医生给患者设置了备注名后，此项显示患者的备注名），（复用于：云诊公告，客服回复，账户动态） */
        private TextView tv_patientName;
        /** 最新的信息 */
        private TextView tv_lastChatMsg;
        /** 会话开始时间 */
        private TextView tv_chatStartTime;
        /** 勿扰标识icon */
        private ImageView iv_chatTroubleFree;
        /** 会话生命周期状态（0：咨询中；1：已结束） */
        private ImageView iv_lifeCycle;
        /** 底部分割线 */
        private View v_bottom_line;
        /** 付费标识icon */
        private TextView iv_payAmount;

    }

    public void setContentView(View contentView, int position, HorizontalScrollView parent) {}

    public void setContentView(View contentView, int position, HorizontalScrollView parent, SwipeViewHolder holder, SwipeOnTouchListener swipeOnTouchListener) {
        final JS_ChatListModel bean = dataList.get(position);
        ContentViewHolder contentViewHolder;

        contentViewHolder = (ContentViewHolder) contentView.getTag();
        if(null == contentViewHolder) {
            contentViewHolder = new ContentViewHolder();
            contentViewHolder.rel_contentLayout = (RelativeLayout) contentView.findViewById(R.id.rel_contentLayout);
            contentViewHolder.iv_headImage = (XCRoundedImageView) contentView.findViewById(R.id.iv_headImage);
            contentViewHolder.tv_noReadNumber = (TextView) contentView.findViewById(R.id.tv_noReadNumber);
            contentViewHolder.tv_patientName = (TextView) contentView.findViewById(R.id.tv_patientName);
            contentViewHolder.tv_lastChatMsg = (TextView) contentView.findViewById(R.id.tv_lastChatMsg);
            contentViewHolder.tv_chatStartTime = (TextView) contentView.findViewById(R.id.tv_chatStartTime);
            contentViewHolder.iv_chatTroubleFree = (ImageView) contentView.findViewById(R.id.iv_chatTroubleFree);
            contentViewHolder.iv_lifeCycle = (ImageView) contentView.findViewById(R.id.iv_lifeCycle);
            contentViewHolder.v_bottom_line = contentView.findViewById(R.id.v_bottom_line);
            contentViewHolder.iv_payAmount = (TextView) contentView.findViewById(R.id.iv_payAmount);
            contentView.setTag(contentViewHolder);
        }else {
            contentViewHolder = (ContentViewHolder) contentView.getTag();
        }

        if (position == (dataList.size() - 1)) {
            contentViewHolder.v_bottom_line.setVisibility(View.GONE);
        } else {
            contentViewHolder.v_bottom_line.setVisibility(View.VISIBLE);
        }

        // 判断是否置顶
        if("0".equals(bean.getTopSortTime())) {
            contentViewHolder.rel_contentLayout.setBackgroundResource(R.drawable.js_dd_selector_img_gray_eeeeee);
        }else {
            contentViewHolder.rel_contentLayout.setBackgroundResource(R.drawable.js_dd_bg_gray_eeeeee);
        }
        if ("1".equals(bean.getUserPatient().getConsultPayType()) || "2".equals(bean.getUserPatient().getConsultPayType())) {
            contentViewHolder.iv_payAmount.setVisibility(View.VISIBLE);
        } else {
            contentViewHolder.iv_payAmount.setVisibility(View.GONE);
        }
        // 发送者
        int sender_int = getSenderForIntType(bean.getSender());
        // 患者咨询的UI数据适配
        if(JS_ChatListModel.PATIENT == sender_int || JS_ChatListModel.DOCTOR == sender_int) {
            // 头像
            XCApplication.base_imageloader.displayImage(bean.getUserPatient().getPatientImgHead(), contentViewHolder.iv_headImage, XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default));
            contentViewHolder.iv_headImage.setBackgroundResource(R.color.c_trans);
            // 未读消息数
            setNoReadNumber(contentViewHolder.tv_noReadNumber, bean);
            // 患者名称
            contentViewHolder.tv_patientName.setText(bean.getUserPatient().getPatientDisplayName());
            // 最新的信息
            setLastMsg(contentViewHolder, bean);
            // 会话最新信息的时间
            contentViewHolder.tv_chatStartTime.setText(UtilDate.convertTimeToFormat(UtilString.toLong(bean.getMsgTime())));
            // 勿扰标识icon
            setIsShield(contentViewHolder.iv_chatTroubleFree, bean);
            // 会话生命周期状态（0：咨询中；1：已结束）
            setLifeCycle(contentViewHolder.iv_lifeCycle, bean);
        }
        // 公告通知的UI数据适配
        else if(JS_ChatListModel.MSG_SENDER_TYPE_PUB_NOTICE == sender_int) {
            // 头像
            XCApplication.base_imageloader.displayImage(bean.getUserPatient().getPatientImgHead(), contentViewHolder.iv_headImage, XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.js_d_icon_ymz_notification));
            contentViewHolder.iv_headImage.setBackgroundResource(R.mipmap.js_d_icon_ymz_notification);
            // 未读消息数
            setNoReadNumber(contentViewHolder.tv_noReadNumber, bean);
            // 患者名称
            contentViewHolder.tv_patientName.setText(bean.getUserPatient().getPatientName());
            // 最新的信息
            contentViewHolder.tv_lastChatMsg.setText(bean.getMessageText());
            contentViewHolder.tv_lastChatMsg.setVisibility(View.VISIBLE);
            // 会话最新信息的时间
            contentViewHolder.tv_chatStartTime.setText(UtilDate.convertTimeToFormat(UtilString.toLong(bean.getMsgTime())));
            // 勿扰标识icon
            setIsShield(contentViewHolder.iv_chatTroubleFree, bean);
            // 会话生命周期状态（0：咨询中；1：已结束）
            contentViewHolder.iv_lifeCycle.setVisibility(View.INVISIBLE);
        }
        // 系统通知的UI数据适配
        else if(JS_ChatListModel.MSG_SENDER_TYPE_ACCOUNT_STATE == sender_int) {
            // 头像
            XCApplication.base_imageloader.displayImage(bean.getUserPatient().getPatientImgHead(), contentViewHolder.iv_headImage, XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.js_d_icon_account_msg));
            contentViewHolder.iv_headImage.setBackgroundResource(R.mipmap.js_d_icon_account_msg);
            // 未读消息数
            setNoReadNumber(contentViewHolder.tv_noReadNumber, bean);
            // 患者名称
            contentViewHolder.tv_patientName.setText("系统通知");
            // 最新的信息
            contentViewHolder.tv_lastChatMsg.setText(bean.getMessageText());
            contentViewHolder.tv_lastChatMsg.setVisibility(View.VISIBLE);
            // 会话最新信息的时间
            contentViewHolder.tv_chatStartTime.setText(UtilDate.convertTimeToFormat(UtilString.toLong(bean.getMsgTime())));
            // 勿扰标识icon
            setIsShield(contentViewHolder.iv_chatTroubleFree, bean);
            // 会话生命周期状态（0：咨询中；1：已结束）
            contentViewHolder.iv_lifeCycle.setVisibility(View.INVISIBLE);
        }
        //add by tengfei 2016/09/07 环信客服UI  因需求改动首页列表不添加
        else if(JS_ChatListModel.MSG_SENDER_TYPE_SERVICE == sender_int||JS_ChatListModel
                .MSG_SENDER_TYPE_SERVICE_MY == sender_int ){
            // 头像
            XCApplication.base_imageloader.displayImage(bean.getUserPatient().getPatientImgHead(), contentViewHolder.iv_headImage, XCImageLoaderHelper.getDisplayImageOptions2(R.drawable.doctor_asstant_head));
            // 未读消息数
            contentViewHolder.tv_noReadNumber.setVisibility(View.INVISIBLE);
//            setNoReadNumber(contentViewHolder.tv_noReadNumber, bean);
            int unReadNum = UtilSP.getDoctorAsstantNum();
            if (0 == unReadNum) {
                contentViewHolder.tv_noReadNumber.setVisibility(View.GONE);
            } else if(unReadNum > 0 && unReadNum < 100) {
                contentViewHolder.tv_noReadNumber.setVisibility(View.VISIBLE);
                contentViewHolder.tv_noReadNumber.setText(unReadNum+"");
            } else {
                contentViewHolder.tv_noReadNumber.setVisibility(View.VISIBLE);
                contentViewHolder.tv_noReadNumber.setText("…");
            }
            // 患者名称
            contentViewHolder.tv_patientName.setText("医生助手");
            // 最新的信息
            //2018/5/7 update by cyr start 修复行末省略号后面还有数据的问题（a...b）
            String msg = bean.getMessageText();
            msg = msg.replaceAll("\\n","");
            bean.setMessageText(msg);
            //2018/5/7 update by cyr end
            setLastMsg(contentViewHolder, bean);
            // 会话最新信息的时间
            contentViewHolder.tv_chatStartTime.setText(UtilDate.convertTimeToFormat(UtilString.toLong(bean.getMsgTime())));
            // 勿扰标识icon
            setIsShield(contentViewHolder.iv_chatTroubleFree, bean);
            contentViewHolder.iv_lifeCycle.setVisibility(View.INVISIBLE);
            // 会话生命周期状态（0：咨询中；1：已结束）
//            setLifeCycle(contentViewHolder.iv_lifeCycle, bean);
        }
        // 其他情况的数据适配处理
        else {
            // TODO
        }

        // 内容区布局点击事件的监听
        contentViewHolder.rel_contentLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                homeChatListActionProcess.contentLayoutActionProcess(v, bean);
            }
        });
    }

    /**
     * 列表项菜单区控件持有类
     */
    private class ActionViewHolder {
        /** 置顶按钮 */
        private TextView tv_topBtn;
        /** 免打扰按钮 */
        private TextView tv_noDisturbingBtn;
        /** 删除按钮 */
        private TextView tv_deleteBtn;
    }

    public void setActionView(View actionView, int position, HorizontalScrollView parent) {
        final JS_ChatListModel chatListModel = dataList.get(position);
        ActionViewHolder actionViewHolder;

        actionViewHolder = (ActionViewHolder) actionView.getTag();
        if(null == actionViewHolder) {
            actionViewHolder = new ActionViewHolder();
            actionViewHolder.tv_topBtn = (TextView) actionView.findViewById(R.id.tv_topBtn);
            actionViewHolder.tv_noDisturbingBtn = (TextView) actionView.findViewById(R.id.tv_noDisturbingBtn);
            actionViewHolder.tv_deleteBtn = (TextView) actionView.findViewById(R.id.tv_deleteBtn);

            actionView.setTag(actionViewHolder);
        }else {
            actionViewHolder = (ActionViewHolder) actionView.getTag();
        }

        // “置顶/取消置顶”按钮的显示
        if(!"0".equals(chatListModel.getTopSortTime())){
            actionViewHolder.tv_topBtn.setText("取消置顶");
        }else {
            actionViewHolder.tv_topBtn.setText("置顶");
        }

        // “免打扰/取消免打扰”按钮的显示
        String tempIsShied = chatListModel.getUserPatient().getIsShield(); // 消息提醒屏蔽标示（说明：0:不屏蔽，1:屏蔽）
        if("0".equals(tempIsShied)) {
            actionViewHolder.tv_noDisturbingBtn.setText("免打扰");
        }else {
            actionViewHolder.tv_noDisturbingBtn.setText("取消\n免打扰");
        }

        // 对于“云诊公告”信息、“医生助手”及“账户动态”信息是不显示“免打扰”按钮的
        // 0医生，1患者，2 公共通知，3账户动态，5系统确认购药咨询通知 6、7为医生助手
        int sender_int = getSenderForIntType(chatListModel.getSender());

        if (JS_ChatListModel.PATIENT == sender_int || JS_ChatListModel.DOCTOR == sender_int) {
            actionViewHolder.tv_noDisturbingBtn.setVisibility(View.VISIBLE);
        } else if (JS_ChatListModel.MSG_SENDER_TYPE_PUB_NOTICE == sender_int || JS_ChatListModel.MSG_SENDER_TYPE_ACCOUNT_STATE == sender_int
                || JS_ChatListModel.MSG_SENDER_TYPE_SERVICE == sender_int || JS_ChatListModel.MSG_SENDER_TYPE_SERVICE_MY == sender_int
                ) {
            actionViewHolder.tv_noDisturbingBtn.setVisibility(View.GONE);
        } else {
            actionViewHolder.tv_noDisturbingBtn.setVisibility(View.VISIBLE);
        }

        // 置顶按钮点击事件的监听
        actionViewHolder.tv_topBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(JS_HomeFragment.class,"2","128","tv_topBtn","",false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                homeChatListActionProcess.topBtnActionProcess(v, chatListModel);
            }
        });

        // 免打扰按钮点击事件的监听
        actionViewHolder.tv_noDisturbingBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                homeChatListActionProcess.noDisturbingBtnActionProcess(v, chatListModel);
            }
        });

        // 删除按钮点击事件的监听
        actionViewHolder.tv_deleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                homeChatListActionProcess.deleteBtnActionProcess(v, chatListModel);
            }
        });
    }

    /**
     * 获取发送者类型（int型）。若获取发送者类型（int型）失败，则返回“-10”
     * @param sender 发送者类型
     * @return 发送者类型（int型）
     */
    private int getSenderForIntType(String sender) {
        int int_sender = -10;

        try{
            int_sender = Integer.valueOf(sender);
        }catch(Exception e) {
            int_sender = -10;
        }

        return int_sender;
    }

    /**
     * 首页咨询列表项：操作区按钮被点击时的处理定义
     */
    public interface HomeChatListActionProcess {
        /** 内容区布局点击处理方法 */
        public void contentLayoutActionProcess(View v,JS_ChatListModel chatListModel);
        /** 置顶按钮点击处理方法 */
        public void topBtnActionProcess(View v, JS_ChatListModel chatListModel);
        /** 免打扰按钮点击处理方法 */
        public void noDisturbingBtnActionProcess(View v, JS_ChatListModel chatListModel);
        /** 删除按钮点击处理方法 */
        public void deleteBtnActionProcess(View v, JS_ChatListModel chatListModel);
    }

    public HomeChatListActionProcess homeChatListActionProcess;
    public void setHomeChatListActionProcess(HomeChatListActionProcess homeChatListActionProcess) {
        this.homeChatListActionProcess = homeChatListActionProcess;
    }

}
