package com.qlk.ymz.activity;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SK_AddMedicineAdapter;
import com.qlk.ymz.adapter.SK_SearchAssociationAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.search.XCSearchRecordModel;
import com.qlk.ymz.db.search.XCSearchRecordModelDb;
import com.qlk.ymz.fragment.SKTitleSearchFragment;
import com.qlk.ymz.fragment.SXSearchRecordFragment;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.SearchModel;
import com.qlk.ymz.parse.Parse2DrugBean;
import com.qlk.ymz.parse.Parse2SearchModel;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.util.bi.DurgSreachBi;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.fragment.XCMoveBlockPlusFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;
import com.xiaocoder.ptrrefresh.XCMaterialListPinRefreshLayout;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * @description 搜索页面
 * @author 赖善琦
 * @version 2.14.0
 */
public class SK_MedicineSearchActivity extends DBActivity{
    /** 搜索框 */
    private SKTitleSearchFragment skTitleSearchFragment;
    /** 搜索历史列表 */
    private SXSearchRecordFragment sxSearchRecordFragment;
    /** 搜索联想的容器 */
    private LinearLayout sk_id_search_association_ll;
    /** 搜索历史fragment的布局容器 */
    private LinearLayout sx_id_main_recoder;
    /** 搜索结果列表View，内部封装了listview的上拉和下拉 */
    private XCMaterialListPinRefreshLayout xcMaterialListPinRefreshLayout;
    /** 搜索结果列表 */
    private ListView medicineDrugListView;
    /** 搜索结果适配器 */
    private SK_AddMedicineAdapter medicineAdapter;
    /** 联想关键词列表  */
    private XCListViewFragment mSearchAssociationListViewFragment;
    /** 联想关键词列表适配器 */
    public SK_SearchAssociationAdapter mSk_searchAssociationAdapter;
    /** "默认", "价格", "销量" */
    public XCMoveBlockPlusFragment searchResultSortFragment;
    /**
     * 药箱
     */
    private RelativeLayout rl_recipe_cart;
    /**
     * 药数量的布局
     */
    private LinearLayout ll_medicine_num;
    /**
     * 药数量
     */
    private TextView tv_medicine_num;
    /** 搜索关键字 */
    private String key_word = "";
    /** 默认排序 */
    private static String DEFAULT = "default";
    /** 价格排序 */
    private static String SALEPRICE = "salePrice";
    /**
     * 门诊医生价格排序
     */
    private final String DOCTORPRICE = "doctorPrice";
    /** 销量排序 */
    private static String SALENUM = "saleNum";
    /** 指数排序 */
    private static String DRCOMMISSION = "sortedBy";
    /**
     * 积分排序
     */
    private static String MARKETPOTIN = "marketPoint";
    /** 用于记当前录排序 */
    private String orderBy = "default";
    /** 聊天界面的关键词跳转用的key */
    public static String KEY_WORD = "key_word";
    /** 升序值 */
    private String ASC = "0";
    /** 降序值 */
    private String DESC = "1";
    /** 价格的排序，默认升序 */
    private String saleprice_order = ASC;
    /** 销量的排序，默认升序 */
    private String salenum_order = ASC;
    /** 指数的排序，默认升序 */
    private String drcommission_order = ASC;
    /** 传给服务器的升序或者降序，默认不传，服务器有默认排序 */
    private String order = null;
    /**
     * 是否请求联想词接口
     */
    private boolean showSearchAssociationFlag = true;
    /** 埋点搜索ID，加载下一页的时候传给后端 */
    private String searchId = "";
    /**
     * 进入页标识，会带入药品列表页
     * 0：全科药品（我的药房）；1：常用处方详情添加药品（我的药房）；
     * 2：全科药品（推荐用药，显示处方笺icon）；3：常用处方详情添加药品（推荐用药）；4：处方笺添加药品（推荐用药）
     */
    private int intentFlag;

    private String commonFlag;

    /**
     * 启动此activity
     */
    public static void launch(Context context, int intentFlag, String commonFlag) {

        Intent intent = new Intent(context,SK_MedicineSearchActivity.class);
        intent.putExtra(YR_AllMedicineClassActivity.INTER_FLAG,intentFlag);
        intent.putExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION,commonFlag);
        (context).startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sk_l_activity_search_medicine);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SK_MedicineSearchActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    /**
     * 初始化控件
     */
    @Override
    public void initWidgets() {
        intentFlag = getIntent().getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,0);
        commonFlag = getIntent().getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION);


        rl_recipe_cart = getViewById(R.id.rl_recipe_cart);
        ll_medicine_num = getViewById(R.id.ll_medicine_num);
        tv_medicine_num = getViewById(R.id.tv_medicine_num);

        sk_id_search_association_ll = getViewById(R.id.sk_id_search_association_ll);
        sx_id_main_recoder = getViewById(R.id.sx_id_main_recoder);

        // 标题搜索栏
        skTitleSearchFragment = new SKTitleSearchFragment();
        skTitleSearchFragment.setTabName(XCSearchRecordModelDb.SEARCH_RECORD_INFO1);
        skTitleSearchFragment.setHint("药品搜索");
        addFragment(R.id.xc_id_model_titlebar, skTitleSearchFragment);
        xcMaterialListPinRefreshLayout = getViewById(R.id.sk_id_medicine_drug_list);
        medicineDrugListView = (ListView) xcMaterialListPinRefreshLayout.getListView();
        // 设置搜索结果零数据的背景
        xcMaterialListPinRefreshLayout.setBgZeroHintInfo("没找到相关的药物-更改关键字再试试", "", R.mipmap.js_d_icon_no_data);

        // 搜索结果的适配器
        medicineAdapter = new SK_AddMedicineAdapter(this,null);
        medicineDrugListView.setAdapter(medicineAdapter);
        // 搜索历史布局
        sxSearchRecordFragment = new SXSearchRecordFragment();
        sxSearchRecordFragment.setTabName(XCSearchRecordModelDb.SEARCH_RECORD_INFO1);
        addFragment(R.id.sx_id_main_recoder, sxSearchRecordFragment);

        // 推荐用药 带药箱
        if(2 == intentFlag){
            rl_recipe_cart.setVisibility(View.VISIBLE);
            setMedicineNum();
        }else {
            rl_recipe_cart.setVisibility(View.GONE);
        }

        // 初始化搜索结果排序栏
        initSearchResultFragment();

        // 初始化搜索联想布局
        initSearchAssociationListViewFragment();

    }

    /**
     * 设置监听
     */
    @Override
    public void listeners() {

        // 搜索结果排序监听
        setSearchResultSortFragmentListener();

        // 标题栏相关的监听
        setTitleSearchFragmentListener();

        // 搜索历史的监听
        setSearchRecordFragmentListener();

        // 搜索结果的上下拉监听
        setSearchResultListener();

        // 搜索结果的列表项单击监听，进入到说明书页
        setSearchResultOnItemClickListener();

        // 联想关键字的列表项点击事件
        setSearchAssociationFragmentListener();


        rl_recipe_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkMedicneNum()){
                    SQ_RecommendActivity.launch(SK_MedicineSearchActivity.this);

                }else {
                    shortToast("请选择药品");
                }
            }
        });

    }

    /**
     * 联想关键字的列表项点击事件
     */
    private void setSearchAssociationFragmentListener() {
        mSearchAssociationListViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                SearchModel bean = (SearchModel) arg0.getItemAtPosition(arg2);
                xcMaterialListPinRefreshLayout.resetCurrentPageAndList(medicineAdapter);
                showSearchAssociationFlag = false;// 不需要请求联想词接口
                requestSearch(bean.getName(), "1", orderBy,order);
                skTitleSearchFragment.save(bean.getName());
                sxSearchRecordFragment.adapter();
            }
        });
    }

    /**
     * 搜索结果的列表项单击监听，进入到说明书页
     * 加入药房的监听
     */
    private void setSearchResultOnItemClickListener() {
        medicineDrugListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DrugBean bean = (DrugBean) parent.getItemAtPosition(position);
                UtilNativeHtml5.toJumpDrugDetail(SK_MedicineSearchActivity.this,bean.getId());
                // created by songxin,date：2016-6-29,about：saveInfo,begin
                DurgSreachBi.getInstance().setScot(bean.getName());
                // created by songxin,date：2016-6-29,about：saveInfo,end
                DrugBean.drug_id = bean.getId();
            }
        });

        medicineAdapter.setOnAddMedicineAdapterAction(new SK_AddMedicineAdapter.SK_AddMedicineAdapterAction() {
            @Override
            public void onAddBoxAction(View v) {
                DrugBean bean = (DrugBean) v.getTag();

                // 我的药房
                if(0 == intentFlag){
                    // 添加到常用药
                    bean.setAdded(true);
                    DurgSreachBi.getInstance().setDname(bean.getName());
                    DurgSreachBi.getInstance().setSkuid(bean.getSkuId());
                    DurgSreachBi.getInstance().setDurgid(bean.getId());
                    DurgSreachBi.getInstance().setSearchid(searchId);
                    // created by songxin,date：2018-01-09,about：saveInfo,begin
                    BiUtil.saveBiInfo(SK_MedicineSearchActivity.class, "2", "128", "E00103","", false);
                    // created by songxin,date：2018-01-09,about：saveInfo,end
                    requestAddBox((Button) v,bean, bean.getId());
                    // 我的药房 常用处方详情页
                }else if(1 == intentFlag){
                    // 选中
                    if (null == RecomMedicineHelper.getInstance().getCommonRecipe().getCheckMap().get(bean.getId())) {
                        ToJumpHelp.toJumpUsageActivitiy(SK_MedicineSearchActivity.this,bean,intentFlag,commonFlag);
                    }
                    // 推荐用药 带药箱
                }else if(2 == intentFlag){
                    // created by songxin,date：2018-01-09,about：saveInfo,begin
                    BiUtil.saveBiInfo(SK_MedicineSearchActivity.class, "2", "128", "E00095","", false);
                    // created by songxin,date：2018-01-09,about：saveInfo,end
                    if (null != RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getCheckDrugMap().get(bean.getId())) {
                        RecomMedicineHelper.getInstance().removeDrugBean(bean.getId());
                        setMedicineNum();
                        medicineAdapter.notifyDataSetChanged();

                    } else {
                        ToJumpHelp.toJumpUsageActivitiy(SK_MedicineSearchActivity.this,bean,intentFlag,commonFlag);
                    }

                    // 推荐用药 常用处方详情页 不带药箱
                }else if(3 == intentFlag){
                    if (null == RecomMedicineHelper.getInstance().getCommonRecipe().getCheckMap().get(bean.getId())) {
                        ToJumpHelp.toJumpUsageActivitiy(SK_MedicineSearchActivity.this,bean,intentFlag,commonFlag);
                    }

                    // 推荐用药 处方笺页 不带药箱
                }else if(4 == intentFlag){
                    if(null == RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getCheckDrugMap().get(bean.getId())) {
                        ToJumpHelp.toJumpUsageActivitiy(SK_MedicineSearchActivity.this,bean,intentFlag,commonFlag);
                    }
                }
            }

        });
    }

    /**
     * 搜索结果的上下拉监听
     */
    private void setSearchResultListener() {
        // 搜索结果的上下拉监听
        xcMaterialListPinRefreshLayout.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {
                return false;
            }

            @Override
            public boolean canLoad() {
                return true;
            }

            @Override
            public void refresh(View view, int request_page) {

            }

            // 搜索结果的上拉监听，请求下一页数据
            @Override
            public void load(View view, int request_page) {
                requestSearch(key_word,request_page + "", orderBy,order);
            }
            });
    }

    // 键盘是否已弹出，防止键盘未弹出的情况 点击搜索历史不能切换view
    public boolean isShowKeyBoard = false;
    /**
     * 搜素历史相关的监听
     */
    private void setSearchRecordFragmentListener() {
        // 搜索历史列表页 当软键盘隐藏的时候回调该监听
        sxSearchRecordFragment.setOnKeyBoardStatusListener(new SXSearchRecordFragment.OnKeyBoardStatusListener() {
            @Override
            public void onStatusChange(boolean is_key_board_show) {
                // onStatusChange()仅监听 从显示状态 -- > 隐藏状态 , 关闭记录页面
                if (!is_key_board_show) {
                    hideFragment(sxSearchRecordFragment);
                    sx_id_main_recoder.setVisibility(View.GONE);
                    isShowKeyBoard = false;
                }else {
                    dShortToast("show keyboard");
                    isShowKeyBoard = true;
                }
            }
        });

        // 搜索历史列表页 列表项的点击事件
        sxSearchRecordFragment.setOnRecordItemClickListener(new SXSearchRecordFragment.OnRecordItemClickListener() {

            @Override
            public void onRecordItemClickListener(XCSearchRecordModel model, String key_word, int position) {
                xcMaterialListPinRefreshLayout.resetCurrentPageAndList(medicineAdapter);
                showSearchAssociationFlag = false;// 不需要请求联想词接口
                requestSearch(key_word, "1", orderBy, order);
                if(!isShowKeyBoard){
                    hideFragment(sxSearchRecordFragment);
                    sx_id_main_recoder.setVisibility(View.GONE);
                }
                // 隐藏键盘，会调用隐藏历史记录
                UtilInputMethod.hiddenInputMethod(SK_MedicineSearchActivity.this);


            }
        });

        // 设置监听 使其点击空白区域不会点到底下的商品列表
        sx_id_main_recoder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {}
        });

    }

    /**
     * 标题搜索栏相关的监听
     */
    private void setTitleSearchFragmentListener() {
        // 搜索标题栏的键盘搜索监听
        skTitleSearchFragment.setOnSearchlistener(new SKTitleSearchFragment.OnKeyBoardSearchListener() {
            @Override
            public void searchKeyDown(String key_word) {
                xcMaterialListPinRefreshLayout.resetCurrentPageAndList(medicineAdapter);
                requestSearch(key_word, "1", orderBy,order);
                sxSearchRecordFragment.adapter();
                // created by songxin,date：2016-6-29,about：saveInfo,begin
                DurgSreachBi.getInstance().setScot(key_word);
                // created by songxin,date：2016-6-29,about：saveInfo,end

            }
        });

        // 搜索标题栏的取消按钮监听
        skTitleSearchFragment.setOnClickCancleButtonListener(new SKTitleSearchFragment.OnClickCancleButtonListener() {
            @Override
            public void clicked(String key_word) {
                finish();
            }
        });

        // 搜索标题编辑框的点击事件
        skTitleSearchFragment.setOnClicklistener(new SKTitleSearchFragment.OnEditTextClickedListener() {
            @Override
            public void clicked() {
                //不为空 , 则显示记录页面 ,隐藏搜索页面
                if (sxSearchRecordFragment.isHidden()) {
                    showFragment(sxSearchRecordFragment);
                    sx_id_main_recoder.setVisibility(View.VISIBLE);
                }
            }
        });

        // 搜索标题编辑框的关键字联想功能的监听
        skTitleSearchFragment.setSearchTextWatcher(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tempKey = s + "";
                if("".equals(s) || null == s || s.length() < 1){
                    hideSearchAssociationListViewFragment();
                    return;
                }
                searchAssociationKey = s+"";
                searchAssociationTimer();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    /**
     * 初始化搜索结果排序栏
     */
    private void initSearchResultFragment() {
        searchResultSortFragment = new XCMoveBlockPlusFragment();
        // 调价版本新增  0不显示 、1小七指数、2市场积分
        if("1".equals(UtilSP.getShowCommission())) {
            searchResultSortFragment.setContents(new String[]{"默认", "价格", "销量", "指数"});
            searchResultSortFragment.setImageUris(new String[]{null, "drawable://" + R.mipmap.sk_arrow_def, "drawable://" + R.mipmap.sk_arrow_def, "drawable://" + R.mipmap.sk_arrow_def});
            searchResultSortFragment.setInitSelected(0, 4, true, 0);
        }else if("2".equals(UtilSP.getShowCommission())) {
            searchResultSortFragment.setContents(new String[]{"默认", "价格", "销量", "积分"});
            searchResultSortFragment.setImageUris(new String[]{null, "drawable://" + R.mipmap.sk_arrow_def, "drawable://" + R.mipmap.sk_arrow_def, "drawable://" + R.mipmap.sk_arrow_def});
            searchResultSortFragment.setInitSelected(0, 4, true, 0);
        }else {
            searchResultSortFragment.setContents(new String[]{"默认", "价格", "销量"});
            searchResultSortFragment.setImageUris(new String[]{null, "drawable://" + R.mipmap.sk_arrow_def, "drawable://" + R.mipmap.sk_arrow_def});
            searchResultSortFragment.setInitSelected(0, 3, true, 0);
        }
        searchResultSortFragment.setIsHiddenBlock(true);
        searchResultSortFragment.setDivideLineMargin(10, 10);
        searchResultSortFragment.setMove_block_item_id(R.layout.sk_l_view_item_search_sort);
        searchResultSortFragment.setItemTextPressColorAndDefaulColor(R.color.c_e2231a, R.color.c_7b7b7b);
        addFragment(R.id.sk_id_choice_medicine_search_result, searchResultSortFragment);
        showFragment(searchResultSortFragment);
    }


    /**
     * 初始化搜索联想界面
     */
    private void initSearchAssociationListViewFragment() {
        mSearchAssociationListViewFragment = new XCListViewFragment();
        mSk_searchAssociationAdapter = new SK_SearchAssociationAdapter(this,null);
        mSearchAssociationListViewFragment.setAdapter(mSk_searchAssociationAdapter);
        ColorDrawable colorDrawable = new ColorDrawable(0xFFBEBEBE);
        mSearchAssociationListViewFragment.setListViewStyleParam(colorDrawable, 1, false);
        addFragment(R.id.sk_id_search_association_ll, mSearchAssociationListViewFragment);
        hideFragment(mSearchAssociationListViewFragment);
    }

    /**
     * 搜索结果排序监听
     */
    private void setSearchResultSortFragmentListener() {
        searchResultSortFragment.setOnClickMoveListener(new XCMoveBlockPlusFragment.OnClickMoveListener() {
            @Override
            public void onClickMoveListener(int position, ViewGroup current_item, ImageView current_imageview, ViewGroup last_item, ImageView last_imageview) {

                int last_position = (int) last_item.getTag() / 2;
                switch (position) {
                    case 0:
                        // 选中默认
                        checkDefault(last_imageview, last_position);
                        break;

                    case 1:
                        // 选中价格
                        checkSalePrice(current_imageview, last_imageview, last_position);
                        break;

                    case 2:
                        // 选中销量
                        checkSelenum(current_imageview, last_imageview, last_position);
                        break;

                    case 3:
                        // 选中指数
                        checkDrcommission(current_imageview, last_imageview, last_position);
                        break;

                }
            }

            /**
             * 选中默认排序
             * @param last_imageview 上一次停留的imageview
             * @param last_position  上一次停留的位置
             */
            private void checkDefault(ImageView last_imageview, int last_position) {
                if (UtilString.isBlank(key_word)) {
                    return;
                }
                if (last_position != 0) {
                    last_imageview.setImageResource(R.mipmap.sk_arrow_def);
                }
                xcMaterialListPinRefreshLayout.resetCurrentPageAndList(medicineAdapter);
                requestSearch(key_word, "1", DEFAULT, null);
                dShortToast("销量");
            }

            /**
             * 选中价格排序
             * @param current_imageview 当前的imageview
             * @param last_imageview    上一次停留的imageview
             * @param last_position     上一次停留的位置
             */
            private void checkSalePrice(ImageView current_imageview, ImageView last_imageview, int last_position) {
                if (UtilString.isBlank(key_word)) {
                    return;
                }
                // 如果是升序
                if (ASC.equals(saleprice_order)) {
                    saleprice_order = DESC;
                    current_imageview.setImageResource(R.mipmap.sk_arrow_down);
                } else {
                    saleprice_order = ASC;
                    current_imageview.setImageResource(R.mipmap.sk_arrow_top);
                }
                if (last_position == 2) {
                    last_imageview.setImageResource(R.mipmap.sk_arrow_def);
                }else if(last_position == 3){
                    last_imageview.setImageResource(R.mipmap.sk_arrow_def);
                }
                xcMaterialListPinRefreshLayout.resetCurrentPageAndList(medicineAdapter);
                if("2".equals(UtilSP.getShowCommission())) {
                    requestSearch(key_word, "1", DOCTORPRICE, saleprice_order);
                }else {
                    requestSearch(key_word, "1", SALEPRICE, saleprice_order);
                }
                dShortToast("销量");
            }

            /**
             * 选中销量排序
             * @param current_imageview 当前的imageview
             * @param last_imageview    上一次停留的imageview
             * @param last_position     上一次停留的位置
             */
            private void checkSelenum(ImageView current_imageview, ImageView last_imageview, int last_position) {
                if (UtilString.isBlank(key_word)) {
                    return;
                }
                if (ASC.equals(salenum_order)) {
                    salenum_order = DESC;
                    current_imageview.setImageResource(R.mipmap.sk_arrow_down);
                } else {
                    salenum_order = ASC;
                    current_imageview.setImageResource(R.mipmap.sk_arrow_top);
                }
                if (last_position == 1) {
                    last_imageview.setImageResource(R.mipmap.sk_arrow_def);
                }else if(last_position == 3){
                    last_imageview.setImageResource(R.mipmap.sk_arrow_def);
                }
                xcMaterialListPinRefreshLayout.resetCurrentPageAndList(medicineAdapter);
                requestSearch(key_word, "1", SALENUM, salenum_order);
                dShortToast("销量");
            }

            /**
             * 选中指数排序
             * @param current_imageview 当前的imageview
             * @param last_imageview    上一次停留的imageview
             * @param last_position     上一次停留的位置
             */
            private void checkDrcommission(ImageView current_imageview, ImageView last_imageview, int last_position) {
                if (UtilString.isBlank(key_word)) {
                    return;
                }
                if (ASC.equals(drcommission_order)) {
                    drcommission_order = DESC;
                    current_imageview.setImageResource(R.mipmap.sk_arrow_down);
                } else {
                    drcommission_order = ASC;
                    current_imageview.setImageResource(R.mipmap.sk_arrow_top);
                }
                if (last_position == 1) {
                    last_imageview.setImageResource(R.mipmap.sk_arrow_def);
                }else if(last_position == 2){
                    last_imageview.setImageResource(R.mipmap.sk_arrow_def);
                }
                xcMaterialListPinRefreshLayout.resetCurrentPageAndList(medicineAdapter);
                if("2".equals(UtilSP.getShowCommission())){
                    requestSearch(key_word, "1", MARKETPOTIN, drcommission_order);
                }else {
                    requestSearch(key_word, "1", DRCOMMISSION, drcommission_order);
                }
                dShortToast("指数");
            }
        });
    }

    /**
     * 隐藏搜索联想界面
     */
    public void hideSearchAssociationListViewFragment(){
        if(mSearchAssociationListViewFragment == null){
            return;
        }
        if (!mSearchAssociationListViewFragment.isHidden()){
            if(!mSearchAssociationListViewFragment.isHidden() && !isDestroy && mSearchAssociationListViewFragment.getActivity() != null){
                hideFragment(mSearchAssociationListViewFragment);
                mSearchAssociationListViewFragment.updateList(new ArrayList());
                sk_id_search_association_ll.setVisibility(View.GONE);
            }

        }
    }

    /**
     * 是否正在请求搜索联想中
     */
    private boolean mIsSearchAssociationDoing = true;
    /**
     * 搜索联想关键字
     */
    private String searchAssociationKey = "";
    public void searchAssociationTimer(){
        if(mIsSearchAssociationDoing) {
            if(showSearchAssociationFlag){
                mIsSearchAssociationDoing = false;
                requestSearchAssociation(searchAssociationKey);
            }
        }
    }

    /** 源数据 */
    private List<DrugBean> dataList = new ArrayList<>();

    /**
     * 讲xcjsonbean解析为drugBean
     * @param list 源数据
     */
    public void parseData(List<XCJsonBean> list) {
        dataList = new ArrayList<>();
        Parse2DrugBean parse2DrugBean = new Parse2DrugBean();
        for (XCJsonBean bean : list){
            dataList.add(parse2DrugBean.parse(new DrugBean(),bean));
        }
    }

    /** 是否正在搜索,用于控制联想搜索显示 */
    private boolean isSearchIng = false;
    /** 临时记录搜索edittext内容 */
    private String tempKey = "";

    /**
     * 请求搜索的接口
     * @param key       关键词
     * @param page      页数
     * @param orderBy   排序（默认，价格，销量）
     * @param order     升序或降序 （升序：0、降序：1）
     */
    public void requestSearch(String key,String page,String orderBy,String order){
        this.orderBy = orderBy;
        this.order = order;
        key_word = key;
        isSearchIng = true;

        if("1".equals(page)){
            // 如果是第一页的话
            searchId = "";
        }

        if(TextUtils.isEmpty(key_word)){
            key_word = "";
        }
        if(!key_word.equals(tempKey) && skTitleSearchFragment != null) {
            tempKey = key_word;
            skTitleSearchFragment.setText(key_word);
        }

        RequestParams params = new RequestParams();
        params.put("key",key);
        params.put("page",page);
        params.put("orderBy",orderBy);
        if(!UtilString.isBlank(searchId)){
            params.put("searchId",searchId);
        }
        if(!UtilString.isBlank(order)) {
            params.put("order", order);
        }
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.madicine_search), params, new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !isDestroy) {

                    List<XCJsonBean> mSearchResultBeans = result_bean.getList("data");

                    xcMaterialListPinRefreshLayout.setTotalPage(mSearchResultBeans.get(0).getString("totalPages"));
                    searchId = mSearchResultBeans.get(0).getString("searchId");
                    List<XCJsonBean> beans = mSearchResultBeans.get(0).getList("result");

                    parseData(beans);

                    xcMaterialListPinRefreshLayout.updateListAdd(dataList,medicineAdapter);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                xcMaterialListPinRefreshLayout.completeRefresh(result_boolean);
                isSearchIng = false;
                showSearchAssociationFlag = true;
                if(!isDestroy){
                    hideSearchAssociationListViewFragment();
                }
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SK_MedicineSearchActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 请求添加常用药的接口
     * @param id 药品ID
     */
    public void requestAddBox(final Button button,final DrugBean bean, String id){
        RequestParams params = new RequestParams();
        params.put("pid", id);
        XCHttpAsyn.postAsyn(this,AppConfig.getHostUrl(AppConfig.madicine_addbox),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                dShortToast("添加成功");
                // 以下是已添加数加1
                int addNum = bean.getAddNum();
                bean.setAddNum(addNum + 1 );
                bean.setAdded(true);
                medicineAdapter.notifyDataSetChanged();
                button.setClickable(false);
                button.setBackgroundResource(R.mipmap.sk_dd_added);
                button.setTextColor(context.getResources().getColor(R.color.c_gray_7b7b7b));
                button.setText("已加入常用药");
                RecomMedicineHelper.getInstance().setUpdateCommonMedicine(true);
            }
            @Override
            public void onFinish() {
                super.onFinish();
                // 处理code操作
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SK_MedicineSearchActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 请求搜索联想关键词的接口
     * @param str 关键词
     */
    public void requestSearchAssociation(String str){
        //可以过滤
//        str = URLEncoder.encode(str);
        RequestParams params = new RequestParams();
        params.put("key",str);
        params.put("doctorId",UtilSP.getUserId());
        XCHttpAsyn.getAsyn(true, false, false, this, AppConfig.getHostUrl(AppConfig.medication_associationSearch), params, new XCHttpResponseHandler(this) {
//            XCHttpAsyn.getAsyn(true,false,false, this, AppConfig.SearchAssociationApi + str, params, new XCHttpResponseHandler() {
//            XCHttpAsyn.getAsyn(true,false,false, this, "http://172.16.1.153:9999/search/list/?goods_info=0&query_str=" + str, params, new XCHttpResponseHandler(null) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !isSearchIng && !isDestroy) {
                    List<SearchModel> list = new Parse2SearchModel().parse(result_bean);
                    mSearchAssociationListViewFragment.updateSpecialList(list);
                    if (list.size() > 0) {
                        if(mSearchAssociationListViewFragment.isHidden()){
                            sk_id_search_association_ll.setVisibility(View.VISIBLE);
                            showFragment(mSearchAssociationListViewFragment);
                        }
                    }
                    // if (mSearchAssociationListViewFragment.isHidden()) {
                    //     showFragment(mSearchAssociationListViewFragment);
                    // }
                } else if(result_boolean && isSearchIng && !isDestroy){
                    hideSearchAssociationListViewFragment();
                }

            }

            @Override
            public void onFinish() {
                super.onFinish();
                mIsSearchAssociationDoing = true;

                if (UtilString.isBlank(searchAssociationKey) && !isDestroy) {
                    hideSearchAssociationListViewFragment();
                }
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SK_MedicineSearchActivity.this,
                        getCode(),
                        getMsg())) {
                }

            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
            }

            @Override
            public void fail() {
            }
        });

    }

    /**
     * activity是否被销毁  true：是 ，false：否  默认false
     */
    boolean isDestroy = false;
    @Override
    protected void onDestroy() {
        super.onDestroy();
        isDestroy = true;
    }

    /**
     * 点击无网络背景时的操作会调用此方法
     */
    @Override
    public void onNetRefresh() {
        requestSearch(key_word, "1", DEFAULT,null);
    }

    /**
     * 设置药箱药品数量
     */
    public void setMedicineNum(){
        int num = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size();
        if(num==0){
            ll_medicine_num.setVisibility(View.GONE);
        }else if(num<100){
            ll_medicine_num.setVisibility(View.VISIBLE);
            ll_medicine_num.setBackgroundResource(R.mipmap.xd_red_round);
        }else if(num>=100){
            ll_medicine_num.setVisibility(View.VISIBLE);
            ll_medicine_num.setBackgroundResource(R.drawable.xd_red_round);
        }
        tv_medicine_num.setText("" + num);
    }

    /**
     * 数字动画0
     */
    private void startNumAnimation() {
        ObjectAnimator rotation = ObjectAnimator.ofFloat(ll_medicine_num, "rotation", -180f,
                0f);
        rotation.setDuration(300);
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(ll_medicine_num, "scaleX", 0.8f, 1f);
        scaleX.setDuration(300);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(ll_medicine_num, "scaleY", 0.8f, 1f);
        scaleY.setDuration(300);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(rotation, scaleX, scaleY);
        animatorSet.setStartDelay(500);
        animatorSet.start();
    }

    /**
     * 检查药箱是否有药
     * @return
     */
    private boolean checkMedicneNum() {
        if(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size()>0){
            return true;
        }else {
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode != Activity.RESULT_OK){
            return;
        }

        if(requestCode == UsageActivityV2.REQUEST_CODE_USAGE){
            DrugBean drugBean = (DrugBean) data.getSerializableExtra(UsageActivityV2.DRUG_INFO);
            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().add(drugBean);
            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getCheckDrugMap().put(drugBean.getId(),true);
            //开始数量动画
            startNumAnimation();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        medicineAdapter.notifyDataSetChanged();
        setMedicineNum();
    }
}
