package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.XD_BatchSelctPatientsActivity;
import com.qlk.ymz.model.CheckPatientBean;
import com.qlk.ymz.util.CommonConfig;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by xiedong on 2017/3/30.
 * 批量设置患者分组适配器
 */

public class PatientGroupAdapter extends BaseExpandableListAdapter {
    //患者数据
    private List<List<CheckPatientBean>> mPatientsList;
    //字母集合
    private List<String> mLetterList;
    //选中的患者id集合
    private List<String> mCheckPatients = new ArrayList<>();
    //存储患者的勾选状态map
    private Map<String, Boolean> mCheckMap = new HashMap<>();
    private Context context;
    private LayoutInflater inflater;
    //保存字母位置
    private LinkedHashMap<String, Integer> savaLetterPositionMap = new LinkedHashMap<>();

    public PatientGroupAdapter(List<List<CheckPatientBean>> mPatientsList, List<String>
            mLetterList, Context context,List<String> mCheckPatients,Map<String, Boolean> mCheckMap) {
        this.mPatientsList = mPatientsList;
        this.mLetterList = mLetterList;
        this.context = context;
        this.mCheckPatients = mCheckPatients;
        this.mCheckMap = mCheckMap;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getGroupCount() {
        return mLetterList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return mPatientsList.get(groupPosition).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return mLetterList.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return mPatientsList.get(groupPosition).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupViewHolder groupViewHolder;
        if (convertView != null) {
            groupViewHolder = (GroupViewHolder) convertView.getTag();
        } else {
            convertView = inflater.inflate(R.layout.xd_item_patient_group,
                    null);
            groupViewHolder = GroupViewHolder.getViewHolder(convertView);
        }
        groupViewHolder.tv_patient_letter.setText(mLetterList.get(groupPosition));
        return convertView;
    }


    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        ChildViewHolder childViewHolder;
        if (convertView != null) {
            childViewHolder = (ChildViewHolder) convertView.getTag();
        } else {
            convertView = inflater.inflate(R.layout.xd_item_patient_group_child,
                    null);
            childViewHolder = ChildViewHolder.getViewHolder(convertView);
        }
        //患者信息
        final CheckPatientBean checkPatientBean = mPatientsList.get(groupPosition).get(childPosition);
        //加载患者头像
        ImageAware imageAware = new ImageViewAware(childViewHolder.iv_patient_head, false);
        String patientIcon = checkPatientBean.getPatientImgHead();
        if (!TextUtils.isEmpty(patientIcon) && URLUtil.isValidUrl(patientIcon)) {
            XCApplication.displayImage(patientIcon, childViewHolder.iv_patient_head, XCImageLoaderHelper
                    .getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default));
        } else {
            XCApplication.base_imageloader.displayImage("drawable://" + R.mipmap.xc_d_chat_patient_default, imageAware, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_patient_default));
        }
        //判断是否已选
        if (mCheckMap.get(checkPatientBean.getPatientId()) == null || !mCheckMap.get(checkPatientBean
                .getPatientId())) {//未选
            childViewHolder.iv_check.setBackgroundResource(R.mipmap.sx_d_register_no_sure);
        }else {//已选
            childViewHolder.iv_check.setBackgroundResource(R.mipmap.sx_d_register_sure);
        }

        //设置患者名称
        childViewHolder.tv_patient_name.setText(checkPatientBean.getPatientName());
        //设置患者性别
        if (CommonConfig.GENDER_MALE.equals(checkPatientBean.getPatientGender())) {
            childViewHolder.iv_patient_gender.setBackgroundResource(R.mipmap.icon_patient_man);
            childViewHolder.iv_patient_gender.setVisibility(View.VISIBLE);
        } else if (CommonConfig.GENDER_FEMALE.equals(checkPatientBean.getPatientGender())) {
            childViewHolder.iv_patient_gender.setBackgroundResource(R.mipmap.icon_patient_women);
            childViewHolder.iv_patient_gender.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.iv_patient_gender.setVisibility(View.GONE);
        }
        //设置患者年龄
        if (!TextUtils.isEmpty(checkPatientBean.getPatientAge())) {
            childViewHolder.tv_patient_age.setText(checkPatientBean.getPatientAge() + "岁");
        } else {
            childViewHolder.tv_patient_age.setText("");
        }

        //设置咨询费价格
        long price = UtilString.toLong(checkPatientBean.getPayAmount()) / 100;
        if (price > 0) {
            childViewHolder.tv_consult_fee.setText("咨询费" + price+"元");
            childViewHolder.tv_consult_fee.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.tv_consult_fee.setVisibility(View.GONE);
        }
        //分割线设置
        childViewHolder.line.setVisibility(View.VISIBLE);
        if (childPosition == mPatientsList.get(groupPosition).size() - 1) {
            childViewHolder.line.setVisibility(View.GONE);

        }
        //条目点击监听
        childViewHolder.rl_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCheckMap.get(checkPatientBean.getPatientId()) == null || !mCheckMap.get(checkPatientBean.getPatientId())) {//未选
                    mCheckPatients.add(checkPatientBean.getPatientId());//添加到选中集合
                    mCheckMap.put(checkPatientBean.getPatientId(), true);//更新选中记录
                }else {
                    mCheckPatients.remove(checkPatientBean.getPatientId());//从选中集合移除
                    mCheckMap.put(checkPatientBean.getPatientId(), false);//更新选中记录
                }
                //刷新ui
                notifyDataSetChanged();
                ((XD_BatchSelctPatientsActivity) context).updateBottomUI();
            }
        });
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    /**
     * 获取字母的位置
     */
    public Integer getPositionFromLetter(String letter) {
        return savaLetterPositionMap.get(letter);
    }

    /**
     * 保存字母的位置
     */
    public LinkedHashMap<String, Integer> initLettersPosition(List<String> listParent, List<List<CheckPatientBean>> listChild) {
        String record_last_letter = null;
        for (int i = 0; i < listParent.size(); i++) {
            String letter = listParent.get(i);
            if (!letter.equals(record_last_letter)) {
                if (listChild.get(i) != null) {
                    if (i == 0) {
                        savaLetterPositionMap.put(letter, 0);
                    } else {
                        // position等于上一个字母的位置+改字母的子项的数量
                        int position = 1 + savaLetterPositionMap.get(record_last_letter) + listChild.get(i - 1).size();
                        savaLetterPositionMap.put(letter, position);
                    }
                }
            }
            record_last_letter = letter;
        }
        return savaLetterPositionMap;
    }

    /**
     * 更新字母位置关系map
     */
    public void updateABCPosition() {
        savaLetterPositionMap.clear();
        if (mLetterList != null && mLetterList.size() != 0) {
            initLettersPosition(mLetterList, mPatientsList);
        }
    }


    static class GroupViewHolder {
        TextView tv_patient_letter;


        public GroupViewHolder(View convertView) {
            tv_patient_letter = (TextView) convertView.findViewById(R.id.tv_patient_letter);
        }

        public static GroupViewHolder getViewHolder(View convertview) {
            GroupViewHolder holder = (GroupViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new GroupViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }

    static class ChildViewHolder {
        //选择的图标
        ImageView iv_check;
        //患者头像
        XCRoundedImageView iv_patient_head;
        //患者名称
        TextView tv_patient_name;
        //患者性别
        ImageView iv_patient_gender;
        //患者年龄
        TextView tv_patient_age;
        //咨询费
        TextView tv_consult_fee;
        //子布局条目
        RelativeLayout rl_item;
        //分割线
        View line;

        public ChildViewHolder(View convertView) {
            iv_check = (ImageView) convertView.findViewById(R.id.iv_check);
            tv_patient_name = (TextView) convertView.findViewById(R.id.tv_patient_name);
            iv_patient_head = (XCRoundedImageView) convertView.findViewById(R.id.iv_patient_head);
            iv_patient_gender = (ImageView) convertView.findViewById(R.id.iv_patient_gender);
            tv_patient_age = (TextView) convertView.findViewById(R.id.tv_patient_age);
            tv_consult_fee = (TextView) convertView.findViewById(R.id.tv_consult_fee);
            rl_item = (RelativeLayout) convertView.findViewById(R.id.rl_item);
            line = convertView.findViewById(R.id.line);
        }

        public static ChildViewHolder getViewHolder(View convertview) {
            ChildViewHolder holder = (ChildViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new ChildViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }

}
