package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.fragment.XCCameraPhotoFragment;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.File;

/**
 * SX_EmpCardActivity
 *
 * @author songxin on 2017/7/18.
 * @version 2.9.0
 */
public class SX_EmpCardActivity extends DBActivity implements View.OnClickListener,
        XCCameraPhotoFragment.OnCaremaSelectedFileListener{
    /** 通用标题 */
    private XCTitleCommonLayout titlebar;
    /**工作证上传*/
    private RelativeLayout sx_id_upload_emp_card_rl;
    /**工作证显示*/
    private ImageView sx_id_upload_emp_card_show;
    /**工作证删除*/
    private ImageView sx_id_delete_emp_card;
    /** 提交*/
    private RelativeLayout sx_id_emp_card_submit_authentication_rl;

    /**调用相机Fragment*/
    private XCCameraPhotoFragment xcCameraPhotoFragment;
    /**图片选择弹出Dialog*/
    private ConfirmDialog mUploadDialog;
    /** 上传图片*/
    private TextView xc_id_pop_photoUpload;
    /** 从手机相册选择*/
    private TextView xc_id_pop_localAlbum;
    /** 取消*/
    private TextView xc_id_pop_cancel;
    /**工作证照片文件*/
    private File mEmpCard;

    private Intent mIntent;

    private String mEmpCardPath = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_emp_card);
        super.onCreate(savedInstanceState);
        mEmpCardPath = getIntent().getStringExtra("filePath");
        printi("http","mEmpCardPath----->"+mEmpCardPath);
        if(!UtilString.isBlank(mEmpCardPath)){
            if(mEmpCardPath.contains("http")){
                sx_id_upload_emp_card_rl.setBackgroundResource(0);
                sx_id_delete_emp_card.setVisibility(View.VISIBLE);
                sx_id_upload_emp_card_show.setVisibility(View.VISIBLE);
                XCApplication.displayImage(mEmpCardPath, sx_id_upload_emp_card_show);
                mEmpCard = XCApplication.base_imageloader.getDiscCache().get(mEmpCardPath);
            }else{
                File file = new File(mEmpCardPath);
                if(file == null || !file.isFile()){
                    return;
                }
                mEmpCard = file;
                sx_id_upload_emp_card_rl.setBackgroundResource(0);
                sx_id_delete_emp_card.setVisibility(View.VISIBLE);
                sx_id_upload_emp_card_show.setVisibility(View.VISIBLE);
                Bitmap bm = BitmapFactory.decodeFile(file.getAbsolutePath());
                sx_id_upload_emp_card_show.setImageBitmap(bm);
            }
        }
        mIntent = new Intent();
        //dialog初始化
        initDialog();
        //Fragment初始化
        xcCameraPhotoFragment = new XCCameraPhotoFragment();
        xcCameraPhotoFragment.setIsAllowResizeImage(false);
        addFragment(R.id.sx_id_openshop_camera_rl, xcCameraPhotoFragment);
        xcCameraPhotoFragment.setOnCaremaSelectedFileListener(this);
    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_EmpCardActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */


    @Override
    public void onNetRefresh() {

    }

    /**
     * 控件初始化
     */
    @Override
    public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleCenter(true, "我的工作证");

        sx_id_upload_emp_card_rl = getViewById(R.id.sx_id_upload_emp_card_rl);
        sx_id_upload_emp_card_show = getViewById(R.id.sx_id_upload_emp_card_show);
        sx_id_delete_emp_card = getViewById(R.id.sx_id_delete_emp_card);
        sx_id_emp_card_submit_authentication_rl = getViewById(R.id.sx_id_emp_card_submit_authentication_rl);

    }

    /**
     * 监听
     */
    @Override
    public void listeners() {
        sx_id_upload_emp_card_rl.setOnClickListener(this);
        sx_id_delete_emp_card.setOnClickListener(this);
        sx_id_upload_emp_card_show.setOnClickListener(this);
        sx_id_emp_card_submit_authentication_rl.setOnClickListener(this);

        titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              finish();
            }
        });
    }


    /**
     * dialog初始化
     */
    private void initDialog(){
        int srceenW =  this.getWindowManager().getDefaultDisplay().getWidth();
        mUploadDialog = new ConfirmDialog(SX_EmpCardActivity.this, srceenW,245
                ,R.layout.xc_l_pop_window_photo,R.style.xc_s_dialog);
        mUploadDialog.setCanceledOnTouchOutside(false);
        Window window = mUploadDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        xc_id_pop_photoUpload = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_photoUpload);
        xc_id_pop_localAlbum = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_localAlbum);
        xc_id_pop_cancel = (TextView) mUploadDialog.findViewById(R.id.xc_id_pop_cancel);
        xc_id_pop_photoUpload.setOnClickListener(this);
        xc_id_pop_localAlbum.setOnClickListener(this);
        xc_id_pop_cancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            //拍照
            case R.id.xc_id_pop_photoUpload:{
                xcCameraPhotoFragment.getTakePhoto();
                uploadDialogDismiss();
                break;
            }
            //本地上传
            case R.id.xc_id_pop_localAlbum:{
                ToJumpHelp.toJumpSelctImgsActivity(this, 1, YY_SelectImgsActivity.MODE_SINGLE,
                        false, true, false, true);
                uploadDialogDismiss();
                break;
            }
            //取消
            case R.id.xc_id_pop_cancel:{
                uploadDialogDismiss();
                break;
            }
            //上传工作证
            case R.id.sx_id_upload_emp_card_rl:{
                uploadDialogShow();
                break;
            }
            //上传工作证显示
            case R.id.sx_id_upload_emp_card_show:{
                if(null != mEmpCard){
                    Intent intent = new Intent();
                    intent.putExtra("toShowPicture",0);
                    String s = mEmpCard.getAbsolutePath();
                    intent.putExtra("FILE_PATH", s);
                    intent.putExtra("PICTURE_NAME", "工作证");
                    intent.setClass(SX_EmpCardActivity.this,SX_ShowPictureActivity.class);
                    myStartActivity(intent);

                }
                break;
            }
            //工作证删除
            case R.id.sx_id_delete_emp_card:{
                mEmpCard = null;
                sx_id_upload_emp_card_show.setImageURI(null);
                sx_id_delete_emp_card.setVisibility(View.GONE);
                sx_id_upload_emp_card_show.setVisibility(View.GONE);

                sx_id_upload_emp_card_rl.setBackgroundResource(R.mipmap.sx_d_update_emp_card);
                break;
            }
            //提交
            case  R.id.sx_id_emp_card_submit_authentication_rl:{
                if(null == mEmpCard){
                    shortToast("你好像还没有上传图片");
                    return;
                }
                mIntent.putExtra("filePath",mEmpCard.getAbsolutePath());
                setResult(0,mIntent);
                finish();
            }
        }
    }

    private void uploadDialogDismiss(){
        if(null != mUploadDialog && mUploadDialog.isShowing()){
            mUploadDialog.dismiss();
        }
    }

    private void uploadDialogShow(){
        if(null != mUploadDialog && !mUploadDialog.isShowing()){
            mUploadDialog.show();
        }
    }

    @Override
    public void onCaremaSelectedFile(File file) {
        mEmpCard = file;
        sx_id_delete_emp_card.setVisibility(View.VISIBLE);
        sx_id_upload_emp_card_show.setVisibility(View.VISIBLE);
        sx_id_upload_emp_card_show.setImageURI(Uri.fromFile(file));
        sx_id_upload_emp_card_rl.setBackgroundResource(0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        //用户选择图片完成 add by xd 2017/11/27
        if (requestCode == YY_SelectImgsActivity.REQUEST_IMAGE) {
            if (data == null || data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT) == null) {
                return;
            }
            File file = (File) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
            if (file != null) {
                File toUploadFile = UtilFile.ChangeImgsToUploadFile(file);//压缩图片
                mEmpCard = toUploadFile;
                sx_id_delete_emp_card.setVisibility(View.VISIBLE);
                sx_id_upload_emp_card_show.setVisibility(View.VISIBLE);
                sx_id_upload_emp_card_show.setImageURI(Uri.fromFile(toUploadFile));
                sx_id_upload_emp_card_rl.setBackgroundResource(0);
            }
        }
    }
}
