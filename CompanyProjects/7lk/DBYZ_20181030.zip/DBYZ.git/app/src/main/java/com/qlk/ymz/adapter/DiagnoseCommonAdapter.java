package com.qlk.ymz.adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.DiagnoseCommonBean;

import java.util.List;

/**
 * 常用诊断适配器
 * @author wpq
 * @version 1.0
 */
public class DiagnoseCommonAdapter extends BaseExpandableListAdapter {

    private List<DiagnoseCommonBean> mList;

    public DiagnoseCommonAdapter(List<DiagnoseCommonBean> list) {
        this.mList = list;
    }

    @Override
    public int getGroupCount() {
        return mList == null ? 0 : mList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        // PinnedHeaderExpandableListView.addHeader时groupPosition可能会出现-1
        groupPosition = groupPosition < 0 ? 0 : groupPosition;
        DiagnoseCommonBean commonBean = mList.get(groupPosition);
        return commonBean == null ? 0 : commonBean.voList == null ? 0 : commonBean.voList.size();
    }

    @Override
    public DiagnoseCommonBean getGroup(int groupPosition) {
        return mList.get(groupPosition);
    }

    @Override
    public DiagnoseBean getChild(int groupPosition, int childPosition) {
        DiagnoseCommonBean commonBean = mList.get(groupPosition);
        return commonBean == null ? null : commonBean.voList == null ? null : commonBean.voList.get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupViewHolder groupHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.xc_l_adapter_patient_letter_out_item, null);
            groupHolder = new GroupViewHolder();
            groupHolder.tvLetter = (TextView) convertView.findViewById(R.id.xc_id_fragment_search_letter_view);
            convertView.setTag(groupHolder);
        } else {
            groupHolder = (GroupViewHolder) convertView.getTag();
        }
        DiagnoseCommonBean commonBean = getGroup(groupPosition);
        if (commonBean != null) {
            groupHolder.tvLetter.setText(getGroup(groupPosition).key);
        }
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        ChildViewHolder childHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_diagnose_common, null);
            childHolder = new ChildViewHolder();
            childHolder.tvDiagnoseName = (TextView) convertView.findViewById(R.id.tv_diagnoseName);
            childHolder.splitLine = convertView.findViewById(R.id.splitLine);
            convertView.setTag(childHolder);
        } else {
            childHolder = (ChildViewHolder) convertView.getTag();
        }
        DiagnoseBean diagnoseBean = getChild(groupPosition, childPosition);
        if (diagnoseBean != null) {
            childHolder.tvDiagnoseName.setText(getChild(groupPosition, childPosition).name);
            childHolder.splitLine.setVisibility(childPosition == getChildrenCount(groupPosition) - 1 ? View.GONE : View.VISIBLE);
        }
        return convertView;
    }

    static class GroupViewHolder{
        TextView tvLetter;
    }

    static class ChildViewHolder{
        TextView tvDiagnoseName;
        View splitLine;
    }
}
