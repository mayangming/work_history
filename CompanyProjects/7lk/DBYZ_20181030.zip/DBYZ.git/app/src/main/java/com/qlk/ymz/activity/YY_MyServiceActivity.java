package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.TextPaint;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.LinearLayout;
import android.widget.RadioButton;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.fragment.TF_VideoSettingFragment;
import com.qlk.ymz.fragment.YY_FeedbackSettingFragment;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;

/**
 * @author shuYanYi on 2016/11/07.
 * @description 我的服务
 * @version V2.6.5
 *
 * @author ShuYanYi on 2016/11/17
 * @description 个人中心ui改变了，没有了我的服务页，此页面暂不用了
 */
public class YY_MyServiceActivity extends DBActivity {

    /**标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** 第一个tab控件 */
    private RadioButton service_tab1;
    /** 第二个tab控件 */
    private RadioButton service_tab2;
    /** 第三个tab控件 */
    private RadioButton service_tab3;
    /** 第四个tab控件 */
    private RadioButton service_tab4;
    /** tab的父布局*/
    private ViewGroup ll_menu;

    private View service_menu_line;
    /** 每个菜单tab的宽度*/
    private int tabWidth = 0;
    /** 当前fragment的索引*/
    private int curfragmentIndex;
    /** 滚动条偏移量*/
    private int offsetWidth;
    /** 移动条滑动一个tab的距离*/
    private int moveOneTabWidth;
    /** 菜单滚动条长度*/
    private int barWidth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yy_l_my_service);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-22,about：saveInfo,begin
        BiUtil.saveBiInfo(YY_MyServiceActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-22,about：saveInfo,end
        //默认显示第一个tab
        changeFragmentTab(0,TF_VideoSettingFragment.class);
    }


    /** created by songxin,date：2016-8-16,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YY_MyServiceActivity.class);
    }
    /** created by songxin,date：2016-8-16,about：bi,end */

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "我的服务");
        xc_id_model_titlebar.setTitleLeft(true, null);

        ll_menu = getViewById(R.id.ll_menu);
        service_tab1 = getViewById(R.id.service_tab1);
        service_tab2 = getViewById(R.id.service_tab2);
        service_tab3 = getViewById(R.id.service_tab3);
        service_tab4 = getViewById(R.id.service_tab4);


        //滚动条设置 动态计算菜单数目，适应日后需求变化
        service_menu_line = getViewById(R.id.service_menu_line);
        int tabCount = ll_menu.getChildCount();
        tabWidth = UtilScreen.getScreenWidthPx(this)/tabCount;
        TextPaint paint = service_tab1.getPaint();
        //滚动条长度
        barWidth = (int)paint.measureText("四个字符");
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams)service_menu_line.getLayoutParams();
        lp.width = barWidth;
        offsetWidth = (tabWidth - barWidth)/2;
        moveOneTabWidth = offsetWidth * 2 + barWidth;
    }

    @Override
    public void listeners() {
        xc_id_model_titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        service_tab1.setOnClickListener(this);
        service_tab2.setOnClickListener(this);
        service_tab3.setOnClickListener(this);
        service_tab4.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {
        TF_VideoSettingFragment videoSettingFragment = getFragmentByTag(TF_VideoSettingFragment.class.getSimpleName());
        if(videoSettingFragment != null){
            videoSettingFragment.getVideoStatus();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();


    }

    @Override
    public void onClick(final View v) {
        super.onClick(v);
        //菜单键tab点击进行特殊处理
        if(v instanceof RadioButton){
            menuOnClick((RadioButton)v,true);
        }

    }


    /**
     * 服务设置页tab栏专用点击控制
     * @param checkCanChange 是否检查能否切换fragment
     */
    public void menuOnClick(final RadioButton v,boolean checkCanChange){
        //先检查能否切换fragment
        //如果是从视频预约页跳到其他页面，需检查视频预约时间的设置情况才允许跳转
        if(checkCanChange && v.getId() != R.id.service_tab1){
            TF_VideoSettingFragment videoSettingFragment = getFragmentByTag(TF_VideoSettingFragment.class.getSimpleName());
            if(videoSettingFragment != null && !videoSettingFragment.canQuit()){
                v.setChecked(false);
                final YY_MyServiceActivity act = this;
                videoSettingFragment.setOnVideoSettingDoneListener(new TF_VideoSettingFragment.OnVideoSettingDoneListener() {
                    @Override
                    public void onFinish() {
                        //对话框后，如果点击仍然退出按钮，则需要继续刚才切换fragemnt tab的动作
                        act.menuOnClick(v,false);
                    }
                });
                //打开设置dialog
                videoSettingFragment.initPromptDialog();
                return;
            }
        }

        switch(v.getId()){
            //视频预约
            case R.id.service_tab1 :
                changeFragmentTab(0,TF_VideoSettingFragment.class);
                break;
            //用药随访
            case R.id.service_tab2 :
                changeFragmentTab(1,YY_FeedbackSettingFragment.class);
                break;
            //电话咨询
            case R.id.service_tab3:
                shortToast("敬请期待");
                service_tab3.setChecked(false);
                break;
            //品质预约
             case R.id.service_tab4:
                 shortToast("敬请期待");
                 service_tab4.setChecked(false);
                break;
        }
    }

    /**
     * 切换fragment
     * @param changeIndex 要切换的索引
     * @param fragmentClass
     */
    private void changeFragmentTab(int changeIndex, Class fragmentClass){
        int tabCount = ll_menu.getChildCount();
        if(tabCount == 0){
            return;
        }
        boolean isClickable;
        boolean isChecked;
        for(int i=0; i<tabCount; i++){
            isClickable = !(i == changeIndex);
            isChecked = i == changeIndex;

            RadioButton radioButton = (RadioButton)ll_menu.getChildAt(i);
            radioButton.setClickable(isClickable);
            radioButton.setChecked(isChecked);
        }
        hideBodyFragment();
        showFragmentByClass(fragmentClass, R.id.xc_id_model_content);
        //菜单移动条动画
        int fromX = curfragmentIndex * tabWidth + offsetWidth;
        int toX = changeIndex * tabWidth + offsetWidth;
        Animation animation = new TranslateAnimation(fromX,toX, 0, 0);
        animation.setFillAfter(true);
        animation.setDuration(200);
        service_menu_line.startAnimation(animation);
        curfragmentIndex = changeIndex;
    }

    @Override
    public void onBackPressed() {
        //退出前，其中的视频设置页要检查预约时间是否设置
        TF_VideoSettingFragment videoSettingFragment = getFragmentByTag(TF_VideoSettingFragment.class.getSimpleName());
        if(videoSettingFragment == null){
            myFinish();
        }
        //防止打开开关瞬间，请求没返回之前关掉页面，导致只设置了打开开关，判断时间是否设置的弹窗判断还没获取正确的值 页面就finish
        if(videoSettingFragment.isOpeningVideo){
            shortToast("视频预约时间设置检查中，请稍后");
            return;
        }
        if(!videoSettingFragment.canQuit()){
            final YY_MyServiceActivity act = this;
            videoSettingFragment.setOnVideoSettingDoneListener(new TF_VideoSettingFragment.OnVideoSettingDoneListener() {
                @Override
                public void onFinish() {
                    act.myFinish();
                }
            });
            //打开设置dialog
            videoSettingFragment.initPromptDialog();
            return;
        }
        myFinish();
    }
}
