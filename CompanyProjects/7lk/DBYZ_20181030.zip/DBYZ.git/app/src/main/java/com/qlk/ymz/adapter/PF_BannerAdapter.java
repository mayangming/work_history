package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.jude.rollviewpager.RollPagerView;
import com.jude.rollviewpager.adapter.LoopPagerAdapter;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.R;
import com.qlk.ymz.maintab.JS_HomeFragment;
import com.qlk.ymz.model.BannerInfoBean_V2;
import com.qlk.ymz.parse.Parse2ShareTitle;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 首页banner适配器
 * @author zhangpengfei.
 * @version 2.3
 */
public class PF_BannerAdapter extends LoopPagerAdapter {
    /**
     * 图片显示设置
     */
    private DisplayImageOptions options = XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.js_banner_demo_img);
    /**
     * 数据
     */
    private ArrayList<BannerInfoBean_V2> bannerInfoBean;
    private Context mContext;
    private RollPagerView viewPager;
    public PF_BannerAdapter(Context mContext, RollPagerView viewPager, ArrayList<BannerInfoBean_V2> bannerInfoBean) {
        super(viewPager);
        this.mContext = mContext;
        this.viewPager = viewPager;
        if (null != bannerInfoBean){
            this.bannerInfoBean = bannerInfoBean;
        }else{
            this.bannerInfoBean = new ArrayList<>();
        }
    }

    public void setBannerInfoBean(ArrayList<BannerInfoBean_V2> bannerInfoBean) {
        if (null != bannerInfoBean && bannerInfoBean.size() > 0 && null != viewPager){
            this.bannerInfoBean.clear();
            this.bannerInfoBean.addAll(bannerInfoBean);
            notifyDataSetChanged();
        }
    }

    @Override
    public View getView(ViewGroup container, final int position) {
        View convertView = LayoutInflater.from(mContext).inflate(R.layout.pf_item_banner,null);
        ImageView pf_id_item_banner_iv = (ImageView) convertView.findViewById(R.id.pf_id_item_banner_iv);
        // -------------2016-11-25 zhangpengfei add-------------------
        if (bannerInfoBean.size() > 0){
            XCApplication.base_imageloader.displayImage(bannerInfoBean.get(position).getImageUrl(), pf_id_item_banner_iv, options);
            pf_id_item_banner_iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    // add by songxin,date：2016-4-25,about：saveInfo,begin
                    BiUtil.saveBiInfo(JS_HomeFragment.class,"2","128","viewPagerLayout_banner","",false);
                    // add by songxin,date：2016-4-25,about：saveInfo,end

                    String targetUrl = bannerInfoBean.get(position).getTargetUrl();

                    //add by songxin,date：2018-3-12,about：GrowingIO banner track,begin
                    Map<String,String> track = new HashMap<>();
                    track.put("position",position+"");
                    track.put("bannerTitle", Parse2ShareTitle.parse(targetUrl));
                    GrowingIOUtil.track("bannerClck", track);
                    //add by songxin,date：2018-3-12,about：GrowingIO banner track,end

                    if (mContext instanceof XCBaseActivity){
                        // 需要通过nativehtml5配置协议来跳转到指定页面(不止h5页面)
                        NativeHtml5.newInstance((XCBaseActivity) mContext).webToAppPage(UtilString.f(targetUrl), 0);
                    }
                }
            });

        }
        // -------------2016-11-25 zhangpengfei end-------------------
        return convertView;
    }

    @Override
    public int getRealCount() {
        if (bannerInfoBean != null && bannerInfoBean.size() > 0){
            return bannerInfoBean.size();
        }
        return 0;
    }
}
