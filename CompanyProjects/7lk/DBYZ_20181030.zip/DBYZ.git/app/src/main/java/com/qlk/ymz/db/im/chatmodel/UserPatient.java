package com.qlk.ymz.db.im.chatmodel;

import android.text.TextUtils;

import com.qlk.ymz.model.PatientInfo;
import com.qlk.ymz.util.Utils;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * description: 患者用户基本信息资料
 * autour: YM
 * date: 2017/7/5
 * version:
 */

public class UserPatient implements Serializable, Cloneable{
    protected String patientId = ""; // 患者id
    protected String patientName = "";//患者名
    protected String patientImgHead = "";//患者头像
    // version 1.5新增字段
    @Deprecated
    protected String patientNickName = ""; // 患者昵称,废弃
    protected String patientMemoName = ""; // 患者备注名称
    protected String patientGender = "";//患者性别 1 男 0 女 其他字段改为""
    protected String patientLetter = "";//患者字母
    protected String patientAge = "";//患者年龄
    protected String isShield = ""; //患者被屏蔽标示（说明：0:不屏蔽，1:屏蔽）

    /**
     * add by cyr on 2016/6/24
     * V2.5添加，患者是否为特别关注：true，是；false,否
     * 特别关注的患者会显示在特别关注列表中
     */
    protected String isAttention = "false";
    /**
     * add by cyr on 2016/6/24
     * V2.5添加，患者创建时间，医生添加该患者的时间
     * 格式："1433312000000"
     */
    protected String createTime = "";
    /**
     * add by cyr on 2016/6/24
     * V2.5添加，患者所在地区
     * 两种：
     * 有的返回   "河北 石家庄"
     * 有的返回  "北京"
     */

    //add by cyr on 2017-2-15 start
    protected String cityName = "";
    /**
     * 患者扫码来源 （只新患者页用到，不需要存储）
     * 1:APP扫码进入
     * 2:互联网医院入口
     * 3：推荐活动关注
     * 4：线上诊室
     */
    protected String source = "";
    /** 设置编辑分组患者页gridView的患者item是否是删除状态（不需要存储） */
    public boolean isDeleteStatus = false;
    /** 设置编辑分组患者页gridView的患者item是否是可点击状态状态（不需要存储） */
    public boolean isClickStatus = true;
    /** 患者分组id */
    protected String groupId = "";
    //add by cyr on 2017-2-15 end
        /* 是否选中患者 */
    private boolean isChoose = false;
    /* 2.8添加患者手机号字段 */
    private String patientPhone = ""; // 患者手机号
    private String newPatientStatus = "0";//新患者状态，1 是新患者，0不是新患者
    /* 2.8是否提示患者填写的基本信息*/
    private String showTips = "";
    private String payAmount = ""; //图文咨询收费金额收费金额,价格为0则认为是免费
    private String consultPayType = "";//会话是否付费(1、2 付费, 0 免费)
    private PatientInfo tipsInfo;//患者个人资料

    // v3.0.0 添加
    protected String myGroup = "";//患者分组
    protected String diagnosis = "";//诊断
    protected String subscribe  = "";// 取消关注 0:未取消 1：取消
    protected String subscribeMsg  = "";//取消关注描述
    protected String xdayRevisit  = "";//X天后复诊
    protected String xdayRevisitMsg  = "";//X天后复诊描述
    protected String xdayNoMedicine  = "";// X天后无药
    protected String xdayNoMedicineMsg  = "";//X天后无药描述
    protected String repurchase  = "";//高复购 0:不显示 1:显示
    protected String repurchaseMsg  = "";//高复购描述
    protected String loyalCustomers  = "";//忠实用户 0:不显示 1:显示
    protected String loyalCustomersMsg  = "";//忠实用户描述


    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getPatientId() {
        return UtilString.f(patientId);
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return UtilString.f(patientName);
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientImgHead() {
        return UtilString.f(patientImgHead);
    }

    public void setPatientImgHead(String patientImgHead) {
        this.patientImgHead = patientImgHead;
    }

    public String getPatientNickName() {
        return UtilString.f(patientNickName);
    }

    public void setPatientNickName(String patientNickName) {
        this.patientNickName = patientNickName;
    }

    public String getPatientMemoName() {
        return UtilString.f(patientMemoName);
    }

    public void setPatientMemoName(String patientMemoName) {
        this.patientMemoName = patientMemoName;
    }

    public String getPatientGender() {
        return UtilString.f(patientGender);
    }

    public void setPatientGender(String patientGender) {
        this.patientGender = patientGender;
    }

    public String getPatientLetter() {
        return UtilString.f(patientLetter);
    }

    public void setPatientLetter(String patientLetter) {
        this.patientLetter = patientLetter;
    }


    public String getPatientAge() {
        return UtilString.f(patientAge);
    }

    public void setPatientAge(String patientAge) {
        this.patientAge = patientAge;
    }

    public String getIsAttention() {
        return isAttention;
    }

    public void setIsAttention(String isAttention) {
        if (TextUtils.isEmpty(isAttention)) {
            isAttention = "false";
        }
        this.isAttention = isAttention;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        if (TextUtils.isEmpty(createTime)) {
            createTime = "0";
        }
        this.createTime = createTime;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        if (TextUtils.isEmpty(cityName)) {
            cityName = "";
        }
        this.cityName = cityName;
    }

    public String getSource() {
        return UtilString.f(source);
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getGroupId() {
        return UtilString.f(groupId);
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public boolean isChoose() {
        return isChoose;
    }

    public void setChoose(boolean choose) {
        isChoose = choose;
    }

    public String getPatientPhone() {
        return UtilString.f(patientPhone);
    }

    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }

    private String getNewPatientStatus() {
        return UtilString.f(newPatientStatus);
    }

    public void setNewPatientStatus(boolean isNewPatient) {
        this.newPatientStatus = isNewPatient ? "1" : "0";
    }
    /* 是否是新患者 */
    public boolean isNewPatient(){
        return "1".equals(getNewPatientStatus());
    }
    public String getShowTips() {
        return showTips;
    }

    public void setShowTips(String showTips) {
        this.showTips = showTips;
    }

    public PatientInfo getTipsInfo() {
        return tipsInfo;
    }

    public void setTipsInfo(PatientInfo tipsInfo) {
        this.tipsInfo = tipsInfo;
    }

    public String getIsShield() {
        //患者被屏蔽标示（说明：0:不屏蔽，1:屏蔽）
        if (null == isShield || isShield.trim().length() == 0 || "null".equalsIgnoreCase(isShield)) {
            isShield = "0";
        }

        return isShield;
    }

    public void setIsShield(String isShield) {
        this.isShield = isShield;
    }


    public String getPayAmount() {
        return UtilString.f(payAmount);
    }

    public void setPayAmount(String payAmount) {
        this.payAmount = payAmount;
    }

    public String getConsultPayType() {
        return UtilString.f(consultPayType);
    }

    public void setConsultPayType(String consultPayType) {
        this.consultPayType = consultPayType;
    }

    /**
     * 本地用的（三选一）
     */
    public String getPatientDisplayName() {
        return Utils.getPatientDisplayName(getPatientMemoName()
                , getPatientName());
    }


    public String getMyGroup() {
        return myGroup;
    }

    public void setMyGroup(String myGroup) {
        this.myGroup = myGroup;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }


        public String getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(String subscribe) {
        this.subscribe = subscribe;
    }

    public String getSubscribeMsg() {
        return subscribeMsg;
    }

    public void setSubscribeMsg(String subscribeMsg) {
        this.subscribeMsg = subscribeMsg;
    }

    public String getXdayRevisit() {
        return xdayRevisit;
    }

    public void setXdayRevisit(String xdayRevisit) {
        this.xdayRevisit = xdayRevisit;
    }

    public String getXdayRevisitMsg() {
        return xdayRevisitMsg;
    }

    public void setXdayRevisitMsg(String xdayRevisitMsg) {
        this.xdayRevisitMsg = xdayRevisitMsg;
    }

    public String getXdayNoMedicine() {
        return xdayNoMedicine;
    }

    public void setXdayNoMedicine(String xdayNoMedicine) {
        this.xdayNoMedicine = xdayNoMedicine;
    }

    public String getXdayNoMedicineMsg() {
        return xdayNoMedicineMsg;
    }

    public void setXdayNoMedicineMsg(String xdayNoMedicineMsg) {
        this.xdayNoMedicineMsg = xdayNoMedicineMsg;
    }

    public String getRepurchase() {
        return repurchase;
    }

    public void setRepurchase(String repurchase) {
        this.repurchase = repurchase;
    }

    public String getRepurchaseMsg() {
        return repurchaseMsg;
    }

    public void setRepurchaseMsg(String repurchaseMsg) {
        this.repurchaseMsg = repurchaseMsg;
    }

    public String getLoyalCustomers() {
        return loyalCustomers;
    }

    public void setLoyalCustomers(String loyalCustomers) {
        this.loyalCustomers = loyalCustomers;
    }

    public String getLoyalCustomersMsg() {
        return loyalCustomersMsg;
    }

    public void setLoyalCustomersMsg(String loyalCustomersMsg) {
        this.loyalCustomersMsg = loyalCustomersMsg;
    }
}