package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.AddresseeInfoBean;

import java.util.List;

/**
 * SX_AddresseeAdapter
 * 收件人列表适配器
 * @author songxin on 2017/3/28.
 * @version 2.7.0
 */
public class SX_AddresseeAdapter extends BaseExpandableListAdapter {
    private List<AddresseeInfoBean> addresseeInfoBeanList;
    private Context context;
    private LayoutInflater groupInflater;
    private LayoutInflater childInflater;
    private ExpandableListView re_fragment_search_slide_listview;


    public SX_AddresseeAdapter(List<AddresseeInfoBean> addresseeInfoBeanList,Context context,ExpandableListView re_fragment_search_slide_listview){
        this.addresseeInfoBeanList = addresseeInfoBeanList;
        this.context = context;
        groupInflater = LayoutInflater.from(context);
        childInflater = LayoutInflater.from(context);
        this.re_fragment_search_slide_listview = re_fragment_search_slide_listview;
    }
    @Override
    public int getGroupCount() {
        return addresseeInfoBeanList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        if(groupPosition == 0 || groupPosition == 3){
            return 0;
        }else if(groupPosition == 1 || groupPosition == 2){
            return addresseeInfoBeanList.get(groupPosition).getPatientGroupBeen().size();
        }
        return 0;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return addresseeInfoBeanList.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        if(groupPosition == 0 || groupPosition == 3){
            return null;
        }else if(groupPosition == 1 || groupPosition == 2){
            return addresseeInfoBeanList.get(groupPosition).getPatientGroupBeen().get(childPosition);
        }
        return null;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        final GroupViewHolder groupViewHolder;
        if(null == convertView){
            convertView = groupInflater.inflate(R.layout.sx_l_adapter_addressee_group_item, null);
            groupViewHolder = new GroupViewHolder();
            groupViewHolder.sx_id_choose = (ImageView) convertView.findViewById(R.id.sx_id_choose);
            groupViewHolder.sx_id_addressee_name = (TextView) convertView.findViewById(R.id.sx_id_addressee_name);
            groupViewHolder.sx_id_arrow = (ImageView) convertView.findViewById(R.id.sx_id_arrow);
            groupViewHolder.sx_id_addressee_group_ll = (LinearLayout)convertView.findViewById(R.id.sx_id_addressee_group_ll);
            convertView.setTag(groupViewHolder);
        }else{
            groupViewHolder = (GroupViewHolder) convertView.getTag();
        }
        if(groupPosition == 0){
            groupViewHolder.sx_id_arrow.setVisibility(View.GONE);
        }else if (groupPosition == 3){
            groupViewHolder.sx_id_arrow.setVisibility(View.VISIBLE);
            groupViewHolder.sx_id_arrow.setImageResource(R.mipmap.sx_d_right_arrow);
        }else {
            groupViewHolder.sx_id_arrow.setVisibility(View.VISIBLE);
            if(isExpanded){
                groupViewHolder.sx_id_arrow.setImageResource(R.mipmap.sx_d_up_arrow);
            }else {
                groupViewHolder.sx_id_arrow.setImageResource(R.mipmap.sx_d_down_arrow);
            }
        }
        if(addresseeInfoBeanList.get(groupPosition).isChoose()){
            groupViewHolder.sx_id_choose.setVisibility(View.VISIBLE);
        }else{
            groupViewHolder.sx_id_choose.setVisibility(View.INVISIBLE);
        }
        groupViewHolder.sx_id_addressee_name.setText(addresseeInfoBeanList.get(groupPosition).getAddresseeName());

        return convertView;
    }

    @Override
    public View getChildView(final int groupPosition, final int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        final ChildViewHolder childViewHolder;
        if(null == convertView){
            convertView = childInflater.inflate(R.layout.sx_l_adapter_addressee_child_item, null);
            childViewHolder = new ChildViewHolder();
            childViewHolder.sx_id_choose_child = (ImageView) convertView.findViewById(R.id.sx_id_choose_child);
            childViewHolder.sx_id_addressee_name_child = (TextView) convertView.findViewById(R.id.sx_id_addressee_name_child);
            childViewHolder.sx_id_addressee_child_ll = (LinearLayout)convertView.findViewById(R.id.sx_id_addressee_child_ll);
            convertView.setTag(childViewHolder);
        }else{
            childViewHolder = (ChildViewHolder) convertView.getTag();
        }
        if(addresseeInfoBeanList.get(groupPosition).getPatientGroupBeen().get(childPosition).isChoose()){
            childViewHolder.sx_id_choose_child.setImageResource(R.mipmap.sx_d_register_sure);
        }else {
            childViewHolder.sx_id_choose_child.setImageResource(R.mipmap.sx_d_register_not_choose_v2);
        }
        childViewHolder.sx_id_addressee_name_child.setText(addresseeInfoBeanList.get(groupPosition).getPatientGroupBeen().get(childPosition).getGroupName());

        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    /**
     * 只展开一个分组
     * @param groupPosition 组id
     */
    @Override
    public void onGroupExpanded(int groupPosition) {
        for (int i = 0; i < getGroupCount(); i++) {
            // ensure only one expanded Group exists at every time
            if (groupPosition != i && re_fragment_search_slide_listview.isGroupExpanded(groupPosition)) {
                re_fragment_search_slide_listview.collapseGroup(i);
            }
        }
    }



    class GroupViewHolder{
        ImageView sx_id_choose;
        TextView sx_id_addressee_name;
        ImageView sx_id_arrow;
        LinearLayout sx_id_addressee_group_ll;
    }

    class ChildViewHolder{
        ImageView sx_id_choose_child;
        TextView sx_id_addressee_name_child;
        LinearLayout sx_id_addressee_child_ll;
    }

}
