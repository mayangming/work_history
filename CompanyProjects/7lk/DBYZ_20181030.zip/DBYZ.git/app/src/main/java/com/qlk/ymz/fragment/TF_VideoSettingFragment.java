package com.qlk.ymz.fragment;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.YY_PersonalDataActivityV2;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtiDoctorCheck;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.util.qlkserivce.QlkServiceHelper;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.PickerView;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilNet;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.android.fw.general.view.XCSwitchButton;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * TF_VideoSettingsActivity
 * 视频咨询开关页面
 *
 * @author 王腾飞 on 2016/07/21.
 * @version 1.0
 *
 * @author ShuYanYi on 2016/11/07
 * @version V2.6.5
 * @description 需求移到服务页tab内容区，原activity代码转到此fragment，原页面保留以防需求变更
 *
 * @author ShuYanYi on 2016/11/17
 * @description 个人中心ui改变了，不用tab选项卡，保留用回原来的activity，此页面不用了
 */
public class TF_VideoSettingFragment extends DBFragment {

    /** 提示设置视频通话时间的dialog
     * add by cyr on 2016/10/17 */
    private YR_CommonDialog mPromptDialog;
    /** 是否设置出诊时间 "0"否，"1"是 */
    private String visitTimeStatus = "1";
    /**
     * 视频咨询开关按钮
     */
    private XCSwitchButton xc_switchbutton_video;

    /**
     *设置价格layout
     */
    private RelativeLayout tf_video_settings_price_rl;
    /**
     * 服务时间layout
     */
    private RelativeLayout tf_id_video_setvice_time_rl;
    /**
     *  显示设置价格textview
     */
    private TextView tf_video_settings_price_tv;
    /**
     *  收费单位
     */
    private TextView tf_video_settings_default_tv;
    /**
     *  下方文字说明
     */
    private TextView tf_video_settings_readme_tv;
    /**
     * 设置价格dialog
     */
    private ConfirmDialog mPriceSettingsDialog;
    /**
     * 设置价格dialog 取消按钮
     */
    private TextView tf_settings_price_cancel_tv;
    /**
     * 设置价格dialog 确定按钮
     */
    private TextView tf_settings_price_confirm_tv;
    /**
     * 设置价格dialog 选择价格控件
     */
    private PickerView tf_settings_price_pv;
    /**
     * 当前选中的价格
     */
    private String mCurrentSelect;
    /**
     * 医生是否开启视频咨询   0 关 1 开
     */
    private int mIsOpen;
    /**
     * 弹出我知道了dialog
     */
    private YR_CommonDialog mKnowDialog;
    /**
     * 去认证对dialog
     */
    private YR_CommonDialog mToCheckDialog;
    /**
     * 最低价格
     */
    private int mMinCharge;
    /**
     * 最高价格
     */
    private int mMaxCharge;
    /**
     * 自定义价格dialog
     */
    private ConfirmDialog setPriceDialog;
    private EditText sx_id_department_other_edit;
    private TextView sx_id_confirm_text;
    /**
     * 记录上次列表的位置
     */
    private int mLastPriceSelect;
    /**
     * 由于在操作开关按钮时需要对开、关、开连续三下没有放手不触发监听，而且需要弹出关闭时的dialog需求添加count
     */
    private int count = 0;
    /**
     * 判断xc_switchbutton_video是否向下分发
     */
    private boolean checkDown;
    /** 是否正在打开视频开关状态*/
    public boolean isOpeningVideo = false;
    @Override
    public boolean isBodyFragment() {
        return true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return init(inflater, R.layout.tf_fragment_video_settings);
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public void onStart() {
        super.onStart();
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(TF_VideoSettingFragment.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }


    @Override
    public void initWidgets() {

        xc_switchbutton_video = getViewById(R.id.xc_switchbutton_video);
        xc_switchbutton_video.setOnCanListener(false);
        xc_switchbutton_video.setIsDelayed(true);
        tf_video_settings_price_rl = getViewById(R.id.tf_video_settings_price_rl);
        tf_video_settings_price_tv = getViewById(R.id.tf_video_settings_price_tv);
        tf_video_settings_default_tv = getViewById(R.id.tf_video_settings_default_tv);
        tf_id_video_setvice_time_rl = getViewById(R.id.tf_id_video_setvice_time_rl);
        tf_video_settings_readme_tv = getViewById(R.id.tf_video_settings_readme_tv);
        //获取目前视频服务设置状态
        getVideoStatus();
    }

    @Override
    public void listeners() {
        //    add by tengfei  修改jira3862问题   原因用户认为是右滑开启但实际手指是向左滑进行关闭    所以在此拦截
        xc_switchbutton_video.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(!UtilNet.isNetworkAvailable(getBaseActivity())){
                    return true;
                }
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    if (UtiDoctorCheck.isFailOrNoVerfy()) {
                        showNoCheckDialog(YR_CommonDialog.HINT_TRY_VIDEO_STR, YY_PersonalDataActivityV2.class);
                        checkDown = true;
                    } else if (UtiDoctorCheck.isCheckingOrAgain()) {
                        showCheckingDialog(YR_CommonDialog.HINT_CHECKING_VIDEO_STR);
                        checkDown = true;
                    }
                }
                return checkDown;
            }
        });
        //    add by tengfei  end
        //视频服务开关按钮
        xc_switchbutton_video.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            @Override
            public void open() {
//                如果状态没有改变不进行操作
                if(mIsOpen==1){
                    return;
                }
                switcButtonSettings(true);
            }

            @Override
            public void close() {
                if(mIsOpen==0){
                    return;
                }
                switcButtonSettings(false);
            }
        });
        tf_video_settings_price_rl.setOnClickListener(this);
        tf_id_video_setvice_time_rl.setOnClickListener(this);

    }




    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            //设置价格
            case R.id.tf_video_settings_price_rl:{
                createPriceSettingsDialog();
                break;
            }
            case R.id.tf_id_video_setvice_time_rl:{
                //h5页面服务时间设置
                UtilNativeHtml5.toJumpNativeH5(getBaseActivity(),UtilNativeHtml5.NATIVE_VIDEO_BESPEAK_TIME);
                break;
            }
            case R.id.tf_settings_price_cancel_tv:{
                mPriceSettingsDialog.dismiss();
                break;
            }
            //设置视频服务价格  选择价格dialog确定按钮
            case R.id.tf_settings_price_confirm_tv:{
                defaultSettingsPriceConfirm();
                break;
            }
            //自定义价格确定按钮
            case R.id.sx_id_confirm_text:{
                userSettingsPriceConfirm();
            }

        }
    }

    //设置价格dialog确定按钮
    private void defaultSettingsPriceConfirm() {
        if(!TextUtils.isEmpty(mCurrentSelect)){
            if (mCurrentSelect.equals("自定义")) {
                mPriceSettingsDialog.dismiss();
                //弹出自定义价格dialog
                showSetPriceDialog();
            } else {
                UtilSP.setVideoCurrentCharge(subPriceStr("元"));
                putVideoSetting();
                mPriceSettingsDialog.dismiss();
            }
        }else{
            UtilSP.setVideoCurrentCharge(50);
            putVideoSetting();
            mPriceSettingsDialog.dismiss();
        }
    }

    //自定义视频服务价格
    private void userSettingsPriceConfirm() {
        String tempInputPrice = sx_id_department_other_edit.getText().toString().trim();
        if(TextUtils.isEmpty(tempInputPrice)){
            shortToast("视频咨询金额设置不能为空");
            return;
        }
        int inputPrice = Integer.parseInt(tempInputPrice);
        if(inputPrice<mMinCharge){
            shortToast("视频咨询价格不能低于"+(mMinCharge)+"元");
            return;
        }
        if(inputPrice>mMaxCharge) {
            shortToast("视频咨询价格目前最高金额为"+mMaxCharge+"元");
            return;
        }
        UtilSP.setVideoCurrentCharge(inputPrice);
        tf_video_settings_price_tv.setText(inputPrice + "");
        putVideoSetting();
        setPriceDialog.dismiss();
    }

    /**
     * 获得视频设置的状态
     */
    public void getVideoStatus() {
        RequestParams params = new RequestParams();
        params.put("type", 4);// 收费类型1：图文，2：电话   4:视频咨询
        XCHttpAsyn.postAsyn(getBaseActivity(), AppConfig.getHostUrl(AppConfig.videoCharge_query),
                params, new XCHttpResponseHandler(getBaseActivity()) {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                //提示状态改变
                if (result_boolean) {
                    XCJsonBean bean = null;
                    List<XCJsonBean> jsonBean = result_bean.getList("data");
                    if (jsonBean.size() > 0) {
                        bean = jsonBean.get(0);
                        if (bean != null) {
                            mIsOpen = bean.getInt("open");
                            //收费开关
                            UtilSP.setVideoIsOpen(mIsOpen);
                            //当前收费价格，单位：分
                            if(bean.getInt("currentcharge")!=0){
                                UtilSP.setVideoCurrentCharge(bean.getInt("currentcharge") / 100);
                            }
                            if(bean.getInt("maxcharge")!=0){
                                // 最高价，单位：分
                                UtilSP.setVideoMaxCharge(bean.getInt("maxcharge") / 100);
                            }
                           if(bean.getInt("mincharge")!=0){
                               //最低价,单位：分
                               UtilSP.setVideoMinCharge(bean.getInt("mincharge") / 100);
                           }
                            //收费单位
                            String chargeUnit = bean.getString("chargeunit");
                            UtilSP.setVideoChargeUnit(chargeUnit);
                            //可设置 固定收费额，单位：分
                            List<Integer> list = bean.getIntegerList("charges");
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("自定义,");
                            for (Integer integer : list) {
                                stringBuilder.append(integer / 100 + chargeUnit + ",");
                            }
                            UtilSP.setVideoCharges(stringBuilder.toString());
                            UtilSP.setVideoChargeDesc(bean.getString("chargeDesc"));

                            visitTimeStatus = bean.getString("status");
                            refreshVideoSettingsUI();
                        }else {
                            shortToast(QlkServiceHelper.NETWOK_FAIL);
                        }
                    }else{
                        shortToast(QlkServiceHelper.NETWOK_FAIL);
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(getActivity(),
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }});
    }

    /**
     *  判断出诊时间状态
     * 暂时由前端判断，后期优化成H5
     * */
    /*public void getVisitStatus() {
        RequestParams params = new RequestParams();
        params.put("type", 4);// 收费类型1：图文，2：电话   4:视频咨询
        XCHttpAsyn.postAsyn(getBaseActivity(), AppConfig.getHostUrl(AppConfig.videoCharge_query), params, new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    XCJsonBean bean = result_bean.getList("data").get(0);
                    visitTimeStatus = bean.getString("status");
                    if ("0".equals(visitTimeStatus)) {
                        initPromptDialog();
                    } else {
                        myFinish();
                    }
                }
            }

        });
    }*/




    /**
     * 点击视频设置开关按钮设置
     * @param buttonStatus      改变后的状态
     */
    private void switcButtonSettings(boolean buttonStatus) {
        if(buttonStatus){
            mIsOpen = 1;
            //提交服务器
            putVideoSetting();
        }else{
            if(mKnowDialog==null){
                mKnowDialog = new YR_CommonDialog(getBaseActivity(),"关闭视频预约，之前预约的视频仍会生效","","我知道了") {
                    @Override
                    public void confirmBtn() {
                        mKnowDialog.dismiss();
                    }
                };
            }
            mKnowDialog.show();
            mIsOpen = 0;
            //提交服务器
            putVideoSetting();
        }
    }

    /**
     * 提交视频收费设置
     * update by cyr on 2016/10/18  添加isFinish参数
     */
    private void putVideoSetting(){
        isOpeningVideo = true;
        RequestParams requestParams = new RequestParams();
        //设置价格不更改收费开关状态
        requestParams.put("open", mIsOpen);
        requestParams.put("charge", UtilSP.getVideoCurrentCharge()*100);
        requestParams.put("type", 4);
        XCHttpAsyn.postAsyn(getBaseActivity(), AppConfig.getHostUrl(AppConfig.videoCharge_setting), requestParams, new XCHttpResponseHandler() {
            @Override
            public void onFinish() {
                super.onFinish();
                isOpeningVideo = false;
            }

            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    //保存状态
                    UtilSP.setVideoIsOpen(mIsOpen);
                    //设置视频价格
                    tf_video_settings_price_tv.setText(String.valueOf(UtilSP.getVideoCurrentCharge()));
                    videoServiceIsOpen();
                    if(onVideoSettingDoneListener != null){
                        if(mPromptDialog != null){
                            mPromptDialog.dismiss();
                        }
                        onVideoSettingDoneListener.onFinish();
                        //必须清掉这次动作，以防再一次普通设置时再跑回上次不需要的操作
                        onVideoSettingDoneListener = null;
                    }
                }

            }
        });
    }

    /**
     *  状态改变时更新页面
     */
    private void videoServiceIsOpen(){
        if(mIsOpen==1){
            xc_switchbutton_video.setState(true);
            tf_video_settings_price_rl.setVisibility(View.VISIBLE);
            tf_id_video_setvice_time_rl.setVisibility(View.VISIBLE);
            tf_video_settings_readme_tv.setVisibility(View.VISIBLE);

        }else{
            xc_switchbutton_video.setState(false);
            tf_video_settings_price_rl.setVisibility(View.GONE);
            tf_id_video_setvice_time_rl.setVisibility(View.GONE);
            tf_video_settings_readme_tv.setVisibility(View.GONE);

        }
    }

    private void refreshVideoSettingsUI() {
        //设置视频开关
        videoServiceIsOpen();
        //设置当前价格
        tf_video_settings_price_tv.setText(UtilSP.getVideoCurrentCharge() + "");
        //设置收费单位
        tf_video_settings_default_tv.setText(UtilSP.getVideoChargeUnit());
        //设置收费描述
        String videoChargeDesc = UtilSP.getVideoChargeDesc();
        //最高最低价格
        mMinCharge = UtilSP.getVideoMinCharge();
        mMaxCharge = UtilSP.getVideoMaxCharge();
        //设置下方提示文本
        StringBuilder stringBuilder1 = new StringBuilder();
        String chargeDesc1;
        boolean flag = true;
        //返回的字符串不能够换行  进行换行
        while (flag) {
            int index = videoChargeDesc.indexOf("\\n");
            if (index != -1) {
                chargeDesc1 = videoChargeDesc.substring(0, index);
                videoChargeDesc = videoChargeDesc.substring(index + 2, videoChargeDesc.length());
                stringBuilder1.append(chargeDesc1 + " \n");
                XCApplication.base_log.i("videosettings", "videoChargeDesc" + videoChargeDesc);
            } else {
                stringBuilder1.append(videoChargeDesc);
                flag = false;
                tf_video_settings_readme_tv.setText(stringBuilder1.toString());
            }
        }

    }

    /**
     * 显示认证中对话框
     * @param hint   message中显示文字
     */
    private void showCheckingDialog(String hint) {
        mToCheckDialog = new YR_CommonDialog(getBaseActivity(),hint,"","我知道了") {
            @Override
            public void confirmBtn() {
                mToCheckDialog.dismiss();
            }
        };
        mToCheckDialog.show();
//        mCheckDialog = new XCIMCheckDialog(getBaseActivity(), XCIMCheckDialog.TRAN_STYLE);
//        mCheckDialog.getTextview().setText(hint);
//        mCheckDialog.setCancleVisible(false);
//        mCheckDialog.setConfirmText("我知道了");
//        mCheckDialog.setSelectedListener(new XCIMCheckDialog.SelectedListener() {
//            public void confirm(View view) {
//                mCheckDialog.dismiss();
//            }
//
//            public void cancle(View view) {
//                mCheckDialog.dismiss();
//            }
//        });
//        mCheckDialog.show();
    }

    /**
     * 去认证对话框
     * @param hint    提示文字
     * @param cls     点击去认证
     */
    private void showNoCheckDialog(String hint, final Class<? extends XCBaseActivity> cls) {
        mToCheckDialog = new YR_CommonDialog(getBaseActivity(),hint,"暂不认证","去认证") {
            @Override
            public void confirmBtn() {
                mToCheckDialog.dismiss();
                myStartActivity(cls);
            }
        };
        mToCheckDialog.show();
    }

    /**
     * 创建选择价格对话框
     */
    private void createPriceSettingsDialog() {
        if(mPriceSettingsDialog==null){
            //初始化选择价格dialog
            int srceenW = getBaseActivity().getWindowManager().getDefaultDisplay().getWidth();
            mPriceSettingsDialog = new ConfirmDialog(getBaseActivity(),srceenW,260,R.layout.tf_dialog_video_settings_price,R.style.xc_s_dialog);
            tf_settings_price_cancel_tv =(TextView) mPriceSettingsDialog.findViewById(R.id.tf_settings_price_cancel_tv);
            tf_settings_price_confirm_tv = (TextView)mPriceSettingsDialog.findViewById(R.id.tf_settings_price_confirm_tv);
            tf_settings_price_pv = (PickerView)mPriceSettingsDialog.findViewById(R.id.tf_settings_price_pv);
            mPriceSettingsDialog.setCanceledOnTouchOutside(false);
            Window window = mPriceSettingsDialog.getWindow();
            window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
            List<String> mPrices = new ArrayList<>();
            String charge = UtilSP.getVideoCharges();
            String[] charges = charge.split(",");
            int count = charges.length;
            for (int i = 0;i<count;i++){
                mPrices.add(charges[i]);
            }
            tf_settings_price_pv.setData(mPrices);
            /** dialog取消*/
            tf_settings_price_cancel_tv.setOnClickListener(this);
            /** dialog确定*/
            tf_settings_price_confirm_tv.setOnClickListener(this);
            /** 选择价格选择 */
            tf_settings_price_pv.setOnSelectListener(new PickerView.onSelectListener() {
                @Override
                public void onSelect(String text) {
                    mCurrentSelect = text;
                }
            });
            mPriceSettingsDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialog) {
                    if(!TextUtils.isEmpty(mCurrentSelect)){
                        tf_settings_price_pv.setSelected(mCurrentSelect);
                    }
                }
            });
        }
        tf_settings_price_pv.setSelected(UtilSP.getVideoCurrentCharge() + UtilSP.getVideoChargeUnit());
        mPriceSettingsDialog.show();
    }

    /**
     * 自定义价格dialog
     */
    private void showSetPriceDialog() {
        if(setPriceDialog==null){
            int srceenW =  getBaseActivity().getWindowManager().getDefaultDisplay().getWidth();
            setPriceDialog = new ConfirmDialog(getBaseActivity(), srceenW,55
                    ,R.layout.sx_l_dialog_department_item_other,R.style.xc_s_dialog);
            setPriceDialog.setCanceledOnTouchOutside(true);
            Window window = setPriceDialog.getWindow();
            window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
            sx_id_department_other_edit = (EditText)setPriceDialog.findViewById(R.id.sx_id_department_other_edit);
            //设置edittext输入类型
            sx_id_department_other_edit.setInputType(EditorInfo.TYPE_CLASS_NUMBER);
            //控制输入长度
            sx_id_department_other_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter((mMaxCharge+"").length())});
            sx_id_department_other_edit.setHint("自定义价格为" + mMinCharge + "—" + mMaxCharge + "元");
            sx_id_confirm_text =(TextView)setPriceDialog.findViewById(R.id.sx_id_confirm_text);
            //确定按钮监听
            sx_id_confirm_text.setOnClickListener(this);
        }
        setPriceDialog.show();
        //获取焦点
        sx_id_department_other_edit.setFocusableInTouchMode(true);
        sx_id_department_other_edit.requestFocus();
        //弹出软键盘
        UtilInputMethod.openInputMethod(sx_id_department_other_edit, getBaseActivity());

    }

    //add  by cyr on 2016/10/17  如果预约视频没有设置时间，则弹出dialog提示去设置
    public void initPromptDialog(){
        if (mPromptDialog == null) {
            mPromptDialog = new YR_CommonDialog(getBaseActivity(), "没有设置预约时间，现在退出将无法开通服务!", "仍然退出", "去设置") {
                @Override
                public void confirmBtn() {
                    UtilNativeHtml5.toJumpNativeH5(getBaseActivity(), UtilNativeHtml5.NATIVE_VIDEO_BESPEAK_TIME);
                    mPromptDialog.dismiss();
                }

                @Override
                public void cancelBtn() {
                    mIsOpen = 0;
                    putVideoSetting();
                }
            };
            mPromptDialog.setCanceledOnTouchOutside(false);
        }
        mPromptDialog.show();
    }

    //剪切字符串
    private int subPriceStr(String subString) {
        String price =  mCurrentSelect.substring(0,mCurrentSelect.indexOf(subString));
        return Integer.parseInt(price);
    }

    @Override
    public void onStop() {
        super.onStop();
        if(mToCheckDialog!=null&&mToCheckDialog.isShowing()){
            mToCheckDialog.dismiss();
        }
    }



    @Override
    public void onDestroyView() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mKnowDialog,mToCheckDialog,mPriceSettingsDialog,setPriceDialog,mPromptDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }

    @Override
    public void onResume() {
        super.onResume();
        //start add by syy 2016/11/10 //改为 点进去设置时间页面，然后返回时，刷新最新的预约时间设置状态值；
        // 每次切换fragment或退出主activity时不再发请求，避免卡屏
        if (!this.isHidden()) {
            changeHadSetTimeStatus();
        }
        //end add by syy 2016/11/10
    }

    //start add by syy 2016/11/10 //为了每次切换fragment或退出activity时不发送请求检查预约时间设置导致卡屏，加入以下代码
    /**
     * 刷新是否已经设置了预约时间的判断值
     */
    public void changeHadSetTimeStatus() {
        RequestParams params = new RequestParams();
        params.put("type", 4);// 收费类型1：图文，2：电话   4:视频咨询
        XCHttpAsyn.postAsyn(getBaseActivity(), AppConfig.getHostUrl(AppConfig.videoCharge_query), params, new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    XCJsonBean bean = result_bean.getList("data").get(0);
                    visitTimeStatus = bean.getString("status");
                }
            }

        });
    }
    /**
     * 切换fragment或关闭整个主框架activity前，检查预约时间的设置
     * @return true： 可正常退出或切换fragment，false：弹出提醒设置对话框
     */
    public boolean canQuit(){
        if (mIsOpen == 1 && "0".equals(visitTimeStatus)) {
            return false;
        }
        return true;
    }
    /**
     * 视频设置完成的监听
     */
    public interface OnVideoSettingDoneListener{
        /** 设置的请求处理完成后的动作*/
        void onFinish();
    }
    OnVideoSettingDoneListener onVideoSettingDoneListener;
    public void setOnVideoSettingDoneListener(OnVideoSettingDoneListener onVideoSettingDoneListener) {
        this.onVideoSettingDoneListener = onVideoSettingDoneListener;
    }
    //end add by syy 2016/11/10
}
