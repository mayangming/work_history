package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.BuildConfig;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.service.XC_MqttService;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilAppToSystemApp;
import com.qlk.ymz.util.UtilLoginOut;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.qlk.ymz.view.upgrade.YR_UpgradeDialogActivity_v2;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilSystem;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.android.fw.general.view.XCSwitchButton;

import org.apache.http.Header;


/**
 * Created by sinki on 2015/6/17.
 *
 * update by cyr on 2016-3-30
 * 修改版本升级代码
 */
public class SK_SettingActivityV2 extends DBActivity {
    /** 修改密码布局 */
    LinearLayout sk_id_setting_changepw_ll;
    /** 检测新版本布局 */
    LinearLayout sk_id_my_setting_version_ll;
    /** 服务协议布局 */
    LinearLayout sk_id_setting_agreement_ll;
    /** 关于的布局 */
    LinearLayout sk_id_setting_about_ll;
    /** 版本号 */
    TextView sk_id_setting_version;
    /** 注销按钮 */
    Button sk_id_setting_logout_btn;
    /** 确认退出dialog */
    YR_CommonDialog mExitDialog;
    /** 手机号 */
    TextView id_tv_phone;
    /** 关于 右边的版本号tv */
    TextView id_tv_about_version;
    /**联系客服电话 */
    private TextView pf_id_setting_call_service;
    /**工作时间*/
    private TextView pf_id_setting_work_time;
    /** 联系客服按钮 */
    private LinearLayout ll_call_service_btn;

    //---关闭新的需求----
    LinearLayout xc_id_setting_message;
    //---关闭新的需求----

    XCTitleCommonLayout titlebar;
    XCSwitchButton yy_id_switch_button_headphone;
    LinearLayout id_phone_line;//手机号
    /**开启log点击数量*/
    private int clickCount = 0;
    /** 按下时间 */
    private long downTime = 0l;
    /**按下时长(毫秒)*/
    public static final long TOTAL_TIME = 10 * 1000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sk_l_activity_setting_v2);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(SK_SettingActivityV2.class,"1","","","",false);
//        // created by songxin,date：2016-4-25,about：saveInfo,end
    }

    public void showDialog() {
        if (mExitDialog == null) {
            mExitDialog = new YR_CommonDialog(this, "您确定要退出当前账号吗？", "取消", "确定") {

                @Override
                public void confirmBtn() {
                    // created by songxin,date：2016-4-25,about：saveInfo,begin
                    BiUtil.saveBiInfo(SK_SettingActivityV2.class, "2", "128", "sk_id_setting_logout_btn","", true);
                    // created by songxin,date：2016-4-25,about：saveInfo,end
                    logout();
                }
            };
        }
        mExitDialog.show();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SK_SettingActivityV2.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {

        sk_id_setting_changepw_ll = getViewById(R.id.sk_id_setting_changepw_ll);
        sk_id_my_setting_version_ll = getViewById(R.id.sk_id_my_setting_version_ll);
        sk_id_setting_agreement_ll = getViewById(R.id.sk_id_setting_agreement_ll);
        id_phone_line = getViewById(R.id.id_phone_line);
        sk_id_setting_about_ll = getViewById(R.id.sk_id_setting_about_ll);
        sk_id_setting_version = getViewById(R.id.sk_id_setting_version);
        id_tv_about_version = getViewById(R.id.id_tv_about_version);
        sk_id_setting_logout_btn = getViewById(R.id.sk_id_setting_logout_btn);
        id_tv_phone = getViewById(R.id.id_tv_phone);
        //-------------------zhangpengfei 2016-04-25 add--------------------------
        pf_id_setting_call_service = getViewById(R.id.pf_id_setting_call_service);
        ll_call_service_btn = getViewById(R.id.ll_call_service_btn);
        pf_id_setting_work_time = getViewById(R.id.pf_id_setting_work_time);
        if (!UtilString.isBlank(GlobalConfigSP.getCustomerServPhone())){
            pf_id_setting_call_service.setText("联系我们：" + GlobalConfigSP.getCustomerServPhone());
            ll_call_service_btn.setVisibility(View.VISIBLE);
        }else{
            ll_call_service_btn.setVisibility(View.GONE);
        }
        if (!UtilString.isBlank(GlobalConfigSP.getServerTime())){
            pf_id_setting_work_time.setText("服务时间：" + GlobalConfigSP.getServerTime());
            pf_id_setting_work_time.setVisibility(View.VISIBLE);
        }else{
            pf_id_setting_work_time.setVisibility(View.INVISIBLE);
        }

        //-----------------------------------------end--------------------------
        //----关闭新的需求----
        xc_id_setting_message = getViewById(R.id.xc_id_setting_message);
        //----关闭新的需求----

        //-----------zhangpengfei 2016-07-05 add 用来区分包的环境---------------------
        if (AppConfig.S_TYPE_URL.equals(AppConfig.S_TYPE_URL_ONLINE)){
            sk_id_setting_version.setText("当前版本" + UtilSystem.getVersionName(this));
        }else if (AppConfig.S_TYPE_URL.equals(AppConfig.S_TYPE_URL_DEV)){
            sk_id_setting_version.setText(BuildConfig.RELEASE_TIME + "_" + UtilSystem.getVersionName(this) + "开发环境");
        }else if (AppConfig.S_TYPE_URL.equals(AppConfig.S_TYPE_URL_PRE_ONLINE)){
            sk_id_setting_version.setText(BuildConfig.RELEASE_TIME + "_" + UtilSystem.getVersionName(this) + "预发布环境");
        }else if (AppConfig.S_TYPE_URL.equals(AppConfig.S_TYPE_URL_TEXT)){
            sk_id_setting_version.setText(BuildConfig.RELEASE_TIME + "_" + UtilSystem.getVersionName(this) + "测试环境");
        }
        //-----------zhangpengfei 2016-07-05 end---------------------
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "设置");
        titlebar.setTitleLeft(true, "");
        titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });

        //--v2.0听筒设置移到这页面
        yy_id_switch_button_headphone = getViewById(R.id.yy_id_switch_button_headphone);
        if (UtilSP.getIsSpeakLoud()) {
            yy_id_switch_button_headphone.setState(false);
        } else {
            yy_id_switch_button_headphone.setState(true);
        }
        yy_id_switch_button_headphone.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            public void open() {
                dShortToast("open");
                UtilSP.setIsSpeakLoud(false);
            }

            public void close() {
                dShortToast("close");
                UtilSP.setIsSpeakLoud(true);
            }
        });

        id_tv_phone.setText(UtilSP.getUserPhone());
    }

    @Override
    public void listeners() {
        sk_id_setting_changepw_ll.setOnClickListener(this);
        sk_id_my_setting_version_ll.setOnClickListener(this);
        sk_id_setting_agreement_ll.setOnClickListener(this);
        sk_id_setting_about_ll.setOnClickListener(this);
        sk_id_setting_logout_btn.setOnClickListener(this);
        sk_id_setting_version.setOnClickListener(this);
        id_phone_line.setOnClickListener(this);
        ll_call_service_btn.setOnClickListener(this);
        //----关闭新的需求----
        xc_id_setting_message.setOnClickListener(this);
        //----关闭新的需求----

        titlebar.getXc_id_titlebar_center_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount ++;
                if (clickCount == 5) {
                    myStartActivity(SystemSettingActivity.class);
                }else if (clickCount == 1) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            clickCount = 0;
                        }
                    },3000);
                }
            }
        });
    }


    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            //修改密码
            case R.id.sk_id_setting_changepw_ll:
                myStartActivity(SK_ChangePassWdActivity.class);
                break;

            case R.id.sk_id_my_setting_version_ll:
                break;
            //服务协议
            case R.id.sk_id_setting_agreement_ll:
                WebviewBean bean = new WebviewBean(AppConfig.getH5Url(AppConfig.doctor_service_contract));
                bean.title = "服务协议";
                myStartActivity(JS_WebViewActivity.newIntent(this, bean));
                break;
            //关于
            case R.id.sk_id_setting_about_ll://update by cyr on 2016-9-29  修改静态地址\
                WebviewBean aboutBean = new WebviewBean(AppConfig.getH5Url(AppConfig.doctor_about_us));
                aboutBean.title = "关于";
                myStartActivity(JS_WebViewActivity.newIntent(this, aboutBean));
                break;
            //退出登录
            case R.id.sk_id_setting_logout_btn:
                showDialog();
                break;
            //检测版本
            case R.id.sk_id_setting_version://检查版本，如果正在下载新版本，点击只提示信息
                if(YR_UpgradeDialogActivity_v2.isUpgrading) {
                    shortToast("您当前正在下载!");
                } else {
                    YR_UpgradeDialogActivity_v2.launch(SK_SettingActivityV2.this,YR_UpgradeDialogActivity_v2.UpgradeFrom.SET);
               }
                break;
            //----关闭新的需求-----新消息通知
            case R.id.xc_id_setting_message:
                myStartActivity(XC_MessageSettingActivity.class);
                break;
            //手机号
            case R.id.id_phone_line:
                Intent intent = new Intent();
                intent.putExtra("PHONE_NUMBER", id_tv_phone.getText().toString().trim());
                myStartActivityForResult(intent, SX_ChangePersonalDataActivity.class, 2, 2);
                break;
            //联系客服 zhangpengfei 2016-04-25 add
            case R.id.ll_call_service_btn:
                UtilAppToSystemApp.toPhone(this, GlobalConfigSP.getCustomerServPhone());
                break;

        }
    }

    private void logout() {
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.login_logout), new RequestParams(), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
            }
        });
        if(mExitDialog!=null){
            mExitDialog.dismiss();
        }

        UtilLoginOut.loginOut(this);
        XCApplication.finishAllActivity();
        myStartActivity(LoginAndRegisterActivity.class);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 2:
                if (null != data) {
                    String resultDate = data.getStringExtra("PHONE_NUMBER");
                    id_tv_phone.setText(resultDate);
                }
                break;
        }
    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mExitDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }
}
