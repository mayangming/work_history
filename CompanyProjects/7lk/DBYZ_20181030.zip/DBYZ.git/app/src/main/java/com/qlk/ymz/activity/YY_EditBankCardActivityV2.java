package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.model.UserBankBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 银行选择和编辑
 * @author sinki on 2015/6/17.
 * @version 1.2.0
 *
 * 增加新版区分不同银行不同展现颜色；增加设置默认银行卡功能
 * @modifier syy on 2015/03/03
 * @version v2.0
 * @description
 */
public class YY_EditBankCardActivityV2 extends SK_BaseChoiceAllActivityV2 {
    /** 标识是否从其他页面进入，如提现时用于选择银行卡 */
    String flag = "0";
    /** 无数据显示的文字，提现页面跳转到选择银行卡也会改变此文字 */
    String zeroTextHint = "未添加银行卡";
    /** 标识是否有有删除操作 */
    boolean isDeleted = false;

    Map<String,String> bankIconMap;//银行图标
    Map<String,String> bankColorMap;//银行颜色

    private YR_CommonDialog mYR_commonDialog;
    private String setDefaultBankContent;//确认设置默认银行卡dialog的提示语
    private int setDefaultBankId;//要设置默认卡的卡id

    private int topBankId;//最顶上的银行卡id
    private boolean hasDefaultBank;//是否已有一个默认银行卡
    // (因各种特殊情况:用户删除默认卡，或从来没有手动设置过默认，而且后端也没返回一个默认卡时，我们自己请求一下接口更新设置第一张卡为默认)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initBankMap();
        initSetDefaultBankDialog();
    }

    @Override
    public void initData() {
        super.initData();

        setBeanId("userBankId");
        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            flag = bundle.getString("flag");
            String intentZeroTextHint = bundle.getString("zeroTextHint");
            if(!TextUtils.isEmpty(intentZeroTextHint)){
                zeroTextHint = intentZeroTextHint;
            }
        }
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YY_EditBankCardActivityV2.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    protected void onResume() {
        super.onResume();
        requestBankList( "1");
    }
    @Override
    /**
     * 设置数据适配器
     */
    public void initAdapter() {
        adapter = new SK_BankCardAdapter(this,dataList);
    }

    /**
     * 数据点击事件
     */
    @Override
    public void initChioseItemListenr(){
        listViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                if ("1".equals(flag)) {
                    XCJsonBean bean = (XCJsonBean) arg0.getItemAtPosition(arg2);
                    if(bean == null){
                        return;
                    }
                    //对对象重新赋值，避免null出现。
                    String userBankId = bean.getString("userBankId");
                    String name = bean.getString("name");
                    String bankName = bean.getString("bankName");
                    String shortNum = bean.getString("shortNum");
                    String longNum = bean.getString("longNum");
                    String branch = bean.getString("branch");

                    UserBankBean bankCardEntity = new UserBankBean();
                    bankCardEntity.branch = branch;
                    bankCardEntity.bankName = bankName;
                    bankCardEntity.shortNum = shortNum;
                    bankCardEntity.name = name;
                    bankCardEntity.userBankId = userBankId;
                    bankCardEntity.longNum = longNum;

                    Intent intent = new Intent();
                    intent.putExtra(XL_ApplyCashBackActivityV2.BANK, bankCardEntity);
                    setResult(RESULT_OK, intent);
                    YY_EditBankCardActivityV2.this.finish();
                }

            }
        });
    }

    /**
     * 初始化标题栏
     */
    public void initChioseTitle(){

        titleCommonFragment.setTitleCenter(true, "银行卡");
        titleCommonFragment.setTitleLeft(true, "");
        if(dataList == null || dataList.size() < 1){
            titleCommonFragment.setTitleRight2(false, 0, "编辑");
        }else{
            titleCommonFragment.setTitleRight2(true, 0, "编辑");
        }


        //---返回按钮
        titleCommonFragment.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEdit) {
                    //点击左边返回按钮,父类需要做的事情
                    removeBack();

                } else {
                    //刷新
                    if ("1".equals(flag) && isDeleted) {
                        Intent intent = new Intent();

                        intent.putExtra("isDeleted", "1");
                        setResult(RESULT_OK, intent);

                    }
                    myFinish();
                }
            }
        });
    }



    /**
     * 编辑界面的title
     */
    @Override
    public void initEditTitle(){
        titleCommonFragment.setTitleCenter(true,"编辑");
        titleCommonFragment.setTitleRight2(true,0,"保存");
    }

    /**
     * 删除银行卡 提交数据
     */
    @Override
    public void requestCommit() {
        if("".equals(ids) || ids == null) {
            shortToast("请选择删除最少一个分组");
            return;
        }
        //拼接要删除的ID,去掉最后一个逗号
        ids = ids.substring(0,ids.length()-1) + "";
        requestBankCardRemove(ids + "");
    }

    @Override
    public void listeners() {

    }

    /**
     * 无网到有网络的刷新
     */
    @Override
    public void onNetRefresh() {
        requestBankList("1");
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.sk_id_add_rl:
                myStartActivity(SK_AddBankCardActivityV2.class);

                break;
        }
    }



    class SK_BankCardAdapter extends SK_BaseChoiseAdapter{
        public SK_BankCardAdapter(Context context,List<XCJsonBean> list){
            super(context,list);
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            XCJsonBean bean = dataList.get(i);
            ViewHolder holder = null;

            if(view == null){
                view = LayoutInflater.from(context).inflate(R.layout.yy_l_adapter_bank_card_item_v2,null);
                holder = new ViewHolder();
                holder.id_bank_bg = (LinearLayout)view.findViewById(R.id.id_bank_bg);
                holder.contentTv = (TextView)view.findViewById(R.id.sk_id_bank_card_content_tv);
                holder.checkBox = (CheckBox)view.findViewById(R.id.sk_id_bank_card_cb);
                holder.sk_id_bank_card_num = (TextView)view.findViewById(R.id.sk_id_bank_card_num);
                holder.sk_id_bank_card_iv = (ImageView)view.findViewById(R.id.sk_id_bank_card_iv);
                holder.sk_id_bank_card_iv_intodetail = (ImageView)view.findViewById(R.id.sk_id_bank_card_iv_intodetail);
                holder.id_btn_is_default = (LinearLayout)view.findViewById(R.id.id_btn_is_default);
                holder.id_btn_set_default = (LinearLayout)view.findViewById(R.id.id_btn_set_default);
                holder.id_btn_set_default_ctrl = (LinearLayout)view.findViewById(R.id.id_btn_set_default_ctrl);
                holder.v_bottom = view.findViewById(R.id.v_bottom);
                view.setTag(holder);
            }else{
                holder = (ViewHolder) view.getTag();
            }
            if (dataList.size() -1 == i) {//add by cyr on 2016-11-11 最后一个底部加上一块，防止被底部按钮挡住
                holder.v_bottom.setVisibility(View.VISIBLE);
            } else {
                holder.v_bottom.setVisibility(View.GONE);
            }

            holder.checkBox.setVisibility(View.VISIBLE);
            holder.sk_id_bank_card_iv_intodetail.setVisibility(View.GONE);

            String bankName = bean.getString("bankName");
            if (!TextUtils.isEmpty(bankName)) {//解决有空格导致无法匹配图标的问题
                bankName.trim();
            }
            holder.contentTv.setText(bankName);
            //---------------start 颜色和背景设置
            String icon_api = bean.getString("icon");
            String color_api = bean.getString("color");

            //-----图标
            String bankIconUrl = "";
            if(!TextUtils.isEmpty(icon_api)){
                bankIconUrl = icon_api;
            }else if(bankIconMap.containsKey(bankName)){//对于该银行，接口没提供图标的时候
                bankIconUrl = bankIconMap.get(bankName);
            }else{
                holder.sk_id_bank_card_iv.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(bankIconUrl)){
                XCApplication.displayImage(bankIconUrl,holder.sk_id_bank_card_iv);
            }

            //-----银行背景
            String bgColorStr = "#DC3522";//默认
            if(!TextUtils.isEmpty(color_api)){
                bgColorStr = color_api;
            }else if(bankColorMap.containsKey(bankName)){//对于该银行，接口没背景色的时候
                bgColorStr = bankColorMap.get(bankName);
            }

            GradientDrawable drawable =(GradientDrawable)holder.id_bank_bg.getBackground();
            drawable.setColor(Color.parseColor(bgColorStr));//半圆角背景的动态变色，不能直接setbackground
            //---------------end 颜色和背景设置

            holder.sk_id_bank_card_num.setText(bean.getString("shortNum"));

            initCheckBox(bean,holder.checkBox,holder.id_btn_set_default_ctrl);


            //-----设置默认银行卡
            //初始化重置状态
            holder.id_btn_is_default.setVisibility(View.GONE);
            holder.id_btn_set_default.setVisibility(View.VISIBLE);

            final int userBankId = bean.getInt("userBankId");
            final String bankLastNum = bean.getString("shortNum");
            int isDefault = bean.getInt("isDefault");
            if(isDefault == 1){
                holder.id_btn_is_default.setVisibility(View.VISIBLE);
                holder.id_btn_set_default.setVisibility(View.GONE);

            }
            //设置默认卡按钮
            holder.id_btn_set_default.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    setDefaultBankId = userBankId;
                    setDefaultBankContent = "确认要将此卡片(" + bankLastNum + ")，设为默认卡片吗？";
                    mYR_commonDialog.getContentTV().setText(setDefaultBankContent);
                    mYR_commonDialog.show();
                }
            });


            //-----end 设置默认银行卡

            return view;
        }

        /**
         * 初始化多选框
         * @param checkBox 多选框
         * @param defaultBankIcon 设置默认卡的根部布局
         */
        public void initCheckBox(XCJsonBean bean,CheckBox checkBox,LinearLayout defaultBankIcon){
            if(isEdit){ //如果是编辑页面
                checkBox.setVisibility(View.VISIBLE);
                defaultBankIcon.setVisibility(View.GONE);
            }else{
                checkBox.setVisibility(View.GONE);
                defaultBankIcon.setVisibility(View.VISIBLE);
            }

            checkBox.setFocusable(false);
            checkBox.setClickable(false);

            if(bean.getBoolean("isCheck")){ //如果被选中
                checkBox.setChecked(true);
            }else{
                checkBox.setChecked(false);
            }
        }
    }

    class ViewHolder{
        TextView contentTv;
        LinearLayout id_bank_bg;
        TextView sk_id_bank_card_num;
        CheckBox checkBox;
        ImageView sk_id_bank_card_iv,sk_id_bank_card_iv_intodetail;
        LinearLayout id_btn_set_default;//设为默认卡的按钮
        LinearLayout id_btn_is_default;//已经为默认卡的表示图标
        LinearLayout id_btn_set_default_ctrl;
        View v_bottom;
    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mYR_commonDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }

    /**
     * 获取银行卡列表
     * @param userType：用户类型(0,商务代表；1,医生......)
     */
    private void  requestBankList(String userType){
        RequestParams params = new RequestParams();
        params.put("userType", userType);
        topBankId = 0;
        hasDefaultBank = false;
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.bank_userBanks), params, new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    listViewFragment.setBgZeroHintInfo(zeroTextHint, "", R.mipmap.js_d_icon_no_data);
                    initData(result_bean.getList("data"));
                    YY_EditBankCardActivityV2.super.requestCommit();
                    if(dataList == null || dataList.size() < 1){
                        titleCommonFragment.setTitleRight2(false,0,"编辑");
                    }else{

                        //------begin 后端没有指定默认银行卡时客户端设置第一张为默认银行卡，并请求一次给后端
                        for(XCJsonBean bean : dataList){
                            int userBankId = bean.getInt("userBankId");
                            int isDefault = bean.getInt("isDefault");
                            if(topBankId == 0){//记录第一张银行卡id
                                topBankId = userBankId;
                            }
                            if(isDefault == 1){
                                hasDefaultBank = true;
                                break;
                            }
                        }
                        if(!hasDefaultBank){
                            requestSetDefaultBank(topBankId);
                        }
                        //-------end 后端没有指定默认银行卡时客户端设置第一张为默认银行卡，并请求一次给后端

                        titleCommonFragment.setTitleRight2(true,0,"编辑");
                    }
                }
            }
            @Override
            public void onFinish() {
                super.onFinish();
                if(listViewFragment != null){
                    listViewFragment.doRefreshComplete();
                }
                // 处理code操作
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YY_EditBankCardActivityV2.this,
                        getCode(),
                        getMsg())) {
                }
            }

        });
    }


    /**
     * 删除银行卡
     * @param ids 要删除的卡id
     */
    public void requestBankCardRemove(String ids){
        RequestParams params = new RequestParams();
        params.put("userBankIds", ids);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.bank_delBankCards), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    dShortToast("删除成功");
                    requestBankList("1");

                    // 需要对删除银行卡进行判断，是否删除了银行卡，如果是返回积分提现界面要刷新接口，否则不用
                    isDeleted = true;
                    if(dataList == null || dataList.size() == 0){
                        titleCommonFragment.setTitleRight2(false,0,"编辑");
                    }else{
                        titleCommonFragment.setTitleRight2(true,0,"编辑");
                    }
                }
            }

            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                shortToast("抱歉，请求失败，请稍后再试；code:" + code);
            }
            @Override
            public void onFinish() {
                super.onFinish();
                // 处理code操作
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YY_EditBankCardActivityV2.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });

    }

    /**
     * 初始化银行图标、名字、颜色的对应关系，当后台没配置时显示的默认值
     */
    private void initBankMap(){
        String hostName = AppConfig.address + "/assets/bank/";
        bankIconMap = new HashMap();
        bankIconMap.put("中国招商银行", hostName + "cmb.png");
        bankIconMap.put("中国银行", hostName + "boc.png");
        bankIconMap.put("中国工商银行", hostName + "icbc.png");
        bankIconMap.put("中国民生银行", hostName + "cmbc.png");
        bankIconMap.put("中国农业银行", hostName + "abc.png");
        bankIconMap.put("中国兴业银行", hostName + "cib.png");
        bankIconMap.put("中国邮政银行", hostName + "psbc.png");
        bankIconMap.put("中国光大银行", hostName + "ceb.png");
        bankIconMap.put("中国建设银行", hostName + "ccb.png");
        bankIconMap.put("中国交通银行", hostName + "bocom.png");
        bankIconMap.put("中国中信银行", hostName + "ecitic.png");

        bankColorMap = new HashMap();
        bankColorMap.put("中国招商银行", "#CE0100");
        bankColorMap.put("中国银行", "#BB0403");
        bankColorMap.put("中国工商银行", "#CD0001");
        bankColorMap.put("中国民生银行", "#069984");
        bankColorMap.put("中国农业银行", "#019888");
        bankColorMap.put("中国兴业银行", "#224589");
        bankColorMap.put("中国邮政银行", "#016744");
        bankColorMap.put("中国光大银行", "#611272");
        bankColorMap.put("中国建设银行", "#0D409B");
        bankColorMap.put("中国交通银行", "#013378");
        bankColorMap.put("中国中信银行", "#DC3522");
    }

    /**
     * 初始化设置默认银行卡对话框
     */
    private void initSetDefaultBankDialog() {
        mYR_commonDialog = new YR_CommonDialog(YY_EditBankCardActivityV2.this,setDefaultBankContent,"取消","确定") {
            @Override
            public void confirmBtn() {
                requestSetDefaultBank(setDefaultBankId);
            }
        };
        mYR_commonDialog.getContentTV().setText(setDefaultBankContent);
    }
    /**
     * 更新默认银行卡
     * @pararBankId 默认卡id
     */
    private void requestSetDefaultBank(int userBankId) {
        RequestParams params = new RequestParams();
        params.put("userBankId", userBankId);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.setDefaultBank), params, new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    requestBankList( "1");
                }
            }

            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                shortToast("抱歉，请求失败，请稍后再试；code:" + code);
            }

            public void onFinish() {
                super.onFinish();
                mYR_commonDialog.dismiss();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YY_EditBankCardActivityV2.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }


}
