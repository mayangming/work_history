package com.qlk.ymz.activity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.zoomimageview.XCZoomImageView;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

/**
 * Created by xilinch on 2015/6/19.
 *
 * SX_ProfessionalRanksActivity
 * 图片显示(大图)
 * @author  Changed by songxin on 2016/3/30.
 * @version 2.3
 */
public class SX_ShowPictureActivity extends DBActivity {
    /** 照片名字显示*/
    private TextView sx_id_picture_name_show;
    /** 照片显示*/
    private XCZoomImageView sx_id_picture_show;
    /** 照片路径临时变量*/
    private String mFilePath;
    /** 照片名字临时变量*/
    private String mPictureName;
    /** flag*/
    private int mIntentFlag;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_show_picture);
        super.onCreate(savedInstanceState);
        showTitleLayout(false);
        mIntentFlag = getIntent().getIntExtra("toShowPicture",0);
        mFilePath = getIntent().getStringExtra("FILE_PATH");
        mPictureName = getIntent().getStringExtra("PICTURE_NAME");
        sx_id_picture_name_show.setText(mPictureName);
        if(mIntentFlag == 0){
            //add by xd 优化图片显示 2017/12/8
            XCApplication.displayImage("file://"+mFilePath,sx_id_picture_show,XCImageLoaderHelper
                    .getDisplayImageOptions(R.mipmap.xc_d_chat_photo_default));
        }else if(mIntentFlag == 1){
            if (TextUtils.isEmpty(mFilePath)) {
                shortToast("图片获取失败！");
            } else {
                XCApplication.base_imageloader.displayImage(mFilePath, sx_id_picture_show, XCImageLoaderHelper.getDisplayImageOptions(0), new ImageLoadingListener(){
                    public void onLoadingStarted(String s, View view) {
                    }

                    public void onLoadingFailed(String s, View view, FailReason failReason) {
                        shortToast("图片获取失败！");
                    }

                    public void onLoadingComplete(String s, View view, Bitmap bitmap) {
                    }

                    public void onLoadingCancelled(String s, View view) {
                    }
                });
            }
        }else if(mIntentFlag == 2){
            if("个人照片样例".equals(mPictureName)){
                sx_id_picture_show.setImageResource(R.mipmap.sx_d_personal_photos_sample_amplification);
            }else if("工作证样例".equals(mPictureName)){
                sx_id_picture_show.setImageResource(R.mipmap.sx_d_emp_card_sample_amplification);
            }else if("执业资格证样例".equals(mPictureName)){
                sx_id_picture_show.setImageResource(R.mipmap.sx_d_vocational_qualification_sample_amplification);
            }
        }
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_ShowPictureActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        sx_id_picture_name_show = getViewById(R.id.sx_id_picture_name_show);
        sx_id_picture_show = getViewById(R.id.sx_id_picture_show);
        sx_id_picture_show.setScaleType(ImageView.ScaleType.CENTER_CROP);
        sx_id_picture_show.enable();

    }

    @Override
    public void listeners() {

    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:{
                myFinish();
                break;
            }


        }
        return false;
    }
}
