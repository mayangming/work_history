package com.qlk.ymz.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.RecipeDetailAdapter;
import com.qlk.ymz.adapter.SK_PrescriptionDetailAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.RecommendInfo;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.parse.Parse2MedicalRecordModel;
import com.qlk.ymz.parse.Parse2PatientDrugInfoModel;
import com.qlk.ymz.parse.Parser2RecommendInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtiDoctorCheck;
import com.qlk.ymz.util.UtilAppToSystemApp;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.WaterMarkBg;
import com.qlk.ymz.view.WatermarkDecoration;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

/**
 * Created by smile on 2017/7/25.
 * 处方笺展示页
 * update 2018/3/21
 * 增加药品到期的相关内容:
 * 1、药品到期时间
 * 2、续方 按钮
 * 注意:这两处功能只在药品到期功能触发的时候才进行显示
 */

public class YR_RecommendDetailActivity extends DBActivity  {
    /** title */
    private TextView sx_id_title_center;
    /** 红章*/
    private ImageView iv_cachet;
    /** 时间 */
    private TextView tv_prescription_time;
    /** 编号 */
    private TextView sk_id_pdetail_serialNum;
    /** 患者名 */
    private TextView tv_prescription_name;
    /** 性别 */
    private TextView sk_id_pdetail_sex;
    /** 年龄 */
    private TextView tv_prescription_age;
    /** 临床诊断 */
    private TextView tv_prescription_diagnosis;
    /** 药品列表 */
    private RecyclerView rv_content;
    /** 医生名字 */
    private TextView tv_prescription_doctorName;
    /** 科室title*/
    private TextView sk_id_pdetail_t6;
    /** 医生科室 */
    private TextView tv_prescription_department;
    /** 审核调配姓名 */
    private TextView tv_prescription_medicineName;
    /** 核对发药*/
    private TextView tv_check_medicine_name;
    /** 医生备注 */
    private TextView tv_remark;
    /** 医生签名 （非备注医生没有）*/
    private TextView tv_doctor_sign;
    /** 药师签名 （可没有）*/
    private TextView tv_medicine_sign;
    /** 有效期描述 */
    private TextView tv_expireDesc;
    /** 药品总金额 */
    private TextView tv_total_price;
    /** 处方笺title */
    private TextView tv_titleName;
    /** 作废按钮*/
    private TextView tv_invalid;
    /** 再次推荐的按钮 */
    private TextView tv_again_recommend;
    /** 页面背景*/
    private RelativeLayout rl_bg;
    /** 处方作废引导*/
    private RelativeLayout rl_guide;
    //药品适配器
    private RecipeDetailAdapter mRecipeDetailAdapter;
    private WatermarkDecoration mWatermarkDecoration;

    RecommendInfo recommendInfo = new RecommendInfo();

    public static String RECOMMEND_ID = "recommend_id";    //推荐单ID
    public static String PATIEND_ID = "patient_id";
    public static String REBUY_MSG = "rebuy_msg";//复购的信息
    public static String USER_PATIENT = "userPatient";//患者信息
    public static String FLAG = "flag";//页面标识 1 im进入 2 病历列表进入  3 续方列表进入

    private String patientId = "";
    private String recommendId = "";
    private String flag = "";
    private boolean isShowExpire = false;//是否显示到期提示
    private XC_ChatModel chatModel = new XC_ChatModel();//接收的值
    private  XC_PatientDrugInfo patientDrugInfo;//续方数据
    /** 检测是否认证的dialog */
    private YR_CommonDialog toCheckDialog;
    /** 作废二次确认对话框*/
    private YR_CommonDialog invalidDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        initData();

        setContentView(R.layout.yr_activity_recommend_detail);
        super.onCreate(savedInstanceState);

        initTitle();
    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_RecommendDetailActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */


    private void initData(){
        Intent intent = getIntent();
        patientId = intent.getStringExtra(PATIEND_ID);
        recommendId = intent.getStringExtra(RECOMMEND_ID);
        chatModel = (XC_ChatModel) intent.getSerializableExtra(REBUY_MSG);
        flag = intent.getStringExtra(FLAG);
        UserPatient userPatient = (UserPatient) intent.getSerializableExtra(USER_PATIENT);
        if (null == chatModel){//如果走的不是复购路径则这个值为
            chatModel = new XC_ChatModel();
            chatModel.setUserPatient(userPatient);
        }
        isShowExpire = chatModel.isShowExpire();
    }

    /** 初始化title */
    public void initTitle(){
        findViewById(R.id.sx_id_title_left).setOnClickListener(this);
        sx_id_title_center = (TextView)findViewById(R.id.sx_id_title_center);
        sx_id_title_center.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
        sx_id_title_center.setText("处方详情");
    }

    /**初始化控件*/
    @Override
    public void initWidgets() {
        View headView = LayoutInflater.from(this).inflate(R.layout.layout_recommend_detail_head, null);
        View footView = LayoutInflater.from(this).inflate(R.layout.layout_recommend_detail_foot, null);

        tv_prescription_time = (TextView) headView.findViewById(R.id.tv_prescription_time);
        sk_id_pdetail_serialNum = (TextView) headView.findViewById(R.id.sk_id_pdetail_serialNum);
        tv_prescription_name = (TextView) headView.findViewById(R.id.tv_prescription_name);
        sk_id_pdetail_sex = (TextView) headView.findViewById(R.id.sk_id_pdetail_sex);
        tv_prescription_age = (TextView) headView.findViewById(R.id.tv_prescription_age);
        tv_titleName = (TextView) headView.findViewById(R.id.tv_titleName);
        tv_prescription_diagnosis = (TextView) headView.findViewById(R.id.tv_prescription_diagnosis);
        sk_id_pdetail_t6 = (TextView) headView.findViewById(R.id.sk_id_pdetail_t6);
        tv_prescription_department = (TextView) headView.findViewById(R.id.tv_prescription_department);
        iv_cachet = headView.findViewById(R.id.iv_cachet);
        tv_prescription_doctorName = (TextView) footView.findViewById(R.id.tv_prescription_doctorName);
        tv_prescription_medicineName = (TextView) footView.findViewById(R.id.tv_prescription_medicineName);
        tv_check_medicine_name = footView.findViewById(R.id.tv_check_medicine_name);
        tv_remark = (TextView) footView.findViewById(R.id.tv_remark);
        tv_doctor_sign = (TextView) footView.findViewById(R.id.tv_doctor_sign);
        tv_medicine_sign = (TextView) footView.findViewById(R.id.tv_medicine_sign);
        tv_expireDesc = (TextView) footView.findViewById(R.id.tv_expireDesc);
        tv_total_price = (TextView) footView.findViewById(R.id.tv_total_price);
        tv_again_recommend = getViewById(R.id.tv_again_recommend);
        rv_content = getViewById(R.id.rv_content);
        tv_invalid = getViewById(R.id.tv_invalid);
        rl_bg = getViewById(R.id.rl_bg);
        rl_guide = getViewById(R.id.rl_guide);

        rv_content.setHasFixedSize(true);
        //设置recyclerview的布局方式
        rv_content.setLayoutManager(new LinearLayoutManager(this));
        mRecipeDetailAdapter = new RecipeDetailAdapter(this,recommendInfo.drugInfoBean);
        mRecipeDetailAdapter.addHeadView(headView);
        mRecipeDetailAdapter.addFootView(footView);
        rv_content.setAdapter(mRecipeDetailAdapter);
        mWatermarkDecoration= new WatermarkDecoration.Builder("").setColumnNum(3).builder(this);
        rv_content.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                //设置水印滚动位置
                mWatermarkDecoration.setScrollY(dy);
            }
        });

    }

    @Override
    public void listeners() {

        rl_guide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rl_guide.setVisibility(View.GONE);
            }
        });
        tv_invalid.setOnClickListener(this);
        tv_again_recommend.setOnClickListener(this);

        requestRecommendInfo();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dissmissDialog();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.tv_invalid://作废处方
                showInvalidDialog();
                break;
            case R.id.tv_again_recommend:
                //发送推荐用药
                chatModel.setRequireId("0");
                if (isShowExpire && !UtilString.isBlank(chatModel.getReBuyNotic().getRecommandId())) {
                    // 兼容版本升级，2.5之前的历史记录里是没有这个字段的
                    submit();
                    //add by songxin,date：2018-7-10,about：GrowingIO banner track,begin
                    GrowingIOUtil.track("ContinuPrescriptionclck", null);
                    //add by songxin,date：2018-7-10,about：GrowingIO banner track,end
                }else if(!isShowExpire){
                    submit();
                }
                break;
            case R.id.sx_id_title_left:
                finish();
                break;
        }
    }

    /** 展示作废的对话框*/
    private void showInvalidDialog() {
        if(invalidDialog==null){
            invalidDialog = new YR_CommonDialog(this,"作废后患者将不能通过作废处方购买药品","取消","确定") {
                @Override
                public void confirmBtn() {
                    invalidRecipe();
                    dismiss();
                }

            };
            invalidDialog.setTitle("确认作废该处方吗?");
            invalidDialog.setCanceledOnTouchOutside(false);
        }
        invalidDialog.show();
    }

    /**
     * 作废处方
     */
    private void invalidRecipe() {
        RequestParams params = new RequestParams();
        params.put("recomId", recommendId);
        XCHttpAsyn.postAsyn(this, AppConfig.getTuijianUrl(AppConfig.RECOM_INVALID), params, new
                XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    XCJsonBean xcJsonBean = result_bean.getList("data").get(0);
                    recommendInfo.setInvalidTime(xcJsonBean.getString("invalidTime"));
                    recommendInfo.setShowInvalidBtn("1");
                    recommendInfo.setInvalid("1");
                    setDate(recommendInfo);
                    //  修改im状态
                    XCChatModelDb.getInstance(getApplicationContext(),UtilSP.getIMDetailDbName
                            (UtilSP.getUserId(),patientId)).updateInvalidForRecommandId
                            (recommendId,"1");
                    Intent imIntent = new Intent();
                    imIntent.setAction(XC_ChatDetailActivity.UpdateInvalidReceiver.UPDATE_IVALID_ACTION);
                    imIntent.putExtra(XC_ChatDetailActivity.UpdateInvalidReceiver
                            .UPDATE_IVALID_RECOMMAND_ID,recommendId);
                    imIntent.putExtra(XC_ChatDetailActivity.UpdateInvalidReceiver
                            .UPDATE_IVALID_STATUS,"1");
                    context.sendBroadcast(imIntent);
                    //通知患者病例页刷新诊疗记录
                    Intent intent = new Intent();
                    intent.setAction(XL_PatientInfoAActivity.NewMedicalReceiver.NEW_MEDICAL_ACTION);
                    context.sendBroadcast(intent);
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(CommonConfig.UNAVOID.equals(getCode())){//不能作废
                    showUnavoidDialog(getMsg());
                }else if (null != result_bean && GeneralReqExceptionProcess.checkCode(YR_RecommendDetailActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    /**
     * 不能作废对话框
     * @param msg
     */
    private void showUnavoidDialog(String msg) {
        ClickableSpan click_span = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                UtilAppToSystemApp.toPhone(YR_RecommendDetailActivity.this, GlobalConfigSP.getCustomerServPhone());
            }
        };
        String contentStr = msg+"\n如需帮助请致电：4009-717-717（工作日9:00-23:00）";
        int start = (msg+"\n如需帮助请致电：").length();
        int end = (msg+"\n如需帮助请致电：4009-717-717").length();
        SpannableString spannableString = new SpannableString(contentStr);
        spannableString.setSpan(click_span, start,end, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(new ForegroundColorSpan(Color.parseColor("#395998")), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        YR_CommonDialog unavoidDialog = new YR_CommonDialog(this, spannableString, "", "知道了") {
            @Override
            public void confirmBtn() {
                dismiss();
            }
        };
        unavoidDialog.setCanceledOnTouchOutside(false);
        unavoidDialog.show();
    }

    /** 请求接口数据后，设置页面数据 */
    public void setDate(RecommendInfo recommendInfo){
        try {
            String hospital = TextUtils.isEmpty(recommendInfo.getTitle()) ? "鼎康慈桦互联网医院处方笺" : recommendInfo.getTitle();
            tv_titleName.setText(hospital);

            if(!TextUtils.isEmpty(recommendInfo.getDepartmentName())) {
                sk_id_pdetail_t6.setVisibility(View.VISIBLE);
                tv_prescription_department.setVisibility(View.VISIBLE);
                tv_prescription_department.setText(recommendInfo.getDepartmentName());
            }
            tv_prescription_doctorName.setText("医生：" + recommendInfo.getDoctorName());
            if(!TextUtils.isEmpty(recommendInfo.getPharmacistName())) {
                tv_prescription_medicineName.setVisibility(View.VISIBLE);
                tv_prescription_medicineName.setText("审核调配：" + recommendInfo.getPharmacistName());
            }
           //核对发药
            tv_check_medicine_name.setVisibility(View.VISIBLE);
            tv_check_medicine_name.setText("核对发药："+recommendInfo.getCheckMedicationName());

            if (!TextUtils.isEmpty(recommendInfo.getExpireDesc())) {
                tv_expireDesc.setVisibility(View.VISIBLE);
                tv_expireDesc.setText("注：" + recommendInfo.getExpireDesc());
            }
            if (!TextUtils.isEmpty(recommendInfo.getChronicDisease())) {
                tv_remark.setVisibility(View.VISIBLE);
                tv_remark.setText(recommendInfo.getChronicDisease());
            }
            sk_id_pdetail_serialNum.setText(recommendInfo.getSerialNumber());
            if(!TextUtils.isEmpty(recommendInfo.getRecomTime())) {
                tv_prescription_time.setText(DateUtils.DateFormat(recommendInfo.getRecomTime(), "yyyy/MM/dd HH:mm"));
            }
            String ageContent = "";
            if (!TextUtils.isEmpty(recommendInfo.getPatientAge())){
                ageContent = ageContent.concat(recommendInfo.getPatientAge());
            }
            if (!TextUtils.isEmpty(recommendInfo.getPatientAgeUnit())){
                ageContent = ageContent.concat(recommendInfo.getPatientAgeUnit());
            }
            tv_prescription_age.setText(ageContent);
            tv_prescription_name.setText(recommendInfo.getPatientName());
            if (CommonConfig.GENDER_MALE.equals(recommendInfo.getPatientGender())) {
                sk_id_pdetail_sex.setText("男");
            } else if (CommonConfig.GENDER_FEMALE.equals(recommendInfo.getPatientGender())) {
                sk_id_pdetail_sex.setText("女");
            } else {
                sk_id_pdetail_sex.setText("");
            }
            tv_prescription_diagnosis.setText(recommendInfo.getDiagnosis());

            tv_total_price.setText("总金额：￥" + recommendInfo.getTotalPrice());

            //设置签名
            String time = "";
            if ("1".equals(recommendInfo.getShowDoctorSignature())) {
                tv_doctor_sign.setVisibility(View.VISIBLE);
                if (!TextUtils.isEmpty(recommendInfo.getDoctorAuditTime())) {
                    time = DateFormat.format("yyyy.MM.dd", Long.parseLong(recommendInfo.getDoctorAuditTime())).toString();
                }
                tv_doctor_sign.setText("医生：" + recommendInfo.getDoctorName() + "\n" + recommendInfo.getSignatureContent() + "\n " + time);
            }
            if ("1".equals(recommendInfo.getShowDoctorSignature())) {
                tv_medicine_sign.setVisibility(View.VISIBLE);
                if (!TextUtils.isEmpty(recommendInfo.getDoctorAuditTime())) {
                    time = DateFormat.format("yyyy.MM.dd", Long.parseLong(recommendInfo.getDoctorAuditTime())).toString();
                }
                tv_medicine_sign.setText("审核调配：" + recommendInfo.getPharmacistName() + "\n" +
                        recommendInfo.getSignatureContent() + "\n " + time);
            }

            if("0".equals(recommendInfo.getShowInvalidBtn())){//显示作废按钮
                tv_invalid.setVisibility(View.VISIBLE);
                if(UtilSP.isRecipeGuide()){
                    rl_guide.setVisibility(View.VISIBLE);
                    UtilSP.setRecipeGuide(false);
                }
            }else {//不显示作废按钮
                tv_invalid.setVisibility(View.GONE);
                tv_again_recommend.setBackgroundResource(R.mipmap.buttom_bt_bg);
            }

            if(TextUtils.isEmpty(recommendInfo.getHospitalSealUrl())){//公章是否显示
                iv_cachet.setVisibility(View.GONE);
            }else {
                iv_cachet.setVisibility(View.VISIBLE);
                XCApplication.displayImage(recommendInfo.getHospitalSealUrl(),iv_cachet);
            }

            if("1".equals(recommendInfo.getInvalid())){//已作废
                tv_again_recommend.setText("重新修改处方");
                // 设置作废背景
//                rl_bg.setBackground(new WaterMarkBg(this,recommendInfo.getInvalidTime(),-45));
                mWatermarkDecoration.setWaterText(recommendInfo.getInvalidTime());
                rv_content.addItemDecoration(mWatermarkDecoration);
            }
            //更新药品列表
            mRecipeDetailAdapter.setData(recommendInfo.getDrugInfoBean());
            mRecipeDetailAdapter.notifyDataSetChanged();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void onNetRefresh() {

    }


    /** 请求处方笺info */
    public void requestRecommendInfo() {
        if(TextUtils.isEmpty(recommendId) || TextUtils.isEmpty(patientId)) {
            return;
        }
        RequestParams params = new RequestParams();
        params.put("recommendId", recommendId);
        params.put("patientId", patientId);
        params.put("doctorId", UtilSP.getUserId());
        params.put("showExpire", isShowExpire);//是否显示到期提示
        XCHttpAsyn.postAsyn(this, AppConfig.getTuijianUrl(AppConfig.prescriptionDetail), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean != null) {
                        Parser2RecommendInfo parser2RecommendInfo = new Parser2RecommendInfo(recommendInfo);
                        parser2RecommendInfo.parseJson(result_bean);
                        setDate(recommendInfo);
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
            }

            @Override
            public void onFinish() {
                super.onFinish();

            }
        });
    }

    /* 重新推荐的参数(POST /recom/repeat)：token，doctorId,  patientId, recommendId */
    private void submit() {
        // 点击确认用药按钮
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("patientId",patientId);
        params.put("recommendId",recommendId);//重新推荐用药的时候，服务端会接收这个值
        boolean isShowDialog = true;
        if (!"3".equals(flag)&&!UtiDoctorCheck.isVertify()) {//不是续方列表并且未认证
            // 未认证
            if (isOutUnCheckSendLinkMedicineTimes()) {
                // 未认证，且已经超过了试用的次数
                isShowDialog = false;
                // 去认证提示
                toCheck(true);
            }
        }
        requestUsage(isShowDialog, params);
    }
    /**
     * 当是自主购药、重复推荐的时候会运行到这里，自主购药和重复推荐是一样的逻辑
     */
    private void requestUsage(final boolean isShowDialog, RequestParams params) {

        XCHttpAsyn.postAsyn(isShowDialog, this, AppConfig.getTuijianUrl(AppConfig.repeatRecommand), params, new XCHttpResponseHandler() {

                    @Override
                    public void success() {
                        super.success();
                    }

                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (CommonConfig.MEDICINE_FIFTER_CODE.equals(getCode())){//假如符合正大天晴项目规则，则弹出对话框并终止下一步操作
                            medicineFifterDialog(getMsg());
                            return;
                        }
                        // 后台约定，如果是未认证且超过了使用次数，请求该接口，但是不做处理
                        if (isShowDialog) {
                            patientDrugInfo = Parse2PatientDrugInfoModel.parse(result_bean, chatModel);
                            if (result_boolean) {
                                //该接口是没有数量的， 与后台沟通了，最后是客户端从bean里获取
                                patientDrugInfo.obtQuantity(UtilIMCreateJson.recommandMedicineMsg2Drugs(chatModel));
                                patientDrugInfo.setCheckInventoryInfo(true);//查询库存
                               if("3".equals(flag)){//续方列表
                                   if (RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size() > 0
                                           || RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getDiagnoseBeanList().size() > 0) {//药箱中有药品
                                       showOverRecipeDialog();
                                   } else {
                                       RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setList(patientDrugInfo.getList());
                                       RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setDiagnoseBeanList(patientDrugInfo.getDiagnoseBeanList());
                                       RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setRecommendInfo(patientDrugInfo.getRecommendInfo());
                                       RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setCheckInventoryInfo(true);
                                       SQ_RecommendActivity.launch(YR_RecommendDetailActivity.this);
                                   }
                               }else {//不是续方列表
                                   RecomMedicineHelper.getInstance().setFlag(flag);
                                   RecomMedicineHelper.getInstance().setXC_patientDrugInfo(patientDrugInfo);
                                   if(UtilSP.isRecordRecom()){//医嘱医生
                                       requestCase();
                                       return;
                                   }
                                   SQ_RecommendActivity.launch(YR_RecommendDetailActivity.this);
                               }
                            }
                        }
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        GeneralReqExceptionProcess.checkCode(YR_RecommendDetailActivity.this, getCode(), getMsg());
                    }
                }
        );
    }

    private void requestCase() {//请求病历
        if(TextUtils.isEmpty(chatModel.getReBuyNotic().getRecordId())){//不是带病历的处方
            requestRecentCase();
        }else {
            requestCaseByRecordId();
        }
    }

    /**
     * 是否超出了推荐用药的次数
     */
    private boolean isOutUnCheckSendLinkMedicineTimes() {
        return UtilSP.getLinkMedicineSuccessTimes() <= 0;
    }
    /**
     * 检测审核状态
     *
     * @param isMedicine true 是推荐用药 false 是健康检查
     */
    private void toCheck(boolean isMedicine) {
        if (UtiDoctorCheck.isFailOrNoVerfy()) {
            if (isMedicine) {
                showNoCheckDialog(YR_CommonDialog.HINT_UNCHECK, YY_PersonalDataActivityV2.class);
            } else {
                showNoCheckDialog(YR_CommonDialog.HINT_UNCHECK_HEALTH, YY_PersonalDataActivityV2.class);
            }
        } else if (UtiDoctorCheck.isCheckingOrAgain()) {
            if (isMedicine) {
                showCheckingDialog(YR_CommonDialog.HINT_CHECKING);
            } else {
                showCheckingDialog(YR_CommonDialog.HINT_UNCHECK_HEALTH);
            }
        }
    }
    /**
     * 显示未认证的dialog
     *
     * @param hint 为认证的提示
     * @param cls  跳转到那个activity的class
     */
    private void showNoCheckDialog(String hint, final Class<? extends XCBaseActivity> cls) {
        toCheckDialog = new YR_CommonDialog(this, hint, "暂不认证", "去认证") {
            @Override
            public void confirmBtn() {
                toCheckDialog.dismiss();
                myStartActivity(cls);
            }
        };
        toCheckDialog.show();
    }

    /**
     * 显示覆盖处方的对话框
     */
    private void showOverRecipeDialog() {
        YR_CommonDialog mOverRecipeDialog = new YR_CommonDialog(this,
                "当前已有编辑中的处方，使用“续方”功能将覆盖当前编辑中的处方，是否继续？", "取消", "继续") {
            @Override
            public void confirmBtn() {
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setList(patientDrugInfo.getList());
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setDiagnoseBeanList(patientDrugInfo.getDiagnoseBeanList());
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setRecommendInfo(patientDrugInfo.getRecommendInfo());
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setCheckInventoryInfo(true);
                SQ_RecommendActivity.launch(YR_RecommendDetailActivity.this);
                dismiss();
            }
        };
        mOverRecipeDialog.setCanceledOnTouchOutside(false);
        mOverRecipeDialog.show();
    }

    // add by xjs on 20151119 22:23 start
// 修复JIRA上　http://jira.7lk.me/browse/DBYZ-1024　的问题
    private void showCheckingDialog(String hint) {
        toCheckDialog = new YR_CommonDialog(this, hint, "", "我知道了") {
            @Override
            public void confirmBtn() {
                toCheckDialog.dismiss();
            }
        };
        toCheckDialog.show();
    }
    private YR_CommonDialog medicineFifterDialog;
    private void medicineFifterDialog(String medicines){
        medicineFifterDialog = new YR_CommonDialog(this,medicines,"","我知道了") {
            @Override
            public void confirmBtn() {
                medicineFifterDialog.dismiss();
            }
        };
        medicineFifterDialog.setCanceledOnTouchOutside(false);
        medicineFifterDialog.show();
    }
    /*关闭对话框*/
    private void dissmissDialog(){
        if (null != toCheckDialog && toCheckDialog.isShowing()){
            toCheckDialog.dismiss();
            toCheckDialog = null;
        }
    }

    /**
     * 请求最近的病历
     */
    private void requestRecentCase() {
        RequestParams params = new RequestParams();
        params.put("doctorId",UtilSP.getUserId());
        params.put("patientId",chatModel.getUserPatient().getPatientId());
        XCHttpAsyn.postAsyn(this, AppConfig.getRecordUrl(AppConfig.LAST_MEDICAL_RECORD), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                //如果没有病历则跳转至新建病历页，有病历的话则跳转至查看病历页
                if (result_boolean) {
                    DrRecordVOBean drRecordVOBean = new DrRecordVOBean();
                    Parse2MedicalRecordModel parse2MedicalRecordModel = new Parse2MedicalRecordModel(drRecordVOBean);
                    parse2MedicalRecordModel.parseJson(result_bean);

                    if (!UtilSP.isExplain()){//如果没显示过病历处方说明页则显示病历处方说明页
                        ToJumpHelp.toJumpExplainActivity(YR_RecommendDetailActivity.this,CommonConfig.RE_BUY_NOTIC,drRecordVOBean.getCaseType(), chatModel,drRecordVOBean);
                        return;
                    }

                    if (CommonConfig.NO_MEDICAL_RECORD.equals(drRecordVOBean.getCaseType())){//-1是没有病历，跳转至新建病历
                        ToJumpHelp.toJumpEditMedicalRecordActivity(YR_RecommendDetailActivity.this,patientId,2);
                    }else{//有既往病历
                        ToJumpHelp.toJumpMedicalRecordDetailActivity(YR_RecommendDetailActivity.this, drRecordVOBean,false);
                    }
                }
            }

            @Override
            public void yourCompanyLogic() {
                result_boolean = HTTP_OK.equals(getCode());
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
            }
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                GeneralReqExceptionProcess.checkCode(YR_RecommendDetailActivity.this,getCode(), getMsg());
            }
        });
    }

    /**
     * 根据病历id查询病历
     */
    private void requestCaseByRecordId( ) {
        RequestParams params = new RequestParams();
        params.put("doctorId",UtilSP.getUserId());
        params.put("recoreId",chatModel.getReBuyNotic().getRecordId());
        XCHttpAsyn.getAsyn(YR_RecommendDetailActivity.this, AppConfig.getRecordUrl(AppConfig
                .MEDICAL_RECORD_ID), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    DrRecordVOBean drRecordVOBean = new DrRecordVOBean();
                    Parse2MedicalRecordModel parse2MedicalRecordModel = new Parse2MedicalRecordModel(drRecordVOBean);
                    parse2MedicalRecordModel.parseJson(result_bean);

                    XC_PatientDrugInfo patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
                    patientDrugInfo.setDrRecordVOBean(drRecordVOBean);
                    RecomMedicineHelper.getInstance().setXC_patientDrugInfo(patientDrugInfo);
                    if (!UtilSP.isExplain()){//如果没显示过病历处方说明页则显示病历处方说明页
                        ToJumpHelp.toJumpExplainActivity(YR_RecommendDetailActivity.this,CommonConfig.RE_BUY_NOTIC,drRecordVOBean.getCaseType(), chatModel,drRecordVOBean);
                        return;
                    }
                    SQ_RecommendActivity.launch(YR_RecommendDetailActivity.this);//直接续方
                }
            }

            @Override
            public void yourCompanyLogic() {
                result_boolean = HTTP_OK.equals(getCode());
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
            }
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                GeneralReqExceptionProcess.checkCode(YR_RecommendDetailActivity.this,getCode(),getMsg());
            }
        });
    }
}
