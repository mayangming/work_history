package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.DiagnoseBean;

import java.util.List;

/**
 * 诊断搜索
 * @author wpq
 * @version 1.0
 */
public class DiagnoseSearchAdapter extends BaseAdapter {

    private Context mContext;
    private List<DiagnoseBean> mList;
    private String searchKeyword;

    public DiagnoseSearchAdapter(Context context, List<DiagnoseBean> list) {
        this.mContext = context;
        this.mList = list;
    }

    public void update(String searchKeyword) {
        this.searchKeyword = searchKeyword;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mList == null ? 0 : mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_diagnose_common, null);
            holder = new ViewHolder();
            holder.tvDiagnoseName = (TextView) convertView.findViewById(R.id.tv_diagnoseName);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        DiagnoseBean searchBean = mList.get(position);
        if (searchBean != null) {
            String diagnoseName = searchBean.name;
            if (!TextUtils.isEmpty(diagnoseName) && !TextUtils.isEmpty(searchKeyword)) {
                if (diagnoseName.contains(searchKeyword)) {
                    SpannableStringBuilder ss = new SpannableStringBuilder(diagnoseName);
                    int index = diagnoseName.indexOf(searchKeyword);
                    ss.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.c_e2231a)), index, index + searchKeyword.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE );
                    holder.tvDiagnoseName.setText(ss);
                } else {
                    holder.tvDiagnoseName.setText(diagnoseName);
                }
            }
        }

        return convertView;
    }

    static class ViewHolder{
        TextView tvDiagnoseName;
    }

}
