package com.qlk.ymz.db.invited;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author xiaocoder on 2016/3/23.
 * @modifier xiaocoder 2016/3/23 16:43.
 * @description
 */
public class XL_ContactsModelDb extends SQLiteOpenHelper {
    /**
     * 数据库文件名
     */
    public static String mDefaultDbName = "xL_ContactsModel.db";
    /**
     * 数据库版本号
     */
    public static int mVersion = 10;//变更备用列为 列number display_name

    /**
     * 数据表名称
     */
    public static String mOperatorTableName = "xL_ContactsModelTable";

    /**
     * 排序常量
     */
    public static String SORT_DESC = " DESC";// 有个空格符号，勿删
    public static String SORT_ASC = " ASC";// 有个空格符号，勿删

    /**
     * 以下是表字段
     */
    public static final String _ID = "_id";
    /**
     * 联系人id
     */
    public static final String CONTACT_ID = "contactId";
    /**
     * 医生id
     */
    public static final String DOCTOR_ID = "doctorId";
    /**
     * 是否邀请的标识符
     */
    public static final String FLAG = "flag";
    /**
     * 电话号码
     */
    public static final String NUMBER = "number";
    /**
     * 备用字段2
     */
    public static final String DISPLAY_NAME = "display_name";

    /**
     * 装db集合的
     */
    public static Map<String, XL_ContactsModelDb> map = new LinkedHashMap<String, XL_ContactsModelDb>();

    public static XL_ContactsModelDb getInstance(Context context) {

        return getInstance(context, mDefaultDbName);
    }

    public static XL_ContactsModelDb getInstance(Context context, String dbName) {

        XL_ContactsModelDb db = map.get(dbName);

        if (db != null) {
            return db;
        }

        synchronized (XL_ContactsModelDb.class) {
            if (map.get(dbName) == null) {
                map.put(dbName, new XL_ContactsModelDb(context, dbName));
            }
            return map.get(dbName);
        }

    }

    private XL_ContactsModelDb(Context context) {
        super(context, mDefaultDbName, null, mVersion);
    }

    private XL_ContactsModelDb(Context context, String dbName) {
        super(context, dbName, null, mVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + mOperatorTableName
                + "(" + _ID + " integer primary key autoincrement,"
                + DOCTOR_ID + " text, "
                + CONTACT_ID + " text, "
                + FLAG + " text, "
                + NUMBER + " text, "
                + DISPLAY_NAME + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + mOperatorTableName);

        sqLiteDatabase.execSQL("CREATE TABLE " + mOperatorTableName
                + "(" + _ID + " integer primary key autoincrement,"
                + DOCTOR_ID + " text, "
                + CONTACT_ID + " text, "
                + FLAG + " text, "
                + NUMBER + " text, "
                + DISPLAY_NAME + " text)");
    }

    public ContentValues createContentValue(XL_ContactsInvitedModel model) {
        ContentValues values = new ContentValues();
        values.put(DOCTOR_ID, model.getDoctorId());
        values.put(CONTACT_ID, model.getContactId());
        values.put(FLAG, model.getFlag());
        values.put(NUMBER, model.getNumber());
        values.put(DISPLAY_NAME, model.getDisplay_name());
        return values;
    }

    public XL_ContactsInvitedModel createModel(Cursor c) {
        XL_ContactsInvitedModel model = new XL_ContactsInvitedModel();
        model.setDoctorId(c.getString(c.getColumnIndex(DOCTOR_ID)));
        model.setContactId(c.getString(c.getColumnIndex(CONTACT_ID)));
        model.setFlag(c.getString(c.getColumnIndex(FLAG)));
        model.setNumber(c.getString(c.getColumnIndex(NUMBER)));
        model.setDisplay_name(c.getString(c.getColumnIndex(DISPLAY_NAME)));
        return model;
    }

    /**
     * 插入一条记录
     */
    public synchronized long insert(XL_ContactsInvitedModel model) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = createContentValue(model);
        long id = db.insert(mOperatorTableName, _ID, values);
        db.close();
        return id;
    }

    public synchronized long inserts(List<XL_ContactsInvitedModel> list) {
        int count = 0;
        SQLiteDatabase db = getWritableDatabase();
        for (XL_ContactsInvitedModel model : list) {
            ContentValues values = createContentValue(model);
            long id = db.insert(mOperatorTableName, _ID, values);
            count++;
        }
        db.close();
        return count;
    }

    /**
     * 删除所有记录
     */
    public synchronized int deleteAll() {
        SQLiteDatabase db = getWritableDatabase();
        int raw = db.delete(mOperatorTableName, null, null);
        db.close();
        return raw;
    }

    /**
     * 查询共有多少条记录
     */
    public synchronized int queryCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, new String[]{"COUNT(*)"}, null, null, null, null, null, null);
        c.moveToNext();
        int count = c.getInt(0);
        c.close();
        db.close();
        return count;
    }

    /**
     * 查询所有
     */
    public synchronized List<XL_ContactsInvitedModel> queryAllByIdDesc() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_DESC); // 条件为null可以查询所有
        List<XL_ContactsInvitedModel> beans = new ArrayList<XL_ContactsInvitedModel>();
        while (c.moveToNext()) {
            XL_ContactsInvitedModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /**
     * 查询所有
     */
    public synchronized List<XL_ContactsInvitedModel> queryAllByIdAsc() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_ASC);
        List<XL_ContactsInvitedModel> beans = new ArrayList<XL_ContactsInvitedModel>();
        while (c.moveToNext()) {
            XL_ContactsInvitedModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /**
     * 分页查找
     */
    public synchronized List<XL_ContactsInvitedModel> queryPageByIdAsc(int pageNum, int capacity) {
        String offset = (pageNum - 1) * capacity + ""; // 偏移量
        String len = capacity + ""; // 个数
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_ASC, offset + "," + len);
        List<XL_ContactsInvitedModel> beans = new ArrayList<XL_ContactsInvitedModel>();
        while (c.moveToNext()) {
            XL_ContactsInvitedModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /**
     * 分页查找
     */
    public synchronized List<XL_ContactsInvitedModel> queryPageByIdDesc(int pageNum, int capacity) {
        String offset = (pageNum - 1) * capacity + ""; // 偏移量
        String len = capacity + ""; // 个数
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_DESC, offset + "," + len);
        List<XL_ContactsInvitedModel> beans = new ArrayList<XL_ContactsInvitedModel>();
        while (c.moveToNext()) {
            XL_ContactsInvitedModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /**
     * 根据联系人id和医生id来修改数据
     * @param model  新数据
     * @param value1 联系人id
     * @param doctorId 医生id
     * @return 修改数量
     */
    public synchronized int updateStatusByContactId(XL_ContactsInvitedModel model, String value1, String doctorId) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = createContentValue(model);
        int rows = db.update(mOperatorTableName, values, CONTACT_ID + " = ? and " + DOCTOR_ID + " = ? ", new String[]{value1,doctorId});
        db.close();
        return rows;
    }

    /**
     * 根据联系人id和医生id来查询数据
     * @param value1 联系人id
     * @param doctorId 医生id
     * @return
     */
    public synchronized List<XL_ContactsInvitedModel> queryByContactId(String value1, String doctorId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, CONTACT_ID + " = ? and " + DOCTOR_ID + " = ? ", new String[]{value1,doctorId}, null, null, null, null);
        List<XL_ContactsInvitedModel> beans = new ArrayList<XL_ContactsInvitedModel>();
        while (c.moveToNext()) {
            XL_ContactsInvitedModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }
    /**
     * 查询所有邀请过的人
     * @return
     */
    public synchronized List<XL_ContactsInvitedModel> queryStatusInvitied() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, FLAG + " = 1", null, null, null, null, null);
        List<XL_ContactsInvitedModel> beans = new ArrayList<XL_ContactsInvitedModel>();
        while (c.moveToNext()) {
            XL_ContactsInvitedModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /**
     * 根据医生id来查询邀请过的人
     * @param doctorId 医生id
     * @return
     */
    public synchronized List<XL_ContactsInvitedModel> queryStatusInvitied(String doctorId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, FLAG + " = 1 and " + DOCTOR_ID + " = ?", new String[]{doctorId}, null, null, null, null);
        List<XL_ContactsInvitedModel> beans = new ArrayList<XL_ContactsInvitedModel>();
        while (c.moveToNext()) {
            XL_ContactsInvitedModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }
}
