package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.XL_CashDetailBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import org.apache.http.Header;

import java.util.List;

/**
 *
 * @author xilinch on 2016/1/12.
 * @modifier xilinch 2016/1/12 17:26.
 * @description 提现详情
 *
 * @author cyr on 2016-4-28
 * @description 2.3暂时去掉
 */
public class XL_CashDetailActivity extends DBActivity {
    private XCTitleCommonLayout titlebar;
    /**状态*/
    private TextView xl_activity_cash_tv_status;
    /**金额信息*/
    private TextView xl_activity_cash_tv_count;
    /**银行卡信息*/
    private LinearLayout xl_activity_cash_ll_bank;
    /**银行卡图标*/
    private XCRoundedImageView xl_activity_cash_bank_iv;
    /**账单编号*/
    private TextView xl_activity_cash_id;
    /** 银行卡信息*/
    private TextView xl_activity_cash_detail_tv_bank_info;
    /**创建时间*/
    private TextView xl_activity_cash_create_time;
    /**产生原因*/
    private TextView xl_activity_cash_reason;
    /**备注*/
    private TextView xl_activity_cash_note;
    /**备注父布局*/
    private LinearLayout xl_activity_cash_note_ll;
    /**提现记录id*/
    private int id;
    /**提现记录id key*/
    public static final String ID = "id";
    /**提现记录数据 */
    private XL_CashDetailBean.DataEntity dataEntity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xl_activity_cash_detail);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_CashDetailActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "提现详情");
        titlebar.setTitleLeft(true, "");
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));

        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xl_activity_cash_tv_status = getViewById(R.id.xl_activity_cash_detail_tv_status);
        xl_activity_cash_tv_count = getViewById(R.id.xl_activity_cash_detail_tv_count);
        xl_activity_cash_ll_bank = getViewById(R.id.xl_activity_cash_detail_ll_bank);
        xl_activity_cash_bank_iv = getViewById(R.id.xl_activity_cash_detail_bank_iv);
        xl_activity_cash_id = getViewById(R.id.xl_activity_cash_detail_id);
        xl_activity_cash_create_time = getViewById(R.id.xl_activity_cash_detail_create_time);
        xl_activity_cash_reason = getViewById(R.id.xl_activity_cash_detail_reason);
        xl_activity_cash_note = getViewById(R.id.xl_activity_cash_detail_note);
        xl_activity_cash_note_ll = getViewById(R.id.xl_activity_cash_detail_note_ll);
        xl_activity_cash_detail_tv_bank_info = getViewById(R.id.xl_activity_cash_detail_tv_bank_info);
        id = getIntent().getIntExtra(ID,0);
        if(id == 0){

            shortToast("账单id异常!");
        } else {

            requestData();
        }

    }

    @Override
    public void listeners() {
        xl_activity_cash_ll_bank.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.xl_activity_cash_detail_ll_bank:

                break;
        }
    }

    @Override
    public void onNetRefresh() {
        requestData();
    }


    /**
     * 显示账单详细UI
     * @param dataEntity
    {
    "id": 16,
    "createdAt" : "2016-01-01 00:00:00",
    "amount": 50000,
    "bankName": "中国工商银行",
    "cardTailNum": "7184",
    "statusName": "等待审核",
    "color": "#cccccc" ,
    "bankIcon": "xxx",
    "bankAccount": "xxx",
    "remark": ""
    }
     *
     */
    private void showBillDetail(XL_CashDetailBean.DataEntity dataEntity){

        xl_activity_cash_tv_status.setText(dataEntity.getStatusName());
        xl_activity_cash_tv_count.setText(dataEntity.getAmountText());
        XCApplication.displayImage(dataEntity.getBankIcon(), xl_activity_cash_bank_iv);
        xl_activity_cash_id.setText(dataEntity.getId() + "");
        xl_activity_cash_detail_tv_bank_info.setText(dataEntity.getBankName() + " (" + dataEntity.getCardTailNum() + ")");
        xl_activity_cash_create_time.setText(dataEntity.getCreatedAt());
        xl_activity_cash_note.setText(dataEntity.getRemark());

        String remark = dataEntity.getRemark();
        if(TextUtils.isEmpty(remark)){
            xl_activity_cash_note_ll.setVisibility(View.GONE);
        } else {
            xl_activity_cash_note_ll.setVisibility(View.VISIBLE);
            xl_activity_cash_note.setText(dataEntity.getRemark());
        }

    }

    /**
     * 请求提现详情数据
     */
   private void requestData() {
       RequestParams params = new RequestParams();
       params.put("id", id);
       XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.withdrawal_detail), params, new XCHttpResponseHandler<XL_CashDetailBean>(this, XL_CashDetailBean.class) {
           public void onSuccess(int code, Header[] headers, byte[] arg2) {
               super.onSuccess(code, headers, arg2);
               if (result_boolean) {
                   List<XL_CashDetailBean.DataEntity> objLists = mResultModel.getData();
                   if (objLists != null && objLists.size() > 0) {
                       XL_CashDetailBean.DataEntity obj = objLists.get(0);
                       dataEntity = obj;
                       showBillDetail(obj);
                   }
               }
           }

           // 对账户冻结情况的判断处理
           public void onFinish() {
               super.onFinish();

               if (null != result_bean && GeneralReqExceptionProcess.checkCode(XL_CashDetailActivity.this,
                       getCode(),
                       getMsg())) {
                   // 接口请求业务成功时的处理
               }
           }
       });
   }
}
