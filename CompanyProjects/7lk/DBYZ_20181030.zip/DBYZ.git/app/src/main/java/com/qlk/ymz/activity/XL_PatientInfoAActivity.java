package com.qlk.ymz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.contrarywind.view.WheelView;
import com.handmark.pulltorefresh.library.ILoadingLayout;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.loopj.android.http.RequestParams;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_MedicalRecordsAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.record.Attribute;
import com.qlk.ymz.model.record.DataInfoWithType;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.DrRecordPageVO;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.model.record.MemberVOBean;
import com.qlk.ymz.model.record.PatientCaseVOBean;
import com.qlk.ymz.model.record.PatientOldCaseVOBean;
import com.qlk.ymz.model.record.PrescriptionVOBean;
import com.qlk.ymz.model.record.RecordVOBean;
import com.qlk.ymz.modelflag.XL_PatientBasicBean;
import com.qlk.ymz.parse.Parse2PatientBasicBean;
import com.qlk.ymz.parse.Parse2PatientBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.ListItemFilter;
import com.qlk.ymz.util.MultiTypeJsonParser;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilAppToSystemApp;
import com.qlk.ymz.util.UtilBasicInfo;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.Utils;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ArrayTextWheelAdapter;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.zoomimageview.XCViewPagerFragment;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilBroadcast;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

import static com.qlk.ymz.util.AppConfig.patient_detail;

/**
 * @author cyr on 2016-4-28
 * @description 患者详细资料
 * <p>
 * V2.7.0 每次进入此页面请求一次当前患者信息，并更新数据库中当前患者的信息
 * （包括真实姓名、性别、年龄、城市）
 * <p>
 * v2.8  wy 页面改版
 */
public class XL_PatientInfoAActivity extends DBActivity {
    private XCTitleCommonLayout titlebar;
    /**
     * 患者头像
     */
    private XCRoundedImageView xl_patientinfo_ic;
    /**
     * 进入聊天
     */
    private TextView xl_personinfo_btn_chat;
    /**
     * 名字
     */
    private TextView xl_patientinfo_tv_name;
    /**
     * 昵称
     */
    private TextView xl_patientinfo_tv_nick_name;
    /**
     * 手机号
     */
    private TextView xl_patientinfo_tv_phone;
    /**
     * 年龄
     */
    private TextView xl_patientinfo_tv_age;
    /**
     * 地区
     */
    private TextView xl_patientinfo_tv_other;
    /**
     * 昵称布局
     */
    private LinearLayout nicknameLayout;
    /**
     * 电话布局
     */
    private LinearLayout phoneLayout;
    /**
     * 地区布局
     */
    private LinearLayout areaLayout;
    /**
     * 患者信息布局
     */
    private RelativeLayout patientinfo_layout;
    /**
     * 分组布局
     */
    private LinearLayout grouplayout;
    /**
     * 患者分组名称
     */
    private TextView groupName;
    /**
     * 无基本病情展示
     */
    private TextView emptyCondition_tv;
    /**
     * 诊疗记录列表
     */
    private PullToRefreshListView sx_id_medical_records_list;
    private ListView lv;
    /**
     * 病历列表数据转换
     */
    private DrRecordPageVO parse2MedicalRecordsModel;
    /**
     * 病历列表适配器
     */
    private SX_MedicalRecordsAdapter mSX_MedicalRecordsAdapter;
    /**
     * 添加病历
     */
    private TextView sx_id_add_medical_rl;
    /**
     * 性别
     */
    private TextView xl_patientinfo_tv_sex;
    /**
     * 患者id
     */
    private String mPatientId;
    /**
     * 跳转到聊天必须封装的对象
     */
    private XC_ChatModel xc_chatModel;
    /**
     * 图片显示设置
     */
    private DisplayImageOptions options1 = XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default);
    /**
     * 显示的大图
     */
    private XCViewPagerFragment fragment;
    /**
     * 图文咨询付费标识
     */
    private TextView tv_consult_fee;

    /**
     * 没有诊疗记录的视图
     */
    private LinearLayout emptyLayout;
    /**
     * 筛选条件布局
     */
    private LinearLayout screen_layout;
    /**
     * 编辑诊疗记录的PopupWindow
     */
    private PopupWindow mPopWindow;
    /**
     * 选择分组的list
     */
    private ArrayList<String> groupName_list = new ArrayList<String>();
    /**
     * 跳转到基本病情封装的对象
     */
    private XL_PatientBasicBean petientBasicBeanFlag;
    private static final int REQ_CODE_PERSONINFO = 1001;
    private static final int REQ_CODE_GROUPLIST = 1002;
    private static final int REQ_CODE_PATIENT_BASIC_INFO = 1003;
    private static final int REQ_CODE_MEDICAL = 1004;
    private NewMedicalReceiver mNewMedicalReceiver;
    /** 删除患者信息的广播 */
    private DelPatientReceiver delPatientReceiver;
    /**
     * 筛选条件文字
     */
    private TextView mScreentv;
    /**
     * 屏幕宽
     */
    private int mScreenWidth = 720;
    /**
     * 选择筛选条件对话框
     */
    private ConfirmDialog mScreenDialog;

    /**
     * 选择筛选条件控件
     */
    private WheelView mWheelView;
    /**
     * 选择筛选条件对话框取消按钮
     */
    private TextView tv_set_screen_cancel;
    /**
     * 选择筛选条件对话框确定按钮
     */
    private TextView tv_set_screen_confirm;
    /**
     * 筛选条件数值
     */
    private String value = "";
    private List<DrRecordVOBean> mList = new ArrayList<>();
    /**
     * 记录点击时候的时间
     */
    private long lastClickTime;

    /**
     * 防止500毫秒内重复点击的方法
     *
     * @return true：重复点击，false：不是重复点击
     */
    public boolean isFastClick() {
        long time = System.currentTimeMillis();
        if (time - lastClickTime < 1000) {
            return true;
        }
        lastClickTime = time;
        return false;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        initData();
        setContentView(R.layout.xl_activity_patientinfoa);
        super.onCreate(savedInstanceState);
        requestData();
        BiUtil.saveBiInfo(XL_PatientInfoAActivity.class, "1", "", "", "", false);
        mNewMedicalReceiver = new NewMedicalReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000, NewMedicalReceiver.NEW_MEDICAL_ACTION, mNewMedicalReceiver);
        UtilBroadcast.myRegisterReceiver(this, 1000, CommonConfig.DEL_PATIENT_ACTION, delPatientReceiver = new DelPatientReceiver());
    }

    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_PatientInfoAActivity.class);
    }


    // 无网络时,点击屏幕后回调的方法
    @Override
    public void onNetRefresh() {
        requestData();
    }

    public void initData() {
        Intent intent = getIntent();
        xc_chatModel = (XC_ChatModel) intent.getSerializableExtra(CommonConfig.CHAT_PARAMS_MODEL);
        if (xc_chatModel != null) {
            mPatientId = xc_chatModel.getUserPatient().getPatientId();
        } else {
            xc_chatModel = new XC_ChatModel();
        }
        String pPatientId = intent.getStringExtra(CommonConfig.PATIENT_ID);
        if (!TextUtils.isEmpty(pPatientId)) {
            mPatientId = pPatientId;
        }
        if (!TextUtils.isEmpty(mPatientId)) {
            UtilBasicInfo.getAllBasicInfo(xc_chatModel, mPatientId, UtilSP.getUserId());
        }
    }

    /**
     * 初始化头部信息
     */
    public void initTitle() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "病历");
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleRight(true, R.mipmap.chat_setting_menu);
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));
    }

    @Override
    public void initWidgets() {
        initTitle();
        xc_id_model_no_net = getViewById(R.id.xc_id_model_no_net);
        sx_id_medical_records_list = getViewById(R.id.sx_id_medical_records_list);
        sx_id_medical_records_list.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
        ILoadingLayout startLabels = sx_id_medical_records_list
                .getLoadingLayoutProxy(true, false);
        startLabels.setPullLabel("下拉刷新...");
        startLabels.setRefreshingLabel("正在载入...");
        startLabels.setReleaseLabel("放开刷新...");

        ILoadingLayout endLabels = sx_id_medical_records_list.getLoadingLayoutProxy(
                false, true);
        endLabels.setPullLabel("上拉刷新...");
        endLabels.setRefreshingLabel("正在载入...");
        endLabels.setReleaseLabel("放开刷新...");
        sx_id_medical_records_list.getRefreshableView().setSelector(new ColorDrawable(Color.TRANSPARENT));

        View patientView = getLayoutInflater().from(XL_PatientInfoAActivity.this).inflate(R.layout.xl_item_patientinfo, null);
        initHeaderView(patientView);

        xl_personinfo_btn_chat = getViewById(R.id.xl_personinfo_btn_chat);
        sx_id_add_medical_rl = getViewById(R.id.xl_add_record);
        AbsListView.LayoutParams layoutParams = new AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT, AbsListView.LayoutParams.WRAP_CONTENT);
        patientView.setLayoutParams(layoutParams);
        lv = sx_id_medical_records_list.getRefreshableView();
        lv.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (firstVisibleItem == 0) {
                    sx_id_medical_records_list.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
                } else {
                    if (mList.size() < UtilString.toInt(parse2MedicalRecordsModel.getTotalCount())) {
                        sx_id_medical_records_list.setMode(PullToRefreshBase.Mode.PULL_FROM_END);
                    } else {
                        sx_id_medical_records_list.setMode(PullToRefreshBase.Mode.DISABLED);
                    }
                }
            }

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

            }

        });
        lv.addHeaderView(patientView);
        parse2MedicalRecordsModel = new DrRecordPageVO();
        mSX_MedicalRecordsAdapter = new SX_MedicalRecordsAdapter(XL_PatientInfoAActivity.this, mList,xc_chatModel);
        lv.setAdapter(mSX_MedicalRecordsAdapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (isFastClick()) {
                    return;
                }
                if (i > 1) {
                    DrRecordVOBean bean = mList.get(i -2);
                    if("2".equals(bean.getCaseType())){
                        PrescriptionVOBean preBean = (PrescriptionVOBean) bean.getMdicalRecordVO();
                        ToJumpHelp.toJumpRecommendDetailActivity(XL_PatientInfoAActivity.this,preBean.getRecommendId(),xc_chatModel.getUserPatient(),"2");
                    }else if("7".equals(bean.getCaseType())){
                        DrCaseVOBean drBean = (DrCaseVOBean) bean.getMdicalRecordVO();
                        mSX_MedicalRecordsAdapter.requestRecommendInfo(XL_PatientInfoAActivity.this,bean,drBean.getPrescriptionVO().getRecommendId(),bean.getPatientId(),xc_chatModel,1);
                    } else{
                        ToJumpHelp.toJumpMedicalRecordDetailActivity(XL_PatientInfoAActivity.this,bean,true);
                    }

                }
            }
        });
    }

    private void initHeaderView(View patientView) {
        xl_patientinfo_ic = (XCRoundedImageView) patientView.findViewById(R.id.xl_patientinfo_ic);
        xl_patientinfo_tv_name = (TextView) patientView.findViewById(R.id.xl_patientinfo_tv_name);
        xl_patientinfo_tv_sex = (TextView) patientView.findViewById(R.id.xl_patientinfo_tv_sex);
        xl_patientinfo_tv_nick_name = (TextView) patientView.findViewById(R.id.xl_patientinfo_tv_nick_name);
        xl_patientinfo_tv_age = (TextView) patientView.findViewById(R.id.xl_patientinfo_tv_age);
        xl_patientinfo_tv_phone = (TextView) patientView.findViewById(R.id.xl_patientinfo_tv_phone);
        xl_patientinfo_tv_other = (TextView) patientView.findViewById(R.id.xl_patientinfo_tv_other);
        tv_consult_fee = (TextView) patientView.findViewById(R.id.tv_consult_fee);
        patientinfo_layout = (RelativeLayout) patientView.findViewById(R.id.xl_patientinfo_layout);
        grouplayout = (LinearLayout) patientView.findViewById(R.id.xl_patient_group_layout);
        groupName = (TextView) patientView.findViewById(R.id.xl_patientinfo_tv_group_name);
        nicknameLayout = (LinearLayout) patientView.findViewById(R.id.nickname_layout);
        phoneLayout = (LinearLayout) patientView.findViewById(R.id.phone_layout);
        areaLayout = (LinearLayout) patientView.findViewById(R.id.area_layout);
        mScreentv = (TextView) patientView.findViewById(R.id.screen_tv);
        screen_layout = (LinearLayout) patientView.findViewById(R.id.screen_layout);
        emptyLayout = (LinearLayout) patientView.findViewById(R.id.empty_layout);
    }

    @Override
    public void listeners() {
        patientinfo_layout.setOnClickListener(this);
        grouplayout.setOnClickListener(this);
        xl_patientinfo_ic.setOnClickListener(this);
        xl_personinfo_btn_chat.setOnClickListener(this);
        sx_id_add_medical_rl.setOnClickListener(this);
        xl_patientinfo_tv_phone.setOnClickListener(this);
        mScreentv.setOnClickListener(this);
        titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (UtilChat.isTwoOnclick()){
                    return;
                }
                setPFActivityResult();
            }
        });
        titlebar.getXc_id_titlebar_right_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (UtilChat.isTwoOnclick()){
                    return;
                }
                if (xc_chatModel != null) {
                    ToJumpHelp.toJumpChatSettingDialogActivity(XL_PatientInfoAActivity.this, xc_chatModel, CommonConfig.CHAT_SETTING_FROM_PATIENT);
                }
            }
        });
        sx_id_medical_records_list.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                getMedicalRecordsList(mPatientId, xc_chatModel.getType(), "1", "10", true, value);

            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                if (null != parse2MedicalRecordsModel) {
                    int num = Integer.valueOf(parse2MedicalRecordsModel.getPageNo());
                    getMedicalRecordsList(mPatientId, xc_chatModel.getType(), String.valueOf(num + 1), "10", false, value);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    /**
     * 请求患者资料接口
     */
    private void requestData() {
        if (TextUtils.isEmpty(mPatientId)) {
            shortToast("患者信息有误!");
            return;
        }
        RequestParams params = new RequestParams();
        params.put("patientId", mPatientId);
        XCHttpAsyn.postAsyn(XL_PatientInfoAActivity.this, AppConfig.getHostUrl(patient_detail), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                xc_id_model_no_net.setVisibility(View.GONE);
                if (result_boolean) {
                    Parse2PatientBean.parsePatientBean(xc_chatModel, result_bean);
                    petientBasicBeanFlag = Parse2PatientBasicBean.parsePatientBasic(result_bean, true);
                    List<XCJsonBean> result_list = result_bean.getList("data");

                    // 每次更新数据库
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            JS_ChatListDB.getInstance(XL_PatientInfoAActivity.this, UtilSP.getUserId()).updatePatientInfo(xc_chatModel);
                        }
                    }).start();

                    //update by cyr on 2017-6-23 通知更新患者列表显示 start
                    Intent intent = new Intent();
                    intent.putExtra(XD_SetPersonalConsultingFeesActivity.PATIENT_INGO, xc_chatModel);
                    intent.setAction(JS_MainActivity.ChatNewPatientReceiver.CHAT_NEW_PATIENT_ACTION);
                    context.sendBroadcast(intent);
                    //update by cyr on 2017-6-23 通知更新患者列表显示 end

                    showPatientInfo();
                    showPatientGroup(result_list);
                    getRelationList(result_list);
//                    showPatientCondition();
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                xc_id_model_no_net.setVisibility(View.VISIBLE);
            }

            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(XL_PatientInfoAActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }

        });
    }

    /**
     * 显示患者资料
     */
    private void showPatientInfo() {
        if (xc_chatModel == null) {
            return;
        }
        UserPatient userPatient = xc_chatModel.getUserPatient();
        String name = userPatient.getPatientName();
        String memoName = userPatient.getPatientMemoName();
        String gender = userPatient.getPatientGender();
        String patientIcon = userPatient.getPatientImgHead();
        String phone = userPatient.getPatientPhone();

        xl_patientinfo_tv_name.setText(TextUtils.isEmpty(memoName) ? "" : memoName);
        xl_patientinfo_tv_name.setHint(TextUtils.isEmpty(memoName) ? "姓名未填写" : "");
        if (!TextUtils.isEmpty(name)) {
            nicknameLayout.setVisibility(View.VISIBLE);
            xl_patientinfo_tv_nick_name.setText(name);
        } else {
            nicknameLayout.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(phone)) {
            phoneLayout.setVisibility(View.VISIBLE);
            xl_patientinfo_tv_phone.setText(phone);
        } else {
            phoneLayout.setVisibility(View.GONE);
        }
        //初始化患者性别显示
        showGender(gender);
        //初始化患者年龄和所在城市显示
        initAgeAndCity(userPatient.getPatientAge(), userPatient.getCityName());
        //初始化患者头像显示
        XCApplication.displayImage(patientIcon, xl_patientinfo_ic, options1);
        //初始化患者图文咨询诊金显示
//        initConsultCost(xc_chatModel.getPayAmount());
    }

    /**
     * 初始化性别
     *
     * @param gender 性别
     */
    private void showGender(String gender) {
        if (TextUtils.isEmpty(gender)) {
            return;
        }
        gender = gender.trim();
        Drawable drawable;
        if (CommonConfig.GENDER_MALE.equals(gender)) {
            drawable = ContextCompat.getDrawable(this, R.mipmap.icon_patient_man);
//            xl_patientinfo_tv_sex.setText("男");
        } else if (CommonConfig.GENDER_FEMALE.equals(gender)) {
            drawable = ContextCompat.getDrawable(this, R.mipmap.icon_patient_women);
//            xl_patientinfo_tv_sex.setText("女");
        } else {
            return;
        }
        drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
        xl_patientinfo_tv_name.setCompoundDrawables(null, null, drawable, null);
    }

    /**
     * 初始化年龄和城市
     *
     * @param age      患者年龄
     * @param cityName 患者所在城市
     */
    public void initAgeAndCity(String age, String cityName) {
        if (!TextUtils.isEmpty(age)) {
            age = age + "岁  ";
        } else {
            age = "";
        }
        xl_patientinfo_tv_age.setText(age);
        if (!TextUtils.isEmpty(cityName)) {
            areaLayout.setVisibility(View.VISIBLE);
            xl_patientinfo_tv_other.setText(cityName);
        } else {
            areaLayout.setVisibility(View.GONE);
        }
    }

    /**
     * 初始化图文咨询费标识 ,价格为0-1000元的整数
     *
     * @param payAmount 咨询价格
     */
    public void initConsultCost(String payAmount) {
        long consultCost;
        try {
            consultCost = Long.parseLong(payAmount);
        } catch (Exception e) {
            consultCost = 0;
        }
        if (consultCost >= 100) {
            tv_consult_fee.setText("咨询费" + consultCost / 100 + "元");
            tv_consult_fee.setVisibility(View.VISIBLE);
        } else {
            tv_consult_fee.setVisibility(View.GONE);
        }
    }

    /**
     * 展示患者分组
     *
     * @param result_list
     */
    private void showPatientGroup(List<XCJsonBean> result_list) {
        if (UtilCollection.isBlank(result_list)) {
            return;
        }
        groupName_list.clear();
        List<XCJsonBean> patient_group = result_list.get(0).getList("patientGroupList");
        if (patient_group != null && patient_group.size() > 0) {
            StringBuilder sb = new StringBuilder("");
            for (int i = 0; i < patient_group.size(); i++) {
                String group = patient_group.get(i).getString("groupName");
                groupName_list.add(group);
                if (!TextUtils.isEmpty(group)) {
                    sb.append(group);
                    if (i < patient_group.size() - 1) {
                        sb.append("，");
                    }
                }
            }
            groupName.setText(sb.toString());
            groupName.setTextColor(getResources().getColor(R.color.c_444444));
        } else {
            groupName.setText("选择分组");
            groupName.setTextColor(getResources().getColor(R.color.c_gray_cccccc));
        }
    }

    /**
     * 获取筛选条件
     */
    private void getRelationList(List<XCJsonBean> result_list) {
        if (UtilCollection.isBlank(result_list)) {
            return;
        }
        try {
            List<XCJsonBean> list = result_list.get(0).getList("relationList");
            if (list != null && list.size() > 0) {
                List<String> relationList = new ArrayList<>();
                List<MemberVOBean> memberList = new ArrayList<>();
                for (int i = 0; i < list.size(); i++) {
                    String name = list.get(i).getString("name");
                    relationList.add(name);
                    MemberVOBean memberVOBean = new MemberVOBean();
                    memberVOBean.setName(name);
                    memberVOBean.setValue(list.get(i).getString("value"));
                    memberList.add(memberVOBean);
                }
                value = "-1";
                initScreenDialog(relationList, memberList);
                getMedicalRecordsList(mPatientId, xc_chatModel.getType(), "1", "10", true, value);
            } else {
                screen_layout.setVisibility(View.GONE);
            }
        } catch (Exception e) {

        }
    }


    /**
     * 初始化筛选条件选择器
     */
    private void initScreenDialog(final List<String> relationList, final List<MemberVOBean> memberVOBeanList) {
        mScreenWidth = UtilScreen.getScreenWidthPx(this);
        mScreenDialog = new ConfirmDialog(this, mScreenWidth, R.layout
                .dialog_roll_select, R.style.xc_s_dialog);
        mScreenDialog.setCanceledOnTouchOutside(false);
        Window window = mScreenDialog.getWindow();
        window.setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        mWheelView = (WheelView) mScreenDialog.findViewById(R.id.wheelview);
        tv_set_screen_cancel = (TextView) mScreenDialog.findViewById(R.id.tv_set_price_cancel);
        tv_set_screen_confirm = (TextView) mScreenDialog.findViewById(R.id.tv_set_price_confirm);
        mWheelView.setCyclic(false);//不循环
        mWheelView.setAdapter(new ArrayTextWheelAdapter(relationList));
        tv_set_screen_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mScreenDialog.dismiss();
            }
        });
        tv_set_screen_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String member = relationList.get(mWheelView.getCurrentItem());
                mScreentv.setText(member);
                for (int i = 0; i < relationList.size(); i++) {
                    if (relationList.get(i).equals(member)) {
                        value = memberVOBeanList.get(i).getValue();
                        break;
                    }
                }
                getMedicalRecordsList(mPatientId, xc_chatModel.getType(), "1", "10", true, value);
                mScreenDialog.dismiss();
            }
        });
        mScreenDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                String screen = mScreentv.getText().toString();
                for (int i = 0; i < relationList.size(); i++) {
                    if (screen.equals(relationList.get(i))) {
                        mWheelView.setCurrentItem(i);
                    }
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (UtilChat.isTwoOnclick()){
            return;
        }
        if (mPopWindow != null && mPopWindow.isShowing()) {
            mPopWindow.dismiss();
        } else {
            setPFActivityResult();
        }
    }

    /**
     * 监听返回键，返回到聊天设置页面，需要带回去显示名
     */
    private void setPFActivityResult() {
        Intent intent = new Intent();
        if (xc_chatModel != null) {
            String name = Utils.getPatientDisplayName(xc_chatModel.getUserPatient().getPatientMemoName(), xc_chatModel.getUserPatient().getPatientName());
            intent.putExtra(PF_ChatSetting.PATIENT_NAME, name);
        }
        setResult(RESULT_OK, intent);
        finish();
    }

    /**
     * 显示头像
     *
     * @param url
     */
    private void showHeadUrl(String url) {
        if (options1 == null) {
            options1 = XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default);
        }
        if (fragment == null) {
            fragment = new XCViewPagerFragment();
            fragment.setDefaultSelectedIndex(1);
            ArrayList<String> list = new ArrayList<>();
            list.add(url);
            fragment.setData(list);
            fragment.setIsShowIndex(false);
            fragment.setOnImageClickListener(new XCViewPagerFragment.OnImageClickListener() {
                @Override
                public void onImageClickListener(int position) {
                    if (fragment != null) {
                        removeFragment(fragment);
                    }
                }
            });
            fragment.setOnLoadImageListener(new XCViewPagerFragment.OnLoadImage() {
                @Override
                public void onLoadImage(ImageView imageview, String url) {

                    XCApplication.displayImage(url, imageview, options1);
                }
            });
        }
        addFragment(R.id.xc_id_model_layout, fragment, fragment.getClass().getSimpleName(), true);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        Intent intent;
        switch (v.getId()) {
            case R.id.xl_patientinfo_layout:
                // V2.6.5以后没有备注名时，也不传昵称
                intent = new Intent(XL_PatientInfoAActivity.this, PatientPersonInfoActivity.class);
                intent.putExtra(CommonConfig.PATIENT_ID, mPatientId);
                intent.putExtra(CommonConfig.CHAT_PARAMS_MODEL, xc_chatModel);
                myStartActivityForResult(intent, REQ_CODE_PERSONINFO);
                break;
            case R.id.xl_patient_group_layout:
                intent = new Intent();
                intent.setClass(XL_PatientInfoAActivity.this, PatientGroupActivity.class);
                intent.putExtra(CommonConfig.PATIENT_ID, mPatientId);
                myStartActivityForResult(intent, REQ_CODE_GROUPLIST);
                break;
            case R.id.xl_patient_conditon_layout:
                intent = new Intent(XL_PatientInfoAActivity.this, PatientInfoBasicEditActivity.class);
                intent.putExtra(CommonConfig.PATIENT_ID, mPatientId);
                intent.putExtra(PatientInfoBasicEditActivity.PATIENT_INFO_BASIC, petientBasicBeanFlag);
                myStartActivityForResult(intent, REQ_CODE_PATIENT_BASIC_INFO);
                break;
            case R.id.xl_patientinfo_ic: //显示大头像
                if (xc_chatModel != null) {
                    showHeadUrl(xc_chatModel.getUserPatient().getPatientImgHead());
                }
                break;
            case R.id.xl_patientinfo_tv_phone:
                UtilAppToSystemApp.toPhone(this, xl_patientinfo_tv_phone.getText().toString());
                break;
            case R.id.screen_tv:
                mScreenDialog.show();
                break;
            case R.id.xl_personinfo_btn_chat: //进入聊天
                xl_personinfo_btn_chat.setEnabled(false);
                UtilChat.launchChatDetail(this, mPatientId, new UtilChat.LaunchChatDetailListener() {
                    @Override
                    public void onError() {
                        shortToast("网络错误,不能发送消息,请您稍后重试!");
                    }

                    @Override
                    public void onFinish() {
                        xl_personinfo_btn_chat.setEnabled(true);
                    }
                });
                break;
            case R.id.xl_add_record:
                ToJumpHelp.toJumpEditMedicalRecordActivity(XL_PatientInfoAActivity.this, mPatientId,5);
                break;
            default:
                break;
        }
    }


    /**
     * 获取诊疗记录列表
     *
     * @param patientId 患者id
     * @param type      类型
     * @param page      页码
     * @param number    每页数量
     * @param isFirst   是否为第一次获取
     */
    private void getMedicalRecordsList(String patientId, String type, String page, String number, final boolean isFirst, final String value) {
        RequestParams params = new RequestParams();
        params.put("patientId", patientId);
//        params.put("type", type);
        params.put("page", page);
        params.put("num", number);
        params.put("relation", value);

        XCHttpAsyn.postAsyn(this, AppConfig.getRecordUrl(AppConfig.record_list), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                xc_id_model_no_net.setVisibility(View.GONE);
                MultiTypeJsonParser<Attribute> multiTypeJsonParser = new MultiTypeJsonParser.Builder<Attribute>()
                        .registerTypeElementName("caseType")
                        .registerTargetClass(Attribute.class)
                        .registerTargetUpperLevelClass(DrRecordVOBean.class)
                        .registerTypeElementValueWithClassType(CommonConfig.MEDICAL_RECORD, RecordVOBean.class)
                        .registerTypeElementValueWithClassType(CommonConfig.MEDICAL_PATIENT_OLD, PatientOldCaseVOBean.class)
                        .registerTypeElementValueWithClassType(CommonConfig.MEDICAL_PRESCRIPTION, PrescriptionVOBean.class)
                        .registerTypeElementValueWithClassType(CommonConfig.MEDICAL_PATIENT_NEW, PatientCaseVOBean.class)
                        .registerTypeElementValueWithClassType(CommonConfig.MEDICAL_DOCTOR, DrCaseVOBean.class)
                        .registerTypeElementValueWithClassType(CommonConfig.MEDICAL_CONDITION_RECORD, RecordVOBean.class)
                        .registerTypeElementValueWithClassType(CommonConfig.MEDICAL_CONDITION_PRESCRIPTION, PrescriptionVOBean.class)
                        .registerTypeElementValueWithClassType(CommonConfig.MEDICAL_DOCTOR_PRESCRIPTION, DrCaseVOBean.class)
                        .registerTypeElementValueWithClassType(CommonConfig.MEDICAL_CONSULT_ROOM, DrCaseVOBean.class)
                        .build();

                DataInfoWithType responseBean = multiTypeJsonParser.fromJson(new String(arg2), DataInfoWithType.class);
                if (responseBean == null || !GeneralReqExceptionProcess.checkCode(XL_PatientInfoAActivity.this, String.valueOf(responseBean.code), responseBean.msg)) {
                    return;
                }
                //如果含有未知的type类型，解析的集合中包含null，过滤一下
                List<DrRecordPageVO> data = responseBean.getList();
                data.get(0).setResult(ListItemFilter.filterNullElement(data.get(0).getResult()));
                parse2MedicalRecordsModel = responseBean.getList().get(0);
                if (isFirst) {
                    if (parse2MedicalRecordsModel != null && parse2MedicalRecordsModel.getResult().size() > 0) {
                        mList.clear();
                    }
                }
                if (parse2MedicalRecordsModel.getResult() != null && parse2MedicalRecordsModel.getResult().size() > 0) {
                    mList.addAll(parse2MedicalRecordsModel.getResult());
                }
                sx_id_medical_records_list.onRefreshComplete();
                if("-1".equals(value) && mList.size() == 0){
                    screen_layout.setVisibility(View.GONE);
                }else {
                    screen_layout.setVisibility(View.VISIBLE);
                }
                if (mList.size() > 0) {
                    emptyLayout.setVisibility(View.GONE);
                } else {
                    emptyLayout.setVisibility(View.VISIBLE);
                }
                //如果不够一页，不显示下拉加载
                if (mList.size() >= UtilString.toInt(parse2MedicalRecordsModel.getTotalCount())) {
                    sx_id_medical_records_list.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
                } else {
                    sx_id_medical_records_list.setMode(PullToRefreshBase.Mode.BOTH);
                }
                mSX_MedicalRecordsAdapter.notifyDataSetChanged();
                if (isFirst) {
                    lv.setSelection(0);
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                xc_id_model_no_net.setVisibility(View.VISIBLE);
            }

            public void onFinish() {
                super.onFinish();
                if (!GeneralReqExceptionProcess.checkCode(XL_PatientInfoAActivity.this, getCode(), getMsg())) {
                    screen_layout.setVisibility(View.GONE);
                }
                if (sx_id_medical_records_list != null) {
                    sx_id_medical_records_list.onRefreshComplete();
                }
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(XL_PatientInfoAActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }


    /**
     * 编辑诊疗记录
     *
     * @param img
     * @param i
     */
    private void showPopupWindow(View img, final int i) {
        View view = LayoutInflater.from(XL_PatientInfoAActivity.this).inflate(R.layout.edit_layout, null);
        //防止华为手机popwindow背景颜色透明
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        mPopWindow = new PopupWindow(view, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        TextView edit = (TextView) view.findViewById(R.id.edit);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPopWindow.dismiss();
                Intent intent = new Intent();
                intent.putExtra(CommonConfig.CHAT_PARAMS_MODEL, xc_chatModel);
                intent.putExtra(CommonConfig.PATIENT_MEDICALRECORD, parse2MedicalRecordsModel.getResult().get(i));
                intent.setClass(XL_PatientInfoAActivity.this, SX_AddMedicalRecordActivity.class);
                myStartActivityForResult(intent, REQ_CODE_MEDICAL);
            }
        });
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 0.4f;
        getWindow().setAttributes(lp);
        mPopWindow.setTouchable(true);
        mPopWindow.setOutsideTouchable(true);
        mPopWindow.setFocusable(true);
        mPopWindow.setBackgroundDrawable(new BitmapDrawable());
        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int popupWidth = view.getMeasuredWidth();
        int popupHeight = view.getMeasuredHeight();
        //获取需要在其上方显示的控件的位置信息
        int[] location = new int[2];
        img.getLocationOnScreen(location);
        //在控件上方显示
        mPopWindow.showAtLocation(img, Gravity.NO_GRAVITY, (location[0] + img.getWidth()) - popupWidth, location[1] - popupHeight);
        mPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            public void onDismiss() {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.alpha = 1f;
                getWindow().setAttributes(lp);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (RESULT_OK == resultCode) {
            switch (requestCode) {
                case REQ_CODE_PERSONINFO:
                    requestData();
                    break;
                case REQ_CODE_GROUPLIST:
                    requestData();
                    break;
                case REQ_CODE_PATIENT_BASIC_INFO:
                    requestData();
                    break;
                case REQ_CODE_MEDICAL:
                    getMedicalRecordsList(mPatientId, xc_chatModel.getType(), "1", "10", true, value);
                    break;
            }
        }
    }

    /**
     * 接受新诊疗记录的广播
     */
    public class NewMedicalReceiver extends BroadcastReceiver {
        public final static String NEW_MEDICAL_ACTION = "new_medical_action";

        public void onReceive(Context context, Intent intent) {
            getMedicalRecordsList(mPatientId, xc_chatModel.getType(), "1", "10", true, value);
        }
    }
    /**
     * add by mym on 2018/7/2
     * 删除患者的通知
     */
    public class DelPatientReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            myFinish();
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        UtilBroadcast.myUnregisterReceiver(this, mNewMedicalReceiver);
        UtilBroadcast.myUnregisterReceiver(this, delPatientReceiver);
    }
}
