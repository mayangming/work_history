package com.qlk.ymz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;

/**
 * LoginAndRegisterAcitivity
 * 3.0石榴云医注册登录页面
 * @author songxin on 2018/7/30.
 * @version 3.0.0
 */
public class LoginAndRegisterActivity extends DBActivity{
    /** 跳转到登录页按钮*/
    private Button bt_jump_to_login;
    /** 跳转到注册页按钮*/
    private Button bt_jump_to_register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_login_and_register);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onStart() {
        super.onStart();
        UtilInputMethod.hiddenInputMethod(LoginAndRegisterActivity.this);
        //created by songxin,date：2018-10-29,about：bi,begin
        BiUtil.savePid(LoginActivity.class);
        //created by songxin,date：2018-10-29,about：bi,end
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        bt_jump_to_login = getViewById(R.id.bt_jump_to_login);
        bt_jump_to_register = getViewById(R.id.bt_jump_to_register);
    }

    @Override
    public void listeners() {
        bt_jump_to_login.setOnClickListener(this);
        bt_jump_to_register.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.bt_jump_to_login:
                myStartActivity(LoginActivity.class);
                break;
            case R.id.bt_jump_to_register:
                myStartActivity(SX_RegisterActivityV2.class);
                break;
        }
    }

    @Override
    public void onBackPressed() {
        XCApplication.AppExit();
    }
}
