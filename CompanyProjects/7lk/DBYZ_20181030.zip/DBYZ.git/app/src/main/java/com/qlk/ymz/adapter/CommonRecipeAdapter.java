package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.RecipeBean;
import com.qlk.ymz.view.SwipeLayout.PullSwipeLayoutAdapter;
import com.qlk.ymz.view.SwipeLayout.SwipeOnTouchListener;
import com.qlk.ymz.view.SwipeLayout.SwipeViewHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2017/12/14.
 */

public class CommonRecipeAdapter extends PullSwipeLayoutAdapter<RecipeBean> {

    private CommonRecipeActionListener mCommonRecipeActionListener;
    //是否是推荐路径下
    private boolean isRecom = false;
    /**
     * 构造函数
     *
     * @param context
     * @param contentViewResourceId
     * @param actionViewResourceId
     * @param itemWidth
     * @param contentWidth
     * @param list
     */
    public CommonRecipeAdapter(Context context, int contentViewResourceId, int actionViewResourceId, int itemWidth, int contentWidth, List<RecipeBean> list) {
        super(context, contentViewResourceId, actionViewResourceId, itemWidth, contentWidth, list);
    }

    public void setRecom(boolean recom) {
        isRecom = recom;
    }

    @Override
    public void setContentView(View contentView, final int position, HorizontalScrollView parent, SwipeViewHolder holder, SwipeOnTouchListener swipeOnTouchListener) {
        ContentViewHolder viewHolder = ContentViewHolder.getViewHolder(contentView);

        RecipeBean recipeBean = list.get(position);//处方信息
        viewHolder.tv_recipe_diagnosis.setText("临床诊断: " + getDiagnosisStr(recipeBean
                .getDiagnosisList()));
        ArrayList<DrugBean> drugInfoBeans = recipeBean.getDrugBeans();
        viewHolder.tv_medicine_kind.setText("共" + drugInfoBeans.size() + "种药品");
        if (drugInfoBeans.size() >= 1) {
            viewHolder.tv_first_medicine_name.setText(drugInfoBeans.get(0).getRecomName());
            viewHolder.tv_first_medicine_num.setText("×" + drugInfoBeans.get(0).getQuantity());
        }
        if (drugInfoBeans.size() >= 2) {
            viewHolder.tv_second_medicine_name.setText(drugInfoBeans.get(1).getRecomName());
            viewHolder.tv_second_medicine_num.setText("×" + drugInfoBeans.get(1).getQuantity());
        }
        if (drugInfoBeans.size() == 1) {
            viewHolder.ll_first_medicine.setVisibility(View.VISIBLE);
            viewHolder.ll_second_medicine.setVisibility(View.GONE);
            viewHolder.tv_ellipsis.setVisibility(View.GONE);
        } else if (drugInfoBeans.size() == 0) {
            viewHolder.ll_first_medicine.setVisibility(View.GONE);
            viewHolder.ll_second_medicine.setVisibility(View.GONE);
            viewHolder.tv_ellipsis.setVisibility(View.GONE);
        } else if (drugInfoBeans.size() == 2) {
            viewHolder.ll_first_medicine.setVisibility(View.VISIBLE);
            viewHolder.ll_second_medicine.setVisibility(View.VISIBLE);
            viewHolder.tv_ellipsis.setVisibility(View.GONE);
        } else if (drugInfoBeans.size() > 2) {
            viewHolder.ll_first_medicine.setVisibility(View.VISIBLE);
            viewHolder.ll_second_medicine.setVisibility(View.VISIBLE);
            viewHolder.tv_ellipsis.setVisibility(View.VISIBLE);
        }

        if(isRecom){
            viewHolder.tv_use_recipe.setVisibility(View.VISIBLE);
        }else {
            viewHolder.tv_use_recipe.setVisibility(View.GONE);
        }
        viewHolder.tv_use_recipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCommonRecipeActionListener != null) {
                    mCommonRecipeActionListener.useRecipe(position);
                }
            }
        });
        viewHolder.ll_common_recipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCommonRecipeActionListener != null) {
                    mCommonRecipeActionListener.onItemClick(position);
                }
            }
        });
    }

    @Override
    public void setActionView(View actionView, final int position, HorizontalScrollView parent) {
        ActionViewHolder viewHolder = ActionViewHolder.getViewHolder(actionView);
        viewHolder.tv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCommonRecipeActionListener != null) {
                    mCommonRecipeActionListener.delete(position);
                }
            }
        });
    }

    public void setCommonRecipeActionListener(CommonRecipeActionListener commonRecipeActionListener) {
        mCommonRecipeActionListener = commonRecipeActionListener;
    }

    /**
     * 获取临床诊断str
     */
    private String getDiagnosisStr(List<DiagnoseBean> diagnoseBeans) {
        String diagnosisStr = "";
        for (int i = 0; i < diagnoseBeans.size(); i++) {
            if (i == diagnoseBeans.size() - 1) {
                diagnosisStr = diagnosisStr + diagnoseBeans.get(i).name;
            } else {
                diagnosisStr = diagnosisStr + diagnoseBeans.get(i).name + ",";
            }
        }
        if(TextUtils.isEmpty(diagnosisStr)){
            diagnosisStr = "无";
        }
        return diagnosisStr;
    }

    static class ContentViewHolder {
        //整个item
        LinearLayout ll_common_recipe;
        //诊断信息
        TextView tv_recipe_diagnosis;
        //药品种类
        TextView tv_medicine_kind;
        //第一个药
        LinearLayout ll_first_medicine;
        //第一个药名
        TextView tv_first_medicine_name;
        //第一个药数量
        TextView tv_first_medicine_num;
        //第二个药
        LinearLayout ll_second_medicine;
        //第二个药名
        TextView tv_second_medicine_name;
        //第二个药数量
        TextView tv_second_medicine_num;
        //省略号
        TextView tv_ellipsis;
        //使用常用处方
        TextView tv_use_recipe;


        public ContentViewHolder(View convertView) {
            ll_common_recipe = (LinearLayout) convertView.findViewById(R.id.ll_common_recipe);
            tv_recipe_diagnosis = (TextView) convertView.findViewById(R.id.tv_recipe_diagnosis);
            tv_medicine_kind = (TextView) convertView.findViewById(R.id.tv_medicine_kind);
            tv_first_medicine_name = (TextView) convertView.findViewById(R.id.tv_first_medicine_name);
            tv_first_medicine_num = (TextView) convertView.findViewById(R.id.tv_first_medicine_num);
            ll_second_medicine = (LinearLayout) convertView.findViewById(R.id.ll_second_medicine);
            ll_first_medicine = (LinearLayout) convertView.findViewById(R.id.ll_first_medicine);
            tv_second_medicine_name = (TextView) convertView.findViewById(R.id.tv_second_medicine_name);
            tv_second_medicine_num = (TextView) convertView.findViewById(R.id.tv_second_medicine_num);
            tv_ellipsis = (TextView) convertView.findViewById(R.id.tv_ellipsis);
            tv_use_recipe = (TextView) convertView.findViewById(R.id.tv_use_recipe);
        }

        public static ContentViewHolder getViewHolder(View convertview) {
            ContentViewHolder holder = (ContentViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new ContentViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }

    static class ActionViewHolder {
        //删除
        TextView tv_delete;

        public ActionViewHolder(View convertView) {
            tv_delete = (TextView) convertView.findViewById(R.id.tv_delete);
        }

        public static ActionViewHolder getViewHolder(View convertview) {
            ActionViewHolder holder = (ActionViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new ActionViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }

    public interface CommonRecipeActionListener {
        void delete(int position);

        void useRecipe(int position);

        void onItemClick(int position);
    }
}
