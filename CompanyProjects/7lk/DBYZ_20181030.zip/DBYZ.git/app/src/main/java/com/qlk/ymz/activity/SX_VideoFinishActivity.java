package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.VideoFinishBean;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilVideo;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * SX_VideoFinishActivity
 * 视频结束页面（dialog）
 * @author songxin on 2016/7/24.
 * @version 2.6.0
 */
public class SX_VideoFinishActivity extends DBActivity {
    /** 视频时间，用时X分XX秒*/
    private TextView sx_id_video_time_consuming;
    /** 视频花费*/
    private TextView sx_id_video_spend;
    /** 视频结束后填写诊疗记录*/
    private LinearLayout sx_id_write_records_rl;
    /** 视频结束后推荐用药*/
    private LinearLayout sx_id_recommended_medication_rl;
    /** 视频结束后再次发起视频*/
    private LinearLayout sx_id_send_video_again_rl;
    /** 分割线*/
    private View view2;
    /** 关闭按钮*/
    private ImageView sx_id_close;
    /** 结束信息model*/
    private VideoFinishBean videoFinishBean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_video_finish);
        super.onCreate(savedInstanceState);
        initData();
        sx_id_video_spend.setText(videoFinishBean.getAmount());
        try {
            printi("http","videoFinishBean.getOpenSecond()------------->"+videoFinishBean.getOpenSecond());
            sx_id_video_time_consuming.setText(UtilDate.formatTime(Long.valueOf(videoFinishBean.getOpenSecond())));
        }catch (Exception e){
            e.printStackTrace();
        }
        setWidgetStatus();

    }

    /** created by songxin,date：2017-4-10,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_VideoFinishActivity.class);
    }

    /** created by songxin,date：2016-4-10,about：bi,end */

    @Override
    public void initWidgets() {
        sx_id_video_time_consuming = getViewById(R.id.sx_id_video_time_consuming);
        sx_id_video_spend = getViewById(R.id.sx_id_video_spend);
        sx_id_write_records_rl = getViewById(R.id.sx_id_write_records_rl);
        sx_id_recommended_medication_rl = getViewById(R.id.sx_id_recommended_medication_rl);
        sx_id_send_video_again_rl = getViewById(R.id.sx_id_send_video_again_rl);
        view2 = getViewById(R.id.view2);
        sx_id_close = getViewById(R.id.sx_id_close);
    }

    @Override
    public void listeners() {
        sx_id_write_records_rl.setOnClickListener(this);
        sx_id_recommended_medication_rl.setOnClickListener(this);
        sx_id_send_video_again_rl.setOnClickListener(this);
        sx_id_close.setOnClickListener(this);
    }

    private void initData(){
        videoFinishBean = (VideoFinishBean)getIntent().getSerializableExtra("videoFinish");
        if(null == videoFinishBean){
            videoFinishBean = new VideoFinishBean();
        }
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            //病情备注跳转
            case R.id.sx_id_write_records_rl:{
             /*   Intent intent = new Intent();
//                intent.setClass(SX_VideoFinishActivity.this,SX_AddMedicalRecordActivity.class);
                //start add by syy 2016/9/23 V2.7 跳转到诊疗记录列表页
                intent.setClass(SX_VideoFinishActivity.this,SX_MedicalRecordsActivity.class);
                //end add by syy 2016/9/23
                intent.putExtra(SX_MedicalRecordsActivity.COME_FROM_VIDEO_KEY,SX_MedicalRecordsActivity.TO_SEND_MEDICAL_RECORDMSG);
                intent.putExtra(CommonConfig.CHAT_PARAMS_MODEL,getParamsModel());
                startActivity(intent);*/
                toAddMedicRecordList(getParamsModel());//v2.8 add by xd 直接到添加诊疗记录页
                finish();
                break;
            }
            //推荐用药
            case R.id.sx_id_recommended_medication_rl:{
                //直接跳转到跟这个患者的聊天中，启动推荐用药
                UtilChat.launchChatDetail(this,getPatientId(),null,CommonConfig.COME_FROM_VIDEO);
                finish();
                break;
            }
            //再起发起视频
            case R.id.sx_id_send_video_again_rl:{
                //视频相关参数初始化，跳转
                if(!UtilString.isBlank(videoFinishBean.getPatientId())){
                    String[] patientids = videoFinishBean.getPatientId().split("_");
                    if(patientids.length == 2){
                        printi("http","videoFinishBean.getPatientId()--------->"+patientids[1]);
                        UtilVideo.requestVideo(SX_VideoFinishActivity.this,videoFinishBean.getReservationId(),patientids[1]);
                    }
                    finish();
                }
                break;
            }
            //关闭
            case R.id.sx_id_close:{
                finish();
                break;
            }
        }
    }

    private XC_ChatModel getParamsModel() {
        XC_ChatModel model = new XC_ChatModel();
        model.getUserPatient().setPatientId(getPatientId());
        model.getUserDoctor().setDoctorSelfId(UtilSP.getUserId());
        // 如果是从视频进入的，后台要求传“1”
        model.setType("1");
        return model;
    }

    private String getPatientId() {
        // videoFinishBean.getPatientId() 为 pt_123456
        String str = videoFinishBean.getPatientId();

        String patientId = "";
        if(str != null && str.split("_").length > 1){
            patientId = str.split("_")[1];
        }
        return patientId;
    }

    private void setWidgetStatus(){
        //初次问诊
        if(videoFinishBean.getFirstisit().equals("0")){
            //是否可以重新开启
            if(videoFinishBean.getTimeOfAdvent().equals("0")){
                sx_id_send_video_again_rl.setVisibility(View.VISIBLE);
            }else {
                sx_id_send_video_again_rl.setVisibility(View.GONE);
            }
            sx_id_recommended_medication_rl.setVisibility(View.GONE);
            view2.setVisibility(View.GONE);
        }else{
            //是否可以重新开启
            if(videoFinishBean.getTimeOfAdvent().equals("0")){
                sx_id_send_video_again_rl.setVisibility(View.VISIBLE);
            }else {
                sx_id_send_video_again_rl.setVisibility(View.GONE);
            }
            sx_id_recommended_medication_rl.setVisibility(View.VISIBLE);
            view2.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 跳转添加诊疗记录
     * v2.8 add by xd
     */
    private void toAddMedicRecordList(XC_ChatModel chatModel) {
        Intent intent = new Intent();
        intent.putExtra(CommonConfig.CHAT_PARAMS_MODEL, chatModel);
        intent.setClass(this, SX_AddMedicalRecordActivity.class);
        myStartActivity(intent);
    }
}
