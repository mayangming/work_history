package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.YR_MedicalRecordAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.util.List;

/**
 * 用药记录页
 *
 * @author 崔毅然
 * @version 2.2
 */
public class YR_MedicationRecordActivity extends DBActivity{
    /** 用药记录list */
    private XCListViewFragment listViewFragment;
    /** 病人分组adapter */
    private YR_MedicalRecordAdapter medicalRecordAdapter;
    /** 药单id标识, 向用药详情页传递统一名称 */
    public static String ORDERID = "orderId";
    /** 每页显示记录条数（用药记录默认30条） */
    public static String PAGE_NUM = "30";
    /**title布局*/
    private RelativeLayout pf_title_rl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yr_activity_medicationrecord);
        super.onCreate(savedInstanceState);

        initTitle();
        //初始化加载第一页数据
        requestMedicalRecordList(1);

    }

    /** 初始化title */
    public void initTitle() {
        findViewById(R.id.sx_id_title_left).setOnClickListener(this);
        pf_title_rl = getViewById(R.id.pf_title_rl);
        pf_title_rl.setBackgroundColor(getResources().getColor(R.color.c_white_ffffff));
        ((TextView)findViewById(R.id.sx_id_title_center)).setText("用药记录");
    }

    @Override
    public void initWidgets() {
        findViewById(R.id.ll_patient_search).setOnClickListener(this);
//      用药记录listView相关设置
        medicalRecordAdapter = new YR_MedicalRecordAdapter(this,null);
        listViewFragment = new XCListViewFragment();
        listViewFragment.setAdapter(medicalRecordAdapter);
        listViewFragment.setMode(XCListViewFragment.MODE_UP_DOWN);//设置可刷新、加载
        listViewFragment.setBgZeroHintInfo("无用药记录!", "", R.mipmap.js_d_icon_no_data);//无数据遮罩
        listViewFragment.setListViewStyleParam(null, 20, false);//设置分隔线和progressbar
        addFragment(R.id.xc_d_rl_medical_record, listViewFragment);
    }

    @Override
    public void listeners() {
        listViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                // 跳转到用药详情页（只传递用药单号id）
                XCJsonBean xcJsonBean = (XCJsonBean) (arg0.getItemAtPosition(arg2));
                Intent intent = new Intent();
                intent.setClass(YR_MedicationRecordActivity.this, PF_MedicationDetailActivity.class);
                intent.putExtra(ORDERID, xcJsonBean.getString("id"));
                myStartActivity(intent);
            }
        });

        //刷新和加载调用
        listViewFragment.setOnRefreshNextPageListener(new XCBaseAbsListFragment.OnRefreshNextPageListener() {
            @Override
            public void onRefreshNextPageListener(int current_page) {
                if (current_page == 1) {
                    listViewFragment.base_refresh_abs_listview.setMode(PullToRefreshBase.Mode.BOTH);
                }
                requestMedicalRecordList(current_page);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        listViewFragment.base_abs_listview.setOverScrollMode(View.OVER_SCROLL_NEVER);//去掉listView拉动时的边框
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(YR_MedicationRecordActivity.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    @Override
    public void onNetRefresh() {
        requestMedicalRecordList(listViewFragment.base_currentPage);//页数显示正常(已查)
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.sx_id_title_left:
                myFinish();
                break;
            case R.id.ll_patient_search:
                myStartActivity(new Intent(this, YR_MedicationRecordSearchActivity.class));
                break;
        }
    }

    /** 请求用药记录列表
     * @param  page 请求的页
     * */
    public void  requestMedicalRecordList(int page){
        RequestParams params = new RequestParams();
        params.put("page", page);
        params.put("num", PAGE_NUM);
        params.put("key", "");//必须传空，不然无数据
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.medicationRecomSearch), params, new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (!listViewFragment.checkGoOn()) {
                        listViewFragment.base_refresh_abs_listview.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
                        return;
                    }
                    List<XCJsonBean> result_list = result_bean.getList("data");
                    if (result_list != null && result_list.size() > 0 && result_list.get(0) != null) {//更新listView数据
                        List<XCJsonBean> medicationList = result_list.get(0).getList("result");
                        listViewFragment.updateList(medicationList);
                        listViewFragment.setTotalPage(result_list.get(0).getString("totalPages"));
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if(listViewFragment != null){
                    listViewFragment.doRefreshComplete();
                }
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YR_MedicationRecordActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });

    }

}
