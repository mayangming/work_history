package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.YR_CommonDialog;

/**
 *  WangYong
 *  既往病史、病理特征等编辑页面
 */
public class ExamineContentActivity extends DBActivity {
    //title左边文字
    private TextView sx_id_title_left;
    //title中间文字
    private TextView sx_id_title_center;
    //title右边文字
    private TextView sx_id_title_right_btn;
    // 输入计数
    private TextView sx_id_word_count_record;
    // 输入最大内容计数
    private TextView sx_id_write_content_max;
    // 内容输入框/
    private EditText sx_id_condition_record_edit;
    // 输入内容最大长度限制
    int maxLength = 0;
    // 提示保存对话框
    private YR_CommonDialog mDialog;
    // 从上个界面带过来的数据
    private String contentStr = "";
    public static final  String EXAMINE_TITLE = "examine_title";
    public static final  String CONTENTSTR = "content";
    public static final  String MAXLENGTH = "max";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_examine_content);
        super.onCreate(savedInstanceState);
        sx_id_title_center.setText(getIntent().getStringExtra(EXAMINE_TITLE));
        contentStr = getIntent().getStringExtra(CONTENTSTR);
        sx_id_condition_record_edit.setHint("输入患者"+ getIntent().getStringExtra(EXAMINE_TITLE));
        sx_id_condition_record_edit.setText(contentStr);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(ExamineContentActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    /**
     * 初始化控件显示的内容
     */
    private void initWidgetsData() {
        String length = getIntent().getStringExtra(MAXLENGTH);
        if(TextUtils.isEmpty(length)){
            maxLength = 200;
        }else{
            maxLength = Integer.valueOf(length);
        }
        sx_id_condition_record_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        sx_id_write_content_max.setText(maxLength + "");
    }

    /**
     * 初始化保存提示对话框
     */
    private void initDialog() {
        mDialog = new YR_CommonDialog(this, "放弃保存吗？", "放弃", "取消") {
            @Override
            public void confirmBtn() {
                dismiss();
            }

            @Override
            public void cancelBtn() {
                super.cancelBtn();
                myFinish();
            }
        };
        mDialog.setCanceledOnTouchOutside(true);
    }

    @Override
    public void initWidgets() {
        sx_id_title_left = getViewById(R.id.sx_id_title_left);
        sx_id_title_center = getViewById(R.id.sx_id_title_center);
        sx_id_title_right_btn = getViewById(R.id.sx_id_title_right_btn);
        sx_id_condition_record_edit = getViewById(R.id.sx_id_condition_record_edit);
        sx_id_word_count_record = getViewById(R.id.sx_id_record_content);
        sx_id_write_content_max = getViewById(R.id.sx_id_write_content_max);
        initWidgetsData();
        initDialog();
    }

    @Override
    public void listeners() {
        sx_id_title_left.setOnClickListener(this);
        sx_id_title_right_btn.setOnClickListener(this);
        sx_id_condition_record_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                sx_id_word_count_record.setText(s.length() + "");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.sx_id_title_left: {
                onBackPressed();
                break;
            }
            case R.id.sx_id_title_right_btn: {
                String content = sx_id_condition_record_edit.getText().toString().trim();
                Intent intent = new Intent();
                intent.putExtra(CONTENTSTR, content);
                setResult(RESULT_OK, intent);
                myFinish();
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        String content = sx_id_condition_record_edit.getText().toString().trim();
        if(!TextUtils.isEmpty(content)){
            mDialog.show();
        }else {
            myFinish();
        }
    }

    @Override
    public void onNetRefresh() {

    }
}
