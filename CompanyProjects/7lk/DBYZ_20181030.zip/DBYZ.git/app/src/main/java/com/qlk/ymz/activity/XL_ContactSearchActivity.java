package com.qlk.ymz.activity;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PF_SearchContactsAdapter;
import com.qlk.ymz.db.invited.XL_ContactsInvitedModel;
import com.qlk.ymz.model.XL_RawContactModel;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCClearEditText;

import java.util.ArrayList;
import java.util.List;

/**
 * 联系人搜索页，默认是search_record_info4表
 *
 * create by xilinch on 2016-3-24
 * @version 2.3
 *
 * update author zhangpengfei
 * @version 2.3.0
 */
public class XL_ContactSearchActivity extends XL_BaseContactInviteActivity {
    public static final String TO_CONTACTSEARCH_INFO = "toContactsSearchInfo";
    /** 搜索关键字 */
    public static String SEARCH_KEY = "search_key";
    /** 联想结果列表 */
    private XCListViewFragment listViewFragment;
    /** 联想结果适配器 */
    private PF_SearchContactsAdapter searchContactsAdapter;
    /** 联系人信息 */
    private List<XL_ContactsInvitedModel> mAllContactsList;
    /** 联想结果信息 */
    private List<XL_ContactsInvitedModel> mResultList;
    /** 搜索关键字 */
    private XCClearEditText sk_id_search_edit;
    /**没有数据提示*/
    private LinearLayout pf_no_date;
    /**输入的最大长度*/
    private int maxLength = 0;
    /**输入的最小长度*/
    private int minLength = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xc_l_activity_patient_search);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_ContactSearchActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    /** 无网络时,点击屏幕后回调的方法 */
    @Override
    public void onNetRefresh() {
    }

    /** 初始化控件 */
    @Override
    public void initWidgets() {
        pf_no_date = getViewById(R.id.pf_no_date);
        ((TextView)getViewById(R.id.id_zero_data_tv)).setText("没有找到相关的联系人，更改关键字试试");

        mResultList = new ArrayList<>();
        mAllContactsList = new ArrayList<>();
        searchContactsAdapter = new PF_SearchContactsAdapter(this, mResultList);
        sk_id_search_edit = (XCClearEditText) findViewById(R.id.sk_id_search_edit);
        sk_id_search_edit.requestFocus();
        sk_id_search_edit.setFocusable(true);
        sk_id_search_edit.setHint("请输入联系人关键字");
        sk_id_search_edit.setHintTextColor(getResources().getColor(R.color.c_gray_bbbbbb));
        findViewById(R.id.xc_id_titlebar_right2_textview).setOnClickListener(this);
        listViewFragment = new XCListViewFragment();
        listViewFragment.setMode(XCListViewFragment.MODE_NOT_PULL);//不可上下拉的listview
        listViewFragment.setBgZeroHintInfo("抱歉，没有匹配的联系人", "重新加载", R.mipmap.js_d_icon_no_data);
        listViewFragment.setAdapter(searchContactsAdapter);
        ColorDrawable colorDrawable = new ColorDrawable(0xFFBEBEBE);
        listViewFragment.setListViewStyleParam(colorDrawable, 1, false);
        addFragment(R.id.xc_id_model_content, listViewFragment);
        //格式化数据
        ArrayList<XL_RawContactModel> rawContactModels = XL_ContactsInviteActivity.CONTACTS_INFO;
        if (null != rawContactModels && rawContactModels.size() > 0){
            for (int i = 0; i < rawContactModels.size(); i ++){
                List<XL_RawContactModel.XL_PhoneContent> phoneContents = rawContactModels.get(i).getPhoneContents();
                if (null != phoneContents && phoneContents.size() > 0){
                    for (int j = 0; j < phoneContents.size(); j ++){
                        XL_ContactsInvitedModel contactsInvitedModel = new XL_ContactsInvitedModel();
                        contactsInvitedModel.number = phoneContents.get(j).getPhone();
                        contactsInvitedModel.display_name = phoneContents.get(j).getDisplay_name();
                        contactsInvitedModel.contactId = phoneContents.get(j).getContactId();
                        contactsInvitedModel.phoneId = phoneContents.get(j).get_id();
                        contactsInvitedModel.doctorId = UtilSP.getUserId();
                        mAllContactsList.add(contactsInvitedModel);
                    }
                }
            }
        }

        //获取sp的极限值
        maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PHONE_CONTACT_SEARCH, 0, 19);
        minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PHONE_CONTACT_SEARCH, 1, 0);
        sk_id_search_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});

    }

    @Override
    public void listeners() {
        //点击软件盘搜索按钮跳转搜索结果页
        sk_id_search_edit.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    String keyWord = sk_id_search_edit.getText().toString().trim();
                    if (UtilString.isBlank(keyWord) || keyWord.length() < minLength){
//                        shortToast("请输入联系人姓名");
                        return true;
                    }
                    UtilInputMethod.hiddenInputMethod(XL_ContactSearchActivity.this);
                    searchAssociation(keyWord);
                    if (mResultList.size() == 0){
                        pf_no_date.setVisibility(View.VISIBLE);
                    }else{
                        pf_no_date.setVisibility(View.GONE);
                    }
                    return true;
                }
                return false;
            }
        });
        // 搜索标题编辑框的关键字联想功能的监听
        sk_id_search_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchAssociation(s + "");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        // 选择联系人
        listViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                //因为listViewFragment添加了一个header,所有要减1
                if ((arg2 - 1) >= 0){
                    mResultList.get(arg2 - 1).setFlag(XL_ContactsInvitedModel.STATUS_INVITIED_YES);
                    clickedPhoneContactMap.put(mResultList.get(arg2 - 1).getContactId(), mResultList.get(arg2 - 1));
                    save2InvitedDb();
                    requestContactsLog_batchInvite();//批量邀请患者操作日志埋点
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.xc_id_titlebar_right2_textview:
                myFinish();
                break;
        }
    }

    /**
     * 搜索结果
     * @param key 关键字
     */
    private void searchAssociation(String key){
        pf_no_date.setVisibility(View.GONE);
        mResultList.clear();
        if (!UtilString.isBlank(key.toString().trim())){
            for (int i = 0; i < mAllContactsList.size(); i ++){
                if (mAllContactsList.get(i).display_name.toLowerCase().contains(key.toLowerCase())
                        || mAllContactsList.get(i).number.contains(key)){
                    mResultList.add(mAllContactsList.get(i));
                }
            }
        }
        listViewFragment.updateSpecialList(mResultList);

    }


}
