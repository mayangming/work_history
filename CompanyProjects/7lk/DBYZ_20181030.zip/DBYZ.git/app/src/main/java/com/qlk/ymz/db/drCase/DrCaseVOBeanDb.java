package com.qlk.ymz.db.drCase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.google.gson.JsonArray;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.model.record.ImgListBean;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class DrCaseVOBeanDb extends SQLiteOpenHelper {

    public static final String DB_NAME = "drCaseVOBean.db";
    public static final int VERSION = 1;
    public String mOperatorTableName ="drCase";


    /** 排序常量 */
    public static String SORT_DESC = " DESC";// 有个空格符号，勿删
    public static String SORT_ASC = " ASC";// 有个空格符号，勿删

    /**以下是表字段*/
    public static final String _ID = "_id";
    public static final String AGE = "age";
    public static final String AGEUNIT = "ageUnit";
    public static final String ALT = "alt";
    public static final String AST = "ast";
    public static final String CREATEDATE = "createDate";
    public static final String DEPARTMENT = "department";
    public static final String DIAGNOSIS = "diagnosis";
    public static final String DIAGNOSISLIST = "diagnosisList";
    public static final String DIASTOLE = "diastole";
    public static final String DOCTORID = "doctorId";
    public static final String DOCTORNAME = "doctorName";
    public static final String DOCTORORDER = "doctorOrder";
    public static final String GENDER = "gender";
    public static final String HBVDNA = "hbvDna";
    public static final String HEARTRETE = "heartRete";
    public static final String HOSPITALNAME = "hospitalName";
    public static final String MAINCOMPLAINT = "mainComplaint";
    public static final String MEMBER = "member";
    public static final String MOREEXAMIN = "moreExamin";
    public static final String NAME = "name";
    public static final String PASTHISTORY = "pastHistory";
    public static final String PATIENTID = "patientId";
    public static final String PRESENTDISEASE = "presentDisease";
    public static final String REVISITDATEUNIT = "revisitDateUnit";
    public static final String REVISITFALG = "revisitFalg";
    public static final String REVISITNUMBER = "revisitNumber";
    public static final String SYSTOLIC = "systolic";
    public static final String TEMPERATURE = "temperature";
    public static final String TEMPLATETYPE = "templateType";
    public static final String WEIGHT = "weight";
    public static final String IMGLIST = "imgList";
    public static final String PRESCRIPTIONVO = "prescriptionVO";

    public DrCaseVOBeanDb (Context context) {
        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + mOperatorTableName
                + "("+_ID +" integer primary key autoincrement,"
                + AGE + " text, "
                + AGEUNIT + " text, "
                + ALT + " text, "
                + AST + " text, "
                + CREATEDATE + " text, "
                + DEPARTMENT + " text, "
                + DIAGNOSIS + " text, "
                + DIAGNOSISLIST + " text, "
                + DIASTOLE + " text, "
                + DOCTORID + " text, "
                + DOCTORNAME + " text, "
                + DOCTORORDER + " text, "
                + GENDER + " text, "
                + HBVDNA + " text, "
                + HEARTRETE + " text, "
                + HOSPITALNAME + " text, "
                + MAINCOMPLAINT + " text, "
                + MEMBER + " text, "
                + MOREEXAMIN + " text, "
                + NAME + " text, "
                + PASTHISTORY + " text, "
                + PATIENTID + " text, "
                + PRESENTDISEASE + " text, "
                + REVISITDATEUNIT + " text, "
                + REVISITFALG + " text, "
                + REVISITNUMBER + " text, "
                + SYSTOLIC + " text, "
                + TEMPERATURE + " text, "
                + TEMPLATETYPE + " text, "
                + WEIGHT + " text, "
                + IMGLIST + " text, "
                + PRESCRIPTIONVO + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        if (newVersion > oldVersion) {
            //执行删除旧数据操作
            sqLiteDatabase.execSQL("drop table if exists " + mOperatorTableName);
            //创建新的db
            onCreate(sqLiteDatabase);
        }
    }

    public ContentValues createContentValue(DrCaseVOBean model) {
        ContentValues values = new ContentValues();
        values.put(AGE, model.getAge());
        values.put(AGEUNIT, model.getAgeUnit());
        values.put(ALT, model.getAlt());
        values.put(AST, model.getAst());
        values.put(CREATEDATE, model.getCreateDate());
        values.put(DEPARTMENT, model.getDepartment());
        values.put(DIAGNOSIS, model.getDiagnosis());
        values.put(DIAGNOSISLIST, createJsonArry(model.getDiagnosisList()).toString());
        values.put(DIASTOLE, model.getDiastole());
        values.put(DOCTORID, model.getDoctorId());
        values.put(DOCTORNAME, model.getDoctorName());
        values.put(DOCTORORDER, model.getDoctorOrder());
        values.put(GENDER, model.getGender());
        values.put(HBVDNA, model.getHbvDna());
        values.put(HEARTRETE, model.getHeartRete());
        values.put(HOSPITALNAME, model.getHospitalName());
        values.put(MAINCOMPLAINT, model.getMainComplaint());
        values.put(MEMBER, model.getMember());
        values.put(MOREEXAMIN, model.getMoreExamin());
        values.put(NAME, model.getName());
        values.put(PASTHISTORY, model.getPastHistory());
        values.put(PATIENTID, model.getPatientId());
        values.put(PRESENTDISEASE, model.getPresentDisease());
        values.put(REVISITDATEUNIT, model.getRevisitDateUnit());
        values.put(REVISITFALG, model.getRevisitFalg());
        values.put(REVISITNUMBER, model.getRevisitNumber());
        values.put(SYSTOLIC, model.getSystolic());
        values.put(TEMPERATURE, model.getTemperature());
        values.put(TEMPLATETYPE, model.getTemplateType());
        values.put(WEIGHT, model.getWeight());
        values.put(IMGLIST, createImgJsonArry(model.getImgList()).toString());
        return values;
    }

    private JSONArray createImgJsonArry(List<ImgListBean> imgListBeans) {
        JSONArray jsonArray = new JSONArray();
        for (ImgListBean imgListBean:imgListBeans){
            jsonArray.put(imgListBean.getImgUrl());
        }
        return jsonArray;
    }
    private JSONArray createJsonArry(List<String> diagnosisList) {
        JSONArray jsonArray = new JSONArray();
        for (String string:diagnosisList){
            jsonArray.put(string);
        }
        return jsonArray;
    }

    public DrCaseVOBean createModel(Cursor c){
        DrCaseVOBean model = new DrCaseVOBean();
        model.setAge(c.getString(c.getColumnIndex(AGE)));
        model.setAgeUnit(c.getString(c.getColumnIndex(AGEUNIT)));
        model.setAlt(c.getString(c.getColumnIndex(ALT)));
        model.setAst(c.getString(c.getColumnIndex(AST)));
        model.setCreateDate(c.getString(c.getColumnIndex(CREATEDATE)));
        model.setDepartment(c.getString(c.getColumnIndex(DEPARTMENT)));
        model.setDiagnosis(c.getString(c.getColumnIndex(DIAGNOSIS)));
        model.setDiagnosisList(getDiagnosisList(c.getString(c.getColumnIndex(DIAGNOSISLIST))));
        model.setDiastole(c.getString(c.getColumnIndex(DIASTOLE)));
        model.setDoctorId(c.getString(c.getColumnIndex(DOCTORID)));
        model.setDoctorName(c.getString(c.getColumnIndex(DOCTORNAME)));
        model.setDoctorOrder(c.getString(c.getColumnIndex(DOCTORORDER)));
        model.setGender(c.getString(c.getColumnIndex(GENDER)));
        model.setHbvDna(c.getString(c.getColumnIndex(HBVDNA)));
        model.setHeartRete(c.getString(c.getColumnIndex(HEARTRETE)));
        model.setHospitalName(c.getString(c.getColumnIndex(HOSPITALNAME)));
        model.setMainComplaint(c.getString(c.getColumnIndex(MAINCOMPLAINT)));
        model.setMember(c.getString(c.getColumnIndex(MEMBER)));
        model.setMoreExamin(c.getString(c.getColumnIndex(MOREEXAMIN)));
        model.setName(c.getString(c.getColumnIndex(NAME)));
        model.setPastHistory(c.getString(c.getColumnIndex(PASTHISTORY)));
        model.setPatientId(c.getString(c.getColumnIndex(PATIENTID)));
        model.setPresentDisease(c.getString(c.getColumnIndex(PRESENTDISEASE)));
        model.setRevisitDateUnit(c.getString(c.getColumnIndex(REVISITDATEUNIT)));
        model.setRevisitFalg(c.getString(c.getColumnIndex(REVISITFALG)));
        model.setRevisitNumber(c.getString(c.getColumnIndex(REVISITNUMBER)));
        model.setSystolic(c.getString(c.getColumnIndex(SYSTOLIC)));
        model.setTemperature(c.getString(c.getColumnIndex(TEMPERATURE)));
        model.setTemplateType(c.getString(c.getColumnIndex(TEMPLATETYPE)));
        model.setWeight(c.getString(c.getColumnIndex(WEIGHT)));
        model.setImgList(getImgList(c.getString(c.getColumnIndex(IMGLIST))));
        return model;
    }

    private List<String> getDiagnosisList(String json) {
        ArrayList<String> diagnosisList = new ArrayList<>();
        try{
            JSONArray jsonArray = new JSONArray(json);
            for(int i=0;i<jsonArray.length();i++){
                diagnosisList.add(jsonArray.getString(i));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return diagnosisList;
    }

    private List<ImgListBean> getImgList(String json) {
        ArrayList<ImgListBean> imgListBeans = new ArrayList<>();
        try{
            JSONArray jsonArray = new JSONArray(json);
            for(int i=0;i<jsonArray.length();i++){
                ImgListBean imgListBean = new ImgListBean();
                imgListBean.setImgUrl(jsonArray.getString(i));
                imgListBeans.add(imgListBean);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return imgListBeans;
    }

    /** 插入一条记录 */
    public synchronized  long insert(DrCaseVOBean model) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = createContentValue(model);
        long id = db.insert(mOperatorTableName, _ID, values);
        //Logger.i("insert()插入的记录的id是: " + id);
        db.close();
        return id;
    }
    public synchronized int UpdateCaseById(DrCaseVOBean model){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValue = createContentValue(model);
        String queryClause = PATIENTID + "=?" + " and " + DOCTORID + "=?"; // 更新条件
        int update = db.update(mOperatorTableName, createContentValue(model), queryClause, new String[]{model
                .getPatientId(), model.getDoctorId()});
        db.close();
        return update;
    }

    public synchronized DrCaseVOBean queryCaseById(String docId,String patientId){
        SQLiteDatabase db = getReadableDatabase();
        String whereClause = PATIENTID + "=?" + " and " + DOCTORID + "=?";
        Cursor query = db.query(mOperatorTableName, null, whereClause, new String[]{patientId, docId}, null, null, null);
        if(query.moveToNext()){
            return createModel(query);
        }else {
            return null;
        }
    }

    public synchronized int deleteById(String patientId,String docId){
        SQLiteDatabase db = getWritableDatabase();
        String queryClause = PATIENTID + "=?" + " and " + DOCTORID + "=?";
        int delete = db.delete(mOperatorTableName, queryClause, new String[]{patientId, docId});
        db.close();
        return delete;
    }

    public synchronized  long inserts(List<DrCaseVOBean> list) {
        int count = 0;
        SQLiteDatabase db = getWritableDatabase();
        for(DrCaseVOBean model : list){
            ContentValues values = createContentValue(model);
            long id = db.insert(mOperatorTableName, _ID, values);
            //Logger.i("insert()插入的记录的id是: " + id);
            count++;
        }
        db.close();
        return count;
    }


    /** 删除所有记录 */
    public synchronized int deleteAll() {
        SQLiteDatabase db = getWritableDatabase();
        int raw = db.delete(mOperatorTableName, null, null);
        db.close();
        return raw;
    }


    /** 查询共有多少条记录 */
    public synchronized int queryCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, new String[]{"COUNT(*)"},null, null, null, null, null, null);
        c.moveToNext();
        int count = c.getInt(0);
        c.close();
        db.close();
        return count;
    }


    /** 查询所有*/
    public synchronized List<DrCaseVOBean> queryAllByIdDesc() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null,_ID + SORT_DESC); // 条件为null可以查询所有
        List<DrCaseVOBean> beans = new ArrayList<DrCaseVOBean>();
        while (c.moveToNext()) {
            DrCaseVOBean bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }


    /** 查询所有*/
    public synchronized List<DrCaseVOBean> queryAllByIdAsc() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null,_ID + SORT_ASC);
        List<DrCaseVOBean> beans = new ArrayList<DrCaseVOBean>();
        while (c.moveToNext()) {
            DrCaseVOBean bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }


    /** 分页查找 */
    public synchronized List<DrCaseVOBean> queryPageByIdAsc(int pageNum, int capacity){
        String offset = (pageNum - 1) * capacity + ""; // 偏移量
        String len = capacity + ""; // 个数
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_ASC , offset + "," + len);
        List<DrCaseVOBean> beans = new ArrayList<DrCaseVOBean>();
        while (c.moveToNext()) {
            DrCaseVOBean bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }


    /** 分页查找 */
    public synchronized List<DrCaseVOBean> queryPageByIdDesc(int pageNum, int capacity){
        String offset = (pageNum - 1) * capacity + ""; // 偏移量
        String len = capacity + ""; // 个数
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_DESC , offset + "," + len);
        List<DrCaseVOBean> beans = new ArrayList<DrCaseVOBean>();
        while (c.moveToNext()) {
            DrCaseVOBean bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

}