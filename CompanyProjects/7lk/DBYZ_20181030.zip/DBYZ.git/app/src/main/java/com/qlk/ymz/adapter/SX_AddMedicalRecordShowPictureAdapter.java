package com.qlk.ymz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.SX_AddMedicalRecordActivity;
import com.qlk.ymz.model.PictureFileInfo;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.util.LinkedList;

/**
 * SX_AddMedicalRecordShowPictureAdapter
 * 添加诊疗记录适配器
 * @author songxin on 2016/6/14.
 * @version 2.5.0
 */
public class SX_AddMedicalRecordShowPictureAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private LinkedList<PictureFileInfo> mPicUrls;
    private Context mContext;
    private ViewHolder mViewHolder;
    /** 图片数量限制 */
    private int maxImgNum;

    private int num;
    public SX_AddMedicalRecordShowPictureAdapter(Context context,LinkedList<PictureFileInfo> picUrls,int maxImgNum){
        this.mPicUrls = picUrls;
        this.mContext = context;
        this.maxImgNum = maxImgNum;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sx_l_adapter_add_medical_show_pic_item, parent,
                false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        XCApplication.base_log.i("http","position------>"+ position + "--" + ++num);
        mViewHolder = (ViewHolder)holder;
        final String imgType = mPicUrls.get(position).getImageType();
        //如果type = IMAGE_TYPE_IMAGE 是可删除的，删除小标显示
        if(PictureFileInfo.IMAGE_TYPE_IMAGE.equals(imgType)){
            mViewHolder.sx_id_delete_image.setVisibility(View.VISIBLE);
        }else{
            mViewHolder.sx_id_delete_image.setVisibility(View.INVISIBLE);
        }
        // type = IMAGE_TYPE_IMAGE 显示图片加载本地需要加前缀file://,不显示计数
        if(PictureFileInfo.IMAGE_TYPE_IMAGE.equals(imgType)){
            if(mPicUrls.get(position).getLocalUrl().toLowerCase().startsWith("http")){
                XCApplication.displayImage(mPicUrls.get(position).getLocalUrl(),mViewHolder.sx_id_show_image);
            }else {
                XCApplication.displayImage("file://" + mPicUrls.get(position).getLocalUrl(),mViewHolder.sx_id_show_image);
            }
            mViewHolder.sx_id_show_image_text.setVisibility(View.INVISIBLE);
            //type = IMAGE_TYPE_IMAGE_ADD 显示图片加载需要加drawable://,不显示计数
        }else if(PictureFileInfo.IMAGE_TYPE_IMAGE_ADD.equals(imgType)){
            XCApplication.base_imageloader.displayImage("drawable://" + R.mipmap.sx_d_add_medical_record_add, mViewHolder.sx_id_show_image, XCImageLoaderHelper.getDisplayNoCacheImageOptions(R.mipmap.sx_d_add_medical_record_add));
            mViewHolder.sx_id_show_image_text.setVisibility(View.INVISIBLE);
            //type = IMAGE_TYPE_TEXT 不显示图片，显示计数
        }else{
            XCApplication.base_imageloader.displayImage("drawable://" + R.mipmap.sx_d_add_medical_record_def, mViewHolder.sx_id_show_image, XCImageLoaderHelper.getDisplayNoCacheImageOptions(R.mipmap.sx_d_add_medical_record_def));
            mViewHolder.sx_id_delete_image.setVisibility(View.INVISIBLE);
            mViewHolder.sx_id_show_image_text.setVisibility(View.VISIBLE);
        }
        mViewHolder.sx_id_show_image_text.setText(mPicUrls.size() - 2 + "/" + maxImgNum);

        //如果数量等于5，说明已经添加了三张图片，后面的加号
        if(mPicUrls.size() >= maxImgNum + 2){
            //如果type等于IMAGE_TYPE_IMAGE_ADD
            if(PictureFileInfo.IMAGE_TYPE_IMAGE_ADD.equals(imgType)){
                mViewHolder.sx_id_show_image_text.setVisibility(View.VISIBLE);
                XCApplication.base_imageloader.displayImage("drawable://" + R.mipmap.sx_d_add_medical_record_def, mViewHolder.sx_id_show_image, XCImageLoaderHelper.getDisplayNoCacheImageOptions(R.mipmap.sx_d_add_medical_record_def));
            }
            if(PictureFileInfo.IMAGE_TYPE_TEXT.equals(imgType)){
                mViewHolder.sx_id_show_image_text.setVisibility(View.INVISIBLE);
            }
        }


        //删除图片事件
        mViewHolder.sx_id_delete_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //update by wangyong 修改图片删除逻辑 20170615 start
                onUIRefreshListener.recordPhotoRefresh(position,mPicUrls.get(position).getLocalUrl());
                //update by wangyong 修改图片删除逻辑 20170615 end
            }
        });

        //显示图片选择框
        mViewHolder.sx_id_show_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(null != mPicUrls && PictureFileInfo.IMAGE_TYPE_IMAGE_ADD.equals(imgType)){
                    if(null != mContext && mContext instanceof SX_AddMedicalRecordActivity){
                        ((SX_AddMedicalRecordActivity) mContext).openMutiplePhohoSelect(mPicUrls.size()-2);
                    }
                }
            }
        });
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return mPicUrls.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder{
        /** 图片显示*/
        private ImageView sx_id_show_image;
        /** 删除图片*/
        private ImageView sx_id_delete_image;
        /** 计数小标*/
        private TextView sx_id_show_image_text;

        public ViewHolder(View itemView) {
            super(itemView);
            sx_id_delete_image = (ImageView)itemView.findViewById(R.id.sx_id_delete_image);
            sx_id_show_image = (ImageView)itemView.findViewById(R.id.sx_id_show_image);
            sx_id_show_image_text = (TextView)itemView.findViewById(R.id.sx_id_show_image_text);
        }
    }

    //删除图片借口回调
    public interface OnUIRefreshListener{
        void recordPhotoRefresh(int pos ,String url);
    }

    private OnUIRefreshListener onUIRefreshListener;

    public void setOnUIRefreshListener(OnUIRefreshListener onUIRefreshListener) {
        this.onUIRefreshListener = onUIRefreshListener;
    }
}
