package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.TextChangedListenerUtil;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.SX_ClearEditText;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilMd5;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * SX_ConfirmationCodeActivity
 * 用户注册(确认验证码页面)
 * @author songxin on 2016/1/7.
 * @version 1.2.0
 */
public class SX_ConfirmationCodeActivity extends DBActivity implements View.OnClickListener {
    /** title左边按钮*/
    private ImageView sx_id_title_left;
    /** title中间文字*/
    private TextView sx_id_title_center;
    /** 确认验证码页面验证码输入框*/
    private SX_ClearEditText sx_l_verification_code_edit;
    /** 确认验证码页面重新获取验证码*/
    private TextView sx_l_verification_code_text;
    /** 确认验证码页面下一步按钮*/
    private Button sx_l_next_button;
    /** 确认验证码页面用户名显示*/
    private TextView sx_l_show_phone_number;
    /** 计时器*/
    Timer mTimer;
    TimerTask mTask;
    int mTime = 60;
    /** 用户名(手机号)*/
    private String mUserName = "";
    /** 跳转标记*/
    private int mFlag = -1;



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// 设置布局
		setContentView(R.layout.sx_l_activity_confirmation_code);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(SX_ConfirmationCodeActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-25,about：saveInfo,end
        mFlag = getIntent().getIntExtra("toConfirmationCode",0);
        sx_id_title_center.setText("确认验证码");
        mUserName = getIntent().getStringExtra("USERNAME");
        sx_l_show_phone_number.setText(Html.fromHtml("请输入<font color='#e2231a'>" + mUserName + "</font>收到的验证码"));
        mTimer = new Timer();
        startTimer();
	}

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_ConfirmationCodeActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

	// 无网络时,点击屏幕后回调的方法
	@Override
	public void onNetRefresh() {
	}

	// 初始化控件
	@Override
	public void initWidgets() {
        getViewById(R.id.pf_title_rl).setBackgroundColor(getResources().getColor(R.color.c_trans));
        getViewById(R.id.line).setVisibility(View.GONE);
        sx_id_title_left = getViewById(R.id.sx_id_title_left);
        sx_id_title_center = getViewById(R.id.sx_id_title_center);
        sx_l_verification_code_edit = getViewById(R.id.sx_l_verification_code_edit);
        sx_l_verification_code_text = getViewById(R.id.sx_l_verification_code_text);
        sx_l_next_button = getViewById(R.id.sx_l_next_button);
        sx_l_show_phone_number = getViewById(R.id.sx_l_show_phone_number);
	}

	// 设置监听
	@Override
	public void listeners() {
        sx_id_title_left.setOnClickListener(this);
        sx_l_verification_code_text.setOnClickListener(this);
        sx_l_next_button.setOnClickListener(this);
        //监听输入框变化，控制登录按钮颜色，是否可点击
        TextChangedListenerUtil.textChanged(sx_l_verification_code_edit,SX_ConfirmationCodeActivity.this,sx_l_next_button);
	}

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            //返回按钮
            case R.id.sx_id_title_left:{
                finish();
                break;
            }
            //重新获取按钮
            case R.id.sx_l_verification_code_text:{
                getCurtentTime();
                break;
            }
            //下一步按钮
            case R.id.sx_l_next_button:{
                if(UtilString.isBlank(sx_l_verification_code_edit.getText().toString().trim())){
                    XCApplication.base_log.shortToast("请输入验证码后重试！");
                    return;
                }
                if(mFlag == 0){
                    nextStep(mUserName, sx_l_verification_code_edit.getText().toString().trim(), AppConfig.getHostUrl(AppConfig.login_validateRegist));
                }else if(mFlag == 1){
                    nextStep(mUserName, sx_l_verification_code_edit.getText().toString().trim(), AppConfig.getHostUrl(AppConfig.login_validateForgetPwd));
                }
                break;
            }
            default:{
                break;
            }
        }
    }

    /***
     * 开始倒计时60s
     */
    private void startTimer(){
        sx_l_verification_code_text.setEnabled(false);
        mTask = new TimerTask() {
            @Override
            public void run() {

                runOnUiThread(new Runnable() { // UI thread
                    @Override
                    public void run() {
                        if (mTime <= 0) {
                            sx_l_verification_code_text.setEnabled(true);
                            sx_l_verification_code_text.setText("重新获取");
                            sx_l_verification_code_text.setTextColor(getResources().getColor(R.color.c_e2231a));
                            mTask.cancel();
                        } else {
                            sx_l_verification_code_text.setEnabled(false);
                            sx_l_verification_code_text.setText(mTime + "s后重新获取");
                            sx_l_verification_code_text.setTextColor(getResources().getColor(R.color.c_7b7b7b));
                        }
                        mTime--;
                    }
                });
            }
        };
        mTime = 60;
        mTimer.schedule(mTask, 0, 1000);
    }

    /**
     * 结束倒计时调用
     */
    private void stopTimer(){
        if(null != mTimer){
            mTimer.purge();
            mTimer.cancel();
        }
    }

    /**
     * 请求验证码
     * @param phoneNumber :医生输入手机号码
     * @param actionType ：功能类型(1/注册；2/忘记密码；3/修改手机号)
     */
    private void requestVcode(final String phoneNumber,String actionType,String currentTime){
        //发送请求
        RequestParams params = new RequestParams();
        params.put("phoneNum", phoneNumber);
        params.put("actionType", actionType);
        params.put("t", currentTime);
        params.put("sign", UtilMd5.MD5Encode("actionType="+actionType+"&phoneNum="+phoneNumber+"&t="+currentTime+AppConfig.SECRET_KEY));

        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.sendSms), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if(result_boolean){
                    startTimer();
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_ConfirmationCodeActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    private void getCurtentTime(){
        try {
            //发送请求
            RequestParams params = new RequestParams();
            XCHttpAsyn.postAsyn(false, SX_ConfirmationCodeActivity.this, AppConfig.getHostUrl(AppConfig.get_time), params, new XCHttpResponseHandler() {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if(result_boolean){
                        long time = ((List<Long>)result_bean.get("data")).get(0);
                        if(mFlag == 0){
                            requestVcode(mUserName, "1",time+"");
                        }else if(mFlag == 1){
                            requestVcode(mUserName,"2",time+"");
                        }
                    }
                }
            });
        } catch(Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 验证码确认接口
     * @param username 用户名
     * @param vCode 验证码
     */
    private void nextStep(final String username,String vCode,final String url){
        //发送请求
        RequestParams params = new RequestParams();
        params.put("phoneNum", username);
        params.put("verifyCode", vCode);
            XCHttpAsyn.postAsyn(false, this, url, params, new XCHttpResponseHandler() {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    printi("songxin", "arg2===validateRegist======>"+new String(arg2));
                    if (result_boolean) {
                        //成功进入下一步
                        Intent intent = new Intent();
                        intent.putExtra("USERNAME",username);
                        intent.putExtra("toSetLogin",mFlag);
                        if(mFlag == 0){
                            intent.setClass(SX_ConfirmationCodeActivity.this,SX_SetLoginActivity.class);
                            myStartActivity(intent);
                        }else if(mFlag == 1){
                            intent.setClass(SX_ConfirmationCodeActivity.this,SX_ForgetPasswordActivity.class);
                            myStartActivity(intent);
                        }
                    }
                }

                // add by xjs on 20151027 19:48 start
                // 对账户冻结情况的判断处理
                public void onFinish() {
                    super.onFinish();
                    if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_ConfirmationCodeActivity.this,
                            getCode(),
                            getMsg())) {
                        // 接口请求业务成功时的处理
                    }
                }
                // add by xjs on 20151027 19:48 end
            });
        }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopTimer();
    }
}
