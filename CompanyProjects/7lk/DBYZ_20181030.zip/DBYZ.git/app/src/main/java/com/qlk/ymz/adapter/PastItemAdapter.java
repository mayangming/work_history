package com.qlk.ymz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.flexbox.AlignItems;
import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexWrap;
import com.google.android.flexbox.FlexboxLayout;
import com.qlk.ymz.R;
import com.qlk.ymz.model.PastBean;
import com.qlk.ymz.util.UtilScreen;

import java.util.List;

/**
 * @author WangYong
 * @version 1.0
 */
public class PastItemAdapter extends RecyclerView.Adapter<PastItemAdapter.mViewHolder> {
    private List<PastBean> list;
    private Context mContext;
    private View mHeaderView;
    private LayoutInflater mInflater;
    public static final int TYPE_HEADER = 0;
    public static final int TYPE_NORMAL = 1;

    public PastItemAdapter(Context context, List<PastBean> list) {
        this.list = list;
        mContext = context;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public mViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (mHeaderView != null && viewType == TYPE_HEADER) return new mViewHolder(mHeaderView);
        View inflate = mInflater.inflate(R.layout.item_past, parent, false);
        mViewHolder holder = new mViewHolder(inflate);

        return holder;
    }

    @Override
    public void onBindViewHolder(mViewHolder holder, int position) {
        if (getItemViewType(position) == TYPE_HEADER) return;
        if (holder != null) {
            List<String> bean = list.get(position - 1).getItemList();
            holder.tv_past_name.setText(list.get(position - 1).getName());
            FlexboxLayout flexboxLayout = new FlexboxLayout(mContext);
            flexboxLayout.setFlexDirection(FlexDirection.ROW);
            flexboxLayout.setFlexWrap(FlexWrap.WRAP);
            flexboxLayout.setAlignItems(AlignItems.STRETCH);
            for (String str : bean) {
                flexboxLayout.addView(createNewFlexItemTextView(str));
            }
            ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            flexboxLayout.setLayoutParams(layoutParams);
            holder.mLinearLayout.addView(flexboxLayout);
        }
    }

    public void setHeaderView(View headerView) {
        mHeaderView = headerView;
        notifyItemInserted(0);
    }

    /**
     * 动态创建TextView
     */
    private TextView createNewFlexItemTextView(final String disease) {
        TextView textView = new TextView(mContext);
        textView.setGravity(Gravity.CENTER);
        textView.setText(disease);
        textView.setTextSize(14);
        textView.setTextColor(mContext.getResources().getColor(R.color.c_444444));
        textView.setBackgroundResource(R.drawable.pf_dd_line_cccccc__bg_white_r_2);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mOnUIRefreshListener.setPastTv(disease);
            }
        });
        int padding = UtilScreen.dip2px(mContext, 5);
        int paddingLeft = UtilScreen.dip2px(mContext, 10);
        textView.setPadding(paddingLeft, padding, paddingLeft, padding);
        FlexboxLayout.LayoutParams layoutParams = new FlexboxLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        int margin = UtilScreen.dip2px(mContext, 6);
        int marginTop = UtilScreen.dip2px(mContext, 12);
        layoutParams.setMargins(0, marginTop, margin, 0);
        textView.setLayoutParams(layoutParams);
        return textView;
    }

    @Override
    public int getItemCount() {
        return list.size() + 1;
    }

    @Override
    public int getItemViewType(int position) {
        if (mHeaderView == null) return TYPE_NORMAL;
        if (position == 0) return TYPE_HEADER;
        return TYPE_NORMAL;
    }

    static class mViewHolder extends RecyclerView.ViewHolder {

        TextView tv_past_name;
        LinearLayout mLinearLayout;

        public mViewHolder(View itemView) {
            super(itemView);
            tv_past_name = (TextView) itemView.findViewById(R.id.past_tv);
            mLinearLayout = (LinearLayout) itemView.findViewById(R.id.linear);
        }
    }

    public interface OnUIRefreshListener {
        void setPastTv(String str);
    }

    private OnUIRefreshListener mOnUIRefreshListener;

    public void setOnUIRefreshListener(OnUIRefreshListener onUIRefreshListener) {
        mOnUIRefreshListener = onUIRefreshListener;
    }
}
