package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.util.EditsChangeCheckUtil;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.util.UtilString;


public class YR_OtherIndicatorsActivity extends DBActivity {

    private XCTitleCommonLayout xcTitleCommonLayout;
    /** 依次为ALT,AST,DNA */
    private EditText et_alt,et_ast,et_dna;

    EditsChangeCheckUtil.textChangeListener textChangeListener;

    /** 上个页面传过来的检查数据model ，第一次进入数据为空，第二次以后进入传入第一次保存的数据，然后显示 */
    DrCaseVOBean mDrCaseVOBean;

    /** 判断从上个页面进入时是否有当前页面数据的标识（如果一个都没有，保存按钮不能点击） */
    boolean isHasData = false;
    /** 判断是否全部控件为空的标识 */
    boolean isAllEmpty = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
     setContentView(R.layout.activity_other_indicators);
        super.onCreate(savedInstanceState);

        initData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_OtherIndicatorsActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    public void initData(){
        mDrCaseVOBean = (DrCaseVOBean) getIntent().getSerializableExtra(XD_EditMedicalRecordActivity.DR_CASE_VO_BEAN);
        if (mDrCaseVOBean != null) {
            et_alt.setText(mDrCaseVOBean.getAlt());
            et_alt.requestFocus();
            et_ast.setText(mDrCaseVOBean.getAst());
            et_dna.setText(mDrCaseVOBean.getHbvDna());
        }

        //判断上个页面传过来是否有数据，如果没有，保存按钮默认不能点击
        if (TextUtils.isEmpty(mDrCaseVOBean.getAlt()) && TextUtils.isEmpty(mDrCaseVOBean.getAst())
                && TextUtils.isEmpty(mDrCaseVOBean.getHbvDna())) {
            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_cccccc));
            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setEnabled(false);
            isHasData = false;
        } else {
            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setEnabled(true);
            isHasData = true;
        }
    }


    @Override
    public void initWidgets() {
        xcTitleCommonLayout = getViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonLayout.setTitleCenter(true, "其它检查");
        xcTitleCommonLayout.setTitleRight2(true, 0, "保存");
        xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_cccccc));
        xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setEnabled(false);
        xcTitleCommonLayout.setTitleLeft(true, "取消");
        xcTitleCommonLayout.getXc_id_titlebar_left_imageview().setVisibility(View.GONE);

        et_alt = (EditText) findViewById(R.id.et_alt);
        et_ast = (EditText) findViewById(R.id.et_ast);
        et_dna = (EditText) findViewById(R.id.et_dna);
        //设置HBV-DNA最大字符上限
        InputFilter[] filters = {new InputFilter.LengthFilter(
                GlobalConfigSP.getLimitValue(GlobalConfigSP.HBV_DNA, 0, 10))};
        et_dna.setFilters(filters);
    }

    @Override
    public void listeners() {
        //右侧保存按钮
        xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });

        //保存按钮
        textChangeListener =
                new EditsChangeCheckUtil.textChangeListener(xcTitleCommonLayout.getXc_id_titlebar_right2_textview()){

                    @Override
                    public boolean btnChange() {
                        isAllEmpty = super.btnChange();
                        if (!isHasData && !isAllEmpty) {
                            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_cccccc));
                            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setEnabled(false);
                        } else {
                            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
                            xcTitleCommonLayout.getXc_id_titlebar_right2_textview().setEnabled(true);
                        }

                        return isAllEmpty;
                    }
                };


        textChangeListener.addAllEditText(et_alt,et_ast,et_dna);

        //左侧取消按钮，判断是否有数据，有弹出阻断dialog
        xcTitleCommonLayout.getXc_id_titlebar_left_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isHasData && !isAllEmpty) {
                    myFinish();
                } else {
                    showDialog();
                }
            }
        });

    }

    @Override
    public void onBackPressed() {//手机返回键阻止
        if (!isHasData && !isAllEmpty) {
            super.onBackPressed();
        } else {
            showDialog();
        }

    }

    @Override
    public void onNetRefresh() {

    }


    /** 点击取消按钮，如果输入框有数据，弹出阻止dialog */
    private void showDialog() {
        YR_CommonDialog dialog = new YR_CommonDialog(this, "放弃保存吗？", "放弃", "取消") {
            @Override
            public void confirmBtn() {
                dismiss();

            }

            @Override
            public void cancelBtn() {
                super.cancelBtn();
                YR_OtherIndicatorsActivity.this.finish();
            }
        };
        dialog.setCancelable(false);
        dialog.show();
    }


    /**
     * 点击保存按钮，需要判断取值范围
     *
     * 保存完，直接退出页面
     * */
    public void save() {
        String alt = et_alt.getText().toString();
        String ast = et_ast.getText().toString();
        String dna = et_dna.getText().toString();

        if (!TextUtils.isEmpty(alt)) {
            long iAlt = UtilString.toInt(alt);
            long altMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.ALT, 0, 1000);
            long altMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.ALT, 1, 0);

            if (iAlt < altMin || iAlt > altMax || !chk(alt)) {
                shortToast("请输入真实ALT");
                return;
            }
        }

        if (!TextUtils.isEmpty(ast)) {
            long iAst = UtilString.toInt(ast);
            long astMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.AST, 0, 1000);
            long astMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.AST, 1, 0);

            if (iAst < astMin || iAst > astMax || !chk(ast)) {
                shortToast("请输入真实AST");
                return;
            }
        }

        if (StringUtils.containsEmoji(dna)) {
            shortToast("请输入真实HBV_DNA");
            return;
        }

        shortToast("保存成功");
        if (mDrCaseVOBean == null) {
            mDrCaseVOBean = new DrCaseVOBean();
        }
        mDrCaseVOBean.setAlt(alt);
        mDrCaseVOBean.setAst(ast);
        mDrCaseVOBean.setHbvDna(dna);

        Intent intent = new Intent();
        intent.putExtra(XD_EditMedicalRecordActivity.DR_CASE_VO_BEAN,mDrCaseVOBean);
        setResult(RESULT_OK, intent);
        myFinish();
    }


    /** 这则匹配填入数据的正确性 */
    private boolean  chk(String str) {
        String  patrn = "0|([1-9]\\d*)";

        try{
            if(str.matches(patrn)){
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }

}
