package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_ErrorPromptEditText;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilMd5;
import com.xiaocoder.android.fw.general.util.UtilRSA;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @description 修改密码界面
 * Created by 赖善琦 on 2015/6/17.
 * @version 2.0.0
 */
public class SK_ChangePassWdActivity extends DBActivity {
    private XCTitleCommonLayout titleCommonFragment;
    /** 输入手机号控件  */
    private EditText sk_id_changepw_phone_et;
    /** 输入验证码控件 */
    private EditText sk_id_changepw_verc_et;
    /** 发送验证码按钮 */
    private TextView sk_id_changepw_verc_btn;
    /** 输入密码控件 */
    private YR_ErrorPromptEditText sk_id_changepw_passwd_et;
    private Timer mTimer;
    private TimerTask mTask;
    private int mTime = 60;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sk_l_activity_change_passwd);
        super.onCreate(savedInstanceState);
        mTimer = new Timer();

    }

    /** created by songxin,date：2016-4-22,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SK_ChangePassWdActivity.class);
    }
    /** created by songxin,date：2016-4-22,about：bi,end */

    @Override
    public void initWidgets() {

        titleCommonFragment = getViewById(R.id.xc_id_model_titlebar);
        titleCommonFragment.setTitleLeft(true, "");
        titleCommonFragment.setTitleCenter(true, "修改密码");
        titleCommonFragment.setTitleRight2(true, 0, "确定");

        sk_id_changepw_phone_et = getViewById(R.id.sk_id_changepw_phone_et);
        sk_id_changepw_verc_et = getViewById(R.id.sk_id_changepw_verc_et);
        sk_id_changepw_verc_btn = getViewById(R.id.sk_id_changepw_verc_btn);
        sk_id_changepw_passwd_et = getViewById(R.id.sk_id_changepw_passwd_et);
        sk_id_changepw_phone_et.setText(UtilSP.getUserPhone());
        if(!"".equals(UtilSP.getUserPhone())){
            sk_id_changepw_phone_et.setSelection(sk_id_changepw_phone_et.getText().toString().trim().length());
            sk_id_changepw_phone_et.setEnabled(false);
        }
        // update by 崔毅然 on 2016-8-2  V2.6 修改输入框错误提示方式  start
        int maxPwLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PASSWORD, 0, 19);
        int minPwLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PASSWORD, 1, 6);
        sk_id_changepw_passwd_et.sx_clearEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxPwLength)});
        sk_id_changepw_passwd_et.setLimitAttrs(YR_ErrorPromptEditText.PWD_REGULAR, minPwLength, maxPwLength);
        sk_id_changepw_passwd_et.sx_clearEditText.setHint("请输入" + minPwLength + "-" + maxPwLength + "位字符");
        // update by 崔毅然 on 2016-8-2  V2.6 修改输入框错误提示方式  end
    }

    @Override
    public void listeners() {
        sk_id_changepw_verc_btn.setOnClickListener(this);
        titleCommonFragment.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changePassword(sk_id_changepw_verc_et.getText().toString().trim(),sk_id_changepw_phone_et.getText().toString().trim(),
                        sk_id_changepw_passwd_et.sx_clearEditText.getText().toString().trim(), UtilSP.getPublicKey());
            }
        });

    }



    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.sk_id_changepw_verc_btn:{
                String username = sk_id_changepw_phone_et.getText().toString().trim();
                if(UtilString.isBlank(username)){
                    shortToast("手机号不能为空");
                    return;
                }
                if(!UtilString.isPhoneNum(username)){
                    shortToast("手机号格式不正确");
                    return;
                }
                getCurtentTime(username);
                break;
            }
        }

    }

    /**
     * 请求验证码
     * @param phoneNumber :医生输入手机号码
     * @param actionType ：功能类型(1/注册；2/忘记密码；3/修改手机号)
     */
    private void requestVcode(String phoneNumber,String actionType,String currentTime){
        //发送请求
        RequestParams params = new RequestParams();
        params.put("phoneNum", phoneNumber);
        params.put("actionType", actionType);
        params.put("t", currentTime);
        params.put("sign", UtilMd5.MD5Encode("actionType="+actionType+"&phoneNum="+phoneNumber+"&t="+currentTime+AppConfig.SECRET_KEY));

        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.sendSms), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if(result_boolean){
                    sk_id_changepw_verc_btn.setEnabled(false);
                    mTask = new TimerTask() {
                        @Override
                        public void run() {

                            runOnUiThread(new Runnable() { // UI thread
                                @Override
                                public void run() {
                                    if (mTime <= 0) {
                                        sk_id_changepw_verc_btn.setEnabled(true);
                                        sk_id_changepw_verc_btn.setText("重新获取");
                                        sk_id_changepw_verc_btn.setTextColor(getResources().getColor(R.color.c_e2231a));
                                        mTask.cancel();
                                    } else {
                                        sk_id_changepw_verc_btn.setText(mTime + "s后重新获取");
                                        sk_id_changepw_verc_btn.setTextColor(getResources().getColor(R.color.c_7b7b7b));
                                    }
                                    mTime--;
                                }
                            });
                        }
                    };
                    mTime = 60;
                    mTimer.schedule(mTask, 0, 1000);
                }

            }
            @Override
            public void onFinish() {
                super.onFinish();
                // 处理code操作
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SK_ChangePassWdActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });

    }

    private void getCurtentTime(final String username){
        try {
            //发送请求
            RequestParams params = new RequestParams();
            XCHttpAsyn.postAsyn(false, SK_ChangePassWdActivity.this, AppConfig.getHostUrl(AppConfig.get_time), params, new XCHttpResponseHandler() {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if(result_boolean){
                        long time = ((List<Long>)result_bean.get("data")).get(0);
                        requestVcode(username, "4",time+"");
                    }
                }
            });
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 请求修改密码接口
     * @param verifyCode 验证码
     * @param username 手机号
     * @param password 密码
     * @param pubKey 公钥
     */
    private void changePassword(String verifyCode,String username,String password,String pubKey){
        //验证
        if (UtilString.isBlank(username)) {
            shortToast("请输入手机号");
            return;
        }
        if (UtilString.isBlank(verifyCode)) {
            shortToast("请输入验证码");
            return;
        }
        if(!UtilString.isPhoneNum(username)){
            shortToast("手机号格式不对，请重新输入");
            return;
        }
        if (!sk_id_changepw_passwd_et.setErrorText()){
            sk_id_changepw_passwd_et.errorInfo_tv.setVisibility(View.VISIBLE);
            return;
        }
        //发送请求
        RequestParams params = new RequestParams();
        params.put("phoneNum", username);
        params.put("verifyCode", verifyCode);
        params.put("newPwd", UtilRSA.encryByRSA(pubKey, password));
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.login_setDoctorPwd), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    shortToast("修改成功");
                    finish();
                }
            }
            @Override
            public void onFinish() {
                super.onFinish();
                // update by 崔毅然 on 2016-8-9  修改返回错误msg为显示红字
                if (null != result_bean) {
                    if (!GeneralReqExceptionProcess.checkCode(SK_ChangePassWdActivity.this,
                            getCode(), "")){
                        sk_id_changepw_passwd_et.errorInfo_tv.setText(getMsg());
                        sk_id_changepw_passwd_et.errorInfo_tv.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
    }

}
