package com.qlk.ymz.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.DiagnoseActivity;
import com.qlk.ymz.adapter.DiagnoseCommonAdapter;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.model.DiagnoseCommonBean;
import com.qlk.ymz.model.ResponseBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.view.PinnedHeaderExpandableListView;
import com.qlk.ymz.view.XCSlideBar_V2;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.ListUtil;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * 常用诊断
 * @author wpq
 * @version 1.0
 */
public class DiagnoseCommonFragment extends DBFragment{

    private PinnedHeaderExpandableListView mPinnedHeaderExpandableListView;
    private TextView mTvSlideDialog;
    private XCSlideBar_V2 mSlideBar;

    private List<DiagnoseCommonBean> mList = new ArrayList<>();
    private DiagnoseCommonAdapter mAdapter;

    public static DiagnoseCommonFragment newInstance() {
        return new DiagnoseCommonFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return init(inflater, R.layout.fragment_diagnose_common);
    }

    @Override
    public void initWidgets() {
        mPinnedHeaderExpandableListView = getViewById(R.id.pinnedHeaderExpandableListView);
        mTvSlideDialog = getViewById(R.id.tv_slideDialog);
        mSlideBar = getViewById(R.id.slideBar);

        mSlideBar.setTextView(mTvSlideDialog); // 字母显示

        @SuppressLint("InflateParams")
        View header = LayoutInflater.from(getActivity()).inflate(R.layout.view_diagnose_common_header, null);
        // 低版本中addHeaderView必须在setAdapter之前，否则报错。refs: http://blog.csdn.net/androiddevelop/article/details/8474939
        mPinnedHeaderExpandableListView.addHeaderView(header);
        // 添加悬浮view的布局
        final View mHeaderView = View.inflate(getActivity(), R.layout.xc_l_adapter_patient_letter_out_item, null);
        mPinnedHeaderExpandableListView.setHeaderView(mHeaderView);
        // ListView中有headerView
        mPinnedHeaderExpandableListView.setHasHeaderView(true);
        // 给悬浮字母View添加数据
        mPinnedHeaderExpandableListView.setPinnedableView(new PinnedHeaderExpandableListView.Pinnedable() {
            @Override
            public void setHeaderData(int groupPosition) {
                if (mAdapter == null || groupPosition < 0) {
                    return;
                }
                String groupData = mAdapter.getGroup(groupPosition).key;
                TextView textView = (TextView) mHeaderView.findViewById(R.id.xc_id_fragment_search_letter_view);
                textView.setText(groupData);
            }
        });
        mPinnedHeaderExpandableListView.setAdapter(mAdapter = new DiagnoseCommonAdapter(mList));
        mPinnedHeaderExpandableListView.setVisibility(View.GONE);
    }

    @Override
    public void listeners() {
        mPinnedHeaderExpandableListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                return true;
            }
        });
        mPinnedHeaderExpandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                try {
                    Activity activity = getActivity();
                    if (activity instanceof DiagnoseActivity) {
                        ((DiagnoseActivity) activity).insertDiagnose(mAdapter.getChild(groupPosition, childPosition));
                    }
                } catch (Exception e) {}
                return false;
            }
        });
        // 字母滑动监听
        mSlideBar.setOnTouchingLetterChangedListener(new XCSlideBar_V2.OnTouchingLetterChangedListener() {
            @Override
            public void onTouchingLetterChanged(String s) {
                for (int i = 0; i < mList.size(); i++) {
                    if (s.equals(mList.get(i).key)) {
                        mPinnedHeaderExpandableListView.setSelectedGroup(i);
                    }
                }
            }
        });
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        requestCommonDiagnoses();
    }

    /** 请求常用诊断数据 */
    @SuppressLint("InflateParams")
    private void requestCommonDiagnoses() {
        XCHttpAsyn.postAsyn(false, getActivity(), AppConfig.getTuijianUrl(AppConfig.DIAGNOSE_LIST), new RequestParams(), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                try {
                    // {"code":0,"msg":"成功","data":[{"key":"A","voList":[{"id":17,"name":"a","type":1}]},{"key":"B","voList":[{"id":16,"name":"b","type":1}]}]}
                    ResponseBean<List<DiagnoseCommonBean>> responseBean = new Gson().fromJson(new String(arg2), new TypeToken<ResponseBean<List<DiagnoseCommonBean>>>() {}.getType());
                    if (responseBean == null || !GeneralReqExceptionProcess.checkCode(getActivity(), String.valueOf(responseBean.code), responseBean.msg)) {
                        return;
                    }

                    List<DiagnoseCommonBean> listHttp = responseBean.data;
                    listHttp = ListUtil.filterNullElements(listHttp);
                    mList.clear();
                    mList.addAll(listHttp);
                    mAdapter.notifyDataSetChanged();
                    mPinnedHeaderExpandableListView.setVisibility(View.VISIBLE);

                    // 全部展开
                    for (int i = 0; i < mAdapter.getGroupCount(); i++) {
                        mPinnedHeaderExpandableListView.expandGroup(i);
                    }

                    // 刷新右侧字母
                    ArrayList<String> slideData = new ArrayList<>();
                    for (DiagnoseCommonBean commonBean : mList) {
                        slideData.add(commonBean.key);
                    }
                    mSlideBar.setABC(slideData);
                    mSlideBar.invalidate();
                } catch (Exception e) {}
            }
        });
    }

}
