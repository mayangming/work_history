package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.YR_AddGroupPatientAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.parse.Parse2PatientBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.PinnedHeaderExpandableListView;
import com.qlk.ymz.view.XCSlideBar_V2;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 添加患者页
 *
 * @author 崔毅然 2016-1-9
 * @version 2.0
 */
public class YR_AddPatientActivity extends DBActivity {
    /** 从接口获得的字母list（有患者的字母） */
    private ArrayList<String> parentList = new ArrayList<>();
    /** 按字母分组的所有患者list */
    private List<List<XC_ChatModel>> childList = new ArrayList<>();
    /** 右侧字母滑条 */
    private XCSlideBar_V2 xc_id_fragment_search_slide_slidebar;
    /** 屏幕中间弹出的字母 */
    private TextView xc_id_fragment_search_slide_dialog;
    /** 患者可扩展列表 */
    private PinnedHeaderExpandableListView xc_id_fragment_search_slide_listview;
    /** 添加患者适配器 */
    private YR_AddGroupPatientAdapter addGroupPatientAdapter;
    /** 无数据显示 */
    private LinearLayout xl_nodata_rl;
    /** 分组ID */
    private String mGroupId;
    /** 无数据跳转按钮 */
    private Button xc_id_data_zero_do_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xc_l_activity_add_patient);
        mGroupId = getIntent().getStringExtra(YR_PatientGroupManagerActivity.GROUP_ID);
        super.onCreate(savedInstanceState);

        initTitle();

        requestPatientList();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_AddPatientActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    /** 初始化title */
    public void initTitle(){
        findViewById(R.id.sx_id_title_left).setOnClickListener(this);
        ((TextView)findViewById(R.id.sx_id_title_center)).setText("添加成员");
        TextView sx_id_title_right_btn = (TextView) findViewById(R.id.sx_id_title_right_btn);
        sx_id_title_right_btn.setVisibility(View.VISIBLE);
        sx_id_title_right_btn.setText("完成");
        sx_id_title_right_btn.setOnClickListener(this);
        findViewById(R.id.sx_id_title_right).setVisibility(View.GONE);
    }

    @Override
    public void initWidgets() {
        xl_nodata_rl = getViewById(R.id.xl_nodata_rl);
        ((TextView) getViewById(R.id.id_zero_data_tv)).setText("无可供选择的患者");
        xc_id_data_zero_do_button = (Button) findViewById(R.id.xc_id_data_zero_do_button);
        xc_id_data_zero_do_button.setVisibility(View.VISIBLE);
        xc_id_data_zero_do_button.setText(Html.fromHtml("快邀请<font color='#e2231a'>手机联系人</font>成为我的患者吧！"));
        xc_id_data_zero_do_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myStartActivity(XL_ContactsInviteActivity.class);
            }
        });

        // 初始化右侧字母列表bar和字母提示dialog
        xc_id_fragment_search_slide_dialog = getViewById(R.id.xc_id_fragment_search_slide_dialog);
        xc_id_fragment_search_slide_slidebar = getViewById(R.id.xc_id_fragment_search_slide_slidebar);
        xc_id_fragment_search_slide_slidebar.setTextView(xc_id_fragment_search_slide_dialog);

        xc_id_fragment_search_slide_listview = (PinnedHeaderExpandableListView)findViewById(R.id.xc_id_fragment_search_slide_listview);
        // 添加悬浮view的布局
        final View mHeaderView = View.inflate(this, R.layout.xc_l_adapter_patient_letter_out_item, null);
        xc_id_fragment_search_slide_listview.setHeaderView(mHeaderView);
        addGroupPatientAdapter = new YR_AddGroupPatientAdapter(childList, parentList, YR_AddPatientActivity.this);
        xc_id_fragment_search_slide_listview.setAdapter(addGroupPatientAdapter);
        // 给悬浮字母View添加数据
        xc_id_fragment_search_slide_listview.setPinnedableView(new PinnedHeaderExpandableListView.Pinnedable() {
            @Override
            public void setHeaderData(int groupPosition) {
                if (groupPosition < 0)
                    return;
                String groupData = addGroupPatientAdapter.getGroupDate().get(groupPosition);
                ((TextView) mHeaderView.findViewById(R.id.xc_id_fragment_search_letter_view)).setText(groupData);
            }
        });

    }

    @Override
    public void listeners() {
        // 右侧字母列表的滑动监听
        xc_id_fragment_search_slide_slidebar.setOnTouchingLetterChangedListener(new XCSlideBar_V2.OnTouchingLetterChangedListener() {

            @Override
            public void onTouchingLetterChanged(String s) {
                //获得手指按压的字母位置，患者列表滑动到相应字母位置
                Integer position = addGroupPatientAdapter.getPositionFromLetter(s);
                if (position != null) {
                    xc_id_fragment_search_slide_listview.setSelection(position);
                }
            }
        });
        // 返回true，不会收缩(点击效果还在)，即在调用allExpand后， 再设置该监听，即可达到全部展示不会收缩的效果
        xc_id_fragment_search_slide_listview.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                return true;
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.sx_id_title_right_btn:
                List<XC_ChatModel> addPatient = addGroupPatientAdapter.getAddPatient();
                //将添加状态的患者id，拼成字符串
                if (addPatient.size() > 0) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < addPatient.size(); i++) {
                        if (i == addPatient.size() - 1) {
                            sb.append(addPatient.get(i).getUserPatient().getPatientId());
                        } else {
                            sb.append(addPatient.get(i).getUserPatient().getPatientId() + ",");
                        }
                    }
                    addPatient(sb.toString());
                } else {
                    shortToast("您还没有选择患者");
                }
                break;
            case R.id.sx_id_title_left:
                myFinish();
                break;
        }
    }

    /**
     * 批量请求添加分组患者
     * @param patientIds 请求添加的患者id拼成的字符串，以","号隔开
     * */
    private void addPatient(String patientIds) {
        RequestParams params = new RequestParams();
        params.put("groupId", mGroupId);
        params.put("patientIds", patientIds);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.patientGroup_addUser), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    resultData();
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YR_AddPatientActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /** 添加成功后，将新添加的成员返回上个页面 */
    public void resultData(){
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        myFinish();
    }

    // 无网络时,点击遮罩重新请求
    @Override
    public void onNetRefresh() {
        requestPatientList();
    }

    /** 获得当前分组的患者列表 */
    public void requestPatientList() {
        RequestParams params = new RequestParams();
        params.put("groupId", mGroupId);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.patient_abclist), params, new XCHttpResponseHandler(this) {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    Parse2PatientBean.parseABCList(parentList, childList, result_bean);
                    updateParentAndChild();
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YR_AddPatientActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 更新parentList和childList
     */
    public void updateParentAndChild() {
        if (parentList != null && childList != null && parentList.size() > 0 && childList.size() > 0) {
            xl_nodata_rl.setVisibility(View.GONE);
            //动态设置右侧字母表,只显示接口实际获得的字母
            xc_id_fragment_search_slide_slidebar.setABC(parentList);
            addGroupPatientAdapter.updateABCPosition();
            addGroupPatientAdapter.notifyDataSetChanged();
            allExpandList();
        } else {   //没有患者的时候，显示无数据遮罩
            xl_nodata_rl.setVisibility(View.VISIBLE);
        }
    }

    /** 初始化abc患者列表全部展开 */
    public void allExpandList() {
        int count = addGroupPatientAdapter.getGroupCount();
        for (int i = 0; i < count; i++) {
            if (!xc_id_fragment_search_slide_listview.isGroupExpanded(i)) {
                xc_id_fragment_search_slide_listview.expandGroup(i);
            }
        }
    }

}
