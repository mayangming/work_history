package com.qlk.ymz.activity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;

import com.handmark.pulltorefresh.library.ILoadingLayout;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshExpandableListView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.YY_FeedbackRecordAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.YY_FeedbackRecordBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilView;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.XC_VisitDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.LinkedList;
import java.util.List;

/**
 * @author shuYanYi on 2016/11/07.
 * @description 随访记录
 * @version V2.6.5
 */
public class YY_FeedbackRecordActivity extends DBActivity implements PullToRefreshExpandableListView.OnRefreshListener2 {

    /**标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** 拉动刷新控件*/
    private PullToRefreshExpandableListView pull_list;
    /** 数据视图*/
    private ExpandableListView listView;
    /** 随访就适配器*/
    YY_FeedbackRecordAdapter adapter;
    /** 视频详情数据pojo*/
    YY_FeedbackRecordBean.DataBean recordBean;
    /** 保存请求获取到的全部记录*/
    private List<YY_FeedbackRecordBean.DataBean.ResultBean> allRecords = new LinkedList();
    /** 随访详情对话框*/
    private XC_VisitDialog visitDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yy_l_feedback_record);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-22,about：saveInfo,begin
        BiUtil.saveBiInfo(YY_FeedbackRecordActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-22,about：saveInfo,end
        requestData(1);
    }


    /** created by songxin,date：2016-8-16,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YY_FeedbackRecordActivity.class);
    }
    /** created by songxin,date：2016-8-16,about：bi,end */

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "随访记录");
        xc_id_model_titlebar.setTitleLeft(true, null);
        xc_id_model_titlebar.setTitleRight2(true,0,"随访模板");
        pull_list = getViewById(R.id.pull_list);
        listView = pull_list.getRefreshableView();
        listView.setGroupIndicator(null);
        adapter = new YY_FeedbackRecordAdapter(this,allRecords);
        listView.setAdapter(adapter);
        //无数据设置
        View emptyView = UtilView.getEmptyView(this,"暂无随访记录");
        //避免无数据布局出现延长线
        emptyView.setBackgroundColor(getResources().getColor(R.color.c_white_ffffff));
        pull_list.setEmptyView(emptyView);
        //上下拉刷新控件设置
        pull_list.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
        ILoadingLayout startLabels = pull_list.getLoadingLayoutProxy(true, false);
        startLabels.setPullLabel("下拉刷新...");// 刚下拉时，显示的提示
        startLabels.setRefreshingLabel("正在载入...");// 刷新时
        startLabels.setReleaseLabel("放开刷新...");// 下来达到一定距离时，显示的提示

        ILoadingLayout endLabels = pull_list.getLoadingLayoutProxy(false, true);
        endLabels.setPullLabel("上拉刷新...");// 刚下拉时，显示的提示
        endLabels.setRefreshingLabel("正在载入...");// 刷新时
        endLabels.setReleaseLabel("放开刷新...");// 下来达到一定距离时，显示的提示
        pull_list.getRefreshableView().setSelector(new ColorDrawable(Color.TRANSPARENT));
    }

    @Override
    public void listeners() {
        xc_id_model_titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myStartActivity(YY_TemplateListActivity.class);
            }
        });
        pull_list.setOnRefreshListener(this);

        listView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                return true;
            }
        });
        //随访详情点击
        adapter.setOnVisitInfoClickListener(new YY_FeedbackRecordAdapter.OnVisitInfoClickListener() {
            @Override
            public void onClick(YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean.VisitInfoBean visitInfoBean) {
                String visitId = visitInfoBean.getVisitId();
                String patientId = visitInfoBean.getPatientId();
                showVisitDialog(visitId,patientId);
            }
        });
    }
    @Override
    public void onPullDownToRefresh(PullToRefreshBase refreshView) {
        requestData(1);
    }

    @Override
    public void onPullUpToRefresh(PullToRefreshBase refreshView) {
        requestData(recordBean.getNextPage());
    }

    @Override
    public void onNetRefresh() {
       requestData(1);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(final View v) {
        super.onClick(v);
    }

    /**
     * 请求随访记录数据
     * @param page
     */
    private void requestData(final int page){
            RequestParams params = new RequestParams();
            params.put("doctorId", UtilSP.getUserId());
            params.put("page", page);
            params.put("num", 10);
            XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.feedback_record_list), params, new XCHttpResponseHandler<YY_FeedbackRecordBean>(this, YY_FeedbackRecordBean.class) {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    //测试数据，暂保留注释，真实数据不好造
                    //setTestData("{\"code\":0,\"msg\":\"成功\",\"data\":[{\"pageNo\":1,\"pageSize\":10,\"orderBy\":null,\"order\":null,\"result\":[{\"visitMonth\":\"2016年11月\",\"visitInfoInMonth\":[{\"visitDate\":\"21日\",\"visitInfo\":[{\"visitId\":83,\"patientId\":49386,\"patientName\":\"一二三四五六七八九十一二三四五六七八九十\",\"visitStatus\":1,\"visitTime\":\"18:29\"},{\"visitId\":82,\"patientId\":49386,\"patientName\":\"七乐康患者\",\"visitStatus\":1,\"visitTime\":\"18:28\"},{\"visitId\":81,\"patientId\":49386,\"patientName\":\"七乐康患者\",\"visitStatus\":0,\"visitTime\":\"18:09\"},{\"visitId\":76,\"patientId\":49386,\"patientName\":\"七乐康患者\",\"visitStatus\":0,\"visitTime\":\"17:53\"}]}]}],\"totalCount\":4,\"totalPages\":1,\"hasNext\":false,\"nextPage\":1,\"orderBySetted\":false,\"hasPre\":false,\"prePage\":1,\"first\":0}]}",YY_FeedbackRecordBean.class);
                    if (!result_boolean) {
                        return;
                    }
                    List<YY_FeedbackRecordBean.DataBean> objLists = mResultModel.getData();
                    if (objLists == null && objLists.size() == 0) {
                        return;
                    }
                    recordBean = objLists.get(0);
                    List<YY_FeedbackRecordBean.DataBean.ResultBean> result = recordBean.getResult();
                    //是否有下一页
                    if(recordBean.isHasNext()){
                        pull_list.setMode(PullToRefreshBase.Mode.BOTH);
                    }else{
                        pull_list.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
                    }
                    //获取刷新前组标题的数量
                    int lastSize = adapter.getGroupCount();

                    //第一页的请求即是进页面或下拉刷新、要清列表数据
                    if(page == 1) {
                        allRecords.clear();
                    }
                    //下一页的数据和上一页最后数据 同月份或同日期的情况
                    mergeNextPageSameDay(result);

                    allRecords.addAll(result);
                    adapter.update(allRecords,listView);
                    adapter.notifyDataSetChanged();

                }

                // 对账户冻结情况的判断处理
                public void onFinish() {
                    super.onFinish();
                    pull_list.onRefreshComplete();
                    if (null != result_bean && GeneralReqExceptionProcess.checkCode(YY_FeedbackRecordActivity.this,
                            getCode(),
                            getMsg())) {
                    }
                }

                /**
                 * 下一页的数据和上一页最后数据 合并同月份或同日期的情况，为了UI展示时同日子的患者信息合并到圆角卡片里
                 * @param newPageResult 新页面的数据
                 */
                private void mergeNextPageSameDay(List<YY_FeedbackRecordBean.DataBean.ResultBean> newPageResult) {
                    if(page > 1){
                        //上一页最后月节点
                        YY_FeedbackRecordBean.DataBean.ResultBean lastMonthItem = allRecords.get(allRecords.size() - 1);
                        //上一页最后的月
                        String lastMoth = lastMonthItem.getVisitMonth();
                        //上一页最后月的日节点集合
                        List<YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean> lastDayInfoList = lastMonthItem.getVisitInfoInMonth();
                        //上一页最后月的最后的日节点
                        YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean lastDateItem = lastDayInfoList.get(lastDayInfoList.size() - 1);
                        //上一页最后一日
                        String lastDay = lastDateItem.getVisitDate();


                        //把新一页的数据，同月/同日的数据 合并到同样的展示list里
                        //新页第一个月节点
                        YY_FeedbackRecordBean.DataBean.ResultBean newMonthItem = newPageResult.get(0);
                        if(!newMonthItem.getVisitMonth().equals(lastMoth)){
                            return;
                        }
                        //开始合并处理
                        //新页第一个月的日集合
                        List<YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean> newDayInfoList = newMonthItem.getVisitInfoInMonth();
                        //遍历新页的日信息集合，同日的取日节点里多个患者info剪切过去上一页的数据里，不同日的，只把日节点合并到上一页的日数据集合里。
                        for(YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean newDayItem : newDayInfoList){
                            String newDay = newDayItem.getVisitDate();
                            if(newDay.equals(lastDay)){
                                //同日，合并日节点(新页同日里的多个患者info剪切过去上一页的数据里)
                                lastDateItem.getVisitInfo().addAll(newDayItem.getVisitInfo());
                            }else{
                                //不同日 (新页日数据集合剪切到上一页的数据里)
                                lastDayInfoList.add(newDayItem);
                            }
                        }

                        //删除处理完的新页第一个节点
                        newPageResult.remove(0);
                    }
                }

            });

        }


    /**
     * 显示随访详情
     * @param visitId
     * @param patientId
     */
    private void showVisitDialog(String visitId,String patientId){
        if(visitDialog == null){
            visitDialog = new XC_VisitDialog(this);
        }
        visitDialog.show(visitId,patientId);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        UtilViewShow.destoryDialogs(visitDialog);
    }
}
