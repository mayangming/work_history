package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.util.List;

/**
 * @description 支持银行列表
 * Created by 赖善琦 on 2015/6/17.
 * @version 2.0.0
 */
public class SK_BankCardActivityV2 extends DBActivity {
    /** 返回数据的key */
    public static String BANK_CARD_NAME = "bankCardName";
    /** 银行列表数据 */
    private XCListViewFragment listViewFragment;
    private XCTitleCommonLayout titlebar;
    /** 银行列表适配器 */
    private SK_BankCardAdapter adapter;

    /** 由于是重用的布局，这个是重用的View，此页面隐藏 */
    private RelativeLayout sk_id_delete_bank_card_rl;
    /** 由于是重用的布局，这个是重用的View，此页面隐藏 */
    private RelativeLayout sk_id_add_bank_card_rl;
    /** 银行数据 */
    private List<XCJsonBean> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sk_l_activity_bank_card_v2);
        super.onCreate(savedInstanceState);

        requestData();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SK_BankCardActivityV2.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    /**
     * 初始化控件
     */
    @Override
    public void initWidgets() {
        listViewFragment = new XCListViewFragment();
        adapter = new SK_BankCardAdapter(this,null);
        listViewFragment.setAdapter(adapter);
        addFragment(R.id.sk_id_bank_card_list, listViewFragment);
        listViewFragment.setAdapter(new SK_BankCardAdapter(this, null));

        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "选择银行");
        titlebar.setTitleLeft(true,"");

        sk_id_delete_bank_card_rl = getViewById(R.id.sk_id_delete_bank_card_rl);
        sk_id_delete_bank_card_rl.setVisibility(View.GONE);
        sk_id_add_bank_card_rl = getViewById(R.id.sk_id_add_bank_card_rl);
        sk_id_add_bank_card_rl.setVisibility(View.GONE);
        initChioseItemListenr();
    }

    /**
     * 列表item事件
     */
    public void initChioseItemListenr(){
        listViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                XCJsonBean bean = (XCJsonBean) arg0.getItemAtPosition(arg2);
                XCJsonBean bankBean = new XCJsonBean();
                bankBean.setString("bId", bean.getString("bId"));
                bankBean.setString("bName", bean.getString("bName"));
                Intent it = new Intent();
                it.putExtra(BANK_CARD_NAME, bankBean);
                setResult(Activity.RESULT_OK, it);
                dShortToast(bean.toString());
                myFinish();
            }
        });
    }

    @Override
    public void listeners() {

    }

    /**
     * 请求获取支持的银行列表
     */
    private void requestData() {
        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.bank_banks), new RequestParams(), new XCHttpResponseHandler(this) {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (!listViewFragment.checkGoOn()) {
                        return;
                    }
                    List<XCJsonBean> result_list = result_bean.getList("data");

                    if (result_list != null) {
                        dataList = result_list;
                        adapter.update(result_list);
                        adapter.notifyDataSetChanged();
                        listViewFragment.updateList(result_list);
                    } else {
                        shortToast("暂无银行信息!");
                    }

                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if(listViewFragment != null){
                    listViewFragment.doRefreshComplete();
                }
                // 处理code操作
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SK_BankCardActivityV2.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 无网络背景点击的回调，重新请求数据
     */
    @Override
    public void onNetRefresh() {
        requestData();
    }

    /**
     * 银行列表适配器
     */
    class SK_BankCardAdapter extends XCBaseAdapter<XCJsonBean>{

        public SK_BankCardAdapter(Context context,List<XCJsonBean> list){
            super(context,list);

        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            XCJsonBean bean = list.get(i);
            ViewHolder holder = null;

            if(view == null){
                view = LayoutInflater.from(context).inflate(R.layout.sk_l_adapter_bank_card_item,null);
                holder = new ViewHolder();
                holder.sk_id_bank_card_content_tv = (TextView)view.findViewById(R.id.sk_id_bank_card_content_tv);
                holder.sk_id_bank_card_num = (TextView)view.findViewById(R.id.sk_id_bank_card_num);
                holder.checkBox = (CheckBox)view.findViewById(R.id.sk_id_bank_card_cb);
                holder.iv = (ImageView)view.findViewById(R.id.sk_id_bank_card_iv);
                holder.sk_id_bank_card_iv_intodetail = (ImageView)view.findViewById(R.id.sk_id_bank_card_iv_intodetail);
                view.setTag(holder);
            }else{
                holder = (ViewHolder) view.getTag();
            }
            holder.sk_id_bank_card_content_tv.setText(bean.getString("bName"));
            holder.sk_id_bank_card_num.setVisibility(View.GONE);
            String bIcon = bean.getString("bIcon");

            XCApplication.displayImage(bIcon,holder.iv);

            holder.checkBox.setVisibility(View.GONE);


            return view;
        }


    }

    class ViewHolder{
        ImageView iv,sk_id_bank_card_iv_intodetail;
        TextView sk_id_bank_card_content_tv,sk_id_bank_card_num;
        CheckBox checkBox;
    }

}
