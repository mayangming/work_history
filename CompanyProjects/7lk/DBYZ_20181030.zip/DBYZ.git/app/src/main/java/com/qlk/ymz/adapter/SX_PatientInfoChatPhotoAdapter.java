package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.SX_ChatPhotoInfo;
import com.xiaocoder.android.fw.general.view.XCNoScrollGridView;

import org.w3c.dom.Text;

import java.util.List;

/**
 * SX_PatientInfoChatPhotoAdapter
 * 聊天图片适配器
 * @author songxin on 2016/4/29.
 * @version 2.3.0
 */
public class SX_PatientInfoChatPhotoAdapter extends BaseAdapter {
    /** 聊天图片适配数据*/
    private List<SX_ChatPhotoInfo.DataEntity.ResultEntity> mResult;
    /** 上下文*/
    private Context mContext;
    /** LayoutInflater*/
    private LayoutInflater mInflater;

    public SX_PatientInfoChatPhotoAdapter(Context context,List<SX_ChatPhotoInfo.DataEntity.ResultEntity> result){
        this.mContext = context;
        mInflater = LayoutInflater.from(context);
        this.mResult = result;
    }
    @Override
    public int getCount() {
        return mResult.size();
    }

    @Override
    public Object getItem(int position) {
        return mResult.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(null == convertView){
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.sx_l_adapter_patient_info_chat_photo_item,null);
            viewHolder.sx_id_chat_phone_date_text = (TextView)convertView.findViewById(R.id.sx_id_chat_phone_date_text);
            viewHolder.sx_id_photo_show = (XCNoScrollGridView)convertView.findViewById(R.id.sx_id_photo_show);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.sx_id_chat_phone_date_text.setText(mResult.get(position).getDate());

        //适配图片
        if(null != mResult.get(position).getImgs()){
            viewHolder.sx_patientChatPhotoShowAdapter = new SX_MedicalRecirdsPhotoShowAdapter(mContext,mResult.get(position).getImgs());
            viewHolder.sx_id_photo_show.setAdapter(viewHolder.sx_patientChatPhotoShowAdapter);
        }

        if(mResult.get(position).isExpand()){
            //显示图片
            viewHolder.sx_id_photo_show.setVisibility(View.VISIBLE);
        }else {
            //隐藏图片
            viewHolder.sx_id_photo_show.setVisibility(View.GONE);
        }
        viewHolder.sx_id_chat_phone_date_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mResult.get(position).setExpand(!mResult.get(position).isExpand());
                notifyDataSetChanged();
            }
        });
        return convertView;
    }

    static class ViewHolder{
        /** 日期显示*/
        TextView sx_id_chat_phone_date_text;
        /** 图片显示*/
        XCNoScrollGridView sx_id_photo_show;
        /** 图片显示适配器*/
        SX_MedicalRecirdsPhotoShowAdapter sx_patientChatPhotoShowAdapter;
    }
}
