package com.qlk.ymz.db.im.chatmodel;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;

/**
 * description: 聊天信息中的宣教内容
 * autour: YM
 * date: 2017/7/11
 * update: $date$
 * version: $version$
 */

public class ChatModelEdu implements Serializable,Cloneable{
    private String eduId = "";//宣教Id
    private String eduUrl = "";//宣教链接
    private String eduOrigin = "";//宣教来源
    private String eduTitle = "";//宣教标题
    private String eduText = "";//宣教信息
    private String eduReadStatus = "0";//宣教内容的读取标志（说明：0：未读，1：已读）
    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
    public String getEduId() {
        return UtilString.f(eduId);
    }

    public void setEduId(String eduId) {
        this.eduId = eduId;
    }

    public String getEduUrl() {
        return UtilString.f(eduUrl);
    }

    public void setEduUrl(String eduUrl) {
        this.eduUrl = eduUrl;
    }

    public String getEduOrigin() {
        return UtilString.f(eduOrigin);
    }

    public void setEduOrigin(String eduOrigin) {
        this.eduOrigin = eduOrigin;
    }

    public String getEduTitle() {
        return UtilString.f(eduTitle);
    }

    public void setEduTitle(String eduTitle) {
        this.eduTitle = eduTitle;
    }

    public String getEduText() {
        return UtilString.f(eduText);
    }

    public void setEduText(String eduText) {
        this.eduText = eduText;
    }

    public String getEduReadStatus() {
        return UtilString.f(eduReadStatus);
    }

    public void setEduReadStatus(String eduReadStatus) {
        this.eduReadStatus = eduReadStatus;
    }
}