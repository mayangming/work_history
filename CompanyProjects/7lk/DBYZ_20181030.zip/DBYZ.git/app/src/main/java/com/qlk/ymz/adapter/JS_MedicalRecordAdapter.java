package com.qlk.ymz.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.JS_MedicalDetailActivity;
import com.qlk.ymz.activity.XC_ChatImageShowActivity;
import com.qlk.ymz.model.MedicalDetailBean;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.StringUtils;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.ArrayList;

/**
 * @description 病历档案列表适配器
 * @author 徐金山
 * @version 1.2.0
 */
public class JS_MedicalRecordAdapter extends BaseAdapter {
    /** 上下文对象 */
    private Context context;
    /** 列表项布局填充器 */
    private LayoutInflater inflater;
    /** 病历档案列表 */
    private ArrayList<MedicalDetailBean> medicalRecordList;
    /** 患者ID */
    private String patientId = "";

    /**
     * 构造方法
     * @param context 上下文对象
     * @param patientId 患者ID
     * @param  medicalRecordList 病历档案列表
     */
    public JS_MedicalRecordAdapter(Context context, String patientId, ArrayList<MedicalDetailBean> medicalRecordList) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.medicalRecordList = medicalRecordList;
        this.patientId = patientId;
    }

    public int getCount() {
        return medicalRecordList.size();
    }

    public long getItemId(int position) {
        return position;
    }

    public Object getItem(int position) {
        return medicalRecordList.get(position);
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;

        if(null == convertView) {
            viewHolder = new ViewHolder();
            convertView = inflater.inflate(R.layout.js_item_medical_record, null);
            viewHolder.tv_time = (TextView) convertView.findViewById(R.id.tv_time);
            viewHolder.tv_hospital_and_department = (TextView) convertView.findViewById(R.id.tv_hospital_and_department);
            viewHolder.tv_medicalRecordInfo = (TextView) convertView.findViewById(R.id.tv_medicalRecordInfo);
            viewHolder.ll_image = (LinearLayout) convertView.findViewById(R.id.ll_image);
            viewHolder.iv_image01 = (ImageView) convertView.findViewById(R.id.iv_image01);
            viewHolder.iv_image02 = (ImageView) convertView.findViewById(R.id.iv_image02);
            viewHolder.iv_image03 = (ImageView) convertView.findViewById(R.id.iv_image03);
            viewHolder.iv_image04 = (ImageView) convertView.findViewById(R.id.iv_image04);
            viewHolder.rl_show_detail = (RelativeLayout) convertView.findViewById(R.id.rl_show_detail);

            viewHolder.imageViewList.add(viewHolder.iv_image01);
            viewHolder.imageViewList.add(viewHolder.iv_image02);
            viewHolder.imageViewList.add(viewHolder.iv_image03);
            viewHolder.imageViewList.add(viewHolder.iv_image04);

            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        // 获取初始化数据
        MedicalDetailBean medicalDetailBean = medicalRecordList.get(position);
        final String date = DateUtils.DateFormat(medicalDetailBean.getVistingTime());
        String hospital = StringUtils.getSuffixSubString(medicalDetailBean.getHospital(), 6, StringUtils.SUFFIX_THREE_POINT);
        String department = StringUtils.getSuffixSubString(medicalDetailBean.getDepartment(), 4, StringUtils.SUFFIX_THREE_POINT);
        String medicalRecordInfo = medicalDetailBean.getDiscription();
        final String caseId = medicalDetailBean.getId();

        // 初始化页面控件的值
        // 问诊日期
        viewHolder.tv_time.setText(date);
        // 医院及科室
        if(UtilString.isBlank(department) || UtilString.isBlank(hospital)){
            viewHolder.tv_hospital_and_department.setText(hospital + department);
        }else {
            viewHolder.tv_hospital_and_department.setText(hospital + "/" + department);

        }
        // 病情描述
        viewHolder.tv_medicalRecordInfo.setText(medicalRecordInfo);
        // 相关图片
        ArrayList<String> imgs = medicalRecordList.get(position).getImgList();
        int imgsSize = imgs.size();
        if(imgsSize > 0) {
            viewHolder.ll_image.setVisibility(View.VISIBLE);

            for(int i=0; i<4; i++) {
                viewHolder.imageViewList.get(i).setVisibility(View.INVISIBLE);
                viewHolder.imageViewList.get(i).setImageResource(R.mipmap.bg_pic_default);
            }

            for(int i=0; i<imgsSize; i++) {
                viewHolder.imageViewList.get(i).setVisibility(View. VISIBLE);
                XCApplication.base_imageloader.displayImage(medicalRecordList.get(position).getImgList().get(i), viewHolder.imageViewList.get(i));
            }
        }else {
            viewHolder.ll_image.setVisibility(View.GONE);
        }

        // 设置控件点击监听事件
        // 点击图片01
        viewHolder.iv_image01.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                toShowImagesActivity(position, 0);
            }
        });
        // 点击图片02
        viewHolder.iv_image02.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                toShowImagesActivity(position, 1);
            }
        });
        // 点击图片03
        viewHolder.iv_image03.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                toShowImagesActivity(position, 2);
            }
        });
        // 点击图片04
        viewHolder.iv_image04.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                toShowImagesActivity(position, 3);
            }
        });

        // 查看详情
        viewHolder.rl_show_detail.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(context, JS_MedicalDetailActivity.class);
                intent.putExtra("patientId", patientId); // 患者ID
                intent.putExtra("caseId", caseId); // 病例ID
                context.startActivity(intent);
            }
        });

        return convertView;
    }

    /**
     * 跳转到大图显示页
     * @param position 被点击的列表项序号
     * @param index 图片序号
     */
    private void toShowImagesActivity(int position, int index) {
        Intent intent = new Intent(context, XC_ChatImageShowActivity.class);
        intent.putExtra(XC_ChatImageShowActivity.PICTURES_KEY, medicalRecordList.get(position).getImgList());
        intent.putExtra(XC_ChatImageShowActivity.INDEX, index);
        context.startActivity(intent);

    }

    /**
     * ViewHolder类
     */
    private class ViewHolder {
        /** 就诊日期 */
        private TextView tv_time;
        /** 就诊医院及就诊科室 */
        private TextView tv_hospital_and_department;
        /** 就诊信息 */
        private TextView tv_medicalRecordInfo;
        /** 图片控件布局 */
        private LinearLayout ll_image;
        /** 就诊相关图片_第一张图片 */
        private ImageView iv_image01;
        /** 就诊相关图片_第二张图片 */
        private ImageView iv_image02;
        /** 就诊相关图片_第三张图片 */
        private ImageView iv_image03;
        /** 就诊相关图片_第四张图片 */
        private ImageView iv_image04;
        /** 查看详情 */
        private RelativeLayout rl_show_detail;
        /** 保存图片控件对象的数组 */
        private ArrayList<ImageView> imageViewList = new ArrayList<ImageView>();
    }
}
