package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PatientGroupByAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 患者分组界面
 */
public class PatientGroupActivity extends DBActivity {
    private XCTitleCommonLayout titlebar;
    private XCListViewFragment listViewFragment;
    //患者分组适配器
    private PatientGroupByAdapter patientGroupAdapter;
    //添加分组控件
    private TextView tv_add_group_btn;
    public static final String PATIENT_GROUP = "patient_group";
    //患者id
    private String mPatientId;
    private List<XCJsonBean> result_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_patient_group);
        super.onCreate(savedInstanceState);
        requestPatientGroupList(true);
    }

    /**
     * 初始化标题
     */
    private void initTitle() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "分组");
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleRight2(true, 0, "保存");
        titlebar.getXc_id_titlebar_right2_textview().setEnabled(false);
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColorStateList(R.color.selector_text_group));
        titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));
    }

    @Override
    public void initWidgets() {
        initTitle();
        if (!TextUtils.isEmpty(getIntent().getExtras().getString(CommonConfig.PATIENT_ID))) {
            mPatientId = getIntent().getExtras().getString(CommonConfig.PATIENT_ID);
        }
        tv_add_group_btn = (TextView) findViewById(R.id.tv_add_group_btn);
        patientGroupAdapter = new PatientGroupByAdapter(this, null);
        listViewFragment = new XCListViewFragment();
        listViewFragment.setAdapter(patientGroupAdapter);
        listViewFragment.setMode(XCListViewFragment.MODE_NOT_PULL);
        listViewFragment.setBgZeroHintInfo("无分组信息!", "", R.mipmap.js_d_icon_no_data);
        listViewFragment.setListViewStyleParam(null, 1, false);
        addFragment(R.id.xc_id_new_patient_list, listViewFragment);
    }

    @Override
    public void listeners() {
        titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        tv_add_group_btn.setOnClickListener(this);
        titlebar.getXc_id_titlebar_right2_textview().setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {
        requestPatientGroupList(true);
    }

    @Override
    protected void onStart() {
        super.onStart();
        //created by songxin,date：2017-9-26,about：bi,begin
        BiUtil.savePid(PatientGroupActivity.class);
        // created by songxin,date：2017-9-26,about：bi,end
        //去掉listView分割线
        listViewFragment.base_abs_listview.setDividerHeight(0);
        //去掉listView拉动时的边框
        listViewFragment.base_abs_listview.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.tv_add_group_btn:
                myStartActivityForResult(new Intent(this, YR_AddPatientGroupActivity.class), 1);
                overridePendingTransition(R.anim.activity_open_up, R.anim.activity_no_move);
                break;
            case R.id.xc_id_titlebar_right2_textview:
                savePatientGroupList();
                break;
        }
    }

    /**
     * 获得分组列表
     *
     * @param isDialog 是否显示进度条
     */
    public void requestPatientGroupList(boolean isDialog) {
        RequestParams params = new RequestParams();
        params.put("patientId", mPatientId);
        XCHttpAsyn.postAsyn(isDialog, this, AppConfig.getHostUrl(AppConfig.doctor_group_list), params, new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    result_list = result_bean.getList("data");
                    if (result_list != null) {//更新listView数据
                        listViewFragment.updateSpecialList(result_list);
                        if (result_list.size() > 0) {
                            titlebar.getXc_id_titlebar_right2_textview().setEnabled(true);
                        }
                        HashMap<Integer, Boolean> map = patientGroupAdapter.getIsCheckMap();
                        map.clear();
                        for (int i = 0; i < result_list.size(); i++) {
                            if (result_list.get(i).getInt("included") == 1) {
                                map.put(i, true);
                            }
                        }
                        patientGroupAdapter.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (listViewFragment != null) {
                    listViewFragment.doRefreshComplete();
                }
            }
        });
    }

    private String getGroupIds() {
        HashMap<Integer, Boolean> map = patientGroupAdapter.getIsCheckMap();
        ArrayList<String> groupid_list = new ArrayList<String>();
        if (map != null && map.size() > 0) {
            for (Integer key : map.keySet()) {
                String group = result_list.get(key).getString("id");
                if (!TextUtils.isEmpty(group)) {
                    groupid_list.add(group);
                }
            }
        }
        StringBuilder sb = new StringBuilder("");
        if (groupid_list != null && groupid_list.size() > 0) {
            for (int i = 0; i < groupid_list.size(); i++) {
                String groupId = groupid_list.get(i);
                if (!TextUtils.isEmpty(groupId)) {
                    sb.append(groupId);
                    if (i < groupid_list.size() - 1) {
                        sb.append(",");
                    }
                }
            }
        }
        return sb.toString();
    }

    /**
     * 保存患者分组
     */
    private void savePatientGroupList() {
        RequestParams params = new RequestParams();
        params.put("patientId", mPatientId);
        params.put("groupIds", getGroupIds());
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.modify_patient_group_list), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();
            }

            @Override
            public void onFinish() {
                super.onFinish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        requestPatientGroupList(false);
    }
}
