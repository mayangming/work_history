package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.db.invited.XL_ContactsInvitedModel;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * 选中联系人adapter
 * @author zhangpengfei on 2016/4/18.
 * @version 2.3.0
 */
public class PF_SelectContactsAdapter extends BaseAdapter {
    private List<XL_ContactsInvitedModel> mList;
    private LayoutInflater mLayoutInflater;

    public void setList(List<XL_ContactsInvitedModel> mList) {
        if (null != mList && mList.size() > 0){
            this.mList = mList;
            notifyDataSetChanged();
        }
    }

    public PF_SelectContactsAdapter(Context context, List<XL_ContactsInvitedModel> mList){
        this.mList = mList;
        this.mLayoutInflater = LayoutInflater.from(context);

    }
    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(null == convertView){
            convertView = mLayoutInflater.inflate(R.layout.pf_item_select_contacts,null);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)convertView.getTag();
        }
        if (null != mList && null != mList.get(position)){
            viewHolder.pf_id_select_name.setText(UtilString.f(mList.get(position).getDisplay_NameText()));
        }
        return convertView;
    }

    static class ViewHolder{
        /**姓名*/
        private TextView pf_id_select_name;
        public ViewHolder(View convertView){

            pf_id_select_name = (TextView)convertView.findViewById(R.id.pf_id_select_name);

        }


    }
}
