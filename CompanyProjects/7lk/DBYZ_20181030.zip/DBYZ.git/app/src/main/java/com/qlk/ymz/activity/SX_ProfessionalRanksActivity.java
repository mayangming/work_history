package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.RelativeLayout;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_ProfessionalRanksAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.YY_DoctorlInfoBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.util.List;

/**
 * Created by songxin on 2015/6/18.
 *
 *
 * SX_ProfessionalRanksActivity
 * 编辑职称页面
 * @author  Changed by songxin on 2016/3/30.
 * @version 2.3
 */
public class SX_ProfessionalRanksActivity extends DBActivity {
    /** 修改职称layout*/
    private RelativeLayout sx_id_professional_ranks_rl;
    /** title*/
    private XCTitleCommonLayout titlebar;
    /** 显示职称list*/
    private XCListViewFragment list_fragment;
    /** intent*/
    private Intent mIntent;
    /** flag*/
    private int mIntentFlags;
    /** 职称数据*/
    private List<XCJsonBean> xcJsonBeans;
    /** 职称临时变量*/
    private String mCurrentProfessionalRanks;
    /** 适配职称数据adapter*/
    private SX_ProfessionalRanksAdapter mSXProfessionalRanksAdapter;
    /** 职称id临时变量*/
    private String mCurrentTitleId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_professional_ranks);
        super.onCreate(savedInstanceState);
        mIntent = new Intent();
        mIntentFlags = getIntent().getFlags();
        mCurrentProfessionalRanks = "";
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleCenter(true, "选择职称");
        titlebar.setTitleRight2(true, 0, "确定");
        getProfessionalRanks();
        //加载list
        list_fragment = new XCListViewFragment();
        mSXProfessionalRanksAdapter = new SX_ProfessionalRanksAdapter(this, null);
        list_fragment.setAdapter(mSXProfessionalRanksAdapter);
        list_fragment.setMode(XCListViewFragment.MODE_NOT_PULL);
        addFragment(R.id.sx_id_professional_ranks_rl, list_fragment);
        //列表点击事件
        list_fragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> paramAdapterView, View paramView, int position, long paramLong) {
                for (int i = 1; i < xcJsonBeans.size() + 1; i++) {
                    if (position == i) {
                        xcJsonBeans.get(position - 1).setBoolean("isChoose", true);
                        mCurrentProfessionalRanks = xcJsonBeans.get(position - 1).getString("titleName");
                        mCurrentTitleId = xcJsonBeans.get(position - 1).getString("titleId");
                    } else {
                        xcJsonBeans.get(i - 1).setBoolean("isChoose", false);
                    }
                }
                mSXProfessionalRanksAdapter.notifyDataSetChanged();
            }
        });
        //title右侧按钮点击事件
        titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                YY_DoctorlInfoBean.DataEntity currentData = new YY_DoctorlInfoBean.DataEntity();
                currentData.setTitleId(mCurrentTitleId);
                currentData.setTitle(mCurrentProfessionalRanks);
                mIntent.putExtra("PROFESSIONAL_RANKS", currentData);
                SX_ProfessionalRanksActivity.this.setResult(5,mIntent);
                SX_ProfessionalRanksActivity.this.myFinish();
            }
        });
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_ProfessionalRanksActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        //职称
        sx_id_professional_ranks_rl = getViewById(R.id.sx_id_professional_ranks_rl);
    }

    @Override
    public void listeners() {
    }

    @Override
    public void onNetRefresh() {

    }

    /**
     * 获取职称列表
     */
    private void getProfessionalRanks(){
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.doctorInfo_departmentAndTitle), new RequestParams(), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    xcJsonBeans = result_bean.getList("data").get(0).getList("titleList");
                    String intentData = getIntent().getStringExtra("PROFESSIONAL_RANKS");
                    for(XCJsonBean x :xcJsonBeans){
                        if(x.getString("titleName").equals(intentData)){
                            x.setBoolean("isChoose",true);
                            mCurrentTitleId = x.getString("titleId");
                            mCurrentProfessionalRanks = intentData;
                        }else{
                            x.setBoolean("isChoose",false);
                        }
                    }
                    list_fragment.updateSpecialList(xcJsonBeans);
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_ProfessionalRanksActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }
}
