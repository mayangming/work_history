package com.qlk.ymz.base;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.qlk.ymz.activity.PF_SingleLoginDialogActivity;
import com.qlk.ymz.model.CheckLoginDevice;
import com.qlk.ymz.service.XC_MqttService;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UmengProxy;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonParse;
import com.xiaocoder.android.fw.general.util.UtilSound;

import java.util.List;

/**
 * Created by jingyu
 *
 * @description 基类
 */
public abstract class DBActivity extends XCBaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //启动的时候把单设备登陆状态改成在前台
        GlobalConfigSP.setSingleLoginState(false);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            try {

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        UmengProxy.onPageStart(this);
        UmengProxy.onResume(this);
        singleLogin();
    }

    @Override
    protected void onPause() {
        super.onPause();
        UmengProxy.onPageEnd(this);
        UmengProxy.onPause(this);
        UtilSound.setSpeakerphoneOn(this, true);
    }

    public void isNotifyMqtt() {
        boolean currentStatue = isAppOnForeground();
        // change by 马杨茗 date 2016/6/30 content 改变前后台切换的状态由内存改为磁盘，防止进程被杀死后后重新初始化前后台状态 start
        String lastStatue = UtilSP.getLastIsappforeground();//保存到磁盘

//        if(!((currentStatue+"").equals(lastStatue))){
//            notifyMqtt(currentStatue);
//        }
        notifyMqtt(currentStatue);//因为有时候会出现前后端状态切换不过来的情况，所以先把判断条件去除
        // change by 马杨茗 date 2016/6/30 content 改变前后台切换的状态由内存改为磁盘，防止进程被杀死后后重新初始化前后台状态 end
        // XCApplication.base_log.i("background","切换到了前台么-->"+currentStatue+",之前是前台么-->"+lastStatue);
    }

    protected void notifyMqtt(boolean currentStatue) {
        // 记录值
        UtilSP.setLastIsappforeground(currentStatue+"");
        // 告诉mqtt前后台切换了
        Intent intent = new Intent();
        intent.putExtra(XC_MqttService.ForeAndBackgroundReceiver.KEY_STATUS, currentStatue);
        intent.setAction(XC_MqttService.ForeAndBackgroundReceiver.ACTION);
        sendBroadcast(intent);
        XCApplication.base_log.writeLog2File("notifyMqtt.txt","--->"+currentStatue+"\n",true);
        // XCApplication.base_log.i("background","给mqtt发的状态是-->"+currentStatue);
    }

    @Override
    protected void onStop() {
        super.onStop();
        // 还原扬声器设置
        UtilSound.setSpeakerphoneOn(this, true);

        isNotifyMqtt();

    }

    @Override
    protected void onStart() {
        super.onStart();
        isNotifyMqtt();
    }

    // add by xjs on 20160511 start
    // 当APP被切换到后台时，要进行MQTT offLine状态同步给服务器端的处理，故加此代码
    public boolean isAppOnForeground() {
        ActivityManager activityManager = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
        String packageName = getApplicationContext().getPackageName();

        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        if (appProcesses == null)
            return false;

        for (ActivityManager.RunningAppProcessInfo appProcess:appProcesses) {
            if (appProcess.processName.equals(packageName) && appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                return true;
            }
        }

        // 在这里写MQTT offLine 状态信息同步给服务端的处理
        // TODO
        return false;
    }
    // add by xjs on 20160511 end

    /**
     * 由于在后台,在此唤醒的时候判断是否踢出,跳到单设备登陆界面
     */
    private void singleLogin() {
        if (GlobalConfigSP.getSingleLoginState()) {
            GlobalConfigSP.setSingleLoginState(false);
            printi("单设备信息: " + GlobalConfigSP.getSingleLoginState());
            XCJsonBean result_bean = XCJsonParse.getJsonParseData(GlobalConfigSP.getSingleLoginMsg());
            if (null == result_bean){
                return ;
            }
            List<XCJsonBean> jsonBeans = result_bean.getList("data");
            CheckLoginDevice checkLoginDevice = new CheckLoginDevice();
            checkLoginDevice.setLogout(jsonBeans.get(0).getBoolean("logout"));
            checkLoginDevice.setLoginTime(jsonBeans.get(0).getString("loginTime"));
            checkLoginDevice.setModel(jsonBeans.get(0).getString("model"));
            checkLoginDevice.setLoginAddr(jsonBeans.get(0).getString("loginAddr"));
            Intent mIntent = new Intent(this, PF_SingleLoginDialogActivity.class);
            mIntent.putExtra(PF_SingleLoginDialogActivity.SIGLE_LOGIN, checkLoginDevice);
            startActivity(mIntent);
        }
    }

}
