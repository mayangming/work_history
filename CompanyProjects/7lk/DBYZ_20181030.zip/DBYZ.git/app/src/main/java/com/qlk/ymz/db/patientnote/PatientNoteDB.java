package com.qlk.ymz.db.patientnote;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * 病情备注数据库
 * @author 徐金山
 * @version 2.1.0
 */
public class PatientNoteDB {
    // ==========变量==========
    /** 数据库处理对象 */
    private static PatientNoteDB dbProcessObj = null;
    /** 数据库对象 */
    private SQLiteDatabase db = null;
    /** 上下文对象 */
    private Context context = null;

    // ==========数据库表结构相关数据==========
    /** 数据库版本号 */
    private final int DB_VERSION = 10;
    /** 数据库名 */
    private final static String DATABASE_NAME = "db_patientNote";

    // 病情备注信息表
    /** 病情备注信息表名 */
    private static final String TB_NAME_PATIENT_NOTE = "table_patientNote";
    /** 主键 */
    private static final String F_ID = "_id";
    /** 患者id */
    public static final String F_PATIENT_ID = "patientId";
    /** 医生id */
    public static final String F_DOCTOR_SELF_ID = "doctorSelfId";
    /** 病情备注 */
    public static final String F_PATIENT_NOTE = "patientNote";
    /** 病情备注创建时间 */
    public static final String F_PATIENT_NOTE_CREATE_TIME = "patientNoteCreateTime";
    /** 备用字段1 至 备用字段30 */
    public static final String F_BACK1 = "back1";
    public static final String F_BACK2 = "back2";
    public static final String F_BACK3 = "back3";
    public static final String F_BACK4 = "back4";
    public static final String F_BACK5 = "back5";
    public static final String F_BACK6 = "back6";
    public static final String F_BACK7 = "back7";
    public static final String F_BACK8 = "back8";
    public static final String F_BACK9 = "back9";
    public static final String F_BACK10 = "back10";
    public static final String F_BACK11 = "back11";
    public static final String F_BACK12 = "back12";
    public static final String F_BACK13 = "back13";
    public static final String F_BACK14 = "back14";
    public static final String F_BACK15 = "back15";
    public static final String F_BACK16 = "back16";
    public static final String F_BACK17 = "back17";
    public static final String F_BACK18 = "back18";
    public static final String F_BACK19 = "back19";
    public static final String F_BACK20 = "back20";

    /**
     * 数据库助手类
     */
    private class DbHelper extends SQLiteOpenHelper {
        /**
         * 构造方法
         * @param context 上下文对象
         */
        public DbHelper(Context context) {
            super(context, DATABASE_NAME, null, DB_VERSION);
        }

        /**
         * 初始化数据库
         * @param db 数据库对象
         */
        public void onCreate(SQLiteDatabase db) {
            // sql文
            String sql = new String();

            // 创建“咨询列表信息表”
            sql = "create table " + TB_NAME_PATIENT_NOTE +
                    "(" +
                    F_ID + " integer primary key AUTOINCREMENT," +
                    F_PATIENT_ID + " text, " +
                    F_DOCTOR_SELF_ID + " text, " +
                    F_PATIENT_NOTE + " text, " +
                    F_PATIENT_NOTE_CREATE_TIME + " text, " +
                    F_BACK1 + " text, " +
                    F_BACK2 + " text, " +
                    F_BACK3 + " text, " +
                    F_BACK4 + " text, " +
                    F_BACK5 + " text, " +
                    F_BACK6 + " text, " +
                    F_BACK7 + " text, " +
                    F_BACK8 + " text, " +
                    F_BACK9 + " text, " +
                    F_BACK10 + " text, " +
                    F_BACK11 + " text, " +
                    F_BACK12 + " text, " +
                    F_BACK13 + " text, " +
                    F_BACK14 + " text, " +
                    F_BACK15 + " text, " +
                    F_BACK16 + " text, " +
                    F_BACK17 + " text, " +
                    F_BACK18 + " text, " +
                    F_BACK19 + " text, " +
                    F_BACK20 + " text" +
                    ")";
            db.execSQL(sql);
        }

        /**
         * 更新数据库
         * @param db 数据库对象
         * @param oldVersion 数据库的旧版本号
         * @param newVersion 数据库的新版本号
         */
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            if(newVersion > oldVersion) {
                db.execSQL("drop table if exists " + TB_NAME_PATIENT_NOTE);
                onCreate(db);
            }
        }
    }

    /**
     * 构造方法
     * @param context 上下文
     */
    private PatientNoteDB(Context context) {
        this.context = context;
    }

    /**
     * 获取数据库适配器对象
     * @param context 上下文对象
     * @return 数据库处理对象
     */
    public static PatientNoteDB getInstance(Context context) {
        if(null == dbProcessObj) {
            dbProcessObj = new PatientNoteDB(context);
        }
        return dbProcessObj.openDataBase(context);
    }

    /**
     * 获取数据库操作权限
     * @param context 上下文对象
     * @return 数据库操作操作对象
     */
    private PatientNoteDB openDataBase(Context context) {
        DbHelper dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
        return dbProcessObj;
    }

    /**
     * 关闭数据库
     */
    private void closeDataBase() {
        try {
            if(null != db && db.isOpen()) {
                db.close();
            }
        }catch(Exception e) {
            System.out.println("---close database happened exception---");
            e.printStackTrace();
        }
    }

    /**
     * 保存患者信息
     * @param patientInfoModelObj 患者信息BEAN
     * @return 被操作记录的主键。当发生错误时，返回-1。
     */
    public long saveInfo(PatientInfoModel patientInfoModelObj) {
        if(null == patientInfoModelObj) {
            closeDataBase();
            return -1;
        }

        // 行记录的主键值
        long rowId = 0;
        // 表中是否存在相同患者信息的标示（true：存在，false：不存在，默认值：false）
        boolean flag = false;

        String queryClause = F_PATIENT_ID + "=?" + " AND " + F_DOCTOR_SELF_ID + "=?"; // 查询条件
        String[] queryClauseParamStrings = new String[]{patientInfoModelObj.getPatientId(), patientInfoModelObj.getDoctorSelfId()}; // 查询条件的参数值
        Cursor queryCursor = db.query(TB_NAME_PATIENT_NOTE, null, queryClause, queryClauseParamStrings, null, null, null);
        flag = queryCursor.moveToNext();

        // 以“患者ID”及“医生ID”联合作为判断条件，若表中没有相同的信息，则进行插入操作
        if(flag == false) {
            ContentValues values = patientInfoModel2ContentValues(patientInfoModelObj);
            rowId = db.insert(TB_NAME_PATIENT_NOTE, F_ID, values);
        }
        // 若表中有相同的信息，则进行更新操作
        else {
            // 要更新的记录主键
            long tempRowId = queryCursor.getInt(queryCursor.getColumnIndex(F_ID));

            // 进行更新操作
            String updateClause = F_PATIENT_ID + "=?" + " AND " + F_DOCTOR_SELF_ID + "=?"; // 更新条件
            String[] updateClauseParamStrings = new String[]{patientInfoModelObj.getPatientId(), patientInfoModelObj.getDoctorSelfId()}; // 更新条件的参数值
            ContentValues contentValues = patientInfoModel2ContentValues(patientInfoModelObj);
            int numberOfRowsAffected = db.update(TB_NAME_PATIENT_NOTE, contentValues, updateClause, updateClauseParamStrings);

            if(numberOfRowsAffected > 0) {
                rowId = tempRowId;
            }
        }

        queryCursor.close();
        closeDataBase();
        return rowId;
    }

    /**
     * 根据“患者id”及“医生id”查询患者的“编辑病情备注信息”
     * @param patientId 患者id
     * @param doctorId 医生id
     * @return 患者的“编辑病情备注信息”
     */
    public PatientInfoModel getInfo(String patientId, String doctorId) {
        PatientInfoModel patientInfoModel = new PatientInfoModel();

        String[] columns = null;
        String selection = F_PATIENT_ID + "=?" + " AND " + F_DOCTOR_SELF_ID + "=?";
        String[] selectionArgs = new String[]{patientId, doctorId};
        Cursor cursor = db.query(TB_NAME_PATIENT_NOTE, columns, selection, selectionArgs, null, null, null);

        if(cursor.moveToNext()) {
            patientInfoModel = cursor2PatientInfoModel(cursor);
        }

        cursor.close();
        closeDataBase();
        return patientInfoModel;
    }

    /**
     * 将PatientInfoModel业务信息对象转换成ContentValues对象
     * @param patientInfoModelObj 患者信息BEAN
     * @return 转换后得到的ContentValues对象
     */
    private ContentValues patientInfoModel2ContentValues(PatientInfoModel patientInfoModelObj) {
        ContentValues contentValuesObj = new ContentValues();

        contentValuesObj.put(F_PATIENT_ID, patientInfoModelObj.getPatientId()); // 患者id
        contentValuesObj.put(F_DOCTOR_SELF_ID, patientInfoModelObj.getDoctorSelfId()); // 医生id
        contentValuesObj.put(F_PATIENT_NOTE, patientInfoModelObj.getPatientNote()); // 病情备注
        contentValuesObj.put(F_PATIENT_NOTE_CREATE_TIME, patientInfoModelObj.getPatientNoteCreateTime()); // 病情备注创建时间
        contentValuesObj.put(F_BACK1, ""); // 备用字段1
        contentValuesObj.put(F_BACK2, ""); // 备用字段2
        contentValuesObj.put(F_BACK3, ""); // 备用字段3
        contentValuesObj.put(F_BACK4, ""); // 备用字段4
        contentValuesObj.put(F_BACK5, ""); // 备用字段5
        contentValuesObj.put(F_BACK6, ""); // 备用字段6
        contentValuesObj.put(F_BACK7, ""); // 备用字段7
        contentValuesObj.put(F_BACK8, ""); // 备用字段8
        contentValuesObj.put(F_BACK9, ""); // 备用字段9
        contentValuesObj.put(F_BACK10, ""); // 备用字段10
        contentValuesObj.put(F_BACK11, ""); // 备用字段11
        contentValuesObj.put(F_BACK12, ""); // 备用字段12
        contentValuesObj.put(F_BACK13, ""); // 备用字段13
        contentValuesObj.put(F_BACK14, ""); // 备用字段14
        contentValuesObj.put(F_BACK15, ""); // 备用字段15
        contentValuesObj.put(F_BACK16, ""); // 备用字段16
        contentValuesObj.put(F_BACK17, ""); // 备用字段17
        contentValuesObj.put(F_BACK18, ""); // 备用字段18
        contentValuesObj.put(F_BACK19, ""); // 备用字段19
        contentValuesObj.put(F_BACK20, ""); // 备用字段20

        return contentValuesObj;
    }


    private PatientInfoModel cursor2PatientInfoModel(Cursor cursor) {
        PatientInfoModel patientInfoModel = new PatientInfoModel();

        patientInfoModel.setPatientId(cursor.getString(cursor.getColumnIndex(F_PATIENT_ID))); // 患者id
        patientInfoModel.setDoctorSelfId(cursor.getString(cursor.getColumnIndex(F_DOCTOR_SELF_ID))); // 医生id
        patientInfoModel.setPatientNote(cursor.getString(cursor.getColumnIndex(F_PATIENT_NOTE))); // 病情备注
        patientInfoModel.setPatientNoteCreateTime(cursor.getString(cursor.getColumnIndex(F_PATIENT_NOTE_CREATE_TIME))); // 病情备注创建时间
        patientInfoModel.setBack1(cursor.getString(cursor.getColumnIndex(F_BACK1))); // 备用字段1
        patientInfoModel.setBack2(cursor.getString(cursor.getColumnIndex(F_BACK2))); // 备用字段2
        patientInfoModel.setBack3(cursor.getString(cursor.getColumnIndex(F_BACK3))); // 备用字段3
        patientInfoModel.setBack4(cursor.getString(cursor.getColumnIndex(F_BACK4))); // 备用字段4
        patientInfoModel.setBack5(cursor.getString(cursor.getColumnIndex(F_BACK5))); // 备用字段5
        patientInfoModel.setBack6(cursor.getString(cursor.getColumnIndex(F_BACK6))); // 备用字段6
        patientInfoModel.setBack7(cursor.getString(cursor.getColumnIndex(F_BACK7))); // 备用字段7
        patientInfoModel.setBack8(cursor.getString(cursor.getColumnIndex(F_BACK8))); // 备用字段8
        patientInfoModel.setBack9(cursor.getString(cursor.getColumnIndex(F_BACK9))); // 备用字段9
        patientInfoModel.setBack10(cursor.getString(cursor.getColumnIndex(F_BACK10))); // 备用字段10
        patientInfoModel.setBack11(cursor.getString(cursor.getColumnIndex(F_BACK11))); // 备用字段11
        patientInfoModel.setBack12(cursor.getString(cursor.getColumnIndex(F_BACK12))); // 备用字段12
        patientInfoModel.setBack13(cursor.getString(cursor.getColumnIndex(F_BACK13))); // 备用字段13
        patientInfoModel.setBack14(cursor.getString(cursor.getColumnIndex(F_BACK14))); // 备用字段14
        patientInfoModel.setBack15(cursor.getString(cursor.getColumnIndex(F_BACK15))); // 备用字段15
        patientInfoModel.setBack16(cursor.getString(cursor.getColumnIndex(F_BACK16))); // 备用字段16
        patientInfoModel.setBack17(cursor.getString(cursor.getColumnIndex(F_BACK17))); // 备用字段17
        patientInfoModel.setBack18(cursor.getString(cursor.getColumnIndex(F_BACK18))); // 备用字段18
        patientInfoModel.setBack19(cursor.getString(cursor.getColumnIndex(F_BACK19))); // 备用字段19
        patientInfoModel.setBack20(cursor.getString(cursor.getColumnIndex(F_BACK20))); // 备用字段20

        return patientInfoModel;
    }
}
