package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.gdca.sdk.casign.GdcaResultListener;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.ElectronicSignatureHelper;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.List;


/**
 * Created by xiedong on 2017/8/1.
 * 输入以及更换手机号申请证书
 */

public class XD_EditPhoneNumberActivity extends DBActivity {
    public static final String FROM = "from";//从哪个页面来的标识
    public static final int FROM_BACKUP = 1;//从备案页面过来
    public static final int FROM_SIGNATURE = 2;//从电子签名过来
    /**
     * 标题栏
     */
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**
     * 新输入手机号
     */
    private EditText et_phone_number;
    /**
     * 下一步
     */
    private TextView tv_next;
    /**
     * 证书凭证id
     */
    private String voucherId = "";
    /**
     * 来源页码
     */
    private int fromCode = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_change_phone_number);
        super.onCreate(savedInstanceState);
        initUI();//初始化显示
    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_EditPhoneNumberActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleLeft(true, "");

        et_phone_number = getViewById(R.id.et_phone_number);
        tv_next = getViewById(R.id.tv_next);

    }

    /**
     * 初始化显示
     */
    private void initUI() {
        fromCode = getIntent().getIntExtra(FROM, 0);
        if (fromCode == FROM_BACKUP) {//从备案页过来
            xc_id_model_titlebar.setTitleCenter(true, "输入手机号码");
            et_phone_number.setHint("请输入手机号码");
            String phone = UtilSP.getLastCertificationPhone();
            if (TextUtils.isEmpty(phone)) {
                phone = UtilSP.getUserPhone();
            }
            et_phone_number.setText(phone);
            et_phone_number.setSelection(phone.length());
        } else if (fromCode == FROM_SIGNATURE) {//从证书页过来
            xc_id_model_titlebar.setTitleCenter(true, "更换手机号码");
            et_phone_number.setHint("请输入新的手机号码");
        }
    }

    @Override
    public void listeners() {
        xc_id_model_titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });

        et_phone_number.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().length() > 0) {
                    tv_next.setBackgroundResource(R.drawable.yr_bg_btn_canpressed);
                    tv_next.setClickable(true);
                    tv_next.setTextColor(getResources().getColor(R.color.c_e2231a));
                } else {
                    tv_next.setBackgroundResource(R.drawable.yr_bg_btn_cannotpressed);
                    tv_next.setClickable(false);
                    tv_next.setTextColor(getResources().getColor(R.color.c_50e2231a));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        tv_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  下一步操作
                getVoucherId();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case 2:
                    setResult(RESULT_OK);
                    myFinish();
                    break;
            }
        }
    }

    /**
     * 获取证书凭证id
     */
    private void getVoucherId() {
        final String phone = et_phone_number.getText().toString().trim();
        if(!UtilString.isPhoneNum(phone)){
            shortToast("手机号格式不对，请重新输入");
            return;
        }
        RequestParams params = new RequestParams();
        params.put("phoneNum", phone);
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.voucherid), params, new
                XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (result_boolean) {
                            List<XCJsonBean> data = result_bean.getList("data");
                            if (data != null && data.size() > 0) {
                                voucherId = data.get(0).getString("voucherId");
                                //保存认证手机号 以及凭证id
                                UtilSP.setLastCertificationPhone(phone);
                                ElectronicSignatureHelper.getInstance().setVoucherId(voucherId);
                                ElectronicSignatureHelper.getInstance().clearCert();//清除证书信息
                                if (fromCode == FROM_BACKUP) {//从备案页过来
                                    ToJumpHelp.toJumpElectronicSignatureActivity(XD_EditPhoneNumberActivity.this, XD_ElectronicSignatureActivity.FROM_PHONE);

                                } else if (fromCode == FROM_SIGNATURE) {//从证书页过来
                                    //申请证书
                                    ElectronicSignatureHelper.getInstance().createCert(XD_EditPhoneNumberActivity.this, new GdcaResultListener() {
                                        @Override
                                        public void onResultSuccess(String s) {
                                            shortToast("生成证书成功");
                                            setResult(RESULT_OK);
                                            myFinish();
                                        }

                                        @Override
                                        public void onResultError(int errode, String s) {
                                            shortToast("证书生成失败");
                                        }
                                    });
                                }
                            }
                        }
                    }

                    // 对账户冻结情况的判断处理
                    public void onFinish() {
                        super.onFinish();
                        if(null != result_bean){
                            String code = getCode();
                            if("600011".equals(code)){
                                shortToast("该手机号已经设置过电子签名");
                                return;
                            }
                            if ( GeneralReqExceptionProcess.checkCode(XD_EditPhoneNumberActivity.this,
                                    getCode(),
                                    getMsg())) {
                                // 接口请求业务成功时的处理
                            }
                        }
                    }
                });
    }


}
