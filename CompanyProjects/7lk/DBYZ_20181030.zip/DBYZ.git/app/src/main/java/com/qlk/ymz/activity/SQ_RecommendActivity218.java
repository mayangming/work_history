package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.contrarywind.view.WheelView;
import com.gdca.sdk.casign.model.GdcaCertModel;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SQ_RecommendAdapter;
import com.qlk.ymz.application.DBApplication;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.InventoryInfo;
import com.qlk.ymz.model.RecipeBean;
import com.qlk.ymz.model.RecommendInfo;
import com.qlk.ymz.model.RecommendMedicineResultBean;
import com.qlk.ymz.model.SK_RecommendInfo;
import com.qlk.ymz.model.SafeMedicationBean;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.parse.Parse2InventoryInfo;
import com.qlk.ymz.parse.Parse2SafeMedication;
import com.qlk.ymz.parse.Parser2RecomMedResultBean;
import com.qlk.ymz.parse.Parser2SQRecommendInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.ElectronicSignatureHelper;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.HospitalBackupsBeanSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.UtilInsertMsg2JsDb;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.UtilNum;
import com.qlk.ymz.util.UtilPackMsg;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ArrayTextWheelAdapter;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.MedicalServiceFeeDialog;
import com.qlk.ymz.view.SQ_SexChoiceDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author 赖善琦
 *
 * 2.18 版本以前的推荐用药界面
 */
public class SQ_RecommendActivity218 extends DBActivity {

    private XCTitleCommonLayout title_common_layout;
    private XCBaseActivity mContext;//上下文对象
    private ListView ordonnance_medicines_lv;//药品名称显示列表
    private View ym_ordonnance_head_view;//药品名称显示列表的HeadView
    private View ym_ordonnance_foot_view;//药品名称显示列表的HeadView
    private TextView ordonnance_patient_date;//诊断时间(时间从本地获取)
    private TextView tv_recommend_tltle; // 处方笺标题
    private EditText ym_ordonnance_patient_name;//患者姓名(单行显示,显示不完显示...)
    private TextView ym_ordonnance_patient_age;//患者年龄
    private TextView ym_ordonnance_number;//处方单编号(共16位,长度固定，分四部分)
    private TextView ym_ordonnance_patient_sex;//患者性别(获取不到显示空)
    private TextView ym_ordonnance_diacrisis_edt;//临床诊断输入框(字符长度限制为19字)
    private ImageView ym_ordonnance_medicines_add;//处方笺的添加药品按钮
    private TextView ym_ordonnance_medicition_send;//发送按钮
    private TextView ym_ordonnance_doctor_name;//医师姓名
    private TextView ym_ordonnance_department_name;//科室
    private TextView sq_id_ordonnance_edit;//编辑按钮
    private RelativeLayout ym_ordonnance_diacrisis_rl;//临床诊断布局
    private SQ_SexChoiceDialog sexChoiceDialog;//性别选择对话框
    private TextView tv_total_price; // 总金额
    /**
     * 屏幕宽
     */
    private int mScreenWidth = 720;
    /**
     * 选择年龄对话框
     */
    private ConfirmDialog mSetAgeDialog;
    /**
     * 选择年龄控件
     */
    private WheelView mWheelView;
    /**
     * 选择年龄对话框取消按钮
     */
    private TextView tv_set_age_cancel;
    /**
     * 选择年龄对话框确定按钮
     */
    private TextView tv_set_age_confirm;

    private RecommendInfo recommendInfo;

    /** 临床诊断请求码*/
    public static int REQUEST_CODE_DIAGNOSE = 101;
    /**
     * 用药确认列表的adapter
     */
    private SQ_RecommendAdapter recommendAdapter;
    /**
     * IM传过来的model，具体信息进去看
     */
    private XC_PatientDrugInfo patientDrugInfo;
    /**
     * 用药确认列表的数据
     */
    private List<DrugBean> mDrugBeanList = new ArrayList<>();

    private String ordonnanceNumber = "";//处方单编号
    private XC_ChatModel chatModel;//聊天实体类

    /**
     * 用法用量提示对话框
     */
    private YR_CommonDialog mYR_commonDialog;
    /**
     * 药事服务费dialog
     */
    private MedicalServiceFeeDialog medicalServiceFeeDialog;

    /**
     * 药品是否勾选的map集合
     */
    private Map<String, Boolean> checkDrugMap = new HashMap<>();
    private ArrayList<DiagnoseBean> diagnosisList = new ArrayList<>();
    // 编辑按钮对应的当前文案，true ： 编辑，false：完成
    private boolean isEdit = true;
    // 是否需要请求初始化处方笺的标识  true 要，false 不要
    private boolean isRequestInitData = true;
    // 用于监控点击了哪个editext 控制姓名和年龄在键盘弹出时获取焦点  0：姓名，1：年龄
    private  int editextIndex = -1;

    // 点击了哪个item的修改用法  position = 位置
    private int editPosition = -1;
    // 校验完安全用药后下一步的标记，区分是保存常用处方还是发送处方； 0：保存常用，1：发送处方
    private int checkSafeRecomNextTag;
    /** 用于解决安全用药提示页回来进度度消失问题*/
    private boolean isActivityResult = false;
    /**
     * 电子签名签署监听
     */
    private ElectronicSignatureHelper.signListener signListener = new ElectronicSignatureHelper.signListener() {
        @Override
        public void onSuccess(String msg) {
            sendToChatDetailActivity();
        }

        @Override
        public void onFail(String msg) {
            new YR_CommonDialog(SQ_RecommendActivity218.this,"电子签名异常，是否继续发送处方","继续发送","取消"){
                @Override
                public void confirmBtn() {
                    dismiss();
                }

                @Override
                public void cancelBtn() {
                    // 签署异常 强制推荐
                    patientDrugInfo.getChatModel().setForce(true);
                    sendToChatDetailActivity();
                }
            }.show();
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        //created by songxin,date：2017-9-26,about：bi,begin
        BiUtil.savePid(SQ_RecommendActivity218.class);
        //created by songxin,date：2017-9-26,about：bi,end
        // 查询库存信息
        requestGetInventoryInfo(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        recommendAdapter.notifyDataSetChanged();
        if(!UtilSP.isRecomSafe()) {
            requestRemind();
        }
    }


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        DrugBean drugBean = (DrugBean) intent.getSerializableExtra(UsageActivityV2.DRUG_INFO);
        if(null == drugBean) return;
        // 添加药品
        sq_id_ordonnance_edit.setVisibility(View.VISIBLE);
        setSaveTextViewState(0);
        mDrugBeanList.add(drugBean);
        checkDrugMap.put(drugBean.getId(),true);
        computeTotalPrice();
    }

    /**
     * 启动此activity
     */
    public static void launch(Context context) {
        Intent intent = new Intent(context, SQ_RecommendActivity218.class);
        (context).startActivity(intent);
    }
    /**
     * 启动此activity
     */
    public static void launch(Context context,DrugBean bean) {
        Intent intent = new Intent(context, SQ_RecommendActivity218.class);
        intent.putExtra(UsageActivityV2.DRUG_INFO,bean);
        (context).startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sq_activity_recommend);
        super.onCreate(savedInstanceState);
    }

    /**
     * 从intent获取数据
     */
    private void getData() {
        patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
        recommendInfo = patientDrugInfo.getRecommendInfo();

        if (null != patientDrugInfo.getDiagnoseBeanList()) {
            diagnosisList = (ArrayList<DiagnoseBean>) patientDrugInfo.getDiagnoseBeanList();
        }

        if (recommendInfo == null || UtilString.isBlank(recommendInfo.getTitle())) {
            recommendInfo = new SK_RecommendInfo();
            requestInitData();
        }

        mDrugBeanList = patientDrugInfo.getList();
        checkDrugMap = patientDrugInfo.getCheckDrugMap();
        chatModel = patientDrugInfo.getChatModel();
    }

    /**
     *  计算总金额
     */
    private void computeTotalPrice() {

        if(UtilCollection.isBlank(mDrugBeanList)){
            tv_total_price.setVisibility(View.GONE);
            return;
        }else {
            tv_total_price.setVisibility(View.VISIBLE);
        }

        long total = 0;
        for (DrugBean drugBean : mDrugBeanList){

            total = total + UtilNum.yuan2FenBigDecimal(UtilString.toDouble(drugBean.getSalePrice()))
                        * UtilString.toLong(drugBean.getMedicineUsageBean().getQuantity())
            ;
        }
        tv_total_price.setText("总金额："+AppConfig.renminbi+" "+StringUtils.getMoneyString(total));

    }

    /**
     * 初始化控件
     */
    @Override
    public void initWidgets() {
        mContext = this;
        getData();

        title_common_layout = getViewById(R.id.title_common_layout);
        ordonnance_medicines_lv = getViewById(R.id.ym_ordonnance_medicines_lv);
        ym_ordonnance_medicition_send = getViewById(R.id.ym_ordonnance_medicition_send);

        //以下为药品显示列表的HeadView的控件初始化 start
        ym_ordonnance_head_view = getLayoutInflater().inflate(R.layout.sq_view_ordonnance_head218, null);
        ordonnance_patient_date = (TextView) ym_ordonnance_head_view.findViewById(R.id.ordonnance_patient_date);
        tv_recommend_tltle = (TextView) ym_ordonnance_head_view.findViewById(R.id.tv_recommend_tltle);
        ym_ordonnance_patient_name = (EditText) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_patient_name);
        ym_ordonnance_patient_age = (TextView) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_patient_age);
        ym_ordonnance_number = (TextView) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_number);
        ym_ordonnance_patient_sex = (TextView) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_patient_sex);
        ym_ordonnance_diacrisis_edt = (TextView) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_diacrisis_edt);
        sq_id_ordonnance_edit = (TextView) ym_ordonnance_head_view.findViewById(R.id.sq_id_ordonnance_edit);
        ym_ordonnance_diacrisis_rl = (RelativeLayout) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_diacrisis_rl);
        sq_id_ordonnance_edit.setVisibility(View.VISIBLE);
        //以上为药品显示列表的HeadView的控件初始化 end

        //以下为药品显示列表的FootView的控件初始化 start
        ym_ordonnance_foot_view = getLayoutInflater().inflate(R.layout.sq_dialog_ordonnance_foot, null);
        ym_ordonnance_medicines_add = (ImageView) ym_ordonnance_foot_view.findViewById(R.id.ym_ordonnance_medicines_add);
        ym_ordonnance_doctor_name = (TextView) ym_ordonnance_foot_view.findViewById(R.id.ym_ordonnance_doctor_name);
        ym_ordonnance_department_name = (TextView) ym_ordonnance_foot_view.findViewById(R.id.ym_ordonnance_department_name);
        tv_total_price = (TextView) ym_ordonnance_foot_view.findViewById(R.id.tv_total_price);
        //以上为药品显示列表的FootView的控件初始化 end

        ordonnance_medicines_lv.addHeaderView(ym_ordonnance_head_view);
        ordonnance_medicines_lv.addFooterView(ym_ordonnance_foot_view);

        // ym_ordonnance_diacrisis_edt.setFilters(new InputFilter[]{new InputFilter.LengthFilter(19)});

        title_common_layout.getXc_id_titlebar_center_textview().setTextSize(TypedValue.COMPLEX_UNIT_DIP,18);
        title_common_layout.setTitleLeft(true, null);
        title_common_layout.setTitleCenter(true, "处方详情");
        title_common_layout.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returnToChoiceMedicineActivity();
            }
        });
        setSaveTextViewState(0);
        title_common_layout.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if("保存常用".equals(title_common_layout.getXc_id_titlebar_right2_textview().getText().toString())){
                    // created by songxin,date：2018-01-09,about：saveInfo,begin
                    BiUtil.saveBiInfo(SQ_RecommendActivity218.class, "2", "128", "E00098","", false);
                    // created by songxin,date：2018-01-09,about：saveInfo,end
                    if(UtilSP.isRecomSafe()){
                        checkSafeRecomNextTag = 0;
                        requestSafeMedication();
                    }else {
                        addPrescription();
                    }
                }
            }
        });

        medicalServiceFeeDialog = new MedicalServiceFeeDialog(this);
        medicalServiceFeeDialog.getWindow().setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        medicalServiceFeeDialog.setSendBtnOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSave();
            }
        });

        sexChoiceDialog = new SQ_SexChoiceDialog(mContext);
        sexChoiceDialog.getWindow().setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        sexChoiceDialog.setSexChangeListener(new SQ_SexChoiceDialog.SexChangeListener() {
            @Override
            public void onSexChange(String sex) {
                ym_ordonnance_patient_sex.setText(sex);
            }
        });
        sexChoiceDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
                ym_ordonnance_patient_age.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        handler.sendMessage(new Message());
                    }
                },1000);
            }
        });


        recommendAdapter = new SQ_RecommendAdapter(mContext, mDrugBeanList);
        ordonnance_medicines_lv.setAdapter(recommendAdapter);

        setDataToViews();
        initSetAgeDialog();
        computeTotalPrice();

    }

    private List<String> getAgeData() {
        List<String> ages = new ArrayList<>();
        for (int i = 1; i<5 ;i++){
            ages.add(i + "周");
        }
        for (int i = 1; i<13;i++){
            ages.add(i + "个月");
        }
        for (int i = 1;i<121 ; i++){
            ages.add(i + "岁");
        }
        return ages;
    }

    /**
     * 初始化选择年龄对话框
     */
    private void initSetAgeDialog() {
        final List<String> ageData = getAgeData();
        mScreenWidth = UtilScreen.getScreenWidthPx(this);
        mSetAgeDialog = new ConfirmDialog(this, mScreenWidth, R.layout.dialog_roll_select, R.style.xc_s_dialog);
        mSetAgeDialog.setCanceledOnTouchOutside(false);
        Window window = mSetAgeDialog.getWindow();
        window.setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        tv_set_age_cancel = (TextView) mSetAgeDialog.findViewById(R.id.tv_set_price_cancel);
        tv_set_age_confirm = (TextView) mSetAgeDialog.findViewById(R.id.tv_set_price_confirm);

        mWheelView = (WheelView) mSetAgeDialog.findViewById(R.id.wheelview);
        mWheelView.setCyclic(false);//不循环
        mWheelView.setAdapter(new ArrayTextWheelAdapter(ageData));

        tv_set_age_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mSetAgeDialog.dismiss();
            }
        });
        tv_set_age_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ym_ordonnance_patient_age.setText(ageData.get(mWheelView.getCurrentItem()));
                saveAge();
                mSetAgeDialog.dismiss();
                ym_ordonnance_patient_age.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        handler.sendMessage(new Message());
                    }
                },1000);
            }
        });

        mSetAgeDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                String mAge = recommendInfo.getPatientAge() + recommendInfo.getPatientAgeUnit();
                if(UtilString.toInt(recommendInfo.getPatientAge()) > 120 || UtilString.isBlank(mAge)){
                    mAge = "1岁";
                }
                for(int i=0;i<ageData.size();i++){
                    if(mAge.equals(ageData.get(i))){
                        mWheelView.setCurrentItem(i);
                    }
                }
            }
        });
    }

    /**
     * 初始化列表数据
     */
    private void setDataToViews() {
        tv_recommend_tltle.setText(recommendInfo.getTitle());

        if (null == chatModel) {
            chatModel = new XC_ChatModel();
        }
        String patientGender = recommendInfo.getPatientGender() + "";
        if (CommonConfig.GENDER_MALE.equals(patientGender)) {
            patientGender = "男";
        } else if (CommonConfig.GENDER_FEMALE.equals(patientGender)) {
            patientGender = "女";
        } else {
            patientGender = "";
        }
        try {
            String date = DateFormat.format("时间 " + "yyyy/MM/dd", Long.parseLong(recommendInfo.getRecomTime())).toString();
            ordonnance_patient_date.setText(date);
            ym_ordonnance_patient_name.setText(recommendInfo.getPatientName());
            ym_ordonnance_patient_age.setText(recommendInfo.getPatientAge() + recommendInfo.getPatientAgeUnit());
            ym_ordonnance_number.setText("编号 " + recommendInfo.getSerialNumber());
            ym_ordonnance_patient_sex.setText(patientGender);
            ym_ordonnance_doctor_name.setText(recommendInfo.getDoctorName());
            ym_ordonnance_department_name.setText(recommendInfo.getDepartmentName());
            setDiagnosisText();
        } catch (Exception e) {
            //防止获取的值为""，导致的异常警告
            e.printStackTrace();
        }

        recommendAdapter.setRecommendAdapterOnClickListener(new SQ_RecommendAdapter.RecommendAdapterOnClickListener() {
            @Override
            public void OnRemoveClickListener(final View v, final int position) {
                new YR_CommonDialog(mContext, "请确认是否删除", "取消", "确认") {
                    @Override
                    public void confirmBtn() {
                        DrugBean bean = (DrugBean) v.getTag();
                        bean.setCheck(false);
                        mDrugBeanList.remove(position);
                        checkDrugMap.remove(bean.getId());
                        if (UtilCollection.isBlank(mDrugBeanList)) {
                            sq_id_ordonnance_edit.setVisibility(View.GONE);
                            setSaveTextViewState(0);
                            if(UtilCollection.isBlank(diagnosisList)){
                                setSaveTextViewState(2);
                            }
                        }else {
                            setSaveTextViewState(0);
                        }
                        recommendAdapter.notifyDataSetChanged();
                        computeTotalPrice();
                        dismiss();
                    }
                }.show();
            }

            @Override
            public void OnEditUsageDataClickListener(View v,int position) {
                // created by songxin,date：2018-01-09,about：saveInfo,begin
                BiUtil.saveBiInfo(SQ_RecommendActivity218.class, "2", "128", "E00096","", false);
                // created by songxin,date：2018-01-09,about：saveInfo,end
                editPosition = position;
                DrugBean drugBean = (DrugBean) v.getTag();
                drugBean.setEditUsage(true);
                UsageActivityV2.launch(SQ_RecommendActivity218.this, drugBean,CommonConfig.ALL_MEDICINE_FLAG_2,"");
            }

        });
    }

    /**
     * 设置保存按钮状态
     * @param state 0:保存为常用 可点击， 1：已保存，2：保存为常用 不可点击
     */
    public void setSaveTextViewState(int state){
        if(0 == state){
            title_common_layout.setTitleRight2(true,0,"保存常用");
            title_common_layout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
            title_common_layout.getXc_id_titlebar_right2_layout().setClickable(true);
            title_common_layout.getXc_id_titlebar_right2_layout().setFocusable(true);
        }else if(1 == state){
            title_common_layout.setTitleRight2(true,0,"已添加常用");
            title_common_layout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        }else if(2 == state){
            title_common_layout.setTitleRight2(true,0,"保存常用");
            title_common_layout.getXc_id_titlebar_right2_layout().setClickable(false);
            title_common_layout.getXc_id_titlebar_right2_layout().setFocusable(false);
            title_common_layout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_ececec));

        }

    }

    @Override
    public void onNetRefresh() {
    }

    @Override
    public void listeners() {
        ym_ordonnance_medicines_add.setOnClickListener(this);
        ym_ordonnance_medicition_send.setOnClickListener(this);
        sq_id_ordonnance_edit.setOnClickListener(this);
        ym_ordonnance_patient_sex.setOnClickListener(this);
        ym_ordonnance_diacrisis_rl.setOnClickListener(this);
        ym_ordonnance_patient_age.setOnClickListener(this);

    }

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(!UtilSP.isRecomSafe()) {
                requestRemind();
            }
        }
    };

    /**
     * 刷新页面
     */
    public void notifyDataSetChanged() {
        if (null != recommendAdapter) {
            recommendAdapter.notifyDataSetChanged();
        }
    }

    /**
     * 请求配伍禁忌
     */
    public void requestMatching() {
        String goodsIds = "";
        for (DrugBean bean : mDrugBeanList) {
            goodsIds = goodsIds + bean.getId() + ",";
        }
        String goodsId = UtilString.getStringWithoutLast(goodsIds);
        RequestParams params = new RequestParams();

        XCHttpAsyn.getAsyn(false, true, true, mContext, AppConfig.MatchingApi + goodsId, params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (mContext == null) {
                    return;
                }
                // XCHttpAsyn.closeLoadingDialog();
                try {
                    if (result_boolean && !mContext.isDestroy) {
                        List<XCJsonBean> beanList = result_bean.getList("data");
                        XCJsonBean bean = beanList.get(0);
                        XCJsonBean dismatchBean = bean.getModel("dismatch");
                        JSONObject jsonObject = new JSONObject(dismatchBean.toString());
                        Iterator iterator = jsonObject.keys();
                        String key = "";
                        while (iterator.hasNext()) {
                            key = (String) iterator.next(); // 得到key，key我们是不知道的  （key是药名）
                        }
                        List<String> list = dismatchBean.getStringList(key);

                        if (list.size() < 1) {
                            DBApplication.base_log.newV("YM_RecommendDialog============");
                            // 如果可以匹配 （无冲突） ，去推荐
                            toSend();
                        } else {
                            // 如果不能匹配 （有冲突）
                            String names = "";
                            for (String name : list) {   // 遍历起冲突的药品名字
                                names = names + name + ",";  // 拼接字符串
                            }
                            names = UtilString.getStringWithoutLast(names);
                            XCApplication.longToast(key + "与" + names + "存在冲突，请重新检查药物清单后再进行推荐。");
                            XCHttpAsyn.closeLoadingDialog();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    super.onFinish();
                    XCApplication.longToast("配伍禁忌解析错误");
                }
            }

            @Override
            public void onFinish() {
//                super.onFinish();
                if (!GeneralReqExceptionProcess.checkCode(mContext,getCode(),getMsg())) {
                    XCHttpAsyn.closeLoadingDialog();
                }
            }

        });
    }

    /**
     * 将用药确认列表数据传给聊天页
     */
    private void sendToChatDetailActivity() {
        // 计算毫秒值
        savePatientDrugInfo();

        requestSendRecommendMedicine(patientDrugInfo.getChatModel());
    }

    /**
     * 将用药确认列表数据返回给推荐用药页
     */
    private void returnToChoiceMedicineActivity() {
        try {
            saveRecommendInfo();
            savePatientDrugInfo();

            myFinish();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void savePatientDrugInfo() {
        patientDrugInfo.setList(mDrugBeanList);
        patientDrugInfo.setChatModel(chatModel);//防止chatModel为null
        patientDrugInfo.getChatModel().setDiagnosis(ym_ordonnance_diacrisis_edt.getText().toString().trim());
        patientDrugInfo.getChatModel().setSerialNumber(ordonnanceNumber);
    }

    private void saveRecommendInfo() {
        recommendInfo.setPatientName(ym_ordonnance_patient_name.getText().toString().trim());
        saveAge();
        // 患者性别：0.女 1.男
        int gender;
        if ("女".equals(ym_ordonnance_patient_sex.getText().toString().trim())) {
            gender = 0;
        } else {
            gender = 1;
        }
        recommendInfo.setPatientGender(gender + "");
    }

    private void saveAge() {
        String age = ym_ordonnance_patient_age.getText().toString().trim();
        if(age.contains("周")){
            recommendInfo.setPatientAgeUnit("周");
            recommendInfo.setPatientAge(UtilString.getStringWithoutLast(age,"周"));
        }else if(age.contains("个月")){
            recommendInfo.setPatientAgeUnit("个月");
            recommendInfo.setPatientAge(UtilString.getStringWithoutLast(age,"个月"));
        }else if(age.contains("岁")){
            recommendInfo.setPatientAgeUnit("岁");
            recommendInfo.setPatientAge(UtilString.getStringWithoutLast(age,"岁"));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ym_ordonnance_medicines_add:
                saveRecommendInfo();
                savePatientDrugInfo();
                UtilInputMethod.hiddenInputMethod(ym_ordonnance_diacrisis_edt, mContext);
                ToJumpHelp.toJumpAllMedicineClassActivity(this,CommonConfig.ALL_MEDICINE_FLAG_4
                ,getIntent().getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION));

                break;
            case R.id.ym_ordonnance_medicition_send:
                // created by songxin,date：2018-01-09,about：saveInfo,begin
                BiUtil.saveBiInfo(SQ_RecommendActivity218.class, "2", "128", "E00099","", false);
                // created by songxin,date：2018-01-09,about：saveInfo,end
                if (isFastClick()) {
                    return;
                }

                // 检查勾选的药品列表
                if (mDrugBeanList.size() < 1) {
                    mContext.shortToast("药品为空请添加药品");
                    return;
                }
                // 效验用法用量
                if (!checkUsage()) {
                    return;
                }
                if (UtilString.isBlank(ym_ordonnance_diacrisis_edt.getText().toString().trim())) {
                    mContext.shortToast("请完整填写患者信息后提交");
                    return;
                }
                if (StringUtils.containsEmoji(ym_ordonnance_diacrisis_edt.getText().toString())) {
                    mContext.shortToast("诊断内容不能包含有特殊字符");
                    return;
                }
                if (UtilString.isBlank(ym_ordonnance_patient_age.getText().toString().trim())) {
                    mContext.shortToast("请完整填写患者信息后提交");
                    return;
                }
                if (UtilString.isBlank(ym_ordonnance_patient_name.getText().toString().trim())) {
                    mContext.shortToast("请完整填写患者信息后提交");
                    return;
                }
                if (UtilString.isBlank(ym_ordonnance_patient_sex.getText().toString().trim())) {
                    mContext.shortToast("请完整填写患者信息后提交");
                    return;
                }
                //  要求备案
                if ("4".equals(UtilSP.getDoctorStatus())) {
                    // 校验状态
                    requestRecomCheck();
                    return;
                }else if ("2".equals(UtilSP.getDoctorStatus())) {
                    // 备案成功 查询电子签名
                    getCertInfo();
                    return;
                }
                // 发送处方
                checkInventoryInfo();
                break;

            case R.id.sq_id_ordonnance_edit:
                if (isEdit) {
                    sq_id_ordonnance_edit.setText("完成");
                    isEdit = false;
                    recommendAdapter.showEdtLinearLayout();
                } else {
                    sq_id_ordonnance_edit.setText("编辑");
                    isEdit = true;
                    recommendAdapter.hideEdtLinearLayout();

                    if (mDrugBeanList.size() == 0) {
                        sq_id_ordonnance_edit.setVisibility(View.GONE);
                    }
                }

                break;

            case R.id.ym_ordonnance_patient_sex:
                sexChoiceDialog.setSexString(ym_ordonnance_patient_sex.getText().toString().trim());
                sexChoiceDialog.show();
                break;

            case R.id.ym_ordonnance_diacrisis_rl:
                DrCaseVOBean drCaseVOBean = new DrCaseVOBean();
                drCaseVOBean.setDoctorId(UtilSP.getUserId());
                drCaseVOBean.setDepartment(UtilSP.getFirstDepartmentName());
                drCaseVOBean.setPatientId(chatModel.getUserPatient().getPatientId());
                saveRecommendInfo();
                drCaseVOBean.setGender(recommendInfo.getPatientGender());
                drCaseVOBean.setAge(recommendInfo.getPatientAge());
                drCaseVOBean.setAgeUnit(recommendInfo.getPatientAgeUnit());
                NativeHtml5.drCaseVOBean = drCaseVOBean;
                startActivityForResult(DiagnoseActivity.newIntent(this, diagnosisList), REQUEST_CODE_DIAGNOSE);
                overridePendingTransition(R.anim.activity_open_up, R.anim.activity_no_move);
                break;

            case R.id.ym_ordonnance_patient_age:
                mSetAgeDialog.show();
                break;

        }
    }
    //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
    private void sendGIO(){
        try {
            for(int i = 0;i < mDrugBeanList.size(); i++){
                Map<String,String> track = new HashMap<>();
                //患者id
                track.put("patientID", chatModel.getUserPatient().getPatientId());
                //是否为处方药
                track.put("ifOTC", mDrugBeanList.get(i).isPrescribed()? "是":"不是");
                //通用名称
                track.put("name", mDrugBeanList.get(i).getCommonName());
                //生产厂家
                track.put("manufacturer", mDrugBeanList.get(i).getManufacturer());
                //规格
                track.put("specification", mDrugBeanList.get(i).getSpec());
                //剂型
                track.put("specification", mDrugBeanList.get(i).getMedicineUsageBean().getQuantityUnit());
                //用量
                track.put("effectiveDuration", mDrugBeanList.get(i).getMedicineUsageBean().getLocalDosageStr());
                //用法
                track.put("certification", (mDrugBeanList.get(i).getMedicineUsageBean().getUsageTime())+ mDrugBeanList.get(i).getMedicineUsageBean().getUsageMethod());
                //药品数量
                track.put("amount", mDrugBeanList.get(i).getMedicineUsageBean().getQuantity());
                //金额
                track.put("units", mDrugBeanList.get(i).getSalePrice());
                //医生ID
                track.put("docID", UtilSP.getUserId());
                GrowingIOUtil.track("patientDrugConsultation", track);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    //add by songxin,date：2018-3-29,about：GrowingIO banner track,end

    /**
     * 检查是否需要校验库存，不需要则去发送
     */
    private void checkInventoryInfo() {
        if (patientDrugInfo.isCheckInventoryInfo()) {
            requestGetInventoryInfo(patientDrugInfo.isCheckInventoryInfo());
            return;
        }
        // 请求正大天晴
        requestCttqVerify();
    }

    /**
     * 备案dialog
     * @param status 状态
     * @param text 对话框内容
     * @param forbidenRecom 是否禁止推药，（1：允许，2：禁止，0：无文案（历史数据）禁止推送，）
     */
    private void showSHospitalBackupsDialog(final int status, String text,final String forbidenRecom ) {
        if("0".equals(forbidenRecom)){
            text = "根据卫健委要求，也是为了保障您的处方行为真实有效，请提交互联网医院备案资料";
        }
        new YR_CommonDialog(this, text, "取消", "去备案") {
            @Override
            public void confirmBtn() {
                HospitalBackupsBeanSP.TO_ACTIVITY = NativeHtml5.RECOMMEND_DETAIL;
                UtilNativeHtml5.toJumpNativeH5(SQ_RecommendActivity218.this, UtilNativeHtml5.INTERNET_HOSPITAL_RECORD);
                dismiss();
            }

            @Override
            public void cancelBtn() {
                if(status == 4){
                    if("1".equals(forbidenRecom)){  // 允许推荐
                        // 推药
                        dismiss();
                        checkInventoryInfo();
                    }else if("0".equals(forbidenRecom)){ // 旧版本处理
                        dismiss();
                        showCheckUsageDialog(CommonConfig.RECOMMEND_PATH);
                    }else { // 禁止推荐
                        dismiss();
                    }
                }
            }
        }.show();
    }

    /**
     * 我知道提示dialog
     *
     * @param content
     */
    public void showCheckUsageDialog(String content) {
        if (mYR_commonDialog == null) {
            mYR_commonDialog = new YR_CommonDialog(mContext, content, "", "知道了") {
                @Override
                public void confirmBtn() {
                    mYR_commonDialog.dismiss();
                }
            };
        }
        mYR_commonDialog.setContentStr(content);
        mYR_commonDialog.show();
    }

    private YR_CommonDialog mInventoryInfoDialog;
    /**
     * 库存信息dialog
     */
    public void showInventoryInfoDialog(int index,String name) {
        String content;
        if(1 == index){
            content = "当前处方中的"+ name +"已下架，请确认是否继续发送该处方？";
        }else {
            content = "当前处方中的"+ name +"库存不足，请确认是否继续发送该处方？";
        }

        if (mInventoryInfoDialog == null) {
            mInventoryInfoDialog = new YR_CommonDialog(mContext, content, "取消", "继续发送") {
                @Override
                public void cancelBtn() {
                    dismiss();
                }

                @Override
                public void confirmBtn() {
                    requestCttqVerify();
                    mInventoryInfoDialog.dismiss();
                }
            };
        }
        mInventoryInfoDialog.setContentStr(content);
        mInventoryInfoDialog.show();
    }

    /**
     * 效验用法用量
     *
     * @return true 通过
     */
    private boolean checkUsage() {
        boolean result = true;
        StringBuilder dialogContentSB = new StringBuilder();
        boolean isFirst = true;
        for (DrugBean bean : mDrugBeanList) {
            if (UtilString.isBlank(bean.getMedicineUsageBean().getBakUp()) && UtilString.isBlank(bean.getMedicineUsageBean().getUsages())) {
                String name = bean.getName();
                if (isFirst) {
                    isFirst = false;
                } else {
                    dialogContentSB.append("\n");
                }
                dialogContentSB.append(name);
            }
        }
        String dialogContent = dialogContentSB.toString();
        if (!UtilString.isBlank(dialogContent)) {
            dialogContent = "以下药品未填写用法用量，请先补充：\n" + dialogContent;
            showCheckUsageDialog(dialogContent);
            result = false;
        }
        return result;
    }

    /**
     * 请求查询库存信息
     */
    public void requestGetInventoryInfo(final boolean isShowInventoryInfoDialog) {
        // 如果药品集合为空则不请求
        if(UtilCollection.isBlank(mDrugBeanList)) return;
        String skuIds = "";
        String buyNums = "";
        // 拼接skuid和购买数量
        for (DrugBean bean : mDrugBeanList) {
            String skuId = bean.getSkuId();
            String num = bean.getMedicineUsageBean().getQuantity();
            skuIds = skuIds + skuId + ",";
            buyNums = buyNums + num + ",";
        }
        skuIds = UtilString.getStringWithoutLast(skuIds);
        buyNums = UtilString.getStringWithoutLast(buyNums);

        RequestParams params = new RequestParams();
        params.put("skuIds", skuIds);
        params.put("nums", buyNums);
        params.put("patientId",patientDrugInfo.getChatModel().getUserPatient().getPatientId());

        XCHttpAsyn.postAsyn(mContext, AppConfig.getHostUrl(AppConfig.inventory_info), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {
                    Parse2InventoryInfo parse2InventoryInfo = new Parse2InventoryInfo();
                    List<InventoryInfo> list = parse2InventoryInfo.parse(result_bean);
                    try {
                        int salaCount = 0;
                        int shortCount = 0;
                        String drugName = "";
                        for (int i = 0; i < mDrugBeanList.size(); i++) {
                            mDrugBeanList.get(i).getInventoryInfo().setStockNum(list.get(i).getStockNum());
                            mDrugBeanList.get(i).getInventoryInfo().setIsPresell(list.get(i).getIsPresell());
                            mDrugBeanList.get(i).getInventoryInfo().setIsShort(list.get(i).getIsShort());
                            mDrugBeanList.get(i).getInventoryInfo().setPresellInfo(list.get(i).getPresellInfo());
                            mDrugBeanList.get(i).getInventoryInfo().setSale(list.get(i).isSale());
                            mDrugBeanList.get(i).getInventoryInfo().setIslimit(list.get(i).getIslimit());
                            mDrugBeanList.get(i).getInventoryInfo().setPatientLimitInfo(list.get(i).getPatientLimitInfo());
                            mDrugBeanList.get(i).getInventoryInfo().setSkuLimitInfo(list.get(i).getSkuLimitInfo());
                            mDrugBeanList.get(i).setSale(list.get(i).isSale());
                            mDrugBeanList.get(i).setSixtyDosage(list.get(i).getSixtyDosage());
                            mDrugBeanList.get(i).setDosageMonth(list.get(i).getDosageMonth());
                            mDrugBeanList.get(i).setDosageWeek(list.get(i).getDosageWeek());
                            // 控制是否校验库存，显示对话框
                            if(!isShowInventoryInfoDialog) {
                                continue;
                            }
                            // 以下是续方和常用处方发送前校验库存逻辑
                            if(salaCount == 0 && "1".equals(list.get(i).getIsShort())) {
                                // 缺货
                                shortCount++;
                                if (shortCount == 1) {
                                    drugName = mDrugBeanList.get(i).getName();
                                } else if (shortCount == 2) {
                                    drugName = drugName + "等药品";
                                }
                            }else if(shortCount == 0 && !list.get(i).isSale()){
                                // 下架
                                salaCount++;
                                if(salaCount == 1){
                                    drugName = mDrugBeanList.get(i).getName();
                                }else if (salaCount == 2){
                                    if(!"1".equals(list.get(i).getIsShort())){
                                        drugName = drugName + "等药品";
                                    }else { // 即是下架又是库存不足
                                        salaCount --;
                                    }
                                }
                            }
                        }
                        // 是否校验库存，显示对话框
                        if(isShowInventoryInfoDialog) {
                            if (shortCount > 0) {
                                showInventoryInfoDialog(2, drugName);
                                XCHttpAsyn.closeLoadingDialog();
                            }else if (salaCount > 0) {
                                showInventoryInfoDialog(1, drugName);
                                XCHttpAsyn.closeLoadingDialog();
                            }else {
                                requestCttqVerify();
                            }
                        }else {
                            if(isActivityResult){
                                isActivityResult = false;
                            }else {
                                XCHttpAsyn.closeLoadingDialog();
                            }
                        }
                        recommendAdapter.notifyDataSetChanged();
                    } catch (Exception e) {
                        isActivityResult = false;
                        XCHttpAsyn.closeLoadingDialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                isActivityResult = false;
            }

            @Override
            public void onFinish() {
                // super.onFinish();
                if (!GeneralReqExceptionProcess.checkCode(mContext,getCode(),getMsg())) {
                    isActivityResult = false;
                    XCHttpAsyn.closeLoadingDialog();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        returnToChoiceMedicineActivity();
    }

    /**
     * 组建save接口请求json，提交给服务器
     */
    private JSONObject createJson(XC_PatientDrugInfo patientDrugInfo) {

        JSONObject data = new JSONObject();
        try {
            saveRecommendInfo();
            UserPatient userPatient = patientDrugInfo.getChatModel().getUserPatient();
            data.put("patientAge", recommendInfo.getPatientAge());
            data.put("patientAgeUnit", recommendInfo.getPatientAgeUnit());
            data.put("patientGender", recommendInfo.getPatientGender());
            data.put("patientId", userPatient.getPatientId());
            data.put("patientName", recommendInfo.getPatientName());
            if(!TextUtils.isEmpty(patientDrugInfo.getRecommendInfo().getOriginRecom())){//3.4新加续方来源
                data.put("originRecom",patientDrugInfo.getRecommendInfo().getOriginRecom());
            }
            data.put("timestamp", System.currentTimeMillis()); // 请求时间戳
            // 患者自主购药id ，主动推荐传 0
            if ("".equals(patientDrugInfo.getChatModel().getRequireId())
                    || "0".equals(patientDrugInfo.getChatModel().getRequireId())) {
                data.put("requireId", 0);
                data.put("type", 1);  //推荐类型(1:普通推荐,2:求药推荐)
            } else {
                data.put("requireId", patientDrugInfo.getChatModel().getRequireId());
                data.put("type", 2);
            }

            JSONArray diagnosis = new JSONArray();
            for (DiagnoseBean bean : diagnosisList) {
                diagnosis.put(bean.name);
            }
            data.put("diagnosis", diagnosis);

            // collectStatus (integer, optional): 病历数据收集状态 1：同意， 2：不同意，3：不提示，4：暂不同意
            data.put("collectStatus", medicalServiceFeeDialog.getCollectStatus());

            JSONArray drugItems = getDrugInfoJsonArray();
            data.put("items", drugItems);

        } catch (Exception e) {
            e.printStackTrace();
            XCApplication.base_log.debugShortToast("创建json异常");
        }
        return data;

    }

    @NonNull
    private JSONArray getDrugInfoJsonArray(){
        savePatientDrugInfo();
        List<DrugBean> drugBeanList = patientDrugInfo.getList();
        JSONArray drugItems = new JSONArray();
        try{
            JSONObject drugItem;
            for (DrugBean bean : drugBeanList) {
                drugItem = new JSONObject();
                drugItem.put("backup", bean.getMedicineUsageBean().getBakUp());
                drugItem.put("commonName", bean.getCommonName());
                drugItem.put("productId", bean.getId());
                drugItem.put("productName", bean.getName());
                drugItem.put("quantity", bean.getMedicineUsageBean().getQuantity());
                drugItem.put("skuId", bean.getMedicineUsageBean().getSkuId());
                drugItem.put("usage", bean.getMedicineUsageBean().getUsages());
                drugItem.put("dosageCount", bean.getMedicineUsageBean().getDosageCount());
                drugItem.put("dosageCycle", bean.getMedicineUsageBean().getDosageCycle());
                drugItem.put("dosageCycleUnit", bean.getMedicineUsageBean().getDosageCycleUnit());
                drugItem.put("drugCycle", bean.getMedicineUsageBean().getDrugCycle());
                drugItem.put("drugCycleUnit", bean.getMedicineUsageBean().getDrugCycleUnit());
                drugItem.put("eachDosageCount", bean.getMedicineUsageBean().getEachDosageCount());
                drugItem.put("eachDoseUnit", bean.getMedicineUsageBean().getEachDoseUnit());
                drugItem.put("quantityUnit", bean.getMedicineUsageBean().getQuantityUnit());
                drugItem.put("usageMethod", bean.getMedicineUsageBean().getUsageMethod());
                drugItem.put("usageTime", bean.getMedicineUsageBean().getUsageTime());
                drugItem.put("containUsageDetail", bean.isContainUsageDetail());
                drugItems.put(drugItem);
            }
        }catch (Exception e){e.printStackTrace();}
        return drugItems;
    }

    /**
     * 初始化处方单数据
     */
    public void requestInitData() {
        RequestParams params = new RequestParams();
        params.put("patientId", patientDrugInfo.getChatModel().getUserPatient().getPatientId());
        XCHttpAsyn.postAsyn(mContext, AppConfig.getTuijianUrl(AppConfig.prescriptionInit), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {
                    isRequestInitData = false;
                    Parser2SQRecommendInfo parser2SQRecommendInfo = new Parser2SQRecommendInfo(recommendInfo);
                    parser2SQRecommendInfo.parseJson(result_bean);

                    setDataToViews();
                    if(!UtilSP.isRecomSafe()) {
                        requestRemind();
                    }
                    patientDrugInfo.setRecommendInfo(recommendInfo);
                }else {
                    isRequestInitData = true;
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 创建推荐单
     */
    public void requestSave() {
        JSONObject jsonObject = createJson(patientDrugInfo);
        XCHttpAsyn.postAsync(true,true,mContext, AppConfig.getTuijianUrl(AppConfig.recomSave+ "?doctorId="+UtilSP.getUserId()+
                        "&token="+UtilSP.getUserToken()),
                jsonObject.toString(), new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        try {

                            if (result_boolean && !mContext.isDestroy) {
                                // eSignSerial (Array[string]): 电子签名签署单号
                                // recomId (integer): 推荐ID
                                // changedRemarkName (boolean): 是否更新备注名
                                // safeMedicine (RecomSafeMedicineVO, optional): 安全用药检查

                                if (result_bean.getList("data").get(0).getBoolean("changedRemarkName")) {
                                    // 2.9版本 更新患者备注名
                                    requestPatientSimple();
                                }

                                patientDrugInfo.getChatModel().setRecommandId(result_bean.getList("data").get(0).getString("recomId"));

                                if (!"2".equals(UtilSP.getDoctorStatus())) {
                                    sendToChatDetailActivity();
                                    return;
                                }

                                List<String> eSignSerial = result_bean.getList("data").get(0).getStringList("eSignSerial");
                                ElectronicSignatureHelper.getInstance().signFile(SQ_RecommendActivity218.this, eSignSerial, signListener);

                            }
                        } catch (Exception e) {
                            XCHttpAsyn.closeLoadingDialog();
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFinish() {
                        // super.onFinish();
                        if (!GeneralReqExceptionProcess.checkCode(mContext,getCode(),getMsg())) {
                            XCHttpAsyn.closeLoadingDialog();
                        }
                    }
                });

    }

    /**
     * 请求医事服务费接口
     */
    public void requestCollectPrompt() {
        JSONArray jsonArray = getDrugInfoJsonArray();
        XCHttpAsyn.postAsync(true,mContext, AppConfig.getTuijianUrl(AppConfig.COLLECT_PROMPT + "?doctorId="+UtilSP.getUserId()+
                        "&token="+UtilSP.getUserToken()),
                jsonArray.toString(), new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        // -------------- 以下为该接口返回参数 ---------------------
                        // cost (integer, optional): 平台补贴医事服务费 ,
                        // flag (integer, optional): 是否提示病历数据收集标识： 0 不提示， 1 提示 ,
                        // reward (integer, optional): 病历数据收集费
                        // ------------------------------------------------------
                        try {
                            if (result_boolean && !mContext.isDestroy) {
                                XCJsonBean jsonBean = result_bean.getList("data").get(0);
                                String cost = jsonBean.getString("cost");
                                String flag = jsonBean.getString("flag");
                                String reward = jsonBean.getString("reward");

                                medicalServiceFeeDialog.getTv_medical_service_fee().setText("平台将补贴给您"+ cost +"元医事服务费");
                                // 显示是否同意布局
                                medicalServiceFeeDialog.setCollectStatus(flag);
                                medicalServiceFeeDialog.setReward(reward);
                                medicalServiceFeeDialog.show();
                                XCHttpAsyn.closeLoadingDialog();
                            }
                        } catch (Exception e) {
                            XCHttpAsyn.closeLoadingDialog();
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFinish() {
                        if (!GeneralReqExceptionProcess.checkCode(mContext,getCode(),getMsg())) {
                            XCHttpAsyn.closeLoadingDialog();
                        }
                    }
                });

    }

    /**
     * 用药安全提示
     */
    public void requestRemind() {
        if(UtilSP.isRecomSafe()){
            return;
        }

        if(TextUtils.isEmpty(ym_ordonnance_patient_age.getText().toString().trim())){
            return;
        }

        RequestParams params = new RequestParams();
        params.put("patientId", chatModel.getUserPatient().getPatientId());
        String age = ym_ordonnance_patient_age.getText().toString().trim();
        if(age.contains("周")){
            params.put("age",UtilString.getStringWithoutLast(age,"周"));
            params.put("patientAgeUnit","周");
        }else if(age.contains("个月")){
            params.put("age",UtilString.getStringWithoutLast(age,"个月"));
            params.put("patientAgeUnit","个月");
        }else if(age.contains("岁")){
            params.put("age",UtilString.getStringWithoutLast(age,"岁"));
            params.put("patientAgeUnit","岁");
        }

        // 患者性别：0.女 1.男
        int gender;
        if ("女".equals(ym_ordonnance_patient_sex.getText().toString().trim())) {
            gender = 0;
            params.put("gender", gender);
        } else if ("男".equals(ym_ordonnance_patient_sex.getText().toString().trim())){
            gender = 1;
            params.put("gender", gender);
        }

        XCHttpAsyn.postAsyn(false, this, AppConfig.getTuijianUrl(AppConfig.recomRemind), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {
                    try {

                        //content (string,): 提醒内容 ,
                        //remind (integer): 是否提示：0.不提示 1.提示
                        if ("1".equals(result_bean.getList("data").get(0).getString("remind"))) {
                            XCApplication.base_log.shortToast(result_bean.getList("data").get(0).getString("content"));
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 2.9版本需求
     * 获取患者姓名更新患者数据库
     */
    public void requestPatientSimple() {
        RequestParams params = new RequestParams();
        params.put("patientId", chatModel.getUserPatient().getPatientId());

        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.patientSimple), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {

                    try {

                        // id (integer),
                        // name (string): 患者姓名或昵称 ,
                        // remarkName (string): 患者备注名

                        JS_ChatListModel chatListModel = JS_ChatListDB.getInstance(context, UtilSP.getUserId()).getPatientInfo(chatModel.getUserPatient().getPatientId());
                        chatListModel.getUserPatient().setPatientName(result_bean.getList("data").get(0).getString("name"));
                        chatListModel.getUserPatient().setPatientMemoName(result_bean.getList("data").get(0).getString("remarkName"));
                        JS_ChatListDB.getInstance(context, UtilSP.getUserId()).updatePatientInfo(chatListModel);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }

            @Override
            public void onFinish() {
                // super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }

        // 从临床诊断返回
        if (requestCode == REQUEST_CODE_DIAGNOSE) {
            diagnosisList = (ArrayList<DiagnoseBean>) data.getSerializableExtra(DiagnoseActivity.INTENT_KEY_DIAGNOSIS);
            setDiagnosisText();
            if(UtilCollection.isBlank(diagnosisList) && UtilCollection.isBlank(mDrugBeanList)){
                setSaveTextViewState(2);
            }else if(patientDrugInfo.getDiagnoseBeanList().size() != diagnosisList.size()){
                setSaveTextViewState(0);
            }else {
                for(int i = 0 ; i < patientDrugInfo.getDiagnoseBeanList().size() ; i++){
                    // 判断数据是否有修改
                    if(!patientDrugInfo.getDiagnoseBeanList().get(i).name.equals(diagnosisList.get(i).name)){
                        setSaveTextViewState(0);
                        break;
                    }
                }
            }
            patientDrugInfo.setDiagnoseBeanList(diagnosisList);

            // 从用法用量返回
        } else if (requestCode == UsageActivityV2.REQUEST_CODE_USAGE) {
            DrugBean drugBean = (DrugBean)data.getSerializableExtra(UsageActivityV2.DRUG_INFO);
            if(editPosition != -1){
                if(mDrugBeanList.get(editPosition) != null) {
                    // 判断数据是否有修改
                    if(!mDrugBeanList.get(editPosition).getMedicineUsageBean().getUsages().equals(
                            drugBean.getMedicineUsageBean().getUsages())
                            || !mDrugBeanList.get(editPosition).getMedicineUsageBean().getBakUp().equals(
                            drugBean.getMedicineUsageBean().getBakUp())
                            || !mDrugBeanList.get(editPosition).getMedicineUsageBean().getQuantity().equals(
                            drugBean.getMedicineUsageBean().getQuantity())
                            ) {
                        setSaveTextViewState(0);
                    }
                    mDrugBeanList.remove(editPosition);
                    mDrugBeanList.add(editPosition,drugBean);
                    editPosition = -1;
                }
            }
            computeTotalPrice();
            notifyDataSetChanged();

            // 从安全用药点击仍然发送
        }else if(requestCode == SafeMedicationActivity.REQUEST_CODE_SAFE_MEDICATION){
            isActivityResult = true;
            if(checkSafeRecomNextTag == 0){  // 0为保存常用处方触发的安全校验
                addPrescription();
            }else {
                toSend();
            }
        }
    }

    /**
     * 设置临床诊断
     */
    private void setDiagnosisText() {
        String diagnosisStr = "";
        for (int i = 0; i < diagnosisList.size(); i++) {
            if (i == diagnosisList.size() - 1) {
                diagnosisStr = diagnosisStr + diagnosisList.get(i).name;
            } else {
                diagnosisStr = diagnosisStr + diagnosisList.get(i).name + ",";
            }
        }

        ym_ordonnance_diacrisis_edt.setText(diagnosisStr);
    }

    private YR_CommonDialog medicineFifterDialog;
    private void medicineFifterDialog(String medicines) {
        medicineFifterDialog = new YR_CommonDialog(this, medicines, "", "我知道了") {
            @Override
            public void confirmBtn() {
                medicineFifterDialog.dismiss();
            }
        };
        medicineFifterDialog.setCanceledOnTouchOutside(false);
        medicineFifterDialog.show();
    }

    /**
     * 记录点击时候的时间
     */
    private long lastClickTime;

    /**
     * 防止500毫秒内重复点击的方法
     *
     * @return true：重复点击，false：不是重复点击
     */
    public boolean isFastClick() {
        long time = System.currentTimeMillis();
        if (time - lastClickTime < 1000) {
            return true;
        }
        lastClickTime = time;
        return false;
    }

    /**
     *  校验正大天晴
     */
    public void requestCttqVerify(){
        // 如果药品集合为空则不请求
        if(UtilCollection.isBlank(mDrugBeanList)) return;
        String pids = "";
        // 拼接商品Id
        for (DrugBean bean : mDrugBeanList) {
            String pid = bean.getId();
            pids = pids + pid + ",";
        }
        pids = UtilString.getStringWithoutLast(pids);
        RequestParams params = new RequestParams();
        params.put("pids", pids);

        XCHttpAsyn.postAsyn(mContext, AppConfig.getTuijianUrl(AppConfig.cttqVerify), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {
                    // 安全用药提醒
                    if(UtilSP.isRecomSafe()) {
                        checkSafeRecomNextTag = 1;
                        requestSafeMedication();
                    }else {
                        requestMatching();
                    }
                }
            }

            @Override
            public void onFinish() {
                // super.onFinish();
                if (CommonConfig.MEDICINE_FIFTER_CODE.equals(getCode())){//符合正大天晴项目拦截规则，则弹出对话框(之所以在这里返回是为了防止弹出Toast)，否则进行下一步操作，
                    showCheckUsageDialog(getMsg());
                    XCHttpAsyn.closeLoadingDialog();
                    return;
                }
                if (!GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                    XCHttpAsyn.closeLoadingDialog();
                }
            }
        });

    }
    /**
     * 查询是否设置电子签名
     */
    public void getCertInfo(){
            ElectronicSignatureHelper.getInstance().getCertInfo(true,this,new ElectronicSignatureHelper.CertInfoListener() {
                @Override
                public void onCertInfo(GdcaCertModel var1) {
                    // 已经设置电子签名
                    checkInventoryInfo();
                }

                @Override
                public void onFail(String msg, int code) {
                    if (code == ElectronicSignatureHelper.UNSET_CERT) {
                        //未设置证书
                        YR_CommonDialog mSetCertDialog = new YR_CommonDialog(SQ_RecommendActivity218.this, "根据卫健委要求，您是互联网医院备案医生\n请先设置电子签名后处方",
                                "暂不处理", "设置电子签名") {
                            @Override
                            public void confirmBtn() {
                                this.dismiss();
                                ToJumpHelp.toJumpHospitalBackupsActivity(SQ_RecommendActivity218.this);//去备案页
                            }
                        };
                        mSetCertDialog.show();
                    }else {
                        shortToast(msg);
                    }
                }
            });

    }

    /**
     * 请求安全用药提醒
     */
    public void requestSafeMedication(){
        saveRecommendInfo();
        savePatientDrugInfo();

        JSONObject data = new JSONObject();
        try {
            UserPatient userPatient = patientDrugInfo.getChatModel().getUserPatient();
            data.put("patientAge", recommendInfo.getPatientAge());
            data.put("patientAgeUnit",recommendInfo.getPatientAgeUnit());
            data.put("patientGender", recommendInfo.getPatientGender());
            data.put("patientId", userPatient.getPatientId());
            JSONArray diagnosis = new JSONArray();
            for (DiagnoseBean bean : patientDrugInfo.getDiagnoseBeanList()) {
                diagnosis.put(bean.name);
            }
            data.put("diagnosis", diagnosis);
            JSONArray skuIds = new JSONArray();
            for (DrugBean item : recommendInfo.getDrugInfoBean()) {
                skuIds.put(item.getSkuId());
            }
            data.put("skuIds", skuIds);
            List<DrugBean> drugBeans = patientDrugInfo.getList();
            JSONArray recomSafeItems = new JSONArray();
            JSONObject drugItem;
            for (DrugBean item : drugBeans){
                drugItem = new JSONObject();
                drugItem.put("commonName",item.getCommonName());
                drugItem.put("productName", item.getName());
                drugItem.put("recomName", item.getRecomName());
                drugItem.put("quantity",item.getMedicineUsageBean().getQuantity());
                drugItem.put("skuId",item.getMedicineUsageBean().getSkuId());
                recomSafeItems.put(drugItem);
            }
            data.put("recomSafeItems", recomSafeItems);
        } catch (Exception e) {
            e.printStackTrace();
            XCApplication.base_log.debugShortToast("创建json异常");
        }

        // 发送请求
        XCHttpAsyn.postAsync(true,true,this,AppConfig.getTuijianUrl(AppConfig.recomCheck+ "?doctorId="+UtilSP.getUserId()+
                "&token="+UtilSP.getUserToken()),data.toString(),new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean && context != null){
                    try {
                        Parse2SafeMedication parse2SafeMedication = new Parse2SafeMedication();
                        SafeMedicationBean safeMedicationBean = parse2SafeMedication.parse(result_bean.getList("data").get(0));
                        if("3".equals(safeMedicationBean.getSafeStatus())){ // 通过
                            if(checkSafeRecomNextTag == 0){  // 0为保存常用处方触发的安全校验
                                addPrescription();
                            }else {
                                toSend();
                            }
                        }else if("2".equals(safeMedicationBean.getSafeStatus())){ // 谨慎
                            // 若两次提醒一致
                            if(safeMedicationBean.getSn().equals(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getSn())){
                                if(checkSafeRecomNextTag == 0){  // 0为保存常用处方触发的安全校验
                                    addPrescription();
                                }else {
                                    toSend();
                                }
                                return;
                            }
                            // 设置安全提醒的按钮为 仍然保存
                            if(checkSafeRecomNextTag == 0) safeMedicationBean.setBtnTextTag(1);
                            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setSn(safeMedicationBean.getSn());
                            SafeMedicationActivity.launch(SQ_RecommendActivity218.this,safeMedicationBean);
                        }else if("1".equals(safeMedicationBean.getSafeStatus())){ // 禁用
                            if(checkSafeRecomNextTag == 0) safeMedicationBean.setBtnTextTag(1);
                            SafeMedicationActivity.launch(SQ_RecommendActivity218.this,safeMedicationBean);
                        }
                    }catch (Exception e){
                        XCHttpAsyn.closeLoadingDialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                // super.onFinish();
                if (!GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                    XCHttpAsyn.closeLoadingDialog();
                }
            }
        });
    }

    private void toSend() {
        // 阳光化状态  1：否；2：是
        if("2".equals(UtilSP.getDoctorSunshine())){
            requestCollectPrompt();
        }else {
            requestSave();
        }
    }

    /* 推荐用药调用接口 */
    private void requestSendRecommendMedicine(final XC_ChatModel model){
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("recomId", model.getRecommandId());
        params.put("force", model.isForce());
        XCHttpAsyn.postAsyn(true,this,AppConfig.getTuijianUrl(AppConfig.recomConfirm),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    XC_ChatModel chatModel = UtilPackMsg.packRecommandMedicineMsg(patientDrugInfo);
                    RecommendMedicineResultBean resultBean = new RecommendMedicineResultBean();
                    Parser2RecomMedResultBean parser2RecomMedResultBean = new Parser2RecomMedResultBean(resultBean);
                    parser2RecomMedResultBean.parseJson(result_bean);
                    chatModel.setMsgTime(resultBean.getSendTime());
                    chatModel.setMessageId(resultBean.getMessageId());
                    // 推荐用药的审核状态
                    chatModel.setRecommandStatus(resultBean.getCheckingStatus());
                    chatModel.setSessionId(resultBean.getSessionId());
                    chatModel.setSessionBeginTime(resultBean.getBeginTime());
                    chatModel.getChatSession().setConsultSourceType(resultBean.getConsultSourceType());
                    chatModel.setSessionJson(UtilIMCreateJson.createSessionJson(chatModel));
                    String content = UtilIMCreateJson.createMedicineJson(chatModel);//3.4版本后推荐用药(非医嘱处方)开始存储content字段到数据库
                    chatModel.setContent(content);
                    XCChatModelDb.getInstance(getApplicationContext(), UtilSP.getIMDetailDbName(UtilSP.getUserId(), chatModel.getUserPatient().getPatientId())).insert(chatModel);
                    UtilInsertMsg2JsDb.insert(getApplicationContext(), chatModel);
                    if("2".equals(RecomMedicineHelper.getInstance().getFlag())){
                        DBApplication.finishActivities(YR_RecommendDetailActivity.class);
                        DBApplication.finishActivities(YM_ExplainActivity.class);
                        myFinish();
                        //通知患者病例页刷新诊疗记录
                        Intent intent = new Intent();
                        intent.setAction(XL_PatientInfoAActivity.NewMedicalReceiver.NEW_MEDICAL_ACTION);
                        context.sendBroadcast(intent);
                    }else {
                        UtilChat.launchChatDetail(SQ_RecommendActivity218.this, chatModel.getUserPatient().getPatientId(), null);
                    }
                    //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
                    sendGIO();
                    //add by songxin,date：2018-3-29,about：GrowingIO banner track,end
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                // 处理code操作
                GeneralReqExceptionProcess.checkCode(SQ_RecommendActivity218.this, getCode(), getMsg());
            }
        });
    }

    /**
     * 新建常用处方
     */
    private void addPrescription() {

        RecipeBean recipeBean = new RecipeBean();
        recipeBean.setDiagnosisList(diagnosisList);
        recipeBean.setDrugBeans((ArrayList<DrugBean>) mDrugBeanList);

        RequestParams params = new RequestParams();
        String str = UtilIMCreateJson.createCommonPrescriptionJson(recipeBean);
        params.put("commonPrescription", str);
        XCHttpAsyn.postAsync(true, true, mContext, AppConfig.getHostUrl(AppConfig.addCommonPrescription + "?doctorId=" + UtilSP.getUserId() +
                "&token=" + UtilSP.getUserToken()), str, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    setSaveTextViewState(1);
                    RecomMedicineHelper.getInstance().setUpdateCommonRecipe(true);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 2.16 版本
     * 发送处方前校验备案
     */
    public void requestRecomCheck() {
        RequestParams params = new RequestParams();
        XCHttpAsyn.postAsyn(true, this, AppConfig.getTuijianUrl(AppConfig.recordCheck), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {
                    try {
                        // forbidenRecom (integer, optional): 是否禁止推药，1：允许，2：禁止，0：历史数据 ,3:继续发送
                        // remindInfo (string, optional): 提示信息
                        String forbidenRecom = result_bean.getList("data").get(0).getString("forbidenRecom");
                        String remindInfo = result_bean.getList("data").get(0).getString("remindInfo");
                        if("3".equals(forbidenRecom)){
                            checkInventoryInfo();
                            return;
                        }
                        XCHttpAsyn.closeLoadingDialog();
                        showSHospitalBackupsDialog(4,remindInfo,forbidenRecom);
                    } catch (Exception e) {
                        XCHttpAsyn.closeLoadingDialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                // super.onFinish();
                if (!GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                    XCHttpAsyn.closeLoadingDialog();
                }
            }
        });
    }

}
