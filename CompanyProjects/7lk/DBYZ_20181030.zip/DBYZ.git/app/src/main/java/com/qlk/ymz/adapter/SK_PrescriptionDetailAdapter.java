package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.qlk.ymz.R;
import com.qlk.ymz.adapter.ViewHolder.SK_PrescriptionDetailViewHolder;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.util.SP.UtilSP;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * @author 赖善琦
 * @description 电子处方单详情
 */
public class SK_PrescriptionDetailAdapter extends XCBaseAdapter<DrugBean> {
    private boolean isPreview = false;//是否是预览页

    public SK_PrescriptionDetailAdapter(Context context,boolean isPreview, List<DrugBean> list) {
        super(context, list);
        this.isPreview = isPreview;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        DrugBean model = list.get(position);
        SK_PrescriptionDetailViewHolder holder;
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.sk_item_prescription_detail,null);
            holder = new SK_PrescriptionDetailViewHolder(convertView);
            convertView.setTag(holder);
        }else {
            holder = (SK_PrescriptionDetailViewHolder) convertView.getTag();
        }

        String note = model.getMedicineUsageBean().getBakUp();
        if(TextUtils.isEmpty(note)){ // 备注为空
            holder.tv_item_prescription_drugUsage.setText("用法："+ model.getMedicineUsageBean().getUsages());

        }else{ // 备注不为空
            if(TextUtils.isEmpty(model.getMedicineUsageBean().getUsages())){ // 用法用量为空
                holder.tv_item_prescription_drugUsage.setText("用法："+ note);
            }else {
                holder.tv_item_prescription_drugUsage.setText("用法："+model.getMedicineUsageBean().getUsages() + "," + note);
            }
        }

        holder.tv_item_prescription_drugName.setText(model.getRecomName());
        holder.tv_item_prescription_drugNum.setText("×" + model.getMedicineUsageBean()
                .getQuantity()+ (TextUtils.isEmpty(model.getMedicineUsageBean().getQuantityUnit())?"":model.getMedicineUsageBean()
                .getQuantityUnit()));

        if(position == list.size() - 1){
            holder.v_line.setVisibility(View.GONE);
        } else {
            holder.v_line.setVisibility(View.VISIBLE);
        }

        if (!UtilString.isBlank(model.getExpireDesc())){
            holder.tv_medicine_limit_time.setVisibility(View.VISIBLE);
            holder.tv_medicine_limit_time.setText(model.getExpireDesc());
        }else {
            holder.tv_medicine_limit_time.setVisibility(View.GONE);
        }

        if(isPreview){
            showSafeHint(model,holder);
        }

        return convertView;
    }

    /**
     * 安全用量提示
     */
    public void showSafeHint(DrugBean drugBean,SK_PrescriptionDetailViewHolder viewHolder){
        String hint = "";
        if(UtilSP.isRecomSafe()) {
            int num = UtilString.toInt(drugBean.getMedicineUsageBean().getQuantity(), 0);
            if (drugBean.getSixtyDosage()>0 &&num >drugBean.getSixtyDosage()) {
                hint = "禁止：超出安全用药用量上限(上限2个月)";
                viewHolder.tv_item_safe_dosage.setTextColor(context.getResources().getColor(R.color.c_e2231a));
            } else if (drugBean.getDosageMonth()>0 &&num >drugBean.getDosageMonth()) {
                hint = "谨慎：当前药品用量大于30天用量";
                viewHolder.tv_item_safe_dosage.setTextColor(context.getResources().getColor(R.color.c_f5a623));
            } else if (drugBean.getDosageWeek()>0 &&num >drugBean.getDosageWeek()) {
                hint = "谨慎：当前药品用量大于7天用量";
                viewHolder.tv_item_safe_dosage.setTextColor(context.getResources().getColor(R.color.c_f5a623));
            }
            if(TextUtils.isEmpty(hint)){
                viewHolder.tv_item_safe_dosage.setVisibility(View.GONE);
            }else {
                viewHolder.tv_item_safe_dosage.setVisibility(View.VISIBLE);
                viewHolder.tv_item_safe_dosage.setText(hint);
            }
        }
    }
}
