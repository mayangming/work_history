package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.RecommendInfo;
import com.qlk.ymz.model.record.DoctorDesVOBean;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.model.record.PatientCaseVOBean;
import com.qlk.ymz.model.record.PatientOldCaseVOBean;
import com.qlk.ymz.model.record.PrescriptionListBean;
import com.qlk.ymz.model.record.PrescriptionVOBean;
import com.qlk.ymz.model.record.RecordVOBean;
import com.qlk.ymz.parse.Parser2RecommendInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilScreen;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * SX_MedicalRecordsAdapter
 * 诊疗记录适配器
 *
 * @author songxin on 2016/6/14.
 * @version 2.5.0
 */
public class SX_MedicalRecordsAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private ViewHolder mViewHolder;
    private List<DrRecordVOBean> mSX_MedicalRecordsInfo;
    private XC_ChatModel xc_chatModel;
    private int widthScreen;
    private int width;
    private int num;

    public SX_MedicalRecordsAdapter(Context context, List<DrRecordVOBean> sx_medicalRecordsInfos,XC_ChatModel xc_chatModel) {
        this.mInflater = LayoutInflater.from(context);
        this.mContext = context;
        this.mSX_MedicalRecordsInfo = sx_medicalRecordsInfos;
        this.xc_chatModel = xc_chatModel;
        widthScreen = UtilScreen.getScreenWidthPx(mContext) - UtilScreen.dip2px(mContext, 190);
        width = UtilScreen.dip2px(mContext, 70);
        num = widthScreen / width;
    }

    @Override
    public int getCount() {
        return mSX_MedicalRecordsInfo.size();
    }

    @Override
    public Object getItem(int position) {
        return mSX_MedicalRecordsInfo.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        DrRecordVOBean drRecordVOBean = mSX_MedicalRecordsInfo.get(position);
        if (null == convertView) {
            mViewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.sx_l_adapter_medical_records_item, null);
            initViews(convertView);
            convertView.setTag(mViewHolder);
        } else {
            mViewHolder = (ViewHolder) convertView.getTag();
        }
        if (mSX_MedicalRecordsInfo.size() - 1 == position) {
            mViewHolder.v_bottom.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.v_bottom.setVisibility(View.GONE);
        }
        mViewHolder.date_layout.setOnClickListener(null);
        if (drRecordVOBean != null) {
            showBasicInfo(drRecordVOBean);
            // 0:原诊疗记录,1:患者原病例,2:系统处方,3:患者发送病例,4:医生填写病历,5:带基本病情诊疗记录,6:带基本病情系统处方
            String type = drRecordVOBean.getCaseType();
            switch (type) {
                case "0":
                    showRecord(type, drRecordVOBean);
                    break;
                case "1":
                    showPatientOldMedicineInfo(type, drRecordVOBean);
                    break;
                case "2":
                    showPrescWithInfo(type, drRecordVOBean);
                    break;
                case "3":
                    showPatientNewMedicine(type, drRecordVOBean);
                    break;
                case "4":
                    showDoctorInfo(type, drRecordVOBean);
                    break;
                case "5":
                    showRecord(type, drRecordVOBean);
                    break;
                case "6":
                    showPrescWithInfo(type, drRecordVOBean);
                    break;
                case "7":
                case "8":
                    showDoctorInfo(type, drRecordVOBean);
                    break;
            }
        }
        return convertView;
    }

    /**
     * 初始化控件
     * @param convertView
     */
    private void initViews(View convertView) {
        mViewHolder.sx_id_year_month_show = (TextView) convertView.findViewById(R.id.sx_id_year_month_show);
        mViewHolder.sx_id_time_show = (TextView) convertView.findViewById(R.id.sx_id_time_show);
        mViewHolder.sx_id_hospital_show = (TextView) convertView.findViewById(R.id.sx_id_hospital_show);
        mViewHolder.sx_id_department_show = (TextView) convertView.findViewById(R.id.sx_id_department_show);
        mViewHolder.sx_id_record_content_show = (TextView) convertView.findViewById(R.id.sx_id_record_content_show);
        mViewHolder.sx_id_doctor_show = (TextView) convertView.findViewById(R.id.sx_id_doctor_show);
        mViewHolder.v_bottom = convertView.findViewById(R.id.v_bottom);
//            mViewHolder.bottom_line = convertView.findViewById(R.id.bottom_line);
        mViewHolder.image = (TextView) convertView.findViewById(R.id.image);
        mViewHolder.sx_id_patient_push_show = (TextView) convertView.findViewById(R.id.sx_id_patient_push_show);
        mViewHolder.date_layout = (LinearLayout) convertView.findViewById(R.id.sx_id_date_show);
        mViewHolder.info_layout = (LinearLayout) convertView.findViewById(R.id.xl_patient_layout);
        mViewHolder.name = (TextView) convertView.findViewById(R.id.xl_patientinfo_tv_name);
        mViewHolder.age = (TextView) convertView.findViewById(R.id.xl_patientinfo_tv_age);
        mViewHolder.sex = (TextView) convertView.findViewById(R.id.xl_patientinfo_tv_sex);
        mViewHolder.patient_condition_show_layout = (LinearLayout) convertView.findViewById(R.id.xl_patient_conditon_show_layout);
        mViewHolder.xc_id_personbasicinfo_tv_marry_layout = (LinearLayout) convertView.findViewById(R.id.xc_id_personbasicinfo_marry_layout);
        mViewHolder.xc_id_personbasicinfo_tv_height_layout = (LinearLayout) convertView.findViewById(R.id.xc_id_personbasicinfo_height_layout);
        mViewHolder.xc_id_personbasicinfo_tv_weight_layout = (LinearLayout) convertView.findViewById(R.id.xc_id_personbasicinfo_weight_layout);
        mViewHolder.xc_id_personbasicinfo_tv_allergy_layout = (LinearLayout) convertView.findViewById(R.id.xc_id_personbasicinfo_allergy_layout);
        mViewHolder.xc_id_personbasicinfo_tv_anamnesis_layout = (LinearLayout) convertView.findViewById(R.id.xc_id_personbasicinfo_anamnesis_layout);
        mViewHolder.xc_id_personbasicinfo_tv_family_history_layout = (LinearLayout) convertView.findViewById(R.id.xc_id_personbasicinfo_family_history_layout);
        mViewHolder.xc_id_personbasicinfo_tv_genetic_history_layout = (LinearLayout) convertView.findViewById(R.id.xc_id_personbasicinfo_genetic_history_layout);
        mViewHolder.xc_id_personbasicinfo_tv_smoke_layout = (LinearLayout) convertView.findViewById(R.id.xc_id_personbasicinfo_smoke_layout);
        mViewHolder.xc_id_personbasicinfo_tv_drink_layout = (LinearLayout) convertView.findViewById(R.id.xc_id_personbasicinfo_drink_layout);
        mViewHolder.xc_id_personbasicinfo_tv_marry = (TextView) convertView.findViewById(R.id.xc_id_personbasicinfo_tv_marry);
        mViewHolder.xc_id_personbasicinfo_tv_height = (TextView) convertView.findViewById(R.id.xc_id_personbasicinfo_tv_height);
        mViewHolder.xc_id_personbasicinfo_tv_weight = (TextView) convertView.findViewById(R.id.xc_id_personbasicinfo_tv_weight);
        mViewHolder.xc_id_personbasicinfo_tv_allergy = (TextView) convertView.findViewById(R.id.xc_id_personbasicinfo_tv_allergy);
        mViewHolder.xc_id_personbasicinfo_tv_anamnesis = (TextView) convertView.findViewById(R.id.xc_id_personbasicinfo_tv_anamnesis);
        mViewHolder.xc_id_personbasicinfo_tv_family_history = (TextView) convertView.findViewById(R.id.xc_id_personbasicinfo_tv_family_history);
        mViewHolder.xc_id_personbasicinfo_tv_genetic_history = (TextView) convertView.findViewById(R.id.xc_id_personbasicinfo_tv_genetic_history);
        mViewHolder.xc_id_personbasicinfo_tv_smoke = (TextView) convertView.findViewById(R.id.xc_id_personbasicinfo_tv_smoke);
        mViewHolder.xc_id_personbasicinfo_tv_drink = (TextView) convertView.findViewById(R.id.xc_id_personbasicinfo_tv_drink);

        mViewHolder.doctor_write_layout = (LinearLayout) convertView.findViewById(R.id.doctor_write_layout);
        mViewHolder.main_complaint_layout = (LinearLayout) convertView.findViewById(R.id.main_complaint_layout);
        mViewHolder.main_past_layout = (LinearLayout) convertView.findViewById(R.id.past_layout);
        mViewHolder.physical_examination_layout = (LinearLayout) convertView.findViewById(R.id.physical_examination_layout);
        mViewHolder.other_inspections_layout = (LinearLayout) convertView.findViewById(R.id.other_inspections_layout);
        mViewHolder.diagnose_layout = (LinearLayout) convertView.findViewById(R.id.diagnose_layout);
        mViewHolder.testamentary_summary_layout = (LinearLayout) convertView.findViewById(R.id.testamentary_summary_layout);
        mViewHolder.main_complaint = (TextView) convertView.findViewById(R.id.main_complaint);
        mViewHolder.main_past = (TextView) convertView.findViewById(R.id.past_tv);
        mViewHolder.physical_examination = (TextView) convertView.findViewById(R.id.physical_examination);
        mViewHolder.other_inspections = (TextView) convertView.findViewById(R.id.other_inspections);
        mViewHolder.diagnose = (TextView) convertView.findViewById(R.id.diagnose);
        mViewHolder.testamentary_summary = (TextView) convertView.findViewById(R.id.testamentary_summary);

        mViewHolder.disease_description_layout = (LinearLayout) convertView.findViewById(R.id.disease_description_layout);
        mViewHolder.self_diagnosis_results_layout = (LinearLayout) convertView.findViewById(R.id.self_diagnosis_results_layout);
        mViewHolder.disease_description = (TextView) convertView.findViewById(R.id.disease_description);
        mViewHolder.self_diagnosis_results = (TextView) convertView.findViewById(R.id.self_diagnosis);
        mViewHolder.record_content_layout = (LinearLayout) convertView.findViewById(R.id.record_content_layout);
        mViewHolder.photo_layout = (LinearLayout) convertView.findViewById(R.id.photo_layout);
        mViewHolder.hospital_layout = (LinearLayout) convertView.findViewById(R.id.sx_id_hospital_show_layout);
        mViewHolder.presc_layout = (LinearLayout) convertView.findViewById(R.id.prescription_layout);
        mViewHolder.presc_image = (ImageView) convertView.findViewById(R.id.presc_image);
        mViewHolder.out_medical_card = convertView.findViewById(R.id.out_medical_card);
    }

    /**
     * 动态添加ImageView
     * @param list
     * @param size
     * @param type
     * @param recommandId
     * @param patientId
     */
    private void addGroupImage(final ArrayList<String> list, int size, final String type, final String recommandId, final String patientId) {
        mViewHolder.photo_layout.removeAllViews();
        TextView textView = new TextView(mContext);
        textView.setText("其它");
        textView.setTextSize(15);
        textView.setTextColor(mContext.getResources().getColor(R.color.c_7b7b7b));
        LinearLayout.LayoutParams textparams = new LinearLayout.LayoutParams(UtilScreen.dip2px(mContext, 100), LinearLayout.LayoutParams.WRAP_CONTENT);
        textView.setLayoutParams(textparams);
        mViewHolder.photo_layout.addView(textView);
        for (int i = 0; i < size; i++) {
            ImageView imageView = new ImageView(mContext);
            imageView.setImageResource(R.mipmap.bg_pic_default);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, UtilScreen.dip2px(mContext, 70));
            if (i < size - 1) {
                params.setMargins(0, 0, UtilScreen.dip2px(mContext, 10), 0);
            }
            imageView.setLayoutParams(params);
            if ("2".equals(type) || "6".equals(type)) {
                //防止处方图片出现显示不全(这个图片底色也是白的)
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            } else {
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            }
            XCApplication.base_imageloader.displayImage(list.get(i), imageView, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.bg_pic_default));
            final int index = i;
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //(0:为医生添加，1：为患者上传 ,2：系统处方添加)
                    if (("2".equals(type) || "6".equals(type)) && !UtilString.isBlank(recommandId) && !UtilString.isBlank(patientId)) {
                        ToJumpHelp.toJumpRecommendDetailActivity(mContext, recommandId, xc_chatModel.getUserPatient(),"2");
                    } else {
                        ToJumpHelp.toJumpChatImageShowActivity(mContext, list, index);
                    }
                }
            });
            mViewHolder.photo_layout.addView(imageView);
        }
    }

    /**
     * 展示头部一些公共信息
     *
     * @param drRecordVOBean
     */
    private void showBasicInfo(DrRecordVOBean drRecordVOBean) {
        mViewHolder.sx_id_year_month_show.setText(DateUtils.DateFormat(drRecordVOBean.getCreateAt(),"yyyy/MM/dd   HH:mm"));
        if ("1".equals(drRecordVOBean.getCaseType()) || "3".equals(drRecordVOBean.getCaseType())) {
            mViewHolder.sx_id_patient_push_show.setVisibility(View.VISIBLE);
            mViewHolder.sx_id_patient_push_show.setText("患者上传");
        } else if ("2".equals(drRecordVOBean.getCaseType()) || "6".equals(drRecordVOBean.getCaseType())) {
            mViewHolder.sx_id_patient_push_show.setVisibility(View.VISIBLE);
            mViewHolder.sx_id_patient_push_show.setText("系统保存处方");
        } else {
            mViewHolder.sx_id_patient_push_show.setVisibility(View.GONE);
        }
        if("2".equals(drRecordVOBean.getCaseType()) || "6".equals(drRecordVOBean.getCaseType())){
            mViewHolder.info_layout.setVisibility(View.GONE);
        }else {
            String name = drRecordVOBean.getName();
            String age = drRecordVOBean.getAge();
            String sex = drRecordVOBean.getGender();
            if (TextUtils.isEmpty(name) && TextUtils.isEmpty(age) && TextUtils.isEmpty(sex)) {
                mViewHolder.info_layout.setVisibility(View.GONE);
            } else {
                mViewHolder.info_layout.setVisibility(View.VISIBLE);
                mViewHolder.name.setText(name);
                mViewHolder.age.setText(age + drRecordVOBean.getAgeUnit());
                if("0".equals(sex)){
                    mViewHolder.sex.setText("女");
                }else if("1".equals(sex)){
                    mViewHolder.sex.setText("男");
                }
            }
        }

        // 0：父亲；1：母亲；2：兄弟姐妹；3：子女；4：丈夫；5：妻子；6：本人；7：其他家庭成员
        if ("0".equals(drRecordVOBean.getRelation())) {
            mViewHolder.image.setText("父亲");
        } else if ("1".equals(drRecordVOBean.getRelation())) {
            mViewHolder.image.setText("母亲");
        } else if ("2".equals(drRecordVOBean.getRelation())) {
            mViewHolder.image.setText("兄弟姐妹");
        } else if ("3".equals(drRecordVOBean.getRelation())) {
            mViewHolder.image.setText("子女");
        } else if ("4".equals(drRecordVOBean.getRelation())) {
            mViewHolder.image.setText("丈夫");
        } else if ("5".equals(drRecordVOBean.getRelation())) {
            mViewHolder.image.setText("妻子");
        } else if ("6".equals(drRecordVOBean.getRelation())) {
            mViewHolder.image.setText("本人");
        } else if ("7".equals(drRecordVOBean.getRelation())) {
            mViewHolder.image.setText("其他家庭成员");
        }
        if(!TextUtils.isEmpty(drRecordVOBean.getHospitalName())){
            mViewHolder.hospital_layout.setVisibility(View.VISIBLE);
            mViewHolder.sx_id_hospital_show.setText(drRecordVOBean.getHospitalName());
        }else {
            mViewHolder.hospital_layout.setVisibility(View.GONE);
        }
    }

    /**
     * 设置控件隐藏
     */
    private void showViews() {
        mViewHolder.patient_condition_show_layout.setVisibility(View.GONE);
        mViewHolder.doctor_write_layout.setVisibility(View.GONE);
        mViewHolder.record_content_layout.setVisibility(View.GONE);
        mViewHolder.disease_description_layout.setVisibility(View.GONE);
        mViewHolder.self_diagnosis_results_layout.setVisibility(View.GONE);
        mViewHolder.presc_layout.setVisibility(View.GONE);
        mViewHolder.photo_layout.setVisibility(View.GONE);
        mViewHolder.out_medical_card.setVisibility(View.GONE);
    }

    /**
     * 是否展示还有更多图片提示(...)
     *
     * @param pictures
     * @param num
     * @param type
     */
    private void showMoreText(ArrayList<String> pictures, int num, String type, String recommid, String patientid) {
//        if (pictures.size() > num) {
//            num = num - 1;
//            addGroupImage(pictures, num, type, recommid, patientid);
//            TextView textView = new TextView(mContext);
//            textView.setGravity(Gravity.CENTER);
//            textView.setText("...");
//            textView.setTextSize(14);
//            textView.setTextColor(mContext.getResources().getColor(R.color.c_444444));
//            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(UtilScreen.dip2px(mContext, 70), UtilScreen.dip2px(mContext, 70));
//            params.setMargins(UtilScreen.dip2px(mContext, 10), 0, 0, 0);
//            textView.setLayoutParams(params);
//            mViewHolder.photo_layout.addView(textView);
//        } else if(pictures.size() == num){
//            if (widthScreen >= (width * num + UtilScreen.dip2px(mContext, 10) * (num - 1))) {
//                addGroupImage(pictures, num, type, recommid, patientid);
//            }else {
//                num = num - 1;
//                addGroupImage(pictures, num, type, recommid, patientid);
//                TextView textView = new TextView(mContext);
//                textView.setGravity(Gravity.CENTER);
//                textView.setText("...");
//                textView.setTextSize(14);
//                textView.setTextColor(mContext.getResources().getColor(R.color.c_444444));
//                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(UtilScreen.dip2px(mContext, 70), UtilScreen.dip2px(mContext, 70));
//                params.setMargins(UtilScreen.dip2px(mContext, 10), 0, 0, 0);
//                textView.setLayoutParams(params);
//                mViewHolder.photo_layout.addView(textView);
//            }
//        }else {
//            addGroupImage(pictures, pictures.size(), type, recommid, patientid);
//        }
        if (pictures.size() >= num) {
            if((width + UtilScreen.dip2px(mContext, 10)) * (num - 1) + width > widthScreen){
                num = num -1;
            }
            addGroupImage(pictures, num, type, recommid, patientid);
        } else {
            addGroupImage(pictures, pictures.size(), type, recommid, patientid);
        }
    }

    private String getTrimStr(String str, String values, String unit) {
        String s = "";
        s += TextUtils.isEmpty(values) ? "" : str + values + unit + ",";
        return s;
    }

    private String clearEnd(String str) {
        while (str.endsWith(",")) {
            str = UtilString.getStringWithoutLast(str, ",");
        }
        return str;
    }


    /**
     * 医生填写
     *
     * @param type
     * @param drRecordVOBean
     */
    private void showDoctorInfo(final String type, final DrRecordVOBean drRecordVOBean) {
        showViews();
        final DrCaseVOBean bean = (DrCaseVOBean) drRecordVOBean.getMdicalRecordVO();
        if (bean == null) {
            return;
        }
        if("1".equals(bean.getInvalid())){
            mViewHolder.out_medical_card.setVisibility(View.VISIBLE);
        }else {
            mViewHolder.out_medical_card.setVisibility(View.GONE);
        }
        mViewHolder.doctor_write_layout.setVisibility(View.VISIBLE);
        String complaint = bean.getMainComplaint();
        String presentDisease = bean.getPresentDisease();
        if (!TextUtils.isEmpty(complaint) || !TextUtils.isEmpty(presentDisease)) {
            if (!TextUtils.isEmpty(complaint) && !TextUtils.isEmpty(presentDisease)) {
                complaint = complaint + ",";
            }
            if(TextUtils.isEmpty(complaint)){
                complaint = "";
            }
            if(TextUtils.isEmpty(presentDisease)){
                presentDisease = "";
            }
            mViewHolder.main_complaint_layout.setVisibility(View.VISIBLE);
            mViewHolder.main_complaint.setText(complaint + presentDisease);
        } else {
            mViewHolder.main_complaint_layout.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(bean.getPastHistory())) {
            mViewHolder.main_past_layout.setVisibility(View.VISIBLE);
            mViewHolder.main_past.setText(bean.getPastHistory());
        } else {
            mViewHolder.main_past_layout.setVisibility(View.GONE);
        }
        String temp = bean.getTemperature();
        String weight = bean.getWeight();
        String heartStr = bean.getHeartRete();
        String syst = bean.getSystolic();
        String dias = bean.getDiastole();
        String more = bean.getMoreExamin();

        if (!TextUtils.isEmpty(temp) || !TextUtils.isEmpty(weight) || !TextUtils.isEmpty(heartStr) || !TextUtils.isEmpty(syst) || !TextUtils.isEmpty(dias) || !TextUtils.isEmpty(more)) {
            mViewHolder.physical_examination_layout.setVisibility(View.VISIBLE);
            if(!TextUtils.isEmpty(temp)){
                temp = "体温：" + temp + "度";
                if (!TextUtils.isEmpty(weight) || !TextUtils.isEmpty(heartStr) || !TextUtils.isEmpty(syst) || !TextUtils.isEmpty(dias) || !TextUtils.isEmpty(more)) {
                    temp = temp + ",";
                }
            }else {
                temp = "";
            }
            if(!TextUtils.isEmpty(weight)){
                weight = "体重：" + weight +"kg";
                if  (!TextUtils.isEmpty(heartStr) || !TextUtils.isEmpty(syst) || !TextUtils.isEmpty(dias) || !TextUtils.isEmpty(more)) {
                    weight = weight + ",";
                }
            }else {
                weight ="";
            }
            if (!TextUtils.isEmpty(heartStr)){
                heartStr = "心率：" + heartStr + "bpm";
                if (!TextUtils.isEmpty(syst) || !TextUtils.isEmpty(dias) || !TextUtils.isEmpty(more)) {
                    heartStr = heartStr + ",";
                }
            }else {
                heartStr = "";
            }
            if (!TextUtils.isEmpty(syst)){
                syst = "收缩压" + syst + "mmhg";
                if (!TextUtils.isEmpty(dias) || !TextUtils.isEmpty(more)) {
                    syst = syst + ",";
                }
            }else {
                syst = "";
            }
            if (!TextUtils.isEmpty(dias)){
                dias = "舒张压" + dias + "mmhg";
                if (!TextUtils.isEmpty(more)) {
                    dias = dias + ",";
                }
            }else {
                dias = "";
            }
            if (!TextUtils.isEmpty(more)) {
                more = "更多检查结果"+ more;
            }else {
                more = "";
            }
            mViewHolder.physical_examination.setText(temp + weight + heartStr + syst + dias + more);
        } else {
            mViewHolder.physical_examination_layout.setVisibility(View.GONE);
        }
        String alt = bean.getAlt();
        String ast = bean.getAst();
        String hbv = bean.getHbvDna();
        if (!TextUtils.isEmpty(alt) || !TextUtils.isEmpty(ast) || !TextUtils.isEmpty(hbv)) {
            mViewHolder.other_inspections_layout.setVisibility(View.VISIBLE);
            if (!TextUtils.isEmpty(alt)){
                alt = "谷丙转氨酶" + alt + "IU/ml";
                if (!TextUtils.isEmpty(ast) || !TextUtils.isEmpty(hbv)) {
                    alt = alt + ",";
                }
            }else {
                alt = "";
            }
            if (!TextUtils.isEmpty(ast)){
                ast = "谷草转氨酶" + ast + "IU/ml";
                if (!TextUtils.isEmpty(hbv)) {
                    ast = ast + ",";
                }
            }else {
                ast = "";
            }
            if (!TextUtils.isEmpty(hbv)) {
                hbv = hbv + "IU/ml";
            }else {
                hbv = "";
            }
            mViewHolder.other_inspections.setText(alt + ast + hbv);
        } else {
            mViewHolder.other_inspections_layout.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(bean.getDiagnosis())) {
            mViewHolder.diagnose_layout.setVisibility(View.VISIBLE);
            mViewHolder.diagnose.setText(bean.getDiagnosis());
        } else {
            mViewHolder.diagnose_layout.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(bean.getDoctorOrder()) || "1".equals(bean.getRevisitFalg())) {
            mViewHolder.testamentary_summary_layout.setVisibility(View.VISIBLE);
            String str = "";
            if ("2".equals(bean.getRevisitFalg())) {
                str = bean.getDoctorOrder();
            } else {
                if("月".equals(bean.getRevisitDateUnit())){
                    str= getTrimStr("下次复诊时间：",bean.getRevisitNumber() +"个"+bean.getRevisitDateUnit(),"后")+
                            getTrimStr( "", bean.getDoctorOrder(),"");
                }else {
                    str= getTrimStr("下次复诊时间：",bean.getRevisitNumber() +bean.getRevisitDateUnit(),"后")+
                            getTrimStr( "", bean.getDoctorOrder(),"");
                }
            }
            mViewHolder.testamentary_summary.setText(clearEnd(str));
        } else {
            mViewHolder.testamentary_summary_layout.setVisibility(View.GONE);
        }
        if ("7".equals(drRecordVOBean.getCaseType())) {
            PrescriptionVOBean poBean = bean.getPrescriptionVO();
            if (poBean != null) {
                if (!TextUtils.isEmpty(poBean.getUrl())) {
                    final String patientId = bean.getPatientId();
                    final ArrayList<String> pictures = new ArrayList<>();
                    final String recommandId = poBean.getRecommendId();
                    pictures.add(poBean.getUrl());
                    XCApplication.base_imageloader.displayImage(poBean.getUrl(), mViewHolder.presc_image, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.bg_pic_default));
                    mViewHolder.presc_image.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            requestRecommendInfo(mContext,drRecordVOBean,recommandId,drRecordVOBean.getPatientId(),xc_chatModel,2);
                        }
                    });
                    mViewHolder.presc_layout.setVisibility(View.VISIBLE);
                } else {
                    mViewHolder.presc_layout.setVisibility(View.GONE);
                }
            } else {
                mViewHolder.presc_layout.setVisibility(View.GONE);
            }
        }
        if (bean.getImgList() != null && bean.getImgList().size() > 0) {
            ArrayList<String> pictures = new ArrayList<>();
            for (int i = 0; i < bean.getImgList().size(); i++) {
                String url = bean.getImgList().get(i).getImgUrl();
                pictures.add(url);
            }
            showMoreText(pictures,num,type,"",drRecordVOBean.getPatientId());
            mViewHolder.photo_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.photo_layout.setVisibility(View.GONE);
        }
    }


    /**
     * 患者新病例
     *
     * @param type
     * @param drRecordVOBean
     */
    private void showPatientNewMedicine(String type, DrRecordVOBean drRecordVOBean) {
       showViews();
        PatientCaseVOBean bean = (PatientCaseVOBean) drRecordVOBean.getMdicalRecordVO();
        if (bean == null) {
            return;
        }
        mViewHolder.patient_condition_show_layout.setVisibility(View.VISIBLE);
        String maritalStatus = bean.getMaritalStatus();
        String height = bean.getHeight();
        String weight = bean.getWeight();
        String medicationAllergy = bean.getMedicAllergys();
        String pastDisease = bean.getPastDiseases();
        String familyHistory = bean.getFamilyDiseases();
        String hereditaryDisease = bean.getHereditaryDiseases();
        String smokeHistory = bean.getSmoke();
        String drinkHstory = bean.getDrink();
        showPatientCondition(maritalStatus, height, weight, medicationAllergy, pastDisease, familyHistory, hereditaryDisease, smokeHistory, drinkHstory);
        if (!TextUtils.isEmpty(bean.getDescription())) {
            mViewHolder.disease_description_layout.setVisibility(View.VISIBLE);
            mViewHolder.disease_description.setText(bean.getDescription());
        } else {
            mViewHolder.disease_description_layout.setVisibility(View.GONE);
        }
        if (bean.getAcmResult() != null) {
            if (!TextUtils.isEmpty(bean.getAcmResult().getInquirySymptom())) {
                mViewHolder.self_diagnosis_results_layout.setVisibility(View.VISIBLE);
                mViewHolder.self_diagnosis_results.setText(bean.getAcmResult().getInquirySymptom());
            } else {
                mViewHolder.self_diagnosis_results_layout.setVisibility(View.GONE);
            }
        } else {
            mViewHolder.self_diagnosis_results_layout.setVisibility(View.GONE);
        }
        List<PrescriptionListBean> adviceList = bean.getAdviceList();
        List<PrescriptionListBean> checkList = bean.getCheckList();
        List<PrescriptionListBean> prescList = bean.getPrescriptionList();
        if ((adviceList != null && adviceList.size() > 0) || (checkList != null && checkList.size() > 0) || (prescList != null && prescList.size() > 0)) {
            ArrayList<String> pictures = new ArrayList<>();
            if (adviceList != null && adviceList.size() > 0) {
                for (int i = 0; i < adviceList.size(); i++) {
                    String url = adviceList.get(i).getImgUrl();
                    pictures.add(url);
                }
            }
            if (prescList != null && prescList.size() > 0) {
                for (int i = 0; i < prescList.size(); i++) {
                    String url = prescList.get(i).getImgUrl();
                    pictures.add(url);
                }
            }
            if (checkList != null && checkList.size() > 0) {
                for (int i = 0; i < checkList.size(); i++) {
                    String url = checkList.get(i).getImgUrl();
                    pictures.add(url);
                }
            }
            showMoreText(pictures,num,type,"",drRecordVOBean.getPatientId());
            mViewHolder.photo_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.photo_layout.setVisibility(View.GONE);
        }
    }

    /**
     * 患者老病历
     *
     * @param type
     * @param drRecordVOBean
     */
    private void showPatientOldMedicineInfo(String type, DrRecordVOBean drRecordVOBean) {
        showViews();
        PatientOldCaseVOBean oldCaseVOBean = (PatientOldCaseVOBean) drRecordVOBean.getMdicalRecordVO();
        if (oldCaseVOBean == null) {
            return;
        }
        if (!TextUtils.isEmpty(oldCaseVOBean.getDescript())) {
            mViewHolder.disease_description_layout.setVisibility(View.VISIBLE);
            mViewHolder.disease_description.setText(oldCaseVOBean.getDescript());
        } else {
            mViewHolder.disease_description_layout.setVisibility(View.GONE);
        }
        if (oldCaseVOBean.getImgList() != null && oldCaseVOBean.getImgList().size() > 0) {
            ArrayList<String> pictures = new ArrayList<>();
            for (int i = 0; i < oldCaseVOBean.getImgList().size(); i++) {
                String url = oldCaseVOBean.getImgList().get(i);
                pictures.add(url);
            }
            showMoreText(pictures,num,type,"",drRecordVOBean.getPatientId());
            mViewHolder.photo_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.photo_layout.setVisibility(View.GONE);
        }
    }

    /**
     * 诊疗记录
     *
     * @param type
     * @param drRecordVOBean
     */
    private void showRecord(String type, DrRecordVOBean drRecordVOBean) {
        showViews();
        RecordVOBean recordVOBean = (RecordVOBean) drRecordVOBean.getMdicalRecordVO();
        if (recordVOBean == null) {
            return;
        }
        DoctorDesVOBean bean = recordVOBean.getDoctorDesVO();
        if (bean != null) {
            mViewHolder.patient_condition_show_layout.setVisibility(View.VISIBLE);
            String maritalStatus = bean.getMaritalStatus();
            String height = bean.getHeight();
            String weight = bean.getWeight();
            String medicationAllergy = bean.getAllergy();
            String pastDisease = bean.getPastDisease();
            String familyHistory = bean.getFamilyHistory();
            String hereditaryDisease = bean.getHereditaryDisease();
            String smokeHistory = bean.getSmokeHistory();
            String drinkHstory = bean.getDrinkHistory();
            showPatientCondition(maritalStatus, height, weight, medicationAllergy, pastDisease, familyHistory, hereditaryDisease, smokeHistory, drinkHstory);
        }else {
            mViewHolder.patient_condition_show_layout.setVisibility(View.GONE);
        }
        if (recordVOBean.getImgList() != null && recordVOBean.getImgList().size() > 0) {
            ArrayList<String> pictures = new ArrayList<>();
            for (int i = 0; i < recordVOBean.getImgList().size(); i++) {
                String url = recordVOBean.getImgList().get(i);
                pictures.add(url);
            }
            showMoreText(pictures,num,type,"",drRecordVOBean.getPatientId());
            mViewHolder.photo_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.photo_layout.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(recordVOBean.getRecord())) {
            mViewHolder.record_content_layout.setVisibility(View.VISIBLE);
            mViewHolder.sx_id_record_content_show.setText(recordVOBean.getRecord());
        } else {
            mViewHolder.record_content_layout.setVisibility(View.GONE);
        }
    }

    /**
     * 旧的系统处方
     *
     * @param type
     * @param drRecordVOBean
     */
    private void showPrescWithInfo(final String type, DrRecordVOBean drRecordVOBean) {
        showViews();
        PrescriptionVOBean preBean = (PrescriptionVOBean) drRecordVOBean.getMdicalRecordVO();
        if (preBean == null) {
            return;
        }
        DoctorDesVOBean bean = preBean.getDoctorDesVO();
        if (bean != null) {
            mViewHolder.patient_condition_show_layout.setVisibility(View.VISIBLE);
            String maritalStatus = bean.getMaritalStatus();
            String height = bean.getHeight();
            String weight = bean.getWeight();
            String medicationAllergy = bean.getAllergy();
            String pastDisease = bean.getPastDisease();
            String familyHistory = bean.getFamilyHistory();
            String hereditaryDisease = bean.getHereditaryDisease();
            String smokeHistory = bean.getSmokeHistory();
            String drinkHstory = bean.getDrinkHistory();
            showPatientCondition(maritalStatus, height, weight, medicationAllergy, pastDisease, familyHistory, hereditaryDisease, smokeHistory, drinkHstory);
        }else {
            mViewHolder.patient_condition_show_layout.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(preBean.getUrl())) {
            final ArrayList<String> pictures = new ArrayList<>();
            pictures.add(preBean.getUrl());
            final String patientId = drRecordVOBean.getPatientId();
            final String recommandId = preBean.getRecommendId();
            XCApplication.base_imageloader.displayImage(preBean.getUrl(), mViewHolder.presc_image, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.bg_pic_default));
            mViewHolder.presc_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //(0:为医生添加，1：为患者上传 ,2：系统处方添加)
                    if (("2".equals(type) || "6".equals(type)) && !UtilString.isBlank(recommandId) && !UtilString.isBlank(patientId)) {
                        ToJumpHelp.toJumpRecommendDetailActivity(mContext, recommandId, xc_chatModel.getUserPatient(),"2");
                    } else {
                        ToJumpHelp.toJumpChatImageShowActivity(mContext, pictures, 0);
                    }
                }
            });
            mViewHolder.presc_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.presc_layout.setVisibility(View.GONE);
        }
    }


    /**
     * 展示患者基本病情
     */
    private void showPatientCondition(String maritalStatus, String height, String weight, String medicationAllergy, String pastDisease, String familyHistory, String hereditaryDisease, String smokeHistory, String drinkHstory) {
        if (!TextUtils.isEmpty(maritalStatus)) {
            if ("1".equals(maritalStatus)) {
                mViewHolder.xc_id_personbasicinfo_tv_marry.setText("已婚");
            } else if ("0".equals(maritalStatus)) {
                mViewHolder.xc_id_personbasicinfo_tv_marry.setText("未婚");
            }
            mViewHolder.xc_id_personbasicinfo_tv_marry_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.xc_id_personbasicinfo_tv_marry_layout.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(height)) {
            height = height.trim();
            mViewHolder.xc_id_personbasicinfo_tv_height.setText(height + "cm");
            mViewHolder.xc_id_personbasicinfo_tv_height_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.xc_id_personbasicinfo_tv_height_layout.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(weight)) {
            weight = weight.trim();
            mViewHolder.xc_id_personbasicinfo_tv_weight.setText(weight + "kg");
            mViewHolder.xc_id_personbasicinfo_tv_weight_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.xc_id_personbasicinfo_tv_weight_layout.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(medicationAllergy)) {
            medicationAllergy = medicationAllergy.trim();
            mViewHolder.xc_id_personbasicinfo_tv_allergy.setText(medicationAllergy);
            mViewHolder.xc_id_personbasicinfo_tv_allergy_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.xc_id_personbasicinfo_tv_allergy_layout.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(pastDisease)) {
            pastDisease = pastDisease.trim();
            mViewHolder.xc_id_personbasicinfo_tv_anamnesis.setText(pastDisease);
            mViewHolder.xc_id_personbasicinfo_tv_anamnesis_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.xc_id_personbasicinfo_tv_anamnesis_layout.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(familyHistory)) {
            familyHistory = familyHistory.trim();
            mViewHolder.xc_id_personbasicinfo_tv_family_history.setText(familyHistory);
            mViewHolder.xc_id_personbasicinfo_tv_family_history_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.xc_id_personbasicinfo_tv_family_history_layout.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(hereditaryDisease)) {
            hereditaryDisease = hereditaryDisease.trim();
            mViewHolder.xc_id_personbasicinfo_tv_genetic_history.setText(hereditaryDisease);
            mViewHolder.xc_id_personbasicinfo_tv_genetic_history_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.xc_id_personbasicinfo_tv_genetic_history_layout.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(smokeHistory)) {
            smokeHistory = smokeHistory.trim();
            mViewHolder.xc_id_personbasicinfo_tv_smoke.setText(smokeHistory);
            mViewHolder.xc_id_personbasicinfo_tv_smoke_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.xc_id_personbasicinfo_tv_smoke_layout.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(drinkHstory)) {
            drinkHstory = drinkHstory.trim();
            mViewHolder.xc_id_personbasicinfo_tv_drink.setText(drinkHstory);
            mViewHolder.xc_id_personbasicinfo_tv_drink_layout.setVisibility(View.VISIBLE);
        } else {
            mViewHolder.xc_id_personbasicinfo_tv_drink_layout.setVisibility(View.GONE);
        }
    }

    public static class ViewHolder {
        /**
         * 年月
         */
        TextView sx_id_year_month_show;
        /**
         * 时间
         */
        TextView sx_id_time_show;
        /**
         * 就诊医院
         */
        TextView sx_id_hospital_show;
        /**
         * 就诊科室
         */
        TextView sx_id_department_show;
        /**
         * 诊疗内容
         */
        TextView sx_id_record_content_show;
        /**
         * 诊疗医生
         */
        TextView sx_id_doctor_show;
        /**
         * 底部
         */
        View v_bottom;
        /**
         * 分割线
         */
//        View bottom_line;
        TextView image;
        TextView sx_id_patient_push_show;
        LinearLayout date_layout;
        /**
         * 诊疗记录布局
         */
        private LinearLayout record_content_layout;
        /**
         * 患者个人资料布局
         */
        private LinearLayout info_layout;
        private TextView name;
        private TextView age;
        private TextView sex;
        /**
         * 基本病情布局
         */
        private LinearLayout patient_condition_show_layout;
        /**
         * 婚姻布局
         */
        private LinearLayout xc_id_personbasicinfo_tv_marry_layout;
        /**
         * 身高布局
         */
        private LinearLayout xc_id_personbasicinfo_tv_height_layout;
        /**
         * 体重布局
         */
        private LinearLayout xc_id_personbasicinfo_tv_weight_layout;
        /**
         * 过敏史布局
         */
        private LinearLayout xc_id_personbasicinfo_tv_allergy_layout;
        /**
         * 疾病历史布局
         */
        private LinearLayout xc_id_personbasicinfo_tv_anamnesis_layout;
        /**
         * 家庭病史布局
         */
        private LinearLayout xc_id_personbasicinfo_tv_family_history_layout;
        /**
         * 遗传病史布局
         */
        private LinearLayout xc_id_personbasicinfo_tv_genetic_history_layout;
        /**
         * 抽烟布局
         */
        private LinearLayout xc_id_personbasicinfo_tv_smoke_layout;
        /**
         * 是否饮酒布局
         */
        private LinearLayout xc_id_personbasicinfo_tv_drink_layout;
        /**
         * 婚姻状态
         */
        private TextView xc_id_personbasicinfo_tv_marry;
        /**
         * 身高
         */
        private TextView xc_id_personbasicinfo_tv_height;
        /**
         * 体重
         */
        private TextView xc_id_personbasicinfo_tv_weight;
        /**
         * 过敏史
         */
        private TextView xc_id_personbasicinfo_tv_allergy;
        /**
         * 疾病历史
         */
        private TextView xc_id_personbasicinfo_tv_anamnesis;
        /**
         * 家庭病史
         */
        private TextView xc_id_personbasicinfo_tv_family_history;
        /**
         * 遗传病史
         */
        private TextView xc_id_personbasicinfo_tv_genetic_history;
        /**
         * 抽烟
         */
        private TextView xc_id_personbasicinfo_tv_smoke;
        /**
         * 是否饮酒
         */
        private TextView xc_id_personbasicinfo_tv_drink;

        /**
         * 医生填写布局
         */
        private LinearLayout doctor_write_layout;

        /**
         * 主诉布局
         */
        private LinearLayout main_complaint_layout;
        /**
         * 既往史布局
         */
        private LinearLayout main_past_layout;
        /**
         * 体检检查布局
         */
        private LinearLayout physical_examination_layout;
        /**
         * 其它检查布局
         */
        private LinearLayout other_inspections_layout;
        /**
         * 诊断布局
         */
        private LinearLayout diagnose_layout;
        /**
         * 医嘱小结布局
         */
        private LinearLayout testamentary_summary_layout;
        /**
         * 病情描述布局
         */
        private LinearLayout disease_description_layout;
        /**
         * 自诊结果布局
         */
        private LinearLayout self_diagnosis_results_layout;

        /**
         * 主诉
         */
        private TextView main_complaint;
        /**
         * 既往史
         */
        private TextView main_past;
        /**
         * 体检检查
         */
        private TextView physical_examination;
        /**
         * 其它检查
         */
        private TextView other_inspections;
        /**
         * 诊断
         */
        private TextView diagnose;
        /**
         * 医嘱小结
         */
        private TextView testamentary_summary;
        /**
         * 病情描述
         */
        private TextView disease_description;
        /**
         * 自诊结果
         */
        private TextView self_diagnosis_results;
        /**
         * 展示图片布局
         */
        private LinearLayout photo_layout;
        /**
         * 就诊医院布局
         */
        private LinearLayout hospital_layout;
        /**
         *  处方笺布局
         */
        private LinearLayout presc_layout;
        /**
         *  处方笺图片
         */
        private ImageView presc_image;
        /**
         * 作废病历标识
         */
        private TextView out_medical_card;
    }

    /** 查询处方详情 */
    public static void requestRecommendInfo(Context context, final DrRecordVOBean drRecordVOBean, String recommendId, String patientId, final XC_ChatModel xc_chatModel, final int type) {
        RequestParams params = new RequestParams();
        params.put("recommendId", recommendId);
        params.put("patientId", patientId);
        params.put("doctorId", UtilSP.getUserId());
        params.put("showExpire", xc_chatModel.isShowExpire());//是否显示到期提示
        XCHttpAsyn.postAsyn(context, AppConfig.getTuijianUrl(AppConfig.prescriptionDetail), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean != null) {
                        RecommendInfo recommendInfo = new RecommendInfo();
                        Parser2RecommendInfo parser2RecommendInfo = new Parser2RecommendInfo(recommendInfo);
                        parser2RecommendInfo.parseJson(result_bean);
                        ToJumpHelp.toJumpCaseRecipeDetailActivity(context,drRecordVOBean,
                                recommendInfo,type,xc_chatModel.getUserPatient(),"2");
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(context,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    public interface OnUIRefreshListener {
        void recordRefresh(View image, int pos);
    }

    private OnUIRefreshListener onUIRefreshListener;

    public void setOnUIRefreshListener(OnUIRefreshListener onUIRefreshListener) {
        this.onUIRefreshListener = onUIRefreshListener;
    }
}
