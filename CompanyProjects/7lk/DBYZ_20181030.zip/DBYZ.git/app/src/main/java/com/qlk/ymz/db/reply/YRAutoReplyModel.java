package com.qlk.ymz.db.reply;

import java.io.Serializable;

/**
 * 自动回复内容model
 *
 * @author 崔毅然
 * @version 1.5.0
 */
public class YRAutoReplyModel implements Serializable {

    /** id */
    String id;
    /** 回复内容 */
    String content;
//    /** 是否选中的回复内容 */
//    String isSelected = "false";
//    /** 医生id */
//    String doctorId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

//    public String getIsSelected() {
//        return isSelected;
//    }
//
//    public void setIsSelected(String isSelected) {
//        this.isSelected = isSelected;
//    }
//
//    public String getDoctorId() {
//        return doctorId;
//    }
//
//    public void setDoctorId(String doctorId) {
//        this.doctorId = doctorId;
//    }
}
