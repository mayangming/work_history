package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.model.AuthDataInfo;
import com.qlk.ymz.model.YY_DoctorlInfoBean;
import com.qlk.ymz.parse.Parse2AuthData;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

/**
 * SX_PersonalDataMoreActivity
 * 个人信息 更多页面
 * @author songxin on 2016/2/26.
 * @version 2.2.0
 */
public class SX_PersonalDataMoreActivity extends XCBaseActivity {
    /** title左边按钮*/
    private ImageView sx_id_title_left;
    /** title中间文字*/
    private TextView sx_id_title_center;
    /** 出诊时间*/
    private RelativeLayout yy_id_out_call;
    /** 擅长*/
    private RelativeLayout sx_id_be_good_at_rl;
    /** 擅长显示*/
    private TextView sx_id_be_good_at_show;
    /** 个人简介*/
    private RelativeLayout sx_id_personal_profile_rl;
    /** 个人简介显示*/
    private TextView sx_id_personal_profile_show;

    private YY_DoctorlInfoBean.DataEntity mDoctorlInfoBean;
    /**title布局*/
    private RelativeLayout pf_title_rl;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// 设置布局
		setContentView(R.layout.sx_l_activity_personal_data_more);
		super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(SX_PersonalDataMoreActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-25,about：saveInfo,end

        mDoctorlInfoBean = (YY_DoctorlInfoBean.DataEntity)getIntent().getSerializableExtra("DoctorlInfoBean");
        if(null == mDoctorlInfoBean){
            mDoctorlInfoBean = new YY_DoctorlInfoBean.DataEntity();
        }
        sx_id_be_good_at_show.setText(mDoctorlInfoBean.getExpertise());
        sx_id_personal_profile_show.setText(mDoctorlInfoBean.getIntroduction());
        sx_id_title_center.setText("更多资料");

	}

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_PersonalDataMoreActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

	// 无网络时,点击屏幕后回调的方法
	@Override
	public void onNetRefresh() {
	}

	// 初始化控件
	@Override
	public void initWidgets() {
        sx_id_title_left = getViewById(R.id.sx_id_title_left);
        sx_id_title_center = getViewById(R.id.sx_id_title_center);
        yy_id_out_call = getViewById(R.id.yy_id_out_call);
        sx_id_be_good_at_rl = getViewById(R.id.sx_id_be_good_at_rl);
        sx_id_be_good_at_show = getViewById(R.id.sx_id_be_good_at_show);
        sx_id_personal_profile_rl = getViewById(R.id.sx_id_personal_profile_rl);
        sx_id_personal_profile_show = getViewById(R.id.sx_id_personal_profile_show);
        pf_title_rl = getViewById(R.id.pf_title_rl);
        pf_title_rl.setBackgroundColor(getResources().getColor(R.color.c_white_ffffff));
	}

	// 设置监听
	@Override
	public void listeners() {
        sx_id_title_left.setOnClickListener(this);
        yy_id_out_call.setOnClickListener(this);
        sx_id_be_good_at_rl.setOnClickListener(this);
        sx_id_personal_profile_rl.setOnClickListener(this);
	}

    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        switch (v.getId()){
            //返回按钮
            case R.id.sx_id_title_left:
                onBackPressed();
                break;
            //出诊时间
            case R.id.yy_id_out_call:
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(SX_PersonalDataMoreActivity.class,"2","128","yy_id_out_call","",false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                intent.setClass(this, SX_OutOfTimeActivity.class);
                startActivity(intent);
                break;
            //擅长
            case R.id.sx_id_be_good_at_rl:
                intent.putExtra("BE_GOOD_AT", sx_id_be_good_at_show.getText().toString().trim());
                myStartActivityForResult(intent, SX_ChangePersonalDataActivity.class, 6, 6);
                break;
            //个人简介
            case R.id.sx_id_personal_profile_rl:
                intent.putExtra("PERSONAL_PROFILE", sx_id_personal_profile_show.getText().toString().trim());
                myStartActivityForResult(intent, SX_ChangePersonalDataActivity.class, 7, 7);
                break;
        }
    }

    /**
     * 跳转之后回调方法
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult ( int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 6: {
                if (null != data) {
                    String resultDate = data.getStringExtra("BE_GOOD_AT");
                    sx_id_be_good_at_show.setText(resultDate);
                    mDoctorlInfoBean.setExpertise(resultDate);
                }
                break;
            }
            case 7: {
                if (null != data) {
                    String resultDate = data.getStringExtra("PERSONAL_PROFILE");
                    sx_id_personal_profile_show.setText(resultDate);
                    mDoctorlInfoBean.setIntroduction(resultDate);
                }
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        printi("http", "=====onBackPressed======");
        Intent intent = new Intent();
        intent.putExtra("BE_GOOD_AT", mDoctorlInfoBean.getExpertise());
        intent.putExtra("PERSONAL_PROFILE", mDoctorlInfoBean.getIntroduction());
        setResult(6,intent);
        finish();
    }

}
