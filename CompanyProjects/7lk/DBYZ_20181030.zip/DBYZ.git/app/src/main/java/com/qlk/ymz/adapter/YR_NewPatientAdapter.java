package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.YR_NewPatientActivity;
import com.qlk.ymz.model.NewPatientModel;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.Utils;
import com.qlk.ymz.view.pop.LTNewPatientHint;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * Created on 2016/8/24.
 *
 * @author 崔毅然
 * @version V2.7.0
 */
public class YR_NewPatientAdapter extends XCBaseAdapter<NewPatientModel> {
    LayoutInflater layoutInflater;
    private boolean judgeShow=true;//进入页面第一次显示提示患者入口的弹窗

    public YR_NewPatientAdapter(Context context, List<NewPatientModel> list) {
        super(context, list);
        this.list = list;
        layoutInflater = LayoutInflater.from(context);
    }

    class ViewHolder {
        ImageView xc_id_patient_icon;
        TextView xc_id_patient_name;
        ImageView iv_patient_gender;
        TextView xc_id_patient_age;
        //add by litao 2016.11.18----------------  start
        ImageView iv_judge_entrance;//判断患者入口
        //add by litao 2016.11.18----------------   end
        View v_bottom_line;//底部分割线
        View v_newPatientStatus;
        TextView tv_createTime;
        TextView tv_come_action;
        TextView tv_online;//线上诊室
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final NewPatientModel bean = list.get(position);
        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.xc_l_adapter_patient_new_item, null);

            holder.xc_id_patient_icon = (ImageView) convertView.findViewById(R.id.xc_id_patient_icon);
            holder.xc_id_patient_name = (TextView) convertView.findViewById(R.id.tv_patientName);
            holder.iv_patient_gender = (ImageView) convertView.findViewById(R.id.iv_patient_gender);
            holder.xc_id_patient_age = (TextView) convertView.findViewById(R.id.xc_id_patient_age);
            holder.iv_judge_entrance = (ImageView) convertView.findViewById(R.id.iv_judge_entrance);
            holder.v_bottom_line = convertView.findViewById(R.id.v_bottom_line);
            holder.v_newPatientStatus = convertView.findViewById(R.id.v_newPatientStatus);
            holder.tv_createTime = (TextView) convertView.findViewById(R.id.tv_createTime);
            holder.tv_come_action = (TextView) convertView.findViewById(R.id.tv_come_action);
            holder.tv_online = convertView.findViewById(R.id.tv_online);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        // 患者添加的时间
        holder.tv_createTime.setText(UtilDate.convertTimeToFormat(UtilString.toLong(bean.getUserPatient().getCreateTime())));
        // 获取和设置控件的显示值
        holder.xc_id_patient_age.setText(bean.getUserPatient().getPatientAge());
        holder.xc_id_patient_name.setText(Utils.getPatientDisplayName(bean.getUserPatient().getPatientMemoName(), bean.getUserPatient().getPatientName()));

        // 设置性别，如果性别未知则隐藏
        if (CommonConfig.GENDER_MALE.equals(bean.getUserPatient().getPatientGender())) {
            holder.iv_patient_gender.setBackgroundResource(R.mipmap.icon_patient_man);
            holder.iv_patient_gender.setVisibility(View.VISIBLE);
        } else if (CommonConfig.GENDER_FEMALE.equals(bean.getUserPatient().getPatientGender())) {
            holder.iv_patient_gender.setBackgroundResource(R.mipmap.icon_patient_women);
            holder.iv_patient_gender.setVisibility(View.VISIBLE);
        } else {
            holder.iv_patient_gender.setVisibility(View.GONE);
        }
        if (bean.getUserPatient().isNewPatient() && isSHowRedNode(UtilString.toLong(bean.getUserPatient().getCreateTime()))){
            holder.v_newPatientStatus.setVisibility(View.VISIBLE);
        }else{
            holder.v_newPatientStatus.setVisibility(View.GONE);
            if (!isSHowRedNode(UtilString.toLong(bean.getUserPatient().getCreateTime())) && context instanceof YR_NewPatientActivity){
                ((YR_NewPatientActivity) context).reset(bean.getUserPatient().getPatientId());
            }
        }
        // 设置患者头像
        String patientIcon = bean.getUserPatient().getPatientImgHead();
        if (!TextUtils.isEmpty(patientIcon) && URLUtil.isValidUrl(patientIcon)) {
            XCApplication.displayImage(patientIcon, holder.xc_id_patient_icon);
        }
        // 设置底部分割线，如果是当前字母最后一个则隐藏
        if (list.size() - 1 == position) {
            holder.v_bottom_line.setVisibility(View.INVISIBLE);
        } else {
            holder.v_bottom_line.setVisibility(View.VISIBLE);
        }

//        add by litao 2016.11.19   xd update 2018.9.14
//       1:APP扫码进入2:互联网医院入口3：推荐活动关注4：线上诊室
        holder.iv_judge_entrance.setVisibility(View.GONE);
        holder.tv_online.setVisibility(View.GONE);
        holder.tv_come_action.setVisibility(View.GONE);
        switch (bean.getUserPatient().getSource()){
            case "2":
                //第一次显示弹框提示
                holder.iv_judge_entrance.setVisibility(View.VISIBLE);
                if (judgeShow) {
                    LTNewPatientHint.showHandlerPopup(holder.iv_judge_entrance);
                    judgeShow = false;
                }
                holder.iv_judge_entrance.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        LTNewPatientHint.showTipPopupWindow(holder.iv_judge_entrance);
                    }
                });
                break;
            case "3":
                holder.tv_come_action.setVisibility(View.VISIBLE);
                holder.tv_come_action.setText(TextUtils.isEmpty(bean.getSourceMsg())? "来自于推荐活动": bean.getSourceMsg());
                break;
            case "4":
                holder.tv_online.setVisibility(View.VISIBLE);
                break;
        }

        holder.tv_come_action.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(bean.getSourceTips())) {
                    Toast.makeText(context, bean.getSourceTips(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        return convertView;
    }


    /** update by cyr on 2017-6-23  如果本地向后调一个月以上，患者显示时间大于一个月，隐藏小红点  */
    private boolean isSHowRedNode(long timeStamp) {
        long curTime = System.currentTimeMillis();
        long time = (curTime - timeStamp)/1000;
        if (time >= 3600 * 24 * 30) {
            return false;
        }
        return true;
    }

}
