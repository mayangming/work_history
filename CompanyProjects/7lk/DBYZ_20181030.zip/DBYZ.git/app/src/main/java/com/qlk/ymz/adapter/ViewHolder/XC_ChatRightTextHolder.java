package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.view.EllipsizingTextView;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

/**
 * 聊天详情  医生 纯文本消息
 */
public class XC_ChatRightTextHolder extends XC_ChatRightBaseHolder {

    public TextView xc_id_adapter_right_content_text;

    public XC_ChatRightTextHolder(View convertView) {
        super(convertView);
        xc_id_adapter_right_content_text = (TextView) convertView.findViewById(R.id.xc_id_adapter_right_content_text);
        xc_id_adapter_right_head = (XCRoundedImageView) convertView.findViewById(R.id.xc_id_adapter_right_head);

    }
}