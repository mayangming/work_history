package com.qlk.ymz.db.im.chatmodel;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;

/**
 * description: 聊天信息中的图文咨询
 * autour: YM
 * date: 2017/12/20
 * update: $date$
 * version: $version$
 */

public class ChatModelPaid  implements Serializable,Cloneable{
    private String paidDetail = "";//图文咨询内容明细
    private String paidPrice = "";//图文咨询付费价格
    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
    public String getPaidDetail() {
        return UtilString.f(paidDetail);
    }

    public void setPaidDetail(String paidDetail) {
        this.paidDetail = paidDetail;
    }

    public String getPaidPrice() {
        return UtilString.f(paidPrice);
    }

    public void setPaidPrice(String paidPrice) {
        this.paidPrice = paidPrice;
    }
}