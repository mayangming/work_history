package com.qlk.ymz.db.im;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.parse.Parse2ChatContent;
import com.qlk.ymz.parse.Parse2ChatExd;
import com.qlk.ymz.parse.Parse2ChatSession;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 咨询列表数据库操作类
 * @author 徐金山
 * @version 1.5.0
 */
public class JS_ChatListDB {
    // ==========常量数据==========
    /** 发送者标示（0：医生，1：患者） */
    private final String SENDER_IS_DOCTOR = "0";
    /** 发送者标示（0：医生，1：患者） */
    private final String SENDER_IS_PATIENT = "1";
    /** 公共通知 */
    private final String PUB_NOTICE = "2";
    /** 系统通知 */
    private final String ACCOUNT_STATE = "3";
    //add by tengfei 2016/09/07 添加首页入口 start
    /**
     * 客服发来消息
     */
    private final String SERVICE = "6";
//    private final String SERVICE_MY = "7";发给客服消息
    //add by tengfei 2016/09/07 添加首页入口 end
    /** 购药咨询信息 */
    private static final String BUY_MEDICINE_REQUIRE_MSG = "<font size=14 color=#444444>[购药咨询]</font>患者想购买处方药等待您的确认";

    // ==========上下文环境数据==========
    /** 上下文对象 */
    private Context context = null;
    /** 数据库处理对象 */
    private static JS_ChatListDB dbProcessObj = null;
    /** 数据库对象 */
    private SQLiteDatabase db = null;
    /** 数据库是否可操作的标识（true：可操作，false：不可操作，默认值：true） */
    private static boolean processKeyCanUseFlag = true;

    // ==========数据库表结构相关数据==========
    /** 数据库版本号 */
    private final int DB_VERSION = 13;

    // 咨询交流信息表
    /** 咨询列表信息表名 */
    private static final String TB_NAME_CHATLIST = "table_chatlist";
    /** 主键 */
    private static final String F_ID = "_id";
    //患者信息
    /** 患者id */
    private static final String F_PATIENT_ID = "patientId";
    /** 患者真实名称 */
    private static final String F_PATIENT_NAME = "patientName";
    /** 患者昵称名称 */
    private static final String F_PATIENT_NICK_NAME = "patientNickName";
    /** 患者备注名称 */
    private static final String F_PATIENT_MEMO_NAME = "patientMemoName";
    /** 患者头像 */
    private static final String F_PATIENT_IMG_HEAD = "patientImgHead";
    /** 患者性别（1：男，0：女） */
    private static final String F_PATIENT_GENDER = "patientGender";
    /** 字母 */
    private static final String F_PATIENT_LETTER = "patientLetter";
    /** 患者年龄（单位：岁） */
    private static final String F_PATIENT_AGE = "patientAge";
    /** 患者所在地区（格式为：省名 市名） */
    private static final String F_PATIENT_CITY_NAME = "patientCityName";
    /** 此患者是否为医生的特别关注患者（true：是；false：否；默认值：false） */
    private static final String F_IS_ATTENTION = "isAttention";
    /** 医生添加患者的时间点 */
    private static final String F_DOCTOR_ADD_PATIENT_TIME = "doctorAddPatientTime";

    //其他
    /** 医生id */
    private static final String F_DOCTOR_SELF_ID = "doctorSelfId";
    /** 医生名 */
    private static final String F_DOCTOR_SELF_NAME = "doctorSelfName";
    /** 医生头像 */
    private static final String F_DOCTOR_SELF_IMG_HEAD = "doctorSelfImgHead";
    /** 搜索推荐 */
    private static final String F_MESSAGE_TEXT_RECOMMAND = "messageTextRecommand";
    // 聊天记录
    /** 消息类型（1：文本，2：图片，4：音频，8：视频，16：文本+医药链接，32：文本+搜索，64：购药咨询[患者自主购药申请]） */
    private static final String F_MSG_TYPE = "msgType";
    /** 此记录被逻辑删除的标识（0:未被逻辑删除；1:已被逻辑删除） */
    private static final String F_DELETED_FLAG = "deletedflag";
    /** 发送时间（单位：毫秒） */
    private static final String F_MSG_TIME = "msgTime";
    /** 文本信息 */
    private static final String F_MESSAGE_TEXT = "messageText";
    /** 每条信息的唯一标识，本地 */
    private static final String F_MSG_UNIQUE = "msgUnique";
    /** 声音的本地缓存 */
    private static final String F_VOICE_LOCALURI = "voiceLocalUri";
    /** 声音的网络地址 */
    private static final String F_VOICE_HTTPURI = "voiceHttpUri";
    /** 视频的本地缓存 */
    private static final String F_MOVE_LOCALURI = "moveLocalUri";
    /** 视频的网络地址 */
    private static final String F_MOVE_HTTPURI = "moveHttpUri";
    /** 图片的本地缓存 */
    private static final String F_PHOTO_LOCALURI = "photoLocalUri";
    /** 图片的网络地址 */
    private static final String F_PHOTO_HTTPURI = "photoHttpUri";
    /** 发送者标识（0：医生，1：患者） */
    private static final String F_SENDER = "sender";
    /** 音频视频的时间（单位：毫秒） */
    private static final String F_MEDIA_DURATION = "mediaDuration";
    /** 音频视频的大小（单位：KB） */
    private static final String F_MEDIA_SIZE = "mediaSize";
    /** 是否发送成功的标识（0：失败，1：成功，2：正在发送） */
    private static final String F_IS_SEND_SUCCESS = "isSendSuccess";
    /** 声音信息的读取标示（0：未读，1：已读） */
    private static final String F_IS_READ = "isRead";
    /** 置顶排序时间（long型，精确到毫秒） */
    private static final String F_TOP_SORT_TIME = "topSortTime";
    /** 聊天会话ID (doctorID + patientID + systemTime (systemTime != beginTime))*/
    private static final String F_SESSION_ID = "sessionId";
    /** 会话开始时间（毫秒值） */
    private static final String F_SESSION_BEGIN_TIME = "sessionBeginTime";
    /** 会话结束时间（毫秒值） */
    private static final String F_SESSION_END_TIME = "sessionEndTime";
    /** 会话生命周期状态（0：进行中；1：已结束） */
    private static final String F_SESSION_LIFE_CYCLE = "sessionLifeCycle";
    /** 患者信息提醒是否被屏蔽标示（0:不屏蔽，1：屏蔽） */
    private static final String F_IS_SHIELD = "isShield";

    /** 未读信息数 */
    private static final String F_UN_READ_MESSAGE_NUM = "unReadMessageNum";
    /** 服务端信息ID（信息在服务器端的编号） */
    private static final String F_MSG_SERVER_ID = "msgServerId";
    /** 会话的付费模式（0：免费；1：付费） */
    private static final String F_PAY_MODE = "payMode";
    /** 会话的付费状态（0：未付费；1：已付费） */
    private static final String F_PAY_RESULT = "payResult";
    /** 公告被点击时的着陆页URL */
    private static final String F_LINK_URL = "LinkUrl";
    /** 公告二级分类的id */
    private static final String F_TOPIC = "topic";

    /**
     * 特别的消息类型的保存
     * <p>说明：因业务上对“购药咨询”类型消息的处理有个性化逻辑，为支持对“购药咨询”类型消息的个性化逻辑，
     * 特别建立此字段支持。消息类型参看“F_MSG_TYPE”字段。
     */
    private static final String F_MSG_TYPE_BUY_MEDICINE_REQUIRE = "msgTypeBuyMedicineRequire";
    /** 购药咨询id */
    private static final String F_BUY_MEDICINE_REQUIRE_ID = "BuyMedicineConsultingRequireId";
    /** 购药咨询信息 */
    private static final String F_BUY_MEDICINE_REQUIRE_MSG = "buyMedicineRequireMsg";


    //备用字段1 至 备用字段10
    //TODO update by cyr on 2017-3-29 start
    /** 患者付费图文咨询的价格 "0"表示医生未设置付费图文咨询  */
    private static final String F_BACK1 = "back1";
    // TODO update by cyr on 2017-3-29 end
    /** 2.7版本启用F_BACK2字段来放置IM消息中的content内容 */
    private static final String F_BACK2 = "back2";
    /** 2.7版本启用F_BACK3字段来放置控制关闭titleTip关闭的时间 */
    private static final String F_BACK3 = "back3";
    /** 2.7版本启用F_BACK4字段来放置consultPayType(会话是否付费(1-付费,0免费) */
    private static final String F_BACK4 = "back4";
    /** 2.8版本启用BACK5字段放置是否被撤销的字段（0:表示未撤销；1:表示已撤销） */
    private static final String F_BACK5 = "back5";
    /** 2.8版本启用BACK6字段放置是患者手机号 */
    private static final String F_BACK6 = "back6";
    private static final String F_BACK7 = "back7";
    /** 2.17版本启用F_BACK8字段放置拓展字段exd的内容 */
    private static final String F_BACK8 = "back8";
    /** 3.3版本启用F_BACK9字段放置session的json内容 */
    private static final String F_BACK9 = "back9";
    private static final String F_BACK10 = "back10";

    /**
     * 数据库助手类
     */
    private class DbHelper extends SQLiteOpenHelper {
        /**
         * 构造方法
         * @param context 上下文对象
         * @param dataBaseName 数据库名
         */
        private DbHelper(Context context, String dataBaseName) {
            super(context, dataBaseName, null, DB_VERSION);
        }

        /**
         * 初始化数据库
         * @param db 数据库对象
         */
        public void onCreate(SQLiteDatabase db) {
            // 创建“咨询列表信息表”
            String sql = "create table " + TB_NAME_CHATLIST +
                    "(" +
                    F_ID + " integer primary key AUTOINCREMENT," +
                    F_PATIENT_ID + " text, " +
                    F_DELETED_FLAG + " text, " +
                    F_PATIENT_NAME + " text, " +
                    F_PATIENT_IMG_HEAD + " text, " +
                    F_DOCTOR_SELF_ID + " text, " +
                    F_DOCTOR_SELF_NAME + " text, " +
                    F_DOCTOR_SELF_IMG_HEAD + " text, " +
                    F_MSG_TIME + " text, " +
                    F_MESSAGE_TEXT_RECOMMAND + " text, " +
                    F_MESSAGE_TEXT + " text, " +
                    F_MSG_TYPE + " text, " +
                    F_MSG_UNIQUE + " text, " +
                    F_VOICE_LOCALURI + " text, " +
                    F_VOICE_HTTPURI + " text, " +
                    F_MOVE_LOCALURI + " text, " +
                    F_MOVE_HTTPURI + " text, " +
                    F_PHOTO_LOCALURI + " text, " +
                    F_PHOTO_HTTPURI + " text, " +
                    F_SENDER + " text, " +
                    F_MEDIA_DURATION + " text, " +
                    F_MEDIA_SIZE + " text, " +
                    F_PATIENT_GENDER + " text, " +
                    F_PATIENT_LETTER + " text, " +
                    F_PATIENT_AGE + " text, " +
                    F_UN_READ_MESSAGE_NUM + " text, " +
                    F_IS_SEND_SUCCESS + " text, " +
                    F_MSG_SERVER_ID + " text, " +
                    F_IS_READ + " text, " +
                    F_IS_SHIELD + " text, " +
                    F_TOP_SORT_TIME + " text," +
                    F_PATIENT_NICK_NAME + " text, " +
                    F_PATIENT_MEMO_NAME + " text, " +
                    F_SESSION_ID + " text, " +
                    F_SESSION_LIFE_CYCLE + " text, " +
                    F_PAY_MODE + " text, " +
                    F_PAY_RESULT + " text, " +
                    F_SESSION_BEGIN_TIME + " text, " +
                    F_SESSION_END_TIME + " text, " +
                    F_LINK_URL + " text," +
                    F_TOPIC + " text," +
                    F_MSG_TYPE_BUY_MEDICINE_REQUIRE + " text," +
                    F_BUY_MEDICINE_REQUIRE_ID + " text," +
                    F_BUY_MEDICINE_REQUIRE_MSG + " text," +
                    F_BACK1 + " text, " +
                    F_BACK2 + " text, " +
                    F_BACK3 + " text, " +
                    F_BACK4 + " text, " +
                    F_BACK5 + " text, " +
                    F_BACK6 + " text, " +
                    F_BACK7 + " text, " +
                    F_BACK8 + " text, " +
                    F_BACK9 + " text, " +
                    F_BACK10 + " text, " +
                    F_PATIENT_CITY_NAME + " text, " +
                    F_IS_ATTENTION + " text, " +
                    F_DOCTOR_ADD_PATIENT_TIME + " text" +
                    ")";
            db.execSQL(sql);
        }

        /** add by cyr on 2016/7/6  数据库临时表名，用于V2.5数据库升级 */
        private static final String NEW_TB_NAME_CHATLIST = "new_table_chatlist";


        /**
         * 更新数据库
         * @param db 数据库对象
         * @param oldVersion 数据库的旧版本号
         * @param newVersion 数据库的新版本号
         *
         * update by cyr on 2016-9-23  兼容2.3之前的版本
         */
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            if (newVersion > oldVersion) {
                if (oldVersion <= 10) {
                    db.execSQL("drop table if exists " + TB_NAME_CHATLIST);
                    onCreate(db);
                } else {
                    db.execSQL("alter table " + TB_NAME_CHATLIST + " rename to " + NEW_TB_NAME_CHATLIST);
                    onCreate(db);
                    db.execSQL("insert into " + TB_NAME_CHATLIST + " select *,'','','' from " + NEW_TB_NAME_CHATLIST);
                    db.execSQL("drop table if exists " + NEW_TB_NAME_CHATLIST);
                }
            }
        }
    }

    /**
     * 将XC_ChatModel业务bean对象转换成JS_ChatListModel对象
     * @param obj 业务bean对象
     * @return 转化成的业务Bean
     */
    private JS_ChatListModel bean2JS_ChatListModel(XC_ChatModel obj) {
        JS_ChatListModel dataSetObj = new JS_ChatListModel();
        dataSetObj.getUserPatient().setPatientId(obj.getUserPatient().getPatientId()); // 患者ID
        dataSetObj.setDeletedflag(JS_ChatListModel.FLAG_VISIBLE); // 此记录被逻辑删除的标识（0:未被逻辑删除；1:已被逻辑删除；默认值：0）
        dataSetObj.getUserPatient().setPatientName(obj.getUserPatient().getPatientName()); // 患者名称
        dataSetObj.getUserPatient().setPatientImgHead(obj.getUserPatient().getPatientImgHead()); // 患者头像
        dataSetObj.getUserDoctor().setDoctorSelfId(obj.getUserDoctor().getDoctorSelfId()); // 医生ID
        dataSetObj.getUserDoctor().setDoctorSelfName(obj.getUserDoctor().getDoctorSelfName()); // 医生名称
        dataSetObj.getUserDoctor().setDoctorSelfImgHead(obj.getUserDoctor().getDoctorSelfImgHead()); // 医生头像
        dataSetObj.setMsgTime(obj.getMsgTime()); // 发送时间（单位：毫秒）
        dataSetObj.setMessageTextRecommand(obj.getMessageTextRecommand()); // 推荐用药
        dataSetObj.setMessageText(getMessageText(obj, obj.getMessageText())); // 文本信息（说明：当信息类型为“64：购药咨询”时，文本信息要进行特殊赋值）
        dataSetObj.setMsgType(obj.getMsgType()); // 消息类型（1：文本，2：图片，4：音频，8：视频，16：文本+医药链接，32：文本+搜索）
        dataSetObj.setMsgUnique(obj.getMsgUnique()); // 每条信息的唯一标示（格式：user_id + time）
        dataSetObj.setVoiceLocalUri(obj.getVoiceLocalUri()); // 声音的本地缓存
        dataSetObj.setVoiceHttpUri(obj.getVoiceHttpUri()); // 声音的网络地址
        dataSetObj.setMoveLocalUri(obj.getMoveLocalUri()); // 视频的本地缓存
        dataSetObj.setMoveHttpUri(obj.getMoveHttpUri()); // 视频的网络地址
        dataSetObj.getChatModelPhoto().setPhotoLocalUri(obj.getChatModelPhoto().getPhotoLocalUri()); // 图片的本地缓存
        dataSetObj.getChatModelPhoto().setPhotoHttpUri(obj.getChatModelPhoto().getPhotoHttpUri()); // 图片的网络地址
        dataSetObj.setSender(obj.getSender()); // 发送者标识（0：医生，1：患者）
        dataSetObj.setMediaDuration(obj.getMediaDuration()); // 音频视频的时间（单位：毫秒）
        dataSetObj.setMediaSize(obj.getMediaSize()); // 音频视频的大小（单位：KB）
        dataSetObj.getUserPatient().setPatientGender(obj.getUserPatient().getPatientGender()); // 患者性别（1：男，0：女）
        dataSetObj.getUserPatient().setPatientLetter(obj.getUserPatient().getPatientLetter()); // 分组字母
        dataSetObj.getUserPatient().setPatientAge(obj.getUserPatient().getPatientAge()); // 患者年龄（单位：岁）
        dataSetObj.getUserPatient().setCityName(obj.getUserPatient().getCityName()); // 患者所在地区（格式为：省名 市名）
        dataSetObj.getUserPatient().setIsAttention(obj.getUserPatient().getIsAttention()); // 此患者是否为医生的特别关注患者（true：是；false：否；默认值：false）
        dataSetObj.getUserPatient().setCreateTime(obj.getUserPatient().getCreateTime()); // 医生添加患者的时间点
        dataSetObj.setUnReadMessageNum(obj.getUnReadMessageNum()); // 未读信息数
        dataSetObj.setIsSendSuccess(obj.getIsSendSuccess()); // 发送状态标示（0：发送失败，1：发送成功，2：正在发送）
        dataSetObj.setMsgServerId(obj.getMsgServerId()); // 服务端信息ID
        dataSetObj.setIsRead(obj.getIsRead()); // 声音信息的读取标示（0：未读，1：已读）
        dataSetObj.getUserPatient().setIsShield(obj.getUserPatient().getIsShield()); // 患者被屏蔽标示（0：不屏蔽，1：屏蔽）
        dataSetObj.getUserPatient().setPatientNickName(obj.getUserPatient().getPatientNickName()); // 患者昵称名称
        dataSetObj.getUserPatient().setPatientMemoName(obj.getUserPatient().getPatientMemoName()); // 患者备注名称
        dataSetObj.setSessionId(obj.getSessionId()); // 会话ID
        dataSetObj.setSessionLifeCycle(obj.getSessionLifeCycle()); // 会话生命周期状态（0：进行中；1：已结束）
        dataSetObj.setPayMode(obj.getPayMode()); // 会话的付费模式（0：免费；1：付费）
        dataSetObj.setPayResult(obj.getPayResult()); // 会话的付费状态（0：未付费；1：已付费）
        dataSetObj.setSessionBeginTime(obj.getSessionBeginTime()); // 会话开始时间（毫秒值）
        dataSetObj.setSessionEndTime(obj.getSessionEndTime()); // 会话结束时间（毫秒值）
        dataSetObj.setLinkUrl(obj.getLinkUrl()); // 云诊公告被点击时的着陆页URL
        dataSetObj.setTopSortTime("0"); // 置顶排序时间（long型，精确到毫秒）
        dataSetObj.setTopic(obj.getTopic()); // 公告二级分类id
        dataSetObj.setMsgTypeBuyMedicineRequire(getMsgTypeBuyMedicineRequire(obj.getMsgType()));  // 特别的消息类型（64：购药咨询）
        dataSetObj.setRequireId(obj.getRequireId()); // 购药咨询id
        dataSetObj.setBuyMedicineRequireMsg(getMessageText(obj, "")); // 购药咨询信息
        dataSetObj.getUserPatient().setPayAmount(obj.getUserPatient().getPayAmount());//患者图文咨询的付费价格
        dataSetObj.setContent(obj.getContent());
        dataSetObj.setTitleTipCloseTime(obj.getTitleTipCloseTime());
        dataSetObj.getUserPatient().setConsultPayType(obj.getUserPatient().getConsultPayType());
        dataSetObj.setCancelFlag(obj.getCancelFlag());
        dataSetObj.getUserPatient().setPatientPhone(obj.getUserPatient().getPatientPhone());
        dataSetObj.setExd(obj.getExd());
        dataSetObj.setSessionJson(obj.getSessionJson());
        return dataSetObj;
    }

    /**
     * 当信息类型为“64：购药咨询”时，文本信息返回预设值BUY_MEDICINE_REQUIRE_MSG。否则返回默认值。
     * @param obj 聊天咨询信息对象
     * @param defaultValue 默认值
     * @return 文本信息
     */
    private String getMessageText(XC_ChatModel obj, String defaultValue) {
        String str;

        String msgType = obj.getMsgType();
        if(String.valueOf(XC_ChatModel.PATIENT_BUY).equals(msgType)) {
            str = BUY_MEDICINE_REQUIRE_MSG;
        }else {
            str = defaultValue;
        }

        return str;
    }

    /**
     * 获取“购药咨询类型”的信息，当信息类型不是“购药咨询”时，返回“”
     * @param msgType 信息类型
     * @return 返回“购药咨询类型”的信息
     */
    private String getMsgTypeBuyMedicineRequire(String msgType) {
        try {
            int int_msgType = Integer.valueOf(msgType);
            if(XC_ChatModel.PATIENT_BUY == int_msgType) {
                // 什么都不做
            }else {
                msgType = "";
            }
        }catch(Exception e) {
            e.printStackTrace();
            msgType = "";
        }

        return msgType;
    }

    /**
     * 将cursor转化成业务Bean
     * @param cursor 数据cursor
     * @return 由cursor转化成的业务Bean
     */
    private JS_ChatListModel cursor2JS_ChatListModel(Cursor cursor) {
        JS_ChatListModel dataSetObj = new JS_ChatListModel();

        dataSetObj.getUserPatient().setPatientId(cursor.getString(cursor.getColumnIndex(F_PATIENT_ID))); // 患者ID
        dataSetObj.setDeletedflag(cursor.getString(cursor.getColumnIndex(F_DELETED_FLAG))); // 此记录被逻辑删除的标识（0:未被逻辑删除；1:已被逻辑删除）
        dataSetObj.getUserPatient().setPatientName(cursor.getString(cursor.getColumnIndex(F_PATIENT_NAME))); // 患者名称
        dataSetObj.getUserPatient().setPatientImgHead(cursor.getString(cursor.getColumnIndex(F_PATIENT_IMG_HEAD))); // 患者头像
        dataSetObj.getUserDoctor().setDoctorSelfId(cursor.getString(cursor.getColumnIndex(F_DOCTOR_SELF_ID))); // 医生ID
        dataSetObj.getUserDoctor().setDoctorSelfName(cursor.getString(cursor.getColumnIndex(F_DOCTOR_SELF_NAME))); // 医生名称
        dataSetObj.getUserDoctor().setDoctorSelfImgHead(cursor.getString(cursor.getColumnIndex(F_DOCTOR_SELF_IMG_HEAD))); // 医生头像
        dataSetObj.setMsgTime(cursor.getString(cursor.getColumnIndex(F_MSG_TIME))); // 发送时间（单位：毫秒）
        dataSetObj.setMessageTextRecommand(cursor.getString(cursor.getColumnIndex(F_MESSAGE_TEXT_RECOMMAND))); // 推荐用药
        dataSetObj.setMessageText(cursor.getString(cursor.getColumnIndex(F_MESSAGE_TEXT))); // 文本信息
        dataSetObj.setMsgType(cursor.getString(cursor.getColumnIndex(F_MSG_TYPE))); // 消息类型（1：文本，2：图片，4：音频，8：视频，16：文本+医药链接，32：文本+搜索）
        dataSetObj.setMsgUnique(cursor.getString(cursor.getColumnIndex(F_MSG_UNIQUE))); // 每条信息的唯一标示（格式：user_id + time）
        dataSetObj.setVoiceLocalUri(cursor.getString(cursor.getColumnIndex(F_VOICE_LOCALURI))); // 声音的本地缓存
        dataSetObj.setVoiceHttpUri(cursor.getString(cursor.getColumnIndex(F_VOICE_HTTPURI))); // 声音的网络地址
        dataSetObj.setMoveLocalUri(cursor.getString(cursor.getColumnIndex(F_MOVE_LOCALURI))); // 视频的本地缓存
        dataSetObj.setMoveHttpUri(cursor.getString(cursor.getColumnIndex(F_MOVE_HTTPURI))); // 视频的网络地址
//        dataSetObj.setPhotoLocalUri(cursor.getString(cursor.getColumnIndex(F_PHOTO_LOCALURI))); // 图片的本地缓存
//        dataSetObj.setPhotoHttpUri(cursor.getString(cursor.getColumnIndex(F_PHOTO_HTTPURI))); // 图片的网络地址
        dataSetObj.setSender(cursor.getString(cursor.getColumnIndex(F_SENDER))); // 发送者标识（0：医生，1：患者）
        dataSetObj.setMediaDuration(cursor.getString(cursor.getColumnIndex(F_MEDIA_DURATION))); // 音频视频的时间（单位：毫秒）
        dataSetObj.setMediaSize(cursor.getString(cursor.getColumnIndex(F_MEDIA_SIZE))); // 音频视频的大小（单位：KB）
        dataSetObj.getUserPatient().setPatientGender(cursor.getString(cursor.getColumnIndex(F_PATIENT_GENDER))); // 患者性别（1：男，0：女）
        dataSetObj.getUserPatient().setPatientLetter(cursor.getString(cursor.getColumnIndex(F_PATIENT_LETTER))); // 分组字母
        dataSetObj.getUserPatient().setPatientAge(cursor.getString(cursor.getColumnIndex(F_PATIENT_AGE))); // 患者年龄（单位：岁）
        dataSetObj.getUserPatient().setCityName(cursor.getString(cursor.getColumnIndex(F_PATIENT_CITY_NAME))); // 患者所在地区（格式为：省名 市名）
        dataSetObj.getUserPatient().setIsAttention(cursor.getString(cursor.getColumnIndex(F_IS_ATTENTION))); // 此患者是否为医生的特别关注患者（true：是；false：否；默认值：false）
        dataSetObj.getUserPatient().setCreateTime(cursor.getString(cursor.getColumnIndex(F_DOCTOR_ADD_PATIENT_TIME))); // 医生添加患者的时间点
        dataSetObj.setUnReadMessageNum(cursor.getString(cursor.getColumnIndex(F_UN_READ_MESSAGE_NUM))); // 未读信息数
        dataSetObj.setIsSendSuccess(cursor.getString(cursor.getColumnIndex(F_IS_SEND_SUCCESS))); // 发送状态标示（0：发送失败，1：发送成功，2：正在发送）
        dataSetObj.setMsgServerId(cursor.getString(cursor.getColumnIndex(F_MSG_SERVER_ID))); // 服务端信息ID
        dataSetObj.setIsRead(cursor.getString(cursor.getColumnIndex(F_IS_READ))); // 声音信息的读取标示（0：未读，1：已读）
        dataSetObj.getUserPatient().setIsShield(cursor.getString(cursor.getColumnIndex(F_IS_SHIELD))); // 患者被屏蔽标示（0：不屏蔽，1：屏蔽）
        dataSetObj.getUserPatient().setPatientNickName(cursor.getString(cursor.getColumnIndex(F_PATIENT_NICK_NAME))); // 患者昵称名称
        dataSetObj.getUserPatient().setPatientMemoName(cursor.getString(cursor.getColumnIndex(F_PATIENT_MEMO_NAME))); // 患者备注名称
        dataSetObj.setSessionId(cursor.getString(cursor.getColumnIndex(F_SESSION_ID))); // 聊天会话ID
        dataSetObj.setSessionLifeCycle(cursor.getString(cursor.getColumnIndex(F_SESSION_LIFE_CYCLE))); // 会话生命周期状态（0：进行中；1：已结束）
        dataSetObj.setPayMode(cursor.getString(cursor.getColumnIndex(F_PAY_MODE))); // 会话的付费模式（0：免费；1：付费）
        dataSetObj.setPayResult(cursor.getString(cursor.getColumnIndex(F_PAY_RESULT))); // 会话的付费状态（0：未付费；1：已付费）
        dataSetObj.setSessionBeginTime(cursor.getString(cursor.getColumnIndex(F_SESSION_BEGIN_TIME))); // 会话开始时间（毫秒值）
        dataSetObj.setSessionEndTime(cursor.getString(cursor.getColumnIndex(F_SESSION_END_TIME))); // 会话开始时间（毫秒值）
        dataSetObj.setLinkUrl(cursor.getString(cursor.getColumnIndex(F_LINK_URL))); // 云诊公告被点击时的着陆页URL
        dataSetObj.setTopic(cursor.getString(cursor.getColumnIndex(F_TOPIC))); // 公告二级分类的id
        dataSetObj.setTopSortTime(cursor.getString(cursor.getColumnIndex(F_TOP_SORT_TIME))); // 置顶排序时间（long型，精确到毫秒）
        dataSetObj.setMsgTypeBuyMedicineRequire(cursor.getString(cursor.getColumnIndex(F_MSG_TYPE_BUY_MEDICINE_REQUIRE))); // 特别的消息类型的保存
        dataSetObj.setRequireId(cursor.getString(cursor.getColumnIndex(F_BUY_MEDICINE_REQUIRE_ID))); // 购药咨询id
        dataSetObj.setBuyMedicineRequireMsg(cursor.getString(cursor.getColumnIndex(F_BUY_MEDICINE_REQUIRE_MSG))); // 购药咨询信息
        dataSetObj.getUserPatient().setPayAmount(cursor.getString(cursor.getColumnIndex(F_BACK1)));//图文咨询付费价格
        dataSetObj.setContent(cursor.getString(cursor.getColumnIndex(F_BACK2)));
        dataSetObj.setTitleTipCloseTime(cursor.getString(cursor.getColumnIndex(F_BACK3)));
        dataSetObj.getUserPatient().setConsultPayType(cursor.getString(cursor.getColumnIndex(F_BACK4)));
        dataSetObj.setCancelFlag(cursor.getString(cursor.getColumnIndex(F_BACK5)));
        dataSetObj.getUserPatient().setPatientPhone(cursor.getString(cursor.getColumnIndex(F_BACK6)));
        dataSetObj.setExd(cursor.getString(cursor.getColumnIndex(F_BACK8)));
        dataSetObj.setSessionJson(cursor.getString(cursor.getColumnIndex(F_BACK9)));
        Parse2ChatExd.parseExd(dataSetObj);
        Parse2ChatContent.parseContent(dataSetObj);
        Parse2ChatSession.parseSession(dataSetObj);
        return dataSetObj;
    }

    /**
     * 将JS_ChatListModel业务信息对象转换成ContentValues对象
     * @param chatListModel 业务信息对象
     * @return 转换后得到的ContentValues对象
     */
    private ContentValues JS_ChatListModel2ContentValues(JS_ChatListModel chatListModel) {
        ContentValues contentValuesObj = new ContentValues();

        contentValuesObj.put(F_PATIENT_ID, chatListModel.getUserPatient().getPatientId()); // 患者ID
        contentValuesObj.put(F_DELETED_FLAG, chatListModel.getDeletedflag()); // 此记录被逻辑删除的标识（0:未被逻辑删除；1:已被逻辑删除）
        contentValuesObj.put(F_PATIENT_NAME, chatListModel.getUserPatient().getPatientName()); // 患者名称
        contentValuesObj.put(F_PATIENT_IMG_HEAD, chatListModel.getUserPatient().getPatientImgHead()); // 患者头像
        contentValuesObj.put(F_DOCTOR_SELF_ID, chatListModel.getUserDoctor().getDoctorSelfId()); // 医生ID
        contentValuesObj.put(F_DOCTOR_SELF_NAME, chatListModel.getUserDoctor().getDoctorSelfName()); // 医生名称
        contentValuesObj.put(F_DOCTOR_SELF_IMG_HEAD, chatListModel.getUserDoctor().getDoctorSelfImgHead()); // 医生头像
        contentValuesObj.put(F_MSG_TIME, chatListModel.getMsgTime()); // 发送时间（单位：毫秒）
        contentValuesObj.put(F_MESSAGE_TEXT_RECOMMAND, chatListModel.getMessageTextRecommand()); // 推荐用药
        contentValuesObj.put(F_MESSAGE_TEXT, chatListModel.getMessageText()); // 文本信息
        contentValuesObj.put(F_MSG_TYPE, chatListModel.getMsgType()); // 消息类型（1：文本，2：图片，4：音频，8：视频，16：文本+医药链接，32：文本+搜索）
        contentValuesObj.put(F_MSG_UNIQUE, chatListModel.getMsgUnique()); // 每条信息的唯一标示（格式：user_id + time）
        contentValuesObj.put(F_VOICE_LOCALURI, chatListModel.getVoiceLocalUri()); // 声音的本地缓存
        contentValuesObj.put(F_VOICE_HTTPURI, chatListModel.getVoiceHttpUri()); // 声音的网络地址
        contentValuesObj.put(F_MOVE_LOCALURI, chatListModel.getMoveLocalUri()); // 视频的本地缓存
        contentValuesObj.put(F_MOVE_HTTPURI, chatListModel.getMoveHttpUri()); // 视频的网络地址
        contentValuesObj.put(F_PHOTO_LOCALURI, chatListModel.getChatModelPhoto().getPhotoLocalUri()); // 图片的本地缓存
        contentValuesObj.put(F_PHOTO_HTTPURI, chatListModel.getChatModelPhoto().getPhotoHttpUri()); // 图片的网络地址
        contentValuesObj.put(F_SENDER, chatListModel.getSender()); // 发送者标识（0：医生，1：患者）
        contentValuesObj.put(F_MEDIA_DURATION, chatListModel.getMediaDuration()); // 音频视频的时间（单位：毫秒）
        contentValuesObj.put(F_MEDIA_SIZE, chatListModel.getMediaSize()); // 音频视频的大小（单位：KB）
        contentValuesObj.put(F_PATIENT_GENDER, chatListModel.getUserPatient().getPatientGender()); // 患者性别（1：男，0：女）
        contentValuesObj.put(F_PATIENT_LETTER, chatListModel.getUserPatient().getPatientLetter()); // 分组字母
        contentValuesObj.put(F_PATIENT_AGE, chatListModel.getUserPatient().getPatientAge()); // 患者年龄（单位：岁）
        contentValuesObj.put(F_UN_READ_MESSAGE_NUM, chatListModel.getUnReadMessageNum()); // 未读信息数
        contentValuesObj.put(F_IS_SEND_SUCCESS, chatListModel.getIsSendSuccess()); // 发送状态标示（0：发送失败，1：发送成功，2：正在发送）
        contentValuesObj.put(F_MSG_SERVER_ID, chatListModel.getMsgServerId()); // 服务端信息ID
        contentValuesObj.put(F_IS_READ, chatListModel.getIsRead()); // 声音信息的读取标示（0：未读，1：已读）
        contentValuesObj.put(F_IS_SHIELD, chatListModel.getUserPatient().getIsShield()); // 患者被屏蔽标示（0：不屏蔽，1：屏蔽）
        contentValuesObj.put(F_PATIENT_NICK_NAME, chatListModel.getUserPatient().getPatientNickName()); // 患者昵称名称
        contentValuesObj.put(F_PATIENT_MEMO_NAME, chatListModel.getUserPatient().getPatientMemoName()); // 患者备注名称
        contentValuesObj.put(F_SESSION_ID, chatListModel.getSessionId()); // 聊天会话ID
        contentValuesObj.put(F_SESSION_LIFE_CYCLE, chatListModel.getSessionLifeCycle()); // 会话生命周期状态（0：进行中；1：已结束）
        contentValuesObj.put(F_PAY_MODE, chatListModel.getPayMode()); // 会话的付费模式（0：免费；1：付费）
        contentValuesObj.put(F_PAY_RESULT, chatListModel.getPayResult()); // 会话的付费状态（0：未付费；1：已付费）
        contentValuesObj.put(F_SESSION_BEGIN_TIME, chatListModel.getSessionBeginTime()); // 会话开始时间（毫秒值）
        contentValuesObj.put(F_SESSION_END_TIME, chatListModel.getSessionEndTime()); // 会话结束时间（毫秒值）
        contentValuesObj.put(F_LINK_URL, chatListModel.getLinkUrl()); // 云诊公告被点击时的着陆页URL
        contentValuesObj.put(F_TOPIC, chatListModel.getTopic()); // 公告二级分类的id
        contentValuesObj.put(F_TOP_SORT_TIME, chatListModel.getTopSortTime()); // 置顶排序时间（long型，精确到毫秒）
        contentValuesObj.put(F_MSG_TYPE_BUY_MEDICINE_REQUIRE, chatListModel.getMsgTypeBuyMedicineRequire()); // 特别的消息类型的保存
        contentValuesObj.put(F_BUY_MEDICINE_REQUIRE_ID, chatListModel.getRequireId()); // 购药咨询id
        contentValuesObj.put(F_BUY_MEDICINE_REQUIRE_MSG, chatListModel.getBuyMedicineRequireMsg()); // 购药咨询信息
        contentValuesObj.put(F_PATIENT_CITY_NAME, chatListModel.getUserPatient().getCityName()); // 患者所在地区（格式为：省名 市名）
        contentValuesObj.put(F_IS_ATTENTION, chatListModel.getUserPatient().getIsAttention()); // 此患者是否为医生的特别关注患者（true：是；false：否；默认值：false）
        contentValuesObj.put(F_DOCTOR_ADD_PATIENT_TIME, chatListModel.getUserPatient().getCreateTime()); // 医生添加患者的时间点
        contentValuesObj.put(F_BACK1, chatListModel.getUserPatient().getPayAmount());//图文咨询付费价格
        contentValuesObj.put(F_BACK2, chatListModel.getContent());
        contentValuesObj.put(F_BACK3, chatListModel.getTitleTipCloseTime());
        contentValuesObj.put(F_BACK4, chatListModel.getUserPatient().getConsultPayType());
        contentValuesObj.put(F_BACK5, chatListModel.getCancelFlag());
        contentValuesObj.put(F_BACK6, chatListModel.getUserPatient().getPatientPhone());
        contentValuesObj.put(F_BACK8, chatListModel.getExd());
        contentValuesObj.put(F_BACK9, chatListModel.getSessionJson());
        return contentValuesObj;
    }

    /**
     * 将XC_ChatModel业务信息对象转换成ContentValues对象
     * @param chatModel 业务信息对象
     * @return 转换后得到的ContentValues对象
     */
    private ContentValues XC_ChatModel2ContentValues(XC_ChatModel chatModel) {
        ContentValues contentValuesObj = new ContentValues();

        contentValuesObj.put(F_PATIENT_ID, chatModel.getUserPatient().getPatientId()); // 患者ID
        contentValuesObj.put(F_DELETED_FLAG, JS_ChatListModel.FLAG_GONE); // 此记录被逻辑删除的标识（0:未被逻辑删除；1:已被逻辑删除）
        contentValuesObj.put(F_PATIENT_NAME, chatModel.getUserPatient().getPatientName()); // 患者名称
        contentValuesObj.put(F_PATIENT_IMG_HEAD, chatModel.getUserPatient().getPatientImgHead()); // 患者头像
        contentValuesObj.put(F_DOCTOR_SELF_ID, chatModel.getUserDoctor().getDoctorSelfId()); // 医生ID
        contentValuesObj.put(F_DOCTOR_SELF_NAME, chatModel.getUserDoctor().getDoctorSelfName()); // 医生名称
        contentValuesObj.put(F_DOCTOR_SELF_IMG_HEAD, chatModel.getUserDoctor().getDoctorSelfImgHead()); // 医生头像
        contentValuesObj.put(F_MSG_TIME, chatModel.getMsgTime()); // 发送时间（单位：毫秒）
        contentValuesObj.put(F_MESSAGE_TEXT_RECOMMAND, chatModel.getMessageTextRecommand()); // 推荐用药
        contentValuesObj.put(F_MESSAGE_TEXT, chatModel.getMessageText()); // 文本信息
        contentValuesObj.put(F_MSG_TYPE, chatModel.getMsgType()); // 消息类型（1：文本，2：图片，4：音频，8：视频，16：文本+医药链接，32：文本+搜索）
        contentValuesObj.put(F_MSG_UNIQUE, chatModel.getMsgUnique()); // 每条信息的唯一标示（格式：user_id + time）
        contentValuesObj.put(F_VOICE_LOCALURI, chatModel.getVoiceLocalUri()); // 声音的本地缓存
        contentValuesObj.put(F_VOICE_HTTPURI, chatModel.getVoiceHttpUri()); // 声音的网络地址
        contentValuesObj.put(F_MOVE_LOCALURI, chatModel.getMoveLocalUri()); // 视频的本地缓存
        contentValuesObj.put(F_MOVE_HTTPURI, chatModel.getMoveHttpUri()); // 视频的网络地址
        contentValuesObj.put(F_PHOTO_LOCALURI, chatModel.getChatModelPhoto().getPhotoLocalUri()); // 图片的本地缓存
        contentValuesObj.put(F_PHOTO_HTTPURI, chatModel.getChatModelPhoto().getPhotoHttpUri()); // 图片的网络地址
        contentValuesObj.put(F_SENDER, chatModel.getSender()); // 发送者标识（0：医生，1：患者）
        contentValuesObj.put(F_MEDIA_DURATION, chatModel.getMediaDuration()); // 音频视频的时间（单位：毫秒）
        contentValuesObj.put(F_MEDIA_SIZE, chatModel.getMediaSize()); // 音频视频的大小（单位：KB）
        contentValuesObj.put(F_PATIENT_GENDER, chatModel.getUserPatient().getPatientGender()); // 患者性别（1：男，0：女）
        contentValuesObj.put(F_PATIENT_LETTER, chatModel.getUserPatient().getPatientLetter()); // 分组字母
        contentValuesObj.put(F_PATIENT_AGE, chatModel.getUserPatient().getPatientAge()); // 患者年龄（单位：岁）
        contentValuesObj.put(F_PATIENT_CITY_NAME, chatModel.getUserPatient().getCityName()); // 患者所在地区（格式为：省名 市名）
        contentValuesObj.put(F_IS_ATTENTION, chatModel.getUserPatient().getIsAttention()); // 此患者是否为医生的特别关注患者（true：是；false：否；默认值：false）
        contentValuesObj.put(F_DOCTOR_ADD_PATIENT_TIME, chatModel.getUserPatient().getCreateTime()); // 医生添加患者的时间点
        contentValuesObj.put(F_UN_READ_MESSAGE_NUM, chatModel.getUnReadMessageNum()); // 未读信息数
        contentValuesObj.put(F_IS_SEND_SUCCESS, chatModel.getIsSendSuccess()); // 发送状态标示（0：发送失败，1：发送成功，2：正在发送）
        contentValuesObj.put(F_MSG_SERVER_ID, chatModel.getMsgServerId()); // 服务端信息ID
        contentValuesObj.put(F_IS_READ, chatModel.getIsRead()); // 声音信息的读取标示（0：未读，1：已读）
        contentValuesObj.put(F_IS_SHIELD, chatModel.getUserPatient().getIsShield()); // 患者被屏蔽标示（0：不屏蔽，1：屏蔽）
        contentValuesObj.put(F_PATIENT_NICK_NAME, chatModel.getUserPatient().getPatientNickName()); // 患者昵称名称
        contentValuesObj.put(F_PATIENT_MEMO_NAME, chatModel.getUserPatient().getPatientMemoName()); // 患者备注名称
        contentValuesObj.put(F_SESSION_ID, chatModel.getSessionId()); // 聊天会话ID
        contentValuesObj.put(F_SESSION_LIFE_CYCLE, chatModel.getSessionLifeCycle()); // 会话生命周期状态（0：进行中；1：已结束）
        contentValuesObj.put(F_PAY_MODE, chatModel.getPayMode()); // 会话的付费模式（0：免费；1：付费）
        contentValuesObj.put(F_PAY_RESULT, chatModel.getPayResult()); // 会话的付费状态（0：未付费；1：已付费）
        contentValuesObj.put(F_SESSION_BEGIN_TIME, chatModel.getSessionBeginTime()); // 会话开始时间（毫秒值）
        contentValuesObj.put(F_SESSION_END_TIME, chatModel.getSessionEndTime()); // 会话结束时间（毫秒值）
        contentValuesObj.put(F_LINK_URL, chatModel.getLinkUrl()); // 云诊公告被点击时的着陆页URL
        contentValuesObj.put(F_TOPIC, chatModel.getTopic()); // 公告二级分类的id
        contentValuesObj.put(F_BACK1, chatModel.getUserPatient().getPayAmount());//图文咨询付费价格
        contentValuesObj.put(F_BACK2, chatModel.getContent());//IM消息中content的内容
        contentValuesObj.put(F_BACK3, chatModel.getTitleTipCloseTime());//聊天页面收费框关闭的时间
        contentValuesObj.put(F_BACK4, chatModel.getUserPatient().getConsultPayType());//2.7版本中医生对某个医生是否收费的标志
        contentValuesObj.put(F_BACK5, chatModel.getCancelFlag());//2.8版本撤销标志
        contentValuesObj.put(F_BACK6, chatModel.getUserPatient().getPatientPhone());//2.8患者手机号
        contentValuesObj.put(F_BACK8, chatModel.getExd());
        contentValuesObj.put(F_BACK9, chatModel.getSessionJson());
        return contentValuesObj;
    }

    /**
     * 获取数据库名称
     * @param doctorId 医生ID
     * @return 数据库名称
     */
    private String getDataBaseName(String doctorId) {
        return "chatlist" + doctorId + ".db";
    }

    /**
     * 构造方法
     * @param context 上下文
     */
    private JS_ChatListDB(Context context) {
        this.context = context;
    }

    /**
     * 获取数据库适配器对象
     * @param context 上下文对象
     * @param doctorId 医生ID
     * @return 数据库处理对象
     */
    public synchronized static JS_ChatListDB getInstance(Context context, String doctorId) {
        if(null == dbProcessObj) {
            dbProcessObj = new JS_ChatListDB(context);
        }
        return dbProcessObj.openDataBase(context, doctorId);
    }

//    /**
//     * 获取数据库操作权限
//     * @param context 上下文对象
//     * @param doctorId 医生ID
//     * @return 数据库操作操作对象
//     */
//    private synchronized JS_ChatListDB openDataBase(Context context, String doctorId) {
//        while(true) {
//            if(processKeyCanUseFlag) {
//                // 将数据库可操作的标识设置为“不可操作”
//                processKeyCanUseFlag = false;
//
//                DbHelper dbHelper = new DbHelper(context, getDataBaseName(doctorId));
//                db = dbHelper.getWritableDatabase();
//                break;
//            }
//        }
//
//        return dbProcessObj;
//    }

    private AtomicInteger mOpenCounter = new AtomicInteger();
    /**
     * 获取数据库操作权限
     * @param context 上下文对象
     * @param doctorId 医生ID
     * @return 数据库操作操作对象
     * 注意:
     * 1、当医生切换的时候，恰巧数据库没有关闭，这时候可能会出现另一个医生的数据存入到上个数据库的情况。
     * 2、这种情况暂时不解决，假如现有思路可以解决数据库并发读写的问题再着手解决这个问题
     * 3、(后来经过测试并没有发现预料之中的问题，暂时先不予考虑这个情况，倘若有问题时候再考虑这个这个原因)
     */
    private JS_ChatListDB openDataBase(Context context, String doctorId) {
        if (mOpenCounter.incrementAndGet() == 1){
            DbHelper dbHelper = new DbHelper(context, getDataBaseName(doctorId));
            db = dbHelper.getWritableDatabase();
        }

        return dbProcessObj;
    }

    /**
     * 关闭数据库
     */
    private void closeDataBase() {
        try {
            if(mOpenCounter.decrementAndGet() == 0) {
                if(null != db && db.isOpen()) {
                    db.close();
                }
            }
        }catch(Exception e) {
            System.out.println("---close database happened exception---");
            e.printStackTrace();
        }finally {
            // 将数据库可操作的标识设置为“可操作”
            processKeyCanUseFlag = true;
        }
    }

    /**
     * 获取未读记录的患者数
     * @return 未读记录的患者数
     */
    public int getUnreadRecordPatientCount() {
        // 未读记录的患者数（默认值：0）
        int unreadRecordPatientCount;

        String[] columns = new String[]{"COUNT(*)"};
        String selection =  F_UN_READ_MESSAGE_NUM + ">0" + F_DELETED_FLAG + "=" + JS_ChatListModel.FLAG_VISIBLE;
        Cursor cursor = db.query(TB_NAME_CHATLIST, columns, selection, null, null, null, null);
        cursor.moveToNext();
        unreadRecordPatientCount = cursor.getInt(0);

        cursor.close();
        closeDataBase();
        return unreadRecordPatientCount;
    }

    /**
     * 获取未读记录总数（去除公告和通知的未读数）
     * @return 未读记录总数
     */
    public int getUnreadRecordCount() {
        // 未读记录总数（默认值：0）
        int unreadRecordCount = 0;
        String[] columns = new String[]{F_PATIENT_ID,F_UN_READ_MESSAGE_NUM};
        String selection =  F_UN_READ_MESSAGE_NUM + ">0" + " and " + F_DELETED_FLAG + "=" + JS_ChatListModel.FLAG_VISIBLE ;
        Cursor cursor = db.query(TB_NAME_CHATLIST, columns, selection ,null, null, null, null);
        while(cursor.moveToNext()) {
            String patientId = cursor.getString(cursor.getColumnIndex(F_PATIENT_ID));
            if(!JS_ChatListModel.ACCOUNT_ID.equals(patientId)&&!JS_ChatListModel.NOTICE_ID.equals(patientId)){
                unreadRecordCount += cursor.getInt(cursor.getColumnIndex(F_UN_READ_MESSAGE_NUM));
            }
        }

        cursor.close();
        closeDataBase();
        return unreadRecordCount;
    }

    /**
     * 获取系统消息类型的未读消息数（系统公告 系统通知）
     * @return
     */
    public int getSysMessageUnreadRecordCount() {
        // 未读记录总数（默认值：0）
        int unreadRecordCount = 0;
        String[] columns = new String[]{F_UN_READ_MESSAGE_NUM};
        String selection =  F_UN_READ_MESSAGE_NUM + ">0" + " and " + F_DELETED_FLAG + "=" +
                JS_ChatListModel.FLAG_VISIBLE +" and "+ F_PATIENT_ID +" in (?,?)";
        String[] patientIds = new String[]{JS_ChatListModel.NOTICE_ID,JS_ChatListModel.ACCOUNT_ID};
        Cursor cursor = db.query(TB_NAME_CHATLIST, columns, selection ,patientIds, null, null, null);
        while(cursor.moveToNext()) {
            unreadRecordCount += cursor.getInt(cursor.getColumnIndex(F_UN_READ_MESSAGE_NUM));
        }

        cursor.close();
        closeDataBase();
        return unreadRecordCount;
    }

    /**
     * 获取系统通知未读消息数
     * @return
     */
    public int getNoticeUnreadRecordCount( ) {
        // 未读记录总数（默认值：0）
        int unreadRecordCount = 0;
        String[] columns = new String[]{F_UN_READ_MESSAGE_NUM};
        String selection =  F_UN_READ_MESSAGE_NUM + ">0" + " and " + F_DELETED_FLAG + "=" +
                JS_ChatListModel.FLAG_VISIBLE +" and "+ F_PATIENT_ID +" =? ";
        String[] patientIds = new String[]{JS_ChatListModel.ACCOUNT_ID};
        Cursor cursor = db.query(TB_NAME_CHATLIST, columns, selection ,patientIds, null, null, null);
        while(cursor.moveToNext()) {
            unreadRecordCount += cursor.getInt(cursor.getColumnIndex(F_UN_READ_MESSAGE_NUM));
        }

        cursor.close();
        closeDataBase();
        return unreadRecordCount;
    }

    /**
     * 获取公告类未读消息数
     * @param topic
     * @return
     */
    public int getUnreadRecordCount(String topic) {
        // 未读记录数（默认值：0）
        int unreadRecordCount = 0;
        String[] columns = new String[]{F_UN_READ_MESSAGE_NUM};
        String selection =  F_UN_READ_MESSAGE_NUM + ">0" + " and " + F_DELETED_FLAG + "=" +
                JS_ChatListModel.FLAG_VISIBLE +" and " + F_PATIENT_ID + "=?" +" and "+ F_TOPIC  + "=?";
        String[] patientIds = new String[]{ JS_ChatListModel.NOTICE_ID,topic};
        Cursor cursor = db.query(TB_NAME_CHATLIST, columns, selection ,patientIds, null, null, null);
        while(cursor.moveToNext()) {
            unreadRecordCount += cursor.getInt(cursor.getColumnIndex(F_UN_READ_MESSAGE_NUM));
        }

        cursor.close();
        closeDataBase();
        return unreadRecordCount;
    }
    /**
     * 获取全部咨询列表的信息记录
     * @return 咨询患者的全部记录列表对象。
     */
    public ArrayList<JS_ChatListModel> getAllRecord() {
        ArrayList<JS_ChatListModel> dataSetListObj = new ArrayList<JS_ChatListModel>();

        // 获取置顶列表信息
        String selection_01 = F_DELETED_FLAG + "=" + JS_ChatListModel.FLAG_VISIBLE + " and " + F_TOP_SORT_TIME + ">0";
        String orderBy_01 = F_TOP_SORT_TIME + " desc"; // 按“【置顶】排序时间”进行降序排序
        Cursor cursor_01 = db.query(TB_NAME_CHATLIST, null, selection_01, null, null, null, orderBy_01);
        while(cursor_01.moveToNext()) {
            JS_ChatListModel dataSetObj = cursor2JS_ChatListModel(cursor_01);
            dataSetListObj.add(dataSetObj);
        }
        // 获取非置顶列表信息
        String selection_02 = F_DELETED_FLAG + "=" + JS_ChatListModel.FLAG_VISIBLE + " and " + F_TOP_SORT_TIME + "=0";
        String orderBy_02 = F_MSG_TIME + " desc"; // 按“消息时间”进行降序排序
        Cursor cursor_02 = db.query(TB_NAME_CHATLIST, null, selection_02, null, null, null, orderBy_02);
        while(cursor_02.moveToNext()) {
            JS_ChatListModel dataSetObj = cursor2JS_ChatListModel(cursor_02);
            dataSetListObj.add(dataSetObj);
        }

        cursor_01.close();
        cursor_02.close();
        closeDataBase();
        return dataSetListObj;
    }

    /**
     * 获取全部咨询列表的信息记录（剔除公告类以及系统）
     * @return 咨询患者的全部记录列表对象。
     */
    public ArrayList<JS_ChatListModel> getImRecord() {
        ArrayList<JS_ChatListModel> dataSetListObj = new ArrayList<JS_ChatListModel>();

        // 获取置顶列表信息
        String selection_01 = F_DELETED_FLAG + "=" + JS_ChatListModel.FLAG_VISIBLE + " and " + F_TOP_SORT_TIME + ">0";
        String orderBy_01 = F_TOP_SORT_TIME + " desc"; // 按“【置顶】排序时间”进行降序排序
        Cursor cursor_01 = db.query(TB_NAME_CHATLIST, null, selection_01, null, null, null, orderBy_01);
        while(cursor_01.moveToNext()) {
            JS_ChatListModel dataSetObj = cursor2JS_ChatListModel(cursor_01);
            if(!JS_ChatListModel.ACCOUNT_ID.equals(dataSetObj.getUserPatient().getPatientId()) && !JS_ChatListModel.NOTICE_ID.equals(dataSetObj.getUserPatient().getPatientId())){
                dataSetListObj.add(dataSetObj);
            }
        }
        // 获取非置顶列表信息
        String selection_02 = F_DELETED_FLAG + "=" + JS_ChatListModel.FLAG_VISIBLE + " and " + F_TOP_SORT_TIME + "=0";
        String orderBy_02 = F_MSG_TIME + " desc"; // 按“消息时间”进行降序排序
        Cursor cursor_02 = db.query(TB_NAME_CHATLIST, null, selection_02, null, null, null, orderBy_02);
        while(cursor_02.moveToNext()) {
            JS_ChatListModel dataSetObj = cursor2JS_ChatListModel(cursor_02);
            if(!JS_ChatListModel.ACCOUNT_ID.equals(dataSetObj.getUserPatient().getPatientId()) && !JS_ChatListModel.NOTICE_ID.equals(dataSetObj.getUserPatient().getPatientId())){
                dataSetListObj.add(dataSetObj);
            }
        }

        cursor_01.close();
        cursor_02.close();
        closeDataBase();
        return dataSetListObj;
    }
    /**
     * 将会话生命周期状态设置为已结束（会话生命周期状态。0：咨询中；1：已结束）
     * @param sessionId 会话ID
     * @param sessionEndTime 会话结束时间
     * @return 操作结果状态标示（true：操作成功，false：操作失败）
     */
    public boolean setSessionLifeCycleIsOver(String sessionId, String sessionEndTime) {
        if(null == sessionId || sessionId.trim().length() == 0) {
            closeDataBase();
            return false;
        }

        if(null == sessionEndTime) {
            sessionEndTime = "";
        }

        // 操作结果状态标示（true：操作成功，false：操作失败，默认值：false）
        boolean flag = false;

        ContentValues contentValues = new ContentValues();
        contentValues.put(F_SESSION_LIFE_CYCLE, "1"); // 会话生命周期状态（0：进行中；1：已结束）
        contentValues.put(F_SESSION_END_TIME, sessionEndTime); // 会话结束时间（毫秒值）
        String whereClause = F_SESSION_ID + "=?";
        String[] whereArgs = new String[]{sessionId};
        int  numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
        if(numberOfRowsAffected > 0) {
            flag = true;
        }

        closeDataBase();
        return flag;
    }

    /**
     * 查看某位患者的咨询信息后，要将此患者的未读信息数清零
     * @param patientId 患者ID
     * @return 操作结果状态标示（true：操作成功，false：操作失败）
     */
    public boolean setUnReadMessageNum2Zero(String patientId) {
        if(null == patientId || patientId.trim().length() == 0) {
            closeDataBase();
            return false;
        }

        // 操作结果状态标示（true：操作成功，false：操作失败，默认值：false）
        boolean flag = false;

        ContentValues contentValues = new ContentValues();
        contentValues.put(F_UN_READ_MESSAGE_NUM, "0");
        String whereClause = F_PATIENT_ID + "=?";
        String[] whereArgs = new String[]{patientId};
        int numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
        if(numberOfRowsAffected > 0) {
            flag = true;
        }

        closeDataBase();
        return flag;
    }

    /**
     * 查看某位患者的咨询信息后，要将此患者的未读信息数清零
     * @param chatListBeanObj 咨询列表信息对象
     * @return 操作结果状态标示（true：操作成功，false：操作失败）
     */
    public boolean setUnReadMessageNum2Zero(JS_ChatListModel chatListBeanObj) {
        // 操作结果状态标识（true：操作成功，false：操作失败，默认值：false）
        boolean flag = false;

        String temp_patientId = chatListBeanObj.getUserPatient().getPatientId();
        String temp_topic = chatListBeanObj.getTopic();

        if(null == temp_patientId || temp_patientId.trim().length() == 0) {
            closeDataBase();
            return false;
        }
        //如果二级分类标识为空，就是患者，否则为公告
        if(null == temp_topic || temp_topic.trim().length() == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(F_UN_READ_MESSAGE_NUM, "0");
            String whereClause = F_PATIENT_ID + "=?";
            String[] whereArgs = new String[]{temp_patientId};
            int numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
            if(numberOfRowsAffected > 0) {
                flag = true;
            }
        }else {
            ContentValues contentValues = new ContentValues();
            contentValues.put(F_UN_READ_MESSAGE_NUM, "0");
            String whereClause = F_PATIENT_ID + "=?" + " and " + F_TOPIC + "=?";
            String[] whereArgs = new String[]{temp_patientId, temp_topic};
            int numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
            if(numberOfRowsAffected > 0) {
                flag = true;
            }
        }

        closeDataBase();
        return flag;
    }

    /**
     * 将某种类型的公告未读清零
     * @param topic
     * @return
     */
    public boolean setNoticeUnReadMessageNum2Zero(String topic) {
        // 操作结果状态标识（true：操作成功，false：操作失败，默认值：false）
        boolean flag = false;

        if(null == topic || topic.trim().length() == 0) {
            closeDataBase();
            return false;

        }
        ContentValues contentValues = new ContentValues();
        contentValues.put(F_UN_READ_MESSAGE_NUM, "0");
        String whereClause = F_PATIENT_ID + "=?" + " and " + F_TOPIC + "=?";
        String[] whereArgs = new String[]{JS_ChatListModel.NOTICE_ID, topic};
        int numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
        if(numberOfRowsAffected > 0) {
            flag = true;
        }
        closeDataBase();
        return flag;
    }

    /**
     * 根据患者ID获取患者的咨询状态值（包括置顶状态，免打扰状态等）
     * @param patientId 患者ID
     * @return 咨询列表信息BEAN对象
     */
    public JS_ChatListModel getChatStatus(String patientId) {
        JS_ChatListModel js_ChatListModelObj = new JS_ChatListModel();

        String[] columns = null;
        String selection = F_PATIENT_ID + "=?";
        String[] selectionArgs = new String[]{patientId};
        Cursor cursor = db.query(TB_NAME_CHATLIST, columns, selection, selectionArgs, null, null, null);

        if(cursor.moveToNext()) {
            js_ChatListModelObj = cursor2JS_ChatListModel(cursor);
        }

        cursor.close();
        closeDataBase();
        return js_ChatListModelObj;
    }

    /**
     * 根据患者ID获取患者的信息
     * @param patientId 患者ID
     * @return 咨询列表信息BEAN对象
     */
    public JS_ChatListModel getPatientInfo(String patientId) {
        JS_ChatListModel js_ChatListModelObj = new JS_ChatListModel();

        String[] columns = null;
        String selection = F_PATIENT_ID + "=?";
        String[] selectionArgs = new String[]{patientId};
        Cursor cursor = db.query(TB_NAME_CHATLIST, columns, selection, selectionArgs, null, null, null);

        if(cursor.moveToNext()) {
            js_ChatListModelObj = cursor2JS_ChatListModel(cursor);
        }

        cursor.close();
        closeDataBase();
        return js_ChatListModelObj;
    }

    /** created by 马杨茗,date：2016-4-13
     * 根据患者昵称对患者列表进行模糊查询
     * @param patientName 患者真实姓名 或者 患者备注名称
     * @return 咨询列表信息BEAN对象
     */
    public List<JS_ChatListModel> getSearchPatientInfo(String patientName){
        List<JS_ChatListModel> chatListModels = new ArrayList<>();
        String[] columns = null;
        String selection = F_PATIENT_NAME + " like ? or " + F_PATIENT_MEMO_NAME + " like ?";
        String[] selectionArgs = new String[]{"%"+patientName+"%","%"+patientName+"%"};
        Cursor cursor = db.query(TB_NAME_CHATLIST, columns, selection, selectionArgs, null, null, null);

        while(cursor.moveToNext()) {
            JS_ChatListModel js_ChatListModelObj = cursor2JS_ChatListModel(cursor);
            chatListModels.add(js_ChatListModelObj);
        }

        cursor.close();
        closeDataBase();
        return chatListModels;
    }

    /**
     * 插入一条咨询记录<p>
     * 当收到push信息时，进行新数据的插入操作，处理逻辑为：<p>
     * １.若表中没有相同患者的信息，则进行插入操作
     * （1）注意：对于“云诊公告”及“账户动态”类型的信息是没有patientId的，所以要使用预设定的值进行保存（预设定的值参见：JS_ChatListModel.java 中的 NOTICE_ID 及 ACCOUNT_ID）；<p>
     * ２.若表中有相同患者的信息，则进行更新操作（更新规则为：<p>
     * （1）“屏蔽此患者消息的状态标示”字段内容不进行更新，<p>
     * （2）“未读信息数”要进行累加，<p>
     * （3）如果“【置顶】排序时间（T2）”字段的值不等于“”或“０”则使用“消息时间　msgTime”的值更新“【置顶】排序时间（T2）”的值<p>
     * （4）如果传入记录的“患者备注名”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值。<p>
     * （5）如果传入记录的“特别的消息类型”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值。<p>
     * （6）如果传入记录的“购药咨询id”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值。<p>
     * （7）如果传入记录的“购药咨询信息”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值。<p>
     * （8）如果传入记录的“患者头像网络url”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值。<p>
     * （9）如果传入记录的“患者性别”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值。<p>
     * （10）如果传入记录的“患者年龄”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值。<p>
     * （11）如果传入记录的“患者名称的分组字母”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值。<p>
     * （12）更新其余所有字段。
     * @param obj 业务信息对象
     * @return 被操作记录的主键。当发生错误时，返回-1。
     */
    public long insertNewChatInfo(XC_ChatModel obj) {
        if(null == obj) {
            closeDataBase();
            return -1;
        }

        // 行记录的主键值
        long rowId = 0;
        // 表中是否存在相同患者信息的标示（true：存在，false：不存在，默认值：false）
        boolean flag;

        String topic = obj.getTopic();
        String queryClause;
        String[] queryClauseParamStrings;
        Cursor queryCursor;
        // 若是公告通知类型信息的插入，需进行patientId　及　topic信息的比对
        if(null != topic && topic.trim().length() > 0) {
            queryClause = F_PATIENT_ID + "=?" + " and " + F_TOPIC + "=?"; // 查询条件
            queryClauseParamStrings = new String[]{obj.getUserPatient().getPatientId(), obj.getTopic()}; // 查询条件的参数值
            queryCursor = db.query(TB_NAME_CHATLIST, null, queryClause, queryClauseParamStrings, null, null, null);
            flag = queryCursor.moveToNext();
        }
        // 若是非公告通知类型信息，只需进行patientId信息的比对
        else {
            queryClause = F_PATIENT_ID + "=?"; // 查询条件
            queryClauseParamStrings = new String[]{obj.getUserPatient().getPatientId()}; // 查询条件的参数值
            queryCursor = db.query(TB_NAME_CHATLIST, null, queryClause, queryClauseParamStrings, null, null, null);
            flag = queryCursor.moveToNext();
        }

        // 若表中没有相同患者的信息，则进行插入操作
        if(!flag) {
            // 将传入信息对象的未读信息数设置为“1”（说明：因为非医生角色的消息算作是一条未读信息）
            obj.setUnReadMessageNum("1");
            ContentValues values = JS_ChatListModel2ContentValues(bean2JS_ChatListModel(obj));
            rowId = db.insert(TB_NAME_CHATLIST, F_ID, values);
        }
        // 若表中有相同患者的信息，则进行更新操作
        else {
            // 行记录的主键值（临时保存使用）
            long tempRowId = queryCursor.getInt(queryCursor.getColumnIndex(F_ID));
            // 要保存到数据库中的新的业务信息对象
            JS_ChatListModel newJS_ChatListModelObj = bean2JS_ChatListModel(obj);
            // 从数据库中取出的旧的业务信息对象
            JS_ChatListModel oldJS_ChatListModelObj = cursor2JS_ChatListModel(queryCursor);

            // 按更新规则，对要保存的数据进行再处理
            // （1）“屏蔽此患者消息的状态标示”字段内容不进行更新，使用原值
            newJS_ChatListModelObj.getUserPatient().setIsShield(oldJS_ChatListModelObj.getUserPatient().getIsShield());

            // （2）“未读信息数”要进行累加后再进行保存
            String defaultValue;
            String sender = newJS_ChatListModelObj.getSender();
            if(SENDER_IS_PATIENT.equals(sender)) {
                defaultValue = "1";
            } else if(PUB_NOTICE.equals(sender)) {
                defaultValue = "1";
            } else if(ACCOUNT_STATE.equals(sender)) {
                defaultValue = "1";
            } else if(SERVICE.equals(sender)){//add by cyr on 2017-9-1 新添加医生助手标识，修复医生助手没有计算在未读消息的bug
                defaultValue = "1";
            } else {
                defaultValue = "0";
            }
            String oldUnReadMessageNum = oldJS_ChatListModelObj.getUnReadMessageNum(); // 未读信息数（旧值）
            String newUnReadMessageNum = newJS_ChatListModelObj.getUnReadMessageNumWhenZero(defaultValue); // 未读信息数（新值）
            String sumUnReadMessageNum = String.valueOf(Integer.valueOf(oldUnReadMessageNum) + Integer.valueOf(newUnReadMessageNum)); // 未读信息数（旧值 + 新值）
            newJS_ChatListModelObj.setUnReadMessageNum(sumUnReadMessageNum);

            // （3）如果“【置顶】排序时间（T2）”字段的值不等于“”或“0”则使用“消息时间　msgTime”的值更新“【置顶】排序时间（T2）”的值
            String topSortTime = oldJS_ChatListModelObj.getTopSortTime().trim();
            if(null == topSortTime || topSortTime.length() == 0 || "0".equals(topSortTime)) {
                newJS_ChatListModelObj.setTopSortTime("0");
            }else {
                newJS_ChatListModelObj.setTopSortTime(newJS_ChatListModelObj.getMsgTime());
            }

            // （4）如果传入记录的“患者备注名”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newPatientMemoName = newJS_ChatListModelObj.getUserPatient().getPatientMemoName();
            if(TextUtils.isEmpty(newPatientMemoName)) {
                // 不覆盖旧值
                String oldPatientMemoName = oldJS_ChatListModelObj.getUserPatient().getPatientMemoName();
                newJS_ChatListModelObj.getUserPatient().setPatientMemoName(oldPatientMemoName);
            }

            // （4.1）如果传入记录的“患者真实名”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newtPatientName = newJS_ChatListModelObj.getUserPatient().getPatientName();
            if(TextUtils.isEmpty(newtPatientName)) {
                // 不覆盖旧值
                String oldPatientName = oldJS_ChatListModelObj.getUserPatient().getPatientName();
                newJS_ChatListModelObj.getUserPatient().setPatientName(oldPatientName);
            }

            // （5）如果传入记录的“特别的消息类型”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newMsgTypeBuyMedicineRequire = newJS_ChatListModelObj.getMsgTypeBuyMedicineRequire();
            if(TextUtils.isEmpty(newMsgTypeBuyMedicineRequire)) {
                String oldMsgTypeBuyMedicineRequire = oldJS_ChatListModelObj.getMsgTypeBuyMedicineRequire();
                newJS_ChatListModelObj.setMsgTypeBuyMedicineRequire(oldMsgTypeBuyMedicineRequire);
            }

            // （6）如果传入记录的“购药咨询id”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newRequireId = newJS_ChatListModelObj.getRequireId();
            if(TextUtils.isEmpty(newRequireId)) {
                String oldRequireId = oldJS_ChatListModelObj.getRequireId();
                newJS_ChatListModelObj.setRequireId(oldRequireId);
            }

            // （7）如果传入记录的“购药咨询信息”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newBuyMedicineRequireMsg = newJS_ChatListModelObj.getBuyMedicineRequireMsg();
            if(TextUtils.isEmpty(newBuyMedicineRequireMsg)) {
                String oldBuyMedicineRequireMsg = oldJS_ChatListModelObj.getBuyMedicineRequireMsg();
                newJS_ChatListModelObj.setBuyMedicineRequireMsg(oldBuyMedicineRequireMsg);
            }

            // （8）如果传入记录的“患者头像网络url”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newPatientImgHead = newJS_ChatListModelObj.getUserPatient().getPatientImgHead();
            if(TextUtils.isEmpty(newPatientImgHead)) {
                // 不覆盖旧值
                String oldPatientImgHead = oldJS_ChatListModelObj.getUserPatient().getPatientImgHead();
                newJS_ChatListModelObj.getUserPatient().setPatientImgHead(oldPatientImgHead);
            }

            // （9）如果传入记录的“患者性别”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newPatientGender = newJS_ChatListModelObj.getUserPatient().getPatientGender();
            if(TextUtils.isEmpty(newPatientGender)) {
                // 不覆盖旧值
                String oldPatientGender = oldJS_ChatListModelObj.getUserPatient().getPatientGender();
                newJS_ChatListModelObj.getUserPatient().setPatientGender(oldPatientGender);
            }

            // （10）如果传入记录的“患者年龄”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newPatientAge = newJS_ChatListModelObj.getUserPatient().getPatientAge();
            if(TextUtils.isEmpty(newPatientAge)) {
                // 不覆盖旧值
                String oldPatientAge = oldJS_ChatListModelObj.getUserPatient().getPatientAge();
                newJS_ChatListModelObj.getUserPatient().setPatientAge(oldPatientAge);
            }

            // （11）如果传入记录的“患者名称的分组字母”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newPatientLetter = newJS_ChatListModelObj.getUserPatient().getPatientLetter();
            if(TextUtils.isEmpty(newPatientLetter)) {
                // 不覆盖旧值
                String oldnewPatientLetter = oldJS_ChatListModelObj.getUserPatient().getPatientLetter();
                newJS_ChatListModelObj.getUserPatient().setPatientLetter(oldnewPatientLetter);
            }
            // （11）如果传入记录的“患者的手机号”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newPatientPhone = newJS_ChatListModelObj.getUserPatient().getPatientPhone();
            if(TextUtils.isEmpty(newPatientPhone)) {
                // 不覆盖旧值
                String oldnewPatientPhone = oldJS_ChatListModelObj.getUserPatient().getPatientPhone();
                newJS_ChatListModelObj.getUserPatient().setPatientPhone(oldnewPatientPhone);
            }
            // （12）如果传入记录的“患者的付费咨询状态”有值，则使用传入记录的值覆盖表中的旧值。否则，不覆盖表中的旧值
            String newPatientConsultPayType = newJS_ChatListModelObj.getUserPatient().getConsultPayType();
            if(TextUtils.isEmpty(newPatientConsultPayType)) {
                // 不覆盖旧值
                String oldPatientConsultPayType = oldJS_ChatListModelObj.getUserPatient().getConsultPayType();
                newJS_ChatListModelObj.getUserPatient().setConsultPayType(oldPatientConsultPayType);
            }
            // 进行更新操作
            String tempTopic = obj.getTopic();
            String updateClause;
            String[] updateClauseParamStrings;
            ContentValues contentValues;
            int numberOfRowsAffected;
            // 若是公告通知类型信息的插入，需进行patientId　及　topic信息的比对
            if(null != tempTopic && tempTopic.trim().length() > 0) {
                updateClause = F_PATIENT_ID + "=?" + " and " + F_TOPIC + "=?"; // 更新条件
                updateClauseParamStrings = new String[]{obj.getUserPatient().getPatientId(), obj.getTopic()}; // 更新条件的参数值
                contentValues = JS_ChatListModel2ContentValues(newJS_ChatListModelObj);
                numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, updateClause, updateClauseParamStrings);
            }
            // 若是非公告通知类型信息，只需进行patientId信息的比对
            else {
                updateClause = F_PATIENT_ID + "=?"; // 更新条件
                updateClauseParamStrings = new String[]{obj.getUserPatient().getPatientId()}; // 更新条件的参数值
                contentValues = JS_ChatListModel2ContentValues(newJS_ChatListModelObj);
                numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, updateClause, updateClauseParamStrings);
            }

            if(numberOfRowsAffected > 0) {
                rowId = tempRowId;
            }
        }

        queryCursor.close();
        closeDataBase();
        return rowId;
    }

    /**
     * 根据“患者id”及“公告二级分类的id”查询相匹配的记录<p>
     * 将相匹配记录中的“特别的消息类型　msgTypeBuyMedicineRequire”及“购药咨询id　requireId”字段内容删除掉
     * @param obj 咨询信息对象
     * @return 操作结果标示（true：操作成功；false：操作失败）
     */
    public boolean deleteBuyMedicineRequireInfo(XC_ChatModel obj) {
        if(null == obj) {
            closeDataBase();
            return false;
        }

        // 操作结果标示（true：操作成功；false：操作失败；默认值：false）
        boolean oprationFlag = false;
        // 表中是否存在相同患者信息的标示（true：存在，false：不存在，默认值：false）
        boolean flag;

        String queryClause;
        String[] queryClauseParamStrings;
        Cursor queryCursor;

        // 1.判断咨询列表中是否有相同患者
        queryClause = F_PATIENT_ID + "=?" + " and " + F_TOPIC + "=?"; // 查询条件
        queryClauseParamStrings = new String[]{obj.getUserPatient().getPatientId(), obj.getTopic()}; // 查询条件的参数值
        queryCursor = db.query(TB_NAME_CHATLIST, null, queryClause, queryClauseParamStrings, null, null, null);
        flag = queryCursor.moveToNext();
        // 2.1如果没有相同的患者，则不进行任何处理
        if(!flag) {
            // 什么都不做
        }
        // 2.2如果有相同的患者，则对“咨询列表DB”中相同患者记录的“特别的消息类型　msgTypeBuyMedicineRequire”字段，“购药咨询id　requireId”字段及“购药咨询信息　buyMedicineRequireMsg”字段内容进行清空
        else {
            String updateClause;
            String[] updateClauseParamStrings;
            ContentValues contentValues;
            int numberOfRowsAffected;

            updateClause = F_PATIENT_ID + "=?" + " and " + F_TOPIC + "=?"; // 更新条件
            updateClauseParamStrings = new String[]{obj.getUserPatient().getPatientId(), obj.getTopic()}; // 更新条件的参数值
            JS_ChatListModel oldChatListModel = cursor2JS_ChatListModel(queryCursor);
            oldChatListModel.setMsgTypeBuyMedicineRequire(""); // 特别的消息类型
            oldChatListModel.setRequireId(""); // 购药咨询id
            oldChatListModel.setBuyMedicineRequireMsg(""); // 购药咨询信息
            contentValues = JS_ChatListModel2ContentValues(oldChatListModel);
            numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, updateClause, updateClauseParamStrings);

            if(numberOfRowsAffected > 0) {
                oprationFlag = true;
            }
        }

        queryCursor.close();
        closeDataBase();
        return oprationFlag;
    }

    /**
     * 根据置顶状态获取置顶排序时间。<p>
     * 说明：当置顶状态为true时，置顶排序时间的值为“0”。当置顶状态为false时，置顶排序时间的值为系统当前时间（long型的值内容）
     * @param status 状态值（true：置顶，false：取消置顶）
     * @return 置顶排序时间
     */
    private String getTopSortTimeByStatus(boolean status) {
        // 置顶排序时间（置顶时：取系统当前时间，不置顶时：取“0”，默认值：“0”）
        String topSortTime;
        if(status) {
            topSortTime = String.valueOf(System.currentTimeMillis());
        }else {
            topSortTime = "0";
        }

        return topSortTime;
    }

    /**
     * 更新一条指定记录的“置顶/取消置顶”状态。（注意：此方法只更新“置顶/取消置顶”状态字段，不更新其他字段）
     * @param patientId 患者ID
     * @param status 状态值（true：置顶，false：取消置顶）
     * @return 操作结果状态标识。true：操作成功，false：操作失败。
     */
    public boolean setTopStatus(String patientId, boolean status) {
        // 操作结果状态标识（true：操作成功，false：操作失败，默认值：操作失败）
        boolean flag = false;

        /*
         * (1)查询数据表中是否有此患者的记录
         * (2)如果没有：执行插入操作
         * (3)如果有：执行更新操作
         */
        String queryClause = F_PATIENT_ID + "=?"; // 更新条件
        String[] queryClauseParamStrings = new String[]{patientId}; // 更新条件的参数值
        Cursor queryCursor = db.query(TB_NAME_CHATLIST, new String[]{"COUNT(*)"}, queryClause, queryClauseParamStrings, null, null, null);
        queryCursor.moveToNext();
        int count = queryCursor.getInt(0);

        if(count == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(F_PATIENT_ID, patientId);
            contentValues.put(F_TOP_SORT_TIME, getTopSortTimeByStatus(status));
            long rowId = db.insert(TB_NAME_CHATLIST, F_ID, contentValues);

            if(rowId > -1) {
                flag = true;
            }
        }else {
            String updateClause = F_PATIENT_ID + "=?"; // 更新条件
            String[] updateClauseParamStrings = new String[]{patientId}; // 更新条件的参数值
            ContentValues contentValues = new ContentValues();
            contentValues.put(F_PATIENT_ID, patientId);
            contentValues.put(F_TOP_SORT_TIME, getTopSortTimeByStatus(status));
            int numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, updateClause, updateClauseParamStrings);

            if(numberOfRowsAffected > 0) {
                flag = true;
            }
        }

        queryCursor.close();
        closeDataBase();
        return flag;
    }

    /**
     * 更新一条指定记录的“免打扰/取消免打扰”状态。（注意：此方法只更新“免打扰/取消免打扰”状态字段，不更新其他字段）
     * @param patientId 患者ID
     * @param status 状态值（true：免打扰，false：取消免打扰）
     * @return 操作结果状态标识。true：操作成功，false：操作失败。
     */
    public boolean setSilentStatus(String patientId, boolean status) {
        // 操作结果状态标识（true：操作成功，false：操作失败，默认值：操作失败）
        boolean flag = false;

        /*
         * (1)查询数据表中是否有此患者的记录
         * (2)如果没有：执行插入操作
         * (3)如果有：执行更新操作
         */
        String queryClause = F_PATIENT_ID + "=?"; // 更新条件
        String[] queryClauseParamStrings = new String[]{patientId}; // 更新条件的参数值
        Cursor queryCursor = db.query(TB_NAME_CHATLIST, new String[]{"COUNT(*)"}, queryClause, queryClauseParamStrings, null, null, null);
        queryCursor.moveToNext();
        int count = queryCursor.getInt(0);

        if(count == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(F_PATIENT_ID, patientId);
            contentValues.put(F_IS_SHIELD, status);
            long rowId = db.insert(TB_NAME_CHATLIST, F_ID, contentValues);

            if(rowId > -1) {
                flag = true;
            }
        }else {
            String updateClause = F_PATIENT_ID + "=?"; // 更新条件
            String[] updateClauseParamStrings = new String[]{patientId}; // 更新条件的参数值
            ContentValues contentValues = new ContentValues();
            contentValues.put(F_PATIENT_ID, patientId);
            contentValues.put(F_IS_SHIELD, status);
            int numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, updateClause, updateClauseParamStrings);

            if(numberOfRowsAffected > 0) {
                flag = true;
            }
        }

        queryCursor.close();
        closeDataBase();
        return flag;
    }

    /**
     * 更新一条指定记录的“置顶/取消置顶”状态　或　“免打扰/取消免打扰”状态。（注意：同时更新其他字段。）
     * 当用户对某条记录进行“置顶/取消置顶”或“免打扰/取消免打扰”操作时，调用此方法。（注意：同时更新其他字段。）
     * @param obj 咨询列表信息BEAN。
     * @return 操作结果状态标识。true：操作成功，false：操作失败。
     */
    public boolean setTopStatusOrSilentStatus(JS_ChatListModel obj) {
        if(null == obj) {
            closeDataBase();
            return false;
        }

        // 操作结果状态标识（true：操作成功，false：操作失败，默认值：操作失败）
        boolean flag = false;

        /*
         * (1)查询数据表中是否有此患者的记录
         * (2)如果没有：执行插入操作
         * (3)如果有：执行更新操作
         */
        String topic = obj.getTopic();
        Cursor queryCursor;
        if(null == topic || topic.trim().length() == 0) {
            String queryClause = F_PATIENT_ID + "=?"; // 更新条件
            String[] queryClauseParamStrings = new String[]{obj.getUserPatient().getPatientId()}; // 更新条件的参数值
            queryCursor = db.query(TB_NAME_CHATLIST, new String[]{"COUNT(*)"}, queryClause, queryClauseParamStrings, null, null, null);
        }else {
            String queryClause = F_PATIENT_ID + "=?" + " and " + F_TOPIC + "=?"; // 更新条件
            String[] queryClauseParamStrings = new String[]{obj.getUserPatient().getPatientId(), obj.getTopic()}; // 更新条件的参数值
            queryCursor = db.query(TB_NAME_CHATLIST, new String[]{"COUNT(*)"}, queryClause, queryClauseParamStrings, null, null, null);
        }

        queryCursor.moveToNext();
        int count = queryCursor.getInt(0);

        if(count == 0) {
            ContentValues values = JS_ChatListModel2ContentValues(obj);
            long rowId = db.insert(TB_NAME_CHATLIST, F_ID, values);

            if(rowId > -1) {
                flag = true;
            }
        }else {
            int numberOfRowsAffected;
            if(null == topic || topic.trim().length() == 0) {
                String updateClause = F_PATIENT_ID + "=?"; // 更新条件
                String[] updateClauseParamStrings = new String[]{obj.getUserPatient().getPatientId()}; // 更新条件的参数值
                ContentValues contentValues = JS_ChatListModel2ContentValues(obj);
                numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, updateClause, updateClauseParamStrings);
            }else {
                String updateClause = F_PATIENT_ID + "=?" + " and " + F_TOPIC + "=?"; // 更新条件
                String[] updateClauseParamStrings = new String[]{obj.getUserPatient().getPatientId(), obj.getTopic()}; // 更新条件的参数值
                ContentValues contentValues = JS_ChatListModel2ContentValues(obj);
                numberOfRowsAffected = db.update(TB_NAME_CHATLIST, contentValues, updateClause, updateClauseParamStrings);
            }


            if(numberOfRowsAffected > 0) {
                flag = true;
            }
        }

        queryCursor.close();
        closeDataBase();
        return flag;
    }

    /**
     * 获取患者对应的免打扰状态标识值
     * @param patientId 患者ID
     * @return 患者对应的免打扰状态标识值（true：免打扰，false：取消免打扰）
     */
    public boolean getPatientSilentStatus(String patientId) {
        if(null == patientId || patientId.trim().length() == 0 || "null".equalsIgnoreCase(patientId.trim())) {
            closeDataBase();
            return false;
        }

        // 患者对应的免打扰状态标识值（true：免打扰，false：取消免打扰，默认值：false）
        boolean silentStatus = false;

        String[] columns = new String[]{F_IS_SHIELD};
        String selection = F_PATIENT_ID + "=?";
        String[] selectionArgs = new String[]{patientId};
        Cursor cursor = db.query(TB_NAME_CHATLIST, columns, selection, selectionArgs, null, null, null);
        boolean flag = cursor.moveToNext();
        if(flag) {
            // 患者信息提醒是否被屏蔽标示（"0":不屏蔽，"1"：屏蔽）
            String strSilentStatus = cursor.getString(cursor.getColumnIndex(F_IS_SHIELD));
            if("1".equals(strSilentStatus)) {
                silentStatus = true;
            }else {
                silentStatus = false;
            }
        }

        cursor.close();
        closeDataBase();
        return silentStatus;
    }

    /**
     * 更新患者备注名
     * @param obj (需要patientId,remarkName)
     */
    public void updatePatientRemarkName(JS_ChatListModel obj) {
        try {
            // 这里直接连一次库更新，不用先查是否存在
            ContentValues contentValues = new ContentValues();
            contentValues.put(F_PATIENT_MEMO_NAME, obj.getUserPatient().getPatientMemoName()); // 备注名
            String whereClause = F_PATIENT_ID + "=?";
            String[] whereArgs = new String[]{obj.getUserPatient().getPatientId()};
            db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
        } catch (Exception e) {

        } finally {
            closeDataBase();
        }
    }


    /**
     * add by cyr on 2017-3-7  在患者详细信息页更新下当前患者的数据库信息
     * 更新患者信息（姓名、年龄、性别、图文咨询价格、城市（此处暂不处理））
     * @param obj 传入的参数
     */
    public void updatePatientInfo(XC_ChatModel obj) {
        try {
            ContentValues contentValues = new ContentValues();
            UserPatient userPatient = obj.getUserPatient();
            contentValues.put(F_PATIENT_NAME, userPatient.getPatientName());
            contentValues.put(F_PATIENT_AGE, userPatient.getPatientAge());
            contentValues.put(F_PATIENT_GENDER, userPatient.getPatientGender());
            contentValues.put(F_BACK1, userPatient.getPayAmount());
            //add by wangyong 添加患者备注名、手机号、城市 20170614
            contentValues.put(F_PATIENT_MEMO_NAME, userPatient.getPatientMemoName());
            contentValues.put(F_BACK7, userPatient.getPatientPhone());
            contentValues.put(F_PATIENT_CITY_NAME, userPatient.getCityName());
            //add by wangyong 添加患者备注名、手机号、城市 20170614
            String whereClause = F_PATIENT_ID + "=?";
            String[] whereArgs = new String[]{userPatient.getPatientId()};
            db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
        } catch (Exception e) {

        } finally {
            closeDataBase();
        }
    }

    /**
     * add by mym on 2017-3-31
     * 更新关闭收费通知的时间
     */
    public void updateTitleTipCloseTime(XC_ChatModel obj) {
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put(F_BACK3, obj.getTitleTipCloseTime());
            String whereClause = F_PATIENT_ID + "=?";
            String[] whereArgs = new String[]{obj.getUserPatient().getPatientId()};
            db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeDataBase();
        }
    }
    /**
     * add by mym on 2017-5-09
     * 更新撤销消息的model
     */
    public void updateCancelStatus(XC_ChatModel obj) {

        JS_ChatListModel chatListModel = getPatientInfo(obj.getUserPatient().getPatientId());
//        if (UtilString.isBlank(obj.getMsgUnique()) && UtilString.isBlank(chatListModel.getMsgUnique())){
//            //假如两条消息为空，则不更新首页的列表
//            return;
//        }
        if (!obj.getMsgUnique().equals(chatListModel.getMsgUnique())){
            //假如两条消息不一致，则不更新首页的列表
            return;
        }
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put(F_BACK5, obj.getCancelFlag());
            String whereClause = F_PATIENT_ID + "=?";
            String[] whereArgs = new String[]{obj.getUserPatient().getPatientId()};
            db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeDataBase();
        }
    }

    /**
     * 修改数据库中患者的咨询价格
     * @param chatModels 所有的患者数据
     */
    public void updatePatientPayAmount(List<XC_ChatModel> chatModels) {
        try {
            db.beginTransaction();
            for (XC_ChatModel chatModel : chatModels){
                ContentValues contentValues = new ContentValues();
                contentValues.put(F_BACK1, chatModel.getUserPatient().getPayAmount());
                String whereClause = F_PATIENT_ID + "=?";
                String[] whereArgs = new String[]{chatModel.getUserPatient().getPatientId()};
                db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.endTransaction();
            closeDataBase();
        }
    }

    /**
     * 修改数据库中患者的咨询价格
     * @param chatModels 所有的患者数据
     */
    public void updatePatientConsultPayType(XC_ChatModel chatModels) {
        if (UtilString.isBlank(chatModels.getUserPatient().getConsultPayType())){
            return;//如果传进来的数据为空则不再进行插入
        }
        try {
            db.beginTransaction();
            ContentValues contentValues = new ContentValues();
            contentValues.put(F_BACK4, chatModels.getUserPatient().getConsultPayType());
            String whereClause = F_PATIENT_ID + "=?";
            String[] whereArgs = new String[]{chatModels.getUserPatient().getPatientId()};
            db.update(TB_NAME_CHATLIST, contentValues, whereClause, whereArgs);
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.endTransaction();
            closeDataBase();
        }
    }
    /**
     * 修改数据库中患者的咨询价格
     * @param chatModels 所有的患者数据
     */
    public void updatePatientPayAmount2(List<XC_ChatModel> chatModels) {
        try {

            String sql = "update " + TB_NAME_CHATLIST
                    + " set " + F_PATIENT_IMG_HEAD
                    + "=?, " + F_PATIENT_NAME
                    + "=?, " + F_PATIENT_MEMO_NAME
                    + "=?, " + F_PATIENT_NICK_NAME
                    + "=?, " + F_PATIENT_GENDER
                    + "=?, " + F_PATIENT_LETTER
                    + "=?, " + F_PATIENT_AGE
                    + "=?, " + F_IS_SHIELD
                    + "=?, " + F_PATIENT_CITY_NAME
                    + "=?, " + F_IS_ATTENTION
                    + "=?, " + F_DOCTOR_ADD_PATIENT_TIME
                    + "=?, " + F_BACK1
                    + "=? where " + F_PATIENT_ID + " = ?";
            SQLiteStatement sqlListStatment = db.compileStatement(sql);

            db.beginTransaction();
            int size = chatModels.size();
            for (int i = 0; i < size; i++) {
                XC_ChatModel tempObj = chatModels.get(i);
                UserPatient userPatient = tempObj.getUserPatient();
                sqlListStatment.bindString(1, userPatient.getPatientImgHead());
                sqlListStatment.bindString(2, userPatient.getPatientName());
                sqlListStatment.bindString(3, userPatient.getPatientMemoName());
                sqlListStatment.bindString(4, userPatient.getPatientNickName());
                sqlListStatment.bindString(5, userPatient.getPatientGender());
                sqlListStatment.bindString(6, userPatient.getPatientLetter());
                sqlListStatment.bindString(7, userPatient.getPatientAge());
                sqlListStatment.bindString(8, userPatient.getIsShield());
                sqlListStatment.bindString(9, userPatient.getCityName());
                sqlListStatment.bindString(10, userPatient.getIsAttention());
                sqlListStatment.bindString(11, userPatient.getCreateTime());
                sqlListStatment.bindString(12, userPatient.getPayAmount());

                sqlListStatment.bindString(13, userPatient.getPatientId());
                sqlListStatment.executeUpdateDelete();
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.endTransaction();
            closeDataBase();
        }
    }

    /**
     * 逻辑删除指定的会话咨询信息（根据传入的“患者ID”及“每条信息的唯一标示”逻辑删除相匹配的记录）<p>
     * （逻辑删除的标识说明：0:未被逻辑删除；1:已被逻辑删除）<p>
     * 只保留DB记录中以下字段的内容（其他字段的内容清除）：<p>
     * （1）患者id<p>
     * （2）患者头像网络url<p>
     * （3）患者真实名称<p>
     * （4）患者昵称名称<p>
     * （5）患者备注名称<p>
     * （6）患者性别<p>
     * （7）患者名称的分组字母<p>
     * （8）患者年龄<p>
     * （9）屏蔽此患者状态标示（0:不屏蔽；1:屏蔽）<p>
     * （10）特别的消息类型<p>
     * （11）购药咨询id<p>
     * （12）购药咨询信息
     * （13）医生给患者设置的图文咨询价格
     * （14）患者所在城市
     * （15）是否为特别关注患者
     * （16）医生创建患者的时间
     * @param chatListModel 咨询列表项信息BEAN对象
     * @return 操作结果状态标识。true：操作成功，false：操作失败。
     */
    public boolean removeRecord(JS_ChatListModel chatListModel) {
        // 操作结果状态标识（true：操作成功，false：操作失败。默认值：false）
        boolean flag = false;

        // 发送者类型
        String temp_sender = chatListModel.getSender();
        if(null == temp_sender || temp_sender.trim().length() == 0) {
            closeDataBase();
            return false;
        }

        // 患者ID
        String temp_patientId = chatListModel.getUserPatient().getPatientId();
        if(null == temp_patientId || temp_patientId.trim().length() == 0 || "null".equalsIgnoreCase(temp_patientId.trim())) {
            closeDataBase();
            return false;
        }

        // 公告主题id
        String temp_topic = chatListModel.getTopic();
        // 若公告主题id的值不存在，则以患者角色的逻辑进行删除处理
        if(null == temp_topic || temp_topic.trim().length() == 0) {
            String temp_msgUnique = chatListModel.getMsgUnique();
            if(null == temp_msgUnique || "null".equalsIgnoreCase(temp_msgUnique.trim())) {
                temp_msgUnique = "";
            }

            // 查询出旧的记录信息
            String queryClause = F_PATIENT_ID + "=?"; // 查询条件
            String[] queryClauseParamStrings = new String[]{chatListModel.getUserPatient().getPatientId()}; // 查询条件的参数值
            Cursor queryCursor = db.query(TB_NAME_CHATLIST, null, queryClause, queryClauseParamStrings, null, null, null);
            queryCursor.moveToNext();
            JS_ChatListModel oldChatListModelObj = cursor2JS_ChatListModel(queryCursor);
            queryCursor.close();

            // 删除旧记录
            String whereClause = F_PATIENT_ID + "=?" + " and " + F_MSG_UNIQUE + "=?";
            String[] whereArgs = new String[]{temp_patientId, temp_msgUnique};
            db.delete(TB_NAME_CHATLIST, whereClause, whereArgs);

            // 进行插入新记录操作的数据准备
            JS_ChatListModel newChatListModel = new JS_ChatListModel();

            UserPatient newUserPatient = newChatListModel.getUserPatient();
            UserPatient userPatient = oldChatListModelObj.getUserPatient();
            newChatListModel.setDeletedflag(JS_ChatListModel.FLAG_GONE); // 此记录被逻辑删除的标识（0:未被逻辑删除；1:已被逻辑删除）
            newUserPatient.setPatientId(userPatient.getPatientId()); // 患者id
            newUserPatient.setPatientImgHead(userPatient.getPatientImgHead()); // 患者头像网络url
            newUserPatient.setPatientName(userPatient.getPatientName()); // 患者真实名称
            newUserPatient.setPatientNickName(userPatient.getPatientNickName()); // 患者昵称名称
            newUserPatient.setPatientMemoName(userPatient.getPatientMemoName()); // 患者备注名称
            newUserPatient.setPatientGender(userPatient.getPatientGender()); // 患者性别
            newUserPatient.setPatientLetter(userPatient.getPatientLetter()); // 患者名称的分组字母
            newUserPatient.setPatientAge(userPatient.getPatientAge()); // 患者年龄
            newUserPatient.setIsShield(userPatient.getIsShield()); // 屏蔽此患者状态标示（0:不屏蔽；1:屏蔽）
            newUserPatient.setCityName(userPatient.getCityName());//患者所在城市
            newUserPatient.setCreateTime(userPatient.getCreateTime());//医生创建患者时间
            newUserPatient.setIsAttention(userPatient.getIsAttention());//是否为特别关注患者
            newUserPatient.setPayAmount(userPatient.getPayAmount()); // 患者图文咨询的付费价格
            newUserPatient.setConsultPayType(userPatient.getConsultPayType());//患者付费状态
            newChatListModel.setMsgTypeBuyMedicineRequire(oldChatListModelObj.getMsgTypeBuyMedicineRequire()); // 特别的消息类型
            newChatListModel.setRequireId(oldChatListModelObj.getMsgServerId()); // 购药咨询id
            newChatListModel.setBuyMedicineRequireMsg(oldChatListModelObj.getBuyMedicineRequireMsg()); // 购药咨询信息
            ContentValues values = JS_ChatListModel2ContentValues(newChatListModel);

            long rowId = db.insert(TB_NAME_CHATLIST, F_ID, values);
            if(rowId > -1) {
                flag = true;
            }
        }
        // 若公告主题id的值存在，则以通知push角色的逻辑进行物理删除处理
        else {
            String whereClause = F_PATIENT_ID + "=?" + " and " + F_TOPIC + "=?";
            String[] whereArgs = new String[]{temp_patientId, temp_topic};
            int deleteRecordCount = db.delete(TB_NAME_CHATLIST, whereClause, whereArgs);
            if(deleteRecordCount > 0) {
                flag = true;
            }
        }

        closeDataBase();
        return flag;
    }

    /**
     * 插入医生的全部患者信息，处理逻辑为：<p>
     * 1.若表中没有任何患者的信息，则进行全部信息的插入操作；<p>
     * 2.若表中有患者的信息，则对每条患者信息判断是“插入”还是“更新”还是“不必入库”：<p>
     * 　一次性将数据库里的数据全部取出放入内存，然后在内存中进行信息比较：<p>
     * （1）若无此患者的信息，则进行插入操作；<p>
     * （2）若有此患者的信息，且“患者图像”,“患者名称”,“患者性别(0男1女)”,“患者年龄”,“屏蔽此患者消息的状态标示”不都相同，则进行更新操作
     * 　　（更新规则为：只更新“患者id”,“患者图像”,“患者名称”,“患者性别(0男1女)”,“患者年龄”,“屏蔽此患者消息的状态标示”字段，其他字段不更新）<p>
     * （3）若有此患者的信息，且“患者图像”,“患者名称”,“患者性别(0男1女)”,“患者年龄”,“屏蔽此患者消息的状态标示”都相同，则不必入库
     *
     * update by cyr on 2017-3-29 在2规则的基础上，增加
     *
     * @param patientInfoList 患者信息列表对象
     * @return 操作结果状态标示（true：操作成功，false：操作失败）
     */
    public void insertAllChatInfo(ArrayList<XC_ChatModel> patientInfoList) {
        if (null == patientInfoList || patientInfoList.size() == 0) {
            closeDataBase();
            return;
        }

        String[] columns = new String[]{"COUNT(*)"};
        Cursor queryCountCursor = db.query(TB_NAME_CHATLIST, columns, null, null, null, null, null);
        queryCountCursor.moveToNext();
        int recordCount = queryCountCursor.getInt(0);
        queryCountCursor.close();

        if (0 == recordCount) {
            // 表中无数据，进行全部信息的插入操作
            int size = patientInfoList.size();

            db.beginTransaction();
            try {
                for (int i = 0; i < size; i++) {
                    XC_ChatModel tempObj = patientInfoList.get(i);
                    if (null != tempObj) {
                        ContentValues values = XC_ChatModel2ContentValues(tempObj);
                        db.insert(TB_NAME_CHATLIST, F_ID, values);
                    }
                }
                db.setTransactionSuccessful();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                db.endTransaction();
            }

        } else {
            // 优化算法：优化判断本条患者记录是进行插入操作还是进行更新操作还是不必入库操作的代码
            // 一次性将数据库里的数据全部取出放入内存，然后在内存中进行信息比较，判断出每条记录是“插入”还是“更新”还是“不必入库”
            // （1）若无此患者的信息，则进行插入操作；
            // （2）若有此患者的信息，且“患者图像”,“患者名称”,“患者性别(0男1女)”,“患者年龄”,“屏蔽此患者消息的状态标示”,“患者所在城市”,“此患者是否为医生的特别关注患者”,“医生添加患者的时间点”，“图文咨询金额”不都相同，则进行更新操作
            //      （更新规则为：只更新“患者id”,“患者图像”,“患者名称”,“患者性别(0男1女)”,“患者年龄”,“屏蔽此患者消息的状态标示”,“患者所在城市”,“此患者是否为医生的特别关注患者”,“医生添加患者的时间点”，“图文咨询金额”字段，其他字段不更新）
            // （3）若有此患者的信息，且(2)中字段都相同，则不必入库
            int size = patientInfoList.size();
            ArrayList<JS_ChatListModel> dataSetListObj = new ArrayList<>(); // 数据库中原有的全部记录
            int size_dataSetListObj = dataSetListObj.size();

//                db.beginTransaction();
            try {
                for (int i = 0; i < size; i++) {

                    XC_ChatModel tempObj = patientInfoList.get(i);
                    if (null != tempObj) {
                        if (0 == size_dataSetListObj) {
                            Cursor cursor_AllRecord = db.query(TB_NAME_CHATLIST, null, null, null, null, null, null);
                            while (cursor_AllRecord.moveToNext()) {
                                JS_ChatListModel dataSetObj = cursor2JS_ChatListModel(cursor_AllRecord);
                                dataSetListObj.add(dataSetObj);
                            }
                            cursor_AllRecord.close();
                            size_dataSetListObj = dataSetListObj.size();
                        }

                        // 数据库中是否有与此Bean对象的“患者ID”值相同记录的标识（true：有此记录；false：无此记录；默认值：false）
                        boolean hasTheRecordFlag = false;

                        String patientId_fromBean = tempObj.getUserPatient().getPatientId();
                        for (int j = 0; j < size_dataSetListObj; j++) {
                            JS_ChatListModel tempObj_DB = dataSetListObj.get(j);
                            String patientId_fromDB = tempObj_DB.getUserPatient().getPatientId();

                            // 如果数据库里有相同“患者ID”的记录，则判断对Bean对象是进行“更新”操作还是进行“插入”操作
                            if (patientId_fromBean.equals(patientId_fromDB)) {
                                // 设置数据库中是否有与此Bean对象的“患者ID”值相同记录的标识（true：有此记录；false：无此记录；默认值：false）
                                hasTheRecordFlag = true;

                                // “患者图像”,“患者名称”,“患者性别(0男1女)”,“患者年龄”,“屏蔽此患者消息的状态标示”,“患者所在城市”,“此患者是否为医生的特别关注患者”,“医生添加患者的时间点”，“图文咨询金额”都相同则不必入库
                                if (tempObj_DB.equalsObj(tempObj)) {
                                    // do nothing
                                }
                                // “患者图像”,“患者名称”,“患者性别(0男1女)”,“患者年龄”,“患者所在城市”,“此患者是否为医生的特别关注患者”,“医生添加患者的时间点”，“屏蔽此患者消息的状态标示”，“图文咨询金额”不都相同则进行更新操作
                                else {
                                    // 将本条数据更新数据库
                                    ContentValues values = new ContentValues();
                                    values.put(F_PATIENT_ID, tempObj.getUserPatient().getPatientId()); // 患者id
                                    values.put(F_PATIENT_IMG_HEAD, tempObj.getUserPatient().getPatientImgHead()); // 患者图像
                                    values.put(F_PATIENT_NAME, tempObj.getUserPatient().getPatientName()); // 患者名称
                                    values.put(F_PATIENT_GENDER, tempObj.getUserPatient().getPatientGender()); // 患者性别
                                    values.put(F_PATIENT_AGE, tempObj.getUserPatient().getPatientAge()); // 患者年龄
                                    values.put(F_IS_SHIELD, tempObj.getUserPatient().getIsShield()); // 屏蔽此患者消息的状态标示
                                    values.put(F_PATIENT_CITY_NAME, tempObj.getUserPatient().getCityName()); // 患者所在地区（格式为：省名 市名）
                                    values.put(F_IS_ATTENTION, tempObj.getUserPatient().getIsAttention()); // 此患者是否为医生的特别关注患者（true：是；false：否；默认值：false）
                                    values.put(F_DOCTOR_ADD_PATIENT_TIME, tempObj.getUserPatient().getCreateTime()); // 医生添加患者的时间点
                                    values.put(F_BACK1, tempObj.getUserPatient().getPayAmount()); // 医生给患者患者设置的图文咨询价格
                                    String whereClause = F_PATIENT_ID + "=?";
                                    String[] whereArgs = new String[]{tempObj.getUserPatient().getPatientId()};
                                    db.update(TB_NAME_CHATLIST, values, whereClause, whereArgs);

                                }

                                break;
                            }
                        }

                        if (!hasTheRecordFlag) {

                            // 将本条数据插入数据库
                            ContentValues values = XC_ChatModel2ContentValues(tempObj);
                            db.insert(TB_NAME_CHATLIST, F_ID, values);

                        }
                    }
                }

//                        db.setTransactionSuccessful();
            } catch (Exception e) {
                e.printStackTrace();
            }
//            finally {
//                    db.endTransaction();
//            }
        }

        closeDataBase();
    }

    /**
     * 物理删除咨询列表中所有的记录
     * @return 被删除的记录条数
     */
    public int removeAllRecord() {
        int raw = db.delete(TB_NAME_CHATLIST, null, null);
        closeDataBase();

        return raw;
    }


    /**
     * add by cyr on 2018/6/6
     * 删除重复患者，只保留F_ID字段值最大的记录
     * */
    public void deleteRepeatPatient() {
      String sql = "delete from "+TB_NAME_CHATLIST+" where "+F_ID
              +" not in (select maxid from (select max("+F_ID+") as maxid from "
              + TB_NAME_CHATLIST+" group by "+F_PATIENT_ID+"))";
        db.execSQL(sql);
        closeDataBase();
    }
    /**
     * 根据患者ID删除患者
     * */
    public int delPatientByPatientId(String patientId){
        String whereClause = F_PATIENT_ID + "=?";
        String[] whereArgs = new String[]{patientId};
        int raw = db.delete(TB_NAME_CHATLIST, whereClause, whereArgs);
        closeDataBase();
        return raw;
    }

}
