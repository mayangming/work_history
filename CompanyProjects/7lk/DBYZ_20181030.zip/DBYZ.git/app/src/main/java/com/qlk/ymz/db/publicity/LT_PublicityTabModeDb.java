package com.qlk.ymz.db.publicity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.qlk.ymz.parse.Parse2PublictyTabBean;
import com.qlk.ymz.util.SP.UtilSP;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 李涛
 * @description 有关宣教的sqlite
 * @Date 2018/3/21.
 */


public class LT_PublicityTabModeDb   extends SQLiteOpenHelper{

    /**数据库名*/
    public static  final String SQLITE_NAME = "qlk_lt_pub_sqlite3";
    /**数据库表格名  tab  和医生关联*/
    public static final String SQLITE_TABLE_NAME = "lt_pub_table3";
    public static final   int DB_VERSION = 1;
    /**数据库ID*/
    public String _ID = "id";
    /**滑动标题tab*/
    public String PUB_TAB_NAME = "label";
    public String PUB_TAB_ID = "labelid";
    public String PUB_TAB_LABELLIST = "labelList";
    /**患者ID*/
    private String PATIENT_ID = "patientID";
    private  String mTaleName;
    private Cursor c;
    private long id;
    private String labelStr;
    private int raw;



    public LT_PublicityTabModeDb(Context context, String name, SQLiteDatabase.CursorFactory factory,String mTaleName) {
        super(context, name, factory, DB_VERSION);
        if (UtilString.isBlank(name)) {
            throw new RuntimeException("宣教数据库名不能为空-------》LT_PublicityTabModeDb");
        }
        this.mTaleName = mTaleName;
    }

    /**
     * 删除表格
     */
    public int deleteTable() {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put("seq","0");
            db.update("sqlite_sequence",values,"name = ?",new String[]{SQLITE_TABLE_NAME});
            raw = db.delete(mTaleName, null, null);
            db.setTransactionSuccessful();
        }catch (Exception e){
            Log.e("slite","宣教数据库删除失败");
        }finally {
            db.endTransaction();
            db.close();
        }

        return raw;
    }



    /**
     * 插入一条记录
     *
     * @param
     */
    public long insert(String patientID, ArrayList<Parse2PublictyTabBean> insertData){
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        JSONArray jsonArray = new JSONArray();

            try {
                for (int i=0;i<insertData.size();i++){
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(PUB_TAB_NAME,insertData.get(i).getLabel());
                    jsonObject.put(PUB_TAB_ID,insertData.get(i).getId());
                    jsonArray.put(jsonObject);
                }
                ContentValues values = new ContentValues();
                values.put(PATIENT_ID,patientID);
                values.put(PUB_TAB_LABELLIST,jsonArray.toString());
                id = db.insert(mTaleName, _ID, values);
                db.setTransactionSuccessful();

            } catch (JSONException e) {
                e.printStackTrace();
            }finally {
                db.endTransaction();
                db.close();
            }

        return id;
    }


    /**
     * 根据患者ID查询
     *第一条数据是默认的
     * @param id 患者ID/或者是第一个数据 _ID = 0
     */
    public  ArrayList<Parse2PublictyTabBean> queryForPatientID(String id)   {
        ArrayList<Parse2PublictyTabBean> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        if("1".equals(id)){
            c = db.query(mTaleName, null, _ID + "=?", new String[]{id}, null, null, null);
        }else{
            c = db.query(mTaleName, null, PATIENT_ID + "=?", new String[]{id}, null, null, null);
        }
        while (c.moveToNext()) {
            labelStr = c.getString(c.getColumnIndex(PUB_TAB_LABELLIST));
            JSONArray jsonArray = null;
            try {
                jsonArray = new JSONArray(labelStr.toString());
                for (int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject  = jsonArray.getJSONObject(i);
                    Parse2PublictyTabBean bean = new Parse2PublictyTabBean();
                    bean.setLabel(jsonObject.getString(PUB_TAB_NAME));
                    bean.setId(jsonObject.getString(PUB_TAB_ID));
                    list.add(bean);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }finally {
                c.close();
                db.close();
            }
        }


        return list;
    }


    /**
     * 更新记录
     *
     * @param
     */
    public long update( String patientID, ArrayList<Parse2PublictyTabBean> updateData) {
            SQLiteDatabase db = getWritableDatabase();
            db.beginTransaction();
              JSONArray jsonArray = new JSONArray();
            try {
                for (int i=0;i<updateData.size();i++){
                JSONObject jsonObject = new JSONObject();
                jsonObject.put(PUB_TAB_NAME,updateData.get(i).getLabel());
                jsonObject.put(PUB_TAB_ID,updateData.get(i).getId());
                jsonArray.put(jsonObject);
            }
                ContentValues values = new ContentValues();
                values.put(PATIENT_ID,patientID);
                values.put(PUB_TAB_LABELLIST,jsonArray.toString());
                db.update(mTaleName,values,PATIENT_ID+"= ?",new String[]{patientID});
                db.setTransactionSuccessful();
            } catch (JSONException e) {
                e.printStackTrace();
            }finally {
                db.endTransaction();
                db.close();
            }
        return id;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + SQLITE_TABLE_NAME
                + "(" + _ID + " integer primary key autoincrement, "
                + PATIENT_ID+ " text, "
                + PUB_TAB_LABELLIST + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if(newVersion != oldVersion){
            db.execSQL("drop table if exists " + SQLITE_TABLE_NAME);
        }
    }
}
