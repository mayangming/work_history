package com.qlk.ymz.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * Created by xiedong on 2018/10/29.
 */

public class RecipeDetailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context context;
    private View headView;
    private View footView;
    private List<DrugBean> mDrugBeans;

    public RecipeDetailAdapter(Context context,List<DrugBean> list){
        this.context = context;
        this.mDrugBeans = list;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(1==viewType){
            return new HeadHolder(headView);
        }else if (2==viewType){
            return new HeadHolder(footView);
        }
        View view = LayoutInflater.from(context).inflate(R.layout.sk_item_prescription_detail, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if(position ==0 || position ==mDrugBeans.size()+1){
            return;
        }
        ViewHolder viewHolder = (ViewHolder) holder;
        final DrugBean drugBean = mDrugBeans.get(position-1);
        String note = drugBean.getMedicineUsageBean().getBakUp();
        if(TextUtils.isEmpty(note)){ // 备注为空
            viewHolder.tv_item_prescription_drugUsage.setText("用法："+ drugBean.getMedicineUsageBean().getUsages());

        }else{ // 备注不为空
            if(TextUtils.isEmpty(drugBean.getMedicineUsageBean().getUsages())){ // 用法用量为空
                viewHolder.tv_item_prescription_drugUsage.setText("用法："+ note);
            }else {
                viewHolder.tv_item_prescription_drugUsage.setText("用法："+drugBean.getMedicineUsageBean().getUsages() + "," + note);
            }
        }

        viewHolder.tv_item_prescription_drugName.setText(drugBean.getRecomName());
        viewHolder.tv_item_prescription_drugNum.setText("×" + drugBean.getMedicineUsageBean()
                .getQuantity()+ (TextUtils.isEmpty(drugBean.getMedicineUsageBean().getQuantityUnit())?"":drugBean.getMedicineUsageBean()
                .getQuantityUnit()));

        if(position == mDrugBeans.size()){
            viewHolder.v_line.setVisibility(View.GONE);
        } else {
            viewHolder.v_line.setVisibility(View.VISIBLE);
        }

        if (!UtilString.isBlank(drugBean.getExpireDesc())){
            viewHolder.tv_medicine_limit_time.setVisibility(View.VISIBLE);
            viewHolder.tv_medicine_limit_time.setText(drugBean.getExpireDesc());
        }else {
            viewHolder.tv_medicine_limit_time.setVisibility(View.GONE);
        }

        viewHolder.rl_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UtilNativeHtml5.toJumpDrugDetail(context, drugBean.getId());
            }
        });

    }

    public void setData(List<DrugBean> list){
        this.mDrugBeans = list;
    }

    @Override
    public int getItemCount() {
        if(mDrugBeans!=null){
            return mDrugBeans.size()+2;
        }else {
            return 0;
        }
    }

    public void addHeadView(View view){
        this.headView = view;
    }
    public void addFootView(View view){this.footView = view;}
    @Override
    public int getItemViewType(int position) {
        if(position ==0){
            return 1;
        }else if(position ==mDrugBeans.size()+1){
            return 2;
        }
        return super.getItemViewType(position);
    }


    class HeadHolder extends RecyclerView.ViewHolder{
        public HeadHolder(View itemView) {
            super(itemView);
        }
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private View rl_item;
        private TextView tv_item_prescription_drugName;
        private TextView tv_item_prescription_drugNum;
        private TextView tv_item_prescription_drugUsage;
        private TextView tv_item_safe_dosage;
        private TextView tv_medicine_limit_time;
        private View v_line;

        public ViewHolder(View itemView) {
            super(itemView);
            rl_item = itemView.findViewById(R.id.rl_item);
            tv_item_prescription_drugName = (TextView)itemView.findViewById(R.id.tv_item_prescription_drugName);
            tv_item_prescription_drugNum = (TextView)itemView.findViewById(R.id.tv_item_prescription_drugNum);
            tv_item_prescription_drugUsage = (TextView)itemView.findViewById(R.id.tv_item_prescription_drugUsage);
            tv_item_safe_dosage = itemView.findViewById(R.id.tv_item_safe_dosage);
            tv_medicine_limit_time = (TextView)itemView.findViewById(R.id.tv_medicine_limit_time);
            v_line = itemView.findViewById(R.id.v_line);
        }
    }
}
