package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 病历详情，有查看处方和需方的操作
 */
public class XC_ChatRighMedicalRecordHolder extends XC_ChatRightBaseHolder {

    public LinearLayout sk_id_medical_rl;
    public TextView details;

    public TextView medical_record_name;//病历详情的患者姓名、性别、年龄信息
    public TextView medical_record_main_complaint;//主诉
    public TextView medical_record_diagnosis;//诊断
    public TextView medical_record_doctor_advice;//医嘱小结
    public LinearLayout medical_record_operation;//查看处方和续房的操作

    public ImageView check_img;
    public TextView check_text;
    public LinearLayout check_layout;
    public TextView id_right_patient_medicine_show;
    public TextView id_right_patient_medicine_recommend_again;
    public TextView medicine_invalid_tv;
    public XC_ChatRighMedicalRecordHolder(View convertView) {
        super(convertView);
        sk_id_medical_rl = (LinearLayout) convertView.findViewById(R.id.sk_id_medical_rl);
        details = (TextView) convertView.findViewById(R.id.details);
        medical_record_name = (TextView) convertView.findViewById(R.id.medical_record_name);
        medical_record_main_complaint = (TextView) convertView.findViewById(R.id.medical_record_main_complaint);
        medical_record_diagnosis = (TextView) convertView.findViewById(R.id.medical_record_diagnosis);
        medical_record_doctor_advice = (TextView) convertView.findViewById(R.id.medical_record_doctor_advice);
        medical_record_operation = (LinearLayout) convertView.findViewById(R.id.medical_record_operation);

        check_img = (ImageView) convertView.findViewById(R.id.check_img);
        check_text = (TextView) convertView.findViewById(R.id.check_text);
        check_layout = (LinearLayout) convertView.findViewById(R.id.check_layout);
        id_right_patient_medicine_show = (TextView) convertView.findViewById(R.id.id_right_patient_medicine_show);
        id_right_patient_medicine_recommend_again = (TextView) convertView.findViewById(R.id.id_right_patient_medicine_recommend_again);
        medicine_invalid_tv = (TextView) convertView.findViewById(R.id.medical_invalid_tv);
    }
}