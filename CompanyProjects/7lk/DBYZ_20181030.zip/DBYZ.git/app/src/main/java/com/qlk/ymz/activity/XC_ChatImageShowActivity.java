package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.UtilChatPhoto;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCIMMenuDialog;
import com.qlk.ymz.view.zoomimageview.XCViewPagerFragment;
import com.qlk.ymz.view.zoomimageview.XCZoomImageView;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jingyu.
 *
 * @version 1.0
 * @description 聊天页中的图片展示
 * <p/>
 * update by cyr on 2016-3-9
 * 添加了点击图片位置参数
 */
public class XC_ChatImageShowActivity extends DBActivity {
    /** title中间文字 */
    TextView xc_id_titlebar_center_textview;
    /**
     * 上一个界面传递过来数据的key值
     */
    public static String PICTURES_KEY = "picture";
    /**
     * 点击的图片位置
     */
    public static String INDEX = "index";

    public static String IS_SHOW_TITLE = "isShowTile";
    public static String TITLE_NAME = "titleName";

    private XCIMMenuDialog dialog;

    private ArrayList<String> urls;

    private boolean isShowTitle = false;

    private String titleName = "";

    //传入图片的位置
    private int imageIndex;

    public static final String SAVE_PHOTO = "保存图片";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xc_l_activity_chat_images_show);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XC_ChatImageShowActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        xc_id_titlebar_center_textview = getViewById(R.id.xc_id_titlebar_center_textview);
        isShowTitle = getIntent().getBooleanExtra(IS_SHOW_TITLE,false);
        if(isShowTitle){
            xc_id_titlebar_center_textview.setVisibility(View.VISIBLE);
            titleName = getIntent().getStringExtra(TITLE_NAME);
            xc_id_titlebar_center_textview.setText(titleName);
        }else {
            xc_id_titlebar_center_textview.setVisibility(View.GONE);
        }
        urls = getIntent().getStringArrayListExtra(PICTURES_KEY);
        imageIndex = getIntent().getIntExtra(INDEX, 0);

        XCViewPagerFragment fragment = new XCViewPagerFragment();
        fragment.setData(urls);
        fragment.setDefaultSelectedIndex(imageIndex);
        fragment.setOnLoadImageListener(new XCViewPagerFragment.OnLoadImage() {
            @Override
            public void onLoadImage(final ImageView imageview, String url) {
                XCApplication.displayImage(url, imageview, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_photo_default));

                if (imageview instanceof XCZoomImageView) {
                    //设置长按事件
                    ((XCZoomImageView) imageview).setOnLongPressListener(new XCZoomImageView.OnLongPressListener() {
                        @Override
                        public void onLongPress() {
                            if (dialog == null) {
                                dialog = new XCIMMenuDialog(XC_ChatImageShowActivity.this);
                                dialog.update("", new String[]{SAVE_PHOTO});
                            }

                            dialog.setOnDialogItemClickListener(new XCIMMenuDialog.OnDialogItemClickListener() {
                                @Override
                                public void onClick(View view, String hint) {
                                    if (SAVE_PHOTO.equals(hint)) {
                                        Integer position = (Integer) (imageview.getTag());
                                        UtilChatPhoto.saveFileToSystem(XC_ChatImageShowActivity.this, urls.get(position));
                                    }
                                    shortToast("已保存到系统相册");
                                    dialog.cancel();
                                }
                            });
                            dialog.show();
                        }
                    });

                    imageview.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            XC_ChatImageShowActivity.this.myFinish();
                            closeAnimation();
                        }
                    });
                }

            }
        });

        addFragment(R.id.xc_id_images_show, fragment);
    }

    @Override
    public void showPage() {
        showTitleLayout(false);
        showContentLayout();
    }

    @Override
    public void listeners() {

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        closeAnimation();
    }

    /**
     * 关闭activity动画
     */
    public void closeAnimation(){
        //jira3702 与设计沟通，优化体验，所有进入大图片都进行直接打开、直接关闭，不做移动关闭。后期做仿微信的获取原图位置的放大缩小式打开/关闭。
        overridePendingTransition(0,0);
    }
    /**
     * 打开大图片
     * @param context
     * @param index 图片索引
     * @param picList 图片地址list
     */
    public static void showPic(Context context, int index, List<String> picList) {
        Intent intent = new Intent(context, XC_ChatImageShowActivity.class);
        intent.putExtra(XC_ChatImageShowActivity.PICTURES_KEY, (Serializable)picList);
        intent.putExtra(XC_ChatImageShowActivity.INDEX, index);
        context.startActivity(intent);
        ((Activity)context).overridePendingTransition(0,0);
    }

}
