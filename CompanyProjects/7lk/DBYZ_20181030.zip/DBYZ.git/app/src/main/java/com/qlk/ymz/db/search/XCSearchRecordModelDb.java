package com.qlk.ymz.db.search;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jingyu on 2015/6/22.
 *
 * @version 1.0
 * @description 搜索记录的数据库
 */
public class XCSearchRecordModelDb extends SQLiteOpenHelper {

    public String mDbName;
    public int mVersion;
    public String mOperatorTableName;
    /**
     * 存储历史版本号
     */
    private ArrayList<Integer> versionList = new ArrayList<>();
    /**
     * 存储表名
     */
    private ArrayList<String> tabNameList = new ArrayList<>();
    /**
     * 排序常量 降序
     */
    public static String SORT_DESC = " DESC";//here
    /**
     * 排序常量 升序
     */
    public static String SORT_ASC = " ASC";

    /**
     * 以下是表字段 id
     */
    public static final String _ID = "_id";
    /**
     * 以下是表字段 关键词
     */
    public static final String KEY_WORD = "key_word";
    /**
     * 以下是表字段 搜索时间
     */
    public static final String TIME = "time";

    /**
     * 默认的搜索历史记录数据表
     */
    public static final String SEARCH_RECORD_INFO = "search_record_info";
    /**
     * 我的药房--搜索药品历史记录数据表
     */
    public static final String SEARCH_RECORD_INFO1 = "search_record_info1";
    /**
     * 推荐用药--搜索药品历史记录数据表
     */
    public static final String SEARCH_RECORD_INFO2 = "search_record_info2";
    /**
     * 个人信息--医院搜索历史记录数据表
     */
    public static final String SEARCH_RECORD_INFO3 = "search_record_info3";
    /**
     * 联系人检索历史 add by xilinch 20160329
     */
    public static final String SEARCH_RECORD_INFO4 = "search_record_info4";

    /**
     * 宣教页面搜索
     **/
    public static final String SEARCH_RECORD_INFO5 = "search_record_info5";

    /**
     * 搜索数据库名
     */
    public static final String SEARCH_DB_NAME = "qlk_wyd_search_record.db";
    /**
     * 搜索数据库版本信息
     */
    public static final int SEARCH_DB_VERSION = 13; // edit by xjs on 20151216  edit 11 by xilinch on 20160330

    /***
     * 临时表名
     */
    private static String TEMP_TABLE_NAME = "temp_" + SEARCH_RECORD_INFO;
    /**
     * 多出字段时数据单引号的拼接
     */
    private StringBuilder builder = new StringBuilder();

    public XCSearchRecordModelDb(Context context, String dbName, int version, String operatorTableName) {
        super(context, dbName, null, version);
        //添加当前的数据库版本
        addVersion();
        if (UtilString.isBlank(dbName)) {
            throw new RuntimeException("数据库名不能为空");
        }

        if (operatorTableName == null || operatorTableName.length() < 1) {
            mOperatorTableName = SEARCH_RECORD_INFO;
        } else {
            mOperatorTableName = operatorTableName;

        }
        mDbName = dbName;
        mVersion = version;
    }

    /**
     * 添加历史版本号用作数据库升级
     */
    private void addVersion() {

        //添加历史版本 当前版本升级也要添加
        versionList.add(12);
        versionList.add(13);

        //这里添加所有的数据库表名，如果没有历史版本会做删除表格重写创建
        tabNameList.add(SEARCH_RECORD_INFO);
        tabNameList.add(SEARCH_RECORD_INFO1);
        tabNameList.add(SEARCH_RECORD_INFO2);
        tabNameList.add(SEARCH_RECORD_INFO3);
        tabNameList.add(SEARCH_RECORD_INFO4);
        tabNameList.add(SEARCH_RECORD_INFO5);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS  " + SEARCH_RECORD_INFO
                + "(" + _ID + " integer primary key autoincrement,"
                + KEY_WORD + " text, "
                + TIME + " text)");
        db.execSQL("CREATE TABLE IF NOT EXISTS  " + SEARCH_RECORD_INFO1
                + "(" + _ID + " integer primary key autoincrement,"
                + KEY_WORD + " text, "
                + TIME + " text)");
        db.execSQL("CREATE TABLE IF NOT EXISTS  " + SEARCH_RECORD_INFO2
                + "(" + _ID + " integer primary key autoincrement,"
                + KEY_WORD + " text, "
                + TIME + " text)");
        db.execSQL("CREATE TABLE IF NOT EXISTS  " + SEARCH_RECORD_INFO3
                + "(" + _ID + " integer primary key autoincrement,"
                + KEY_WORD + " text, "
                + TIME + " text)");
        db.execSQL("CREATE TABLE IF NOT EXISTS  " + SEARCH_RECORD_INFO4
                + "(" + _ID + " integer primary key autoincrement,"
                + KEY_WORD + " text, "
                + TIME + " text)");//add by xilinch 20160330
        db.execSQL("CREATE TABLE IF NOT EXISTS  " + SEARCH_RECORD_INFO5
                + "(" + _ID + " integer primary key autoincrement,"
                + KEY_WORD + " text, "
                + TIME + " text)");//add by litao 2018- 03- 20
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // add by xjs on 20151216 start
        // 修复七乐康医生1.4.0版本升级到1.5.0版本后，使用常用药及推荐用药崩溃问题。

        if (newVersion > oldVersion) {
//            db.execSQL("drop table if exists " + SEARCH_RECORD_INFO);
//            db.execSQL("drop table if exists " + SEARCH_RECORD_INFO1);
//            db.execSQL("drop table if exists " + SEARCH_RECORD_INFO2);
//            db.execSQL("drop table if exists " + SEARCH_RECORD_INFO3);
//            db.execSQL("drop table if exists " + SEARCH_RECORD_INFO4);//add by xilinch 20160330
//            db.execSQL("drop table if exists " + SEARCH_RECORD_INFO5);//add by litao 2018-03-20
//            onCreate(db);
            judgeVersion(db, oldVersion);
        }
    }

    /**
     * 升级版本数据库
     *
     * @param db
     * @param oldVersion
     */
    private void judgeVersion(final SQLiteDatabase db, final int oldVersion) {
                //先判断集合是否存在当前的版本号
                if (versionList.contains(oldVersion)) {
                    //判断当前版本升级从那个版本开始
                    for (int i = (versionList.indexOf(oldVersion) + 1); i < versionList.size(); i++) {
                        switch (versionList.get(i)) {
                            case 13:
                                updateSqlitefor13(db, versionList.get(i));
                                break;
                        }
                    }
                } else {
                    //如果没有记录的历史版本  就删除所有的表格重新创建
                    for (int i = 0; i < tabNameList.size(); i++) {
                        db.execSQL("drop table if exists " + tabNameList.get(i));
                    }
                    onCreate(db);
                }
    }


    /**
     * 每次更新表会有不同的写法
     *
     * @param db
     * @param version 当前数据库的版本
     */
    private void updateSqlitefor13(SQLiteDatabase db, int version) {
            db.beginTransaction();
            UpdateTable(db,version);
            db.setTransactionSuccessful();
            db.endTransaction();
    }


    /***
     * 数据库升级多出字段或者没有变动的情况下
     * @param db
     * @param tableName 当前迁移的表名
     * @param addFields  新添加字段的个数   0表示没有添加的字段  也可用作修改字段的数据类型
     */
    private void updateTableIfAddField(SQLiteDatabase db, String tableName, int addFields, int version) {
        TEMP_TABLE_NAME = "temp_" + tableName;
        try {
            db.execSQL("ALTER TABLE " + tableName + " RENAME TO  " + TEMP_TABLE_NAME + "");
            UpdateTable(db, version);
            if (addFields > 0) {
                for (int i = 1; i <= addFields; i++) {
                    builder.append(" ''".trim());
                    if (i != addFields) {
                        builder.append(",");
                    }
                }
                db.execSQL("INSERT INTO " + tableName + " SELECT *," + builder.toString() + "FROM  " + TEMP_TABLE_NAME + "");
            } else {
                db.execSQL("INSERT INTO " + tableName + " SELECT * FROM  " + TEMP_TABLE_NAME + "");
            }
            db.execSQL("DROP TABLE  " + TEMP_TABLE_NAME + "");

        } catch (SQLiteException e) {
            Log.e("数据库升级失败", "" + e);
        } finally {
            builder.replace(0, builder.length(), "");
        }
    }


    /**
     * 根据相对应的版本号创建相对应的表
     *
     * @param db
     * @param version
     */
    private void UpdateTable(SQLiteDatabase db, int version) {
        switch (version) {
            case 13:
                db.execSQL("CREATE TABLE IF NOT EXISTS  " + SEARCH_RECORD_INFO5
                        + "(" + _ID + " integer primary key autoincrement,"
                        + KEY_WORD + " text, "
                        + TIME + " text)");//add by litao 2018- 03- 20
                break;
        }
//        db.execSQL("CREATE TABLE " + SEARCH_RECORD_INFO
//                + "(" + _ID + " integer primary key autoincrement,"
//                + KEY_WORD + " text, "
//                + TIME + " text)");
//        db.execSQL("CREATE TABLE " + SEARCH_RECORD_INFO1
//                + "(" + _ID + " integer primary key autoincrement,"
//                + KEY_WORD + " text, "
//                + TIME + " text)");
//        db.execSQL("CREATE TABLE " + SEARCH_RECORD_INFO2
//                + "(" + _ID + " integer primary key autoincrement,"
//                + KEY_WORD + " text, "
//                + TIME + " text)");
//        db.execSQL("CREATE TABLE " + SEARCH_RECORD_INFO3
//                + "(" + _ID + " integer primary key autoincrement,"
//                + KEY_WORD + " text, "
//                + TIME + " text)");
//        db.execSQL("CREATE TABLE " + SEARCH_RECORD_INFO4
//                + "(" + _ID + " integer primary key autoincrement,"
//                + KEY_WORD + " text, "
//                + TIME + " text)");//add by xilinch 20160330
//        db.execSQL("CREATE TABLE " + SEARCH_RECORD_INFO5
//                + "(" + _ID + " integer primary key autoincrement,"
//                + KEY_WORD + " text, "
//                + TIME + " text)");//add by litao 2018- 03- 20
    }


    /**
     * 抽取创建contentValue
     *
     * @param model 需要插入数据库的那条的信息
     * @return contentValue实例
     */
    public ContentValues createContentValue(XCSearchRecordModel model) {
        ContentValues values = new ContentValues();
        values.put(KEY_WORD, model.getKey_word());
        values.put(TIME, model.getTime());
        return values;
    }

    /**
     * 从数据库中取出数据
     *
     * @param c 查询游标
     * @return 封装好的消息model
     */
    public XCSearchRecordModel createModel(Cursor c) {
        XCSearchRecordModel model = new XCSearchRecordModel();
        model.setKey_word(c.getString(c.getColumnIndex(KEY_WORD)));
        model.setTime(c.getString(c.getColumnIndex(TIME)));
        return model;
    }

    /**
     * add by xilinch 20160329
     * 如果不存在搜索联系人历史记录数据表则创建
     *
     * @param db      数据库名
     * @param tabName 数据表名
     */
    public void createTabIfNotExist(SQLiteDatabase db, String tabName) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + tabName
                + "(" + _ID + " integer primary key autoincrement,"
                + KEY_WORD + " text, "
                + TIME + " text)");
    }

    /**
     * 插入一条记录
     *
     * @param model 搜索信息的model
     */
    public long insert(XCSearchRecordModel model) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = createContentValue(model);
        long id = db.insert(mOperatorTableName, _ID, values);
        //XCLog.i(XCConfig.TAG_DB, "插入的记录的id是: " + id);
        db.close();
        return id;
    }

    /**
     * 删除所有记录
     */
    public int deleteAll() {
        SQLiteDatabase db = getWritableDatabase();
        int raw = db.delete(mOperatorTableName, null, null);
        db.close();
        return raw;
    }

    /**
     * 根据时间删除记录
     *
     * @param value 时间戳
     */
    public int deleteByTime(String value) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(mOperatorTableName, TIME + "=?", new String[]{value + ""});
        //XCLog.i(XCConfig.TAG_DB, "delete-->" + rows + "行");
        db.close();
        return rows;
    }

    /**
     * 根据关键字，删除记录
     *
     * @param value 关键字
     */
    public int deleteByKeyword(String value) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(mOperatorTableName, KEY_WORD + "=?", new String[]{value + ""});
        //XCLog.i(XCConfig.TAG_DB, "delete-->" + rows + "行");
        db.close();
        return rows;
    }

    /**
     * 查询共有多少条记录
     */
    public int queryCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, new String[]{"COUNT(*)"}, null, null, null, null, null);
        c.moveToNext();
        int count = c.getInt(0);
        c.close();
        db.close();
        return count;
    }

    /**
     * 查询所有
     */
    public List<XCSearchRecordModel> queryAllByDESC() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_DESC); // 条件为null可以查询所有
        List<XCSearchRecordModel> beans = new ArrayList<XCSearchRecordModel>();
        while (c.moveToNext()) {
            XCSearchRecordModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /**
     * 查询所有
     */
    public List<XCSearchRecordModel> queryAllByASC() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_ASC); // 条件为null可以查询所有
        List<XCSearchRecordModel> beans = new ArrayList<XCSearchRecordModel>();
        while (c.moveToNext()) {
            XCSearchRecordModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /**
     * 根据关键字查询
     *
     * @param value 关键字
     */
    public List<XCSearchRecordModel> query(String value) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, KEY_WORD + "=?", new String[]{value}, null, null, null);
        List<XCSearchRecordModel> beans = new ArrayList<XCSearchRecordModel>();
        while (c.moveToNext()) {
            XCSearchRecordModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /**
     * 分页查找
     *
     * @param pageNum  第几页
     * @param capacity 每页查找多少
     */
    public List<XCSearchRecordModel> queryPage(int pageNum, int capacity) {
        String offset = (pageNum - 1) * capacity + ""; // 偏移量
        String len = capacity + ""; // 个数
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, null, offset + "," + len);
        List<XCSearchRecordModel> beans = new ArrayList<XCSearchRecordModel>();
        while (c.moveToNext()) {
            XCSearchRecordModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /**
     * 更新记录
     *
     * @param model 需要更新的model
     * @param value 以时间戳更新
     */
    public int update(XCSearchRecordModel model, String value) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = createContentValue(model);
        int rows = db.update(mOperatorTableName, values, TIME + "=?", new String[]{value + ""});
        //XCLog.i(XCConfig.TAG_DB, "更新了" + rows + "行");
        db.close();
        return rows;
    }
}
