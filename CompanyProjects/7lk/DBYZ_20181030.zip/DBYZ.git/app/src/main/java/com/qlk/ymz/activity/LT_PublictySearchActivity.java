package com.qlk.ymz.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.LT_PublicityAdpter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.db.search.XCSearchRecordModel;
import com.qlk.ymz.db.search.XCSearchRecordModelDb;
import com.qlk.ymz.fragment.SXSearchRecordFragment;
import com.qlk.ymz.parse.Parse2PublicityBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCClearEditText;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;


/**
 * @author 李涛
 * @description   宣教列表搜索页
 * @Date 2018/3/25.
 */
public class LT_PublictySearchActivity extends DBActivity {

    /**取消按钮*/
    private LinearLayout xc_id_titlebar_right2_layout;
    /**搜索框*/
    private XCClearEditText sk_id_search_edit;
    /**数据库操作*/
    private XCSearchRecordModelDb db;
    /**搜索历史列表*/
    private SXSearchRecordFragment recordFragment;
    /**无网络页面*/
    private RelativeLayout lt_put_nonetview;
    /**无网络页面*/
    private LinearLayout lt_no_date;
    /**搜索历史列表父布局*/
    private RelativeLayout lt_pub_model_content;
    /**内容list view*/
    private PullToRefreshListView lvContent;
    private LT_PublicityAdpter publicityAdpter;
    private ArrayList<Parse2PublicityBean> dataList = new ArrayList();
    private Handler delayHandler = new Handler(Looper.getMainLooper());
    /**发送按钮dialog窗口控件*/
    private Dialog sendDialog;
    private TextView sendName;
    private XCRoundedImageView sendHeader;
    private TextView sendUrl;
    private Button sendCancle;
    private Button sendOk;
    /**判断入口*/
    private Intent comeSourec;
    private XC_ChatModel userData;
    /**判断要不要弹窗*/
    private int intentCode = 0;
    /**页面缓存列表点击的数据*/
    Parse2PublicityBean  LocaData;
    /**内容数据 字段*/
    private String  pageNo ="1";  //页数
    private String  nextPage ="1";  //下一页页数
    private String  pageSize = "10"; //页面的条目数
    private String  hasNex; //是否有下一页
    private  String offset= "0";
    private String searchStr;
    private Button netButton;
    private ListView mListView;
    private int isRefrash = 0; //返回上一页0不刷新 1刷新

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lt__publicty_search);
        comeSourec = getIntent();
         intentCode = comeSourec.getIntExtra(LT_PublicityActivity.PUBLICITY_EDUCATION_INTENTCODE,0);
         userData = (XC_ChatModel) comeSourec.getSerializableExtra(LT_PublicityActivity.PATIENT_INFO);
        //初始化数据库
        db = new XCSearchRecordModelDb(this, XCSearchRecordModelDb.SEARCH_DB_NAME,
                XCSearchRecordModelDb.SEARCH_DB_VERSION, XCSearchRecordModelDb.SEARCH_RECORD_INFO5);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(LT_PublictySearchActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void initWidgets() {

        //初始化Title搜索部分
        xc_id_titlebar_right2_layout = (LinearLayout) findViewById(R.id.xc_id_titlebar_right2_layout);
        sk_id_search_edit = (XCClearEditText) findViewById(R.id.sk_id_search_edit);
        sk_id_search_edit.setHint("输入宣教标题、来源搜索");
        sk_id_search_edit.setFocusable(true);
        sk_id_search_edit.requestFocus();
        //添加搜索记录布局
        lt_pub_model_content = (RelativeLayout) findViewById(R.id.lt_pub_model_content);
        //无网络无数据
        lt_no_date = (LinearLayout) findViewById(R.id.lt_no_date);
        TextView id_zero_data_tv = (TextView) findViewById(R.id.id_zero_data_tv);
        id_zero_data_tv.setText("抱歉，没有找到匹配的宣教");
        lt_put_nonetview = (RelativeLayout) findViewById(R.id.lt_put_nonetview);
        netButton = (Button) findViewById(R.id.xc_id_no_net_button);
        //内容listview
        lvContent = (PullToRefreshListView) findViewById(R.id.lv_pub_search_content);
        lvContent.setMode(PullToRefreshBase.Mode.PULL_FROM_END);//设置了只有上拉加载
        mListView = lvContent.getRefreshableView();
        publicityAdpter = new LT_PublicityAdpter(LT_PublictySearchActivity.this, R.layout.lt_item_publicity,R.layout.js_item_action_chat_list,dataList);
        lvContent.setAdapter(publicityAdpter);
        //添加搜索历史列表
        recordFragment = new SXSearchRecordFragment();
        //设置表格名字
        recordFragment.setTabName(XCSearchRecordModelDb.SEARCH_RECORD_INFO5);
        addFragment(R.id.lt_pub_model_content, recordFragment);
        showFragment(recordFragment);
        lvContent.setVisibility(View.GONE);
    }


    @Override
    public void listeners() {
        netButton.setOnClickListener(this);
        //listview内容布局的监听
        publicityAdpter.setOnViewClick(new LT_PublicityAdpter.ContentViewClick() {
            @Override
            public void onclick(Parse2PublicityBean  contendData) {
                LocaData = contendData;
                ToJumpHelp.toJumpMyMissionaryActivity(LT_PublictySearchActivity.this,"1",contendData,intentCode,userData);
            }
        });
        //取消按钮
        xc_id_titlebar_right2_layout.setOnClickListener(this);
        //搜索记录点击
        recordFragment.setOnRecordItemClickListener(new SXSearchRecordFragment.OnRecordItemClickListener() {
            @Override
            public void onRecordItemClickListener(XCSearchRecordModel model, String key_word, int position) {
                searchStr = key_word.trim();
                sk_id_search_edit.setText(key_word);
                initData("1",pageSize,offset,true,key_word.trim());
            }
        });


        //点击软件盘搜索按钮跳转搜索结果页
        sk_id_search_edit.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    searchStr =  sk_id_search_edit.getText().toString().trim();
                    if(!TextUtils.isEmpty(searchStr)){
                        saveKeyword(searchStr);
                        initData("1",pageSize,offset,true,searchStr);
                    }
                    return true;
                }
                return false;
            }
        });

        //搜索框布局
        sk_id_search_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lvContent.setVisibility(View.GONE);
                lt_pub_model_content.setVisibility(View.VISIBLE);
                recordFragment.adapter();
                showFragment(recordFragment);
            }
        });

        //监听键盘的关闭
        recordFragment.setOnKeyBoardStatusListener(new SXSearchRecordFragment.OnKeyBoardStatusListener() {
            @Override
            public void onStatusChange(boolean is_key_board_show) {
                      if(!is_key_board_show){
                                hideFragment(recordFragment);
                                lt_pub_model_content.setVisibility(View.GONE);
                          lvContent.setVisibility(View.VISIBLE);

                        }
            }
        });


        //内容刷新
        lvContent.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                //延迟0.5秒  PullToRefreshListView 的 onRefreshComplete刷新的问题
                delayHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initData(nextPage,pageSize,offset,false,searchStr);
                    }
                },500);
            }
        });


        //发送按钮的监听
        publicityAdpter.setOnViewSend(new LT_PublicityAdpter.onClickSendButton() {
            @Override
            public void judgeIntent(Parse2PublicityBean sendData) {
                if(0==intentCode){
                    //首页  群发
                    Intent groupSend = new Intent(LT_PublictySearchActivity.this,XD_NewGroupSendActivity.class);
                    groupSend.putExtra(XD_NewGroupSendActivity.PRO_EDU,sendData);
                    myStartActivity(groupSend);
                }else if(1==intentCode){
                    //聊天页 针对某个患者
                    SendDalogMsg(sendData);
                }
            }
        });

        //Adapter侧滑删除数据
        publicityAdpter.deleteContentClick(new LT_PublicityAdpter.deleteContent() {
            @Override
            public void delete(int position) {
                judgeDelete(position);
            }
        });
    }

    private void initData(String  page,String num, String offsets,final boolean isShowDialog,String content) {

        // 隐藏键盘，会调用隐藏历史记录
        UtilInputMethod.hiddenInputMethod(LT_PublictySearchActivity.this);
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("offset", offsets);
        params.put("page",page);
        params.put("type","1");
        params.put("content",content);
        params.put("num",num);
        XCHttpAsyn.postAsyn(isShowDialog,LT_PublictySearchActivity.this, AppConfig.getHostUrl(AppConfig.publicitye_search),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){
                    List<XCJsonBean> data =  result_bean.getList("data");
                    if(data!=null){
                        if(isShowDialog){
                            dataList.clear();
                        }
                        pageNo = data.get(0).getString("pageNo");
                        pageSize = data.get(0).getString("pageSize");
                        offset = data.get(0).getString("offset");
                        hasNex = data.get(0).getString("hasNext");
                        nextPage = data.get(0).getString("nextPage");
                        List<XCJsonBean>  resultList = data.get(0).getList("result");
                        Parse2PublicityBean.ParseJson(resultList,dataList);
                        hideFragment(recordFragment);
                        lt_pub_model_content.setVisibility(View.GONE);
                        if(dataList.size()>0){
                            lvContent.setVisibility(View.VISIBLE);
                            lt_no_date.setVisibility(View.GONE);
                            lt_put_nonetview.setVisibility(View.GONE);
                            publicityAdpter.updateList(dataList);
                            if(isShowDialog){
                                mListView.setSelection(0);
                            }
                            lvContent.onRefreshComplete();
                        }else{
                            lt_no_date.setVisibility(View.VISIBLE);
                            lvContent.setVisibility(View.GONE);
                            lt_put_nonetview.setVisibility(View.GONE);
                        }

                        //判断是否有下一页数据
                        if("false".equals(hasNex)){
                            lvContent.setMode(PullToRefreshBase.Mode.DISABLED);
                        }else if("true".equals(hasNex)){
                            lvContent.setMode(PullToRefreshBase.Mode.PULL_FROM_END);
                        }
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                lt_pub_model_content.setVisibility(View.GONE);
                lt_no_date.setVisibility(View.GONE);
                lvContent.setVisibility(View.GONE);
                lt_put_nonetview.setVisibility(View.VISIBLE);
            }


            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LT_PublictySearchActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }


    /** 保存搜索关键字 */
    public void saveKeyword(String keyword) {
        if (UtilString.isBlank(keyword)) {
            return;
        }
        // 查询数据库中是否有搜索的关键字，如果没有，存入数据库
        List<XCSearchRecordModel> xcSearchRecordModels1 = db.queryAllByDESC();
        boolean is_exist = false;
        for (XCSearchRecordModel model : xcSearchRecordModels1) {
            if (keyword.equals(model.getKey_word())) {
                is_exist = true;
                break;
            }
        }
        if (!is_exist) {
            db.insert(new XCSearchRecordModel(keyword, String.valueOf(System.currentTimeMillis())));
        }

        //查询数据库得到的关键字，如果大于10，删除多余的
        int count = db.queryCount();
        if (count > 10) {
            List<XCSearchRecordModel> xcSearchRecordModels = db.queryAllByDESC();
            for (int i = 10; i < count; i++) {
                XCSearchRecordModel model = xcSearchRecordModels.get(i);
                if (model != null) {
                    db.deleteByTime(model.getTime());
                }
            }
        }
    }


    /***
     * 初始化发送数据的Dialog
     * @param sendData
     */
    public void  SendDalogMsg( final Parse2PublicityBean sendData) {
        if (sendDialog == null) {
            sendDialog = new Dialog(LT_PublictySearchActivity.this, R.style.xc_s_dialog);
            sendDialog.setCanceledOnTouchOutside(false);
            View dialogView = LayoutInflater.from(LT_PublictySearchActivity.this).inflate(R.layout.lt_publicity_dialog, null);
            sendName = (TextView) dialogView.findViewById(R.id.tv_pub_name);
            sendHeader = (XCRoundedImageView) dialogView.findViewById(R.id.iv_pub_dialogiv);
            sendUrl = (TextView) dialogView.findViewById(R.id.tv_pub_url);
            sendCancle = (Button) dialogView.findViewById(R.id.bt_pub_cancle);
            sendOk = (Button) dialogView.findViewById(R.id.bt_pub_ok);
            sendDialog.setContentView(dialogView);
            //设置患者姓名头像
            if(userData!=null){
                sendName.setText(userData.getUserPatient().getPatientDisplayName());
                XCApplication.displayImage(userData.getUserPatient().getPatientImgHead(),sendHeader);
            }
        }
        //设置发送内容
        sendUrl.setText("[链接]"+sendData.getEduTitle());
        if(sendDialog!=null&&!sendDialog.isShowing()){
            sendDialog.show();
        }

        //取消
        sendCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDialog.dismiss();
            }
        });
        //确定
        sendOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comeSourec.putExtra(CommonConfig.PUBLICITY_EDUCATION_DATA,sendData);
                setResult(LT_PublicityActivity.PUBLICITY_SEARCH_INTENT_CODE,comeSourec);
                sendDialog.dismiss();
                finish();
            }
        });
    }


    /**
     * 删除数据  （Item侧滑）
     * @param position
     */
    private  void   judgeDelete( final int position){
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("eduId",dataList.get(position).getEduId());
        XCHttpAsyn.postAsyn(LT_PublictySearchActivity.this, AppConfig.getHostUrl(AppConfig.publicitye_removelist),params,new XCHttpResponseHandler(){

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);

                if (result_boolean){
                    dataList.remove(position);
                    publicityAdpter.notifyDataSetChanged();
                    isRefrash = 1;
                    //新需求  如果用户删到最后一条的时候会去加载下一页数据
                    if(dataList!=null && dataList.size()==0 && "true".equals(hasNex)){
                        initData("1",pageSize,offset,true,searchStr);
                    }else if (dataList.size()==0&&"false".equals(hasNex)){
                        lvContent.setVisibility(View.GONE);
                        lt_no_date.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                lt_no_date.setVisibility(View.GONE);
                lvContent.setVisibility(View.GONE);
                lt_put_nonetview.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(LT_PublictySearchActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //详情页面返回时携带本页面的数据直接返回聊天页面
        if(LT_PublicityActivity.PUBLICITY_INTENT_CHART_CODE==resultCode){
            comeSourec.putExtra(LT_PublicityActivity.PUBLICITY_DETAIL_BACK,LocaData);
            setResult(LT_PublicityActivity.PUBLICITY_INTENT_CHART_CODE,comeSourec);
            myFinish();
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.xc_id_titlebar_right2_layout:
                comeSourec.putExtra(LT_PublicityActivity.PUBLIVITY_ISJUDGE_REFRESH,isRefrash);
                setResult(LT_PublicityActivity.PUBLICITY_SEARCH_INTENT_ISREFRESH,comeSourec);
                myFinish();
                break;
            case R.id.xc_id_no_net_button:
                initData("1",pageSize,offset,true,searchStr);
                break;
        }
    }

    @Override
    public void onNetRefresh() {
    }

    @Override
    public void onBackPressed() {
        comeSourec.putExtra(LT_PublicityActivity.PUBLIVITY_ISJUDGE_REFRESH,isRefrash);
        setResult(LT_PublicityActivity.PUBLICITY_SEARCH_INTENT_ISREFRESH,comeSourec);
        myFinish();
        super.onBackPressed();
    }
}
