package com.qlk.ymz.activity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gdca.sdk.casign.base.BaseActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.util.UtilScreen;

/**
 * 患者列表页智能标签提示页面
 *
 * @author 崔毅然
 * @version 3.0.0
 * */
public class SignContentActivity extends BaseActivity {


    public TextView content_tv;//智能标签解释
    private RelativeLayout ll_content;
    String contentStr;//智能标签解释内容
    int[] location;//智能标签屏幕x,y轴位置
    int signWidth;//智能标签宽度
    int signHeight;//智能标签高度

    int screenWidth;//屏幕宽度
    int screenHeight;//屏幕高度

    ImageView iv_up;//向上箭头
    ImageView iv_down;//向下箭头

    int signLeft;//智能标签解释控件距离屏幕左边距离

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.dialog_sign_content);
        super.onCreate(savedInstanceState);

        initData();
        initView();

        showTimer();
    }

    public void initData(){

        //获取状态栏高度
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }

        screenWidth = UtilScreen.getScreenWidthPx(this);
        //去掉状态栏高度
        screenHeight = UtilScreen.getScreenHeightPx(this) - result;

        contentStr = getIntent().getStringExtra("content");
        location = getIntent().getIntArrayExtra("location");
        location[1] = location[1] - result;//定位需要去掉状态栏的高度
        signWidth = getIntent().getIntExtra("width",0);
        signHeight = getIntent().getIntExtra("height",0);
    }

    public void initView() {
        iv_up = (ImageView) findViewById(R.id.iv_up);
        iv_down = (ImageView) findViewById(R.id.iv_down);

        ll_content = (RelativeLayout) findViewById(R.id.ll_content);
        ll_content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SignContentActivity.this.finish();
            }
        });

        content_tv = (TextView) findViewById(R.id.content_tv);
        content_tv.setText(contentStr);
    }

    /**
     * 控件x方向显示位置
     * 1、显示超出手机左边宽度：0
     * 2、显示超出手机右边宽度：屏幕宽度 - 智能标签宽度
     * 3、正常：点击的智能标签x轴位置 - 解释控件宽度/2 + 智能标签宽度/2
     */
    public void showLocationX() {
        int contentStrWidth = UtilScreen.dip2px(this, 160);
        if (location[0] + signWidth / 2 < contentStrWidth / 2) {
            signLeft = 0;
        } else if ((location[0] + signWidth / 2 + contentStrWidth / 2) > screenWidth) {
            signLeft = screenWidth - contentStrWidth;
        } else {
            signLeft = location[0] - contentStrWidth / 2 + signWidth / 2;
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.pop_up, R.anim.pop_down);//不加的话默认页面从左向右划出
    }

    //箭头宽高（dp）
    private int arrowWidth = 12;
    private int arrowheight = 6;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        //页面画完后进行定位
        if (hasFocus) {

            content_tv.setVisibility(View.VISIBLE);
            showLocationX();

            int height = content_tv.getMeasuredHeight();
            int y;
            int left = location[0] + signWidth / 2 - UtilScreen.dip2px(this, arrowWidth/2);

            // 箭头向上
            if ((location[1] + height + signHeight) < screenHeight) {
                //向上箭头位置
                RelativeLayout.LayoutParams upLayoutParams = (RelativeLayout.LayoutParams) iv_up.getLayoutParams();
                upLayoutParams.setMargins(left, location[1] + signHeight, 0, 0);
                iv_up.setLayoutParams(upLayoutParams);
                iv_up.setVisibility(View.VISIBLE);
                //设置dialog显示位置(点击view的控件高度和箭头高度)
                y = location[1] + UtilScreen.dip2px(this, arrowheight) + signHeight;
            }
            // 箭头向下
            else {
                //向下箭头位置
                RelativeLayout.LayoutParams downLayoutParams = (RelativeLayout.LayoutParams) iv_down.getLayoutParams();
                downLayoutParams.setMargins(left, location[1] - signHeight, 0, 0);
                iv_down.setLayoutParams(downLayoutParams);
                iv_down.setVisibility(View.VISIBLE);
                //设置dialog显示位置（点击view的控件高度和提示view高度）
                y = location[1] - signHeight - height;
            }
            RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) content_tv.getLayoutParams();
            params.setMargins(signLeft, y, 0, 0);
            content_tv.setLayoutParams(params);
        }
    }

    /** 设置3秒定时器，关闭页面 */
    CountDownTimer signTimer;

    public void showTimer() {
        signTimer = new CountDownTimer(3000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                SignContentActivity.this.finish();

            }
        };
        signTimer.start();
    }

    public void onDestroy() {
        if (signTimer != null){
            signTimer.cancel();
            signTimer = null;
        }
        super.onDestroy();
    }

}
