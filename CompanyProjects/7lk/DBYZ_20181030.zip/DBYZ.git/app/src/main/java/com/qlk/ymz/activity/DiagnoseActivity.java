package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.RelativeLayout;

import com.google.gson.Gson;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.fragment.DiagnoseCommonFragment;
import com.qlk.ymz.fragment.DiagnoseSearchFragment;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.TagGroup;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.ListUtil;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static com.qlk.ymz.R.id.tagGroup;

/**
 * 临床诊断
 *
 * 本页面启动有动画，启动方式如下：
 * <pre><code>
 * startActivityForResult(DiagnoseActivity.newIntent(context, diagnosisList), requestCode);
 * overridePendingTransition(R.anim.activity_open_up, R.anim.activity_no_move);
 * </code></pre>
 *
 * 获取本页面返回的数据，即Result:
 * <pre><code>
 * List<DiagnoseBean> list = (ArrayList<DiagnoseBean>) data.getSerializableExtra(DiagnoseActivity.INTENT_KEY_DIAGNOSIS);
 * </code></pre>
 *
 * @author wpq
 * @version 1.0
 */
public class DiagnoseActivity extends DBActivity {

    private static final String FRAGMENT_COMMON = "DiagnoseCommonFragment";
    private static final String FRAGMENT_SEARCH = "DiagnoseSearchFragment";
    /** 诊断数据 */
    public static final String INTENT_KEY_DIAGNOSIS = "diagnosis";
    /** for savedInstanceState */
    private static final String SAVED_DATA = "diagnosisList";

    private XCTitleCommonLayout mTitleBar;
    private TagGroup mTagGroup;

    private DiagnoseCommonFragment mDiagnoseCommonFragment;
    private DiagnoseSearchFragment mDiagnoseSearchFragment;
    private FragmentManager mFragmentManager;
    private boolean isSearchFragmentShowing;
    // 保存已选择的DiagnoseBean
    private List<DiagnoseBean> mList = new ArrayList<>();

    // 提示保存对话框
    private YR_CommonDialog mDialog;
    /**
     * 辅助诊断布局
     */
    private RelativeLayout mLayout;
    /** 惠每对话框*/
    private YR_CommonDialog mCdssDialog;

    /**
     * Intent for this Activity
     * @param context 上下文
     * @param diagnosisList 诊断数据
     */
    public static Intent newIntent(Context context, ArrayList<DiagnoseBean> diagnosisList) {
        Intent intent = new Intent(context, DiagnoseActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable(INTENT_KEY_DIAGNOSIS, diagnosisList);
        intent.putExtras(bundle);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_diagnose);
        super.onCreate(savedInstanceState);

        if (savedInstanceState == null) {
            initIntentDiagnosis();
        } else {
            recoverySavedData(savedInstanceState);
        }

        mFragmentManager = getSupportFragmentManager();
        showFragment(FRAGMENT_COMMON);

    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(DiagnoseActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable(SAVED_DATA, (Serializable) mList);
    }

    @Override
    public void initWidgets() {
        mTitleBar = getViewById(R.id.titleBar);
        mTitleBar.setTitleLeft(true, getString(R.string.diagnose_cancel));
        mTitleBar.setTitleCenter(true, getString(R.string.diagnose_title));
        mTitleBar.setTitleRight2(true, 0, getString(R.string.diagnose_done));
        mTitleBar.getXc_id_titlebar_left_imageview().setVisibility(View.GONE);
        mTitleBar.getXc_id_titlebar_left_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));

        mTagGroup = getViewById(tagGroup);
        mLayout = getViewById(R.id.hm_layout);
        initDialog();
    }

    /**
     * 初始化保存提示对话框
     */
    private void initDialog() {
         mDialog = new YR_CommonDialog(this, "放弃保存吗？", "放弃", "取消") {
            @Override
            public void confirmBtn() {
                dismiss();
            }

            @Override
            public void cancelBtn() {
                super.cancelBtn();
                myFinish();
            }
        };
        mDialog.setCanceledOnTouchOutside(true);
    }

    @Override
    public void listeners() {
        // 取消
        mTitleBar.getXc_id_titlebar_left_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkTags();
            }
        });
        // 完成
        mTitleBar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });
        mTagGroup.setOnTagChangeListener(new TagGroup.OnTagChangeListener() {
            @Override
            public void onInputTextChanged(final CharSequence s) {
                if (!UtilString.isBlank(s.toString())) {
                    if (!isSearchFragmentShowing) {
                        showFragment(FRAGMENT_SEARCH);
                    }
                    mTagGroup.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            // 这里延时是为了保证 DiagnoseSearchFragment 的 search 方法在 onCreateView 和 onActivityCreated 之后执行
                            // 经测试，不延时search会先执行
                            mDiagnoseSearchFragment.search(s.toString());
                        }
                    }, 50);
                } else {
                    showFragment(FRAGMENT_COMMON);
                }
            }

            @Override
            public void onAppend(TagGroup tagGroup, String tag) {
                // 点击空白区域或键盘Enter，将输入框变为新标签，再添加新的输入框
                DiagnoseBean diagnoseBean = new DiagnoseBean();
                diagnoseBean.id = 0; // 自定义默认为0
                diagnoseBean.name = tag;
                diagnoseBean.type = 1; // 自定义为1
                mList.add(diagnoseBean);

                if (isSearchFragmentShowing) {
                    showFragment(FRAGMENT_COMMON);
                }
            }

            @Override
            public void onInsert(TagGroup tagGroup, String tag) {
                // 点 常用诊断或搜索结果 直接在输入框前边添加新标签
                if (isSearchFragmentShowing) {
                    showFragment(FRAGMENT_COMMON);
                }
            }

            @Override
            public void onDelete(TagGroup tagGroup, String tag) {
                // 更新list
                List<DiagnoseBean> filterList = new ArrayList<>();
                for (DiagnoseBean diagnoseBean : mList) {
                    if (diagnoseBean.name.equals(tag)) {
                        filterList.add(diagnoseBean);
                    }
                }
                mList.removeAll(filterList);
            }

            @Override
            public void onTagsCountReachLimit(TagGroup tagGroup, int tagsCountLimit) {
                shortToast(String.format(getString(R.string.diagnose_count_limit), tagsCountLimit));
            }
        });
        mLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCdssDays();
            }
        });
    }

    /** 处理从处方笺带过来诊断数据 */
    private void initIntentDiagnosis() {
        Bundle bundle = getIntent().getExtras();
        if (bundle == null) {
            return;
        }
        @SuppressWarnings("unchecked")
        List<DiagnoseBean> diagnosisList = (ArrayList<DiagnoseBean>) bundle.getSerializable(INTENT_KEY_DIAGNOSIS);
        diagnosisList = ListUtil.filterNullElements(diagnosisList);
        if (diagnosisList.size() == 0) {
            return;
        }

        String[] tags = new String[diagnosisList.size()];
        for (int i = 0; i < diagnosisList.size(); i++) {
            tags[i] = diagnosisList.get(i).name;
        }
        mTagGroup.setTags(tags);
        mList.clear();
        mList.addAll(diagnosisList);
    }

    /** 恢复数据 */
    private void recoverySavedData(Bundle savedInstanceState) {
        @SuppressWarnings("unchecked")
        List<DiagnoseBean> diagnosisList = (ArrayList<DiagnoseBean>) savedInstanceState.getSerializable(SAVED_DATA);
        diagnosisList = ListUtil.filterNullElements(diagnosisList);
        if (diagnosisList.size() == 0) {
            return;
        }

        mList.clear();
        mList.addAll(diagnosisList);
        String[] tags = new String[mList.size()];
        for (int i = 0; i < mList.size(); i++) {
            tags[i] = mList.get(i).name;
        }
        mTagGroup.setTags(tags);
    }

    private void showFragment(String fragmentTag) {
        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        hideFragments(transaction);
        switch (fragmentTag) {
            case FRAGMENT_COMMON: { // 常用诊断
                if (mDiagnoseCommonFragment == null) {
                    mDiagnoseCommonFragment = DiagnoseCommonFragment.newInstance();
                    transaction.add(R.id.container, mDiagnoseCommonFragment, fragmentTag);
                } else {
                    transaction.show(mDiagnoseCommonFragment);
                }
                isSearchFragmentShowing = false;
                break;
            }
            case FRAGMENT_SEARCH: { // 诊断搜索
                if (mDiagnoseSearchFragment == null) {
                    mDiagnoseSearchFragment = DiagnoseSearchFragment.newInstance();
                    transaction.add(R.id.container, mDiagnoseSearchFragment, fragmentTag);
                } else {
                    transaction.show(mDiagnoseSearchFragment);
                }
                isSearchFragmentShowing = true;
                break;
            }
        }
//        transaction.commitAllowingStateLoss();
        transaction.commit();
    }

    private void hideFragments(FragmentTransaction transaction) {
        if (null != mDiagnoseCommonFragment) {
            transaction.hide(mDiagnoseCommonFragment);
        }
        if (null != mDiagnoseSearchFragment) {
            transaction.hide(mDiagnoseSearchFragment);
        }
    }

    /**
     * 调用时机：{@link DiagnoseCommonFragment} 点击常用诊断 || {@link DiagnoseSearchFragment} 点击搜索结果
     * @param diagnoseBean 诊断Bean
     */
    public void insertDiagnose(DiagnoseBean diagnoseBean) {
        if (diagnoseBean != null && !UtilString.isBlank(diagnoseBean.name)) {
            mTagGroup.insertTag(diagnoseBean.name);
            // 因为mTagGroup.insertTag可能需要去重，会先delete已经存在的再重新添加，
            // 所以更新list必须在insertTag之后
            if (mList.size() < mTagGroup.getTagsCountLimit()) {
                mList.add(diagnoseBean);
            }
        }
    }

    /** 点右上角完成保存诊断数据 */
    private void save() {

        if (!mTagGroup.isTagsCountReachLimit()) {
            // 点完成时如果输入框有内容，则保存到常用诊断
            mTagGroup.submitTag();
        }

        if(StringUtils.containsEmoji(getDianoseString(mList))){
            shortToast("诊断不能输入表情");
            return;
        }
//        postTags(); // 考虑保存失败等情况会导致其他问题出现，经讨论最终决定发送处方时后端处理诊断数据

        Intent intent = new Intent();
        intent.putExtra(INTENT_KEY_DIAGNOSIS, (Serializable) mList);
        setResult(RESULT_OK, intent);
        myFinish();
    }

    /** 点完成时把tags保存到服务器 */
    private void postTags() {
        String token = XCApplication.base_sp.getString("token", "");
        String doctorId = XCApplication.base_sp.getString("doctorId", "");
        String url = AppConfig.getTuijianUrl(AppConfig.DIAGNOSE_LIST_UPDATE) + "?token=" + token + "&doctorId=" + doctorId + "&userId=" + doctorId;
        XCHttpAsyn.postAsync(false, this, url, new Gson().toJson(mList), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (arg2 != null) {
                    printi(AppConfig.DIAGNOSE_LIST_UPDATE, new String(arg2));
                }
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onBackPressed() {
        checkTags();
    }

    /** 点左上角返回或系统返回键时，检查tags是否为空，不为空则提示保存 */
    private void checkTags() {
        String[] tags = mTagGroup.getTags();
        // 如果 tags数量 > 0 || (tags数量 == 0 && 输入框内容不为空)
        if (tags != null && tags.length > 0 || !UtilString.isBlank(mTagGroup.getInputTagText())) {
            mDialog.show();
        } else {
            myFinish();
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.activity_no_move, R.anim.activity_close_down);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            mTagGroup.removeAllViews();
        } finally {
            mTagGroup = null;
        }
    }

    /**
     * 获取惠每使用期
     */
    private void getCdssDays() {
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.CDSS_DAYS), params, new
                XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (result_boolean) {
                            String expired = result_bean.getList("data").get(0).getString("expired");
                            String remainDaysDesc = result_bean.getList("data").get(0).getString("remainDaysDesc");
                            //判断使用期
                            if("0".equals(expired)){
                                NativeHtml5.drCaseVOBean.setDiagnosisList(getDianoseList());
                                WebviewBean bean = new WebviewBean(AppConfig.getHuiMeiUrl());
                                bean.titleBarType = 1;
                                bean.isShowCdssInvite = true;
                                bean.cdssContent = UtilString.f(remainDaysDesc);
                                myStartActivityForResult(JS_WebViewActivity.newIntent(DiagnoseActivity.this, bean), XD_EditMedicalRecordActivity.TO_HELP_DIAGNOSIS);
                            }else if("1".equals(expired)){
                                showCdssDialog();
                            }
                        }
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(DiagnoseActivity.this, getCode(), getMsg())) {
                        }
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(XD_EditMedicalRecordActivity.TO_HELP_DIAGNOSIS == requestCode && NativeHtml5.cdssDiagnose.size()>0){
            mList.addAll(NativeHtml5.cdssDiagnose);
            NativeHtml5.cdssDiagnose.clear();
            String[] tags = new String[mList.size()];
            for (int i = 0; i < mList.size(); i++) {
                tags[i] = mList.get(i).name;
            }
            mTagGroup.setTags(tags);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * 显示惠每dialog
     */
    private void showCdssDialog(){
        if(mCdssDialog == null){
            mCdssDialog = new YR_CommonDialog(this,"您的惠每CDSS使用权已到期，立刻邀请医生就可以获得使用权?","取消",
                    "邀请医生") {
                @Override
                public void confirmBtn() {
                    dismiss();
                    WebviewBean bean = new WebviewBean(AppConfig.getH5Url(AppConfig.CDSS_INVITE_DOCTOR));
                    myStartActivity(JS_WebViewActivity.newIntent(DiagnoseActivity.this, bean));
                }
            };
            mCdssDialog.setCanceledOnTouchOutside(false);
        }
        if(mCdssDialog != null && !mCdssDialog.isShowing()){
            mCdssDialog.show();
        }
    }

    /**
     * 转换诊断集合
     * @return
     */
    private List<String> getDianoseList() {
        ArrayList<String> list = new ArrayList<>();
        for(DiagnoseBean diagnoseBean:mList){
            list.add(diagnoseBean.name);
        }
        return list;
    }

    /**
     * 转换诊断字符串
     * @return
     */
    private String getDianoseString(List<DiagnoseBean> list) {
        String diagnose = "";
        for(int i=0;i<list.size();i++ ){
            if(i==list.size()-1){
                diagnose += list.get(i).name;
            }else {
                diagnose += list.get(i).name+",";
            }
        }
        return diagnose;
    }
}
