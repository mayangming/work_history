package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.YY_TemplateDetailBean;
import com.xiaocoder.android.fw.general.adapter.YYBaseExpandableListViewAdapter;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import java.util.List;

/**
 * @author shuYanYi on 2016/11/15.
 * @description 随访模板详情适配器
 */

public class YY_TemplateDetailAdapter extends YYBaseExpandableListViewAdapter<YY_TemplateDetailBean.DataBean.TempletBean,
                                                                                YY_TemplateDetailBean.DataBean.TempletBean.OptionsBean> {

    public YY_TemplateDetailAdapter(Context context, List<YY_TemplateDetailBean.DataBean.TempletBean> list) {
        super(context, list);
    }

    @Override
    public List<YY_TemplateDetailBean.DataBean.TempletBean.OptionsBean> getChildList(int groupPosition) {
        try {
            return list.get(groupPosition).getOptions();
        } catch (Exception e) {
            return null;
        }
    }



    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupViewHolder holder = null;
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.yy_item_template_detail_group,null);
            holder = new GroupViewHolder(convertView);
            convertView.setTag(holder);
        }else{
            holder = (GroupViewHolder) convertView.getTag();
        }
        groupBean = getGroup(groupPosition);
        holder.tv_no.setText(String.valueOf(groupPosition + 1) + ".");
        holder.tv_question.setText(groupBean.getQuestion());
        UtilViewShow.setGone(groupBean.getAnswerType() == YY_TemplateDetailBean.ANSWER_TYPE_FILLBLANKS, holder.id_suifang_answer_text);
        return convertView;
    }

    @Override
    public View getChildView(final int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        ChildViewHolder holder = null;
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.yy_item_template_detail,null);
            holder = new ChildViewHolder(convertView);
            convertView.setTag(holder);
        }else{
            holder = (ChildViewHolder) convertView.getTag();
        }

        groupBean = getGroup(groupPosition);
        childBean = getChild(groupPosition,childPosition);
        if(childBean != null){
            holder.tv_answer.setText(childBean.getOption());
        }

        holder.type_cb.setVisibility(View.GONE);
        holder.type_rb.setVisibility(View.GONE);


        //答案类型
        switch (groupBean.getAnswerType()){
            case YY_TemplateDetailBean.ANSWER_TYPE_MULTISELECT:
                holder.type_cb.setVisibility(View.VISIBLE);
                break;
            case YY_TemplateDetailBean.ANSWER_TYPE_SINGSEL:
                holder.type_rb.setVisibility(View.VISIBLE);
                break;
        }

        return convertView;
    }



    private class GroupViewHolder {
        /** 题号*/
        private TextView tv_no;
        /** 问题*/
        private TextView tv_question;
        /** 填空题的框*/
        private View id_suifang_answer_text;
        public GroupViewHolder(View convertView){
            tv_no = (TextView)convertView.findViewById(R.id.tv_no);
            tv_question = (TextView)convertView.findViewById(R.id.tv_question);
            id_suifang_answer_text = convertView.findViewById(R.id.id_suifang_answer_text);
        }
    }

    private class ChildViewHolder {
        /** 答案选项*/
        private TextView tv_answer;
        /** 多选框*/
        private View type_cb;
        /** 单选框*/
        private View type_rb;
        public ChildViewHolder(View convertView){
            tv_answer = (TextView)convertView.findViewById(R.id.tv_answer);
            type_cb = convertView.findViewById(R.id.type_cb);
            type_rb = convertView.findViewById(R.id.type_rb);
        }
    }

}
