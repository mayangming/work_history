package com.qlk.ymz.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.BuildConfig;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.model.PF_ShareInfo;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.SystemMessageUtil;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.bi.BiUtil;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.smtt.export.external.interfaces.IX5WebChromeClient;
import com.tencent.smtt.export.external.interfaces.SslErrorHandler;
import com.tencent.smtt.sdk.ValueCallback;
import com.tencent.smtt.sdk.WebChromeClient;
import com.tencent.smtt.sdk.WebSettings;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonParse;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilSystem;

import java.io.File;
import java.util.List;

/**
 * 通用自定义WebView页
 * @author 徐金山
 * @version 1.2.0
 *
 * @version 1.5
 * @author zhangpengfei
 */
public class JS_WebViewActivity extends DBActivity {

    /** 要加载的Web页Bean标识 */
    public static final String WEB_BEAN_FLAG = "webBeanFlag";
    /** JSBridge名称 */
    public static final String JS_INTERACTION_NAME = "JSBridge";
    private RelativeLayout base_layout;
    /**标题栏*/
    private RelativeLayout rl_titleBar;
    /** 标题栏-左边图片布局 */
    private LinearLayout ll_titleBar_left_image;
    /** 标题栏-左边图片 */
    private ImageView iv_titleBar_left;
    /** 标题栏-左边文字布局 */
    private TextView tv_titleBar_left;
    /** 标题栏-一级标题 */
    private TextView tv_titleBar_title;
    /** 标题栏-二级标题 */
    private TextView tv_titleBar_subTitle;
    /** 标题栏-右边右数第1个布局 */
    private LinearLayout ll_titleBar_right1;
    /** 标题栏-右边右数第1个图片布局 */
    private LinearLayout ll_titleBar_right1_image;
    /** 标题栏-右边右数第1个图片 */
    private ImageView iv_titleBar_right1;
    /** 标题栏-右边右数第1个文字布局 */
    private TextView tv_titleBar_right1;
    /** 标题栏-右边右数第2个布局 */
    private LinearLayout ll_titleBar_right2;
    /** 标题栏-右边右数第2个图片布局 */
    private LinearLayout ll_titleBar_right2_image;
    /** 标题栏-右边右数第2个图片 */
    private ImageView iv_titleBar_right2;
    /** 标题栏-右边右数第2个文字布局 */
    private TextView tv_titleBar_right2;
    /** WebView */
    private WebView webView;
    /** 加载loading布局 */
    private LinearLayout ll_loading;
    /** 视频布局 */
    private View mCustomView;
    /** 底部点击按钮 */
    private Button bt_click;
    private IX5WebChromeClient.CustomViewCallback mCustomViewCallback;

    /**cdss底部布局*/
    private RelativeLayout cdss_bottom_rl;
    /**cdss底部关闭按钮*/
    private ImageView cdss_bottom_closer_iv;
    /**邀请内容*/
    private TextView cdss_bottom_content_iv;
    /**cdss底部邀请医生按钮*/
    private ImageView cdss_bottom_invite_doctor_iv;
    /**是否显示cdss邀请栏 true显示*/
    public boolean isShowCdssInvite = false;
    /**cdss邀请内容*/
    private String cdssContent = "";
    // intent data
    /** 要加载的web页URL */
    private String htmlUrl = "";
    /** 页面标题 */
    private String title = "";
    /** 用来判断是否显示html的标题: 0 显示, 1 不显示 */
    private int flag = 0;
    /** 用来判断是否显示标题栏: 0 显示, 1 不显示 */
    private int titleType = 0;

    /** 是否出错 */
    private boolean isErro;
    /** 专题二级分类 */
    private String topic = "";
    /** h5拦截返回按钮时调用的方法 */
    private String h5CallBack = "";
    /** 是否能返回 */
    private boolean isCanBack = true;
    /** 是否重新刷新(处理调价页面返回详情页) */
    public static boolean isRefresh = false;
    /**是否支持分享 1 支持 0 不支持*/
    private String shareFlag = "";
    /**分享标题*/
    private String shareTitle = "";
    /**html标题*/
    private String htmlTitle = "";
    /**html描述*/
    private String htmlDescribe = "";
    /**返回键Json*/
    private String backJson = "";
    /**h5设置支持分享*/
    private boolean h5SetShare = false;
    /**记录h5出现的页面次数*/
    private int h5RefreshCount = 0;
    private NativeHtml5 mNativeHtml5;

    /** 用来处理上传图片 */
    private ValueCallback<Uri> uploadMessage;
    private ValueCallback<Uri[]> uploadMessageAboveL;
    /**
     * Intent for JS_WebViewActivity.class
     * @param context 上下文对象
     * @param bean webview交互bean
     */
    public static Intent newIntent(Context context, WebviewBean bean) {
        Intent intent = new Intent(context, JS_WebViewActivity.class);
        intent.putExtra(WEB_BEAN_FLAG, bean);
        return intent;
    }

    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.js_activity_webview);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onStart() {
        super.onStart();
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(JS_WebViewActivity.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (isRefresh && null != webView){
            webView.reload();
            isRefresh = false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        UtilInputMethod.hiddenInputMethod(this);
    }

    /** 初始化数据 */
    private void initData() {
        isRefresh = false;
        WebviewBean webviewBean = (WebviewBean) getIntent().getSerializableExtra(WEB_BEAN_FLAG);
        if (webviewBean != null) {
            htmlUrl = webviewBean.url;
            XCApplication.base_log.i(XCConfig.TAG_HTML5, "h5+Url: " + htmlUrl);
            title = webviewBean.title;
            flag = webviewBean.htmlFlag;
            shareFlag = webviewBean.isShowShare;
            shareTitle = webviewBean.shareTitle;
            backJson = webviewBean.backJson;
            titleType = webviewBean.titleBarType;
            isShowCdssInvite = webviewBean.isShowCdssInvite;
            cdssContent = webviewBean.cdssContent;
            // 如果url中有topic,就清除首页的角标
            if (!UtilString.isBlank(htmlUrl) && htmlUrl.contains("topic=")) {
                topic = htmlUrl.substring(htmlUrl.lastIndexOf("topic=") + 6, htmlUrl.lastIndexOf("topic=") + 7);
                JS_ChatListModel chatListModel = new JS_ChatListModel();
                chatListModel.getUserPatient().setPatientId(JS_ChatListModel.NOTICE_ID);
                chatListModel.setTopic(topic);
                JS_ChatListDB.getInstance(this, UtilSP.getUserId()).setUnReadMessageNum2Zero(chatListModel);
                SystemMessageUtil.deleteSystemMessage(topic);
            }
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    public void initWidgets() {
        initData();
        base_layout = getViewById(R.id.base_layout);
        rl_titleBar = getViewById(R.id.rl_titleBar);
        ll_titleBar_left_image = getViewById(R.id.ll_titleBar_left_image);
        iv_titleBar_left = getViewById(R.id.iv_titleBar_left);
        tv_titleBar_left = getViewById(R.id.tv_titleBar_left);
        tv_titleBar_title = getViewById(R.id.tv_titleBar_title);
        tv_titleBar_subTitle = getViewById(R.id.tv_titleBar_subTitle);
        ll_titleBar_right1 = getViewById(R.id.ll_titleBar_right1);
        ll_titleBar_right1_image = getViewById(R.id.ll_titleBar_right1_image);
        iv_titleBar_right1 = getViewById(R.id.iv_titleBar_right1);
        tv_titleBar_right1 = getViewById(R.id.tv_titleBar_right1);
        ll_titleBar_right2 = getViewById(R.id.ll_titleBar_right2);
        ll_titleBar_right2_image = getViewById(R.id.ll_titleBar_right2_image);
        iv_titleBar_right2 = getViewById(R.id.iv_titleBar_right2);
        tv_titleBar_right2 = getViewById(R.id.tv_titleBar_right2);

        cdss_bottom_rl = (RelativeLayout)findViewById(R.id.cdss_bottom_rl);
        cdss_bottom_closer_iv = (ImageView)findViewById(R.id.cdss_bottom_closer_iv);
        cdss_bottom_content_iv = (TextView)findViewById(R.id.cdss_bottom_content_iv);
        cdss_bottom_invite_doctor_iv = (ImageView)findViewById(R.id.cdss_bottom_invite_doctor_iv);
        cdss_bottom_content_iv.setText(UtilString.f(cdssContent));
        bt_click = getViewById(R.id.bt_click);
        ll_loading = getViewById(R.id.ll_loading);
        webView = getViewById(R.id.webView);
        if (isShowCdssInvite){
            cdss_bottom_rl.setVisibility(View.VISIBLE);
        }else {
            cdss_bottom_rl.setVisibility(View.GONE);
        }
        if (titleType == 0){
            rl_titleBar.setVisibility(View.VISIBLE);
        }else if (titleType == 1){
            rl_titleBar.setVisibility(View.GONE);
        }
        // 设置标题
        tv_titleBar_title.setText(UtilString.f(title));
        // 设置loading半透明
        ll_loading.setAlpha(0.5f);

        WebSettings settings = webView.getSettings();
        // 自适应屏幕
        // 设置webview推荐使用的窗口
        settings.setUseWideViewPort(true);
        // 设置webview加载的页面的模式
        settings.setLoadWithOverviewMode(true);
        // 不进行缓存，总是使用网络数据
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setJavaScriptEnabled(true);
        //开启 DOM 存储功能
        settings.setDomStorageEnabled(true);
        // 增加web与native交互的代码
        webView.addJavascriptInterface(mNativeHtml5 = NativeHtml5.newInstance(this), JS_INTERACTION_NAME);
        webView.loadUrl(initUrls(htmlUrl));

    }

    /* 假如传入进来的url符合规则，则域名改为https格式 */
    public String initUrls(String sourceUrl){
        //http://admin.open.7lk.com/Pharmaceutical/DoctorRecord
        if (sourceUrl.contains("https")){
            return sourceUrl;
        }else if (sourceUrl.contains("dabai.7lk.com") || sourceUrl.contains(".7lk.me") || sourceUrl.contains("dabaitest.7lk.cn")){
            sourceUrl = sourceUrl.replaceFirst("http","https");
        }
        return sourceUrl;
    }

    @Override
    public void listeners() {
        ll_titleBar_left_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                UtilInputMethod.hiddenInputMethod(JS_WebViewActivity.this);
            }
        });
        tv_titleBar_left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                UtilInputMethod.hiddenInputMethod(JS_WebViewActivity.this);
            }
        });
        cdss_bottom_closer_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cdss_bottom_rl.setVisibility(View.GONE);
            }
        });
        cdss_bottom_invite_doctor_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WebviewBean bean = new WebviewBean(AppConfig.getH5Url(AppConfig.CDSS_INVITE_DOCTOR));
                myStartActivity(JS_WebViewActivity.newIntent(JS_WebViewActivity.this, bean));
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                XCApplication.base_log.i(XCConfig.TAG_HTML5, "shouldOverrideUrlLoading-------" + url);
                //重定向的页面hitTestResult不为空,所以返回要false(让webview内部自己处理url,这样点返回键就会认为是一个页面)
                WebView.HitTestResult hitTestResult = view.getHitTestResult();
                if (!UtilString.isBlank(url) && hitTestResult == null){
                    if (url.startsWith("tel:")) {
                        //电话
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } else {
                        // 在当前的webview中跳转到新的url
                        view.loadUrl(initUrls(url.trim()));
                        //用来处理h5的图文模板分享页面里面有超链接,跳过去还要支持分享
                    }
                    return true;
                }
                // 返回: return true;  webview处理url是根据程序来执行的(自己调用view.loadUrl())。
                // 返回: return false; webview处理url是在webview内部执行。
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                XCApplication.base_log.i(XCConfig.TAG_HTML5, "onPageStarted-------" + url);
                showLoading();
                resetTitleRightLayout();
                if (titleType == 0){
                    rl_titleBar.setVisibility(View.VISIBLE);
                }else if (titleType == 1){
                    rl_titleBar.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                XCApplication.base_log.i(XCConfig.TAG_HTML5, "onPageFinished-------" + url);
                stopLoading();
                if (webView.canGoBack()){
                    htmlUrl = initUrls(url.trim());
                    if (h5SetShare){
                        h5SetShare = false;
                        shareFlag = "1";
                        shareTitle = "";
                    }
                }
                //注入JS代码获取网页Title
                view.loadUrl("javascript:" + JS_INTERACTION_NAME + ".getWebViewTile(document.title)");
                //注入JS代码获取一个网页的meta里的description
                view.loadUrl("javascript:" + JS_INTERACTION_NAME + ".getWebViewMeta(document.querySelector('meta[name=\"description\"]')&&document.querySelector('meta[name=\"description\"]').getAttribute('content'))");

                //  2.6.0 注释此代码，不显示关闭按钮
                // if (qlk_id_webview.canGoBack()){
                //    pf_id_wait_register_contacts_back_text.setText("关闭");
                // }

                //加延迟,是为了防止刷新的时候webview会出现无网络页面
                if (!isErro) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (webView != null) {
                                webView.setVisibility(View.VISIBLE);
                                xc_id_model_no_net.setVisibility(View.GONE);
                            }
                        }
                    }, 500);
                }
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (webView != null) {
                            //通过传过来的值和h5不支持分享标识来啊判断显示分享按钮
                            if ("1".equals(shareFlag) && !h5SetShare){
                                ll_titleBar_right1_image.setVisibility(View.VISIBLE);
                                tv_titleBar_right1.setVisibility(View.GONE);
                                iv_titleBar_right1.setImageResource(R.mipmap.share);
                                ll_titleBar_right1.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        PF_ShareInfo info = new PF_ShareInfo();
                                        if (UtilString.isBlank(htmlDescribe)) {
                                            if (UtilString.isBlank(htmlTitle)){
                                                if (UtilString.isBlank(shareTitle)){
                                                    htmlDescribe = "";
                                                }else{
                                                    htmlDescribe = shareTitle;
                                                }
                                            }else {
                                                htmlDescribe = htmlTitle;
                                            }
                                        }
                                        info.setSpreadContent(htmlDescribe);
                                        if (UtilString.isBlank(shareTitle)){
                                            if (UtilString.isBlank(htmlTitle)) {
                                                shareTitle = "石榴云医";
                                            }else {
                                                shareTitle = htmlTitle;
                                            }
                                        }
                                        info.setTitle(shareTitle);
                                        info.setSpreadUrl(initUrls(htmlUrl));
                                        info.setImgUrl(AppConfig.getH5Url(AppConfig.qlkLogo));
                                        info.setIsShowSavePublicity("1");
                                        PF_ShareActivity.launch(JS_WebViewActivity.this, info);
                                    }
                                });
                            }
                        }
                    }
                }, 500);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                stopLoading();
                webView.setVisibility(View.INVISIBLE);
                xc_id_model_no_net.setVisibility(View.VISIBLE);
                isErro = true;
                rl_titleBar.setVisibility(View.VISIBLE);
            }


            @Override
            public void onReceivedSslError(WebView webView, SslErrorHandler sslErrorHandler, com.tencent.smtt.export.external.interfaces.SslError sslError) {
                sslErrorHandler.proceed();

            }

            //            @Override
//            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
//                WebResourceResponse response = null;
//                //拦截首页图表js库,加载本地的图表js库
//                if (url.contains("echarts-all.min.js")){
//                    try {
//                        InputStream localCopy = getAssets().open("echarts-all.min.js");
//                        response = new WebResourceResponse("text/javascript","UTF-8",localCopy);
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//                return response;
//            }


        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                if (newProgress == 100) {
                    stopLoading();
                }
            }

            /**
             * 显示视频布局
             */
            @Override
            public void onShowCustomView(View view, IX5WebChromeClient.CustomViewCallback callback) {
                super.onShowCustomView(view, callback);
                if (mCustomView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                mCustomView = view;
                base_layout.addView(mCustomView);
                mCustomViewCallback = callback;
                webView.setVisibility(View.GONE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            }

            /**
             * 隐藏视频布局
             */
            @Override
            public void onHideCustomView() {
                webView.setVisibility(View.VISIBLE);
                if (mCustomView == null) {
                    return;
                }
                mCustomView.setVisibility(View.GONE);
                base_layout.removeView(mCustomView);
                mCustomViewCallback.onCustomViewHidden();
                mCustomView = null;
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                super.onHideCustomView();
            }

            /**
             * >=5.0系统调用文件上传
             */
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> valueCallback, FileChooserParams fileChooserParams) {
                uploadMessageAboveL = valueCallback;
                ToJumpHelp.toJumpSelctImgsActivity(JS_WebViewActivity.this, 1, YY_SelectImgsActivity.MODE_SINGLE,
                        true, true, false, true);
                return true;
            }
            /**
             * >=4.1系统调用文件上传
             */
            @Override
            public void openFileChooser(ValueCallback<Uri> valueCallback, String s, String s1) {
                uploadMessage = valueCallback;
                ToJumpHelp.toJumpSelctImgsActivity(JS_WebViewActivity.this, 1, YY_SelectImgsActivity.MODE_SINGLE,
                        true, true, false, true);
            }
        });

    }

    @Override
    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        switch (config.orientation) {
            case Configuration.ORIENTATION_LANDSCAPE:
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                break;
            case Configuration.ORIENTATION_PORTRAIT:
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
                break;
        }
    }

    /** 设置页面标题(js调用) */
    public void setWebViewTitle(String htmlTitle){
        h5RefreshCount ++;
        if(h5RefreshCount > 1){
            shareTitle = "";
        }
        this.htmlTitle = UtilString.f(htmlTitle);
        if (flag == 0 && !UtilString.isBlank(htmlTitle)){
            tv_titleBar_title.setText(htmlTitle);
        }
    }

    /** 设置页面描述(js调用) */
    public void setWebViewDescribe(String htmlDescribe){
        this.htmlDescribe = UtilString.f(htmlDescribe);
    }
    /**
     * 设置页面标题
     * @param titleJson  {"mainTitle" : "主要标题 , "assistantTitle" : "辅助标题"}
     *                   1,如果有主要标题就用,没有就取html的标题
     *                   2,辅助标题有就显示,没有就不显示
     */
    public void setTitles(String titleJson) {
        XCJsonBean result_bean = XCJsonParse.getJsonParseData(titleJson);
        if (result_bean == null) {
            return;
        }
        String mainTitle = result_bean.getString("mainTitle");
        String assistantTitle = result_bean.getString("assistantTitle");
        if (!UtilString.isBlank(mainTitle)){
            tv_titleBar_title.setText(mainTitle);
        }
        if (!UtilString.isBlank(assistantTitle)) {
            tv_titleBar_subTitle.setVisibility(View.VISIBLE);
            tv_titleBar_subTitle.setText(assistantTitle);
        } else {
            tv_titleBar_subTitle.setVisibility(View.GONE);
        }
    }

    /**
     * 设置右上角title回调
     * {"url":"rightButton","type":2,"name":"test17"}
     * name 按钮名字
     * type 判断按钮类型 1标示协议类型，是走咱们的协议 url是字符串
     2标示回调类型，url是js回调方法名
     * @param json
     */
    public void setTitleRightContent(String json){
        resetTitleRightLayout();
        List<XCJsonBean> result_bean = XCJsonParse.getJsonListParseData(json);
        if (result_bean == null) {
            return;
        }

        if (result_bean.size() > 0){
            // 右数第一个布局
            setTitleRightLayout(result_bean.get(0), ll_titleBar_right1, ll_titleBar_right1_image, iv_titleBar_right1, tv_titleBar_right1);
            if (result_bean.size() > 1) {
                // 右数第二个布局
                setTitleRightLayout(result_bean.get(1), ll_titleBar_right2, ll_titleBar_right2_image, iv_titleBar_right2, tv_titleBar_right2);
            }
        }
    }

    /**
     * 重置标题右侧布局
     */
    private void resetTitleRightLayout() {
        ll_titleBar_right1_image.setVisibility(View.GONE);
        tv_titleBar_right1.setVisibility(View.GONE);
        ll_titleBar_right2_image.setVisibility(View.GONE);
        tv_titleBar_right2.setVisibility(View.GONE);
    }

    /**
     * 处理标题栏右边布局
     * @param jsonBean 数据
     * @param rightLayout 右边布局
     * @param rightImageLayout 图片布局
     * @param rightImageView 图片
     * @param rightTextView 文字
     */
    private void setTitleRightLayout(XCJsonBean jsonBean, View rightLayout, View rightImageLayout, ImageView rightImageView, TextView rightTextView) {
        if (null != jsonBean) {
            final String text = jsonBean.getString("name");
            final String type = jsonBean.getString("type"); //1 是协议跳转  2 js方法
            final String linkUrl = jsonBean.getString("url");
            final String imageUrlSuffix = jsonBean.getString("imgUrl");
            final String isShowSavePublicity = jsonBean.getString("isShowSavePublicity");  //用来判断是否显示保存宣教按钮,反之出现微信和QQ都没有的情况不显示分享按钮
            String imageUrl = GlobalConfigSP.getHtml5NativePath() + "/" + imageUrlSuffix;

            if ("分享".equals(text) || "_share".equals(linkUrl)) {
                h5SetShare = true;
                Boolean wxIsInstall = UtilSystem.checkAppInstall(this, UtilSystem.WEIXIN_PACKAGE_NAME);
                Boolean qqIsInstall = UtilSystem.checkAppInstall(this, UtilSystem.MOBILEQQ_PACKAGE_NAME);
                IWXAPI wxApi = WXAPIFactory.createWXAPI(this, BuildConfig.wxKey);
                if (!wxApi.isWXAppInstalled() && !wxIsInstall && !qqIsInstall && !"1".equals(isShowSavePublicity)) {
                    return;
                }
                //start add by syy 2016/6/30 当前是公告页、且有分享按钮，显示引导图
                /*if (!UtilString.isBlank(url) && url.contains("topic=") && ("分享".equals(titleName) || "_share".equals(linkUrl))){
                    UtilsGuide.showGuide_notice(this);
                }*/
                //end add by syy 2016/6/30 当前是公告页、且有分享按钮，显示引导图
            }

            if (!UtilString.isBlank(imageUrlSuffix) && UtilFiles.fileIsExists(imageUrl)) {
                rightImageLayout.setVisibility(View.VISIBLE);
                rightTextView.setVisibility(View.GONE);
                XCApplication.displayImage("file://" + imageUrl, rightImageView);
            } else if (!UtilString.isBlank(text)){
                rightImageLayout.setVisibility(View.GONE);
                rightTextView.setVisibility(View.VISIBLE);
                rightTextView.setText(UtilString.f(text));
            }

            rightLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!UtilString.isBlank(type)) {
                        if (type.equals("1")) {
                            mNativeHtml5.webToAppPage(linkUrl);
                        } else if (type.equals("2")) {
                            webView.loadUrl("javascript:" + linkUrl + "()");
                            // created by songxin,date：2017-12-07,about：saveInfo,begin
                            BiUtil.saveBiInfo(JS_WebViewActivity.class, "2", "128", "E00085","", false);
                            // created by songxin,date：2017-12-07,about：saveInfo,end
                        }
                    }
                }
            });

        }

    }

    /**
     * 设置底部按钮
     * @param json  {"btnText":"去看看","btnLink":{"K":"value","V":"value"}}
     */
    public void setBottomBtn(String json){
        XCJsonBean result_bean = XCJsonParse.getJsonParseData(json);
        if (result_bean == null) {
            return;
        }
        String text = result_bean.getString("btnText");
        final String btnLink = result_bean.getString("btnLink");
        if (!UtilString.isBlank(text) && !UtilString.isBlank(btnLink)){
            bt_click.setText(text);
            bt_click.setVisibility(View.VISIBLE);
            bt_click.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mNativeHtml5.webToAppPage(btnLink);
                }
            });
        }
    }

    /**
     * 显示加载框
     */
    public void showLoading() {
        if (ll_loading != null) {
            ll_loading.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 关闭加载框
     */
    public void stopLoading() {
        if (ll_loading != null) {
            ll_loading.setVisibility(View.GONE);
        }
    }

    @Override
    public void onNetRefresh() {
        webView.reload();
        isErro = false;
    }

    /** 刷新页面 */
    public void reloadUrl(){
        if (webView != null) {
            webView.reload();
        }
    }

    /**
     * 设置返回键 isopne:1开启，0关闭
     * @param json {"callBack":"fuckTh","isOpen":,"1"}
     */
    public void setH5CallBack(String json){
        XCJsonBean result = XCJsonParse.getJsonParseData(json);
        if (result == null){
            return;
        }
        h5CallBack = result.getString("callBack");
        String isOpen = result.getString("isOpen");
        if ("1".equals(isOpen)){
            isCanBack = false;
        }else if ("0".equals(isOpen)){
            isCanBack = true;
        }
    }

    @Override
    public void onBackPressed() {
        if (isCanBack){
            if (webView.canGoBack()){
                webView.goBack();
            }else{
                if (!UtilString.isBlank(backJson) && !"{}".equals(backJson)){
                    NativeHtml5.newInstance(this).webToAppPage(backJson);
                    return;
                }
                super.onBackPressed();
            }
        }else{
            if (!UtilString.isBlank(h5CallBack)){
                webView.loadUrl("javascript:" + h5CallBack + "()");
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            // 如果先调用destroy()方法，则会命中if (isDestroyed()) return;这行代码，
            // 需要先onDetachedFromWindow()，再destory()
            ViewParent parent = webView.getParent();
            if (parent != null) {
                ((ViewGroup) parent).removeView(webView);
            }

            webView.stopLoading();
            // 退出时调用此方法，移除绑定的服务，否则某些特定系统会报错
            webView.getSettings().setJavaScriptEnabled(false);
            webView.clearHistory();
            webView.clearView();
//            webView.loadUrl("about:blank");
            webView.removeAllViews();

            try {
                webView.destroy();
                webView = null;
            } catch (Throwable e) {
//                e.printStackTrace();
            }
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (uploadMessage == null && uploadMessageAboveL == null) {
                return;
            }
            //拍照成功和选取照片时
            Uri imageUri;
            if (data == null || data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT) == null) {
                return;
            }
            File file =  (File) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
            File toUploadFile = UtilFile.ChangeImgsToUploadFile(file);//压缩图片
            imageUri = Uri.fromFile(toUploadFile);
            //上传文件
            if (uploadMessage != null) {
                uploadMessage.onReceiveValue(imageUri);
                uploadMessage = null;
            }
            if (uploadMessageAboveL != null) {
                uploadMessageAboveL.onReceiveValue(new Uri[]{imageUri});
                uploadMessageAboveL = null;
            }

        }else if (resultCode != RESULT_OK) { //取消拍照或者图片选择时,返回null,否则<input file> 就是没有反应
            if (uploadMessage != null) {
                uploadMessage.onReceiveValue(null);
                uploadMessage = null;
            }
            if (uploadMessageAboveL != null) {
                uploadMessageAboveL.onReceiveValue(null);
                uploadMessageAboveL = null;

            }
        }
    }
}
