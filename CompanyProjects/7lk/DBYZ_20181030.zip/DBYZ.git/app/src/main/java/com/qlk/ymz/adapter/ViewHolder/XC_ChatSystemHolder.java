package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * @author jingyu on 2016/6/25 0:29
 * @description
 */
public class XC_ChatSystemHolder {
    /**
     * 本地模拟系统消息提示视图
     */
    public TextView textview;

    public XC_ChatSystemHolder(View convertView) {
        this.textview = (TextView) convertView.findViewById(R.id.xc_id_adapter_system_notice);
    }
}
