package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import java.util.List;

/**
 * Created by songxin on 2015/6/17.
 *
 * SX_LeftDepartmentAdapter
 * 职称adapter
 * @author  Changed by songxin on 2016/3/30.
 * @version 2.3
 */
    public class SX_ProfessionalRanksAdapter extends XCBaseAdapter<XCJsonBean> {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                XCJsonBean bean = list.get(position);
                ViewHolder holder = null;

                if (convertView == null) {
                    convertView = LayoutInflater.from(context).inflate(R.layout.sx_l_adapter_professional_ranks_item, null);
                    holder = new ViewHolder();
                    holder.sx_l_adapter_professional_ranks_show = (TextView) convertView.findViewById(R.id.sx_l_adapter_professional_ranks_show);
                    holder.sx_id_adapter_professional_ranks_choose = (ImageView) convertView.findViewById(R.id.sx_id_adapter_professional_ranks_choose);
                    convertView.setTag(holder);
                } else {
                    holder = (ViewHolder) convertView.getTag();
                }
                if(list.get(position).getBoolean("isChoose")){
                    holder.sx_id_adapter_professional_ranks_choose.setImageResource(R.mipmap.sx_d_register_sure);
                }else{
                    holder.sx_id_adapter_professional_ranks_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                }
                holder.sx_l_adapter_professional_ranks_show.setText(list.get(position).getString("titleName"));
                return convertView;
            }

            public SX_ProfessionalRanksAdapter(Context context, List<XCJsonBean> list) {
                super(context, list);
            }

            class ViewHolder {
                TextView sx_l_adapter_professional_ranks_show;
                ImageView sx_id_adapter_professional_ranks_choose;
            }
        }
