package com.qlk.ymz.activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtiDoctorCheck;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.PickerView;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilNet;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.android.fw.general.view.XCSwitchButton;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * TF_VideoSettingsActivity
 * 视频咨询开关页面
 *
 * @author 王腾飞 on 2016/07/21.
 * @version 1.0
 */
public class TF_VideoSettingsActivity extends DBActivity {

    /**
     * 提示设置视频通话时间的dialog
     * add by cyr on 2016/10/17
     */
    private ConfirmDialog promptDialog;
    /**
     * 是否设置出诊时间 "0"否，"1"是
     */
    private String visitTimeStatus;
    /**
     * 标题栏
     */
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**
     * 视频咨询开关按钮
     */
    private XCSwitchButton xc_switchbutton_video;

    /**
     * 设置价格layout
     */
    private RelativeLayout tf_video_settings_price_rl;
    /**
     * 服务时间layout
     */
    private RelativeLayout tf_id_video_setvice_time_rl;
    /**
     * 显示设置价格textview
     */
    private TextView tf_video_settings_price_tv;
    /**
     * 收费单位
     */
    private TextView tf_video_settings_default_tv;
    /**
     * 下方文字说明
     */
    private TextView tf_video_settings_readme_tv;
    /**
     * 设置价格dialog
     */
    private ConfirmDialog mPriceSettingsDialog;
    /**
     * 设置价格dialog 取消按钮
     */
    private TextView tf_settings_price_cancel_tv;
    /**
     * 设置价格dialog 确定按钮
     */
    private TextView tf_settings_price_confirm_tv;
    /**
     * 设置价格dialog 选择价格控件
     */
    private PickerView tf_settings_price_pv;
    /**
     * 当前选中的价格
     */
    private String mCurrentSelect;
    /**
     * 医生是否开启视频咨询   0 关 1 开
     */
    private int mIsOpen;
    /**
     * 弹出我知道了dialog
     */
    private YR_CommonDialog mYR_commonDialog;
    /**
     * 去认证对dialog
     */
    private YR_CommonDialog mToCheckDialog;
    /**
     * 最低价格
     */
    private int mMinCharge;
    /**
     * 最高价格
     */
    private int mMaxCharge;
    /**
     * 自定义价格dialog
     */
    private ConfirmDialog setPriceDialog;
    private EditText sx_id_department_other_edit;
    private TextView sx_id_confirm_text;
    /**
     * 记录上次列表的位置
     */
    private int mLastPriceSelect;
    /**
     * 由于在操作开关按钮时需要对开、关、开连续三下没有放手不触发监听，而且需要弹出关闭时的dialog需求添加count
     */
    private int count = 0;
    /**
     * 判断xc_switchbutton_video是否向下分发
     */
    private boolean checkDown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.tf_activity_video_settings);
        super.onCreate(savedInstanceState);
    }

    /**
     * created by songxin,date：2016-8-16,about：bi,begin
     */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(TF_VideoSettingsActivity.class);
    }

    /**
     * created by songxin,date：2016-8-16,about：bi,end
     */

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleLeft(true, "");
        xc_id_model_titlebar.setTitleCenter(true, "服务设置");
        xc_id_model_titlebar.setTitleRight2(false, 0, "");
        xc_id_model_titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 闭页面前需要做两次判断
                // 1、视频预约开关是否打开
                // 2、视频预约时间是否设置(请求接口判断)
                if (mIsOpen == 1) {
                    getVisitStatus();
                } else {
                    myFinish();
                }
            }
        });

        xc_switchbutton_video = getViewById(R.id.xc_switchbutton_video);
        xc_switchbutton_video.setOnCanListener(false);
        xc_switchbutton_video.setIsDelayed(true);
        tf_video_settings_price_rl = getViewById(R.id.tf_video_settings_price_rl);
        tf_video_settings_price_tv = getViewById(R.id.tf_video_settings_price_tv);
        tf_video_settings_default_tv = getViewById(R.id.tf_video_settings_default_tv);
        tf_id_video_setvice_time_rl = getViewById(R.id.tf_id_video_setvice_time_rl);
        tf_video_settings_readme_tv = getViewById(R.id.tf_video_settings_readme_tv);
        //获取目前视频服务设置状态
        getVideoStatus();
    }

    @Override
    public void listeners() {
        //    add by tengfei  修改jira3862问题   原因用户认为是右滑开启但实际手指是向左滑进行关闭    所以在此拦截
        xc_switchbutton_video.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (!UtilNet.isNetworkAvailable(TF_VideoSettingsActivity.this)) {
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    if (UtiDoctorCheck.isFailOrNoVerfy()) {
                        showNoCheckDialog(YR_CommonDialog.HINT_TRY_VIDEO_STR, YY_PersonalDataActivityV2.class);
                        checkDown = true;
                    } else if (UtiDoctorCheck.isCheckingOrAgain()) {
                        showCheckingDialog(YR_CommonDialog.HINT_CHECKING_VIDEO_STR);
                        checkDown = true;
                    }
                }
                return checkDown;
            }
        });
        //    add by tengfei  end
        //视频服务开关按钮
        xc_switchbutton_video.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            @Override
            public void open() {
//                如果状态没有改变不进行操作
                if (mIsOpen == 1) {
                    return;
                }
                switcButtonSettings(true);
            }

            @Override
            public void close() {
                if (mIsOpen == 0) {
                    return;
                }
                switcButtonSettings(false);
            }
        });
        tf_video_settings_price_rl.setOnClickListener(this);
        tf_id_video_setvice_time_rl.setOnClickListener(this);

    }

    @Override
    public void onNetRefresh() {
        getVideoStatus();
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            //设置价格
            case R.id.tf_video_settings_price_rl: {
                createPriceSettingsDialog();
                break;
            }
            case R.id.tf_id_video_setvice_time_rl: {
                //h5页面服务时间设置
                UtilNativeHtml5.toJumpNativeH5(this, UtilNativeHtml5.NATIVE_VIDEO_BESPEAK_TIME);
                break;
            }
            case R.id.tf_settings_price_cancel_tv: {
                mPriceSettingsDialog.dismiss();
                break;
            }
            //设置视频服务价格  选择价格dialog确定按钮
            case R.id.tf_settings_price_confirm_tv: {
                defaultSettingsPriceConfirm();
                break;
            }
            //自定义价格确定按钮
            case R.id.sx_id_confirm_text: {
                userSettingsPriceConfirm();
            }

        }
    }

    //设置价格dialog确定按钮
    private void defaultSettingsPriceConfirm() {
        if (!TextUtils.isEmpty(mCurrentSelect)) {
            if (mCurrentSelect.equals("自定义")) {
                mPriceSettingsDialog.dismiss();
                //弹出自定义价格dialog
                showSetPriceDialog();
            } else {
                UtilSP.setVideoCurrentCharge(subPriceStr("元"));
                putVideoSetting(false);
                mPriceSettingsDialog.dismiss();
            }
        } else {
            UtilSP.setVideoCurrentCharge(50);
            putVideoSetting(false);
            mPriceSettingsDialog.dismiss();
        }
    }

    //自定义视频服务价格
    private void userSettingsPriceConfirm() {
        String tempInputPrice = sx_id_department_other_edit.getText().toString().trim();
        if (TextUtils.isEmpty(tempInputPrice)) {
            shortToast("视频咨询金额设置不能为空");
            return;
        }
        int inputPrice = Integer.parseInt(tempInputPrice);
        if (inputPrice < mMinCharge) {
            shortToast("视频咨询价格不能低于" + (mMinCharge) + "元");
            return;
        }
        if (inputPrice > mMaxCharge) {
            shortToast("视频咨询价格目前最高金额为" + mMaxCharge + "元");
            return;
        }
        UtilSP.setVideoCurrentCharge(inputPrice);
        tf_video_settings_price_tv.setText(inputPrice + "");
        putVideoSetting(false);
        setPriceDialog.dismiss();
    }

    /**
     * 获得视频设置的状态
     */
    public void getVideoStatus() {
        RequestParams params = new RequestParams();
        params.put("type", 4);// 收费类型1：图文，2：电话   4:视频咨询
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.videoCharge_query), params, new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                //提示状态改变
                if (result_boolean) {
                    XCJsonBean bean = result_bean.getList("data").get(0);
                    mIsOpen = bean.getInt("open");
                    //收费开关
                    UtilSP.setVideoIsOpen(mIsOpen);
                    //当前收费价格，单位：分
                    UtilSP.setVideoCurrentCharge(bean.getInt("currentcharge") / 100);
                    // 最高价，单位：分
                    UtilSP.setVideoMaxCharge(bean.getInt("maxcharge") / 100);
                    //最低价,单位：分
                    UtilSP.setVideoMinCharge(bean.getInt("mincharge") / 100);
                    //收费单位
                    String chargeUnit = bean.getString("chargeunit");
                    UtilSP.setVideoChargeUnit(chargeUnit);
                    //可设置 固定收费额，单位：分
                    List<Integer> list = bean.getIntegerList("charges");
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("自定义,");
                    for (Integer integer : list) {
                        stringBuilder.append(integer / 100 + chargeUnit + ",");
                    }
                    UtilSP.setVideoCharges(stringBuilder.toString());
                    UtilSP.setVideoChargeDesc(bean.getString("chargeDesc"));

                    visitTimeStatus = bean.getString("status");
                }
                refreshVideoSettingsUI();
            }

        });
    }

    /**
     * TODO
     * 判断出诊时间状态
     * 暂时由前端判断，后期优化成H5
     */
    public void getVisitStatus() {
        RequestParams params = new RequestParams();
        params.put("type", 4);// 收费类型1：图文，2：电话   4:视频咨询
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.videoCharge_query), params, new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    XCJsonBean bean = result_bean.getList("data").get(0);
                    visitTimeStatus = bean.getString("status");
                    if ("0".equals(visitTimeStatus)) {
                        initPromptDialog();
                    } else {
                        myFinish();
                    }
                }
            }

        });
    }


    /**
     * 点击视频设置开关按钮设置
     *
     * @param buttonStatus 改变后的状态
     */
    private void switcButtonSettings(boolean buttonStatus) {
        if (buttonStatus) {
            mIsOpen = 1;
            //提交服务器
            putVideoSetting(false);
        } else {
            if (mYR_commonDialog == null) {
                mYR_commonDialog = new YR_CommonDialog(TF_VideoSettingsActivity.this, "关闭后，患者已经预约的视频服务依旧生效！", "", "我知道了") {
                    @Override
                    public void confirmBtn() {
                        mYR_commonDialog.dismiss();
                    }
                };
            }
            mYR_commonDialog.show();
            mIsOpen = 0;
            //提交服务器
            putVideoSetting(false);
        }
    }

    /**
     * 提交视频收费设置
     *
     * @param isFinish 是否是关闭页面时的请求操作
     *                 <p>
     *                 update by cyr on 2016/10/18  添加isFinish参数
     */
    private void putVideoSetting(final boolean isFinish) {
        RequestParams requestParams = new RequestParams();
        //设置价格不更改收费开关状态
        requestParams.put("open", mIsOpen);
        requestParams.put("charge", UtilSP.getVideoCurrentCharge() * 100);
        requestParams.put("type", 4);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.videoCharge_setting), requestParams, new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    //保存状态
                    UtilSP.setVideoIsOpen(mIsOpen);

                    if (isFinish) {//点击设置服务时间提示dialog退出按钮时的操作
                        TF_VideoSettingsActivity.this.finish();
                        return;
                    }
                    //设置视频价格
                    tf_video_settings_price_tv.setText(String.valueOf(UtilSP.getVideoCurrentCharge()));
                    videoServiceIsOpen();
                }
            }
        });
    }

    /**
     * 状态改变时更新页面
     */
    private void videoServiceIsOpen() {
        if (mIsOpen == 1) {
            xc_switchbutton_video.setState(true);
            tf_video_settings_price_rl.setVisibility(View.VISIBLE);
            tf_id_video_setvice_time_rl.setVisibility(View.VISIBLE);
            tf_video_settings_readme_tv.setVisibility(View.VISIBLE);

        } else {
            xc_switchbutton_video.setState(false);
            tf_video_settings_price_rl.setVisibility(View.GONE);
            tf_id_video_setvice_time_rl.setVisibility(View.GONE);
            tf_video_settings_readme_tv.setVisibility(View.GONE);

        }
    }

    private void refreshVideoSettingsUI() {
        //设置视频开关
        videoServiceIsOpen();
        //设置当前价格
        tf_video_settings_price_tv.setText(UtilSP.getVideoCurrentCharge() + "");
        //设置收费单位
        tf_video_settings_default_tv.setText(UtilSP.getVideoChargeUnit());
        //设置收费描述
        String videoChargeDesc = UtilSP.getVideoChargeDesc();
        //最高最低价格
        mMinCharge = UtilSP.getVideoMinCharge();
        mMaxCharge = UtilSP.getVideoMaxCharge();
        //设置下方提示文本
        StringBuilder stringBuilder1 = new StringBuilder();
        String chargeDesc1;
        boolean flag = true;
        //返回的字符串不能够换行  进行换行
        while (flag) {
            int index = videoChargeDesc.indexOf("\\n");
            if (index != -1) {
                chargeDesc1 = videoChargeDesc.substring(0, index);
                videoChargeDesc = videoChargeDesc.substring(index + 2, videoChargeDesc.length());
                stringBuilder1.append(chargeDesc1 + " \n");
                XCApplication.base_log.i("videosettings", "videoChargeDesc" + videoChargeDesc);
            } else {
                stringBuilder1.append(videoChargeDesc);
                flag = false;
                tf_video_settings_readme_tv.setText(stringBuilder1.toString());
            }
        }

    }

    /**
     * 显示认证中对话框
     *
     * @param hint message中显示文字
     */
    private void showCheckingDialog(String hint) {
        mToCheckDialog = new YR_CommonDialog(TF_VideoSettingsActivity.this, hint, "", "我知道了") {
            @Override
            public void confirmBtn() {
                mToCheckDialog.dismiss();
            }
        };
        mToCheckDialog.show();
    }

    /**
     * 去认证对话框
     * @param hint 提示文字
     * @param cls  点击去认证
     */
    private void showNoCheckDialog(String hint, final Class<? extends XCBaseActivity> cls) {
        mToCheckDialog = new YR_CommonDialog(TF_VideoSettingsActivity.this, hint, "暂不认证", "去认证") {
            @Override
            public void confirmBtn() {
                mToCheckDialog.dismiss();
                myStartActivity(cls);
            }
        };
        mToCheckDialog.show();
    }

    /**
     * 创建选择价格对话框
     */
    private void createPriceSettingsDialog() {
        if (mPriceSettingsDialog == null) {
            //初始化选择价格dialog
            int srceenW = this.getWindowManager().getDefaultDisplay().getWidth();
            mPriceSettingsDialog = new ConfirmDialog(TF_VideoSettingsActivity.this, srceenW, 260, R.layout.tf_dialog_video_settings_price, R.style.xc_s_dialog);
            tf_settings_price_cancel_tv = (TextView) mPriceSettingsDialog.findViewById(R.id.tf_settings_price_cancel_tv);
            tf_settings_price_confirm_tv = (TextView) mPriceSettingsDialog.findViewById(R.id.tf_settings_price_confirm_tv);
            tf_settings_price_pv = (PickerView) mPriceSettingsDialog.findViewById(R.id.tf_settings_price_pv);
            mPriceSettingsDialog.setCanceledOnTouchOutside(false);
            Window window = mPriceSettingsDialog.getWindow();
            window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
            List<String> mPrices = new ArrayList<>();
            String charge = UtilSP.getVideoCharges();
            String[] charges = charge.split(",");
            int count = charges.length;
            for (int i = 0; i < count; i++) {
                mPrices.add(charges[i]);
            }
            tf_settings_price_pv.setData(mPrices);
            /** dialog取消*/
            tf_settings_price_cancel_tv.setOnClickListener(this);
            /** dialog确定*/
            tf_settings_price_confirm_tv.setOnClickListener(this);
            /** 选择价格选择 */
            tf_settings_price_pv.setOnSelectListener(new PickerView.onSelectListener() {
                @Override
                public void onSelect(String text) {
                    mCurrentSelect = text;
                }
            });
            mPriceSettingsDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialog) {
                    if (!TextUtils.isEmpty(mCurrentSelect)) {
                        tf_settings_price_pv.setSelected(mCurrentSelect);
                    }
                }
            });
        }
        tf_settings_price_pv.setSelected(UtilSP.getVideoCurrentCharge() + UtilSP.getVideoChargeUnit());
        mPriceSettingsDialog.show();
    }

    /**
     * 自定义价格dialog
     */
    private void showSetPriceDialog() {
        if (setPriceDialog == null) {
            int srceenW = this.getWindowManager().getDefaultDisplay().getWidth();
            setPriceDialog = new ConfirmDialog(TF_VideoSettingsActivity.this, srceenW, 55
                    , R.layout.sx_l_dialog_department_item_other, R.style.xc_s_dialog);
            setPriceDialog.setCanceledOnTouchOutside(true);
            Window window = setPriceDialog.getWindow();
            window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
            sx_id_department_other_edit = (EditText) setPriceDialog.findViewById(R.id.sx_id_department_other_edit);
            //设置edittext输入类型
            sx_id_department_other_edit.setInputType(EditorInfo.TYPE_CLASS_NUMBER);
            //控制输入长度
            sx_id_department_other_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter((mMaxCharge + "").length())});
            sx_id_department_other_edit.setHint("自定义价格为" + mMinCharge + "—" + mMaxCharge + "元");
            sx_id_confirm_text = (TextView) setPriceDialog.findViewById(R.id.sx_id_confirm_text);
            //确定按钮监听
            sx_id_confirm_text.setOnClickListener(this);
        }
        setPriceDialog.show();
        //获取焦点
        sx_id_department_other_edit.setFocusableInTouchMode(true);
        sx_id_department_other_edit.requestFocus();
        //弹出软键盘
        UtilInputMethod.openInputMethod(sx_id_department_other_edit, TF_VideoSettingsActivity.this);

    }

    //add  by cyr on 2016/10/17  如果预约视频没有设置时间，则弹出dialog提示去设置
    public void initPromptDialog() {
        if (promptDialog == null) {
            int srceenW = this.getWindowManager().getDefaultDisplay().getWidth();
            promptDialog = new ConfirmDialog(this, srceenW, 180
                    , R.layout.sx_l_custom_dialog, R.style.xc_s_dialog);
            promptDialog.setCanceledOnTouchOutside(false);
            TextView sx_id_cancel_button = (TextView) promptDialog.findViewById(R.id.sx_id_cancel_button);
            TextView sx_id_confirm_button = (TextView) promptDialog.findViewById(R.id.sx_id_confirm_button);
            ((TextView) promptDialog.findViewById(R.id.sx_id_custom_text)).setText("没有设置预约时间，现在退出将无法开通服务!");
            sx_id_cancel_button.setText("仍然退出");
            sx_id_confirm_button.setText("去设置");
            sx_id_cancel_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mIsOpen = 0;
                    putVideoSetting(true);
                }
            });
            sx_id_confirm_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    UtilNativeHtml5.toJumpNativeH5(TF_VideoSettingsActivity.this, UtilNativeHtml5.NATIVE_VIDEO_BESPEAK_TIME);
                    promptDialog.dismiss();
                }
            });
        }
        promptDialog.show();
    }

    //剪切字符串
    private int subPriceStr(String subString) {
        String price = mCurrentSelect.substring(0, mCurrentSelect.indexOf(subString));
        return Integer.parseInt(price);
    }


    @Override
    protected void onStop() {
        super.onStop();
        if (mToCheckDialog != null && mToCheckDialog.isShowing()) {
            mToCheckDialog.dismiss();
        }
    }

    public void onBackPressed() {
        if (mIsOpen == 1) {
            getVisitStatus();
        } else {
            myFinish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mYR_commonDialog,mToCheckDialog,mPriceSettingsDialog,setPriceDialog,promptDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
    }
}
