package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.contrarywind.view.WheelView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.InspectOrdonnanceItemAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.ExamineBean;
import com.qlk.ymz.model.SK_RecommendInfo;
import com.qlk.ymz.model.SQ_InspectSRActivityLaunchModel;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.parse.Parser2InspectInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.UtilInsertMsg2JsDb;
import com.qlk.ymz.util.UtilPackMsg;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ArrayTextWheelAdapter;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.SQ_SexChoiceDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCKeyBoardLayout;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 推荐检查单
 *
 * @author WuPuquan.  WangYong
 * @version 1.0
 */

public class InspectOrdonnanceActivity extends DBActivity {

    /**
     * 检查方式3列显示
     */
    public static final int INSPECT_MODE_SPAN_COUNT = 3;
    private XCKeyBoardLayout keyboard_layout;
    private XCTitleCommonLayout title_common_layout;
    /**
     * 编号
     */
    private TextView tv_number;
    /**
     * 时间
     */
    private TextView tv_date;
    /**
     * 姓名
     */
    private EditText tv_patient_name;
    /**
     * 性别
     */
    private TextView tv_patient_sex;
    /**
     * 性别选择对话框
     */
    private SQ_SexChoiceDialog sexChoiceDialog;
    /**
     * 年龄
     */
    private TextView tv_patient_age;
    /**
     * 既往病史
     */
    private TextView et_medical_history;
    /**
     * 病理及体征
     */
    private TextView et_pathology;
    /**
     * 相关检查结果
     */
    private TextView et_inspection_result;
    /**
     * 临床诊断
     */
    private TextView et_diagnose;
    /**
     * 检查项目
     */
    private ListView lv_inspect_item;
    /**
     * 加号
     */
    private ImageView iv_add;
    /**
     * 医师
     */
    private TextView tv_doctor;
    /**
     * 科室
     */
    private TextView tv_department;
    /**
     * 发送
     */
    private TextView tv_send;
    /**
     * 屏幕宽
     */
    private int mScreenWidth = 720;
    /**
     * 选择年龄对话框
     */
    private ConfirmDialog mSetAgeDialog;

    /**
     * 选择年龄控件
     */
    private WheelView mWheelView;
    /**
     * 选择年龄对话框取消按钮
     */
    private TextView tv_set_age_cancel;
    /**
     * 选择年龄对话框确定按钮
     */
    private TextView tv_set_age_confirm;

    private SK_RecommendInfo recommendInfo;
    // 检查项目
    private InspectOrdonnanceItemAdapter mItemAdapter;
    private Context mContext;
    // 既往病史
    public static final int REQUEST_CODE_MEDHISTORY = 101;
    // 病理特征
    public static final int REQUEST_CODE_PATHOLOGY = 102;
    // 相关检查结果
    public static final int REQUEST_CODE_INSPECT = 103;
    // 临床诊断
    public static final int REQUEST_CODE_DIAGNOSE = 104;
    // 既往病史布局
    private LinearLayout medical_history_layout;
    //病理及特征布局
    private LinearLayout pathology_layout;
    //相关检查结果布局
    private LinearLayout inspection_result_layout;
    // 临床诊断布局
    private LinearLayout ordonnance_diagnose_layout;
    // 编辑
    private TextView ordonnance_edit;
    // 编辑按钮对应的当前文案，true ： 编辑，false：完成
    private boolean isEdit = true;
    private ArrayList<DiagnoseBean> diagnosisList = new ArrayList<>();
    private SQ_InspectSRActivityLaunchModel inspectInfo;
    // 聊天实体类
    private XC_ChatModel chatModel;
    /**
     * 检查是否勾选的map集合
     */
    private Map<String, Boolean> checkMap = new HashMap<>();
    // 勾选的检查集合
    private List<ExamineBean> examineBeanList = new ArrayList<>();

    public static void launch(Context context, SQ_InspectSRActivityLaunchModel inspectInfo) {
        Intent intent = new Intent(context, InspectOrdonnanceActivity.class);
        intent.putExtra(SQ_InspectSRActivityLaunchModel.LAUNCH_CODE, inspectInfo);
        ((Activity) context).startActivityForResult(intent,SQ_InspectSRActivityLaunchModel.REQUEST_INSPECT);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_inspect_ordonnance);
        mContext = this;
        super.onCreate(savedInstanceState);

    }

    /** created by songxin,date：2017-10-30,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(InspectOrdonnanceActivity.class);
    }

    /** created by songxin,date：2017-10-30,about：bi,end */

    @Override
    public void initWidgets() {
        getData();
        keyboard_layout = getViewById(R.id.keyboard_layout);
        title_common_layout = getViewById(R.id.title_common_layout);
        title_common_layout.getXc_id_titlebar_center_textview().setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        title_common_layout.setTitleLeft(true, null);
        title_common_layout.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returnToChoiceInspectActivity();
            }
        });
        lv_inspect_item = getViewById(R.id.lv_inspect_item);
        tv_send = getViewById(R.id.tv_send);
        //检查申请单的HeadView的控件初始化
        View inspect_ordonnance_headview = getLayoutInflater().inflate(R.layout.inspect_ordonnance_headview, null);
        tv_number = (TextView) inspect_ordonnance_headview.findViewById(R.id.ym_ordonnance_number);
        tv_date = (TextView) inspect_ordonnance_headview.findViewById(R.id.ordonnance_patient_date);
        tv_patient_name = (EditText) inspect_ordonnance_headview.findViewById(R.id.ym_ordonnance_patient_name);
        tv_patient_age = (TextView) inspect_ordonnance_headview.findViewById(R.id.ym_ordonnance_patient_age);
        tv_patient_sex = (TextView) inspect_ordonnance_headview.findViewById(R.id.ym_ordonnance_patient_sex);
        et_medical_history = (TextView) inspect_ordonnance_headview.findViewById(R.id.et_medical_history);
        et_pathology = (TextView) inspect_ordonnance_headview.findViewById(R.id.et_inspect_ordonnance_pathology);
        et_inspection_result = (TextView) inspect_ordonnance_headview.findViewById(R.id.et_inspect_ordonnance_inspection_result);
        et_diagnose = (TextView) inspect_ordonnance_headview.findViewById(R.id.et_inspect_ordonnance_diagnose);
        ordonnance_edit = (TextView) inspect_ordonnance_headview.findViewById(R.id.sq_id_ordonnance_edit);
        medical_history_layout = (LinearLayout) inspect_ordonnance_headview.findViewById(R.id.ym_ordonnance_diacrisis_rl);
        pathology_layout = (LinearLayout) inspect_ordonnance_headview.findViewById(R.id.inspect_ordonnance_pathology_layout);
        inspection_result_layout = (LinearLayout) inspect_ordonnance_headview.findViewById(R.id.inspect_ordonnance_inspection_result_layout);
        ordonnance_diagnose_layout = (LinearLayout) inspect_ordonnance_headview.findViewById(R.id.inspect_ordonnance_diagnose_layout);

        //检查申请单的FootView的控件初始化
        View inspect_ordonnance_footview = getLayoutInflater().inflate(R.layout.inspect_ordonnance_foot, null);
        iv_add = (ImageView) inspect_ordonnance_footview.findViewById(R.id.ym_ordonnance_medicines_add);
        tv_doctor = (TextView) inspect_ordonnance_footview.findViewById(R.id.ym_ordonnance_doctor_name);
        tv_department = (TextView) inspect_ordonnance_footview.findViewById(R.id.ym_ordonnance_department_name);

        lv_inspect_item.addHeaderView(inspect_ordonnance_headview);
        lv_inspect_item.addFooterView(inspect_ordonnance_footview);

        sexChoiceDialog = new SQ_SexChoiceDialog(mContext);
        sexChoiceDialog.getWindow().setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        sexChoiceDialog.setSexChangeListener(new SQ_SexChoiceDialog.SexChangeListener() {
            @Override
            public void onSexChange(String sex) {
                tv_patient_sex.setText(sex);
            }
        });
        // 检查项目
        mItemAdapter = new InspectOrdonnanceItemAdapter(mContext, examineBeanList);
        lv_inspect_item.setAdapter(mItemAdapter);
        initData();
        initSetAgeDialog();
    }

    @Override
    public void listeners() {
        ordonnance_edit.setOnClickListener(this);
        tv_patient_name.setOnClickListener(this);
        tv_patient_age.setOnClickListener(this);
        tv_patient_sex.setOnClickListener(this);
        medical_history_layout.setOnClickListener(this);
        pathology_layout.setOnClickListener(this);
        inspection_result_layout.setOnClickListener(this);
        ordonnance_diagnose_layout.setOnClickListener(this);
        iv_add.setOnClickListener(this);
        tv_send.setOnClickListener(this);

        mItemAdapter.setOnInspectItemListener(new InspectOrdonnanceItemAdapter.OnInspectItemListener() {
            @Override
            public void onItemDeleted(final int pos) {
                new YR_CommonDialog(mContext, "请确认是否删除", "取消", "确认") {

                    @Override
                    public void confirmBtn() {
                        checkMap.put(examineBeanList.get(pos).getId(),false);
                        examineBeanList.remove(pos);
                        if (examineBeanList.size() == 0) {
                            ordonnance_edit.setVisibility(View.GONE);
                        }
                        mItemAdapter.notifyDataSetChanged();
                        dismiss();
                    }
                }.show();
            }
        });
    }
    private List<String> getAgeData() {
        List<String> ages = new ArrayList<>();
        for (int i = 1; i<5 ;i++){
            ages.add(i + "周");
        }
        for (int i = 1; i<13;i++){
            ages.add(i + "个月");
        }
        for (int i = 1;i<121 ; i++){
            ages.add(i + "岁");
        }
        return ages;
    }

    /**
     * 初始化选择年龄对话框
     */
    private void initSetAgeDialog() {
        final List<String> ageData = getAgeData();
        mScreenWidth = UtilScreen.getScreenWidthPx(this);
        mSetAgeDialog = new ConfirmDialog(this, mScreenWidth, R.layout
                .dialog_roll_select, R.style.xc_s_dialog);
        mSetAgeDialog.setCanceledOnTouchOutside(false);
        Window window = mSetAgeDialog.getWindow();
        window.setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        mWheelView = (WheelView) mSetAgeDialog.findViewById(R.id.wheelview);
        tv_set_age_cancel = (TextView) mSetAgeDialog.findViewById(R.id.tv_set_price_cancel);
        tv_set_age_confirm = (TextView) mSetAgeDialog.findViewById(R.id.tv_set_price_confirm);
        mWheelView.setCyclic(false);//不循环
        mWheelView.setAdapter(new ArrayTextWheelAdapter(ageData));
        tv_set_age_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mSetAgeDialog.dismiss();
            }
        });
        tv_set_age_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_patient_age.setText(ageData.get(mWheelView.getCurrentItem()));
                saveAge();
                mSetAgeDialog.dismiss();
            }
        });
        mSetAgeDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                String mAge = recommendInfo.getPatientAge() + recommendInfo.getPatientAgeUnit();
                if(UtilString.toInt(recommendInfo.getPatientAge()) > 120 || UtilString.isBlank(mAge)){
                    mAge = "1岁";
                }
                for(int i=0;i<ageData.size();i++){
                    if(mAge.equals(ageData.get(i))){
                        mWheelView.setCurrentItem(i);
                    }
                }
            }
        });
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ym_ordonnance_patient_age:
                mSetAgeDialog.show();
                break;
            case R.id.ym_ordonnance_patient_sex:
                sexChoiceDialog.setSexString(tv_patient_sex.getText().toString());
                sexChoiceDialog.show();

                break;
            case R.id.ym_ordonnance_diacrisis_rl:
                String history = et_medical_history.getText().toString();
                String max = "";
                if(recommendInfo.getAnamnesisLimit()!= null){
                    max = recommendInfo.getAnamnesisLimit().getMax();
                }
                launch("既往病史", history, max ,REQUEST_CODE_MEDHISTORY);
                break;
            case R.id.inspect_ordonnance_pathology_layout:
                String pathology = et_pathology.getText().toString();
                String pathMax = "";
                if(recommendInfo.getSymptomsLimit() != null){
                    pathMax = recommendInfo.getSymptomsLimit().getMax();
                }
                launch("病理及体征", pathology, pathMax,REQUEST_CODE_PATHOLOGY);
                break;
            case R.id.inspect_ordonnance_inspection_result_layout:
                String inspect_result = et_inspection_result.getText().toString();
                String relateMax = "";
                if(recommendInfo.getRelatedExamineLimit() != null){
                    relateMax = recommendInfo.getRelatedExamineLimit().getMax();
                }
                launch("相关检查结果", inspect_result,relateMax, REQUEST_CODE_INSPECT);
                break;
            case R.id.inspect_ordonnance_diagnose_layout:
                DrCaseVOBean drCaseVOBean = new DrCaseVOBean();
                drCaseVOBean.setDoctorId(UtilSP.getUserId());
                drCaseVOBean.setDepartment(UtilSP.getDepartmentName());
                drCaseVOBean.setPatientId(chatModel.getUserPatient().getPatientId());
                saveRecommendInfo();
                drCaseVOBean.setGender(recommendInfo.getPatientGender());
                drCaseVOBean.setAge(recommendInfo.getPatientAge());
                drCaseVOBean.setAgeUnit(recommendInfo.getPatientAgeUnit());
                drCaseVOBean.setPastHistory(inspectInfo.getMedicalHistory());
                NativeHtml5.drCaseVOBean = drCaseVOBean;
                startActivityForResult(DiagnoseActivity.newIntent(this, diagnosisList), REQUEST_CODE_DIAGNOSE);
                overridePendingTransition(R.anim.activity_open_up, R.anim.activity_no_move);
                break;
            case R.id.sq_id_ordonnance_edit:
                UtilInputMethod.hiddenInputMethod(mContext);
                if (isEdit) {
                    ordonnance_edit.setText("完成");
                    isEdit = false;
                    mItemAdapter.showDelete();
                } else {
                    ordonnance_edit.setText("编辑");
                    isEdit = true;
                    mItemAdapter.hideDelete();
                    if (examineBeanList.size() == 0) {
                        ordonnance_edit.setVisibility(View.GONE);
                    }
                }
                break;
            case R.id.ym_ordonnance_medicines_add:
                returnToChoiceInspectActivity();
                break;
            // 发送
            case R.id.tv_send:
                // created by songxin,date：2017-10-30,about：saveInfo,begin
                BiUtil.saveBiInfo(InspectOrdonnanceActivity.class, "2", "128", "inspect_ordonnance_send","", false);
                // created by songxin,date：2016-10-30,abou t：saveInfo,end
                send();
                break;
        }
    }

    /**
     * 2.9版本需求
     * 获取患者姓名更新患者数据库
     */
    public void requestPatientSimple() {
        RequestParams params = new RequestParams();
        params.put("patientId", chatModel.getUserPatient().getPatientId());

        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.patientSimple), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {

                    try {

                        // id (integer),
                        // name (string): 患者姓名或昵称 ,
                        // remarkName (string): 患者备注名

                        JS_ChatListModel chatListModel = JS_ChatListDB.getInstance(context, UtilSP.getUserId()).getPatientInfo(chatModel.getUserPatient().getPatientId());
                        chatListModel.getUserPatient().setPatientName(result_bean.getList("data").get(0).getString("name"));
                        chatListModel.getUserPatient().setPatientMemoName(result_bean.getList("data").get(0).getString("remarkName"));
                        JS_ChatListDB.getInstance(context, UtilSP.getUserId()).updatePatientInfo(chatListModel);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 创建发送检查单的请求
     */
    private void createQuest() {
        RequestParams params = new RequestParams();
        String str = UtilIMCreateJson.createInspectJson(inspectInfo);
        params.put("recomParam", str);
        XCHttpAsyn.postAsync(true,true,mContext, AppConfig.getTuijianUrl(AppConfig.sendInspect+ "?doctorId="+UtilSP.getUserId()+
                        "&token="+UtilSP.getUserToken()),str, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean.getList("data").get(0).getBoolean("changedRemarkName")) {
                        requestPatientSimple();
                    }
                    savePatientDrugInfo();
                    XC_ChatModel chatModel = UtilPackMsg.packCheckHealthMsg(inspectInfo);
                    chatModel.setSessionBeginTime(result_bean.getList("data").get(0).getString("beginTime"));
                    chatModel.setMessageId(result_bean.getList("data").get(0).getString("messageId"));
                    chatModel.setRecommandId(result_bean.getList("data").get(0).getString("recomId"));
                    chatModel.setMsgTime(result_bean.getList("data").get(0).getString("sendTime"));
                    chatModel.setSessionId(result_bean.getList("data").get(0).getString("sessionId"));
                    chatModel.getChatSession().setConsultSourceType(result_bean.getList("data").get(0).getString("consultSourceType"));
                    chatModel.setSessionJson(UtilIMCreateJson.createSessionJson(chatModel));
                    XCChatModelDb.getInstance(getApplicationContext(), UtilSP.getIMDetailDbName(chatModel.getUserDoctor().getDoctorSelfId(), chatModel.getUserPatient().getPatientId())).insert(chatModel);
                    UtilInsertMsg2JsDb.insert(getApplicationContext(), chatModel);
                    UtilChat.launchChatDetail(InspectOrdonnanceActivity.this, chatModel.getUserPatient().getPatientId(), null);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    private void savePatientDrugInfo() {
        inspectInfo.setExamineBeanList(examineBeanList);
        inspectInfo.setChatModel(chatModel);//防止chatModel为null
        inspectInfo.getChatModel().setDiagnosis(et_diagnose.getText().toString().trim());

    }

    private void saveRecommendInfo() {
        // 既往病史
        String medicalHistory = et_medical_history.getText().toString().trim();
        // 病理及体征
        String pathology = et_pathology.getText().toString().trim();
        // 相关检查结果
        String inspectionResult = et_inspection_result.getText().toString().trim();
        inspectInfo.setMedicalHistory(medicalHistory);
        inspectInfo.setPathology(pathology);
        inspectInfo.setInspectionResult(inspectionResult);
        recommendInfo.setPatientName(tv_patient_name.getText().toString().trim());
        saveAge();
        // 患者性别：0.女 1.男
        int gender;
        if ("女".equals(tv_patient_sex.getText().toString().trim())) {
            gender = 0;
        } else {
            gender = 1;
        }
        recommendInfo.setPatientGender(gender + "");
        inspectInfo.setRecommendInfo(recommendInfo);
    }

    private void saveAge() {
        String age = tv_patient_age.getText().toString().trim();
        if(age.contains("周")){
            recommendInfo.setPatientAgeUnit("周");
            recommendInfo.setPatientAge(UtilString.getStringWithoutLast(age,"周"));
        }else if(age.contains("个月")){
            recommendInfo.setPatientAgeUnit("个月");
            recommendInfo.setPatientAge(UtilString.getStringWithoutLast(age,"个月"));
        }else if(age.contains("岁")){
            recommendInfo.setPatientAgeUnit("岁");
            recommendInfo.setPatientAge(UtilString.getStringWithoutLast(age,"岁"));
        }
    }

    /**
     * 从intent获取数据
     */
    private void getData() {
        inspectInfo = (SQ_InspectSRActivityLaunchModel) getIntent().getSerializableExtra(SQ_InspectSRActivityLaunchModel.LAUNCH_CODE);
        if (inspectInfo.getDiagnosisList() != null) {
            diagnosisList = (ArrayList<DiagnoseBean>) inspectInfo.getDiagnosisList();
        }
        recommendInfo = inspectInfo.getRecommendInfo();
        if (recommendInfo == null || UtilString.isBlank(recommendInfo.getTitle())) {
            recommendInfo = new SK_RecommendInfo();
            requestExamineInitData();
        }
        checkMap = inspectInfo.getCheckMap();
        examineBeanList = inspectInfo.getExamineBeanList();
        chatModel = inspectInfo.getChatModel();
    }

    /**
     * 将检查申请数据返回给选择检查页
     */
    private void returnToChoiceInspectActivity() {
        try {
            savePatientDrugInfo();
            saveRecommendInfo();
            Intent it = new Intent();
            it.putExtra(SQ_InspectSRActivityLaunchModel.LAUNCH_CODE, inspectInfo);
            setResult(Activity.RESULT_OK, it);
            myFinish();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 设置临床诊断
     */
    private void setDiagnosisText() {
        String diagnosisStr = "";
        for (int i = 0; i < diagnosisList.size(); i++) {
            if (i == diagnosisList.size() - 1) {
                diagnosisStr = diagnosisStr + diagnosisList.get(i).name;
            } else {
                diagnosisStr = diagnosisStr + diagnosisList.get(i).name + ",";
            }
        }
        et_diagnose.setText(diagnosisStr);
    }

    /**
     * 获取检查申请单初始化信息
     */
    public void requestExamineInitData() {
        RequestParams params = new RequestParams();
        params.put("patientId", inspectInfo.getChatModel().getUserPatient().getPatientId());
        XCHttpAsyn.postAsyn(mContext, AppConfig.getTuijianUrl(AppConfig.examineFormInit), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    Parser2InspectInfo parser2SQRecommendInfo = new Parser2InspectInfo(recommendInfo);
                    parser2SQRecommendInfo.parseJson(result_bean);
                    initData();
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 赋值检查申请单数据
     */
    private void initData() {
        if (examineBeanList.size() == 0) {
            ordonnance_edit.setVisibility(View.GONE);
        }
        title_common_layout.setTitleCenter(true, recommendInfo.getTitle());
        if (chatModel == null) {
            chatModel = new XC_ChatModel();
        }
        String patientGender = recommendInfo.getPatientGender() + "";
        if (CommonConfig.GENDER_MALE.equals(patientGender)) {
            patientGender = "男";
        } else if (CommonConfig.GENDER_FEMALE.equals(patientGender)) {
            patientGender = "女";
        } else {
            patientGender = "";
        }
        try {
            String date = DateFormat.format("时间: " + "yyyy/MM/dd", Long.parseLong(recommendInfo.getRecomTime())).toString();
            // 编号
            tv_number.setText(fromHtml("编号：", recommendInfo.getSerialNumber()));
            // 时间
            tv_date.setText(fromHtml("", date));
            // 姓名
            tv_patient_name.setText(recommendInfo.getPatientName());
            // 年龄
            tv_patient_age.setText(fromHtml("", recommendInfo.getPatientAge() + recommendInfo.getPatientAgeUnit()));
            // 性别
            tv_patient_sex.setText(fromHtml("", patientGender));
            // 医师
            tv_doctor.setText(recommendInfo.getDoctorName());
            // 科室
            tv_department.setText(recommendInfo.getDepartmentName());
            et_medical_history.setText(inspectInfo.getMedicalHistory());
            et_pathology.setText(inspectInfo.getPathology());
            et_inspection_result.setText(inspectInfo.getInspectionResult());
            setDiagnosisText();
            mItemAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 改变部分字体颜色
     *
     * @param prefix 前半部分，如：编号
     * @param target 后半部分，如：编号value
     */
    private Spanned fromHtml(String prefix, String target) {
        return Html.fromHtml("<font color='#7b7b7b'>" + prefix + "</font><font color='#444444'>" + target + "</font>");
    }

    /**
     * 发送
     */
    private void send() {
        saveRecommendInfo();
        if (UtilString.isBlank(tv_patient_name.getText().toString().trim())) {
            shortToast("请完整填写患者信息后提交");
            return;
        }
        if (UtilString.isBlank(tv_patient_age.getText().toString().trim())) {
            shortToast("请完整填写患者信息后提交");
            return;
        }
        if (UtilString.isBlank(tv_patient_sex.getText().toString().trim())) {
            shortToast("请完整填写患者信息后提交");
            return;
        }
        if (StringUtils.containsEmoji(et_medical_history.getText().toString())) {
            shortToast("既往病史不能包含有特殊字符");
            return;
        }
        if (StringUtils.containsEmoji(et_pathology.getText().toString())) {
            shortToast("病历及体征不能包含有特殊字符");
            return;
        }
        if (StringUtils.containsEmoji(et_inspection_result.getText().toString())) {
            shortToast("相关检查结果不能包含有特殊字符");
            return;
        }
        if (examineBeanList.size() == 0) {
            shortToast("请选择检查项");
            return;
        }
        createQuest();
    }

    private void launch(String title, String str, String max , int requestCode) {
        UtilInputMethod.hiddenInputMethod(mContext);
        Intent intent = new Intent(mContext, ExamineContentActivity.class);
        intent.putExtra(ExamineContentActivity.EXAMINE_TITLE, title);
        intent.putExtra(ExamineContentActivity.CONTENTSTR, str);
        intent.putExtra(ExamineContentActivity.MAXLENGTH, max);
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        String str = data.getStringExtra(ExamineContentActivity.CONTENTSTR);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case REQUEST_CODE_MEDHISTORY:
                    et_medical_history.setText(str);
                    inspectInfo.setMedicalHistory(str);
                    break;
                case REQUEST_CODE_PATHOLOGY:
                    et_pathology.setText(str);
                    inspectInfo.setPathology(str);
                    break;
                case REQUEST_CODE_INSPECT:
                    et_inspection_result.setText(str);
                    inspectInfo.setInspectionResult(str);
                    break;
                case REQUEST_CODE_DIAGNOSE:
                    diagnosisList = (ArrayList<DiagnoseBean>) data.getSerializableExtra(DiagnoseActivity.INTENT_KEY_DIAGNOSIS);
                    setDiagnosisText();
                    inspectInfo.setDiagnosisList(diagnosisList);
                    break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        returnToChoiceInspectActivity();
    }

    @Override
    public void onNetRefresh() {

    }

}

