package com.qlk.ymz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.contrarywind.listener.OnItemSelectedListener;
import com.contrarywind.view.WheelView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ArrayTextWheelAdapter;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * Created by xiedong on 2017/3/28.
 * 设置个人咨询费
 */

public class XD_SetPersonalConsultingFeesActivity extends DBActivity {

    /**
     * 上级页面传一个xcchatmodel
     */
    public static final String PATIENT_INGO = "patient_info";
    /**
     * 标题栏
     */
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**
     * 患者姓名
     */
    private TextView tv_patient_name;
    /**
     * 患者姓名后的文字
     */
    private TextView tv_patient_name_title;
    /**
     * 价格
     */
    private TextView tv_price;
    /**
     * 价格单位
     */
    private TextView tv_price_unit;
    /**
     * 修改价格
     */
    private TextView tv_change_price;

    /**
     * 功能介绍
     */
    private RelativeLayout rl_function_explain;
    /**
     * 规则说明
     */
    private WebView wv_explain;
    /**
     * 屏幕宽
     */
    private int mScreenWidth = 720;
    /**
     * 选择价格对话框
     */
    private ConfirmDialog mSetPriceDialog;

    /**
     * 选择价格控件
     */
    private WheelView mWheelView;
    /**
     * 选择价格对话框取消按钮
     */
    private TextView tv_set_price_cancel;
    /**
     * 选择价格对话框确定按钮
     */
    private TextView tv_set_price_confirm;
    /**
     * 当前选择的价格
     */
    private String mCurrentPrice = "自定义";
    /**
     * 自定义价格对话框
     */
    private ConfirmDialog mCustomPriceDialog;
    /**
     * 自定义价格对话框确定按钮
     */
    private TextView tv_custom_price_confirm;
    /**
     * 自定义价格对话框输入
     */
    private EditText et_custom_price;
    /**
     * 上个界面转来的患者信息
     */
    private XC_ChatModel mPatientInfo;
    /**
     * 价格集合
     */
    private List<String> mPrices = new ArrayList<>();
    /**
     * 最大价格
     */
    private long maxPrice;
    /**
     * 最小价格
     */
    private long minPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_set_personal_consulting_fees);
        //获取屏幕信息
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        mScreenWidth = dm.widthPixels;
        super.onCreate(savedInstanceState);

        //初始化极限值
        maxPrice = GlobalConfigSP.getLimitValue(GlobalConfigSP.MESSAGE_CHARGE_AMOUNT, 0,
                50000000);
        minPrice = GlobalConfigSP.getLimitValue(GlobalConfigSP.MESSAGE_CHARGE_AMOUNT, 1, 0);
        //初始化价格对话框
        initSetPriceDialog();
        //初始化数据和显示
        initBaseInfo();

    }

    /**
     * created by songxin,date：2017-4-10,about：bi,begin
     */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_SetPersonalConsultingFeesActivity.class);
    }

    /**
     * created by songxin,date：2016-4-10,about：bi,end
     */


    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.getXc_id_titlebar_left_imageview().setVisibility(View.GONE);
        xc_id_model_titlebar.setTitleCenter(true, "付费咨询设置");
        xc_id_model_titlebar.setTitleLeft(true, "取消");
        xc_id_model_titlebar.getXc_id_titlebar_left_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        xc_id_model_titlebar.setTitleRight2(true, 0, "保存");
        tv_patient_name = getViewById(R.id.tv_patient_name);
        tv_patient_name_title = getViewById(R.id.tv_patient_name_title);
        tv_price = getViewById(R.id.tv_price);
        tv_price_unit = getViewById(R.id.tv_price_unit);
        tv_change_price = getViewById(R.id.tv_change_price);
        rl_function_explain = getViewById(R.id.rl_function_explain);
        wv_explain = getViewById(R.id.wv_explain);
        if (null != getIntent() && null != getIntent().getSerializableExtra(PATIENT_INGO)) {
            mPatientInfo = (XC_ChatModel) getIntent().getSerializableExtra(PATIENT_INGO);
        } else {
            mPatientInfo = new XC_ChatModel();
        }
    }

    @Override
    public void listeners() {
        xc_id_model_titlebar.getXc_id_titlebar_left_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myFinish();
            }
        });
        xc_id_model_titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSetting(UtilString.toLong(mCurrentPrice) * 100);//元换算成分
            }
        });
        tv_change_price.setOnClickListener(this);
        rl_function_explain.setOnClickListener(this);

        wv_explain.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                wv_explain.setVisibility(View.GONE);
            }
        });

    }

    /**
     * 保存修改
     *
     * @param price 分
     */
    private void saveSetting(final long price) {
        if (minPrice > price || price > maxPrice) {
            shortToast("单笔最大限额为" + maxPrice / 100 + "元，请重新输入");
            return;
        }
        RequestParams params = new RequestParams();
        params.put("charge", price);
        params.put("selectedAll", "0");
        params.put("patientIds", mPatientInfo.getUserPatient().getPatientId());
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.consultSetting), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    mPatientInfo.getUserPatient().setPayAmount(price + "");
                    //更新患者数据
                    JS_ChatListDB.getInstance(getApplicationContext(), UtilSP.getUserId()).updatePatientPayAmount(Collections.singletonList(mPatientInfo));
                    //通知更新患者列表显示
                    Intent intent = new Intent();
                    intent.putExtra(PATIENT_INGO, mPatientInfo);
                    intent.setAction(JS_MainActivity.ChatNewPatientReceiver.CHAT_NEW_PATIENT_ACTION);
                    context.sendBroadcast(intent);

                    Intent intent1 = new Intent();
                    intent1.putExtra(CommonConfig.PERSONAL_CONSULTING_FEES, price+"");
                    setResult(RESULT_OK, intent1);
                    myFinish();
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_SetPersonalConsultingFeesActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_change_price:
                //设置价格
                if (mSetPriceDialog != null) {
                    mSetPriceDialog.show();
                }
                break;
            case R.id.rl_function_explain:
                //进入功能介绍
                UtilNativeHtml5.toJumpNativeH5(this, UtilNativeHtml5.GRAPHIC_CONSULTING);
                break;
            case R.id.tv_set_price_cancel:
                mSetPriceDialog.dismiss();
                break;
            case R.id.tv_set_price_confirm:
                mSetPriceDialog.dismiss();
                if (isCustomPrice(mPrices.get(mWheelView.getCurrentItem()).replace("元/次",""))) {
                    //弹出自定义价格框
                    showCustomPriceDialog();
                } else {
                    mCurrentPrice = mPrices.get(mWheelView.getCurrentItem()).replace("元/次","");
                    setShowPrice(mCurrentPrice);
                }
                break;
            case R.id.tv_custom_price_confirm:
                //自定义价格对话框确定按钮
                String s = et_custom_price.getText().toString();
                if (!TextUtils.isEmpty(s)) {
                    mCurrentPrice = UtilString.toLong(s) + "";
                    setShowPrice(mCurrentPrice);
                } else {
                    shortToast("自定义价格为" + minPrice / 100 + "-" + maxPrice / 100 + "元");
                }
                mCustomPriceDialog.dismiss();
                break;
        }
        super.onClick(v);
    }

    /**
     * 设置显示的价格
     *
     * @param showPrice
     */
    private void setShowPrice(String showPrice) {
        long price = UtilString.toLong(showPrice);
        if (price > 0) {
            tv_price_unit.setVisibility(View.VISIBLE);
            tv_price.setText(showPrice);
        } else {
            tv_price.setText("免费");
            tv_price_unit.setVisibility(View.INVISIBLE);
        }
    }

    /**
     * 显示自定义价格对话框
     */
    private void showCustomPriceDialog() {
        if (mCustomPriceDialog == null) {
            mCustomPriceDialog = new ConfirmDialog(this, mScreenWidth, 55
                    , R.layout.xd_dialog_custom_price, R.style.xc_s_dialog);
            mCustomPriceDialog.setCanceledOnTouchOutside(false);
            Window window = mCustomPriceDialog.getWindow();
            window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
            et_custom_price = (EditText) mCustomPriceDialog.findViewById(R.id.et_custom_price);
            tv_custom_price_confirm = (TextView) mCustomPriceDialog.findViewById(R.id.tv_custom_price_confirm);
            //初始化
            et_custom_price.setHint("自定义价格为" + minPrice / 100 + "-" + maxPrice / 100 + "元");
            //确定按钮监听
            tv_custom_price_confirm.setOnClickListener(this);
            mCustomPriceDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    et_custom_price.setText("");
                }
            });
            mCustomPriceDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialog) {
                    //获取焦点
                    et_custom_price.setFocusableInTouchMode(true);
                    et_custom_price.requestFocus();
                    //弹出软键盘
                    UtilInputMethod.openInputMethod(et_custom_price, XD_SetPersonalConsultingFeesActivity
                            .this);
                }
            });
        }
        mCustomPriceDialog.show();
    }


    /**
     * 初始化数据和显示
     */
    private void initBaseInfo() {
        if (!TextUtils.isEmpty(mPatientInfo.getUserPatient().getPatientDisplayName())) {
            tv_patient_name.setText(mPatientInfo.getUserPatient().getPatientDisplayName());
        } else {
            tv_patient_name.setText(mPatientInfo.getUserPatient().getPatientName());
        }
        //动态设置姓名宽
        int w = View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED);
        tv_patient_name.measure(w,w);
        int nameWidth = tv_patient_name.getMeasuredWidth();
        tv_patient_name_title.measure(w,w);
        int titleWidth = tv_patient_name_title.getMeasuredWidth();
        if((mScreenWidth-(UtilScreen.dip2px(this,30)+titleWidth))<nameWidth){
            tv_patient_name.getLayoutParams().width = mScreenWidth-(UtilScreen.dip2px(this,30)
                    +titleWidth);
        }
        //初始化价格
        long price = UtilString.toLong(mPatientInfo.getUserPatient().getPayAmount()) / 100;
        mCurrentPrice = price + "";
        setShowPrice(mCurrentPrice);

        WebSettings wSettings = wv_explain.getSettings();
        wSettings.setJavaScriptEnabled(true);
        wSettings.setBuiltInZoomControls(true);
        wSettings.setDisplayZoomControls(false);
        wSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); // 不进行缓存，总是使用网络数据
        String url = GlobalConfigSP.getHtml5NativePath() + "/html/" + UtilNativeHtml5.SINGLE_PAY_SETTING_EXPLAIN;
        if (UtilFiles.fileIsExists(url)) {

            url = GlobalConfigSP.getHtml5NativePath() + "/html/" + UtilNativeHtml5.SINGLE_PAY_SETTING_EXPLAIN;
            wv_explain.loadUrl("file://" + url);
        }
        wv_explain.setBackgroundColor(0);
    }

    /**
     * 初始化选择价格对话框
     */
    private void initSetPriceDialog() {
        mSetPriceDialog = new ConfirmDialog(this, mScreenWidth, R.layout
                .dialog_roll_select, R.style.xc_s_dialog);
        mSetPriceDialog.setCanceledOnTouchOutside(false);
        Window window = mSetPriceDialog.getWindow();
        window.setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        mWheelView = (WheelView) mSetPriceDialog.findViewById(R.id.wheelview);
        mWheelView.setCyclic(false);

        tv_set_price_cancel = (TextView) mSetPriceDialog.findViewById(R.id.tv_set_price_cancel);
        tv_set_price_confirm = (TextView) mSetPriceDialog.findViewById(R.id.tv_set_price_confirm);
        String[] consultChargeList = GlobalConfigSP.getConsultChargeList();
        mPrices.add("自定义");
        if (consultChargeList != null) {
            for (int i = 0; i < consultChargeList.length; i++) {
                long price = UtilString.toLong(consultChargeList[i]) / 100;
                mPrices.add(price + "元/次");
            }
        }
        mWheelView.setAdapter(new ArrayTextWheelAdapter(mPrices));

        tv_set_price_cancel.setOnClickListener(this);
        tv_set_price_confirm.setOnClickListener(this);
        mSetPriceDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                mWheelView.setCurrentItem(0);
            }
        });
    }

    /**
     * 判断是否为自定义价格
     *
     * @param currentPrice
     * @return
     */
    private boolean isCustomPrice(String currentPrice) {
        if ("自定义".equals(currentPrice)) {
            return true;
        } else {
            for (int i = 0; i < mPrices.size(); i++) {
                if (currentPrice.equals(mPrices.get(i).replace("元/次", ""))) {
                    return false;
                }
            }
            return true;
        }
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != wv_explain) {
            wv_explain.destroy();
            wv_explain.removeAllViews();
        }
    }
}
