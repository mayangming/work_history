package com.qlk.ymz.activity;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.fragment.SK_MyPharmacyClassificationResultFragment;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.SK_MedicineClassificationBModel;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.bi.BiUtil;

/**
 * @author 赖善琦
 * @description 我的药房，按病理分类结果页
 * @version 2.6.0
 */
public class SK_MedicineClassificationResultActivity extends DBActivity{
    /** 搜索布局 */
    private LinearLayout sk_id_medicine_search;
    /** 分类结果页 */
    private SK_MyPharmacyClassificationResultFragment medicineClassificationResultFragment;
    /** 返回按钮 */
    private ImageView sk_id_titlebar_left_imageview;
    /**
     * 药箱
     */
    private RelativeLayout rl_recipe_cart;
    /**
     * 药数量的布局
     */
    private LinearLayout ll_medicine_num;
    /**
     * 药数量
     */
    private TextView tv_medicine_num;
    /** intent接收数据的key */
    public static String CLASSIFICATIONRESULT_KEY = "ClassificationResult_Key";
    private int intentFlag;
    private String commonFlag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sk_activity_medicine_classification_result);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SK_MedicineClassificationResultActivity.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */

    @Override
    protected void onRestart() {
        super.onRestart();
        medicineClassificationResultFragment.notifyDataSetChanged();
    }

    @Override
    public void initWidgets() {
        intentFlag = getIntent().getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,0);
        commonFlag = getIntent().getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION);

        rl_recipe_cart = getViewById(R.id.rl_recipe_cart);
        ll_medicine_num = getViewById(R.id.ll_medicine_num);
        tv_medicine_num = getViewById(R.id.tv_medicine_num);
        sk_id_titlebar_left_imageview = getViewById(R.id.sk_id_titlebar_left_imageview);
        sk_id_medicine_search = getViewById(R.id.sk_id_medicine_search);
        medicineClassificationResultFragment  = new SK_MyPharmacyClassificationResultFragment();
        addFragment(R.id.sk_id_medicine_classification_ll,medicineClassificationResultFragment);

        SK_MedicineClassificationBModel model = (SK_MedicineClassificationBModel)getIntent().getSerializableExtra(CLASSIFICATIONRESULT_KEY);
        medicineClassificationResultFragment.requestData(model.getParentName(),model.getName());

        // 推荐用药 带药箱
        if(2 == intentFlag){
            rl_recipe_cart.setVisibility(View.VISIBLE);
            setMedicineNum();
        }else {
            rl_recipe_cart.setVisibility(View.GONE);
        }
    }

    @Override
    public void listeners() {
        sk_id_medicine_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ToJumpHelp.toJumpMedicineSearchActivity(SK_MedicineClassificationResultActivity.this,intentFlag,commonFlag);

            }
        });
        sk_id_titlebar_left_imageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        rl_recipe_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkMedicneNum()){
                    SQ_RecommendActivity.launch(SK_MedicineClassificationResultActivity.this);
                }else {
                    shortToast("请选择药品");
                }
            }
        });
    }

    /**
     * 检查药箱是否有药
     * @return
     */
    private boolean checkMedicneNum() {
        if(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size()>0){
            return true;
        }else {
            return false;
        }
    }

    @Override
    public void onNetRefresh() {

    }

    /**
     * 设置药箱药品数量
     */
    public void setMedicineNum(){
        int num = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size();
        if(num==0){
            ll_medicine_num.setVisibility(View.GONE);
        }else if(num<100){
            ll_medicine_num.setVisibility(View.VISIBLE);
            ll_medicine_num.setBackgroundResource(R.mipmap.xd_red_round);
        }else if(num>=100){
            ll_medicine_num.setVisibility(View.VISIBLE);
            ll_medicine_num.setBackgroundResource(R.drawable.xd_red_round);
        }
        tv_medicine_num.setText("" + num);
    }

    /**
     * 数字动画
     */
    private void startNumAnimation() {
        ObjectAnimator rotation = ObjectAnimator.ofFloat(ll_medicine_num, "rotation", -180f,
                0f);
        rotation.setDuration(300);
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(ll_medicine_num, "scaleX", 0.8f, 1f);
        scaleX.setDuration(300);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(ll_medicine_num, "scaleY", 0.8f, 1f);
        scaleY.setDuration(300);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(rotation, scaleX, scaleY);
        animatorSet.setStartDelay(500);
        animatorSet.start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode != Activity.RESULT_OK){
            return;
        }

        if(requestCode == UsageActivityV2.REQUEST_CODE_USAGE){
            DrugBean drugBean = (DrugBean) data.getSerializableExtra(UsageActivityV2.DRUG_INFO);
            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().add(drugBean);
            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getCheckDrugMap().put(drugBean.getId(),true);
            medicineClassificationResultFragment.notifyDataSetChanged();
            //设置药品数量
            setMedicineNum();
            //开始数量动画
            startNumAnimation();
        }

    }
}
