package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.reply.YRAutoReplyDao;
import com.qlk.ymz.db.reply.YRAutoReplyModel;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * 添加免打扰信息页
 *
 * @author 崔毅然
 * @version 1.4
 */
public class YR_AddAvoidDisturbActivity extends DBActivity {

    /** 自动回复数据库操作的dao */
    private YRAutoReplyDao replyDao ;
    /** 页面title */
    private XCTitleCommonLayout titleCommonLayout;
    /** 填写免打扰内容 */
    private EditText et_avoid_disturb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yr_activity_add_avoid_disturb);
        super.onCreate(savedInstanceState);

        delayOpen();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_AddAvoidDisturbActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {

        titleCommonLayout = getViewById(R.id.xc_id_model_titlebar);
        titleCommonLayout.setTitleLeft(true, "");
        titleCommonLayout.setTitleCenter(true, "添加自动回复");
        titleCommonLayout.setTitleRight2(true, 0, "保存");
        titleCommonLayout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));

        et_avoid_disturb = (EditText) findViewById(R.id.et_avoid_disturb);
        int maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.DISTURB_REPLY, 0, 300);
        et_avoid_disturb.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});

        replyDao = YRAutoReplyDao.getInstance(this);//初始化dao
    }

    @Override
    public void listeners() {
        titleCommonLayout.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delayClose();
            }
        });

        titleCommonLayout.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String content = et_avoid_disturb.getText().toString();
                int minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.DISTURB_REPLY, 1, 1);
                if (minLength > 0 && UtilString.isBlank(content)) {
                    shortToast("请填写内容");
                    return;
                }
                if (content.length() < minLength) {
                    shortToast("文本的长度不可小于" + minLength);
                    return;
                }
                requestQuickReplyAdd(content);
            }
        });
    }

    @Override
    public void onNetRefresh() {
    }

    /** 添加免打扰信息，db插入新信息 */
    public void requestQuickReplyAdd(String content) {
        YRAutoReplyModel bean = new YRAutoReplyModel();
        bean.setContent(content);
        replyDao.insertReply(bean);
        shortToast("添加成功");
        myFinish();
    }

    @Override
    public void finish() {
        super.finish();
//      关闭页面动画
        overridePendingTransition(R.anim.activity_no_move, R.anim.activity_close_down);
    }


    /** 延迟弹出软键盘 */
    public void delayOpen(){
        getWindow().getDecorView().postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(et_avoid_disturb, 0);
            }
        }, 300);
    }

    /** 延迟关闭页面，先关闭键盘，防止返回的页面出现抖动 */
    public void delayClose(){
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(et_avoid_disturb.getWindowToken(), 0);
        getWindow().getDecorView().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        },100);
    }
}
