package com.qlk.ymz.activity;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.fragment.QRCodeFragment;
import com.qlk.ymz.model.PF_ShareInfo;
import com.qlk.ymz.modelflag.XL_OrcodeBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.zoomimageview.XCViewPagerFragment;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.fragment.DepthPageTransformer;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.PFViewPager;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * @version 1.0
 * @Created by xilinch on 2015/6/16.
 * @description 推广码
 *
 *
 * @version 2.0
 * @author zhangpengfei
 */
public class XL_ORCodeActivity extends DBActivity implements QRCodeFragment.ORCodeShareListerer {
    /**医生在上面*/
    public static final int DOC_TOP = 1;
    /**患者在上面*/
    public static final int PAT_TOP = 0;
    public static final String TO_ORCODE = "to_orcode";

    private XCTitleCommonLayout xc_id_model_titlebar;
    private View titleRightView;
    /**
     * 医生信息对象
     */
    private XCJsonBean data;

    /**
     * flag bean
     */
    private XL_OrcodeBean orcodeBeanFlag = new XL_OrcodeBean();

    /**
     * 头像大图
     */
    public RelativeLayout xc_id_model_big;
    /**
     * 医生分享链接
     */
    private String spreadDrUrl;
    /**
     * 患者分享链接
     */
    private String spreadPtUrl;
    /**
     * 图片显示设置
     */
    private DisplayImageOptions options = XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.sx_d_identity_personal_head_icon_v2);
    private Dialog shareDialog;
    private View dialogView;
    private PFViewPager xc_id_fragment_viewpager;
    private QRCodeFragment viewpagerFragment;
    /**
     * 分享给患者
     */
    private TextView pf_id_pop_share_patient;
    /**
     * 分享给患者
     */
    private TextView pf_id_pop_share_doctor;
    private ScreenSlidePagerAdapter mPagerAdapter;
    /**邀请联系人*/
    private LinearLayout pf_id_orcode_add_contacts;
    /**默认显示哪个*/
    public int showWhat = 2;
    /**是否刷新数据 默认不刷新*/
    private boolean isRefresh = false;
    /**分享数据*/
    private PF_ShareInfo info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xl_activity_orcode);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(XL_ORCodeActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-25,about：saveInfo,end
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_ORCodeActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        if (null != getIntent()){
            showWhat = getIntent().getIntExtra(TO_ORCODE,2);
        }
        //初始化分享标题和图片
        info = new PF_ShareInfo();
        info.setTitle(GlobalConfigSP.getShareTitle());
        info.setImgUrl(UtilSP.getUserHeaderImage());
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        pf_id_orcode_add_contacts = getViewById(R.id.pf_id_orcode_add_contacts);
        xc_id_model_titlebar.setTitleLeft(R.mipmap.xc_d_chat_back, "");
        xc_id_model_titlebar.setTitleCenter(true, "二维码");
        xc_id_model_titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));
        xc_id_model_titlebar.getXc_id_titlebar_common_layout().setBackgroundColor(getResources().getColor(R.color.c_gray_f0f1f5));
        titleRightView = xc_id_model_titlebar.getXc_id_titlebar_right_layout();
        xc_id_fragment_viewpager = getViewById(R.id.xc_id_fragment_viewpager);
        xc_id_fragment_viewpager.setVisibility(View.INVISIBLE);
        mPagerAdapter = new ScreenSlidePagerAdapter(getSupportFragmentManager());
        //edit by xilinch处理  Fragment QRCodeFragment{22571d25} is not currently in the FragmentManager 友盟报错
        mPagerAdapter.finishUpdate(xc_id_fragment_viewpager);
        xc_id_fragment_viewpager.setAdapter(mPagerAdapter);
        //end
        int spaceHeight = UtilScreen.dip2px(this, 30);
        xc_id_fragment_viewpager.setPageTransformer(true, new DepthPageTransformer(spaceHeight));
        shareDialog = new Dialog(this, R.style.xc_s_dialog);
        dialogView = getLayoutInflater().inflate(R.layout.pf_l_pop_share, null);
        pf_id_pop_share_patient = (TextView) dialogView.findViewById(R.id.pf_id_pop_share_patient);
        pf_id_pop_share_doctor = (TextView) dialogView.findViewById(R.id.pf_id_pop_share_doctor);
        shareDialog.setContentView(dialogView);
        Window window = shareDialog.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        window.setGravity(Gravity.TOP);
        window.setAttributes(lp);
        xc_id_model_big = getViewById(R.id.xc_id_model_big);
        isRefresh = true;
        requestData();
    }


    @Override
    public void listeners() {
        dialogView.setOnClickListener(this);
        pf_id_pop_share_patient.setOnClickListener(this);
        pf_id_pop_share_doctor.setOnClickListener(this);
        titleRightView.setOnClickListener(this);
        pf_id_orcode_add_contacts.setOnClickListener(this);
        xc_id_fragment_viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                //只有患者二维码在前面的时候才显示邀请手机联系人
                if (position % 2 == 0) {
                    pf_id_orcode_add_contacts.setVisibility(View.VISIBLE);
                } else {
                    pf_id_orcode_add_contacts.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    public void onNetRefresh() {
        requestData();
    }

    XCViewPagerFragment fragment;

    /**
     * 显示头像大图
     *
     * @param url
     */
    private void showHeadUrl(String url) {
        if (options == null) {

            options = XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.sx_d_identity_personal_head_icon_v2);
        }
        xc_id_model_big.setVisibility(View.VISIBLE);
        fragment = new XCViewPagerFragment();
        fragment.setDefaultSelectedIndex(1);
        ArrayList<String> list = new ArrayList<>();
        list.add(url);
        fragment.setData(list);
        fragment.setIsShowIndex(false);
        fragment.setOnImageClickListener(new XCViewPagerFragment.OnImageClickListener() {
            @Override
            public void onImageClickListener(int position) {
                if (fragment != null) {
                    removeFragment(fragment);
                }
                xc_id_model_big.setVisibility(View.GONE);
            }
        });
        fragment.setOnLoadImageListener(new XCViewPagerFragment.OnLoadImage() {
            @Override
            public void onLoadImage(ImageView imageview, String url) {

                XCApplication.displayImage(url, imageview, options);
            }
        });

        addFragment(R.id.xc_id_model_big, fragment, fragment.getClass().getSimpleName(), true);
    }


    private void requestData() {
        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.spreadCode), new RequestParams(), new XCHttpResponseHandler(this) {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<XCJsonBean> result_list = result_bean.getList(orcodeBeanFlag.data);

                    if (result_list != null && result_list.size() > 0) {
                        data = result_list.get(0);
                        spreadDrUrl = data.getString(orcodeBeanFlag.spreadDrUrl);
                        spreadPtUrl = data.getString(orcodeBeanFlag.spreadPtUrl);
                        if (!UtilString.isBlank(spreadDrUrl) && !UtilString.isBlank(spreadPtUrl)) {
                            xc_id_model_titlebar.setTitleRight(true, R.mipmap.pf_title_share);
                        }
                        //保存医生名
                        String name = data.getString(orcodeBeanFlag.name);
                        if (TextUtils.isEmpty(name)) {
                            name = "";
                        }
                        UtilSP.setName(name);
                        //保存职称
                        String title = data.getString(orcodeBeanFlag.title);
                        if (TextUtils.isEmpty(title)) {
                            title = "";
                        }
                        UtilSP.setTitle(title);
                        //保存科室
                        String department = data.getString(orcodeBeanFlag.department);
                        if (TextUtils.isEmpty(department)) {
                            department = "";
                        }
                        UtilSP.setDepartment(department);
                        //保存医院
                        String hospital = data.getString(orcodeBeanFlag.hospital);
                        if (TextUtils.isEmpty(hospital)) {
                            hospital = "";
                        }
                        UtilSP.setHospital(hospital);
                        //保存头像
                        String iconUrl = data.getString(orcodeBeanFlag.iconUrl);
                        UtilSP.putUserHeader(iconUrl);
                        //保存患者二维码
                        XCJsonBean spreadPatient = data.getModel(orcodeBeanFlag.spreadPatient);
                        String spreadPatient_qrUrl = spreadPatient.getString(orcodeBeanFlag.qrUrl);
                        if (!TextUtils.isEmpty(spreadPatient_qrUrl)) {
                            UtilSP.setSpreadPatientQrUrl(spreadPatient_qrUrl);
                        }
                        //保存医生二维码
                        XCJsonBean spreadDoctor = data.getModel(orcodeBeanFlag.spreadDoctor);
                        String spreadDoctor_qrUrl = spreadDoctor.getString(orcodeBeanFlag.qrUrl);
                        if (!TextUtils.isEmpty(spreadDoctor_qrUrl)) {
                            UtilSP.setSpreadDoctorQrUrl(spreadDoctor_qrUrl);
                        }
                    }
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();

                // update by xjs on 20160519 start
                // 当快速退出二维码页面时，有时会因fragment无法找到，而发生crash的问题，故用try catch包住
                try {
                    if (null != result_bean && GeneralReqExceptionProcess.checkCode(XL_ORCodeActivity.this,
                            getCode(),
                            getMsg()) && isRefresh) {
                        // 接口请求业务成功时的处理
                        xc_id_fragment_viewpager.setAdapter(mPagerAdapter);
                        isRefresh = false;
                        //判断哪个二维码需要显示在上面
                        if (showWhat == DOC_TOP){
                            xc_id_fragment_viewpager.setCurrentItem(1);
                            pf_id_orcode_add_contacts.setVisibility(View.GONE);
                        }else if (showWhat == PAT_TOP){
                            xc_id_fragment_viewpager.setCurrentItem(0);
                            pf_id_orcode_add_contacts.setVisibility(View.VISIBLE);
                        }
                        xc_id_fragment_viewpager.setVisibility(View.VISIBLE);
                    }
                }catch(Exception e) {
                    e.printStackTrace();
                }
                // update by xjs on 20160519 end
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (v == dialogView) {
            shareDialog.dismiss();
            //分享患者
        } else if (v == pf_id_pop_share_patient) {
            info.setSpreadUrl(spreadPtUrl);
            info.setSpreadContent(GlobalConfigSP.getPtShareContent());
            PF_ShareActivity.launch(this, info);
            shareDialog.dismiss();
            //分享医生
        } else if (v == pf_id_pop_share_doctor) {
            info.setSpreadUrl(spreadDrUrl);
            info.setSpreadContent(GlobalConfigSP.getDcShareContent());
            PF_ShareActivity.launch(this, info);
            shareDialog.dismiss();
            //分享
        } else if (v == titleRightView){
            shareDialog.show();
            //邀请联系人
        } else if (v == pf_id_orcode_add_contacts){
            // created by songxin,date：2016-4-25,about：saveInfo,begin
            BiUtil.saveBiInfo(XL_ORCodeActivity.class,"2","128","pf_id_orcode_add_contacts","",false);
            // created by songxin,date：2016-4-25,about：saveInfo,end
            myStartActivity(XL_ContactsInviteActivity.class);
        }
    }

    @Override
    public void longClick(int position) {
        switch (position) {
            //长按患者
            case QRCodeFragment.PATIENT_TAG:
                info.setSpreadUrl(spreadPtUrl);
                info.setSpreadContent(GlobalConfigSP.getPtShareContent());
                PF_ShareActivity.launch(this, info);
                break;
            //长按医生
            case QRCodeFragment.DOCTOR_TAG:
                info.setSpreadUrl(spreadDrUrl);
                info.setSpreadContent(GlobalConfigSP.getDcShareContent());
                PF_ShareActivity.launch(this, info);
                break;
        }
    }

    @Override
    public void showBigHeader() {
        showHeadUrl(UtilSP.getUserHeaderImage());
    }

    @Override
    public void refreshData() {
        isRefresh = true;
        requestData();
    }

    private class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter {

        public ScreenSlidePagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public float getPageWidth(int position) {
            return 0.9f;
        }

        @Override
        public Fragment getItem(int position) {
            viewpagerFragment = QRCodeFragment.newInstance(position % 2);
            viewpagerFragment.setOrCodeShareListerer(XL_ORCodeActivity.this);
            return viewpagerFragment;
        }

        @Override
        public int getCount() {
            return Integer.MAX_VALUE;
        }

    }


    public interface onShareListener {
         void shareFriend();

         void shareFriends();

         void shareQQ();
    }
}
