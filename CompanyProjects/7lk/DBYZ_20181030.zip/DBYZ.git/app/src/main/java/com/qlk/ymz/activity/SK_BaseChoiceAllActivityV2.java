package com.qlk.ymz.activity;

import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import java.util.ArrayList;
import java.util.List;

/**
 * @description 带全选删除功能界面的基类
 * Created by 赖善琦 on 2015/6/17.
 * @version 2.0.0
 */
public class SK_BaseChoiceAllActivityV2 extends DBActivity{

    /** 底部新增布局 */
    public LinearLayout sk_id_add_rl;
    /**  全选按钮 */
    public CheckBox sk_id_check_cb;
    /** 删除按钮 */
    public TextView yy_id_delete_tv;
    /** 新增内容View */
    public TextView sk_id_choise_add_tv;
    /** 全选布局 */
    public LinearLayout sk_id_check_all_ll;
    /** 编辑界面组名布局 点击触发进入编辑组名 */
    public LinearLayout sk_id_choice_group_name_ll;
    /** 编辑界面组名 */
    public TextView sk_id_choice_group_name_tv;
    /** 删除的布局 */
    public RelativeLayout sk_id_delete_rl;
    /**  数据列表 */
    public XCListViewFragment listViewFragment;
    /** 标题 */
    public XCTitleCommonLayout titleCommonFragment;
    /** 列表适配器 */
    public SK_BaseChoiseAdapter adapter;
    /**  全选标识 默认：false*/
    public boolean isCheckAll = false;
    /** 是否为编辑页面的标识，用来区分编辑和选择页面 (true: 编辑状态，false：选择状态)*/
    public boolean isEdit = false;
    /** 选中的数据ID们 */
    public String ids = "";
    /** 用于获取ID的KEY */
    public String beanId;
    /** 用来操作的数据 */
    public List<XCJsonBean> dataList;
    /** 增加了isCheck字段的原始数据 */
    public List<XCJsonBean> originalList;
    /** 选中的总数，默认为 0 */
    public int checkCount  = 0;
    /** 删除对话框 */
    public YR_CommonDialog mQueryDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sk_l_activity_choise_v2);
        super.onCreate(savedInstanceState);

    }

    @Override
    protected void onStart() {
        super.onStart();
        sk_id_check_cb.setChecked(false);
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(SK_BaseChoiceAllActivityV2.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    /**
     * 初始化控件
     */
    @Override
    public void initWidgets() {
        initData();
        initAdapter();
        listViewFragment = new XCListViewFragment();
        listViewFragment.setAdapter(adapter);
        addFragment(R.id.sk_id_choise_list, listViewFragment);

        titleCommonFragment = getViewById(R.id.xc_id_model_titlebar);
        titleCommonFragment.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titleCommonFragment.setTitleLeft(true, "");

        yy_id_delete_tv = getViewById(R.id.sk_id_delete_btn);
        sk_id_check_cb = getViewById(R.id.sk_id_check_cb);
        sk_id_add_rl = getViewById(R.id.sk_id_add_rl);
        sk_id_check_all_ll = getViewById(R.id.sk_id_check_all_ll);
        sk_id_choise_add_tv = getViewById(R.id.sk_id_choise_add_tv);
        sk_id_choice_group_name_ll = getViewById(R.id.sk_id_choice_group_name_ll);
        sk_id_choice_group_name_tv = getViewById(R.id.sk_id_choice_group_name_tv);
        sk_id_delete_rl = getViewById(R.id.sk_id_delete_rl);
        initChioseView();
        initQueryDialog();
    }

    /**
     * 初始化选择布局
     */
    public void initChioseView(){
        checkCount = 0;
        isEdit = false;
        adapter.notifyDataSetChanged();
        yy_id_delete_tv.setVisibility(View.GONE);
        sk_id_add_rl.setVisibility(View.VISIBLE);
        sk_id_delete_rl.setVisibility(View.GONE);
        sk_id_add_rl.setOnClickListener(this);

        titleCommonFragment.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });
        titleCommonFragment.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initEditView();
            }
        });


        initChioseTitle(); //初始化标题和编辑
        initChioseItemListenr(); //设置item事件


    }

    /**
     * 初始化列表项的点击事件
     */
    public void initChioseItemListenr(){
        listViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
            }
        });
    }

    /**
     * 初始化数据适配器
     */
    public void initAdapter(){
        adapter = new SK_BaseChoiseAdapter(this,dataList);
    }

    /**
     * title内容设置 和 底部的新增内容
     */
    public void initChioseTitle(){
        titleCommonFragment.setTitleCenter(true,"银行卡");
        titleCommonFragment.setTitleRight2(true, 0, "编辑");
        sk_id_choise_add_tv.setText("添加银行卡");
    }

    /**
     * 初始化编辑状态的title
     */
    public void initEditTitle(){
        titleCommonFragment.setTitleCenter(true, "编辑");
        titleCommonFragment.setTitleRight2(true, 0, "保存");
    }

    /**
     * 删除按钮点击事件
     */
    public void initDeleteClick(){
        yy_id_delete_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkCount == 0) {
                    return;
                }
                mQueryDialog.show();

            }
        });
    }

    private void initQueryDialog() {

        if (mQueryDialog == null) {
            mQueryDialog = new YR_CommonDialog(SK_BaseChoiceAllActivityV2.this,"请确认是否删除？","取消","确认") {
                @Override
                public void confirmBtn() {
                    removeData();
                    requestCommit();
                    mQueryDialog.dismiss();
                }

                @Override
                public void cancelBtn() {
                    mQueryDialog.cancel();
                }
            };
            mQueryDialog.setCanceledOnTouchOutside(true);

//            mQueryDialog = new XCQueryDialog(SK_BaseChoiceAllActivityV2.this,
//                    "温馨提示", "请确认是否删除", new String[]{"取消", "确认 "}, true);
//            xcQueryDialog.setOnDecideListener(SK_BaseChoiceAllActivityV2.this);
        }
    }


    /**
     * 初始化编辑状态布局
     */
    public void initEditView(){
        isEdit = true;
        adapter.notifyDataSetChanged();
        initEditTitle();
        if(dataList.size() > 0){
            // 判断是否有数据，有的话显示完成
            sk_id_delete_rl.setVisibility(View.VISIBLE);
            yy_id_delete_tv.setVisibility(View.VISIBLE);
            titleCommonFragment.setTitleRight2(true, 0, "完成");
        }else{
            // 没有的话，不显示
            sk_id_delete_rl.setVisibility(View.GONE);
            titleCommonFragment.setTitleRight2(false, 0, "完成");
        }
        titleCommonFragment.setTitleCenter(true, "编辑");
        sk_id_add_rl.setVisibility(View.GONE);
        sk_id_check_cb.setFocusable(false);
        sk_id_check_cb.setClickable(false);

        // 设置选择状态，默认都是未选中
        for (int i = 0; i < dataList.size(); i++) {
            dataList.get(i).setBoolean("isCheck",false);
        }
        adapter.notifyDataSetChanged();

        // 全选按钮默认未选中
        isCheckAll = false;
        sk_id_check_cb.setChecked(false);

        // 设置编辑状态的返回按钮点击监听
        titleCommonFragment.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // removeBack();
                initChioseView();
            }
        });

        // 设置编辑状态的完成按钮点击监听
        titleCommonFragment.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ids = "";
                initChioseView();
            }
        });

        // 设置编辑状态的列表项点击监听
        listViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int position, long arg3) {
                XCJsonBean jsonBean = dataList.get(position - 1);
                if(jsonBean.getBoolean("isCheck")){
                    // 取消勾选
                    jsonBean.setBoolean("isCheck",false);
                    checkCount--; // 选中的总数 -1
                }else{
                    // 勾选
                    jsonBean.setBoolean("isCheck",true);
                    checkCount++; // 选中的总数 +1
                }
                // 检查全选并且设置全选状态
                checkAll();
                adapter.notifyDataSetChanged();
            }
        });

        // 全选按钮的监听
        sk_id_check_all_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dataList == null || dataList.size() < 1){
                    return;
                }
                if(isCheckAll){
                    for (int i = 0; i < dataList.size(); i++){
                        dataList.get(i).setBoolean("isCheck",false);
                    }
                    isCheckAll = false;
                    sk_id_check_cb.setChecked(false);
                    adapter.notifyDataSetChanged();
                    checkCount = 0;
                    yy_id_delete_tv.setTextColor(getResources().getColor(R.color.c_gray_bbbbbb));
//                                        sk_id_delete_btn.setBackgroundResource(R.drawable.sk_dd_line_gray_e5e5e5_bg_gray_eeeeee_3);
                }else {

                    for (int i = 0; i < dataList.size(); i++){
                        dataList.get(i).setBoolean("isCheck",true);
                    }
                    isCheckAll = true;
                    sk_id_check_cb.setChecked(true);
                    adapter.notifyDataSetChanged();
                    checkCount = dataList.size();
                    yy_id_delete_tv.setTextColor(getResources().getColor(R.color.c_e2231a));
//                                        sk_id_delete_btn.setBackgroundResource(R.drawable.sk_dd_line_gray_e5e5e5_bg_white_ffffff_3);
                }
            }
        });
        initDeleteClick();
    }

    /**
     * 删除对话框的完成按钮点击,刷新数据
     */
    public void requestCommit(){
        ids = "";
        //        if(dataList.size() == 0) {
            initChioseView();
        //        }
        adapter.update(dataList);
        adapter.notifyDataSetChanged();
    }


    @Override
    public void listeners() {

    }

    /**
     * 检查是否全选并且设置全选状态
     */
    public void checkAll(){
        int size = dataList.size();
        int count = 0; // 临时记录是否全选
        for (int i = 0 ; i < size ; i++){
            if(dataList.get(i).getBoolean("isCheck")){
                count++ ;
            }else{
                break;
            }
        }

        // 判断是否全选
        if(count == size){
            isCheckAll = true;
            sk_id_check_cb.setChecked(true);
        }else{
            isCheckAll = false;
            sk_id_check_cb.setChecked(false);
        }

        // 设置按钮颜色
        if(checkCount > 0) {
            yy_id_delete_tv.setTextColor(getResources().getColor(R.color.c_e2231a));
        }else{
            yy_id_delete_tv.setTextColor(getResources().getColor(R.color.c_gray_bbbbbb));
        }
    }

    public void initData(){}

    /**
     * 初始化数据，为每个bean增加isCheck字段
     * @param list 源数据
     */
    public void initData(List<XCJsonBean> list){
        originalList = new ArrayList<>();
        if(dataList == null){
            dataList = list;
        }else {
            dataList.clear();
            dataList.addAll(list);
        }
        for (int i = 0; i < dataList.size(); i++) {
            dataList.get(i).setBoolean("isCheck", false);

        }
        originalList.clear();
        originalList.addAll(dataList);
        listViewFragment.setPerPageNum("1");
        listViewFragment.updateSpecialList(dataList);
    }

    /**
     * 确认删除的完成按钮监听
     */
//    @Override
//    public void confirm() {
//        removeData();
//        requestCommit();
//        xcQueryDialog.dismiss();
//    }

//    /**
//     * 确认删除的取消按钮监听
//     */
//    @Override
//    public void cancle() {
//        xcQueryDialog.cancel();
//    }

    /**
     * 删除选中的数据
     */
    public void removeData(){
        for (int i = dataList.size() - 1 ; i > (-1) ; i--){
            XCJsonBean bean = dataList.get(i);
            if(bean.getBoolean("isCheck")){
                ids = ids + (bean.getString(beanId)+",");
                bean.setBoolean("isCheck",false);
                dataList.remove(i);
            }

            printi("测试打印信息 删除几个 " + i);
        }

    }

    /**
     * 设置服务器返回itemId的key
     * @param id 服务器返回itemId的key
     */
    public void setBeanId(String id){
        beanId = id;
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.sk_id_add_bank_card_rl:
                myStartActivity(SK_AddQuickReplyActivity.class);
                break;
        }
    }

    /**
     * 编辑界面返回的操作，如果用户删除了数据但没提交。则把数据回滚
     */
    public void removeBack(){
        if(originalList != null && dataList != null) {
            dataList =new ArrayList<>();
            dataList.addAll(originalList);
            ids = "";
            sk_id_check_cb.setChecked(false);
            listViewFragment.updateSpecialList(dataList);
        }
    }

    /**
     * listview适配器
     */
    class SK_BaseChoiseAdapter extends XCBaseAdapter<XCJsonBean>{

        public SK_BaseChoiseAdapter(Context context,List<XCJsonBean> list){
            super(context,list);
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            XCJsonBean bean = list.get(i);
            ViewHolder holder = null;

            if(view == null){
                view = LayoutInflater.from(context).inflate(R.layout.sk_l_adapter_bank_card_item,null);
                holder = new ViewHolder();
                holder.contentTv = (TextView)view.findViewById(R.id.sk_id_bank_card_content_tv);
                holder.checkBox = (CheckBox)view.findViewById(R.id.sk_id_bank_card_cb);
                view.setTag(holder);
            }else{
                holder = (ViewHolder) view.getTag();
            }
                holder.checkBox.setVisibility(View.VISIBLE);

            initCheckBox(bean,holder.checkBox);

            return view;
        }

        /**
         * 设置选择按钮的状态
         * @param checkBox 选择按钮
         */
        public void initCheckBox(XCJsonBean bean,CheckBox checkBox){
            if(isEdit){ //如果是编辑页面
                checkBox.setVisibility(View.VISIBLE);
            }else{
                checkBox.setVisibility(View.GONE);
            }

            checkBox.setFocusable(false);
            checkBox.setClickable(false);

            if(bean.getBoolean("isCheck")){ //如果被选中
                checkBox.setChecked(true);
            }else{
                checkBox.setChecked(false);
            }
        }
    }

    class ViewHolder{
        TextView contentTv;
        CheckBox checkBox;
        View v_bottom_line;
        View v_bottom;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode ==KeyEvent.KEYCODE_BACK){
            if (isEdit) {
                removeBack();
                initChioseView();

                return true;
            }

        }
        return super.onKeyDown(keyCode,event);
    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mQueryDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }
}
