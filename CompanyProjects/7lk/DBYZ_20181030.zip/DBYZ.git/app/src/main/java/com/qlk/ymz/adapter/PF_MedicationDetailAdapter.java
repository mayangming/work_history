package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.PF_medicationDetailBean;
import com.qlk.ymz.util.StringUtils;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * 用药详情adapter
 * @author zhangpengfei on 2016/2/26.
 * @version 2.2.0
 */
public class PF_MedicationDetailAdapter extends BaseAdapter {
    private Context mContext;
    private List<PF_medicationDetailBean.DataEntity.SkusEntity> mList;
    private LayoutInflater mLayoutInflater;

    public void setmList(List<PF_medicationDetailBean.DataEntity.SkusEntity> mList) {
        if (null != mList && mList.size() > 0){
            this.mList = mList;
            notifyDataSetChanged();
        }
    }

    public PF_MedicationDetailAdapter(Context context, List<PF_medicationDetailBean.DataEntity.SkusEntity> mList){
        this.mContext = context;
        this.mList = mList;
        this.mLayoutInflater = LayoutInflater.from(context);

    }
    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MedicationDetailHolder holder = null;
        if(null == convertView){
            convertView = mLayoutInflater.inflate(R.layout.pf_item_medication_detail,null);
            holder = new MedicationDetailHolder(convertView);
            convertView.setTag(holder);
        }else{
            holder = (MedicationDetailHolder)convertView.getTag();
        }
        if (null != mList && mList.size() > 0){
            PF_medicationDetailBean.DataEntity.SkusEntity entity = mList.get(position);
            String name = UtilString.f(entity.getName());
            if (!UtilString.isBlank(entity.getCommonName())){
                name = name + "（" + entity.getCommonName() + "）";
            }
            holder.pf_id_item_medication_detail_name.setText(name);
            holder.pf_id_item_medication_detail_price.setText("¥ " + StringUtils.getMoneyString(entity.getSalePrice()));
            holder.pf_id_item_medication_detail_bf_price.setText("¥ " + StringUtils.getMoneyString(entity.getSalePrice()));
            holder.pf_id_item_medication_detail_count.setText("x " + entity.getQuantity());
            //用法用量和备注
            StringBuffer detail = new StringBuffer();
            if (UtilString.isBlank(entity.getUsages()) && UtilString.isBlank(entity.getBackup())){
                holder.pf_id_item_medication_detail_usage.setVisibility(View.GONE);
            }else{
                detail.append(entity.getUsages());
                if (!UtilString.isBlank(entity.getUsages()) && !UtilString.isBlank(entity.getBackup())){
                    detail.append("；");
                }
                detail.append(entity.getBackup());
                holder.pf_id_item_medication_detail_usage.setText(UtilString.f(detail.toString()));
                holder.pf_id_item_medication_detail_usage.setVisibility(View.VISIBLE);
            }
            //控制大白指数是否显示
            if ("0".equals(entity.getShowGoodsCommission())){
                holder.pf_id_item_medication_detail_exponent_ll.setVisibility(View.GONE);
                holder.pf_id_item_medication_detail_bf_price.setVisibility(View.VISIBLE);
                holder.pf_id_item_medication_detail_price.setVisibility(View.GONE);
            }else{
                holder.pf_id_item_medication_detail_exponent_ll.setVisibility(View.VISIBLE);
                holder.pf_id_item_medication_detail_exponent.setText(entity.getDrCommission());
                holder.pf_id_item_medication_detail_bf_price.setVisibility(View.INVISIBLE);
                holder.pf_id_item_medication_detail_price.setVisibility(View.VISIBLE);
            }
            //最后一条线隐藏
            if ((position + 1) == mList.size()){
                holder.pf_id_item_medication__line.setVisibility(View.GONE);
            }else{
                holder.pf_id_item_medication__line.setVisibility(View.VISIBLE);
            }
        }
        return convertView;
    }

    public class MedicationDetailHolder{
        /**药名*/
        TextView pf_id_item_medication_detail_name;
        /**价钱*/
        TextView pf_id_item_medication_detail_price;
        /**步长医生价钱*/
        TextView pf_id_item_medication_detail_bf_price;
        /**用法*/
        TextView pf_id_item_medication_detail_usage;
        /**数量*/
        TextView pf_id_item_medication_detail_count;
        /**指数布局*/
        RelativeLayout pf_id_item_medication_detail_exponent_ll;
        /**指数*/
        TextView pf_id_item_medication_detail_exponent;
        View pf_id_item_medication__line;
        public MedicationDetailHolder(View convertView){

            pf_id_item_medication_detail_name = (TextView)convertView.findViewById(R.id.pf_id_item_medication_detail_name);
            pf_id_item_medication_detail_price = (TextView)convertView.findViewById(R.id.pf_id_item_medication_detail_price);
            pf_id_item_medication_detail_bf_price = (TextView)convertView.findViewById(R.id.pf_id_item_medication_detail_bf_price);
            pf_id_item_medication_detail_usage = (TextView)convertView.findViewById(R.id.pf_id_item_medication_detail_usage);
            pf_id_item_medication_detail_count = (TextView)convertView.findViewById(R.id.pf_id_item_medication_detail_count);
            pf_id_item_medication_detail_exponent_ll = (RelativeLayout) convertView.findViewById(R.id.pf_id_item_medication_detail_exponent_ll);
            pf_id_item_medication_detail_exponent = (TextView)convertView.findViewById(R.id.pf_id_item_medication_detail_exponent);
            pf_id_item_medication__line = convertView.findViewById(R.id.pf_id_item_medication__line);
        }
    }

}
