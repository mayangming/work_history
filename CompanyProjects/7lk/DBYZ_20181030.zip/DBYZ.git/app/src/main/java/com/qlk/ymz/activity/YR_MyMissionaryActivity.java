package com.qlk.ymz.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.parse.Parse2PublicityBean;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

/**
 * Created by cyr on 2017/3/27.
 *
 * 我的宣教
 */

public class YR_MyMissionaryActivity extends DBActivity {
    private TextView tv_patient_read_num;
    private WebView wv_missionary_detail;
    private Button btn_send_missionary;
    /**发送按钮 的弹出框  add by litao */
    private Dialog sendDialog;
    private TextView sendName;
    private XCRoundedImageView sendHeader;
    private TextView sendUrl;
    private Button sendCancle;
    private Button sendOk;
    /**发送按钮 的弹出框      end--------*/

    /** 页面显示类型，需要其他页面传入 （0 只浏览； 1 可发送宣教 ）*/
    private String pageType = "0";
    /** 宣教相关数据的bean */
    private Parse2PublicityBean missionaryBean;
    /**宣教传入的患者信息*/
    private XC_ChatModel xc_chatModel;
    /** 发送跳转 */
    private int fromActivity = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        initData();

        setContentView(R.layout.yr_activity_my_missionary);
        super.onCreate(savedInstanceState);

        initTitle();
    }

    /** created by songxin,date：2017-4-10,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_MyMissionaryActivity.class);
    }

    /** created by songxin,date：2016-4-10,about：bi,end */

    /** 初始化title */
    public void initTitle(){
        findViewById(R.id.sx_id_title_left).setOnClickListener(this);
        ((TextView)findViewById(R.id.sx_id_title_center)).setText("我的宣教");
    }


    /** 进入页面前需要传的数据 */
    public void initData(){
        pageType =  getIntent().getStringExtra("pageType");
        missionaryBean = (Parse2PublicityBean) getIntent().getSerializableExtra("missionary_bean");
        xc_chatModel = (XC_ChatModel) getIntent().getSerializableExtra("xc_chatModel");
        fromActivity = getIntent().getIntExtra(LT_PublicityActivity.PUBLICITY_EDUCATION_INTENTCODE, 0);
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        tv_patient_read_num = (TextView) findViewById(R.id.tv_patient_read_num);
        wv_missionary_detail = (WebView) findViewById(R.id.wv_missionary_detail);
        btn_send_missionary = (Button) findViewById(R.id.btn_send_missionary);

        if (missionaryBean != null ) {
            initView();
            setWebView();
        }
    }

    @Override
    public void listeners() {
        btn_send_missionary.setOnClickListener(this);
    }

    /** 初始化数据 */
    public void initView(){
        //根据传入的不同类型，显示或隐藏阅读数和发送按钮
        if ("1".equals(pageType)) {
            tv_patient_read_num.setVisibility(View.VISIBLE);
            btn_send_missionary.setVisibility(View.VISIBLE);
            tv_patient_read_num.setText("您的患者阅读：" + missionaryBean.getReadCount()+"次"+"  ("+missionaryBean.getReadersNumber() +"人)");
        } else {
            tv_patient_read_num.setVisibility(View.GONE);
            btn_send_missionary.setVisibility(View.GONE);
        }
    }

    /** 设置webView */
    public void setWebView(){
        wv_missionary_detail.setWebChromeClient(new WebChromeClient());
        wv_missionary_detail.setWebViewClient(new WebViewClient());
        WebSettings settings = wv_missionary_detail.getSettings();
        settings.setJavaScriptEnabled(true);
        //适应屏幕
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        //支持缩放
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);

        if (URLUtil.isValidUrl(missionaryBean.getEduUrl())) {
            wv_missionary_detail.loadUrl(missionaryBean.getEduUrl());
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()){
            case R.id.sx_id_title_left: //返回按钮
                myFinish();
                break;
            case R.id.btn_send_missionary://发送宣教按钮
                if (!URLUtil.isValidUrl(missionaryBean.getEduUrl())) {
                    shortToast("宣教跳转链接不正确，无法发送");
                    return;
                }
                if (fromActivity == 1) {
//                    Intent intent = new Intent(this, XC_ChatDetailActivity.class);
//                    intent.putExtra(XC_ChatDetailActivity.PUBLICITY_EDUCATION_DATA, missionaryBean);
//                    myStartActivity(intent);
                   // intent.putExtra(XC_ChatDetailActivity.PUBLICITY_EDUCATION_DATA,missionaryBean);
                    SendDalogMsg();
                } else {
                    ToJumpHelp.toJumpNewGroupSendActivity(this, missionaryBean);
                    myFinish();
                }
                break;
            default:
                break;
        }
    }




    /**
     * 初始化发送数据的Dialog
     */
    public void  SendDalogMsg() {
        if (sendDialog == null) {
            sendDialog = new Dialog(YR_MyMissionaryActivity.this, R.style.xc_s_dialog);
            sendDialog.setCanceledOnTouchOutside(false);
            View dialogView = LayoutInflater.from(YR_MyMissionaryActivity.this).inflate(R.layout.lt_publicity_dialog, null);
            sendName = (TextView) dialogView.findViewById(R.id.tv_pub_name);
            sendHeader = (XCRoundedImageView) dialogView.findViewById(R.id.iv_pub_dialogiv);
            sendUrl = (TextView) dialogView.findViewById(R.id.tv_pub_url);
            sendCancle = (Button) dialogView.findViewById(R.id.bt_pub_cancle);
            sendOk = (Button) dialogView.findViewById(R.id.bt_pub_ok);
            sendDialog.setContentView(dialogView);

            //设置患者姓名头像
            if(xc_chatModel!=null){
                sendName.setText(xc_chatModel.getUserPatient().getPatientDisplayName());
                XCApplication.displayImage(xc_chatModel.getUserPatient().getPatientImgHead(),sendHeader);
            }
        }
        //设置发送内容
        sendUrl.setText("[链接]"+missionaryBean.getEduTitle());
        if(sendDialog!=null&&!sendDialog.isShowing()){
            sendDialog.show();
        }

        sendCancle.setOnClickListener(this);
        sendOk.setOnClickListener(this);
        //取消
        sendCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDialog.dismiss();
            }
        });
        //确定
        sendOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                setResult(LT_PublicityActivity.PUBLICITY_INTENT_CHART_CODE,intent);
                myFinish();
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(sendDialog != null && sendDialog.isShowing()){
            sendDialog.dismiss();
        }
    }
}
