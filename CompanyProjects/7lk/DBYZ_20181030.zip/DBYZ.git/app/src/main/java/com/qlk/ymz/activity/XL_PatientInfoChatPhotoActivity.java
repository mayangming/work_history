package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_PatientInfoChatPhotoAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.SX_ChatPhotoInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import org.apache.http.Header;
import java.util.ArrayList;
import java.util.List;

/**
 * @author xilinch on 2015/10/28.
 * @version 1.2.0
 * @modifier xilinch 2015/10/28.
 * @description 患者聊天图片
 *
 *
 * @author  Changed by songxin on 2016/5/3.
 * @version 2.3
 */
public class XL_PatientInfoChatPhotoActivity extends DBActivity {

    /*** titlebar*/
    private XCTitleCommonLayout titlebar;
    /*** 基础url前缀*/
    private  String baseUrl;
    /*** 患者id*/
    private String mPatientId;
    /*** 显示聊天图片列表*/
    private ListView sx_id_chat_photo_list;
    /*** 聊天图片适配器*/
    private SX_PatientInfoChatPhotoAdapter sx_patientInfoChatPhotoAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setContentView(R.layout.xl_activity_patient_photo);
        super.onCreate(savedInstanceState);
        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            mPatientId = bundle.getString(CommonConfig.PATIENT_ID);
        }
        if(TextUtils.isEmpty(mPatientId)){
            shortToast("患者id非法!");
        }
        requestData(1);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_PatientInfoChatPhotoActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */


    @Override
    public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "聊天图片");
        titlebar.setTitleLeft(true, "");
        titlebar.getXc_id_titlebar_left_imageview().setImageResource(R.mipmap.xc_d_chat_back);
        titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));
        sx_id_chat_photo_list = getViewById(R.id.sx_id_chat_photo_list);
    }

    @Override
    public void listeners() {
        titlebar.getXc_id_titlebar_left_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });
    }

    @Override
    public void onNetRefresh() {
        requestData(1);
    }

    /**
     * 显示无数据的布局
     */
    private void showNoDataLayout(){
        printi("http","showNoDataLayout");
        sx_id_chat_photo_list.setVisibility(View.GONE);
        findViewById(R.id.xc_id_listview_plus_zero_bg).setVisibility(View.VISIBLE);
        ((ImageView)(findViewById(R.id.xc_id_data_zero_imageview))).setImageResource(R.mipmap.js_d_icon_no_data);
        ((TextView)(findViewById(R.id.xc_id_data_zero_hint_textview))).setText("您暂时没有聊天图片!");

    }

    /**
     * 显示无网络的布局
     */
    private void showNoNetDataLayout(){
        sx_id_chat_photo_list.setVisibility(View.GONE);
        (findViewById(R.id.xc_id_listview_plus_zero_bg)).setVisibility(View.VISIBLE);
        ((ImageView)(findViewById(R.id.xc_id_data_zero_imageview))).setImageResource(R.drawable.xc_d_bg_fail);
        ((TextView)(findViewById(R.id.xc_id_data_zero_hint_textview))).setText("网络加载失败");

    }

    /**
     * 请求患者图片数据
     * @param page 页码
     */
    private void requestData(int page) {
        RequestParams params = new RequestParams();
        params.put("patientId", mPatientId);
        params.put("page", page);
        XCHttpAsyn.getAsyn(this, AppConfig.getChatUrl(AppConfig.imgUpload), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {

                    List<XCJsonBean> data_list = result_bean.getList("data");

                    if (data_list != null && data_list.size() > 0) {

                        XCJsonBean xcJsonBean = data_list.get(0);
                        baseUrl = xcJsonBean.getString("baseUrl");
                        if(TextUtils.isEmpty(baseUrl)){
                            shortToast("基础url出错!");
                        }
                        List<SX_ChatPhotoInfo.DataEntity.ResultEntity> resultEntities = new ArrayList<SX_ChatPhotoInfo.DataEntity.ResultEntity>();
                        List<XCJsonBean> resultList = xcJsonBean.getList("result");
                        if(null != resultList && resultList.size() > 0){
                            for(XCJsonBean x : resultList){
                                SX_ChatPhotoInfo.DataEntity.ResultEntity resultEntity = new SX_ChatPhotoInfo.DataEntity.ResultEntity();
                                resultEntity.setDate(x.getString("date"));
                                ArrayList<String> pics = new ArrayList<String>();
                                for(String s : x.getStringList("images")){
                                    pics.add(baseUrl + s);
                                }
                                resultEntity.setImgs(pics);
                                resultEntities.add(resultEntity);
                            }
                        }else{
                            showNoDataLayout();
                        }
                        sx_patientInfoChatPhotoAdapter = new SX_PatientInfoChatPhotoAdapter(XL_PatientInfoChatPhotoActivity.this,resultEntities);
                        sx_id_chat_photo_list.setAdapter(sx_patientInfoChatPhotoAdapter);
                    } else {
                        showNoDataLayout();
                    }

                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                showNoNetDataLayout();
            }
        });
    }
}
