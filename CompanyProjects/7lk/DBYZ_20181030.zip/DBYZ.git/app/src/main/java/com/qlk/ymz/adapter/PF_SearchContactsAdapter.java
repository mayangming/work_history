package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.db.invited.XL_ContactsInvitedModel;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * 搜索联系人结果adapter
 * @author zhangpengfei on 2016/4/19.
 * @version 2.3.0
 */
public class PF_SearchContactsAdapter extends XCBaseAdapter<XL_ContactsInvitedModel> {

    public PF_SearchContactsAdapter(Context context, List<XL_ContactsInvitedModel> list){
        super(context, list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(null == convertView){
            convertView = LayoutInflater.from(context).inflate(R.layout.pf_item_search_contacts,null);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)convertView.getTag();
        }
        if (null != list && null != list.get(position)){
            viewHolder.pf_id_search_cantacts_name.setText(UtilString.f(list.get(position).display_name));
            viewHolder.pf_id_search_cantacts_phone.setText(UtilString.f(list.get(position).number));
        }
        return convertView;
    }

    static class ViewHolder{
        /**姓名*/
        private TextView pf_id_search_cantacts_name;
        /**电话*/
        private TextView pf_id_search_cantacts_phone;
        public ViewHolder(View convertView){

            pf_id_search_cantacts_name = (TextView)convertView.findViewById(R.id.pf_id_search_cantacts_name);
            pf_id_search_cantacts_phone = (TextView)convertView.findViewById(R.id.pf_id_search_cantacts_phone);

        }


    }
}
