package com.qlk.ymz.application;

import android.app.ActivityManager;
import android.content.Context;
import android.support.multidex.MultiDex;

import com.emoji.util.EmojiDataUtils;
import com.gdca.sdk.casign.SdkManager;
import com.networkbench.agent.impl.NBSAppAgent;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.qlkserivce.QlkServiceHelper;
import com.tencent.ilivesdk.ILiveSDK;
import com.tencent.qcloud.utils.Constants;
import com.tencent.smtt.sdk.QbSdk;
import com.umeng.analytics.AnalyticsConfig;
import com.xiaocoder.android.fw.general.application.XCApplication;

/**
 * @author xilinch on 2015/11/19.
 * @version 1.2.0
 * @modifier xilinch 2015/11/19.
 * @description
 */
public class DBApplication extends XCApplication {
    //友盟的key
    public static String key = "55c2fa2667e58e5e1f0013ac";
    private String curProcessName;
    @Override
    public void onCreate() {
        if (AppConfig.S_TYPE_URL_ONLINE.equals(AppConfig.S_TYPE_URL)) {
            SdkManager.getInstance().setPublicSite(true);//签名sdk线上环境设置
            SdkManager.getInstance().init(this,"bx59uILI41qD8GPT","o5s99v1fhhV7zoVreY9r2OZc2TI5aKLIWT0UBUrYgTFU6wfDIfJJz5x6KA8RkI2N");
            key = AppConfig.ONLINE_KEY;
        } else {
            SdkManager.getInstance().setPublicSite(false);//签名sdk测试环境设置
            SdkManager.getInstance().init(this,"zMIPJFr6bIzlpcKQ","cMx4HA9JMTAYCEcoEv5pjCA71nYyM0L3eVGKOJqAhC19Qz7eTzEPJMrXE9mF7y91");
            key = AppConfig.TEST_KEY;
            //测试环境初始化听云
            NBSAppAgent.setLicenseKey("3995009b375e4412ad17f733961784a6").withLocationServiceEnabled(true).start(this.getApplicationContext());
        }
        init(key);
        super.onCreate();
        //GrowingIO初始化
        GrowingIOUtil.init(this);
//        LeakCanary.install(this);
        // 获取当前进程名称
        curProcessName = getCurProcessName(this);
        if (curProcessName.equals(getPackageName())) {   // 主进程初始化
            initYmzResource();
        }else if(curProcessName.equals("com.qlk.ymz:ymz_im")){  // MQTT初始化

        }

//        /* 下面的代码是给解析加入限制特定类型解析的代码，这个代码可以禁止设置的类型进行解析content字段 */
//        XCJsonParse.setNoParseContentTypes(Arrays.asList(String.valueOf(XC_ChatModel.PUBLICITY_EDUCATION),String.valueOf(XC_ChatModel.INDIVIDUATION_COST),String.valueOf(XC_ChatModel.PAID)));
//        XCJsonParse.setNoParseContentkeys(Collections.singletonList("content"));

        new EmojiDataUtils(getBaseContext());//初始化下表情数据
        //初始化x5浏览器内核
        QbSdk.initX5Environment(base_context, null);
    }

    public void init(String key) {
        AnalyticsConfig.setAppkey(getApplicationContext(), key);
    }


    /**
     * 问题原因：每个android应用都要运行在一个虚拟机上，当应用配置了两个进程时，
     * 其实是有两个虚拟机在运行，一个前台的应用进程，一个service后台进程，每个进程对应一个application对象，
     * 所以当应用配置了多个进程的时候，application对象的onCreate方法就会执行多次，
     * 所以如果在application的onCreate方法中开启轮询或者初始化大量数据时，其实是要做出区分的处理的；
     * 解决问题：我们已经知道每个进程对应一个application对象，为了避免浪费资源，
     * 我们可以在application中通过进程的名称来区分具体应该加载哪些资源，执行哪些具体逻辑。
     * app现有进程名称 ：com.qlk.ymz:QALSERVICE  com.qlk.ymz:ymz_im   com.qlk.ymz  分别三个init去初始化资源
     * @param context
     * @return
     */
    private String getCurProcessName(Context context) {
        int pid = android.os.Process.myPid();
        ActivityManager activityManager = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningAppProcessInfo appProcess : activityManager.getRunningAppProcesses()) {
            if (appProcess.pid == pid) {
                return appProcess.processName;
            }
        }
        return "";
    }

    /**
     * 初始化com.qlk.ymz中的资源
     */
    private void initYmzResource() {
        //初始化ICALL SDK
        ILiveSDK.getInstance().initSdk(getApplicationContext(), Constants.SDK_APPID, Constants.ACCOUNT_TYPE);
        //环信初始化
        QlkServiceHelper.getInstance().init(base_context);
    }

}
