package com.qlk.ymz.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.DiagnoseActivity;
import com.qlk.ymz.adapter.DiagnoseSearchAdapter;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.DiagnoseSearchBean;
import com.qlk.ymz.model.ResponseBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.ListUtil;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * 诊断搜索
 * @author wpq
 * @version 1.0
 */
public class DiagnoseSearchFragment extends DBFragment{

    /** 分页每页数据条数 */
    private static final int PAGE_SIZE = 10;

    private PullToRefreshListView mPtrListView;
    private ListView mListView;

    private String mSearchKeyword;
    private DiagnoseSearchAdapter mAdapter;
    private List<DiagnoseBean> mList = new ArrayList<>();
    private int mPage = 1; // 从1开始

    public static DiagnoseSearchFragment newInstance() {
        return new DiagnoseSearchFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return init(inflater, R.layout.fragment_diagnose_search);
    }

    @Override
    public void initWidgets() {
        mPtrListView = getViewById(R.id.ptrListView);
        mPtrListView.setMode(PullToRefreshBase.Mode.PULL_FROM_END);
        mListView = mPtrListView.getRefreshableView();
        mListView.setDividerHeight(0);
        mListView.setAdapter(mAdapter = new DiagnoseSearchAdapter(getActivity(), mList));
    }

    @Override
    public void listeners() {
        mPtrListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {

            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                requestSearch(true);
            }
        });
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                try {
                    Activity activity = getActivity();
                    if (activity instanceof DiagnoseActivity) {
                        ((DiagnoseActivity) activity).insertDiagnose(mList.get(position - 1));
                    }
                } catch (Exception e) {}
            }
        });
    }

    /**
     * 开始诊断搜索
     * @param searchKeyword 搜索关键字
     */
    public void search(String searchKeyword) {
        this.mSearchKeyword = searchKeyword.trim();
        if (UtilString.isBlank(searchKeyword)) {
            return;
        }

        requestSearch(false);
    }

    /**
     * 请求诊断搜索数据
     * @param isLoadMore newSearch or loadMore
     */
    private void requestSearch(final boolean isLoadMore) {
        mPage = isLoadMore ? mPage + 1 : 1;

        RequestParams params = new RequestParams();
        params.put("keyword", mSearchKeyword);
        params.put("page", mPage);
        params.put("num", PAGE_SIZE);
        XCHttpAsyn.postAsyn(false, getActivity(), AppConfig.getTuijianUrl(AppConfig.DIAGNOSE_SEARCH), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                try {
                    // {"code":0,"msg":"成功","data":[{"pageNo":1,"pageSize":10,"orderBy":null,"order":null,"result":[{"id":4951,"name":"1型糖尿病","type":0},{"id":16266,"name":"慢性肾脏病1期","type":0}],"totalCount":30,"totalPages":3,"orderBySetted":false,"hasNext":true,"nextPage":2,"hasPre":false,"prePage":1,"first":0}]}
                    mPtrListView.onRefreshComplete();

                    ResponseBean<List<DiagnoseSearchBean>> responseBean = new Gson().fromJson(new String(arg2), new TypeToken<ResponseBean<List<DiagnoseSearchBean>>>() {}.getType());
                    if (responseBean == null || !GeneralReqExceptionProcess.checkCode(getActivity(), String.valueOf(responseBean.code), responseBean.msg)) {
                        return;
                    }

                    List<DiagnoseSearchBean> searchBeenList = responseBean.data;
                    searchBeenList = ListUtil.filterNullElements(searchBeenList);
                    if (searchBeenList.isEmpty()) {
                        return;
                    }

                    DiagnoseSearchBean searchBean = searchBeenList.get(0);
                    List<DiagnoseBean> listHttp = searchBean.result;
                    listHttp = ListUtil.filterNullElements(listHttp);
                    if (isLoadMore && listHttp.isEmpty()) {
                        shortToast(getString(R.string.diagnose_search_no_more));
                        return;
                    }

                    if (!isLoadMore) {
                        mList.clear();
                    }
                    mList.addAll(listHttp);

                    mAdapter.update(mSearchKeyword);

                    if (!isLoadMore) {
                        mListView.setSelection(0); // 回到顶部
                    }
                } catch (Exception e) {}
            }

        });

    }

}
