package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.medicine.MedicineUsageBean;
import com.qlk.ymz.util.MedicineUsageUtil;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.UsageDialog;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;

/**
 * 自定义用法页.
 */

public class CustomUsageActivity extends CustomBaseActivity {
    /** 服用时间编辑框 */
    EditText et_take_time;
    TextView tv_take_time;
    /** 服用方法编辑框 */
    EditText et_take_method;
    TextView tv_take_method;

    RelativeLayout rl_take_time;

    RelativeLayout rl_take_method;

    MedicineUsageBean usageBean;


    /** 服用时间 */
    private String takeTimeStr;
    /** 服用方法 */
    private String takeMethodStr;

    private UsageDialog usageDialog;

    public static String TAG_TAKETIMESTR = "takeTimeStr";
    public static String TAG_TAKEMETHODSTR = "takeMethodStr";
    private String currentTag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_custom_usage);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(CustomUsageActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void initWidgets() {
        title = "自定义用法";
        super.initWidgets();

        et_take_method = getViewById(R.id.et_take_method);
        tv_take_method = getViewById(R.id.tv_take_method);
        et_take_time = getViewById(R.id.et_take_time);
        tv_take_time = getViewById(R.id.tv_take_time);
        rl_take_time = getViewById(R.id.rl_take_time);
        rl_take_method = getViewById(R.id.rl_take_method);

        usageBean = (MedicineUsageBean) getIntent().getSerializableExtra(UsageDialog.TAG_USAGE_BEAN);

        tv_take_method.setFilters(new InputFilter[]{new InputFilter.LengthFilter(GlobalConfigSP.getLimitValue(GlobalConfigSP.RECOM_OTHER_UNIT,0,9))});
        tv_take_time.setFilters(new InputFilter[]{new InputFilter.LengthFilter(GlobalConfigSP.getLimitValue(GlobalConfigSP.RECOM_OTHER_UNIT,0,9))});
        et_take_method.setFilters(new InputFilter[]{new InputFilter.LengthFilter(GlobalConfigSP.getLimitValue(GlobalConfigSP.RECOM_OTHER_UNIT,0,9))});
        et_take_time.setFilters(new InputFilter[]{new InputFilter.LengthFilter(GlobalConfigSP.getLimitValue(GlobalConfigSP.RECOM_OTHER_UNIT,0,9))});

        usageDialog = new UsageDialog(this);
        usageDialog.hideDiyView();
    }

    @Override
    public void listeners() {
        rl_take_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(View.GONE == et_take_time.getVisibility()){
                    usageDialog.getAdapter().checkItem(tv_take_time.getText().toString());
                }else {
                    usageDialog.getAdapter().checkItem(et_take_time.getText().toString());
                }
                usageDialog.updata(MedicineUsageUtil.getMedicineTakeDateList());
                usageDialog.show();
                currentTag = TAG_TAKETIMESTR;
            }
        });

        rl_take_method.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(View.GONE == et_take_method.getVisibility()){
                    usageDialog.getAdapter().checkItem(tv_take_method.getText().toString());
                }else {
                    usageDialog.getAdapter().checkItem(et_take_method.getText().toString());
                }
                usageDialog.updata(MedicineUsageUtil.getMedicineTakeMethodList());
                usageDialog.show();
                currentTag = TAG_TAKEMETHODSTR;
            }
        });

        usageDialog.setOnUsageDialogClickListener(new UsageDialog.OnUsageDialogClickListener() {
            @Override
            public void onCustomClick() {

            }

            @Override
            public void onSaveClick(String text) {
                if(TextUtils.isEmpty(text)){
                    shortToast("选择一个用法");
                    return;
                }
                if(currentTag.equals(TAG_TAKETIMESTR)){
                    tv_take_time.setText(text);
                    takeTimeStr = text;
                    et_take_time.setVisibility(View.GONE);
                    tv_take_time.setVisibility(View.VISIBLE);
                }else if(currentTag.equals(TAG_TAKEMETHODSTR)){
                    tv_take_method.setText(text);
                    takeMethodStr = text;
                    et_take_method.setVisibility(View.GONE);
                    tv_take_method.setVisibility(View.VISIBLE);
                }
                usageDialog.dismiss();
            }

            @Override
            public void onItemClick(String text) {
                if(currentTag.equals(TAG_TAKETIMESTR) && "手动输入".equals(text)){
                    takeTimeStr = "";
                    et_take_time.setText("");
                    et_take_time.setVisibility(View.VISIBLE);
                    tv_take_time.setVisibility(View.GONE);
                    UtilInputMethod.openInputMethod(et_take_time,CustomUsageActivity.this);

                    usageDialog.dismiss();
                }else if(currentTag.equals(TAG_TAKEMETHODSTR) && "手动输入".equals(text)){
                    takeMethodStr = "";
                    et_take_method.setText("");
                    et_take_method.setVisibility(View.VISIBLE);
                    tv_take_method.setVisibility(View.GONE);
                    UtilInputMethod.openInputMethod(et_take_method,CustomUsageActivity.this);
                    usageDialog.dismiss();
                }
            }
        });


    }

    @Override
    protected void save() {
        super.save();
        if(TextUtils.isEmpty(takeTimeStr)){
            takeTimeStr = et_take_time.getText().toString().trim();
        }
        if(TextUtils.isEmpty(takeMethodStr)){
            takeMethodStr = et_take_method.getText().toString().trim();
        }

        if(TextUtils.isEmpty(takeTimeStr)
                || TextUtils.isEmpty(takeMethodStr)){
            return;
        }

        UtilInputMethod.hiddenInputMethod(this);
        usageBean.setUsageTime(takeTimeStr);
        usageBean.setUsageMethod(takeMethodStr);
        Intent intent = new Intent();
        intent.putExtra(UsageDialog.TAG_USAGE_BEAN,usageBean);
        setResult(Activity.RESULT_OK,intent);
        finish();

    }
}
