package com.qlk.ymz.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.YY_FeedbackRecordActivity;
import com.qlk.ymz.activity.YY_TemplateListActivity;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.util.bi.BiUtil;

/**
 * @author shuYanYi on 2016/11/07.
 * @description 随访服务设置
 * @version V2.6.5
 */
public class YY_FeedbackSettingFragment extends DBFragment {
    /** 随访记录*/
    private View rl_feedback_record;
    /** 随访模板*/
    private View rl_feedback_template;

    @Override
    public boolean isBodyFragment() {
        return true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return init(inflater, R.layout.yy_l_fragment_feedback_setting);
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public void onStart() {
        super.onStart();
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(YY_FeedbackSettingFragment.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    @Override
    public void initWidgets() {
        rl_feedback_record = getViewById(R.id.rl_feedback_record);
        rl_feedback_template = getViewById(R.id.rl_feedback_template);
    }

    @Override
    public void listeners() {
        rl_feedback_record.setOnClickListener(this);
        rl_feedback_template.setOnClickListener(this);
    }




    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            //随访记录
            case R.id.rl_feedback_record:
                myStartActivity(YY_FeedbackRecordActivity.class);
                break;
            //随访模板
            case R.id.rl_feedback_template:
                myStartActivity(YY_TemplateListActivity.class);
                break;
        }
    }

}
