package com.qlk.ymz.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.hyphenate.chat.EMMessage;
import com.hyphenate.chat.EMTextMessageBody;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantChatRow;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantChatRowImage;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantChatRowText;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantChatRowVoice;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantCustomChatRowProvider;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.XD_ServiceChatActivity;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilAppToSystemApp;
import com.qlk.ymz.util.UtilInsertMsg2JsDb;
import com.qlk.ymz.util.qlkserivce.TF_DoctorAsstantFileUtils;
import com.qlk.ymz.util.qlkserivce.QlkServiceConstant;
import com.qlk.ymz.util.qlkserivce.QlkServiceHelper;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantChatEvaluation;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantChatPictureText;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantChatRobotMenu;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantChatTransferToKefu;
import com.qlk.ymz.view.ConfirmDialog;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.json.JSONException;
import org.json.JSONObject;

import static com.hyphenate.chat.EMMessage.*;

/**
 * Created by xiedongtd on 2016/7/8.
 */
public class XD_ServiceChatFragment extends TF_HuanXinChatFragment implements TF_HuanXinChatFragment.EaseChatFragmentHelper {

    // 避免和基类定义的常量可能发生的冲突，
    /**
     * 以下没有使用的类型  在客服端发送来时不做处理
     */
    //去往复制消息、删除消息Menu   目前没有使用
    public static final int REQUEST_CODE_CONTEXT_MENU = 14;
    //发送或接收订单图文组合消息      目前没有使用
    private static final int MESSAGE_TYPE_SENT_PICTURE_TXT = 1;
    private static final int MESSAGE_TYPE_RECV_PICTURE_TXT = 2;
    //发送或接受接收机器人列表消息   目前没有使用
    private static final int MESSAGE_TYPE_SENT_ROBOT_MENU = 3;
    private static final int MESSAGE_TYPE_RECV_ROBOT_MENU = 4;
    // 满意度评价    没有使用
    private static final int MESSAGE_TYPE_SENT_EVAL = 5;
    private static final int MESSAGE_TYPE_RECV_EVAL = 6;
    // 机器人转接客服   没有使用
    private static final int MESSAGE_TYPE_SENT_TRANSFER_TO_KEFU = 7;
    private static final int MESSAGE_TYPE_RECV_TRANSFER_TO_KEFU = 8;
    private static final int MESSAGE_TYPE_RECV_TXT = 9;
    private static final int MESSAGE_TYPE_SENT_TXT = 10;
    private static final int MESSAGE_TYPE_SENT_IMAGE = 11;
    private static final int MESSAGE_TYPE_RECV_IMAGE = 12;
    private static final int MESSAGE_TYPE_SENT_VOICE = 13;
    private static final int MESSAGE_TYPE_RECV_VOICE = 14;
    //评价
    public static final int REQUEST_CODE_EVAL = 26;
    //消息类型    客服端可添加技能组为医生的咨询进行分类
    protected int messageToIndex = QlkServiceConstant.MESSAGE_TO_DEFAULT;
    //拨打电话客服点击提示dialog
    private ConfirmDialog mPhoneConfirmDialog;
    private TextView sx_id_cancel_button;
    private TextView sx_id_confirm_button;
    private TextView sx_id_custom_text;
    private JSONObject weichatJson;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        //在父类中调用了initView和setUpView两个方法
        super.onActivityCreated(savedInstanceState);
        //判断是默认，还是用技能组（售前、售后）
        messageToIndex = fragmentArgs.getInt(QlkServiceConstant.MESSAGE_TO_INTENT_EXTRA, QlkServiceConstant.MESSAGE_TO_DEFAULT);
        //在聊天列表上是否显示用户昵称
        messageList.setShowUserNick(true);
    }

    @Override
    public void listeners() {
        //设置用户点击事件
        setChatFragmentListener(this);
        super.listeners();
        //设置titleUI及监听事件
        titleBar.setTitle("医生助手");
        titleBar.setRightLayoutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mPhoneConfirmDialog == null) {
                    createToPhoneDialog();
                } else {
                    mPhoneConfirmDialog.show();
                }
            }
        });
        titleBar.setLeftLayoutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((XD_ServiceChatActivity) getActivity()).back(view);
            }
        });
    }

    /**
     * 点击拨打电话弹出的dialog
     */
    private void createToPhoneDialog() {
        int srceenW = getActivity().getWindowManager().getDefaultDisplay().getWidth();
        mPhoneConfirmDialog = new ConfirmDialog(getActivity(), srceenW, 180
                , R.layout.sx_l_custom_dialog, R.style.xc_s_dialog);
        mPhoneConfirmDialog.setCanceledOnTouchOutside(false);
        sx_id_cancel_button = (TextView) mPhoneConfirmDialog.findViewById(R.id.sx_id_cancel_button);
        sx_id_confirm_button = (TextView) mPhoneConfirmDialog.findViewById(R.id.sx_id_confirm_button);
        sx_id_custom_text = (TextView) mPhoneConfirmDialog.findViewById(R.id.sx_id_custom_text);
        sx_id_custom_text.setText(UtilSP.getUserName() + ",您好! 如有任何疑问请与我们联系;我们的工作时间是:" + GlobalConfigSP.getServerTime());
        sx_id_cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPhoneConfirmDialog.dismiss();
            }
        });
        sx_id_confirm_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UtilAppToSystemApp.toPhone(getActivity(), GlobalConfigSP.getCustomerServPhone());
                mPhoneConfirmDialog.dismiss();
            }
        });
        mPhoneConfirmDialog.show();
    }

    /**
     * 长按列表中消息条目   进行选择后返回
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @SuppressLint("NewApi")
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_CONTEXT_MENU) {
            switch (resultCode) {

                default:
                    break;
            }
        }
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CODE_EVAL) {
                messageList.refresh();
            }
        }
    }

    /**
     * 第一次发送消息时 附加医生信息
     *
     * @param message
     */
    @Override
    public void onSetMessageAttributes(EMMessage message) {
        // 设置消息扩展属性
        setUserInfoAttribute(message);

        //指向某个客服 , 当会话同时指定了客服和技能组时，以指定客服为准，指定技能组失效。
//		pointToAgentUser(message, "chuanmuxiang@7lk.com");
    }

    /**
     * 头像点击事件
     *
     * @param username
     */
    @Override
    public void onAvatarClick(String username) {

    }

    /**
     * 头像长按
     *
     * @param username
     */
    @Override
    public void onAvatarLongClick(String username) {

    }

    /**
     *
     * @param message
     * @return
     */
    @Override
    public boolean onMessageBubbleClick(EMMessage message) {

        return false;
    }

    /**
     * @param message
     * @return
     */
    @Override
    public void onMessageBubbleLongClick(EMMessage message) {

    }

    /**
     * 自定义更多消息类型
     *
     * @return
     */
    @Override
    public TF_DoctorAsstantCustomChatRowProvider onSetCustomChatRowProvider() {
        //默认自定义添加了4种
        return new CustomChatRowProvider();
    }

    /**
     * 自定义消息message类型
     */
    private final class CustomChatRowProvider implements TF_DoctorAsstantCustomChatRowProvider {
        @Override
        public int getCustomChatRowTypeCount() {
            //此处返回的数目为getCustomChatRowType 中的布局的个数
            return 14;
        }

        @Override
        public int getCustomChatRowType(EMMessage message) {
            Type messageType = message.getType();
            if(messageType == Type.TXT){
                if (QlkServiceHelper.getInstance().isRobotMenuMessage(message)) {
                    // 机器人 列表菜单
                    return message.direct() == Direct.RECEIVE ? MESSAGE_TYPE_RECV_ROBOT_MENU
                            : MESSAGE_TYPE_SENT_ROBOT_MENU;
                } else if (QlkServiceHelper.getInstance().isEvalMessage(message)) {
                    // 满意度评价
                    return message.direct() == Direct.RECEIVE ? MESSAGE_TYPE_RECV_EVAL :
                            MESSAGE_TYPE_SENT_EVAL;
                } else if (QlkServiceHelper.getInstance().isPictureTxtMessage(message)) {
                    // 订单图文组合
                    return message.direct() == Direct.RECEIVE ?
                            MESSAGE_TYPE_RECV_PICTURE_TXT
                            : MESSAGE_TYPE_SENT_PICTURE_TXT;
                } else if (QlkServiceHelper.getInstance().isTransferToKefuMsg(message)) {
                    //转人工消息
                    return message.direct() == Direct.RECEIVE ?
                            MESSAGE_TYPE_RECV_TRANSFER_TO_KEFU
                            : MESSAGE_TYPE_SENT_TRANSFER_TO_KEFU;
                } else{
                    return message.direct() == EMMessage.Direct.RECEIVE ? MESSAGE_TYPE_RECV_TXT : MESSAGE_TYPE_SENT_TXT;
                }
            }

            if(messageType == Type.IMAGE){
                return message.direct() == EMMessage.Direct.RECEIVE ? MESSAGE_TYPE_RECV_IMAGE : MESSAGE_TYPE_SENT_IMAGE;
            }

            if(messageType == Type.VOICE){
                return message.direct() == EMMessage.Direct.RECEIVE ? MESSAGE_TYPE_RECV_VOICE : MESSAGE_TYPE_SENT_VOICE;
            }
            return 7;

        }

        @Override
        public TF_DoctorAsstantChatRow getCustomChatRow(EMMessage message, int position, BaseAdapter adapter) {
            Type messageType = message.getType();
            if ( messageType == Type.TXT) {
                if (QlkServiceHelper.getInstance().isRobotMenuMessage(message)) {
                    return new TF_DoctorAsstantChatRobotMenu(getActivity(), message, position, adapter);
                } else if (QlkServiceHelper.getInstance().isEvalMessage(message)) {
                    return new TF_DoctorAsstantChatEvaluation(getActivity(), message, position, adapter);
                } else if (QlkServiceHelper.getInstance().isPictureTxtMessage(message)) {
                    return new TF_DoctorAsstantChatPictureText(getActivity(), message, position, adapter);
                } else if (QlkServiceHelper.getInstance().isTransferToKefuMsg(message)) {
                    return new TF_DoctorAsstantChatTransferToKefu(getActivity(), message, position, adapter);
                }else {
                    return new TF_DoctorAsstantChatRowText(getActivity(), message, position, adapter);
                }
            }

            if( messageType == Type.IMAGE){
                return new TF_DoctorAsstantChatRowImage(getActivity(), message, position, adapter);
            }

            if( messageType == Type.VOICE){
                return new TF_DoctorAsstantChatRowVoice(getActivity(), message, position, adapter);
            }
            return null;
        }
    }

    /**
     * 设置用户的属性，
     * 通过消息的扩展，传递客服系统用户的属性信息
     *
     * @param message
     */
    private void setUserInfoAttribute(EMMessage message) {
        weichatJson = getWeichatJSONObject(message);
        try {
            JSONObject visitorJson = new JSONObject();
            if (info != null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("医生id:" + info.getDoctorId()+ "\n");
                stringBuilder.append("医生姓名:"+ info.getDoctorName()+"\n");
                stringBuilder.append("医生电话 :" + info.getPhone() + "\n");
                stringBuilder.append("医生性别 :" + info.getGender() + "\n");
                stringBuilder.append("医生所在单位 :" + info.getHospital() + "\n");
                stringBuilder.append("医生科室 :" + info.getDepartment() + "\n");
                stringBuilder.append("医生职称 :" + info.getTitle() + "\n");
                stringBuilder.append("医生所在地区 :" + info.getCityName() + "\n");
                stringBuilder.append("医生昵称:"+info.getDoctorName()+"\n");
                stringBuilder.append("上级商务代表:" + info.getParentName() + "\n");
                stringBuilder.append("上级商务代表所属地区 :" + info.getBusinessArea()+"\n");
                stringBuilder.append("上级商务代表所属公司 :" + info.getPartnerName()+"\n");
                stringBuilder.append("上级商务代表手机号码 :" + info.getParentPhone() + "\n");
                visitorJson.put("description", stringBuilder.toString());
                //            visitorJson.put("email", "abc@123.com");
                visitorJson.put("trueName",info.getDoctorName());
                visitorJson.put("phone",info.getPhone());
                visitorJson.put("companyName",info.getPartnerName());
                visitorJson.put("userNickname",info.getDoctorName());
                weichatJson.put("visitor", visitorJson);
                message.setAttribute("weichat", weichatJson);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取消息中的扩展 weichat是否存在并返回jsonObject
     *
     * @param message
     * @return
     */
    private JSONObject getWeichatJSONObject(EMMessage message) {
        JSONObject weichatJson = null;
        try {
            String weichatString = message.getStringAttribute("weichat", null);
            if (weichatString == null) {
                weichatJson = new JSONObject();
            } else {
                weichatJson = new JSONObject(weichatString);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return weichatJson;
    }

    /**
     * 指向某个具体客服，
     *
     * @param message       消息
     * @param agentUsername 客服的登录账号
     */
    private void pointToAgentUser(EMMessage message, String agentUsername) {
        try {
            JSONObject weichatJson = getWeichatJSONObject(message);
            weichatJson.put("agentUsername", agentUsername);
            message.setAttribute("weichat", weichatJson);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public void sendRobotMessage(String content, String menuId) {
        EMMessage message = createTxtSendMessage(content, toChatUsername);
        if (!TextUtils.isEmpty(menuId)) {
            JSONObject msgTypeJson = new JSONObject();
            try {
                JSONObject choiceJson = new JSONObject();
                choiceJson.put("menuid", menuId);
                msgTypeJson.put("choice", choiceJson);
            } catch (Exception e) {
            }
            message.setAttribute("msgtype", msgTypeJson);
        }
        sendMessage(message);
    }

    /**
     * update by tengfei date 2016/10/11
     * 重写sendmessage是为了在首页中展示医生与客服发送的最新消息
     */
    @Override
    protected void sendMessage(EMMessage message) {
        super.sendMessage(message);
        fileUtils.saveLogInfo(getActivity(), TF_DoctorAsstantFileUtils.DOCTOR_ASSTANT_CHAT, message.toString() + weichatJson);
        XC_ChatModel model = new XC_ChatModel();
        model.getUserPatient().setPatientId(JS_ChatListModel.SERVICE_ID);
        model.setSender(String.valueOf(XC_ChatModel.MSG_SENDER_TYPE_SERVICE_MY));
//         信息发送者类型标示（0医生，1患者，2公共通知，3账户动态，5系统确认购药咨询通知,6客服消息,7发给客服）
        model.getUserPatient().setPatientName("医生助手"); // 患者名称
        model.setMsgTime(System.currentTimeMillis() + ""); // 信息创建时间
        model.getUserDoctor().setDoctorSelfId(UtilSP.getUserId()); // 医生ID
        switch (message.getType()) {
            case TXT:
                model.setMsgType(String.valueOf(XC_ChatModel.TEXT));
                EMTextMessageBody txtBody = (EMTextMessageBody) message.getBody();
                model.setMessageText(txtBody.getMessage()); // 文本信息
                break;
            case IMAGE:
                model.setMsgType(String.valueOf(XC_ChatModel.PHOTO));
                break;
            case VOICE:
                model.setMsgType(String.valueOf(XC_ChatModel.VOICE));
                break;
        }

        UtilInsertMsg2JsDb.insert(getActivity(), model);
        //add by cyr on 2017-9-4 start 清掉未读消息数
        JS_ChatListDB.getInstance(getActivity(), UtilSP.getUserId()).setUnReadMessageNum2Zero(model.getUserPatient().getPatientId());
        //add by cyr on 2017-9-4 end 清掉未读消息数

        //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
        GrowingIOUtil.track("docAssistantMessage", null);
        //add by songxin,date：2018-3-29,about：GrowingIO banner track,end
    }

    @Override
    public void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mPhoneConfirmDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }
}
