package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_AddMedicalRecordShowPictureAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.Picture;
import com.qlk.ymz.model.PictureFileInfo;
import com.qlk.ymz.model.SX_MedicalRecordsInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;

import org.apache.http.Header;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * SX_AddMedicalRecordActivity
 * 添加诊疗记录
 * @author songxin on 2016/6/14.
 * @version 2.5.0
 *
 * @author shanqi on 2016.8.21 01:27:38
 * @version 2.6.0
 * @description 修改了图片删除和保存逻辑
 *
 * @modify shuYanYi on 2016-09-22
 * @version 2.7
 * @description 选择相册图片改为多选模式，
 *
 * @modify wangyong on 2017-06-19
 * @version 2.8
 * @description 添加编辑诊疗记录功能
 */
public class SX_AddMedicalRecordActivity extends DBActivity implements View.OnClickListener{
    /** title左边按钮*/
    private ImageView sx_id_title_left;
    /** title中间文字*/
    private TextView sx_id_title_center;
    /** title右边button*/
    private TextView sx_id_title_right_btn;
    /** 日期显示*/
    private TextView sx_id_date_show;
    /** 输入计数*/
    private TextView sx_id_word_count_record;
    /** 输入最大内容计数*/
    private TextView sx_id_write_content_max;
    /** 内容输入框*/
    private EditText sx_id_condition_record_edit;
    /** 添加图片显示*/
    private RecyclerView sx_id_add_pic_show;
    /** 选择文件变量*/
    private List<File> imageList = new ArrayList<>();
    /** 图片适配数据*/
    private LinkedList<PictureFileInfo> mPictureFileInfos = new LinkedList<>();
    /** 图片适配器*/
    private SX_AddMedicalRecordShowPictureAdapter mSX_addMedicalRecordShowPictureAdapter;
    /** 跳转到聊天必须封装的对象*/
    private XC_ChatModel xc_chatModel;
    /** 诊疗记录最大长度限制 */
    int maxLength = 0;
    /** 图片数量限制 */
    private int maxImgNum;
    /** 是否正在请求提交保存诊疗记录*/
    private boolean isAddRequesting = false;
    private SX_MedicalRecordsInfo mMedicalRecordsInfo;
    //诊疗记录UUID
    private String uuid;
    //编辑界面传递过来的图片
    private List<Picture> list;
    /** 删除文件变量*/
    private List<String> deleteImageList = new ArrayList<>();
    /** 网络图片缓存文件变量*/
    private List<String> cacheImageList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_add_medical_record);
        super.onCreate(savedInstanceState);
        sx_id_title_center.setText("诊疗记录");
        sx_id_title_right_btn.setVisibility(View.VISIBLE);
        sx_id_title_right_btn.setText("保存");
        sx_id_date_show.setText(UtilDate.getNow(UtilDate.FORMAT_SHORT_CN));

        xc_chatModel = (XC_ChatModel)getIntent().getSerializableExtra(CommonConfig.CHAT_PARAMS_MODEL);
        if(null == xc_chatModel){
            xc_chatModel = new XC_ChatModel();
        }
        mMedicalRecordsInfo = (SX_MedicalRecordsInfo) getIntent().getSerializableExtra(CommonConfig.PATIENT_MEDICALRECORD);
        if(mMedicalRecordsInfo != null) {
            uuid = mMedicalRecordsInfo.getUuid();
            sx_id_date_show.setText(mMedicalRecordsInfo.getYear_and_month()+mMedicalRecordsInfo.getDay());
            sx_id_condition_record_edit.setText(mMedicalRecordsInfo.getRecord_content());
            list = mMedicalRecordsInfo.getPictures();
            if (list != null && list.size() > 0) {
                for (Picture str : list) {
                    if (!TextUtils.isEmpty(str.getUrl())) {
                        cacheImageList.add(str.getUrl());
                        PictureFileInfo pictureFileInfo = new PictureFileInfo();
                        pictureFileInfo.setImageType(PictureFileInfo.IMAGE_TYPE_IMAGE);
                        pictureFileInfo.setLocalUrl(str.getUrl());
                        mPictureFileInfos.addFirst(pictureFileInfo);
                    }
                }
            }
        }
        initWidgetsData();
        //取服务器配置的极限值
        maxImgNum = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_RECORD_PIC_NUM, 0, 6);
        //图片数据初始化
        PictureFileInfo image_add = new PictureFileInfo();
        image_add.setImageType(PictureFileInfo.IMAGE_TYPE_IMAGE_ADD);
        image_add.setLocalUrl("drawable://" + R.mipmap.sx_d_add_medical_record_add);
        mPictureFileInfos.add(image_add);
        PictureFileInfo image_text = new PictureFileInfo();
        image_text.setImageType(PictureFileInfo.IMAGE_TYPE_TEXT);
        image_text.setLocalUrl("");
        mPictureFileInfos.addLast(image_text);
        //此设置优化recyclerview
        sx_id_add_pic_show.setHasFixedSize(true);
        //添加自定义分割线
//        sx_id_add_pic_show.addItemDecoration(new ItemDecoration(SX_AddMedicalRecordActivity.this, LinearLayoutManager.HORIZONTAL));
        //设置recyclerview的布局方式
        sx_id_add_pic_show.setLayoutManager(new GridLayoutManager(SX_AddMedicalRecordActivity.this, 4));
        //设置适配器
        mSX_addMedicalRecordShowPictureAdapter = new SX_AddMedicalRecordShowPictureAdapter(SX_AddMedicalRecordActivity.this,mPictureFileInfos,maxImgNum);
        sx_id_add_pic_show.setAdapter(mSX_addMedicalRecordShowPictureAdapter);
        mSX_addMedicalRecordShowPictureAdapter.setOnUIRefreshListener(new SX_AddMedicalRecordShowPictureAdapter.OnUIRefreshListener() {

            @Override
            public void recordPhotoRefresh(int pos, String url) {
                if (!TextUtils.isEmpty(uuid)) {
                    for (int i = 0; i < cacheImageList.size(); i++) {
                        if (url.equals(cacheImageList.get(i))) {
                            deleteImageList.add(list.get(i).getPicUuid());
                        }
                    }
                }
                if (mPictureFileInfos != null && mPictureFileInfos.size() > 1) {
                    deleteFile(mPictureFileInfos.size(),pos);
                    mPictureFileInfos.remove(pos);
                    mSX_addMedicalRecordShowPictureAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    /** created by songxin,date：2016-6-14,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_AddMedicalRecordActivity.class);
        UtilInputMethod.openInputMethod(sx_id_condition_record_edit,SX_AddMedicalRecordActivity.this);
    }

    /** created by songxin,date：2016-6-14,about：bi,end */


    @Override
    public void initWidgets() {
        sx_id_title_left = getViewById(R.id.sx_id_title_left);
        sx_id_title_center = getViewById(R.id.sx_id_title_center);
        sx_id_title_right_btn = getViewById(R.id.sx_id_title_right_btn);
        sx_id_date_show = getViewById(R.id.sx_id_date_show);
        sx_id_word_count_record = getViewById(R.id.sx_id_word_count_record);
        sx_id_condition_record_edit = getViewById(R.id.sx_id_condition_record_edit);
        sx_id_add_pic_show = getViewById(R.id.sx_id_add_pic_show);
        sx_id_write_content_max = getViewById(R.id.sx_id_write_content_max);
    }

    /**
     * 初始化控件显示的内容
     */
    private void initWidgetsData(){
        maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENTRECORDTEXT,0,300);
        sx_id_condition_record_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        sx_id_write_content_max.setText(+maxLength+"");

    }

    @Override
    public void listeners() {
        sx_id_title_left.setOnClickListener(this);
        sx_id_title_right_btn.setOnClickListener(this);
        sx_id_condition_record_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                sx_id_word_count_record.setText(s.length()+"");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.sx_id_title_left:{
                onBackPressed();
                break;
            }
            case R.id.sx_id_title_right_btn:{
                String content = sx_id_condition_record_edit.getText().toString().trim();
                String hasPicture = "0";
                if(!UtilCollection.isBlank(imageList) || cacheImageList.size() != deleteImageList.size()){
                    hasPicture = "1";
                }

                if("".equals(content) && "0".equals(hasPicture)){
                    shortToast("请输入本次的诊疗记录。");
                    return;
                }
                int minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENTRECORDTEXT,1,9);
                if(content.length() < minLength && "0".equals(hasPicture)){
                    shortToast("诊疗记录输入内容小于"+ minLength +"个字符，请重新输入。");
                    return;
                }
                if(TextUtils.isEmpty(uuid)){
                    addMedicalRecord(content,xc_chatModel.getType());
                }else {
                    editMedicalRecord(content,xc_chatModel.getType(),hasPicture);
                }
                break;
            }
            default:{
                break;
            }
        }
    }


    @Override
    public void onNetRefresh() {

    }



    /**
     * 删除文件索引
     * @param size 大小
     * @param position 位置
     */
    public void deleteFile(int size,int position){
        if(imageList.size() - 1 >= position) {
            imageList.remove(position);
        }
    }


    private void addMedicalRecord(String content, String type){
        if(isAddRequesting){
            return;
        }
        isAddRequesting = true;
        try {
            RequestParams params = new RequestParams();
            params.put("patientId",xc_chatModel.getUserPatient().getPatientId());
            params.put("content", content);
            params.put("type", type);

            if(!UtilCollection.isBlank(imageList)){
                //这里再生成压缩图存放，之前不确定上传的操作不去生成多余压缩图
                List<File> uploadFiles = UtilFile.ChangeImgsToUploadFiles(imageList);
                File[] pics = new File[uploadFiles.size()];
                params.put("pictures", uploadFiles.toArray(pics));
            }

            XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.newPatientRecord), params, new XCHttpResponseHandler() {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    printi("songxin", "arg2===onSuccess======>" + new String(arg2));
                    if (result_boolean) {
                        //通知患者病例页刷新诊疗记录
                        Intent intent = new Intent();
                        intent.setAction(XL_PatientInfoAActivity.NewMedicalReceiver.NEW_MEDICAL_ACTION);
                        context.sendBroadcast(intent);

                        finish();
                    }
                }

                // add by xjs on 20151027 19:48 start
                // 对账户冻结情况的判断处理
                public void onFinish() {
                    super.onFinish();
                    isAddRequesting = false;
                    if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_AddMedicalRecordActivity.this,
                           getCode(),
                           getMsg())) {
                        // 接口请求业务成功时的处理
                    }
                }
                // add by xjs on 20151027 19:48 end
            });
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 编辑诊疗记录
     * @param content
     * @param type
     */
    private void editMedicalRecord(String content,String type,String hasPic){
        try {
            StringBuilder sb = new StringBuilder("");
            if(deleteImageList != null && deleteImageList.size() >0){
                for (int i = 0; i < deleteImageList.size(); i++) {
                    String delUuid = deleteImageList.get(i);
                    if (!TextUtils.isEmpty(delUuid)) {
                        sb.append(delUuid);
                        if (i < deleteImageList.size() - 1) {
                            sb.append(",");
                        }
                    }
                }
            }
            RequestParams params = new RequestParams();
            params.put("patientId", xc_chatModel.getUserPatient().getPatientId());
            params.put("content", content);
            params.put("type", type);
            params.put("hasPic", hasPic);
            params.put("recordUuid", uuid);
            params.put("delPicUuids", sb.toString());
            if (!UtilCollection.isBlank(imageList)) {
                List<File> uploadFiles = UtilFile.ChangeImgsToUploadFiles(imageList);
                File[] pics = new File[uploadFiles.size()];
                params.put("pictures", uploadFiles.toArray(pics));
            }
            XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.editPatientRecord), params, new XCHttpResponseHandler() {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if (result_boolean) {
                        Intent intent = new Intent();
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                }

                @Override
                public void onFinish() {
                    super.onFinish();
                    if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_AddMedicalRecordActivity.this,
                            getCode(),
                            getMsg())) {

                    }
                }
            });
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).
                hideSoftInputFromWindow(SX_AddMedicalRecordActivity.this.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

    }

    /**
     * 以多选模式打开本地图片选择
     */
    public void openMutiplePhohoSelect(int num){
        int pickNum = maxImgNum - num;
        if(pickNum > 0){
            ToJumpHelp.toJumpSelctImgsActivity(SX_AddMedicalRecordActivity.this,pickNum,
                    YY_SelectImgsActivity.MODE_MULTIPLE, true,true,false,true);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //用户选择图片完成
        if(resultCode == RESULT_OK && requestCode == YY_SelectImgsActivity.REQUEST_IMAGE){
            if(data == null || data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT) == null){
                return;
            }
            ArrayList<File> files = (ArrayList<File>) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
            for(File file : files){
                imageList.add(0,file);
                PictureFileInfo pictureFileInfo = new PictureFileInfo();
                pictureFileInfo.setImageType(PictureFileInfo.IMAGE_TYPE_IMAGE);
                pictureFileInfo.setLocalUrl(file.getAbsolutePath());
                mPictureFileInfos.addFirst(pictureFileInfo);
            }
            mSX_addMedicalRecordShowPictureAdapter.notifyDataSetChanged();
        }
    }
}
