package com.qlk.ymz.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.YY_VideoDetailActivity;
import com.qlk.ymz.model.TF_VideoListContent;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;

import java.util.List;

/**
 * @author tengfei on 2016/7/22.
 * @version 1.0
 */
public class TF_VideoListAdapter extends XCBaseAdapter<TF_VideoListContent> {

    /**
     * 视频可接通 已结束标记    当前没有使用
     */
    private int mVideoCanStart = 1;
    private LayoutInflater mLayoutInflater;
    private List<TF_VideoListContent> mVideoListBeans;


    public TF_VideoListAdapter(Context context, List list, int mVideoCanStart) {
        super(context, list);
        this.mVideoCanStart = mVideoCanStart;
        this.mLayoutInflater = LayoutInflater.from(context);
        this.mVideoListBeans = list;
        this.context = context;

    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = mLayoutInflater.inflate(R.layout.tf_item_video_list, null);
            viewHolder = new ViewHolder();
            /** 患者名字 */
            viewHolder.tf_item_video_list_name_tv = (TextView) convertView.findViewById(R.id.tf_item_video_list_name_tv);
            /** 患者病情 */
            viewHolder.tf_item_video_list_info_tv = (TextView) convertView.findViewById(R.id.tf_item_video_list_info_tv);
            /** 左侧播放图片  */
            viewHolder.tf_item_video_list_icon_iv = (ImageView) convertView.findViewById(R.id.tf_item_video_list_icon_iv);
            /** 咨询日期  */
            viewHolder.tf_item_video_list_date_tv = (TextView) convertView.findViewById(R.id.tf_item_video_list_date_tv);
            /** 咨询状态  */
            viewHolder.tf_item_video_list_staus_tv = (TextView) convertView.findViewById(R.id.tf_item_video_list_staus_tv);
            /** 右侧查看图片  */
            viewHolder.tf_item_video_list_info_iv = (ImageView) convertView.findViewById(R.id.tf_item_video_list_info_iv);
            viewHolder.tf_video_bottom_line = convertView.findViewById(R.id.tf_video_bottom_line);
            convertView.setTag(viewHolder);

        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        //下方划线是否显示
        if (position == mVideoListBeans.size() - 1) {
            viewHolder.tf_video_bottom_line.setVisibility(View.GONE);
        } else {
            viewHolder.tf_video_bottom_line.setVisibility(View.VISIBLE);
        }
        TF_VideoListContent videoListContent = mVideoListBeans.get(position);
        //跳转到视频详情
        viewHolder.tf_item_video_list_info_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putSerializable("videoBean", list.get(position));
                intent.putExtras(bundle);
                intent.setClass(context, YY_VideoDetailActivity.class);
                context.startActivity(intent);

            }
        });
        //姓名默认只显示4位
        String name = videoListContent.getPatientName();
        if (name.length() > 4) {
            name = name.substring(0, 4) + "...";
        }
        viewHolder.tf_item_video_list_name_tv.setText(name);
        viewHolder.tf_item_video_list_info_tv.setText(videoListContent.getContent());
        viewHolder.tf_item_video_list_date_tv.setText(videoListContent.getCreatedAt());
        viewHolder.tf_item_video_list_staus_tv.setText(videoListContent.getStatusDescribe());
        //判断视频状态
        switch (videoListContent.getStatus()) {
            case 2: {
                if (videoListContent.getIsExceptionVideo() == 1) {
                    //未正常接通
                    viewHolder.tf_item_video_list_staus_tv.setTextColor(Color.parseColor("#e2231a"));
                    viewHolder.tf_item_video_list_date_tv.setTextColor(Color.parseColor("#e2231a"));
                    viewHolder.tf_item_video_list_icon_iv.setImageResource(R.mipmap.tf_video_icon_excaption);
                } else {
                    //等待接通
                    viewHolder.tf_item_video_list_staus_tv.setTextColor(Color.parseColor("#6db131"));
                    viewHolder.tf_item_video_list_date_tv.setTextColor(Color.parseColor("#6db131"));
                    viewHolder.tf_item_video_list_icon_iv.setImageResource(R.mipmap.tf_video_icon_wait_connection);
                }
                break;
            }
            /** 已取消 */
            case 3: {
//                6.0之后getResources().getColor()方法被废弃了，大家可以用ContextCompat.getColor(context, R.color.color_name)替换，ContextCompat 是 v4 包里的，请放心使用，另外还有getDrawable()等方法
                viewHolder.tf_item_video_list_staus_tv.setTextColor(ContextCompat.getColor(context, R.color.c_gray_cccccc));
                viewHolder.tf_item_video_list_date_tv.setTextColor(ContextCompat.getColor(context, R.color.c_gray_cccccc));
                viewHolder.tf_item_video_list_icon_iv.setImageResource(R.mipmap.tf_video_icon_cancle);
                break;
            }
            /** 已完成 */
            case 4: {
                viewHolder.tf_item_video_list_staus_tv.setTextColor(ContextCompat.getColor(context, R.color.c_gray_7b7b7b));
                viewHolder.tf_item_video_list_date_tv.setTextColor(ContextCompat.getColor(context, R.color.c_gray_7b7b7b));
                viewHolder.tf_item_video_list_icon_iv.setImageResource(R.mipmap.tf_video_icon_command);
                break;
            }

        }

        return convertView;
    }

    class ViewHolder {
        /**
         * 患者名字
         */
        TextView tf_item_video_list_name_tv;
        /**
         * 患者病情
         */
        TextView tf_item_video_list_info_tv;
        /**
         * 左侧播放图片
         */
        ImageView tf_item_video_list_icon_iv;
        /**
         * 咨询日期
         */
        TextView tf_item_video_list_date_tv;
        /**
         * 咨询状态
         */
        TextView tf_item_video_list_staus_tv;
        /**
         * 右侧查看图片
         */
        ImageView tf_item_video_list_info_iv;
        View tf_video_bottom_line;
    }
}
