package com.qlk.ymz.adapter;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.qlk.ymz.R;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.Utils;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * SX_ChoosePatientAdapter
 * 选择患者适配器
 * @author songxin on 2016/12/13.
 * @version 2.7.0
 */
public class SX_ChoosePatientAdapter extends BaseExpandableListAdapter {
    private List<List<XC_ChatModel>> childrenData;
    private List<String> groupData;
    private Context context;
    private LayoutInflater inflater;

    public SX_ChoosePatientAdapter(List<List<XC_ChatModel>> childrenData, List<String> groupData , Activity activity) {
        this.groupData = groupData;
        this.childrenData = childrenData;
        this.context = activity;
        inflater = LayoutInflater.from(this.context);
    }

    /** PinnedHeaderExpandableListView页需要调用 */
    public List<String> getGroupDate() {
        return groupData;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public int getGroupCount() {
        return groupData.size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return groupData.get(groupPosition);
    }
    class GroupViewHolder {
        TextView xc_id_fragment_search_letter_view;
    }


    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupViewHolder groupViewHolder;
        if(null == convertView){
            convertView = inflater.inflate(R.layout.sx_l_adapter_choose_patient_group_item, null);
            groupViewHolder = new GroupViewHolder();
            groupViewHolder.xc_id_fragment_search_letter_view = (TextView) convertView.findViewById(R.id.xc_id_fragment_search_letter_view);
            convertView.setTag(groupViewHolder);
        }else{
            groupViewHolder = (GroupViewHolder) convertView.getTag();
        }
        if (groupViewHolder.xc_id_fragment_search_letter_view != null) {
            groupViewHolder.xc_id_fragment_search_letter_view.setText(groupData.get(groupPosition));
        }
        return convertView;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return childrenData.get(groupPosition).get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return 0;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        if (groupPosition < 0)
            return 0;
        return childrenData.get(groupPosition).size();
    }
    class ChildViewHolder {
        RelativeLayout sx_id_choose_patient_rl;//外框
        TextView sx_id_choose_patient_cb;//最左测选择框
        TextView sx_id_choose_patient_name;//患者名字
        View sx_id_bottom_line;//底边框线
        ImageView iv_patient_icon;//患者头像
        ImageView iv_patient_gender;
        TextView tv_patient_age;

    }

    @Override
    public View getChildView(final int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        final ChildViewHolder childViewHolder;
        final XC_ChatModel bean = childrenData.get(groupPosition).get(childPosition);
        if(null == convertView){
            convertView = inflater.inflate(R.layout.sx_l_adapter_choose_patient_child_item, null);
            childViewHolder = new ChildViewHolder();
            childViewHolder.sx_id_choose_patient_cb = (TextView)convertView.findViewById(R.id.sx_id_choose_patient_cb);
            childViewHolder.sx_id_choose_patient_name = (TextView)convertView.findViewById(R.id.sx_id_choose_patient_name);
            childViewHolder.sx_id_bottom_line = convertView.findViewById(R.id.sx_id_bottom_line);
            childViewHolder.sx_id_choose_patient_rl = (RelativeLayout)convertView.findViewById(R.id.sx_id_choose_patient_rl);
            childViewHolder.iv_patient_icon = (ImageView) convertView.findViewById(R.id.iv_patient_icon);
            childViewHolder.iv_patient_gender = (ImageView) convertView.findViewById(R.id.iv_patient_gender);
            childViewHolder.tv_patient_age = (TextView)convertView.findViewById(R.id.tv_patient_age);
            convertView.setTag(childViewHolder);
        }else {
            childViewHolder = (ChildViewHolder) convertView.getTag();
        }
        //姓名
        childViewHolder.sx_id_choose_patient_name.setText(Utils.getPatientDisplayName(bean.getUserPatient().getPatientMemoName()
                , bean.getUserPatient().getPatientName()));

//      设置行间底部分割线，如果是当前字母最后一个则隐藏
        if (childrenData.get(groupPosition).size() - 1 == childPosition) {
            childViewHolder.sx_id_bottom_line.setVisibility(View.INVISIBLE);
        }else {
            childViewHolder.sx_id_bottom_line.setVisibility(View.VISIBLE);
        }

        //加载患者头像
        //显式的将checkActualViewSize设为false, 这样图片的缓存也将只会保存一个副本,保证第二次查询时可以直接命中
        //具体原因可以参考这个链接 http://www.cnblogs.com/wuxilin/p/4333241.html
        ImageAware imageAware = new ImageViewAware(childViewHolder.iv_patient_icon, false);
        String patientIcon = bean.getUserPatient().getPatientImgHead();
        if (!TextUtils.isEmpty(patientIcon) && URLUtil.isValidUrl(patientIcon)) {
            XCApplication.displayImage(patientIcon, childViewHolder.iv_patient_icon, XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default));
        } else {
            XCApplication.base_imageloader.displayImage("drawable://" + R.mipmap.xc_d_chat_patient_default, imageAware, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_patient_default));
        }

        //性别
        if (CommonConfig.GENDER_MALE.equals(bean.getUserPatient().getPatientGender())) {
            childViewHolder.iv_patient_gender.setBackgroundResource(R.mipmap.icon_patient_man);
            childViewHolder.iv_patient_gender.setVisibility(View.VISIBLE);
        } else if (CommonConfig.GENDER_FEMALE.equals(bean.getUserPatient().getPatientGender())) {
            childViewHolder.iv_patient_gender.setBackgroundResource(R.mipmap.icon_patient_women);
            childViewHolder.iv_patient_gender.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.iv_patient_gender.setVisibility(View.GONE);
        }
//      年龄
        if (!TextUtils.isEmpty(bean.getUserPatient().getPatientAge())) {
            childViewHolder.tv_patient_age.setText(bean.getUserPatient().getPatientAge() + "岁  ");
        } else {
            childViewHolder.tv_patient_age.setText("");
        }

        if(childrenData.get(groupPosition).get(childPosition).getUserPatient().isChoose()){
            childViewHolder.sx_id_choose_patient_cb.setText("已添加");
            childViewHolder.sx_id_choose_patient_cb.setTextColor(context.getResources().getColor(R.color.c_white_ffffff));
            childViewHolder.sx_id_choose_patient_cb.setBackgroundResource(R.drawable.sx_dd_bg_dddddd_r2);
        }else {
            childViewHolder.sx_id_choose_patient_cb.setText("添加");
            childViewHolder.sx_id_choose_patient_cb.setTextColor(context.getResources().getColor(R.color.c_e2231a));
            childViewHolder.sx_id_choose_patient_cb.setBackgroundResource(R.drawable.pf_line_e2231a_bg_white_round_2);
        }

        childViewHolder.sx_id_choose_patient_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bean.getUserPatient().setChoose(!bean.getUserPatient().isChoose());
                notifyDataSetChanged();
            }
        });
        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    LinkedHashMap<String, Integer> sava_letter_position_map = new LinkedHashMap<>();

    // 获取字母的位置
    public Integer getPositionFromLetter(String letter) {
        return sava_letter_position_map.get(letter);
    }

    /** 和患者列表中的字母位置对应：右侧按住哪个字母，列表就滑动到相应位置 */
    public LinkedHashMap<String, Integer> initLettersPosition(List<String> listParent, List<List<XC_ChatModel>> listChild) {
        String record_last_letter = null;
        for (int i = 0; i < listParent.size(); i++) {
            String letter = listParent.get(i);
            if (!letter.equals(record_last_letter)) {
                if (listChild.size() > 0 && listChild.get(i) != null) {
                    if (i == 0) {
                        sava_letter_position_map.put(letter, 0);
                    } else {
                        // position等于上一个字母的位置+改字母的子项的数量
                        int position = 1 + sava_letter_position_map.get(record_last_letter) + listChild.get(i - 1).size();
                        sava_letter_position_map.put(letter, position);
                    }
                }
            }
            record_last_letter = letter;
        }
        return sava_letter_position_map;
    }

    public void updateABCPosition() {
        sava_letter_position_map.clear();
        if (groupData != null && groupData.size() > 0 && childrenData != null && childrenData.size() == groupData.size()) {
            initLettersPosition(groupData, childrenData);
        }
    }
}
