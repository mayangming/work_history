package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.Utils;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

/**
 *
 * Created by sinki on 2015/6/17.
 * @modify xilinch
 * @version 1.0
 * @description 添加银行卡
 */
public class SK_AddBankCardActivityV2 extends DBActivity {
    /**
     * 通用标题
     */
    XCTitleCommonLayout titlebar;

    // ********************控件********************
    /**
     * 添加银行卡布局
     */
    RelativeLayout sk_id_add_bank_card_rl;
    /**
     * 银行卡文字控件
     */
    TextView sk_id_add_bank_tv;
    /**
     * 银行卡提示说明
     */
    TextView xl_add_bank_tv_note;

    /**
     * 依次为银行卡卡号输入框、用户名输入框、开户行输入框
     */
    EditText xl_add_bank_et_card,xl_add_bank_et_name,xl_add_bank_et_openCard;
    // ********************控件 end ********************

    // ********************变量********************
    /**
     * 银行数据对象，添加银行卡需要首先选择银行
     */
    XCJsonBean bankBean;

    // ********************常量********************
    /**
     * 选择银行的requestCode
     */
    public static int BANK_CARD = 202;
    /** 银行卡号码最大长度 */
    int bankCardBranchMax = 0;
    /** 银行卡开户行地址最大长度 */
    int bankCardNumMax= 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sk_l_activity_add_bank_card_v2);
        super.onCreate(savedInstanceState);

    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SK_AddBankCardActivityV2.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleCenter(true, "添加银行卡");
        titlebar.setTitleRight2(true, 0, "完成");
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));

        sk_id_add_bank_card_rl = getViewById(R.id.sk_id_add_bank_card_rl);
        sk_id_add_bank_tv = getViewById(R.id.sk_id_add_bank_tv);
        xl_add_bank_et_card = getViewById(R.id.xl_add_bank_et_card);
        xl_add_bank_et_name = getViewById(R.id.xl_add_bank_et_name);
        xl_add_bank_et_openCard = getViewById(R.id.xl_add_bank_et_openCard);
        xl_add_bank_tv_note = getViewById(R.id.xl_add_bank_tv_note);
        String name = UtilSP.getUserName();
        if(TextUtils.isEmpty(name)){
            xl_add_bank_et_name.setEnabled(true);
        }else{
            xl_add_bank_et_name.setEnabled(false);
            xl_add_bank_et_name.setText(UtilSP.getUserName());
        }
        String note = "<font color='#666666'>开户行名称需填写省市，我们才能够划款成功哦，如：</font><font color='#42bd05'>广东省广州增城支行。</font>";
//        SpannableString ss = new SpannableString(note);
//        ss.setSpan(new BackgroundColorSpan(Color.parseColor("#2b98f6")), note.indexOf("广东省"), note.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        xl_add_bank_tv_note.setTextSize(16);
        xl_add_bank_tv_note.setText(Html.fromHtml(note));
        Utils.bankCardNumAddSpace(xl_add_bank_et_card);

        bankCardBranchMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_GROUP_NAME, 0, 19);
        bankCardNumMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.BANKCARDNUM,0,19);
        xl_add_bank_et_openCard.setFilters(new InputFilter[]{new InputFilter.LengthFilter(bankCardBranchMax)});
        xl_add_bank_et_card.setFilters(new InputFilter[]{new InputFilter.LengthFilter(bankCardNumMax + 3)});
    }

    @Override
    public void listeners() {
        titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //判断合法性
                if (isValid()) {
                    requestData();
                } else {
                    printi("添加银行卡，数据不合法!");
                }
            }
        });

        sk_id_add_bank_card_rl.setOnClickListener(this);
    }


    private void requestData() {
        RequestParams params = new RequestParams();
        params.put("name",xl_add_bank_et_name.getText().toString().trim());
        params.put("bId",bankBean.getString("bId"));
        params.put("userType","1");//0商务代表，1医生
        params.put("branch",xl_add_bank_et_openCard.getText().toString().trim());
        params.put("bankCardNum", xl_add_bank_et_card.getText().toString().trim());
        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.addBankCard), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    myFinish();
                }
            }
            @Override
            public void onFinish() {
                super.onFinish();
                // 处理code操作
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SK_AddBankCardActivityV2.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 判断提交数据是否合法
     * @return
     */
    private boolean isValid() {
        boolean isValid = false;
        String name = xl_add_bank_et_name.getText().toString().trim();
        String card = xl_add_bank_et_card.getText().toString().trim();
        String openCard = xl_add_bank_et_openCard.getText().toString().trim();
        int bankCardBranchMIN = GlobalConfigSP.getLimitValue(GlobalConfigSP.BANKCARDBRANCH,1,1);
        int bankCardNumMIN = GlobalConfigSP.getLimitValue(GlobalConfigSP.BANKCARDNUM,1,16);
        //取银行卡真实长度（预防固定空格不确定，判断限制提交时例如如果最小值设置为14，就不是固定加3个空格，而是加2个）
        int cardRealLen = card.replaceAll(" ", "").length();
        if (bankBean == null) {
            shortToast("请先选择银行!");
            return isValid;
        }else if(TextUtils.isEmpty(bankBean.getString("bId"))){
            shortToast("对不起,银行卡异常");
            return isValid;
        }else if(TextUtils.isEmpty(name)){
            shortToast("请输入您的银行卡开户姓名");
            return isValid;
        }else if(name.length() > 15){
            shortToast("请输入合法的银行卡开户姓名");
            return isValid;
        }else if(TextUtils.isEmpty(card)){
            shortToast("请输入您的银行卡卡号");
            return isValid;
        }else if(cardRealLen < bankCardNumMIN || cardRealLen > bankCardNumMax){
            //update by cyr on 2016/7/5 （4444 4444 4444 44444）因银行卡中间有三个空格，此处判断长度需特别处理
            shortToast("请输入正确的银行卡卡号!");
            return isValid;
        }else if(TextUtils.isEmpty(openCard)){
            shortToast("请输入开户行!");
            return isValid;
        }else if(openCard.length() < bankCardBranchMIN || openCard.length() > bankCardBranchMax){
            shortToast("开户行信息长度不符合规则,长度范围为"+bankCardBranchMIN+"~"+bankCardBranchMax);
            return isValid;
        }

        isValid = true;

        return isValid;
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.sk_id_add_bank_card_rl:
                myStartActivityForResult(SK_BankCardActivityV2.class, BANK_CARD);
                break;
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println("requestCode "+ requestCode);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }

        //选择银行卡
        if (requestCode == BANK_CARD) {
            bankBean = (XCJsonBean)data.getSerializableExtra(SK_BankCardActivityV2.BANK_CARD_NAME);
            sk_id_add_bank_tv.setText(bankBean.getString("bName"));
        }
    }



}
