package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.maintab.YR_PatientFragment;
import com.qlk.ymz.model.PatientInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

/**
 * 患者个人资料页
 *
 * @author wangyong on 2017/05/31
 * @version v2.8
 */
public class PatientPersonInfoActivity extends DBActivity {
    //Title
    private XCTitleCommonLayout titlebar;
    //患者id
    private String mPatientId;
    // 医生填写的患者备注名
    private String remarkName;
    // 患者真实姓名
    private String realName;
    // 姓名编辑框
    private EditText xl_patient_et_noteName;
    //采用姓名布局
    private LinearLayout make_name_layout;
    //采用姓名控件
    private TextView make_name_tv;
    //采用姓名图片
    private ImageView make_name_img;
    // 性别选择(男)布局
    private LinearLayout sx_id_male_choose_layout;
    // 性别选择(女)布局
    private LinearLayout sx_id_female_choose_layout;
    // 性别选择(男)
    private ImageView sx_id_male_choose;
    // 性别选择(女)
    private ImageView sx_id_female_choose;
    //采用性别布局
    private LinearLayout make_sex_layout;
    //采用性别控件
    private TextView make_sex_tv;
    //采用性别图片
    private ImageView make_sex_img;
    //年龄编辑框
    private EditText sx_id_age;
    //采用年龄布局
    private LinearLayout make_age_layout;
    //采用年龄控件
    private TextView make_age_tv;
    //采用年龄图片
    private ImageView make_age_img;
    //地址编辑框
    private EditText sx_id_address;
    //采用地址布局
    private LinearLayout make_address_layout;
    //采用地址控件
    private TextView make_address_tv;
    //采用地址图片
    private ImageView make_address_img;
    //填写手机号
    private EditText sx_id_phone;
    //采用手机号布局
    private LinearLayout make_phone_layout;
    //采用手机号控件
    private TextView make_phone_tv;
    //采用手机号图片
    private ImageView make_phone_img;
    // 医生填写的患者性别
    private String patientSex;
    // 医生填写的患者年龄
    private String patientAge;
    // 医生填写的患者地址
    private String patientAddress;
    // 医生填写的患者手机号
    private String patientPhone;
    //是否提示患者填写的基本信息
    private String showTips;
    //选中的性别
    private String sex_choose = "";
    private XC_ChatModel xc_chatModel;
    private YR_CommonDialog PatientInfoDialog;
    /** 备注名最大长度*/
    private int max_length_remark_name;
    /** 备注名最小长度*/
    private int min_length_remark_name;
    /** 地址最大长度*/
    private int max_length_address;
    // 患者填写的名字
    private String patientNameStr;
    // 患者填写的性别
    private String patientSexStr;
    // 患者填写的年龄
    private String patientAgeStr;
    // 患者填写的地址
    private String patientAddressStr;
    // 患者填写的手机号
    private String patientPhoneStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_patient_person_info);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PatientPersonInfoActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */

    @Override
    public void initWidgets() {
        max_length_remark_name = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_REMARK_NAME,0,19);
        min_length_remark_name = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_REMARK_NAME,1,1);
        max_length_address = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_REMARK_ADDRESS,0,50);
        initTitle();
        xl_patient_et_noteName = getViewById(R.id.sx_id_name);
        make_name_layout = getViewById(R.id.make_name_layout);
        make_name_tv = getViewById(R.id.new_name_tv);
        make_name_img = getViewById(R.id.make_name_img);
        sx_id_male_choose_layout = getViewById(R.id.sx_id_male_layout);
        sx_id_female_choose_layout = getViewById(R.id.sx_id_female_layout);
        sx_id_male_choose = getViewById(R.id.sx_id_male);
        sx_id_female_choose = getViewById(R.id.sx_id_female);
        make_sex_layout = getViewById(R.id.sex_linelayout);
        make_sex_tv = getViewById(R.id.make_sex_tv);
        make_sex_img = getViewById(R.id.make_sex_img);
        sx_id_age = getViewById(R.id.sx_id_age);
        make_age_layout = getViewById(R.id.new_age_layout);
        make_age_tv = getViewById(R.id.new_age_tv);
        make_age_img = getViewById(R.id.make_age_img);
        sx_id_address = getViewById(R.id.sx_id_address);
        make_address_layout = getViewById(R.id.new_address_layout);
        make_address_tv = getViewById(R.id.new_address_tv);
        make_address_img = getViewById(R.id.make_address_img);
        sx_id_phone = getViewById(R.id.sx_id_mobile);
        make_phone_layout = getViewById(R.id.new_phone_layout);
        make_phone_tv = getViewById(R.id.new_phone_tv);
        make_phone_img = getViewById(R.id.make_phone_img);
        initData();
        initPatientInfoDialog();
    }

    @Override
    public void listeners() {
        make_name_img.setOnClickListener(this);
        sx_id_male_choose_layout.setOnClickListener(this);
        sx_id_female_choose_layout.setOnClickListener(this);
        make_sex_img.setOnClickListener(this);
        make_age_img.setOnClickListener(this);
        make_address_img.setOnClickListener(this);
        make_phone_img.setOnClickListener(this);
        xl_patient_et_noteName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if ("1".equals(showTips)) {
                    String str = editable.toString().replaceAll(" ", "");
                    if (!TextUtils.isEmpty(patientNameStr)) {
                        String name = patientNameStr.replaceAll(" ", "");
                        if (!name.equals(str)) {
                            make_name_tv.setText("患者填写了姓名：“" + patientNameStr + "”");
                            make_name_layout.setVisibility(View.VISIBLE);
                        }else{
                            make_name_layout.setVisibility(View.GONE);
                        }
                    }
                } else {
                    make_name_layout.setVisibility(View.GONE);
                }
            }
        });
        sx_id_age.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if ("1".equals(showTips)) {
                    String str = editable.toString().replaceAll(" ", "");
                    if (!TextUtils.isEmpty(patientAgeStr)) {
                        String age = patientAgeStr.replaceAll(" ", "");
                        if (!age.equals(str)) {
                            make_age_tv.setText("患者填写了年龄：“" + patientAgeStr + "”");
                            make_age_layout.setVisibility(View.VISIBLE);
                        }else {
                            make_age_layout.setVisibility(View.GONE);
                        }
                    }
                } else {
                    make_age_layout.setVisibility(View.GONE);
                }
            }
        });
        sx_id_address.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if ("1".equals(showTips)) {
                    String str = editable.toString().replaceAll(" ", "");
                    if (!TextUtils.isEmpty(patientAddressStr)) {
                        String address = patientAddressStr.replaceAll(" ", "");
                        if (!address.equals(str)) {
                            make_address_tv.setText("患者填写了地址：“" + patientAddressStr + "”");
                            make_address_layout.setVisibility(View.VISIBLE);
                        }else {
                            make_address_layout.setVisibility(View.GONE);
                        }
                    }
                } else {
                    make_address_layout.setVisibility(View.GONE);
                }
            }
        });
        sx_id_phone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if ("1".equals(showTips)) {
                    String str = editable.toString().replaceAll(" ", "");
                    if (!TextUtils.isEmpty(patientPhoneStr)) {
                        String phone = patientPhoneStr.replaceAll(" ", "");
                        if (!phone.equals(str)) {
                            make_phone_tv.setText("患者填写了手机：“" + patientPhoneStr + "”");
                            make_phone_layout.setVisibility(View.VISIBLE);
                        }else {
                            make_phone_layout.setVisibility(View.GONE);
                        }
                    }
                } else {
                    make_phone_layout.setVisibility(View.GONE);
                }
            }
        });
        titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = xl_patient_et_noteName.getText().toString().trim();
                String address = sx_id_address.getText().toString().trim();
                String phone = sx_id_phone.getText().toString().trim();
                String ageStr = sx_id_age.getText().toString().trim();
                if (!text.equals(remarkName) || !sex_choose.equals(patientSex) || !ageStr.equals(patientAge)
                        || !address.equals(patientAddress) || !phone.equals(patientPhone)) {
                    PatientInfoDialog.show();
                    return;
                }
                myFinish();
            }
        });
        titlebar.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = xl_patient_et_noteName.getText().toString().trim();
                String address = sx_id_address.getText().toString().trim();
                String phone = sx_id_phone.getText().toString().trim();
                String ageStr = sx_id_age.getText().toString().trim();
                int age = 0;
                if (!TextUtils.isEmpty(ageStr)) {
                    age = Integer.valueOf(ageStr);
                }
                remarkName = remarkName.trim();
                //小于最小限制值并且不是置空的情况 （比如后台配置备注名要2个字以上，置空的情况是清空备注名要请求后台，所以text.length() != 0条件要保留）
                if (text.length() < min_length_remark_name && text.length() != 0) {
                    shortToast("姓名需" + min_length_remark_name + "个字以上");
                    return;
                }
                if (!TextUtils.isEmpty(ageStr)) {
                    if (age < 1 || age > 200) {
                        shortToast("请填写1~200之间的年龄");
                        return;
                    }
                }
                if (!TextUtils.isEmpty(phone)) {
                    if (!isMobile(phone)) {
                        shortToast("手机号格式不对，请重新输入");
                        return;
                    }
                }

                if (text.equals(remarkName) && sex_choose.equals(patientSex) && ageStr.equals(patientAge)
                        && address.equals(patientAddress) && phone.equals(patientPhone)) {
                    shortToast("你还没有修改");
                    return;
                }
                editPatientInfo(text, sex_choose, ageStr, address, phone);
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }

    /**
     * 初始化标题
     */
    public void initTitle() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "患者信息");
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleRight2(true, 0, "保存");
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));
    }

    /**
     * 初始化数据
     */
    private void initData() {
        xc_chatModel = (XC_ChatModel) getIntent().getSerializableExtra(CommonConfig.CHAT_PARAMS_MODEL);
        if (xc_chatModel != null) {
            remarkName = xc_chatModel.getUserPatient().getPatientMemoName();
            patientSex = xc_chatModel.getUserPatient().getPatientGender();
            if (CommonConfig.GENDER_MALE.equals(patientSex)) {
                patientSex = "1";
            } else if (CommonConfig.GENDER_FEMALE.equals(patientSex)) {
                patientSex = "0";
            } else {
                patientSex = "";
            }
            patientAge = xc_chatModel.getUserPatient().getPatientAge();
            patientAddress = xc_chatModel.getUserPatient().getCityName();
            patientPhone = xc_chatModel.getUserPatient().getPatientPhone();
            showTips = xc_chatModel.getUserPatient().getShowTips();
            if ("1".equals(showTips)) {
                PatientInfo info = xc_chatModel.getUserPatient().getTipsInfo();
                patientNameStr = info.getRemarkName();
                patientSexStr = info.getGender();
                if (CommonConfig.GENDER_MALE.equals(patientSexStr)) {
                    patientSexStr = "1";
                } else if (CommonConfig.GENDER_FEMALE.equals(patientSexStr)) {
                    patientSexStr = "0";
                } else {
                    patientSexStr = "";
                }
                patientAgeStr = info.getAge();
                patientAddressStr = info.getAddress();
                patientPhoneStr = info.getPhone();
            }
        }
        //患者ID不能为空
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            mPatientId = bundle.getString(CommonConfig.PATIENT_ID);
        }
        if (TextUtils.isEmpty(mPatientId)) {
            Toast.makeText(this, "患者ID非法", Toast.LENGTH_SHORT).show();
        }
        if (TextUtils.isEmpty(remarkName)) {
            remarkName = "";
        }
        xl_patient_et_noteName.setText(remarkName);
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(max_length_remark_name);
        xl_patient_et_noteName.setFilters(inputFilters);
        xl_patient_et_noteName.setSelection(xl_patient_et_noteName.getText().toString().length());
        if ("1".equals(showTips)) {
            String nameStr = "";
            if (!TextUtils.isEmpty(remarkName)) {
                nameStr = remarkName.replaceAll(" ", "");
            }
            if (!TextUtils.isEmpty(patientNameStr)) {
                String name = patientNameStr.replaceAll(" ", "");
                if (!name.equals(nameStr)) {
                    make_name_tv.setText("患者填写了姓名：“" + patientNameStr + "”");
                    make_name_layout.setVisibility(View.VISIBLE);
                }else{
                    make_name_layout.setVisibility(View.GONE);
                }
            }
        } else {
            make_name_layout.setVisibility(View.GONE);
        }
        if ("1".equals(patientSex)) {
            sex_choose = "1";
            sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_sure);
            sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
        } else if ("0".equals(patientSex)) {
            sex_choose = "0";
            sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
            sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_sure);
        }
        sx_id_age.setText(patientAge);
        sx_id_address.setText(patientAddress);
        sx_id_address.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max_length_address)});
        sx_id_phone.setText(patientPhone);
    }

    /**
     * 判断是否是合格的手机号
     *
     * @param num
     * @return
     */
    private boolean isMobile(String num) {
        if (num != null && num.length() == 11) {
            return true;
        }
        return false;
    }

    /**
     * 是否保存备注信息对话框
     */
    private void initPatientInfoDialog() {
        if (PatientInfoDialog == null) {
            PatientInfoDialog = new YR_CommonDialog(PatientPersonInfoActivity.this, "还没有保存", "放弃", "取消") {
                @Override
                public void confirmBtn() {
                    PatientInfoDialog.dismiss();
                }

                @Override
                public void cancelBtn() {
                    super.cancelBtn();
                    myFinish();
                }
            };
            PatientInfoDialog.setCanceledOnTouchOutside(true);
        }
    }

    /**
     * 修改患者备注信息
     */
    private void editPatientInfo(String nameStr, String gender, String age, String addressStr, String phoneStr) {
        RequestParams params = new RequestParams();
        params.put("remarkName", nameStr);
        params.put("gender", gender);
        params.put("age", age);
        params.put("address", addressStr);
        params.put("phone", phoneStr);
        params.put("patientId", mPatientId);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.modifyPatientInfo), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    intent.setAction(YR_PatientFragment.REFRESH_ACTION);
                    sendBroadcast(intent);
                    finish();
                }
            }

            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(PatientPersonInfoActivity.this,
                        getCode(),
                        getMsg())) {

                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        int id = v.getId();
        switch (id) {
            case R.id.sx_id_male_layout:
                sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_sure);
                sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                sex_choose = "1";
                if ("1".equals(showTips)) {
                    if (!TextUtils.isEmpty(patientSexStr) && !(sex_choose.equals(patientSexStr))) {
                        make_sex_tv.setText("患者填写了性别：“女”");
                        make_sex_layout.setVisibility(View.VISIBLE);
                    } else {
                        make_sex_layout.setVisibility(View.GONE);
                    }
                }
                break;
            case R.id.sx_id_female_layout:
                sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_sure);
                sex_choose = "0";
                if ("1".equals(showTips)) {
                    if (!TextUtils.isEmpty(patientSexStr) && !(sex_choose.equals(patientSexStr))) {
                        make_sex_tv.setText("患者填写了性别：“男”");
                        make_sex_layout.setVisibility(View.VISIBLE);
                    } else {
                        make_sex_layout.setVisibility(View.GONE);
                    }
                }
                break;
            case R.id.make_name_img:
                xl_patient_et_noteName.setText(patientNameStr);
                make_name_layout.setVisibility(View.GONE);
                break;
            case R.id.make_sex_img:
                if ("1".equals(patientSexStr)) {
                    sex_choose = "1";
                    sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_sure);
                    sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                } else if ("0".equals(patientSexStr)) {
                    sex_choose = "0";
                    sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                    sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_sure);
                }
                make_sex_layout.setVisibility(View.GONE);
                break;
            case R.id.make_age_img:
                sx_id_age.setText(patientAgeStr);
                make_age_layout.setVisibility(View.GONE);
                break;
            case R.id.make_address_img:
                sx_id_address.setText(patientAddressStr);
                make_address_layout.setVisibility(View.GONE);
                break;
            case R.id.make_phone_img:
                sx_id_phone.setText(patientPhoneStr);
                make_phone_layout.setVisibility(View.GONE);
                break;
        }
    }

    @Override
    public void onBackPressed() {
        String text = xl_patient_et_noteName.getText().toString().trim();
        String address = sx_id_address.getText().toString().trim();
        String phone = sx_id_phone.getText().toString().trim();
        String ageStr = sx_id_age.getText().toString().trim();
        if (!text.equals(remarkName) || !sex_choose.equals(patientSex) || !ageStr.equals(patientAge)
                || !address.equals(patientAddress) || !phone.equals(patientPhone)) {
            PatientInfoDialog.show();
            return;
        }
        myFinish();
    }
}
