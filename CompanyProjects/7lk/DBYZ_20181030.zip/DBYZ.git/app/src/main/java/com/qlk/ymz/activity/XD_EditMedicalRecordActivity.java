package com.qlk.ymz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.contrarywind.view.WheelView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.MedicalImageAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.drCase.DrCaseVOBeanDb;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.model.record.CaseInitBean;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.model.record.ImgListBean;
import com.qlk.ymz.model.record.PatientCaseVOBean;
import com.qlk.ymz.parse.Parse2CaseInitBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ArrayTextWheelAdapter;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.SQ_SexChoiceDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.qlk.ymz.activity.DiagnoseActivity.INTENT_KEY_DIAGNOSIS;


/**
 * Created by xiedong on 2018/5/23.
 * 编辑病历页 v2.18
 */

public class XD_EditMedicalRecordActivity extends DBActivity {
    public static final String DR_CASE_VO_BEAN ="DrCaseVOBean",CASE_INIT_BEAN ="CaseInitBean";
    public static final String SUIT ="suit";//主诉key
    public static final String PRESENT_DISEASE ="presentDisease";//现病史key
    public static final String POST_HISTORY ="postHistory";//既往史key
    public static final String PATIENT_ID = "patientId";
    public static final int TO_SUIT =1001,TO_HISTORY =1002,TO_CHECK=1003,TO_OTHER_CHECK=1004,
                              TO_DIAGNOSIS=1005,TO_DOCTOR_ADVICE=1006,TO_PREVIEW=1007, TO_HELP_DIAGNOSIS=1008;
    public static final String PAGE_FLAG = "pageFlag";
    public static final String DR_RECORD_VOBEAN = "DrRecordVOBean";
    public static final String HAVE_DRUG = "haveDrug";
    /** 标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** 模板*/
    private LinearLayout ll_template;
    /** 模板显示*/
    private TextView tv_template;
    /** 患者姓名*/
    private EditText et_patient_name;
    /** 患者年龄*/
    private TextView tv_patient_age;
    /** 患者性别*/
    private TextView tv_patient_sex;
    /** 主诉布局*/
    private LinearLayout ll_suit;
    /** 主诉*/
    private TextView tv_suit;
    /** 既往史布局*/
    private LinearLayout ll_history;
    /** 既往史*/
    private TextView tv_history;
    /** 检查指标布局*/
    private LinearLayout ll_check;
    /** 检查指标*/
    private TextView tv_check;
    /** 其它检查全部布局*/
    private LinearLayout ll_other_check_all;
    /** 其它检查*/
    private TextView tv_other_check;
    /** 辅助诊断*/
    private ImageView iv_diagnosis_icon;
    /** 诊断布局*/
    private LinearLayout ll_diagnosis;
    /** 诊断*/
    private TextView tv_diagnosis;
    /** 医嘱小结布局*/
    private LinearLayout ll_doctor_advice;
    /** 医嘱小结*/
    private TextView tv_doctor_advice;
    /** 图片*/
    private RecyclerView rv_add_pic;
    /** 下一步*/
    private TextView tv_next;
    /** 图片适配器*/
    private MedicalImageAdapter mMedicalImageAdapter;
    /** 性别对话框*/
    private SQ_SexChoiceDialog mSQ_sexChoiceDialog;

    /** 选择年龄对话框*/
    private ConfirmDialog mSetAgeDialog;
    /** 选择年龄控件*/
    private WheelView mWheelView;
    /** 选择年龄对话框取消按钮*/
    private TextView tv_set_age_cancel;
    /** 选择年龄对话框确定按钮*/
    private TextView tv_set_age_confirm;

    /** 模板选择框*/
    private ConfirmDialog mSelectTemplateDialog;
    /** 取消*/
    private TextView tv_template_cancle;
    /** 通用选择*/
    private LinearLayout ll_check_common;
    private ImageView iv_check_common;
    /** 肝病选择*/
    private LinearLayout ll_check_hepatopathy;
    private ImageView iv_check_hepatopathy;
    /** 使用模板*/
    private TextView tv_template_confirm;
    /** 医生助手*/
    private TextView tv_doctor_assistant;

    /** 模板的当前记录*/
    private int mCurrentTemplate = 1;//通用 1 肝病2
    /** 模板的临时记录*/
    private int mTempTemplate = 1;

    /** 肝病模板提示对话框*/
    private YR_CommonDialog mHepatopathyDialog;
    /** 惠每对话框*/
    private YR_CommonDialog mCdssDialog;

    /** 图片集合*/
    private ArrayList<String> mImageList = new ArrayList<>();
    /** 屏幕宽*/
    private int mScreenWidth = 720;
    /** 医生填写的病历*/
    private DrCaseVOBean mDrCaseVOBean = new DrCaseVOBean();
    /** 诊断集合*/
    private ArrayList<DiagnoseBean> mDiagnoseBeanList = new ArrayList<>();
    /** 患者id*/
    private String mPatientId ="";
    /** 初始化bean*/
    private CaseInitBean mCaseInitBean = new CaseInitBean();;
    /** 图片数量限制 */
    private int maxImgNum;
    /** 是否需要开启推药首页*/
    private boolean isNeed = true;
    /** 上个页面的标识*/
    private int mPageFlag ;//1 im单独填写病历 2 开处方新建病历 3 开处方流程病历预览编辑 4 既往病历编辑病历  5 病历列表单独添加病历
    /** 上个页面传过来病历数据*/
    private DrRecordVOBean mOldDrRecordVOBean;
    /** 是否带药品*/
    private boolean haveDrug;
    private DrCaseVOBeanDb mDrCaseVOBeanDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_edit_medical_record);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_EditMedicalRecordActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleLeft(true, "");
        xc_id_model_titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });

        ll_template = getViewById(R.id.ll_template);
        tv_template = getViewById(R.id.tv_template);

        et_patient_name = getViewById(R.id.et_patient_name);
        tv_patient_age = getViewById(R.id.tv_patient_age);
        tv_patient_sex = getViewById(R.id.tv_patient_sex);

        ll_suit = getViewById(R.id.ll_suit);
        tv_suit = getViewById(R.id.tv_suit);

        ll_history = getViewById(R.id.ll_history);
        tv_history = getViewById(R.id.tv_history);
        ll_check = getViewById(R.id.ll_check);
        tv_check = getViewById(R.id.tv_check);

        ll_other_check_all = getViewById(R.id.ll_other_check_all);
        tv_other_check = getViewById(R.id.tv_other_check);

        iv_diagnosis_icon = getViewById(R.id.iv_diagnosis_icon);
        ll_diagnosis = getViewById(R.id.ll_diagnosis);
        tv_diagnosis = getViewById(R.id.tv_diagnosis);

        ll_doctor_advice = getViewById(R.id.ll_doctor_advice);
        tv_doctor_advice = getViewById(R.id.tv_doctor_advice);

        rv_add_pic = getViewById(R.id.rv_add_pic);
        tv_next = getViewById(R.id.tv_next);

        //此设置优化recyclerview
        rv_add_pic.setHasFixedSize(true);
        //设置recyclerview的布局方式
        rv_add_pic.setLayoutManager(new GridLayoutManager(this, 3));
        //设置适配器
        //取服务器配置的极限值
        maxImgNum = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_RECORD_PIC_NUM, 0, 6);
        mMedicalImageAdapter = new MedicalImageAdapter(this,mImageList,maxImgNum);
        rv_add_pic.setAdapter(mMedicalImageAdapter);

        //性别对话框
        mSQ_sexChoiceDialog = new SQ_SexChoiceDialog(this);
        mSQ_sexChoiceDialog.getWindow().setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        mSQ_sexChoiceDialog.setSexChangeListener(new SQ_SexChoiceDialog.SexChangeListener() {
            @Override
            public void onSexChange(String sex) {
                if("女".equals(sex)){
                    mDrCaseVOBean.setGender("0");
                }else if("男".equals(sex)){
                    mDrCaseVOBean.setGender("1");
                }
                tv_patient_sex.setText(sex);
            }
        });
        //初始化年龄选择框
        initSetAgeDialog();
        //初始化模板选择框
        initTemplateDialog();
    }

    @Override
    public void listeners() {
        ll_template.setOnClickListener(this);
        tv_patient_age.setOnClickListener(this);
        tv_patient_sex.setOnClickListener(this);
        ll_suit.setOnClickListener(this);
        ll_history.setOnClickListener(this);
        ll_check.setOnClickListener(this);
        ll_other_check_all.setOnClickListener(this);
        ll_diagnosis.setOnClickListener(this);
        ll_doctor_advice.setOnClickListener(this);
        iv_diagnosis_icon.setOnClickListener(this);
        tv_next.setOnClickListener(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        xc_id_model_titlebar.setTitleCenter(true, "编辑病历");
        tv_next.setText("保存");
        super.onNewIntent(intent);
    }

    /**
     * 请求数据并初始化显示
     */
    private void initData() {
        mDrCaseVOBeanDb = new DrCaseVOBeanDb(this);

        if("1".equals(GlobalConfigSP.getRequiredFlag())){
            tv_history.setHint("必填");
            tv_suit.setHint("必填");
        }else {
            tv_suit.setHint("请填写");
            tv_history.setHint("请填写");
        }
        mPageFlag = getIntent().getIntExtra(PAGE_FLAG,1);
        switch (mPageFlag){
            case 5:
            case 1://单独添加病历
                xc_id_model_titlebar.setTitleCenter(true, "添加病历");
                tv_next.setText("下一步");
                tv_diagnosis.setHint("请填写");
                initNewCreat();
                break;
            case 2://开处方新建病历
                xc_id_model_titlebar.setTitleCenter(true, "添加病历");
                tv_next.setText("下一步开处方");
                initNewCreat();
                if(!UtilCollection.isBlank(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getRecommendInfo().getDrugInfoBean())) {
                    haveDrug = true;
                }
                break;
            case 3://开处方流程病历预览编辑
                xc_id_model_titlebar.setTitleCenter(true, "编辑病历");
                tv_next.setText("保存");
                mOldDrRecordVOBean = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getDrRecordVOBean();
                initOldRecord();
                break;
            case 4://既往病历过来
                tv_next.setText("下一步开处方");
                haveDrug = getIntent().getBooleanExtra(HAVE_DRUG,false);
                if(TextUtils.isEmpty(getIntent().getStringExtra(PATIENT_ID))){//既往病历完善病历
                    xc_id_model_titlebar.setTitleCenter(true, "编辑病历");
                    mOldDrRecordVOBean = (DrRecordVOBean) getIntent().getSerializableExtra(DR_RECORD_VOBEAN);
                    initOldRecord();
                }else {//既往病历新建病历
                    xc_id_model_titlebar.setTitleCenter(true, "添加病历");
                    initNewCreat();
                }
                break;
        }

    }

    /**
     *
     * 新建时初始化
     */
    private void initNewCreat() {
        mPatientId = getIntent().getStringExtra(PATIENT_ID);
        mDrCaseVOBean.setPatientId(mPatientId);
        DrCaseVOBean drCaseVOBean = mDrCaseVOBeanDb.queryCaseById(UtilSP.getUserId(), mPatientId);
        if(drCaseVOBean!=null){
            mDrCaseVOBean = drCaseVOBean;
            //剔除无效图片
            ArrayList<ImgListBean> listBeans = new ArrayList<>();
            for(ImgListBean imgListBean:mDrCaseVOBean.getImgList()){
                String imgUrl = imgListBean.getImgUrl();
                if(imgUrl.startsWith("http")||new File(imgUrl).exists()){
                   listBeans.add(imgListBean);
                }
            }
            mDrCaseVOBean.setImgList(listBeans);
            et_patient_name.setText(mDrCaseVOBean.getName());
            tv_patient_age.setText(mDrCaseVOBean.getAge()+mDrCaseVOBean.getAgeUnit());
            if("0".equals(mDrCaseVOBean.getGender())){
                tv_patient_sex.setText("女");
            }else if("1".equals(mDrCaseVOBean.getGender())){
                tv_patient_sex.setText("男");
            }
            initOldDrCase();
        }else {
            mCurrentTemplate= UtilSP.getMedicalTemplate(mDrCaseVOBean.getPatientId());
            updateTempateUI(mCurrentTemplate);
            initCase();
        }
    }


    /**
     * 既往病历初始化
     */
    private void initOldRecord() {
        if(mOldDrRecordVOBean!=null){
            et_patient_name.setText(mOldDrRecordVOBean.getName());
            tv_patient_age.setText(mOldDrRecordVOBean.getAge()+mOldDrRecordVOBean.getAgeUnit());
            if("0".equals(mOldDrRecordVOBean.getGender())){
                tv_patient_sex.setText("女");
            }else if("1".equals(mOldDrRecordVOBean.getGender())){
                tv_patient_sex.setText("男");
            }
            if(CommonConfig.MEDICAL_PATIENT_NEW.equals(mOldDrRecordVOBean.getCaseType())){//患者填写病历
                PatientCaseVOBean patientCaseVOBean = (PatientCaseVOBean) mOldDrRecordVOBean.getMdicalRecordVO();
                mCaseInitBean.setName(patientCaseVOBean.getName());
                mCaseInitBean.setAge(patientCaseVOBean.getAge());
                mCaseInitBean.setAgeUnit(patientCaseVOBean.getAgeUnit());
                mCaseInitBean.setGender(patientCaseVOBean.getGender());
                mCaseInitBean.setAmcResultBean(patientCaseVOBean.getAcmResult());
                mCaseInitBean.setDepartment(patientCaseVOBean.getDepartment());
                mCaseInitBean.setDescription(patientCaseVOBean.getDescription());
                mCaseInitBean.setDoctorName(patientCaseVOBean.getDoctorName());
                mCaseInitBean.setDrink(patientCaseVOBean.getDrink());
                mCaseInitBean.setFamilyDiseases(patientCaseVOBean.getFamilyDiseases());
                mCaseInitBean.setHeight(patientCaseVOBean.getHeight());
                mCaseInitBean.setHereditaryDiseases(patientCaseVOBean.getHereditaryDiseases());
                mCaseInitBean.setHospital(patientCaseVOBean.getHospitalName());
                mCaseInitBean.setMedicAllergys(patientCaseVOBean.getMedicAllergys());
                mCaseInitBean.setPastDiseases(patientCaseVOBean.getPastDiseases());
                mCaseInitBean.setPregnancy(patientCaseVOBean.getPregnancy());
                mCaseInitBean.setSmoke(patientCaseVOBean.getSmoke());
                mCaseInitBean.setWeight(patientCaseVOBean.getWeight());
                mCaseInitBean.setCaseType("3");

                mDrCaseVOBean.setPatientId(mOldDrRecordVOBean.getPatientId());
                mCurrentTemplate= UtilSP.getMedicalTemplate(mDrCaseVOBean.getPatientId());
                updateTempateUI(mCurrentTemplate);
                initDataAndUI();
            }else if(CommonConfig.MEDICAL_DOCTOR.equals(mOldDrRecordVOBean.getCaseType())
                    ||CommonConfig.MEDICAL_DOCTOR_PRESCRIPTION.equals(mOldDrRecordVOBean.getCaseType())
                    ||CommonConfig.MEDICAL_CONSULT_ROOM.equals(mOldDrRecordVOBean.getCaseType())) {//医生填写病历
                mDrCaseVOBean = (DrCaseVOBean) mOldDrRecordVOBean.getMdicalRecordVO();
                mDrCaseVOBean.setName(mOldDrRecordVOBean.getName());
                mDrCaseVOBean.setAge(mOldDrRecordVOBean.getAge());
                mDrCaseVOBean.setAgeUnit(mOldDrRecordVOBean.getAgeUnit());
                mDrCaseVOBean.setGender(mOldDrRecordVOBean.getGender());
                if(CommonConfig.MEDICAL_CONSULT_ROOM.equals(mOldDrRecordVOBean.getCaseType())){
                    mDrCaseVOBean.getImgList().clear();//清除线上诊室病历的图片
                }
                initOldDrCase();
            }
        }
    }

    /**
     * 初始化医生填写病历
     */
    private void initOldDrCase() {
        mCurrentTemplate = UtilString.toInt(mDrCaseVOBean.getTemplateType(),1);
        updateTempateUI(mCurrentTemplate);
        String suitStr = "";
        if (!TextUtils.isEmpty(mDrCaseVOBean.getMainComplaint())) {
            suitStr = getTrimStr("",mDrCaseVOBean.getMainComplaint(),"") +"\n"+
                    getTrimStr("现病史：", mDrCaseVOBean.getPresentDisease(),"");
        }else {
            suitStr = getTrimStr("现病史：", mDrCaseVOBean.getPresentDisease(),"");
        }
        tv_suit.setText(clearEnd(suitStr));
        tv_history.setText(mDrCaseVOBean.getPastHistory());
        String checkStr = getTrimStr("体温：",mDrCaseVOBean.getTemperature(),"度")+
                getTrimStr("体重：", mDrCaseVOBean.getWeight(),"kg")+
                getTrimStr("心率：",mDrCaseVOBean.getHeartRete(),"bpm")+
                getTrimStr("收缩压：", mDrCaseVOBean.getSystolic(),"mmhg")+
                getTrimStr("舒张压：",mDrCaseVOBean.getDiastole(),"mmhg")+
                getTrimStr("",mDrCaseVOBean.getMoreExamin(),"");
        tv_check.setText(clearEnd(checkStr));
        if("2".equals(mDrCaseVOBean.getTemplateType())){
            String otherStr = getTrimStr("谷丙转氨酶(ALT)：",mDrCaseVOBean.getAlt(), "IU/ml")+
                    getTrimStr("谷草转氨酶(AST)：",mDrCaseVOBean.getAst(),"IU/ml")+
                    getTrimStr("HBV-DNA：",mDrCaseVOBean.getHbvDna(),"IU/ml");
            tv_other_check.setText(clearEnd(otherStr));
        }
        for(String str:mDrCaseVOBean.getDiagnosisList()){
            DiagnoseBean diagnoseBean = new DiagnoseBean();
            diagnoseBean.name = str;
            mDiagnoseBeanList.add(diagnoseBean);
        }
        tv_diagnosis.setText(mDrCaseVOBean.getDiagnosis());
        String adviceStr = "";
        if("2".equals(mDrCaseVOBean.getRevisitFalg())){
            adviceStr= mDrCaseVOBean.getDoctorOrder();
        }else {
            if("月".equals(mDrCaseVOBean.getRevisitDateUnit())){
                adviceStr= getTrimStr("下次复诊时间：",mDrCaseVOBean.getRevisitNumber() +"个"+mDrCaseVOBean.getRevisitDateUnit(),"后")+
                        getTrimStr( "", mDrCaseVOBean.getDoctorOrder(),"");
            }else {
                adviceStr= getTrimStr("下次复诊时间：",mDrCaseVOBean.getRevisitNumber() +mDrCaseVOBean.getRevisitDateUnit(),"后")+
                        getTrimStr( "", mDrCaseVOBean.getDoctorOrder(),"");
            }
        }
        tv_doctor_advice.setText(clearEnd(adviceStr));
        mImageList.addAll(getUrlList(mDrCaseVOBean.getImgList()));
        mMedicalImageAdapter.notifyDataSetChanged();
    }


    /**
     * 请求初始化病历接口
     */
    private void initCase() {
        RequestParams params = new RequestParams();
        params.put("patientId", mPatientId);
        XCHttpAsyn.postAsyn(this, AppConfig.getRecordUrl(AppConfig.INIT_CASE), params,
                new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (result_boolean) {
                            List<XCJsonBean> data = result_bean.getList("data");
                            Parse2CaseInitBean parse2CaseInitBean = new Parse2CaseInitBean(mCaseInitBean);
                            parse2CaseInitBean.parseJson(data.get(0));
                            initDataAndUI();
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        // 处理code操作
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_EditMedicalRecordActivity.this,
                                getCode(), getMsg())) {
                        }
                    }

                });
    }

    /**
     * 初始化选择病历模板对话框
     */
    private void initTemplateDialog() {
        mScreenWidth = UtilScreen.getScreenWidthPx(this);
        mSelectTemplateDialog = new ConfirmDialog(this, mScreenWidth, R.layout.xd_dialog_template_select, R.style.xc_s_dialog);
        mSelectTemplateDialog.setCanceledOnTouchOutside(false);
        Window window = mSelectTemplateDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        window.setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        tv_template_cancle = (TextView) mSelectTemplateDialog.findViewById(R.id.tv_template_cancle);
        tv_template_confirm = (TextView) mSelectTemplateDialog.findViewById(R.id.tv_template_confirm);
        ll_check_common = (LinearLayout) mSelectTemplateDialog.findViewById(R.id.ll_check_common);
        ll_check_hepatopathy = (LinearLayout) mSelectTemplateDialog.findViewById(R.id.ll_check_hepatopathy);
        iv_check_common = (ImageView) mSelectTemplateDialog.findViewById(R.id.iv_check_common);
        iv_check_hepatopathy = (ImageView) mSelectTemplateDialog.findViewById(R.id.iv_check_hepatopathy);
        tv_doctor_assistant = (TextView) mSelectTemplateDialog.findViewById(R.id.tv_doctor_assistant);

        tv_template_cancle.setOnClickListener(this);
        tv_template_confirm.setOnClickListener(this);
        ll_check_common.setOnClickListener(this);
        ll_check_hepatopathy.setOnClickListener(this);
        tv_doctor_assistant.setOnClickListener(this);
        mSelectTemplateDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                updateTemplateDialogUI(mCurrentTemplate);
                mTempTemplate = mCurrentTemplate;
            }
        });
    }

    /**
     * 刷新模板对话模板选择ui
     * @param tempTemplate
     */
    private void updateTemplateDialogUI(int tempTemplate) {
        if(tempTemplate ==1){
            iv_check_common.setImageResource(R.mipmap.sx_d_register_sure);
            iv_check_hepatopathy.setImageResource(R.mipmap.sx_d_register_no_sure);
        }else if(tempTemplate ==2){
            iv_check_common.setImageResource(R.mipmap.sx_d_register_no_sure);
            iv_check_hepatopathy.setImageResource(R.mipmap.sx_d_register_sure);
        }
    }

    /**
     * 初始化选择年龄对话框
     */
    private void initSetAgeDialog() {
        final List<String> ageData = getAgeData();
        mScreenWidth = UtilScreen.getScreenWidthPx(this);
        mSetAgeDialog = new ConfirmDialog(this, mScreenWidth, R.layout.dialog_roll_select, R.style.xc_s_dialog);
        mSetAgeDialog.setCanceledOnTouchOutside(false);
        Window window = mSetAgeDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        window.setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        tv_set_age_cancel = (TextView) mSetAgeDialog.findViewById(R.id.tv_set_price_cancel);
        tv_set_age_confirm = (TextView) mSetAgeDialog.findViewById(R.id.tv_set_price_confirm);

        mWheelView = (WheelView) mSetAgeDialog.findViewById(R.id.wheelview);
        mWheelView.setCyclic(false);//不循环
        mWheelView.setAdapter(new ArrayTextWheelAdapter(ageData));

        tv_set_age_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mSetAgeDialog.dismiss();
            }
        });
        tv_set_age_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String age = ageData.get(mWheelView.getCurrentItem());
                tv_patient_age.setText(age);
                mDrCaseVOBean.setAge(getAgeNum(age));
                mDrCaseVOBean.setAgeUnit(age.replace(getAgeNum(age),""));
                mSetAgeDialog.dismiss();
            }
        });

        mSetAgeDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                String age = tv_patient_age.getText().toString().trim();
                if(UtilString.toInt(getAgeNum(age)) > 120 || UtilString.isBlank(age)){
                    age = "1岁";
                }
                for(int i=0;i<ageData.size();i++){
                    if(age.equals(ageData.get(i))){
                        mWheelView.setCurrentItem(i);
                    }
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.ll_template://显示模板对话框
                mSelectTemplateDialog.show();
                break;
            case R.id.tv_patient_age://患者年龄选择框
                mSetAgeDialog.show();
                break;
            case R.id.tv_patient_sex://性别选择
                mSQ_sexChoiceDialog.setSexString(tv_patient_sex.getText().toString().trim());
                mSQ_sexChoiceDialog.show();
                break;
            case R.id.ll_suit://主诉
                SQ_ChiefComplaintActivity.launch(this,mCaseInitBean,mDrCaseVOBean.getMainComplaint(), mDrCaseVOBean.getPresentDisease());
                break;
            case R.id.ll_history://既往史
                Intent intent = new Intent(this, PastHistoryActivity.class);
                intent.putExtra(POST_HISTORY,mDrCaseVOBean.getPastHistory());
                intent.putExtra(CASE_INIT_BEAN,mCaseInitBean);
                myStartActivityForResult(intent,TO_HISTORY);
                break;
            case R.id.ll_check://检查指标
                Intent intent1 = new Intent(this, YR_CheckIndexActivity.class);
                intent1.putExtra(DR_CASE_VO_BEAN,mDrCaseVOBean);
                myStartActivityForResult(intent1,TO_CHECK);
                break;
            case R.id.ll_other_check_all://其它检查
                Intent intent2 = new Intent(this, YR_OtherIndicatorsActivity.class);
                intent2.putExtra(DR_CASE_VO_BEAN,mDrCaseVOBean);
                myStartActivityForResult(intent2,TO_OTHER_CHECK);
                break;
            case R.id.ll_diagnosis://诊断
                saveDataToCase();
                copyDataToCase();
                myStartActivityForResult(DiagnoseActivity.newIntent(this,mDiagnoseBeanList),TO_DIAGNOSIS);
                break;
            case R.id.ll_doctor_advice://医嘱
                Intent intent3 = new Intent(this, XD_EditDoctorAdviceActivity.class);
                intent3.putExtra(DR_CASE_VO_BEAN,mDrCaseVOBean);
                myStartActivityForResult(intent3,TO_DOCTOR_ADVICE);
                break;
            case R.id.iv_diagnosis_icon://辅助诊断
                getCdssDays();
                break;
            case R.id.tv_next://下一步
                toNext();
                break;
            case R.id.tv_template_cancle://模板对话框取消
                mSelectTemplateDialog.dismiss();
                break;
            case R.id.tv_template_confirm://使用模板
                if(mTempTemplate ==1 && mCurrentTemplate==2){
                    updateTempateUI(1);
                }else if(mTempTemplate ==2 && mCurrentTemplate == 1){
                    updateTempateUI(2);
                    if(!UtilSP.isHepatopathyShow()){//是否显示过肝病模板
                        showHepatopathyDialog();
                        UtilSP.setHepatopathyShow(true);
                    }
                }
                mCurrentTemplate = mTempTemplate;
                UtilSP.setMedicalTemplate(mCurrentTemplate,mDrCaseVOBean.getPatientId());
                mSelectTemplateDialog.dismiss();
                break;
            case R.id.ll_check_common://选择通用模板
                mTempTemplate = 1;
                updateTemplateDialogUI(mTempTemplate);
                break;
            case R.id.ll_check_hepatopathy://选择肝病模板
                mTempTemplate = 2;
                updateTemplateDialogUI(mTempTemplate);
                break;
            case R.id.tv_doctor_assistant:
                // 医生助手
                Intent mIntent = new Intent(this,XD_ServiceChatActivity.class);
                myStartActivity(mIntent);
                mSelectTemplateDialog.dismiss();
                break;
            default:
                break;
        }
    }

    /**
     * 获取惠每使用期
     */
    private void getCdssDays() {
        RequestParams params = new RequestParams();
        params.put("doctorId",UtilSP.getUserId());
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.CDSS_DAYS), params, new
                XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (result_boolean) {
                            String expired = result_bean.getList("data").get(0).getString("expired");
                            String remainDaysDesc = result_bean.getList("data").get(0).getString("remainDaysDesc");
                            //判断使用期
                            if("0".equals(expired)){
                                saveDataToCase();
                                copyDataToCase();
                                WebviewBean bean = new WebviewBean(AppConfig.getHuiMeiUrl());
                                bean.titleBarType = 1;
                                bean.isShowCdssInvite = true;
                                bean.cdssContent = UtilString.f(remainDaysDesc);
                                myStartActivityForResult(JS_WebViewActivity.newIntent(XD_EditMedicalRecordActivity.this, bean),TO_HELP_DIAGNOSIS);
                            }else if("1".equals(expired)){
                                showCdssDialog();
                            }
                        }
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_EditMedicalRecordActivity.this, getCode(), getMsg())) {
                        }
                    }
                });
    }

    private void copyDataToCase() {
        DrCaseVOBean drCaseVOBean = new DrCaseVOBean();
        drCaseVOBean.setPatientId(mDrCaseVOBean.getPatientId());
        drCaseVOBean.setDoctorId(UtilSP.getUserId());
        drCaseVOBean.setDepartment(UtilSP.getFirstDepartmentName());
        drCaseVOBean.setMainComplaint(mDrCaseVOBean.getMainComplaint());
        drCaseVOBean.setPresentDisease(mDrCaseVOBean.getPresentDisease());
        drCaseVOBean.setGender(mDrCaseVOBean.getGender());
        drCaseVOBean.setAge(mDrCaseVOBean.getAge());
        drCaseVOBean.setAgeUnit(mDrCaseVOBean.getAgeUnit());
        drCaseVOBean.setPastHistory(mDrCaseVOBean.getPastHistory());
        drCaseVOBean.setTemperature(mDrCaseVOBean.getTemperature());
        drCaseVOBean.setWeight(mDrCaseVOBean.getWeight());
        drCaseVOBean.setHeartRete(mDrCaseVOBean.getHeartRete());
        drCaseVOBean.setSystolic(mDrCaseVOBean.getSystolic());
        drCaseVOBean.setDiastole(mDrCaseVOBean.getDiastole());
        drCaseVOBean.setDiagnosisList(mDrCaseVOBean.getDiagnosisList());
        NativeHtml5.drCaseVOBean = drCaseVOBean;
    }

    /**
     * 下一步
     */
    private void toNext() {
        if(TextUtils.isEmpty(et_patient_name.getText().toString().trim())){
            shortToast("姓名必填");
            return;
        }
        if(TextUtils.isEmpty(tv_patient_age.getText().toString().trim())){
            shortToast("年龄必填");
            return;
        }
        if(TextUtils.isEmpty(tv_patient_sex.getText().toString().trim())){
            shortToast("性别必填");
            return;
        }
        if("1".equals(GlobalConfigSP.getRequiredFlag())){//必填
            String suitStr = tv_suit.getText().toString().trim();
            String historyStr = tv_history.getText().toString().trim();
            if(TextUtils.isEmpty(suitStr)&&TextUtils.isEmpty(historyStr)){
                shortToast("主诉/现病史必填");
                return;
            }else if(TextUtils.isEmpty(suitStr)){
                shortToast("主诉/现病史必填");
                return;
            }else if(TextUtils.isEmpty(historyStr)){
                shortToast("既往史必填");
                return;
            }
        }
        if(mPageFlag!=1 && mPageFlag!=5 &&TextUtils.isEmpty(tv_diagnosis.getText().toString().trim())){
            shortToast("诊断必填");
            return;
        }
        saveDataToCase();
        switch (mPageFlag){
            case 5:
            case 1://单独填写病历
                Intent intent = new Intent(this, XD_MedicalRecordPreviewActivity.class);
                intent.putExtra(DR_CASE_VO_BEAN,mDrCaseVOBean);
                intent.putExtra(PAGE_FLAG,mPageFlag);
                myStartActivityForResult(intent,TO_PREVIEW);
                break;
            case 2://开处方新建病历
            case 4://既往病历
                saveCase();
                if("保存".equals(tv_next.getText().toString())){
                    if(haveDrug){
                        SQ_RecommendActivity.launch(this);
                        SQ_PreviewRecommendInfoActivity.launch(this,1);
                    }else {
                        saveDataToRecommendInfo();
                        myStartActivity(XD_RecommendedMedicationActivity.class);
                        SQ_RecommendActivity.launch(this);
                        SQ_PreviewRecommendInfoActivity.launch(this,1);
                    }
                }else {
                    if(haveDrug){
                        SQ_RecommendActivity.launch(this);
                    }else {
                        saveDataToRecommendInfo();
                        myStartActivity(XD_RecommendedMedicationActivity.class);
                    }
                }
                tv_next.setText("下一步开处方");
                xc_id_model_titlebar.setTitleCenter(true, "病历编辑");
                break;
            case 3://开处方流程病历预览编辑
                saveCase();
                myFinish();
                break;
        }
    }

    private void saveDataToRecommendInfo() {
        XC_PatientDrugInfo patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
        patientDrugInfo.getRecommendInfo().setPatientName(((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getName());
        patientDrugInfo.getRecommendInfo().setPatientAge(((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getAge());
        patientDrugInfo.getRecommendInfo().setPatientAgeUnit(((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getAgeUnit());
        patientDrugInfo.getRecommendInfo().setPatientGender(((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getGender());
        patientDrugInfo.getRecommendInfo().setDiagnosis(((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getDiagnosis());

    }

    private void saveDataToCase() {
        mDrCaseVOBean.setName(et_patient_name.getText().toString().trim());
        mDrCaseVOBean.setDiagnosis(getDianoseString());
        mDrCaseVOBean.setDiagnosisList(getDianoseList());
        mDrCaseVOBean.setTemplateType(mCurrentTemplate+"");

        List<ImgListBean> imgListBeanList = new ArrayList<>();
        for(String str:mImageList){
            ImgListBean imgListBean = new ImgListBean();
            imgListBean.setImgUrl(str);
            imgListBeanList.add(imgListBean);
        }
        mDrCaseVOBean.setImgList(imgListBeanList);
    }

    /**
     * 保存病历
     */
    private void saveCase() {
        DrRecordVOBean drRecordVOBean = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getDrRecordVOBean();
        drRecordVOBean.setName(mDrCaseVOBean.getName());
        drRecordVOBean.setGender(mDrCaseVOBean.getGender());
        drRecordVOBean.setAgeUnit(mDrCaseVOBean.getAgeUnit());
        drRecordVOBean.setAge(mDrCaseVOBean.getAge());
        drRecordVOBean.setCreateAt(System.currentTimeMillis()+"");
        drRecordVOBean.setDepartment(mDrCaseVOBean.getDepartment());
        drRecordVOBean.setHospitalName(mDrCaseVOBean.getHospitalName());
        drRecordVOBean.setDoctorName(mDrCaseVOBean.getDoctorName());
        if(mOldDrRecordVOBean!=null && !TextUtils.isEmpty(mOldDrRecordVOBean.getRelation())){
            drRecordVOBean.setRelation(mOldDrRecordVOBean.getRelation());
        }
        drRecordVOBean.setMdicalRecordVO(mDrCaseVOBean);
        RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setDrRecordVOBean(drRecordVOBean);
    }

    /**
     * 转换诊断字符串
     * @return
     */
    private String getDianoseString() {
        String diagnose = "";
        for(int i=0;i<mDiagnoseBeanList.size();i++ ){
            if(i==mDiagnoseBeanList.size()-1){
                diagnose += mDiagnoseBeanList.get(i).name;
            }else {
                diagnose += mDiagnoseBeanList.get(i).name+",";
            }
        }
        return diagnose;
    }

    /**
     * 转换诊断集合
     * @return
     */
    private List<String> getDianoseList() {
        ArrayList<String> list = new ArrayList<>();
        for(DiagnoseBean diagnoseBean:mDiagnoseBeanList){
            list.add(diagnoseBean.name);
        }
        return list;
    }

    /**
     * 显示肝病模板提示的dialog
     */
    private void showHepatopathyDialog(){
        if(mHepatopathyDialog == null){
            mHepatopathyDialog = new YR_CommonDialog(this,"在其它检查入口，增加谷丙转氨酶（ALT）、谷草转氨酶（AST）、HBV-DNA三个检查指标项的录入，便于您长期跟踪肝病患者的病情变化","",
                    "知道了") {
                @Override
                public void confirmBtn() {
                    dismiss();
                }
            };
            mHepatopathyDialog.setTitle("肝病病历模板");
            mHepatopathyDialog.setCanceledOnTouchOutside(false);
        }
        if(mHepatopathyDialog != null && !mHepatopathyDialog.isShowing()){
            mHepatopathyDialog.show();
        }
    }

    /**
     * 显示惠每dialog
     */
    private void showCdssDialog(){
        if(mCdssDialog == null){
            mCdssDialog = new YR_CommonDialog(this,"您的惠每CDSS使用权已到期，立刻邀请医生就可以获得使用权?","取消",
                    "邀请医生") {
                @Override
                public void confirmBtn() {
                    dismiss();
                    WebviewBean bean = new WebviewBean(AppConfig.getH5Url(AppConfig.CDSS_INVITE_DOCTOR));
                    myStartActivity(JS_WebViewActivity.newIntent(XD_EditMedicalRecordActivity.this, bean));
                }
            };
            mCdssDialog.setCanceledOnTouchOutside(false);
        }
        if(mCdssDialog != null && !mCdssDialog.isShowing()){
            mCdssDialog.show();
        }
    }
    /**
     *
     * 创建年龄数据
     * @return
     */
    private List<String> getAgeData() {
        List<String> ages = new ArrayList<>();
        for (int i = 1; i<5 ;i++){
            ages.add(i + "周");
        }
        for (int i = 1; i<13;i++){
            ages.add(i + "个月");
        }
        for (int i = 1;i<121 ; i++){
            ages.add(i + "岁");
        }
        return ages;
    }

    /**
     * 获取年龄数字
     * @return
     */
    private String getAgeNum(String age) {
        if(age.contains("周")){
            return UtilString.getStringWithoutLast(age,"周");
        }else if(age.contains("个月")){
           return UtilString.getStringWithoutLast(age,"个月");
        }else if(age.contains("岁")){
            return UtilString.getStringWithoutLast(age,"岁");
        }
        return "0";
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(TO_HELP_DIAGNOSIS == requestCode){
            mDiagnoseBeanList.addAll(NativeHtml5.cdssDiagnose);
            NativeHtml5.cdssDiagnose.clear();
            tv_diagnosis.setText(getDianoseString());
            return;
        }
        if(resultCode == RESULT_OK){
            switch (requestCode){
                case YY_SelectImgsActivity.REQUEST_IMAGE://用户选择图片完成
                    if(data == null || data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT) == null){
                        return;
                    }
                    ArrayList<File> files = (ArrayList<File>) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
                    for(File file:files){
                        mImageList.add(file.getAbsolutePath());
                    }
                    mMedicalImageAdapter.notifyDataSetChanged();
                    break;
                case TO_SUIT:
                    if(data == null ){
                        return;
                    }
                    if(data.getStringExtra(SUIT)!=null){
                        mDrCaseVOBean.setMainComplaint(data.getStringExtra(SUIT));
                    }
                    if(data.getStringExtra(PRESENT_DISEASE)!=null){
                        mDrCaseVOBean.setPresentDisease(data.getStringExtra(PRESENT_DISEASE));
                    }
                    if(data.getSerializableExtra(CASE_INIT_BEAN)!=null){
                        mCaseInitBean = (CaseInitBean) data.getSerializableExtra(CASE_INIT_BEAN);
                    }
                    String suitStr="";
                    if (!TextUtils.isEmpty(mDrCaseVOBean.getMainComplaint())) {
                         suitStr = getTrimStr("",mDrCaseVOBean.getMainComplaint(),"") +"\n"+
                                   getTrimStr("现病史：", mDrCaseVOBean.getPresentDisease(),"");
                    }else {
                        suitStr = getTrimStr("现病史：", mDrCaseVOBean.getPresentDisease(),"");
                    }
                    tv_suit.setText(clearEnd(suitStr));
                    break;
                case TO_HISTORY:
                    if(data !=null&&data.getStringExtra(POST_HISTORY)!=null){
                        mDrCaseVOBean.setPastHistory(data.getStringExtra(POST_HISTORY));
                        tv_history.setText(mDrCaseVOBean.getPastHistory());
                    }
                    if(data.getSerializableExtra(CASE_INIT_BEAN)!=null){
                        mCaseInitBean = (CaseInitBean) data.getSerializableExtra(CASE_INIT_BEAN);
                    }
                    break;
                case TO_CHECK:
                    if(data !=null&&data.getSerializableExtra(DR_CASE_VO_BEAN)!=null){
                        mDrCaseVOBean = (DrCaseVOBean) data.getSerializableExtra(DR_CASE_VO_BEAN);
                        updateCheckUI();
                    }
                    break;
                case TO_OTHER_CHECK:
                    if(data !=null&&data.getSerializableExtra(DR_CASE_VO_BEAN)!=null){
                        mDrCaseVOBean = (DrCaseVOBean) data.getSerializableExtra(DR_CASE_VO_BEAN);
                        String checkStr = getTrimStr("谷丙转氨酶(ALT)：",mDrCaseVOBean.getAlt(),"IU/ml")+
                                          getTrimStr("谷草转氨酶(AST)：", mDrCaseVOBean.getAst(),"IU/ml")+
                                          getTrimStr("HBV-DNA：",mDrCaseVOBean.getHbvDna(),"IU/ml");
                        tv_other_check.setText(clearEnd(checkStr));
                    }
                    break;
                case TO_DIAGNOSIS:
                    if(data !=null&&data.getSerializableExtra(INTENT_KEY_DIAGNOSIS)!=null){
                        mDiagnoseBeanList = (ArrayList<DiagnoseBean>) data.getSerializableExtra(INTENT_KEY_DIAGNOSIS);
                        tv_diagnosis.setText(getDianoseString());
                    }
                    break;
                case TO_DOCTOR_ADVICE:
                    if(data !=null&&data.getSerializableExtra(DR_CASE_VO_BEAN)!=null){
                        mDrCaseVOBean = (DrCaseVOBean) data.getSerializableExtra(DR_CASE_VO_BEAN);
                        String str = "";
                        if("2".equals(mDrCaseVOBean.getRevisitFalg())){
                            str= mDrCaseVOBean.getDoctorOrder();
                        }else {
                            if("月".equals(mDrCaseVOBean.getRevisitDateUnit())){
                                str= getTrimStr("下次复诊时间：",mDrCaseVOBean.getRevisitNumber() +"个"+mDrCaseVOBean.getRevisitDateUnit(),"后")+
                                     getTrimStr( "", mDrCaseVOBean.getDoctorOrder(),"");
                            }else {
                                str= getTrimStr("下次复诊时间：",mDrCaseVOBean.getRevisitNumber() +mDrCaseVOBean.getRevisitDateUnit(),"后")+
                                     getTrimStr( "", mDrCaseVOBean.getDoctorOrder(),"");
                            }
                        }
                        tv_doctor_advice.setText(clearEnd(str));
                    }
                    break;
                case TO_PREVIEW:
                    myFinish();
                    break;
            }
        }
    }

    /**
     * 更新检查ui
     */
    private void updateCheckUI() {
        String str = getTrimStr("体温：",mDrCaseVOBean.getTemperature(),"度")+
                getTrimStr("体重：", mDrCaseVOBean.getWeight(),"kg")+
                getTrimStr("心率：",mDrCaseVOBean.getHeartRete(),"bpm")+
                getTrimStr("收缩压：", mDrCaseVOBean.getSystolic(),"mmhg")+
                getTrimStr("舒张压：", mDrCaseVOBean.getDiastole(),"mmhg")+
                getTrimStr("", mDrCaseVOBean.getMoreExamin(),"");
        tv_check.setText(clearEnd(str));
    }

    private String getTitleString(String title, String str){
        return TextUtils.isEmpty(str)? "":title+str+" ";
    }

    /**
     * 更新模板文案ui
     */
    private void updateTempateUI(int value) {
        if(value==1){
            tv_template.setText("V2.0 通用病历模板");
            ll_other_check_all.setVisibility(View.GONE);
        }else if(value ==2){
            tv_template.setText("肝病病历模板");
            ll_other_check_all.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 初始化数据和显示
     */
    private void initDataAndUI() {
        if("8".equals(mCaseInitBean.getCaseType())){//线上诊室的初始化数据
            mDrCaseVOBean = mCaseInitBean.getDrCaseVOBean();
            if(mDrCaseVOBean!=null){
                et_patient_name.setText(mDrCaseVOBean.getName());
                tv_patient_age.setText(mDrCaseVOBean.getAge()+mDrCaseVOBean.getAgeUnit());
                if("0".equals(mDrCaseVOBean.getGender())){
                    tv_patient_sex.setText("女");
                }else if("1".equals(mDrCaseVOBean.getGender())){
                    tv_patient_sex.setText("男");
                }
                initOldDrCase();
            }
        }else if(TextUtils.isEmpty(mCaseInitBean.getCaseType())||"3".equals(mCaseInitBean.getCaseType())){
            mDrCaseVOBean.setAge(mCaseInitBean.getAge());
            mDrCaseVOBean.setAgeUnit(mCaseInitBean.getAgeUnit());
            mDrCaseVOBean.setGender(mCaseInitBean.getGender());
            mDrCaseVOBean.setDoctorName(mCaseInitBean.getDoctorName());
            mDrCaseVOBean.setHospitalName(mCaseInitBean.getHospital());
            mDrCaseVOBean.setDepartment(mCaseInitBean.getDepartment());
            et_patient_name.setText(mCaseInitBean.getName());
            tv_patient_age.setText(mCaseInitBean.getAge()+mCaseInitBean.getAgeUnit());
            if("0".equals(mCaseInitBean.getGender())){
                tv_patient_sex.setText("女");
            }else if("1".equals(mCaseInitBean.getGender())){
                tv_patient_sex.setText("男");
            }
        }
    }

    @Override
    protected void onStop() {
        DrCaseVOBean drCaseVOBean = mDrCaseVOBeanDb.queryCaseById(UtilSP.getUserId(), mDrCaseVOBean.getPatientId());
        mDrCaseVOBean.setDoctorId(UtilSP.getUserId());
        saveDataToCase();
        if(drCaseVOBean!=null){
            mDrCaseVOBeanDb.UpdateCaseById(mDrCaseVOBean);
        }else {
            mDrCaseVOBeanDb.insert(mDrCaseVOBean);
        }
        super.onStop();
    }

    private String getTrimStr(String str, String values, String unit){
        String s ="";
        s +=TextUtils.isEmpty(values)? "":str+values+unit+"\n";
        return s;
    }

    private String clearEnd(String str){
        while (str.endsWith("\n")){
            str = UtilString.getStringWithoutLast(str,"\n");
        }
        return str;
    }

    private ArrayList<String> getUrlList(List<ImgListBean> imgListBeanList) {
        ArrayList<String> urls = new ArrayList<>();
        for(ImgListBean imgListBean:imgListBeanList){
            urls.add(imgListBean.getImgUrl());
        }
        return urls;
    }
}
