package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.View;
import android.widget.HorizontalScrollView;

import com.qlk.ymz.view.SwipeLayout.SwipeLayoutAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author shuYanYi on 2016/9/8.
 * @description 带右滑控件的基类adapter，如右滑删除、置顶等
 */
public abstract class YY_BaseSwipeAdapter<T> extends SwipeLayoutAdapter{
    /** 数据集*/
    public List<T> list;
    /**
     * 构造方法
     * @param context 上下文
     * @param contentViewResourceId 显示区域布局ID
     * @param actionViewResourceId  侧滑控件布局ID
     * @param list 数据集
     */
    public YY_BaseSwipeAdapter(Context context,int contentViewResourceId,int actionViewResourceId,List<T> list){
        super(context,contentViewResourceId,actionViewResourceId,list);
        this.list = list;

    }

    @Override
    public void setContentView(View contentView, int position, HorizontalScrollView parent) {

    }

    /**
     * 获取列表集合
     * @return
     */
    public List<T> getList() {
        if (list == null) {
            return list = new ArrayList<T>();
        }
        return list;
    }

    /**
     * 更新列表集合
     * @param list
     */
    public void update(List<T> list) {
        this.list = list;
    }

    @Override
    public int getCount() {
        if (list != null)
            return list.size();
        return 0;
    }

    @Override
    public Object getItem(int position) {
        if (list != null) {
            return list.get(position);
        } else {
            return null;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

}
