package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.search.XCSearchRecordModel;
import com.qlk.ymz.db.search.XCSearchRecordModelDb;
import com.qlk.ymz.fragment.SXSearchRecordFragment;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCClearEditText;

import java.util.List;

/**
 * 患者搜索页，默认是search_record_info表
 *
 * update by cyr on 2016-1-11 ui调整
 * @version 2.0
 */
public class YR_PatientSearchActivity extends DBActivity {
    /** 搜索关键字 */
    public static String SEARCH_KEY = "search_key";
    /** 搜索框 */
    private SXSearchRecordFragment recordFragment;
    /** 患者分组id  */
    private String mGroupId;
    /** 搜索关键字 */
    private XCClearEditText sk_id_search_edit;
    /** 患者关键字搜索历史 */
    private XCSearchRecordModelDb db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xc_l_activity_patient_search);
        mGroupId = getIntent().getStringExtra(YR_PatientGroupManagerActivity.GROUP_ID);
        db = new XCSearchRecordModelDb(this, XCSearchRecordModelDb.SEARCH_DB_NAME,
                XCSearchRecordModelDb.SEARCH_DB_VERSION, "");
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_PatientSearchActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    /** 无网络时,点击屏幕后回调的方法 */
    @Override
    public void onNetRefresh() {
    }

    /** 初始化控件 */
    @Override
    public void initWidgets() {
        sk_id_search_edit = (XCClearEditText) findViewById(R.id.sk_id_search_edit);
        sk_id_search_edit.setHint("请输入患者关键字");
        sk_id_search_edit.setFocusable(true);
        sk_id_search_edit.requestFocus();
        sk_id_search_edit.setHintTextColor(getResources().getColor(R.color.c_gray_bbbbbb));
        findViewById(R.id.xc_id_titlebar_right2_textview).setOnClickListener(this);

        recordFragment = new SXSearchRecordFragment();
        addFragment(R.id.xc_id_model_content, recordFragment);
        int length = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_SEARCH,0,19);
        sk_id_search_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(length)});
//        //如果log开,就把输入框字数限制打开,用来调试h5链接,不要删除
        if (XCConfig.IS_OUTPUT){
            sk_id_search_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(Integer.MAX_VALUE)});
        }
    }

    @Override
    public void listeners() {
        //点击历史搜索记录跳转搜索结果页
        recordFragment.setOnRecordItemClickListener(new SXSearchRecordFragment.OnRecordItemClickListener() {

            @Override
            public void onRecordItemClickListener(XCSearchRecordModel model, String key_word, int position) {
                jumpSearchResult(key_word);
            }
        });

        //点击软件盘搜索按钮跳转搜索结果页
        sk_id_search_edit.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    //---------添加联系人搜索可以直接打开webView页面 zhangpengfei 2016-4-25 add------------------
                    String inputText =  sk_id_search_edit.getText().toString().trim();
                    saveKeyword(inputText);
                    //----------------------------------------------------------------end------------------
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.xc_id_titlebar_right2_textview:
                myFinish();
                break;
        }
    }

    /** 保存搜索关键字 */
    public void saveKeyword(String keyword) {
        if (UtilString.isBlank(keyword)) {
            return;
        }
        // 查询数据库中是否有搜索的关键字，如果没有，存入数据库
        List<XCSearchRecordModel> xcSearchRecordModels1 = db.queryAllByDESC();
        boolean is_exist = false;
        for (XCSearchRecordModel model : xcSearchRecordModels1) {
            if (keyword.equals(model.getKey_word())) {
                is_exist = true;
                break;
            }
        }
        if (!is_exist) {
            db.insert(new XCSearchRecordModel(keyword, String.valueOf(System.currentTimeMillis())));
        }

        //查询数据库得到的关键字，如果大于10，删除多余的
        int count = db.queryCount();
        if (count > 10) {
            List<XCSearchRecordModel> xcSearchRecordModels = db.queryAllByDESC();
            for (int i = 10; i < count; i++) {
                XCSearchRecordModel model = xcSearchRecordModels.get(i);
                if (model != null) {
                    db.deleteByTime(model.getTime());
                }
            }
        }

        jumpSearchResult(keyword);
    }

    /** 跳转到搜索结果页 */
    public void jumpSearchResult(String keyword) {
        Intent intent = new Intent();
        intent.putExtra(SEARCH_KEY, keyword);
        intent.putExtra(YR_PatientGroupManagerActivity.GROUP_ID, mGroupId);
        intent.setClass(YR_PatientSearchActivity.this, YM_PatientSearchResultActivity.class);
        myStartActivity(intent);
        myFinish();
    }

}
