package com.qlk.ymz.adapter.ViewHolder;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilNativeHtml5;

public class SK_DrugViewHolder {
    /**
     * 调价
     */
    public Button sk_id_medichine_change_price;
    /**
     * 勾选按钮
     */
    public Button sk_id_medichine_cb;
    /**
     * 药品图片
     */
    public ImageView sk_id_medichine_item_img;
    /**
     * 公司名字
     */
    public TextView sk_id_medichine_item_name;
    /**
     * 药品名 + （常用名）
     */
    public TextView sk_id_medichine_item_common_name;
    /**
     * 价格
     */
    public TextView sk_id_medichine_item_pprice;
    /**
     * 市场价
     */
    public TextView sk_id_medichine_item_oprice;
    /**
     * 是否在销售的浮层
     */
    public LinearLayout sk_id_medichine_item_sale_ll;

    /**
     * 积分
     */
    public TextView sk_id_medichine_item_recom_point;
    public RelativeLayout sk_id_medichine_item_rl;
    /**
     * 分割线
     * */
    public View sk_id_medichine_item_line;
    /**
     * 小七指数布局
     */
    public LinearLayout sk_id_medicine_drcommission_ll;
    /**
     * 小七指数文本
     */
    public TextView sk_id_medicine_drcommission;
    /**
     * 预售图片
     */
    public ImageView sk_id_medichine_item_presell;
    /**
     * 库存数量
     */
    public TextView sk_id_medichine_item_stock_num;
    /**
     * 无货标识
     */
    public ImageView sk_id_medichine_item_short_iv;
    /**
     * 小七推荐
     */
    public ImageView sk_id_medichine_item_recommend;
    /**
     * 病历收集
     */
    public ImageView sk_id_medichine_item_collect;

    public RelativeLayout sk_id_medichine_item_ll;

    public LinearLayout sk_id_medichine_item_footerView;
    /**
     * 小七指数的名称
     */
    public TextView sk_id_medicine_point_name;

    public SK_DrugViewHolder(final Context context,View convertView) {
        sk_id_medichine_cb = (Button) convertView.findViewById(R.id.sk_id_medichine_cb);
        sk_id_medichine_item_img = (ImageView) convertView.findViewById(R.id.sk_id_medichine_item_img);
        sk_id_medichine_item_name = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_name);
        sk_id_medichine_item_common_name = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_common_name);
        sk_id_medichine_item_pprice = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_pprice);
        sk_id_medichine_item_oprice = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_oprice);
        sk_id_medichine_item_recom_point = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_recom_point);
        sk_id_medichine_item_sale_ll = (LinearLayout) convertView.findViewById(R.id.sk_id_medichine_item_sale_ll);
        sk_id_medichine_item_rl = (RelativeLayout) convertView.findViewById(R.id.sk_id_medichine_item_rl);
        sk_id_medicine_drcommission_ll = (LinearLayout) convertView.findViewById(R.id.sk_id_medicine_drcommission_ll);
        sk_id_medicine_drcommission = (TextView) convertView.findViewById(R.id.sk_id_medicine_drcommission);
        sk_id_medichine_item_footerView = (LinearLayout)convertView.findViewById(R.id.sk_id_medichine_item_footerView);
        sk_id_medichine_item_line = (View)convertView.findViewById(R.id.sk_id_medichine_item_line);
        sk_id_medichine_item_presell = (ImageView)convertView.findViewById(R.id.sk_id_medichine_item_presell);
        sk_id_medichine_item_stock_num = (TextView)convertView.findViewById(R.id.sk_id_medichine_item_stock_num);
        sk_id_medichine_item_short_iv = (ImageView)convertView.findViewById(R.id.sk_id_medichine_item_short_iv);
        sk_id_medichine_item_ll = (RelativeLayout)convertView.findViewById(R.id.sk_id_medichine_item_ll);
        sk_id_medichine_item_recommend = (ImageView) convertView.findViewById(R.id.sk_id_medichine_item_recommend);
        sk_id_medichine_change_price = (Button) convertView.findViewById(R.id.sk_id_medichine_change_price);
        sk_id_medicine_point_name = (TextView) convertView.findViewById(R.id.sk_id_medicine_point_name);
        sk_id_medichine_item_collect = (ImageView)convertView.findViewById(R.id.sk_id_medichine_item_collect);
        sk_id_medichine_change_price.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DrugBean bean = (DrugBean) v.getTag();
                DrugBean.drug_id = bean.getId();
                if(!UtilCollection.isBlank(bean.getSkus()))
                    ToJumpHelp.toJumpPriceCalculatorActivity((Activity) context,bean.getSkuId());

            }
        });
        sk_id_medichine_item_collect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DrugBean bean = (DrugBean) v.getTag();
                UtilNativeHtml5.toJumpSunlightPage(context,bean.getId());
            }
        });
    }
}