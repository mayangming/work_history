package com.qlk.ymz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PF_PaAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.model.PF_PaBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.SystemMessageUtil;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 系统通知
 * @author zhangpengfei
 * @version 2.0
 */
public class PF_PaActivity extends DBActivity implements PullToRefreshListView.OnRefreshListener2{
    /**title*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**内容*/
    private PullToRefreshListView pf_id_pa_listview;
    private PF_PaAdapter adapter;
    private List<PF_PaBean.DataEntity.ResultEntity> list;
    private List<PF_PaBean.DataEntity.ResultEntity> sumList;
    private ListView listView;
    /**页*/
    private int page = 1;
    /**每页数量*/
    private int num = 10;
    /**
     * 接收刷新的广播
     */
    MyBroadcastReceiver myBroadcastReceiver;
    /**
     * 广播action
     */
    public static final String ACTION = "com.qlk.ymz.PA_NEW_MSG";//前台进程时，通过广播更新

    @Override
    public void onPullDownToRefresh(PullToRefreshBase refreshView) {
        requestData(++page, false);
    }

    @Override
    public void onPullUpToRefresh(PullToRefreshBase refreshView) {

    }


    class MyBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION.equals(action)) {
                //更新数据
                requestData(1, true);
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_activity_pa);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_PaActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        registerReceiver(myBroadcastReceiver = new MyBroadcastReceiver(),  new IntentFilter(ACTION));

        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleLeft(true,"");
        xc_id_model_titlebar.setTitleCenter(true, "系统通知");
        pf_id_pa_listview = getViewById(R.id.pf_id_pa_listview);
        pf_id_pa_listview.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
        pf_id_pa_listview.setOnRefreshListener(this);
        listView = pf_id_pa_listview.getRefreshableView();
        list = new ArrayList<>();
        sumList = new ArrayList<>();
        adapter = new PF_PaAdapter(this,list);
        listView.setAdapter(adapter);
        requestData(1, false);
    }

    @Override
    public void listeners() {

    }

    @Override
    public void onNetRefresh() {

    }

    /**
     * 请求数量
     * @param page 页数
     * @param isBroad 是否是接收广播
     */
    private void requestData(final int page, final boolean isBroad) {
        RequestParams params = new RequestParams();
        params.put("page", page);
        params.put("num", num);
        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.findPaList), params, new XCHttpResponseHandler<PF_PaBean>(this, PF_PaBean.class) {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<PF_PaBean.DataEntity> objLists = mResultModel.getData();
                        if (null != objLists && objLists.size() > 0 ){
                            if (null != objLists.get(0) && objLists.get(0).getResult().size() > 0){
                                pf_id_pa_listview.onRefreshComplete();
                                list = objLists.get(0).getResult();
                                Collections.reverse(list);
                                if (page == 1){
                                    sumList.clear();
                                }
                                sumList.addAll(0,list);
                                adapter.setmList(sumList);
                                if (sumList.size() >= objLists.get(0).getTotalCount()){
                                    pf_id_pa_listview.setMode(PullToRefreshBase.Mode.DISABLED);
                                }else{
                                    pf_id_pa_listview.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
                                }
                                if (list.size() > 0){
                                    listView.setSelection(list.size() - 1);
                                }
                            }
                        }

                    //update by cyr on 2016-11-24 在账户动态页收到消息后，将“账户动态”未读消息数置0
                    if (isBroad){
                        JS_ChatListDB.getInstance(PF_PaActivity.this, UtilSP.getUserId()).setUnReadMessageNum2Zero(JS_ChatListModel.ACCOUNT_ID);
                        SystemMessageUtil.deleteSystemMessage("4");
                    }
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(PF_PaActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (myBroadcastReceiver != null) {
                unregisterReceiver(myBroadcastReceiver);
            }
        } catch(Exception e) {

        }
    }
}
