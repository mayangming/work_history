package com.qlk.ymz.activity;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_ChoosePatientAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.parse.Parse2PatientBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.PinnedHeaderExpandableListView;
import com.qlk.ymz.view.XCSlideBar_V2;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YRExpandableListRefreshLayout;
import com.xiaocoder.android.fw.general.dialog.XCSystemVDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonParse;
import com.xiaocoder.android.fw.general.util.UtilMd5;
import com.xiaocoder.android.fw.general.util.UtilNet;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;

import org.apache.http.Header;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * SX_ChoosePatientActivity
 * 选择患者页面
 * @author songxin on 2016/12/13.
 * @version 2.7.0
 */
public class SX_ChoosePatientActivity extends DBActivity {
    private XCTitleCommonLayout titleCommonFragment;
    /** 从接口获得的字母list（有患者的字母） */
    private ArrayList<String> parentList = new ArrayList<>();
    /** 按字母分组的所有患者list */
    private List<List<XC_ChatModel>> childList = new ArrayList<>();
    /** 右侧字母列表的滑条 */
    private XCSlideBar_V2 xc_id_fragment_search_slide_slidebar;
    /** 屏幕中间弹出的显示字母的dialog */
    private TextView xc_id_fragment_search_slide_dialog;
    /** 患者可扩展列表刷新 */
    private YRExpandableListRefreshLayout re_fragment_search_slide_listview;
    /** 患者可扩展列表 */
    private PinnedHeaderExpandableListView xc_id_fragment_search_slide_listview;
    /** 添加患者的适配器 */
    private SX_ChoosePatientAdapter choosePatientAdapter;
    /** 无网络显示 */
    private LinearLayout xc_id_model_no_net_main;
    /** 无网络的提示栏
     * V2.5 add  患者信息修改，刷新患者列表广播
     * */
    public NoNetBroadCastReceiver noNetBroadCastReceiver;
    /** V2.5  患者信息修改,广播ACTION */
    public static final String REFRESH_ACTION = "refresh_action";
    /** 无患者时候的背景图 */
    private  View include_data_zero_view;
    /** 等待对话框 */
    private Dialog loadingDialog;
    /** 特别关注标题名 */
    private String myAttention = "我的关注";

    private List<XC_ChatModel> currentChoosePatientBean = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_choose_patient);
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if(null != (intent.getSerializableExtra("currentChoosePatientBean")) &&
                ((List<XC_ChatModel>)intent.getSerializableExtra("currentChoosePatientBean")).size() > 0){
            currentChoosePatientBean.addAll((List<XC_ChatModel>)intent.getSerializableExtra("currentChoosePatientBean"));
        }
    }

    /** created by songxin,date：2017-4-10,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_ChoosePatientActivity.class);
    }

    /** created by songxin,date：2016-4-10,about：bi,end */

    @Override
    protected void onResume() {
        super.onResume();
        requestPatientABC(true);
    }

    /**
     * 初始化控件
     */
    @Override
    public void initWidgets() {
        titleCommonFragment = getViewById(R.id.xc_id_model_titlebar);
        titleCommonFragment.setTitleLeft(true, "");
        titleCommonFragment.setTitleRight2(true, 0,"完成");
        titleCommonFragment.setTitleCenter(true,"指定患者收到");

        loadingDialog = new XCSystemVDialog(this);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(REFRESH_ACTION);
        registerReceiver(noNetBroadCastReceiver = new NoNetBroadCastReceiver(), intentFilter);

        xc_id_model_no_net_main = getViewById(R.id.xc_id_model_no_net_main);
        //检查网络是否连接
        xc_id_model_no_net_main.setVisibility(UtilNet.isNetworkAvailable(SX_ChoosePatientActivity.this) ? View.GONE : View.VISIBLE);
        //初始化右侧字母列表bar和字母提示dialog
        xc_id_fragment_search_slide_dialog = getViewById(R.id.xc_id_fragment_search_slide_dialog);
        xc_id_fragment_search_slide_slidebar = getViewById(R.id.xc_id_fragment_search_slide_slidebar);
        xc_id_fragment_search_slide_slidebar.setTextView(xc_id_fragment_search_slide_dialog);
        //初始化患者列表
        initListView();
        //初始化无患者时候的背景图
        setNoPatientView();
    }

    /** 初始化患者列表 */
    public void initListView(){
        re_fragment_search_slide_listview = getViewById(R.id.re_fragment_search_slide_listview);
        xc_id_fragment_search_slide_listview = (PinnedHeaderExpandableListView) re_fragment_search_slide_listview.getListView();
        //添加悬浮view的布局
        final View mHeaderView = View.inflate(SX_ChoosePatientActivity.this, R.layout.xc_l_adapter_patient_letter_out_item, null);
        xc_id_fragment_search_slide_listview.setHeaderView(mHeaderView);
        choosePatientAdapter = new SX_ChoosePatientAdapter(childList,parentList,SX_ChoosePatientActivity.this);
        xc_id_fragment_search_slide_listview.setAdapter(choosePatientAdapter);
        //ListView中有headerView
        xc_id_fragment_search_slide_listview.setHasHeaderView(true);
        //给悬浮字母View添加数据
        xc_id_fragment_search_slide_listview.setPinnedableView(new PinnedHeaderExpandableListView.Pinnedable() {
            @Override
            public void setHeaderData(int groupPosition) {
                if (groupPosition < 0)
                    return;
                String groupData = choosePatientAdapter.getGroupDate().get(groupPosition);
                TextView textView = (TextView) mHeaderView.findViewById(R.id.xc_id_fragment_search_letter_view);
                textView.setText(groupData);
            }
        });

        re_fragment_search_slide_listview.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {
                return true;
            }

            @Override
            public boolean canLoad() {
                return false;
            }

            @Override
            public void refresh(View view, int request_page) {
                requestPatientABC(false);
            }

            @Override
            public void load(View view, int request_page) {
            }
        });
    }

    /** 初始化无患者时候的背景图 */
    public void setNoPatientView() {
        include_data_zero_view = getViewById(R.id.include_data_zero_view);
        include_data_zero_view.setVisibility(View.GONE);

        TextView xc_id_no_net_button = (TextView) include_data_zero_view.findViewById(R.id.xc_id_data_zero_hint_textview);
        xc_id_no_net_button.setText(Html.fromHtml("您还没有新增患者，快让患者扫描您的<font color='#e2231a'>二维码</font>吧!"));
        xc_id_no_net_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UtilNativeHtml5.toJumpQRcode(SX_ChoosePatientActivity.this,  "0");
            }
        });
        ((ImageView) include_data_zero_view.findViewById(R.id.xc_id_data_zero_imageview)).setImageResource(R.mipmap.js_d_icon_no_data);
    }


    /**
     * 监听
     */
    @Override
    public void listeners() {
        titleCommonFragment.getXc_id_titlebar_right_layout().setOnClickListener(this);

        xc_id_model_no_net_main.setOnClickListener(this);
        titleCommonFragment.getXc_id_titlebar_left_layout().setOnClickListener(this);
        // 右侧字母列表的滑动监听
        xc_id_fragment_search_slide_slidebar.setOnTouchingLetterChangedListener(new XCSlideBar_V2.OnTouchingLetterChangedListener() {

            @Override
            public void onTouchingLetterChanged(String s) {
                //获得手指按压的字母位置，患者列表滑动到相应字母位置
                Integer position = choosePatientAdapter.getPositionFromLetter(s);
                if (position != null) {
                    xc_id_fragment_search_slide_listview.setSelection(position + 1); // 由于有headView所以+1；2.5版本添加了"我的关注"+1
                }
            }
        });
        // 返回true，不会收缩(点击效果还在)，即在调用allExpand后， 再设置该监听，即可达到全部展示不会收缩的效果
        xc_id_fragment_search_slide_listview.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                return true;
            }
        });

        titleCommonFragment.getXc_id_titlebar_right2_textview().setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.xc_id_titlebar_right_layout:  // V2.7改成打开下拉菜单（包括二维码邀请和群发消息）
                UtilNativeHtml5.toJumpQRcode(SX_ChoosePatientActivity.this, "0");
                break;
            case R.id.xc_id_titlebar_left_layout:
                finish();
                break;
            case R.id.xc_id_model_no_net_main:
                //判断手机系统的版本  即API大于10 就是3.0或以上版本
                if(android.os.Build.VERSION.SDK_INT > 10 ){
                    //3.0以上打开设置界面，也可以直接用ACTION_WIRELESS_SETTINGS打开到wifi界面
                    startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
                } else {
                    startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS));
                }
                break;
            //完成按钮事件
            case R.id.xc_id_titlebar_right2_textview:{
                //遍历已选中的患者
                List<XC_ChatModel> currentChoosePatientBean = new ArrayList<>();
                for(List<XC_ChatModel> choosePatientBeenList :childList){
                        for(XC_ChatModel choosePatientBean :choosePatientBeenList){
                            if(choosePatientBean.getUserPatient().isChoose()){
                                currentChoosePatientBean.add(choosePatientBean);
                            }
                        }
                }
                if(currentChoosePatientBean.size() == 0){
                    shortToast("请选择至少一个患者");
                    return;
                }

                Intent intent = new Intent();
                intent.putExtra("ChoosePatientBeanList",(Serializable)currentChoosePatientBean);
                setResult(0,intent);
                finish();
                break;
            }
        }
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    /** 初始化abc患者列表全部展开 */
    public void allExpandList() {
        int count = choosePatientAdapter.getGroupCount();
        for (int i = 0; i < count; i++) {
            if (!xc_id_fragment_search_slide_listview.isGroupExpanded(i)) {
                xc_id_fragment_search_slide_listview.expandGroup(i);
            }
        }
    }

    /**
     * 1、监听网络状态，无网络显示提示view
     * 2、监听备注页患者信息变化，本地刷新患者列表
     */
    private class NoNetBroadCastReceiver extends BroadcastReceiver {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (REFRESH_ACTION.equals(action)) {
                requestPatientABC(false);
            }
        }
    }

    /**
     * 获取患者abc列表
     * 为了避免低性能手机在请求的时候产生卡顿现象，做了减少请求次数的优化
     * 目前只有四种情况需要请求患者列表：1、医生登陆的时候；2、patientFragment创建的时候；
     *                                   3、医生添加新患者，向服务器发送push消息的时候；4、医生主动修改患者备注名后。
     * @param isProgress 是否显示加载进度条（true 显示；false 不显示）
     */
    public void requestPatientABC(boolean isProgress) {
        if (isProgress){
            if (loadingDialog == null) {
                loadingDialog = new XCSystemVDialog(SX_ChoosePatientActivity.this);
            }
            loadingDialog.show();
        }
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.patient_my), new RequestParams(), new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, final byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean != null) {
                        refreshPatientList(result_bean, arg2);
                    }
                } else {
                    //请求数据为空时，获取sp中存储的患者列表String，并进行json解析，刷新患者列表
                    refreshPatientList(XCJsonParse.getJsonParseData(UtilSP.getContactsList()), null);
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                //请求失败时，获取sp中存储的患者列表String，并进行json解析，刷新患者列表
                refreshPatientList( XCJsonParse.getJsonParseData(UtilSP.getContactsList()), null);
                if (loadingDialog != null && loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }
            }


            @Override
            public void onFinish() {
                super.onFinish();
                //create by songxin date:2016-10-11 about:bug begin
                if (null != result_bean) {
                    GeneralReqExceptionProcess.checkCode(SX_ChoosePatientActivity.this,
                            getCode(),
                            getMsg());
                }
                //create by songxin date:2016-10-11 about:bug end
                re_fragment_search_slide_listview.completeRefresh(result_boolean, false);
            }
        });
    }

    /**
     * 刷新患者列表,无数据显示遮罩
     * @param result_bean 患者的整个报文数据
     * @param arg2 接口请求获得的患者列表byte数组
     * */
    public void refreshPatientList(XCJsonBean result_bean, final byte[] arg2) {
        Parse2PatientBean.parseort(parentList, childList, result_bean);
        updateParentAndChild(arg2);
    }


    /**
     * 更新parentList和childList
     * @param arg2 接口请求获得的患者列表byte数组
     * */
    public void updateParentAndChild(final byte[] arg2 ) {
        if(currentChoosePatientBean.size() > 0){
            for(XC_ChatModel currentChoosePatientBeanList : currentChoosePatientBean){
                for (List<XC_ChatModel> list: childList) {
                    for(int i = 0; i < list.size(); i++){
                        if(list.get(i).getUserPatient().getPatientId().equals(currentChoosePatientBeanList.getUserPatient().getPatientId())){
                            list.get(i).getUserPatient().setChoose(true);
                        }
                    }
                }
            }
        }
        int patientNum = 0;//患者总数，所有字母下的患者数之和

        //便利患者列表，获得患者总数
        for (List<XC_ChatModel> list: childList) {
            patientNum += list.size();
        }

        //如果没有患者，显示无患者默认图
        if (patientNum>0) {
            include_data_zero_view.setVisibility(View.GONE);
        } else {

            include_data_zero_view.setVisibility(View.VISIBLE);
        }
        titleCommonFragment.getXc_id_titlebar_center_textview().setVisibility(View.VISIBLE);
//        titleCommonFragment.getXc_id_titlebar_center_textview().setText(Html.fromHtml("选择患者<small>(" + patientNum +")</small>"));
        // notifyDataSetChanged和adapter数据修改必须放在同一线程中（主线程），如果多线程处理，会发生异常：
        // Java.lang.IllegalStateException: The content of the adapter has changed but ListView did not receive a notification
        //存储患者总数，首页要用
        UtilSP.setPatientSum(String.valueOf(patientNum));
        if (parentList.size() > 0 && myAttention.equals(parentList.get(0))) {
            ArrayList<String> campList = new ArrayList<>();
            campList.addAll(parentList);
            campList.set(0, "");
            xc_id_fragment_search_slide_slidebar.setABC(campList);
        } else {
            xc_id_fragment_search_slide_slidebar.setABC(parentList);
        }
        choosePatientAdapter.updateABCPosition();
        choosePatientAdapter.notifyDataSetChanged();
        allExpandList();

        if (loadingDialog != null && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }

        // 解决主线程卡死问题。开子线程，更新数据库，插入患者
        new Thread(new Runnable() {
            @Override
            public void run() {
                updatePatientDB(arg2);
            }
        }).start();

    }

    /**
     * 将接口请求的患者列表数据存入数据库，如果DB中已经有患者列表，则进行数据比较，更新修改的数据
     * @param arg2 网络请求获得的患者列表数据的byte数组
     * */
    public void updatePatientDB(byte[] arg2) {
        //如果为null,表示是缓存中取sp，否则是接口取；只有从接口中取得数据才进行字符串匹配，进行查库操作
        if (arg2 != null) {
            //将接口请求的数据进行MD5加密
            String byteStr = saveContacts2Local(arg2);
            String newJson = UtilMd5.MD5Encode(byteStr);
            //从sp中获得已经存储的加密字符串
            String oldJson = GlobalConfigSP.getMD5PatientListJson();
            //比对上次患者列表json和新获得的患者列表json数据,不相等进行下面操作
            if (!newJson.equals(oldJson)) {
                //将字符串存储到sp中
                UtilSP.putContactsList(byteStr);
                //将新的加密字符串存储到sp中
                GlobalConfigSP.putMD5PatientListJson(newJson);
                //将数据插入患者db
                ArrayList<XC_ChatModel> allPatientList = new ArrayList<>();
                for (List<XC_ChatModel> c : childList) {
                    allPatientList.addAll(c);
                }
                JS_ChatListDB.getInstance(SX_ChoosePatientActivity.this, UtilSP.getUserId())
                        .insertAllChatInfo(allPatientList);
            }
        }
    }

    /**
     * 将接口请求到的数组流转成字符转
     * @param arg2 byte数组流
     *  */
    public String saveContacts2Local(byte[] arg2) {
        try {
            return  new String(arg2, "utf-8");
        } catch (Exception e) {
            return new String(arg2);
        }
    }

}
