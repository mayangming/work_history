package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

/**
 * 聊天详情  医生 纯文本消息
 */
public class XC_ChatLeftTextHolder extends XC_ChatLeftBaseHolder {

    public TextView xc_id_adapter_left_content_text;

    public XC_ChatLeftTextHolder(View convertView) {
        super(convertView);
        xc_id_adapter_left_content_text = (TextView) convertView.findViewById(R.id.xc_id_adapter_left_content_text);
    }
}