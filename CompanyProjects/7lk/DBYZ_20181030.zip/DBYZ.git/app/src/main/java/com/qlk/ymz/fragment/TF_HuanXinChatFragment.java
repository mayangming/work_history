package com.qlk.ymz.fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.hyphenate.EMCallBack;
import com.hyphenate.EMMessageListener;
import com.hyphenate.chat.EMClient;
import com.hyphenate.chat.EMConversation;
import com.hyphenate.chat.EMImageMessageBody;
import com.hyphenate.chat.EMMessage;
import com.hyphenate.chat.EMTextMessageBody;
import com.hyphenate.easeui.EaseConstant;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantChatList;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantMessageAdapter;
import com.hyphenate.easeui.controller.EaseUI;
import com.hyphenate.easeui.utils.EaseCommonUtils;
import com.hyphenate.easeui.widget.EaseTitleBar;
import com.qlk.ymz.util.qlkserivce.chatrow.TF_DoctorAsstantCustomChatRowProvider;
import com.hyphenate.util.PathUtil;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.model.TF_DoctorInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.qlkserivce.TF_DoctorAsstantFileUtils;
import com.qlk.ymz.util.qlkserivce.QlkServiceHelper;
import com.qlk.ymz.view.EaseChatPrimaryMenuBase;
import com.qlk.ymz.view.TF_HuanXinServiceInputMenu;
import com.qlk.ymz.view.XCRecoderVoiceDialog;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.dialog.XCSystemVDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilBroadcast;
import com.xiaocoder.android.fw.general.util.UtilOom;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import org.apache.http.Header;
import java.io.File;
import java.util.List;

/**
 * 封装环信发送消息逻辑类
 */
public class TF_HuanXinChatFragment extends DBFragment implements EMMessageListener {
    /**
     * 相机code
     */
    protected static final int REQUEST_CODE_CAMERA = 2;
    /**
     * 图库code
     */
    protected static final int REQUEST_CODE_LOCAL = 3;
    /**
     * 传递的信息
     */
    protected Bundle fragmentArgs;
    /**
     * 发送消息的类型 有单聊、群聊、聊天室
     */
    protected int chatType;
    /**
     * 医生发送消息给谁    (环信提供的IM用户)QlkServiceConstant.DEFAULT_COSTOMER_ACCOUNT
     */
    protected String toChatUsername;
    /**
     *  本次会话
     */
    protected EMConversation conversation;
    /**
     * titlebar
     */
    protected EaseTitleBar titleBar;
    /**
     * 聊天列表
     */
    protected TF_DoctorAsstantChatList messageList;
    /**
     * 底部控制按钮
     */
    protected TF_HuanXinServiceInputMenu inputMenu;
    /**
     * 输入法管理类与文本复制管理类
     */
    protected InputMethodManager inputManager;
    protected ClipboardManager clipboard;
    protected Handler handler = new Handler();
    /**
     * 调用相机拍照完成之后临时保存文件
     */
    protected File cameraFile;
    /**
     * 聊天列表
     */
    protected SwipeRefreshLayout swipeRefreshLayout;
    protected ListView listView;
    protected TF_DoctorAsstantMessageAdapter adapter;
    protected boolean isloading;
    protected boolean haveMoreData = true;
    private boolean isFile;
    /**
     * 每次加载消息数量
     */
    protected int pagesize = 20;
    /**
     * 消息实体
     */
    protected EMMessage contextMenuMessage;
    /**
     * 消息列表是否初始化完成
     */
    private boolean isMessageListInited;
    /**
     * 无网络view
     */
    private RelativeLayout noNetLayout;
    /**
     * cms获取的医生消息
     */
    protected TF_DoctorInfo info;
    /**
     * 医生性别
     */
    protected String gender;
    /**
     * 在聊天列表是否显示姓名
     */
    private boolean showNickName = false;
    /**
     * 登录失败页面
     */
    private RelativeLayout tf_login_fail_rl;
    /**
     * 重新加载
     */
    private Button tf_relogin_btn;
    /**
     * 登录成功页面
     */
    private RelativeLayout tf_chat_view_rl;
    /**
     * 重发消息确认dialog
     */
    private YR_CommonDialog mYR_commonDialog;
    /**
     * 等待对话框
     */
    private Dialog loadingDialog;
    private EMMessage emMessage;
    /**
     * 因线上客服端那边获取到的医生信息错误 故在app端添加日志
     */
    protected TF_DoctorAsstantFileUtils fileUtils;
    /**
     * 拼接医生信息
     */
    private StringBuilder mDoctorInfo;
    /**
     * 录音倒计时的视图
     */
    private XCRecoderVoiceDialog voiceTimeDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return init(inflater, R.layout.tf_fragment_chat_huanxin);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // 用于登录失败后重新加载更新UI
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case QlkServiceHelper.QLKSERVICE_LOGIN_SUCCESS:
                        tf_chat_view_rl.setVisibility(View.VISIBLE);
                        tf_login_fail_rl.setVisibility(View.GONE);
                        inputMenu.setVisibility(View.VISIBLE);
                        break;
                }
                if (loadingDialog != null && loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }
                super.handleMessage(msg);
            }
        };
        //获取传递的参数
        fragmentArgs = getArguments();
        // 传递来的聊天消息类型  客服只是单聊
        chatType = fragmentArgs.getInt(EaseConstant.EXTRA_CHAT_TYPE, EaseConstant.CHATTYPE_SINGLE);
        // 用户ID或者群ID   客服只是IM服务号
        toChatUsername = fragmentArgs.getString(EaseConstant.EXTRA_USER_ID);
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void initWidgets() {
        loadingDialog = new XCSystemVDialog(getActivity());
        titleBar = (EaseTitleBar) getView().findViewById(R.id.title_bar);
        noNetLayout = (RelativeLayout) getView().findViewById(R.id.tf_nonet_rl);
        messageList = (TF_DoctorAsstantChatList) getView().findViewById(R.id.message_list);
        tf_login_fail_rl = (RelativeLayout) getView().findViewById(R.id.tf_login_fail_rl);
        tf_relogin_btn = (Button) getView().findViewById(R.id.tf_relogin_btn);
        tf_chat_view_rl = (RelativeLayout) getView().findViewById(R.id.tf_chat_view_rl);
        messageList.setShowUserNick(showNickName);
        listView = messageList.getListView();
        inputMenu = (TF_HuanXinServiceInputMenu) getView().findViewById(R.id.input_menu);
        requestCmsDectorInfo();
        getUserDetail(UtilSP.getUserId());
        swipeRefreshLayout = messageList.getSwipeRefreshLayout();
        swipeRefreshLayout.setColorSchemeResources(R.color.holo_blue_bright, R.color.holo_green_light,
                R.color.holo_orange_light, R.color.holo_red_light);
        inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        clipboard = (ClipboardManager) getActivity().getSystemService(Context.CLIPBOARD_SERVICE);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        //判断环信是否登陆成功 来显示隐藏布局
        if (QlkServiceHelper.getInstance().isHuanXinLogin()) {
            tf_login_fail_rl.setVisibility(View.GONE);
            tf_chat_view_rl.setVisibility(View.VISIBLE);
            inputMenu.setVisibility(View.VISIBLE);
        } else {
            tf_chat_view_rl.setVisibility(View.GONE);
            tf_login_fail_rl.setVisibility(View.VISIBLE);
            inputMenu.setVisibility(View.GONE);
        }
    }


    @Override
    public void listeners() {
        //设置title以及点击事件
        titleBar.setTitle(toChatUsername);
        titleBar.setRightImageResource(R.drawable.tf_doctorasstant_phone);
        titleBar.setLeftLayoutClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });
        tf_relogin_btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                QlkServiceHelper.JudgeRegister = true;
                if (loadingDialog == null) {
                    loadingDialog = new XCSystemVDialog(getActivity());
                }
                loadingDialog.show();
                QlkServiceHelper.getInstance().loginHuanXin(new EMCallBack() {
                    @Override
                    public void onSuccess() {
                        handler.sendEmptyMessage(QlkServiceHelper.QLKSERVICE_LOGIN_SUCCESS);
                    }

                    @Override
                    public void onError(int i, String s) {
                        handler.sendEmptyMessage(QlkServiceHelper.QLKSERVICE_LOGIN_ERROR);
                    }

                    @Override
                    public void onProgress(int i, String s) {

                    }
                });
            }
        });
        //初始化联系人与消息
        onConversationInit();
        //消息列表
        onMessageListInit();
        // 设置下方Menu点击事件
        inputMenu.setChatPrimaryMenuListener(new EaseChatPrimaryMenuBase.EaseChatPrimaryMenuListener() {
            @Override
            public void onSendBtnClicked(String content) {
                sendTextMessage(content);
            }

            @Override
            public void onVoiceRecordComplete(String voiceFilePath, int voiceTimeLength) {
                sendVoiceMessage(voiceFilePath, voiceTimeLength);
            }

            @Override
            public void onPressToPhotoBtnClicked() {
                selectPicFromLocal();
            }

            @Override
            public void onPressToCameraBtnclicked() {
                selectPicFromCamera();
            }

            @Override
            public void showDialog() {
                if (voiceTimeDialog == null) {
                    voiceTimeDialog = new XCRecoderVoiceDialog(getActivity());
                }
                voiceTimeDialog.show();
            }

            @Override
            public void hideDialog() {
                if (voiceTimeDialog != null && voiceTimeDialog.isShowing()) {
                    voiceTimeDialog.cancel();
                }
            }

            @Override
            public void updateTime(int time) {
                voiceTimeDialog.getTextView().setText(time + "");
            }
        });

        setRefreshLayoutListener();

        //转发消息
        String forward_msg_id = getArguments().getString("forward_msg_id");
        if (forward_msg_id != null) {
            forwardMessage(forward_msg_id);
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UtilBroadcast.myRegisterReceiver(getActivity(), 1000, ConnectivityManager.CONNECTIVITY_ACTION, mConnectivityReceiver);
        fileUtils = TF_DoctorAsstantFileUtils.getInstance();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    protected void onConversationInit() {
        conversation = EMClient.getInstance().chatManager().getConversation(toChatUsername, EaseCommonUtils.getConversationType(chatType), true);
        conversation.markAllMessagesAsRead();
        // the number of messages loaded into conversation is getChatOptions().getNumberOfMessagesLoaded
        // you can change this number
        final List<EMMessage> msgs = conversation.getAllMessages();
        int msgCount = msgs != null ? msgs.size() : 0;
        if (msgCount < conversation.getAllMsgCount() && msgCount < pagesize) {
            String msgId = null;
            if (msgs != null && msgs.size() > 0) {
                msgId = msgs.get(0).getMsgId();
            }
            conversation.loadMoreMsgFromDB(msgId, pagesize - msgCount);
        }

    }

    protected void onMessageListInit() {
        messageList.init(toChatUsername, chatType, chatFragmentHelper != null ?
                chatFragmentHelper.onSetCustomChatRowProvider() : null);
        //item点击事件监听
        setListItemClickListener();
        //触摸关闭键盘与语音view
        messageList.getListView().setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideKeyboard();
                inputMenu.getTf_serivce_chat_recoder_rl().setVisibility(View.GONE);
                return false;
            }
        });

        isMessageListInited = true;
    }

    /**
     * 聊天列表点击事件
     */
    protected void setListItemClickListener() {
        messageList.setItemClickListener(new TF_DoctorAsstantChatList.MessageListItemClickListener() {

            @Override
            public void onUserAvatarClick(String username) {
                if (chatFragmentHelper != null) {
                    chatFragmentHelper.onAvatarClick(username);
                }
            }

            @Override
            public void onUserAvatarLongClick(String username) {
                if (chatFragmentHelper != null) {
                    chatFragmentHelper.onAvatarLongClick(username);
                }
            }

            @Override
            public void onResendClick(EMMessage message) {
                //更改重发消息
                emMessage = message;
                if (mYR_commonDialog == null) {
                    createReSendDialog();
                } else {
                    mYR_commonDialog.show();
                }

            }

            @Override
            public void onBubbleLongClick(EMMessage message) {
                contextMenuMessage = message;
                if (chatFragmentHelper != null) {
                    chatFragmentHelper.onMessageBubbleLongClick(message);
                }
            }

            @Override
            public boolean onBubbleClick(EMMessage message) {
                if (chatFragmentHelper != null) {
                    return chatFragmentHelper.onMessageBubbleClick(message);
                }
                return false;
            }

        });
    }

    /**
     * 刷新消息列表   获取历史消息
     */
    protected void setRefreshLayoutListener() {
        swipeRefreshLayout.setOnRefreshListener(new OnRefreshListener() {

            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        if (listView.getFirstVisiblePosition() == 0 && !isloading && haveMoreData) {
                            List<EMMessage> messages;
                            try {
                                //调用这行代码环信SDK会自动加载历史消息，不用我们手动拼接Message
                                messages = conversation.loadMoreMsgFromDB(messageList.getItem(0).getMsgId(),
                                        pagesize);
                            } catch (Exception e1) {
                                swipeRefreshLayout.setRefreshing(false);
                                return;
                            }
                            if (messages.size() > 0) {
                                //指定listview 列表滑动位置
                                messageList.refreshSeekTo(messages.size() - 1);
                                if (messages.size() != pagesize) {
                                    haveMoreData = false;
                                }
                            } else {
                                haveMoreData = false;
                            }
                            isloading = false;
                        } else {
                            Toast.makeText(getActivity(), getResources().getString(R.string.no_more_messages),
                                    Toast.LENGTH_SHORT).show();
                        }
                        swipeRefreshLayout.setRefreshing(false);
                    }
                }, 600);
            }
        });
    }

    /**
     * 从相机跟图库返回
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CODE_CAMERA) {
                if (cameraFile != null && cameraFile.exists())
                    sendImageMessage(cameraFile.getAbsolutePath());
            } else if (requestCode == REQUEST_CODE_LOCAL) {
                if (data != null) {
                    Uri selectedImage = data.getData();
                    if (selectedImage != null) {
                        Bitmap bitmap = UtilOom.getBitmapFromUriForLarge(getActivity(), selectedImage, 500);
                        if (bitmap != null) {
                            sendPicByUri(selectedImage);
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (isMessageListInited)
            messageList.refresh();
        EaseUI.getInstance().pushActivity(getActivity());
        EMClient.getInstance().chatManager().addMessageListener(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EMClient.getInstance().chatManager().removeMessageListener(this);
        EaseUI.getInstance().popActivity(getActivity());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(loadingDialog,mYR_commonDialog,voiceTimeDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        UtilBroadcast.myUnregisterReceiver(getActivity(), mConnectivityReceiver);

        if (mYR_commonDialog != null && mYR_commonDialog.isShowing()) {
            mYR_commonDialog.dismiss();
            mYR_commonDialog = null;
        }
    }

    //  EMMessageListener  消息监听
    @Override
    public void onMessageReceived(List<EMMessage> messages) {
        for (EMMessage message : messages) {
            String username = message.getFrom();
            if (username.equals(toChatUsername)) {
                messageList.refreshSelectLast();
            } else {
                EaseUI.getInstance().getNotifier().onNewMsg(message);
            }
        }
    }

    @Override
    public void onCmdMessageReceived(List<EMMessage> messages) {
    }

    @Override
    public void onMessageReadAckReceived(List<EMMessage> messages) {
        if (isMessageListInited) {
            messageList.refresh();
        }
    }

    @Override
    public void onMessageDeliveryAckReceived(List<EMMessage> messages) {
        if (isMessageListInited) {
            messageList.refresh();
        }
    }

    @Override
    public void onMessageChanged(EMMessage emMessage, Object change) {
        if (isMessageListInited) {
            messageList.refresh();
        }
    }

    /**
     * 消息发送失败  重新发送消息dialog
     */
    private void createReSendDialog() {
        mYR_commonDialog = new YR_CommonDialog(getActivity(),"确定重发这条消息?","取消","确定") {
            @Override
            public void confirmBtn() {
                resendMessage(emMessage);
                mYR_commonDialog.dismiss();
            }
        };
        mYR_commonDialog.show();
    }

    protected void sendTextMessage(String content) {
        EMMessage message = EMMessage.createTxtSendMessage(content, toChatUsername);
        sendMessage(message);
    }

    protected void sendBigExpressionMessage(String name, String identityCode) {
        EMMessage message = EaseCommonUtils.createExpressionMessage(toChatUsername, name, identityCode);
        sendMessage(message);
    }

    protected void sendVoiceMessage(String filePath, int length) {
        EMMessage message = EMMessage.createVoiceSendMessage(filePath, length, toChatUsername);
        sendMessage(message);
    }

    protected void sendImageMessage(String imagePath) {
        EMMessage message = EMMessage.createImageSendMessage(imagePath, false, toChatUsername);
        sendMessage(message);
    }

    /**
     * 发送消息主要方法  在XD_ServiceChatFragment中被重写
     * @param message
     */
    protected void sendMessage(EMMessage message) {
        if (message == null) {
            return;
        }
        if (chatFragmentHelper != null) {
            chatFragmentHelper.onSetMessageAttributes(message);
        }
        EMClient.getInstance().chatManager().sendMessage(message);
        if(!UtilSP.isSended()){
            UtilSP.setSended(true);
        }
        if (isMessageListInited) {
            messageList.refreshSelectLast();
        }
    }

    /**
     * 重发消息
     * @param message
     */
    public void resendMessage(EMMessage message) {
        message.setStatus(EMMessage.Status.CREATE);
        EMClient.getInstance().chatManager().sendMessage(message);
        messageList.refresh();
    }

    //===================================================================================

    /**
     * send image
     * @param selectedImage
     */
    protected void sendPicByUri(Uri selectedImage) {
        String[] filePathColumn = {MediaStore.Images.Media.DATA};
        Cursor cursor = getActivity().getContentResolver().query(selectedImage, filePathColumn, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            cursor = null;

            if (picturePath == null || picturePath.equals("null")) {
                Toast toast = Toast.makeText(getActivity(), R.string.cant_find_pictures, Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                return;
            }
            sendImageMessage(picturePath);
        } else {
            File file = new File(selectedImage.getPath());
            if (!file.exists()) {
                Toast toast = Toast.makeText(getActivity(), R.string.cant_find_pictures, Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                return;

            }
            sendImageMessage(file.getAbsolutePath());
        }

    }


    /**
     * capture new image
     */
    protected void selectPicFromCamera() {
        if (!EaseCommonUtils.isSdcardExist()) {
            Toast.makeText(getActivity(), R.string.sd_card_does_not_exist, Toast.LENGTH_SHORT).show();
            return;
        }

        cameraFile = new File(PathUtil.getInstance().getImagePath(), EMClient.getInstance().getCurrentUser()
                + System.currentTimeMillis() + ".jpg");
        cameraFile.getParentFile().mkdirs();
        startActivityForResult(
                new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cameraFile)),
                REQUEST_CODE_CAMERA);
    }

    /**
     * select local image  直接跳转到相册
     */
    protected void selectPicFromLocal() {
        Intent intentFromLocal = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intentFromLocal.setType("image/*");
        startActivityForResult(intentFromLocal, REQUEST_CODE_LOCAL);
    }

    /**
     * hide
     */
    protected void hideKeyboard() {
        if (getActivity().getWindow().getAttributes().softInputMode != WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN) {
            if (getActivity().getCurrentFocus() != null)
                inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    /**
     * 转发消息
     * @param forward_msg_id
     */
    protected void forwardMessage(String forward_msg_id) {
        final EMMessage forward_msg = EMClient.getInstance().chatManager().getMessage(forward_msg_id);
        EMMessage.Type type = forward_msg.getType();
        switch (type) {
            case TXT:
                if (forward_msg.getBooleanAttribute(EaseConstant.MESSAGE_ATTR_IS_BIG_EXPRESSION, false)) {
                    sendBigExpressionMessage(((EMTextMessageBody) forward_msg.getBody()).getMessage(),
                            forward_msg.getStringAttribute(EaseConstant.MESSAGE_ATTR_EXPRESSION_ID, null));
                } else {
                    // get the content and send it
                    String content = ((EMTextMessageBody) forward_msg.getBody()).getMessage();
                    sendTextMessage(content);
                }
                break;
            case IMAGE:
                // send image
                String filePath = ((EMImageMessageBody) forward_msg.getBody()).getLocalUrl();
                if (filePath != null) {
                    File file = new File(filePath);
                    if (!file.exists()) {
                        // send thumb nail if original image does not exist
                        filePath = ((EMImageMessageBody) forward_msg.getBody()).thumbnailLocalPath();
                    }
                    sendImageMessage(filePath);
                }
                break;
            default:
                break;
        }

        if (forward_msg.getChatType() == EMMessage.ChatType.ChatRoom) {
            EMClient.getInstance().chatroomManager().leaveChatRoom(forward_msg.getTo());
        }
    }

    /**
     * 检测网络状态的广播，用于显示无网络的设置
     */
    private BroadcastReceiver mConnectivityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            ConnectivityManager mConnectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

            NetworkInfo info = mConnectivityManager.getActiveNetworkInfo();

            boolean hasConnectivity = info != null && info.isConnected();

            if (noNetLayout != null) {
                if (hasConnectivity) {
                    noNetLayout.setVisibility(View.GONE);
                } else {
                    noNetLayout.setVisibility(View.VISIBLE);
                }
            }
        }
    };


    protected EaseChatFragmentHelper chatFragmentHelper;

    public void setChatFragmentListener(EaseChatFragmentHelper chatFragmentHelper) {
        this.chatFragmentHelper = chatFragmentHelper;
    }

    public interface EaseChatFragmentHelper {
        /**
         * 发送属性消息
         */
        void onSetMessageAttributes(EMMessage message);

        /**
         * 头像点击事件
         * @param username
         */
        void onAvatarClick(String username);

        /**
         * 头像长按事件
         *
         * @param username
         */
        void onAvatarLongClick(String username);

        /**
         * 消息点击事件
         */
        boolean onMessageBubbleClick(EMMessage message);

        /**
         * 消息长按事件
         */
        void onMessageBubbleLongClick(EMMessage message);

        /**
         * 自定义消息类型
         * @return
         */
        TF_DoctorAsstantCustomChatRowProvider onSetCustomChatRowProvider();
    }

    //以下为获取cms医生信息
    private void requestCmsDectorInfo() {
        mDoctorInfo = new StringBuilder();
        XCHttpAsyn.postAsyn(getActivity(), AppConfig.getHostUrl(AppConfig.doctorinfo), new RequestParams(), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                //提示状态改变
                try{
                    if (result_boolean) {
                        XCJsonBean bean = result_bean.getList("data").get(0);
                        info = new TF_DoctorInfo();
                        info.setDoctorId(checkDectorInfo(String.valueOf(bean.getString("doctorId","-1"))));
                        //医生性别
                        info.setGender(checkDectorInfo(bean.getString("gender")));
                        //医生姓名
                        info.setDoctorName(checkDectorInfo(bean.getString("doctorName")));
                        //医生职称
                        info.setTitle(checkDectorInfo(bean.getString("title")));
                        //医生电话
                        info.setPhone(checkDectorInfo(bean.getString("phone")));
                        //医生所在单位
                        info.setHospital(checkDectorInfo(bean.getString("hospital")));
                        //科室
                        info.setDepartment(checkDectorInfo(bean.getString("department")));
                        //医生所在地区
                        info.setCityName(checkDectorInfo(bean.getString("cityName")));
                        //上级商务代表
                        info.setParentName(checkDectorInfo(bean.getString("parentName")));
                        //上级商务代表电话
                        info.setParentPhone(checkDectorInfo(bean.getString("parentPhone")));
                        //上级商务代表所在地区
                        info.setBusinessArea(checkDectorInfo(bean.getString("businessArea")));
                        //上级商务代表所在公司
                        info.setPartnerName(checkDectorInfo(bean.getString("partnerName")));
                        mDoctorInfo.append(bean.toString());
                        fileUtils.saveLogInfo(context, TF_DoctorAsstantFileUtils.DOCTOR_ASSTANT_CHAT, mDoctorInfo.toString());
                    }
                }catch (Exception e){
                    dShortToast("请求cms接口失败");
                }

            }
        });
    }

    private String checkDectorInfo(String info) {
        if (TextUtils.isEmpty(info)) {
            info = "无";
        }
        return info;
    }

    /**
     * 获得医生信息
     * @param doctorId 医生id
     */
    private void getUserDetail(final String doctorId) {
        RequestParams params = new RequestParams();
        params.put("id", doctorId);
        XCHttpAsyn.postAsyn(getActivity(), AppConfig.getHostUrl(AppConfig.user_detail), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    XCJsonBean bean = result_bean.getList("data").get(0);
                    gender = bean.getString("gender");
                }
            }
        });
    }

}
