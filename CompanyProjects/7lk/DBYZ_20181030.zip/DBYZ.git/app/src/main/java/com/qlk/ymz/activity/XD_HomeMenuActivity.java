package com.qlk.ymz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.bi.BiUtil;

/**
 * Created by xiedong on 2018/7/31.
 * 首页菜单页
 */

public class XD_HomeMenuActivity extends DBActivity {
    private View root;
    private TextView tv_sign;
    private TextView tv_disturb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_home_menu);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_HomeMenuActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        root = getViewById(R.id.root);
        tv_disturb = getViewById(R.id.tv_disturb);
        tv_sign = getViewById(R.id.tv_sign);
    }

    @Override
    public void listeners() {
        root.setOnClickListener(this);
        tv_sign.setOnClickListener(this);
        tv_disturb.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.root:
                myFinish();
                break;
            case R.id.tv_sign:
                myStartActivity(XD_SignRecordActivity.class);
                myFinish();
                break;
            case R.id.tv_disturb:
                myStartActivity(SX_DisturbModeActivity.class);
                myFinish();
                break;
        }
        super.onClick(v);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(0, R.anim.xc_anim_alpha);
    }

    @Override
    public void myFinish() {
        super.myFinish();
        overridePendingTransition(0, R.anim.xc_anim_alpha);
    }
}
