package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.XC_ChatImageShowActivity;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.util.List;

/**
 * @author shuYanYi on 2016/7/22.
 * @description 视频咨询详情页患者症状适配器
 */
public class YY_VideoDetailPicAdapter extends XCBaseAdapter<String> {
    private DisplayImageOptions options_small = XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.moive_bg);
    /**
     * 构造
     * @param context
     * @param list 图片地址列表
     */
    public YY_VideoDetailPicAdapter(Context context, List<String> list){
        super(context,list);
    }


    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if(view == null){
            view = LayoutInflater.from(context).inflate(R.layout.yy_item_video_detail_pic,null);
            holder = new ViewHolder();
            holder.iv = (ImageView)view.findViewById(R.id.iv);
            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }
        String imgUrl = list.get(position);
        XCApplication.displayImage(imgUrl,holder.iv,options_small);
        holder.iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                XC_ChatImageShowActivity.showPic(context,position,list);
            }
        });
        return view;
    }

    /**
     * ViewHolder类
     */
    private class ViewHolder {
        private ImageView iv;
    }


}
