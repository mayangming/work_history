package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.maintab.YR_PatientFragment;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.SX_ClearEditText;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

/**
 * @author xilinch on 2015/11/30.
 * @modifier xilinch 2015/11/30 17:13.
 * @description 患者备注名
 */
public class XL_PatientRemarkNameActivity extends DBActivity {

    /*** titlebar*/
    private XCTitleCommonLayout titlebar;
    /*** 患者id*/
    private String mPatientId;
    /*** 患者备注名*/
    private String remarkName;
    /** 患者真实姓名*/
    private String realName;
    /*** 备注名编辑框  update by cyr on 2016-11-30 统一控件 */
    private SX_ClearEditText xl_patient_et_noteName;
    /*** 0/10 限制长度显示*/
    private TextView xl_patient_tv_limited;

    /** 备注名最大长度*/
    private int max_length_remark_name = 19;
    /** 备注名最小长度*/
    private int min_length_remark_name = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xl_activity_patient_notename);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_PatientRemarkNameActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        max_length_remark_name = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_REMARK_NAME,0,19);
        min_length_remark_name = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_REMARK_NAME,1,1);

        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "备注名");
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleRight2(true, 0, "完成");
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));

        xl_patient_et_noteName = getViewById(R.id.xl_patient_et_noteName);
        xl_patient_tv_limited = getViewById(R.id.xl_patient_tv_limited);

        //患者ID不能为空
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            mPatientId = bundle.getString(CommonConfig.PATIENT_ID);
            remarkName = bundle.getString(CommonConfig.REMARK_NAME);
            //患者微信昵称和真实姓名，后台统一处理后的返回
            realName = bundle.getString(CommonConfig.REAL_NAME);
            if(UtilString.isBlank(realName)){
                realName = "";
            }
        }
        if (TextUtils.isEmpty(mPatientId)) {
            Toast.makeText(this, "患者ID非法", Toast.LENGTH_SHORT).show();
        }

        if(TextUtils.isEmpty(remarkName)){
            remarkName = "";
        }
        /** v2.5需求：
          如果患者仅有昵称，则进入备注后，显示患者的昵称；如果患者设置了姓名，则默认显示患者的姓名。 如果医生对患者进行过备注，则显示上次备注的内容。
          (这需求如果用户没有修改就保存，会出现患者本来的姓名和备注名一样的情况，需控制不给这样无意义的保存)
         */
        String displayName = realName;
        if(!TextUtils.isEmpty(remarkName)){
            displayName = remarkName;
        }

        xl_patient_et_noteName.setText(displayName);
        xl_patient_tv_limited.setText(displayName.length() + "/" + max_length_remark_name);
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(max_length_remark_name);
        xl_patient_et_noteName.setFilters(inputFilters);
        xl_patient_et_noteName.setSelection(xl_patient_et_noteName.getText().toString().length());
        xl_patient_et_noteName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int length = s.toString().trim().length();
                //显示样式 1/10
                xl_patient_tv_limited.setText(length + "/" + max_length_remark_name);
                if (length >= max_length_remark_name || length < min_length_remark_name && length != 0) {//超过最大长度 或 小于最小限制值并且不是置空的情况
                    xl_patient_tv_limited.setTextColor(getResources().getColor(R.color.c_red_e60044));
                } else {
                    xl_patient_tv_limited.setTextColor(getResources().getColor(R.color.c_gray_999999));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    @Override
    public void listeners() {
        titlebar.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击完成，调用接口
                String text = xl_patient_et_noteName.getText().toString().trim();
                /*if (TextUtils.isEmpty(text)) {
                    //为空的话，也可以提交
                    requestData(text);
                } else if (text.equals(remarkName.trim())) {
                    shortToast("备注名没有修改!");
                } else {
                    requestData(text);
                }*/
                //start modify by syy 2016/6/12 增加阻拦无意义的请求
                remarkName = remarkName.trim();
                if(text.length() < min_length_remark_name && text.length() != 0){//小于最小限制值并且不是置空的情况 （比如后台配置备注名要2个字以上，置空的情况是清空备注名要请求后台，所以text.length() != 0条件要保留）
                    shortToast("备注名需" + min_length_remark_name + "个字以上");
                    return;
                }
                //update by cyr on 2016/7/5 如果点击返回按钮不做处理，点击完成按钮提示，此处注释掉
                else if (TextUtils.isEmpty(remarkName) && TextUtils.isEmpty(text)) {
                    //原先没有备注名并且编辑框置空值的情况，不去请求
                    XL_PatientRemarkNameActivity.this.finish();
                    return;
                }
                else if (text.equals(remarkName)) {
                    shortToast("备注名没有修改!");
                    return;
                } /*else if(text.equals(realName)){
                    //根据v2.5新需求，编辑框会默认显示一个患者昵称，如果用户没有修改就保存，会出现患者昵称和备注名一样的情况
                    shortToast("备注名与患者昵称相同，请备注不一样的名字");
                    return;
                }*/
                requestData(text);
                //end modify by syy 2016/6/12 增加阻拦无意义的请求
            }
        });

    }

    @Override
    public void onNetRefresh() {

    }

//    @Override
//    public void onEditTextLengthChanged(int length) {
//        //显示样式 1/10
//        xl_patient_tv_limited.setText(length + "/" + max_length_remark_name);
//        if (length >= max_length_remark_name || length < min_length_remark_name && length != 0) {//超过最大长度 或 小于最小限制值并且不是置空的情况
//            xl_patient_tv_limited.setTextColor(getResources().getColor(R.color.c_red_e60044));
//        } else {
//            xl_patient_tv_limited.setTextColor(getResources().getColor(R.color.c_gray_999999));
//        }
//    }

    /**
     * 修改备注名请求
     * @param remarkName 备注名
     */
    private void requestData(final String remarkName) {

        RequestParams params = new RequestParams();
        params.put("patientId",mPatientId);
        params.put("remarkName",remarkName);
        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.modifyName), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {

                    Intent intent = new Intent();
                    intent.putExtra(CommonConfig.REMARK_NAME, remarkName);
                    setResult(RESULT_OK, intent);
                    //v2.5 by cyr on 2016/6/17 start  修改患者备注后，向患者列表页发送广播，刷新患者列表
                    intent.setAction(YR_PatientFragment.REFRESH_ACTION);
                    sendBroadcast(intent);
                    //v2.5 by cyr on 2016/6/17 end

                    JS_ChatListModel js_chatListModel = new JS_ChatListModel();
                    js_chatListModel.getUserPatient().setPatientId(mPatientId);
                    js_chatListModel.getUserPatient().setPatientMemoName(remarkName);
                    JS_ChatListDB.getInstance(XL_PatientRemarkNameActivity.this, UtilSP.getUserId())
                            .updatePatientRemarkName(js_chatListModel); // 更新本地患者咨询列表备注名
                    XL_PatientRemarkNameActivity.this.finish();
                }
            }
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(XL_PatientRemarkNameActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }
}
