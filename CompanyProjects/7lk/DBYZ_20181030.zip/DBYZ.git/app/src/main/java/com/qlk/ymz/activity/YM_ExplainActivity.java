package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.tencent.smtt.export.external.interfaces.SslErrorHandler;
import com.tencent.smtt.sdk.WebSettings;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * description: 病历处方说明页
 * author: YM
 * date: 2018/6/27
 * update: $date$
 * version: 2.19
 */

public class YM_ExplainActivity extends DBActivity {

    private XCTitleCommonLayout titlebar;
    private TextView explain_btn;
    private WebView webView;
    private XC_ChatModel chatModel;
    private DrRecordVOBean drRecordVOBean;
    private String flag;//处方说明页来源
    private String type;//病历类型
    private String patientId;//患者ID
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.ym_activity_explain);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YM_ExplainActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        titlebar = getViewById(R.id.explain_titlebar);
        explain_btn = getViewById(R.id.explain_btn);
        webView = getViewById(R.id.explain_webView);
        TextView centerTv = titlebar.getXc_id_titlebar_center_textview();
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) centerTv.getLayoutParams();
        lp.setMargins(400,0,0,0);
        centerTv.setLayoutParams(lp);
        titlebar.setTitleCenter(true,"先写病历后开处方的规则说明");
        titlebar.setTitleLeft(true,"");
        titlebar.setTitleLeft(R.mipmap.xc_d_chat_back, "");
        initWebView();
        initData();
    }

    @Override
    public void listeners() {
        explain_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UtilSP.setExplain(true);
                toWhere();
                myFinish();
            }
        });
    }

    private void initWebView(){
        webView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return super.shouldOverrideUrlLoading(view, url);
            }
            @Override
            public void onReceivedSslError(WebView webView, SslErrorHandler sslErrorHandler, com.tencent.smtt.export.external.interfaces.SslError sslError) {
                sslErrorHandler.proceed();

            }
        });
        WebSettings settings = webView.getSettings();
        // 自适应屏幕
        // 设置webview推荐使用的窗口
        settings.setUseWideViewPort(true);
        // 设置webview加载的页面的模式
        settings.setLoadWithOverviewMode(true);
        // 不进行缓存，总是使用网络数据
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setJavaScriptEnabled(true);
        //开启 DOM 存储功能
        settings.setDomStorageEnabled(true);
        // 增加web与native交互的代码
        webView.addJavascriptInterface(NativeHtml5.newInstance(this), JS_WebViewActivity.JS_INTERACTION_NAME);
        String url = UtilNativeHtml5.toJumpExplain();
        if (UtilString.isBlank(url)){
            shortToast("病历处方说明页地址不存在！");
            return;
        }
        webView.loadUrl(url);
    }

    /** 初始化数据 */
    private void initData(){
        flag = getIntent().getStringExtra(CommonConfig.EXPLAIN_FLAG);
        type = getIntent().getStringExtra(CommonConfig.RECOMMEND_Type);
        chatModel = (XC_ChatModel) getIntent().getSerializableExtra(CommonConfig.RECOMMEND_CHAT);
        drRecordVOBean = (DrRecordVOBean) getIntent().getSerializableExtra(CommonConfig.RECOMMEND_RECORD_MODEL);
        patientId = chatModel.getUserPatient().getPatientId();
    }

    /** 根据情况跳转 */
    private void toWhere(){
        switch (flag){
            case CommonConfig.RECOMMEND_BOTTOM://底部推荐用药
                if (CommonConfig.NO_MEDICAL_RECORD.equals(type)){//-1是没有病历，跳转至新建病历
                    ToJumpHelp.toJumpEditMedicalRecordActivity(this,patientId,2);
                }else {//查看既往病历
                    ToJumpHelp.toJumpMedicalRecordDetailActivity(this,drRecordVOBean,false);//既往病历
                }
                break;
            case CommonConfig.RECOMMEND://购药咨询
                if (CommonConfig.NO_MEDICAL_RECORD.equals(type)){//-1是没有病历，跳转至新建病历
                    ToJumpHelp.toJumpEditMedicalRecordActivity(this,patientId,2);
                }else {//查看既往病历
                    ToJumpHelp.toJumpMedicalRecordDetailActivity(this,drRecordVOBean,false);//不带处方的病历
                }
                break;
            case CommonConfig.RECOMMEND_OLD://旧的续方
                if (CommonConfig.NO_MEDICAL_RECORD.equals(type)){//-1是没有病历，跳转至新建病历
                    ToJumpHelp.toJumpEditMedicalRecordActivity(this,patientId,2);
                }else{
                    ToJumpHelp.toJumpMedicalRecordDetailActivity(this,drRecordVOBean,false);//既往病历
//                    ToJumpHelp.toJumpRecommendedMedicationActivity(this,chatModel);
                }
                break;
            case CommonConfig.RECOMMEND_NEW://新的续方
                SQ_RecommendActivity.launch(this);
                break;
            case CommonConfig.RE_BUY_NOTIC://复购
                if(!TextUtils.isEmpty(chatModel.getReBuyNotic().getRecordId())){
                    SQ_RecommendActivity.launch(this);
                    return;
                }
                if (CommonConfig.NO_MEDICAL_RECORD.equals(drRecordVOBean.getCaseType())){//-1是没有病历，跳转至新建病历
                    ToJumpHelp.toJumpEditMedicalRecordActivity(this,patientId,2);
                }else{//有既往病历
                    ToJumpHelp.toJumpMedicalRecordDetailActivity(this, drRecordVOBean,false);
                }
                break;
            case CommonConfig.RECIPE_DETAIL:
                SQ_RecommendActivity.launch(this);
                break;
        }
    }

}