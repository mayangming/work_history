package com.qlk.ymz.adapter;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.YY_SelectImgsActivity;
import com.qlk.ymz.util.ToJumpHelp;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2018/5/28.
 */

public class MedicalImageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    /** 图片集合*/
    private List<String> mImageList = new ArrayList<>();
    /** 图片item*/
    public static final int IMG = 1;
    /** 添加item*/
    public static final int ADD = 2;
    /** 图片最大数量*/
    private int maxNum;

    public MedicalImageAdapter(Context context, List<String> mImageList, int maxNum){
        this.mContext = context;
        this.mImageList = mImageList;
        this.maxNum = maxNum;
    }
    @Override
    public int getItemViewType(int position) {
        if (mImageList.size() < maxNum && position == getItemCount()-1) {
            return ADD;
        } else {
            return IMG;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_medical_image, parent,
                false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        ViewHolder viewHolder = (ViewHolder) holder;
        if(ADD == getItemViewType(position)){
            viewHolder.iv_delete.setVisibility(View.INVISIBLE);
            XCApplication.base_imageloader.displayImage("drawable://" + R.mipmap
                    .add_image, viewHolder.iv_image, XCImageLoaderHelper
                    .getDisplayNoCacheImageOptions(R.mipmap.add_image));
        }else if(mImageList.get(position).toLowerCase().startsWith("http")){
            viewHolder.iv_delete.setVisibility(View.VISIBLE);
            XCApplication.displayImage(mImageList.get(position),viewHolder.iv_image);
        }else {
            viewHolder.iv_delete.setVisibility(View.VISIBLE);
            XCApplication.displayImage("file://" +mImageList.get(position), viewHolder.iv_image);
        }

        viewHolder.iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mImageList.remove(position);
                notifyDataSetChanged();
            }
        });
        viewHolder.iv_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ADD == getItemViewType(position)){
                    ToJumpHelp.toJumpSelctImgsActivity((Activity) mContext,maxNum-mImageList.size(),
                            YY_SelectImgsActivity.MODE_MULTIPLE, true,true,false,true);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        if(mImageList.size() < maxNum ){
            return mImageList.size()+1;
        }
        return mImageList.size();
    }


    static class ViewHolder extends RecyclerView.ViewHolder {
        /** 图片*/
        ImageView iv_image;
        /** 删除*/
        ImageView iv_delete;

        public ViewHolder(View itemView) {
            super(itemView);
            iv_image = (ImageView) itemView.findViewById(R.id.iv_image);
            iv_delete = (ImageView) itemView.findViewById(R.id.iv_delete);
        }
    }
}
