package com.qlk.ymz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.model.BannerInfoBean_V2;
import com.qlk.ymz.service.XC_MqttService;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.MedicineUsageUtil;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.PastCommonUtil;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.upgrade.YR_UpgradeDialogActivity_v2;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.application.XL_CrashHandler;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonParse;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilSystem;
import com.xiaocoder.android.fw.general.view.XCImageView;

import org.apache.http.Header;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 启动界面
 * Created by sinki on 2015/6/16.
 * <p>
 * update by cyr on 2016-3-30
 * 优化升级功能
 * <p>
 * update by sk on 2016-9-1
 * 移除父类，将原父类代码移动到此类
 * <p>
 * update by syr on 2016-9-1
 * 删除本类中更新代码，统一放在YR_UpgradeDialogActivity_v2中
 */
public class SK_LoadActivity extends DBActivity {
    /**
     * 启动页图片控件
     */
    public ImageView load_image;
    /**
     * 引导页viewpage
     */
    private ViewPager mViewPager;
    /**
     * 引导页图片资源集合
     */
    public ArrayList<Integer> welcomeImgList;
    /**
     * 跳到检测h5升级code
     */
    public static final int CHECK_H5_CODE = 1;
    /**
     * 下载页面返回的广播action
     */
    public static final String JUMP_TO_MAIN = "jump_to_main";

    /**
     * 从升级页面接受的广播，跳转页面
     */
    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            finish();
        }
    };
    /**
     * 记录上一次的点击时间
     */
    private long last_time;

    /**
     * 两次点击时间的间隔
     */
    private long CLICK_TIME_GAP = 500;
    /**
     * 广告活动控件
     */
    private ImageView dynamic_image;

    /**
     * 倒计时控件
     */
    private TextView tv;
    private CountDownTimer timer;
    /**
     * 检测是否有升级(1 h5页面返回;)
     */
    public static int isupdate = 0;
    /**
     * 检测是从哪个页面进入升级界面 (0是欢迎页，1是启动页)
     */
    public static int enter_update = 0;
    /**
     * 图片被点击时跳转的url
     */
    private String targetUrl = "";
    /**
     * 是否进入下个界面 (1不进入)
     */
    private int enter_nextpage = 0;
    /**
     *  倒计时总时间
     */
    private long millTimes = 3 * 1000 + 1050;
    /**
     * 倒计时间隔时间
     */
    private long interval = 1000;
    /**
     * 判断此activity是否在前台显示
     */
    private boolean isFront = false;
    /**
     * 是否已经请求过动态接口
     */
    private boolean isRequested = false;
    /**
     * 定时器或者加载图片时间是否已经结束
     */
    private boolean isFinish = false;
    /**
     * 是否继续走图片加载成功方法
     */
    private boolean isToSuccess = true;
    /**
     * 前台图停留时间
     */
    private long frontimg_waiting = 1000;
    /**
     * 启动图加载时间
     */
    private long dynamic_img_loading = 3000;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        selectFirstPage();
        super.onCreate(savedInstanceState);

//        if (!GlobalConfigSP.getPatientRepeat()) {
//            deleteRepeatData();
//        }

        registerReceiver(broadcastReceiver, new IntentFilter(JUMP_TO_MAIN));
        XC_MqttService.actionStart(getApplicationContext(), null);
        getPublicParams();
        initCrashHandler();
        clearCache();
        // created by songxin,date：2016-4-28,about：uploadBiFailInfo,begin
        BiUtil.uploadBiFailInfo();
        // created by songxin,date：2016-4-28,about：uploadBiFailInfo,end

    }

    @Override
    protected void onResume() {
        super.onResume();
        isFront = true;
        // 点击home回到后台然后等到倒计时结束后再点击进入时进入下级界面
        if(isRequested && isFinish){
            if (UtilSP.isLogin()) {
                //首页
                Intent intent = new Intent(SK_LoadActivity.this, JS_MainActivity.class);
                intent.putExtra(JS_MainActivity.TAB_TAG, JS_MainActivity.TAB_HOME);
                intent.putExtra(JS_MainActivity.FROM_PAGE, JS_MainActivity.FROM_H5UPDATE);
                myStartActivity(intent);
            } else {
                myStartActivity(LoginAndRegisterActivity.class);
            }
        }
        // 没有升级 从欢迎页进入并且之前没有请求过动态启动图接口  这种情况下才能请求接口
        if (isupdate == 1 && enter_update == 1 && !isRequested) {
            getDynamicImage();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        isFront = false;
    }

    /**
     * created by songxin,date：2016-4-22,about：bi,begin
     */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SK_LoadActivity.class);
    }
    /** created by songxin,date：2016-4-22,about：bi,end */

    /**
     * 选择启动页状态，第一次显示欢迎页，非第一页显示启动页
     */
    public void selectFirstPage() {
        if (XCApplication.base_sp.getInt("startCode", 0) < UtilSystem.getVersionCode(this)) {//判断版本号是否显示欢迎页
            XCApplication.base_sp.putInt("startCode", UtilSystem.getVersionCode(this));
            enter_update = 0;
            initWelCom();   //v2.6.5 不要引导图
//            initLoad();
        } else {//非第一次，显示启动页
            enter_update = 1;
            initLoad();
        }
    }

    /**
     * 进入首页，有启动动画
     */
    private void initLoad() {
        setContentView(R.layout.lauch_activity_load);
        dynamic_image = getViewById(R.id.dynamic_image);
        load_image = getViewById(R.id.sk_id_load_image);
        tv = getViewById(R.id.tv);
        dynamic_image.setOnClickListener(this);
        tv.setOnClickListener(this);
        Animation alpAnimation = new AlphaAnimation(1f, 0.5f);
        alpAnimation.setDuration(1000);
        load_image.setOnClickListener(this);
        load_image.setAnimation(alpAnimation);
//        setLoad_Bg();
        alpAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation arg0) {
            }

            @Override
            public void onAnimationRepeat(Animation arg0) {
            }

            @Override
            public void onAnimationEnd(Animation arg0) {
                YR_UpgradeDialogActivity_v2.launch(SK_LoadActivity.this, YR_UpgradeDialogActivity_v2.UpgradeFrom.LOAD);
            }
        });

    }

    /**
     * 设置欢迎页轮播图
     */
    private void initWelCom() {
        setWelcomeImgList();
        setContentView(com.xiaocoder.android_fw_general.R.layout.sk_l_activity_welcome);
        mViewPager = getViewById(com.xiaocoder.android_fw_general.R.id.sk_id_welcome_viewpager);
        LayoutInflater mLi = LayoutInflater.from(this);
        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
        bitmapOptions.inJustDecodeBounds = false;
        bitmapOptions.inPreferredConfig = Bitmap.Config.RGB_565;
        bitmapOptions.inPurgeable = true;
        bitmapOptions.inInputShareable = true;
        ArrayList<View> views = new ArrayList<View>();

        for (int i = 0; i < welcomeImgList.size(); i++) {
            View view = mLi.inflate(com.xiaocoder.android_fw_general.R.layout.sk_l_item_welcome, null);
            XCImageView imageView = (XCImageView) view.findViewById(com.xiaocoder.android_fw_general.R.id.sk_id_welcome_img);
            imageView.setBackgroundDrawable(new BitmapDrawable(BitmapFactory.decodeResource(getResources(), welcomeImgList.get(i), bitmapOptions)));
            // 若为最后一张引导图则添加点击事件
            if (i == welcomeImgList.size() - 1) {
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (System.currentTimeMillis() - last_time > CLICK_TIME_GAP) {
                            last_time = System.currentTimeMillis();
                            YR_UpgradeDialogActivity_v2.launch(SK_LoadActivity.this, YR_UpgradeDialogActivity_v2.UpgradeFrom.LOAD);
                        }
                    }
                });
            }
            views.add(view);
        }

        //填充ViewPager的数据适配器
        pagerAdapter mPagerAdapter = new pagerAdapter(views);
        mViewPager.setAdapter(mPagerAdapter);
    }

    /**
     * 清除缓存
     */
    private void clearCache() {
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + UtilFiles.FILE_SEPARATOR + XCConfig.CACHE_DIR);
            if (file.exists()) {
                file.delete();
            }
            file.mkdirs();
        }
    }

    /**
     * 异常捕获
     */
    private void initCrashHandler() {
        if (XCConfig.IS_INIT_CRASH_HANDLER) {
            XL_CrashHandler crashHandler = XL_CrashHandler.getInstance();
            crashHandler.init(getApplicationContext());
        }
    }

    /**
     * 设置启动界面背景
     */
    public void setLoad_Bg() {
        load_image.setImageResource(R.mipmap.sk_d_loading_page);
    }

    /**
     * 配置欢迎界面图片资源
     */
    public void setWelcomeImgList() {
        welcomeImgList = new ArrayList<>();
        welcomeImgList.add(R.mipmap.guide_index_1);
        welcomeImgList.add(R.mipmap.guide_index_2);
        welcomeImgList.add(R.mipmap.guide_index_3);
        welcomeImgList.add(R.mipmap.guide_index_4);
        welcomeImgList.add(R.mipmap.guide_index_5);
    }

    /**
     * 获取公共信息
     */
    private void getPublicParams() {
        XCHttpAsyn.getAsyn(false, this, AppConfig.getHostUrl(AppConfig.global_config), new RequestParams(), new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean != null) {
                        List<XCJsonBean> jsonBeans = result_bean.getList("data");
                        if (jsonBeans != null && jsonBeans.size() > 0) {
                            XCJsonBean bean = jsonBeans.get(0);
                            if (bean != null) {
                                GlobalConfigSP.setCustomerServPhone(bean.getString(GlobalConfigSP.CUSTOMER_SERV_PHONE));
                                GlobalConfigSP.setMedicineEatTime(bean.getString(GlobalConfigSP.MEDICINE_EAT_TIME));
                                GlobalConfigSP.setMedicineUnit(bean.getString(GlobalConfigSP.MEDICINE_UNIT));
                                GlobalConfigSP.setMedicineDirection(bean.getString(GlobalConfigSP.MEDICINE_DIRECTION));
                                GlobalConfigSP.setAppSpreadTitle(bean.getString(GlobalConfigSP.SHARE_TITLE));
                                GlobalConfigSP.setAppSpreadDrContent(bean.getString(GlobalConfigSP.DC_SHARE_CONTENT));
                                GlobalConfigSP.setAppSpreadPtContent(bean.getString(GlobalConfigSP.PT_SHARE_CONTENT));
                                GlobalConfigSP.setServerTime(bean.getString(GlobalConfigSP.SERVER_TIME));
                                GlobalConfigSP.setPtDisabledContent(bean.getString(GlobalConfigSP.PT_DISABLED_CONTENT));
                                GlobalConfigSP.setConsultChargeList(bean.getIntegerList(GlobalConfigSP.CONSULT_CHARGE_LIST));
                                GlobalConfigSP.setDefaultMsg(bean.getString(GlobalConfigSP.DEFAULT_MSG));
                                GlobalConfigSP.setRedMsg(bean.getString(GlobalConfigSP.RED_MSG));
                                GlobalConfigSP.setGreenMsg(bean.getString(GlobalConfigSP.GREEN_MSG));
                                GlobalConfigSP.setLimitValue(bean.getString(GlobalConfigSP.LIMIT_VALUE));
                                GlobalConfigSP.setHomePublictyDot(bean.getString(GlobalConfigSP.HOME_PUBLICTY_DOT));
                                MedicineUsageUtil.saveMedicineUsageData(bean);
                                PastCommonUtil.savePasList(bean);
                            }
                        }
                    }
                }
            }

            @Override
            public void fail() {

            }
        });
    }

    class pagerAdapter extends PagerAdapter {

        private ArrayList<View> views;

        public pagerAdapter(ArrayList<View> views) {

            this.views = views;
        }

        @Override
        public int getCount() {
            return this.views.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

        public void destroyItem(View container, int position, Object object) {
            ((ViewPager) container).removeView(views.get(position));
        }

        //页面view
        public Object instantiateItem(View container, int position) {
            ((ViewPager) container).addView(views.get(position));
            return views.get(position);
        }

    }


    /**
     * 请求动态加载图
     */
    public void getDynamicImage() {
        isRequested = true;
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.STARTINFO), new RequestParams(), new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    try {
                        List<XCJsonBean> result_list = result_bean.getList("data");
                        if (result_list != null && result_list.size() > 0) {
                            List<XCJsonBean> startup_list = result_list.get(0).getList("startup");
                            if(startup_list != null && startup_list.size() > 0){
                                XCJsonBean startup = startup_list.get(0);
                                BannerInfoBean_V2 bannerInfoBeanObj = new BannerInfoBean_V2();
                                String imageUrl = startup.getString("imageUrl");
                                targetUrl = startup.getString("targetUrl");
                                bannerInfoBeanObj.setImageUrl(imageUrl);
                                bannerInfoBeanObj.setTargetUrl(targetUrl);
                                bannerInfoBeanObj.setVersionCode(startup.getString("versionCode"));
                                loadDynamicImage(imageUrl);
                            }else {
                                new Handler().postDelayed(new Runnable(){
                                    public void run() {
                                        showFail();
                                    }
                                }, frontimg_waiting);
                            }
                        }
                    }catch(Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                new Handler().postDelayed(new Runnable(){
                    public void run() {
                        showFail();
                    }
                }, frontimg_waiting);
            }
        });
    }

    /**
     * 加载动态广告图
     */
    public void loadDynamicImage(String url) {
        if (TextUtils.isEmpty(url)) {
            new Handler().postDelayed(new Runnable(){
                public void run() {
                    showFail();
                }
            }, frontimg_waiting);
            return;
        }
        ImageAware imageAware = new ImageViewAware(dynamic_image, false);
        XCApplication.base_imageloader.displayImage(url, imageAware,XCImageLoaderHelper.getDisplayNoCacheImageOptions(R.drawable.dynamic_default), new ImageLoadingListener() {

            @Override
            public void onLoadingStarted(String s, View view) {
                new Handler().postDelayed( new Runnable() {
                    @Override
                    public void run() {
                        if(isToSuccess){
                            isToSuccess = false;
                            isFinish = true;
                            tv.setVisibility(View.GONE);
                            if(isFront){
                                toNextPage();
                            }
                        }
                    }
                }, 3000);
            }

            @Override
            public void onLoadingFailed(String s, View view, FailReason failReason) {
                showFail();
            }

            @Override
            public void onLoadingComplete(String s, View view, Bitmap bitmap) {
                dynamic_image.setImageBitmap(null);
                if(isToSuccess){
                    dynamic_image.setImageBitmap(bitmap);
                    isToSuccess = false;
                    tv.setVisibility(View.VISIBLE);
                    showTimer();
                }
            }

            @Override
            public void onLoadingCancelled(String s, View view) {

            }
        });
    }


    /**
     * 没有活动图或加载活动图失败
     */
    public void showFail() {
        tv.setVisibility(View.GONE);
        toNextPage();
    }

    /**
     * 显示倒计时
     */
    public void showTimer() {
        if (timer == null) {
            timer = new CountDownTimer(millTimes, interval) {
                @Override
                public void onTick(long millisUntilFinished) {
                    int time = ((int) millisUntilFinished / 1000 - 1);
                    if (time > 0) {
                        tv.setText("跳过" + time);
                    } else {
                        tv.setText("跳过");
                    }

                }

                @Override
                public void onFinish() {
                    isFinish = true;
                    if (enter_nextpage == 0 && isFront) {
                        toNextPage();
                    }
                }
            }.start();
        }
    }

    /**
     * 取消倒计时
     */
    private void cancelTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    /**
     * 判断是否登陆来进行跳转到首页还是登陆页
     */
    public void toNextPage() {
        isupdate = 0;
        if (UtilSP.isLogin()) {
            //首页
            Intent intent = new Intent(SK_LoadActivity.this, JS_MainActivity.class);
            intent.putExtra(JS_MainActivity.TAB_TAG, JS_MainActivity.TAB_HOME);
            intent.putExtra(JS_MainActivity.FROM_PAGE, JS_MainActivity.FROM_H5UPDATE);
            myStartActivity(intent);
        } else {
            myStartActivity(LoginAndRegisterActivity.class);
        }
        finish();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.tv:
                // 倒计时控价点击跳过进入下一页
                cancelTimer();
                toNextPage();
                break;
            case R.id.dynamic_image:
                // 活动图点击进入详情链接页面
                isupdate = 0;
                if (!TextUtils.isEmpty(targetUrl)) {
                    try {
                        XCJsonBean result_bean = XCJsonParse.getJsonParseData(targetUrl);
                        if (result_bean == null) {
                            break;
                        }
                        String keyName = result_bean.getString("K");
                        String valueName = result_bean.getString("V");
                        if (UtilString.isBlank(keyName) || !NativeHtml5.QLK_WEB.equals(keyName) || UtilString.isBlank(valueName) || !valueName.startsWith("http")){
                            break;
                        }
                        isToSuccess = false;
                        enter_nextpage = 1;
                        cancelTimer();
                        finish();
                        JSONObject jsonObject = new JSONObject(targetUrl);
                        JSONObject backJson = new JSONObject();
                        backJson.put("K", NativeHtml5.QLK_HOME);
                        backJson.put("other", "1");
                        jsonObject.put(NativeHtml5.BACK_JSON, backJson);
                        NativeHtml5.newInstance(this).webToAppPage(jsonObject.toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                        cancelTimer();
                        toNextPage();
                    }
                }
                break;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(broadcastReceiver);
        cancelTimer();
        super.onDestroy();
    }

    @Override
    public void initWidgets() {
    }

    @Override
    public void listeners() {
    }

    @Override
    public void onNetRefresh() {
    }


    /**  add by cyr on 2018/6/6
     *  删除数据库可能出现的patientId相同的患者
     *  版本只做一次去重，需要登陆状态
     *  TODO 仅v2.18版本，下个版本删除此代码，有强升版本的时候再写一次
     *  */
    public void deleteRepeatData(){
        if (!TextUtils.isEmpty(UtilSP.getUserId())) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    JS_ChatListDB.getInstance(SK_LoadActivity.this,UtilSP.getUserId()).deleteRepeatPatient();
                    GlobalConfigSP.setPatientRepeat(true);
                }
            });
        }
    }

}
