package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.util.UtilFiles;

/**
 * @author 李涛
 * @description   互联网医院备案协议页面
 * @Date 2017/7/19.
 */
public class LT_NetWorkHospitalProtocol extends DBActivity{

    /**
     * WebView布局
     */
    private WebView wv_protocol;
    /**
     * 不同意按钮 和同意按钮
     */
    private LinearLayout lt_nhp_bottom_view;
    private Button lt_nhp_noagree;
    private Button lt_nhp_agree;
    private String goneView;
    private String netUrl;
    private XCTitleCommonLayout xcTitleCommonLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.lt_activity_net_work_hospital_protocol);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(LT_NetWorkHospitalProtocol.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */


    @Override
    public void initWidgets() {
        //标题部分
        xcTitleCommonLayout = (XCTitleCommonLayout) findViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonLayout.setTitleLeft(true, "");
        wv_protocol = getViewById(R.id.wv_protocol);

        lt_nhp_bottom_view = (LinearLayout) findViewById(R.id.lt_nhp_bottom_view);
        lt_nhp_noagree = (Button) findViewById(R.id.lt_nhp_noagree);
        lt_nhp_agree = (Button) findViewById(R.id.lt_nhp_agree);

        //从备案页面跳转过来需要隐藏底部的按钮布局
        Intent intent = getIntent();
        goneView = intent.getStringExtra("goneview");
        netUrl = intent.getStringExtra("netUrl");
        if("gone".equals(goneView)){
            lt_nhp_bottom_view.setVisibility(View.GONE);
        }


        //WebView布局
        WebSettings wSettings = wv_protocol.getSettings();
        wSettings.setJavaScriptEnabled(true);
        wSettings.setBuiltInZoomControls(true);
        wSettings.setDisplayZoomControls(false);
        wSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); // 不进行缓存，总是使用网络数据

        if(TextUtils.isEmpty(netUrl)){
            xcTitleCommonLayout.setTitleCenter(true, "互联网医院备案协议");
            String url = GlobalConfigSP.getHtml5NativePath() + "/html/" + UtilNativeHtml5.INTERNET_RECORD_DEAL;
            if (UtilFiles.fileIsExists(url)) {
                url = GlobalConfigSP.getHtml5NativePath() + "/html/" + UtilNativeHtml5.INTERNET_RECORD_DEAL;
                wv_protocol.loadUrl("file://" + url);
            }
        }else{
            wv_protocol.loadUrl(netUrl);

        }


        wv_protocol.setWebViewClient(new WebViewClient(){

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if(!TextUtils.isEmpty(netUrl)){
                    xcTitleCommonLayout.setTitleCenter(true,  view.getTitle());

                }
            }
        });
    }

    @Override
    public void listeners() {
        lt_nhp_noagree.setOnClickListener(this);
        lt_nhp_agree.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {}


    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()){
            case R.id.lt_nhp_agree:
                ToJumpHelp.toJumpHospitalBackupsActivity(LT_NetWorkHospitalProtocol.this);
                //保证协议页面只出现一次
                UtilSP.setOnlyBackups("1");
                this.finish();
                break;
            case R.id.lt_nhp_noagree:
                this.finish();
                break;
        }
    }



    @Override
    public void onBackPressed() {
        if(wv_protocol.canGoBack()){
            wv_protocol.goBack();
        }else{
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != wv_protocol) {
            wv_protocol.destroy();
            wv_protocol.removeAllViews();
        }
    }
}
