package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PastItemAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.PastBean;
import com.qlk.ymz.model.record.CaseInitBean;
import com.qlk.ymz.util.PastCommonUtil;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;

import java.util.ArrayList;
import java.util.List;

/**
 * 既往史   wangyong
 */
public class PastHistoryActivity extends DBActivity implements View.OnTouchListener {
    /**
     * 既往史标题
     */
    private XCTitleCommonLayout mTitleBar;
    /**
     * 既往史RecyclerView
     */
    private ListView mPastListView;
    private RecyclerView mPastRecyclerView;
    private PastItemAdapter mPastItemAdapter;
    private Context mContext;
    private List<PastBean> mList = new ArrayList<>();
    /**
     * 既往史EditText
     */
    private EditText mEditText;
    /**
     * 清空控件
     */
    private TextView mClearTv;
    /**
     * 输入计数
     */
    private TextView sx_id_word_count_record;
    /**
     * 输入最大内容计数
     */
    private TextView sx_id_write_content_max;
    /**
     * 既往史最大长度限制
     */
    int maxLength = 0;
    /**
     * 既往史最小长度限制
     */
    int minLength = 0;
    // 提示保存对话框
    private YR_CommonDialog mDialog;
    /**
     * 填写病历初始化bean
     */
    private CaseInitBean mCaseInitBean;
    private String medical;
    private boolean isNewLine = false;
    private boolean requiredFlag = false; // 是否填过数据,true:是,false:否

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mContext = this;
        setContentView(R.layout.activity_past_history);
        super.onCreate(savedInstanceState);
        initDialog();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PastHistoryActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void initWidgets() {
        mList = PastCommonUtil.getPastBeanList();
        mTitleBar = getViewById(R.id.title_common_layout);
        mTitleBar.setTitleLeft(0, "取消");
        mTitleBar.setTitleCenter(true, "既往史");
        mTitleBar.setTitleRight2(true, 0, "保存");
        mTitleBar.getXc_id_titlebar_right2_textview().setTextColor(mContext.getResources().getColor(R.color.c_444444));
        mPastRecyclerView = getViewById(R.id.recycler_past);
        mPastRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mPastItemAdapter = new PastItemAdapter(mContext, mList);

        View pastHeaderView = getLayoutInflater().from(mContext).inflate(R.layout.activity_past_history_headerview, null);
        mEditText = (EditText) pastHeaderView.findViewById(R.id.sx_id_past_edit);
        mClearTv = (TextView) pastHeaderView.findViewById(R.id.sx_id_date_show);
        sx_id_word_count_record = (TextView) pastHeaderView.findViewById(R.id.sx_id_word_count_record);
        sx_id_write_content_max = (TextView) pastHeaderView.findViewById(R.id.sx_id_write_content_max);
        mPastRecyclerView.setAdapter(mPastItemAdapter);
        mPastItemAdapter.setHeaderView(pastHeaderView);
        mPastItemAdapter.setOnUIRefreshListener(new PastItemAdapter.OnUIRefreshListener() {
            @Override
            public void setPastTv(String str) {
                String input = mEditText.getText().toString().trim();
                if (isNewLine) {
                    isNewLine = false;
                    input = input + "\n";
                    str = input + str;
                } else {
                    if (!TextUtils.isEmpty(input)) {
                        str = input + "," + str;
                    }
                }
                if (str.length() <= 1000) {
                    mEditText.setText(str);
                    mEditText.setSelection(str.length());
                } else {
                    mEditText.setText(str.substring(0, 1000));
                    mEditText.setSelection(1000);
                }
            }
        });
        initWidgetsData();
    }

    @Override
    public void listeners() {
        // 取消
        mTitleBar.getXc_id_titlebar_left_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        // 完成
        mTitleBar.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });
        mEditText.setOnTouchListener(this);
        mEditText.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String input = mEditText.getText().toString().trim();
                if (!TextUtils.isEmpty(input)) {
                    mTitleBar.getXc_id_titlebar_right2_textview().setEnabled(true);
                    mTitleBar.getXc_id_titlebar_right2_textview().setTextColor(mContext.getResources().getColor(R.color.c_444444));
                } else {
                    if ("1".equals(GlobalConfigSP.getRequiredFlag())) {
                        mTitleBar.getXc_id_titlebar_right2_textview().setEnabled(false);
                        mTitleBar.getXc_id_titlebar_right2_textview().setTextColor(mContext.getResources().getColor(R.color.c_gray_bbbbbb));
                    } else if (requiredFlag && "0".equals(GlobalConfigSP.getRequiredFlag())) {
                        mTitleBar.getXc_id_titlebar_right2_textview().setEnabled(true);
                        mTitleBar.getXc_id_titlebar_right2_textview().setTextColor(mContext.getResources().getColor(R.color.c_444444));
                    } else if (!requiredFlag && "0".equals(GlobalConfigSP.getRequiredFlag())) {
                        mTitleBar.getXc_id_titlebar_right2_textview().setEnabled(false);
                        mTitleBar.getXc_id_titlebar_right2_textview().setTextColor(mContext.getResources().getColor(R.color.c_gray_bbbbbb));
                    }
                }
                sx_id_word_count_record.setText(input.length() + "");
            }
        });
        mClearTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isNewLine = false;
                mEditText.setText("");
            }
        });
    }

    /**
     * 初始化控件显示的内容
     */
    private void initWidgetsData() {
        minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.CASEPAST, 1, 3);
        maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.CASEPAST, 0, 1000);
        mCaseInitBean = (CaseInitBean) getIntent().getSerializableExtra(XD_EditMedicalRecordActivity.CASE_INIT_BEAN);
        String past = getIntent().getStringExtra(XD_EditMedicalRecordActivity.POST_HISTORY);
        if (!TextUtils.isEmpty(past)) {
            mEditText.setText(past);
            sx_id_word_count_record.setText(past.length() + "");
            mEditText.setSelection(past.length());
        } else {
            if (mCaseInitBean != null) {
                if (mCaseInitBean.isSavePast()) {
                    mEditText.setText("");
                } else {
                    String medicAllergys = mCaseInitBean.getMedicAllergys();
                    String familyDiseases = mCaseInitBean.getFamilyDiseases();
                    String hereditaryDiseases = mCaseInitBean.getHereditaryDiseases();
                    String pastDiseases = mCaseInitBean.getPastDiseases();
                    String smoke = mCaseInitBean.getSmoke();
                    String drink = mCaseInitBean.getDrink();
                    if (!TextUtils.isEmpty(medicAllergys) || (!TextUtils.isEmpty(familyDiseases) || !TextUtils.isEmpty(hereditaryDiseases) || !TextUtils.isEmpty(pastDiseases) || !TextUtils.isEmpty(smoke) || !TextUtils.isEmpty(drink))) {
                        isNewLine = true;
                        if (!TextUtils.isEmpty(medicAllergys) && (!TextUtils.isEmpty(familyDiseases) || !TextUtils.isEmpty(hereditaryDiseases) || !TextUtils.isEmpty(pastDiseases) || !TextUtils.isEmpty(smoke) || !TextUtils.isEmpty(drink))) {
                            medicAllergys = medicAllergys + "\n";
                        }
                        if (!TextUtils.isEmpty(familyDiseases) && (!TextUtils.isEmpty(hereditaryDiseases) || !TextUtils.isEmpty(pastDiseases) || !TextUtils.isEmpty(smoke) || !TextUtils.isEmpty(drink))) {
                            familyDiseases = familyDiseases + "\n";
                        }
                        if (!TextUtils.isEmpty(hereditaryDiseases) && (!TextUtils.isEmpty(pastDiseases) || !TextUtils.isEmpty(smoke) || !TextUtils.isEmpty(drink))) {
                            hereditaryDiseases = hereditaryDiseases + "\n";
                        }
                        if (!TextUtils.isEmpty(pastDiseases) && (!TextUtils.isEmpty(smoke) || !TextUtils.isEmpty(drink))) {
                            pastDiseases = pastDiseases + "\n";
                        }
                        if (!TextUtils.isEmpty(smoke) && !TextUtils.isEmpty(drink)) {
                            smoke = smoke + "\n";
                        }
                        medical = medicAllergys + familyDiseases + hereditaryDiseases + pastDiseases + smoke + drink;
                    } else {
                        isNewLine = false;
                    }
                    if (!TextUtils.isEmpty(medical)) {
                        mEditText.setText(medical);
                        sx_id_word_count_record.setText(medical.length() + "");
                        mEditText.setSelection(medical.length());
                    }
                }
            }
        }
        if (!TextUtils.isEmpty(mEditText.getText().toString().trim())) {
            requiredFlag = true;
            mTitleBar.getXc_id_titlebar_right2_textview().setEnabled(true);
            mTitleBar.getXc_id_titlebar_right2_textview().setTextColor(mContext.getResources().getColor(R.color.c_444444));
        } else {
            mTitleBar.getXc_id_titlebar_right2_textview().setEnabled(false);
            mTitleBar.getXc_id_titlebar_right2_textview().setTextColor(mContext.getResources().getColor(R.color.c_gray_bbbbbb));
        }
        mEditText.setHint("输入既往史、个人史、过敏史、家庭史，不少于" + minLength + "个字");
        mEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        sx_id_write_content_max.setText(maxLength + "");
    }

    /**
     * 初始化保存提示对话框
     */
    private void initDialog() {
        mDialog = new YR_CommonDialog(this, "放弃保存吗？", "放弃", "取消") {
            @Override
            public void confirmBtn() {
                dismiss();
            }

            @Override
            public void cancelBtn() {
                super.cancelBtn();
                myFinish();
            }
        };
        mDialog.setCanceledOnTouchOutside(true);
    }

    /**
     * 保存
     */
    private void save() {
        String content = mEditText.getText().toString().trim();
        if (StringUtils.containsEmoji(content)) {
            shortToast("既往史不能输入表情");
            return;
        }
        if (requiredFlag && "0".equals(GlobalConfigSP.getRequiredFlag())) {
            mCaseInitBean.setSavePast(true);
            Intent intent = new Intent();
            intent.putExtra(XD_EditMedicalRecordActivity.POST_HISTORY, content);
            intent.putExtra(XD_EditMedicalRecordActivity.CASE_INIT_BEAN, mCaseInitBean);
            setResult(RESULT_OK, intent);
            myFinish();
            return;
        }
        if (content.length() < minLength) {
            shortToast("既往史输入内容小于" + minLength + "个字符，请重新输入");
            return;
        }
        mCaseInitBean.setSavePast(true);
        Intent intent = new Intent();
        intent.putExtra(XD_EditMedicalRecordActivity.POST_HISTORY, content);
        intent.putExtra(XD_EditMedicalRecordActivity.CASE_INIT_BEAN, mCaseInitBean);
        setResult(RESULT_OK, intent);
        myFinish();
    }

    @Override
    public void onBackPressed() {
        if (!TextUtils.isEmpty(mEditText.getText().toString().trim())) {
            mDialog.show();
        } else {
            myFinish();
        }

    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public boolean onTouch(View view, MotionEvent event) {
        if (view.getId() == R.id.sx_id_past_edit) {
            view.getParent().requestDisallowInterceptTouchEvent(true);
            if (event.getAction() == MotionEvent.ACTION_UP) {
                view.getParent().requestDisallowInterceptTouchEvent(false);
            }
        }
        return false;
    }
}
