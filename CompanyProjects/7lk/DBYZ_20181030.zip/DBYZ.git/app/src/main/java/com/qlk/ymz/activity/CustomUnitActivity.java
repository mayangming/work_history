package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.widget.EditText;

import com.qlk.ymz.R;
import com.qlk.ymz.model.medicine.MedicineUsageBean;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.UsageDialog;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;

/**
 * 自定义单位页
 */

public class CustomUnitActivity extends CustomBaseActivity {
  EditText  et_unit_name;

  /** 自定义单位输入内容 */
  private String unitName;

  private MedicineUsageBean usageBean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_custom_unit);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(CustomUnitActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void initWidgets() {
        title = "自定义单位";
        super.initWidgets();

        et_unit_name = getViewById(R.id.et_unit_name);
        et_unit_name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(GlobalConfigSP.getLimitValue(GlobalConfigSP.RECOM_OTHER_UNIT,0,9))});

        usageBean = (MedicineUsageBean)getIntent().getSerializableExtra(UsageDialog.TAG_USAGE_BEAN);
    }

    @Override
    public void listeners() {

    }

    @Override
    protected void save() {
        super.save();
        unitName = et_unit_name.getText().toString();
        if (TextUtils.isEmpty(unitName)){
            return;
        }
        UtilInputMethod.hiddenInputMethod(this);
        usageBean.setEachDoseUnit(unitName);
        Intent intent = new Intent();
        intent.putExtra(UsageDialog.TAG_USAGE_BEAN,usageBean);
        setResult(Activity.RESULT_OK,intent);
        finish();
    }
}
