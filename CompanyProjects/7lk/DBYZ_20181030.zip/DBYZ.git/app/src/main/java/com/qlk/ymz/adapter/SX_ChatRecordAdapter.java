package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.R;
import com.qlk.ymz.model.SX_ChatRecordInfo;
import com.qlk.ymz.view.CircleImageView;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * SX_ChatRecordAdapter
 * 聊天会话adapter
 * @author songxin on 2016/1/11.
 * @version 2.0
 */
public class SX_ChatRecordAdapter extends BaseAdapter {
    /** 上下文*/
    private Context mContext;
    /** 会话记录数据*/
    private List<SX_ChatRecordInfo> mSX_ChatRecordInfo;
    /** LayoutInflater*/
    private LayoutInflater mLayoutInflater;

    private DisplayImageOptions options_big;

    public SX_ChatRecordAdapter(Context context,List<SX_ChatRecordInfo> sx_chatRecordInfos){
        this.mContext = context;
        this.mSX_ChatRecordInfo = sx_chatRecordInfos;
        this.mLayoutInflater = LayoutInflater.from(context);
        options_big = XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_patient_default);
    }
    @Override
    public int getCount() {
        return mSX_ChatRecordInfo.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(null == convertView){
            viewHolder = new ViewHolder();
            convertView = mLayoutInflater.inflate(R.layout.sx_l_adapter_chat_record_list_item,null);
            viewHolder.sx_id_chat_record_head_photos_show = (CircleImageView)convertView.findViewById(R.id.sx_id_chat_record_head_photos_show);
            viewHolder.sx_id_patient_name = (TextView)convertView.findViewById(R.id.sx_id_patient_name);
            viewHolder.sx_id_patient_record_content = (TextView)convertView.findViewById(R.id.sx_id_patient_record_content);
            viewHolder.sx_id_chat_over_time = (TextView)convertView.findViewById(R.id.sx_id_chat_over_time);
            viewHolder.sx_id_chat_status_show = (TextView)convertView.findViewById(R.id.sx_id_chat_status_show);
//            viewHolder.sx_id_chat_spend = (TextView)convertView.findViewById(R.id.sx_id_chat_spend);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)convertView.getTag();
        }
        //显示头像
        XCApplication.base_imageloader.displayImage(mSX_ChatRecordInfo.get(position).getChat_record_head_image_url(), viewHolder.sx_id_chat_record_head_photos_show,options_big);
        //显示患者姓名
        viewHolder.sx_id_patient_name.setText(mSX_ChatRecordInfo.get(position).getChat_record_patient_name());
        //显示聊天会话
        viewHolder.sx_id_patient_record_content.setText(Html.fromHtml(UtilString.f(mSX_ChatRecordInfo.get(position).getContent())));
        //显示最后时间
        //可能需要处理时间格式
        viewHolder.sx_id_chat_over_time.setText(mSX_ChatRecordInfo.get(position).getChat_over_time());
        //聊天状态
        // add by cyr on 2016/5/13 start 修改bug2831：会话列表中咨询中和已结束文字颜色与UI不一致
        if("咨询中".equals(mSX_ChatRecordInfo.get(position).getChat_status_show())){
            viewHolder.sx_id_chat_status_show.setTextColor(mContext.getResources().getColor(R.color.c_e2231a));
        }else if("已支付".equals(mSX_ChatRecordInfo.get(position).getChat_status_show())){
            viewHolder.sx_id_chat_status_show.setTextColor(mContext.getResources().getColor(R.color.c_7b7b7b));
        }else if("未支付".equals(mSX_ChatRecordInfo.get(position).getChat_status_show())){
            viewHolder.sx_id_chat_status_show.setTextColor(mContext.getResources().getColor(R.color.c_e2231a));
        }else if("已结束".equals(mSX_ChatRecordInfo.get(position).getChat_status_show())){
            viewHolder.sx_id_chat_status_show.setTextColor(mContext.getResources().getColor(R.color.c_7b7b7b));
        }
        // add by cyr on 2016/5/13 end
        viewHolder.sx_id_chat_status_show.setText(mSX_ChatRecordInfo.get(position).getChat_status_show());
//        //显示聊天花费
//        viewHolder.sx_id_chat_spend.setText(mSX_ChatRecordInfo.get(position).getChat_spend());
        return convertView;
    }

    static class ViewHolder{
        /** 聊天会话头像*/
        CircleImageView sx_id_chat_record_head_photos_show;
        /** 聊天会话患者姓名*/
        TextView sx_id_patient_name;
        /** 聊天会话缩略*/
        TextView sx_id_patient_record_content;
        /** 聊天会话最后时间*/
        TextView sx_id_chat_over_time;
        /** 聊天会话状态显示*/
        TextView sx_id_chat_status_show;
//        /** 聊天会话花费*/
//        TextView sx_id_chat_spend;

    }
}
