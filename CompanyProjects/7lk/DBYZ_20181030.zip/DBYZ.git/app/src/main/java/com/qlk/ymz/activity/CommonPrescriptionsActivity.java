package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PrescriptionAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.RecipeBean;
import com.qlk.ymz.model.SafeMedicationBean;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.parse.Parse2SafeMedication;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 常用处方详情界面
 *
 * @author wangyong
 * @version 2.14
 */
public class CommonPrescriptionsActivity extends DBActivity {
    private Context mContext;
    private XCTitleCommonLayout title_common_layout;
    // 适应症
    private TextView et_indication;
    //常用处方列表
    private ListView prescription_lv;
    // 添加药品
    private ImageView iv_add;
    // 发送
    private TextView tv_send;
    // 常用处方适配器
    private PrescriptionAdapter mPrescriptionAdapter;
    // 常用处方药品集合
    private ArrayList<DrugBean> examineBeanList = new ArrayList<>();
    // 诊疗库集合
    private ArrayList<DiagnoseBean> diagnosisList = new ArrayList<>();
    // 编辑状态判断
    private boolean isEdit = true;
    // 药品用法用量是否发生改变
    private boolean isUsage = true;
    public static final int REQUEST_CODE_DIAGNOSE = 1001;
    private int editPosition = -1;
    // 区分是从哪个界面进来  0是新建 1是编辑
    private String commonPrescStr;
    // 原始药品列表数据
    private List<DrugBean> oriBeanList = new ArrayList<>();
    // 原始临床诊断
    private String oriDiagnose = "";
    private RecipeBean recipeBean;
    public static String RECIPE_INFO = "recipe";
    public static String COMMONPRESCRIPTION = "commonprescription";
    public static String COMMONPRESCRIPTION_INTER = "commonprescription_inter";
    // 区分是从我的药房进入还是推荐用药进入
    private int common_flag;
    private DrugBean mDrugBean;
    /**
     * 覆盖处方对话框
     */
    private YR_CommonDialog mOverRecipeDialog;
    private View line;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_common_prescriptions);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(CommonPrescriptionsActivity.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */

    public static void launch(Context context, String commonPrescStr, int interflag) {
        Intent intent = new Intent(context, CommonPrescriptionsActivity.class);
        intent.putExtra(COMMONPRESCRIPTION, commonPrescStr);
        intent.putExtra(COMMONPRESCRIPTION_INTER, interflag);
        (context).startActivity(intent);
    }

    public static void launch(Context context, RecipeBean recipeBean, String commonPrescStr, int interflag) {
        Intent intent = new Intent(context, CommonPrescriptionsActivity.class);
        intent.putExtra(RECIPE_INFO, recipeBean);
        intent.putExtra(COMMONPRESCRIPTION, commonPrescStr);
        intent.putExtra(COMMONPRESCRIPTION_INTER, interflag);
        (context).startActivity(intent);
    }

    public static void launch(Context context, DrugBean drugBean, String commonPrescStr, int interflag) {
        Intent intent = new Intent(context, CommonPrescriptionsActivity.class);
        intent.putExtra(UsageActivityV2.DRUG_INFO, drugBean);
        intent.putExtra(COMMONPRESCRIPTION, commonPrescStr);
        intent.putExtra(COMMONPRESCRIPTION_INTER, interflag);
        (context).startActivity(intent);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        getData(1, intent);
    }

    @Override
    public void initWidgets() {
        mContext = this;
        title_common_layout = getViewById(R.id.title_common_layout);
        title_common_layout.getXc_id_titlebar_center_textview().setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        title_common_layout.setTitleLeft(true, null);
        title_common_layout.setTitleCenter(true, "常用处方详情");
        title_common_layout.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backCommonPrescriptionList();
            }
        });

        title_common_layout.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchEditState();
            }
        });
        line = getViewById(R.id.line_common);
        prescription_lv = getViewById(R.id.lv_prescription_item);
        tv_send = getViewById(R.id.tv_send);
        // 常用处方的HeadView的控件初始化
        View prescription_headview = getLayoutInflater().inflate(R.layout.view_prescription_head, null);
        et_indication = (TextView) prescription_headview.findViewById(R.id.indication_edt);
        // 常用处方的FootView的控件初始化
        View prescription_footview = getLayoutInflater().inflate(R.layout.prescription_foot, null);
        iv_add = (ImageView) prescription_footview.findViewById(R.id.ym_ordonnance_medicines_add);
        prescription_lv.addHeaderView(prescription_headview);
        prescription_lv.addFooterView(prescription_footview);
        mPrescriptionAdapter = new PrescriptionAdapter(mContext,examineBeanList);
        prescription_lv.setAdapter(mPrescriptionAdapter);
        getData(0, null);
    }

    @Override
    public void listeners() {
        et_indication.setOnClickListener(this);
        iv_add.setOnClickListener(this);
        tv_send.setOnClickListener(this);
        prescription_lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DrugBean bean = (DrugBean) parent.getItemAtPosition(position);
                if (bean != null && isEdit && "1".equals(commonPrescStr)) {
                    UtilNativeHtml5.toJumpDrugDetail(mContext, bean.getId());
                }
            }
        });
        mPrescriptionAdapter.setRecommendAdapterOnClickListener(new PrescriptionAdapter.RecommendAdapterOnClickListener() {
            @Override
            public void OnRemoveClickListener(final View v, final int position,final DrugBean bean ) {
                new YR_CommonDialog(mContext, "请确认是否删除", "取消", "确认") {
                    @Override
                    public void confirmBtn() {
                        bean.setCheck(false);
                        examineBeanList.remove(position);
                        ArrayList<DrugBean> list = new ArrayList<>();
                        list.addAll(examineBeanList);
                        recipeBean.setDrugBeans(list);
//                        recipeBean.setDrugBeans(examineBeanList);
                        RecomMedicineHelper.getInstance().setCommonRecipe(recipeBean);
                        mPrescriptionAdapter.notifyDataSetChanged();
                        if (examineBeanList.size() == 0) {
                            String str = et_indication.getText().toString().trim();
                            if (TextUtils.isEmpty(str)) {
                                title_common_layout.getXc_id_titlebar_right2_textview().setEnabled(false);
                            }
                        }
                        dismiss();
                    }
                }.show();
            }

            @Override
            public void OnEditUsageDataClickListener(View v, int position, String usage,DrugBean drugBean ) {
                if(common_flag != 1){
                    // created by songxin,date：2018-01-09,about：saveInfo,begin
                    BiUtil.saveBiInfo(CommonPrescriptionsActivity.class, "2", "128", "E00093","", false);
                    // created by songxin,date：2018-01-09,about：saveInfo,end
                }
                editPosition = position;
                drugBean.setEditUsage(true);
                UsageActivityV2.launch(mContext, examineBeanList.get(editPosition), CommonConfig.ALL_MEDICINE_FLAG_2, commonPrescStr);
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }

    /**
     * 是否可以保存常用处方
     *
     * @return
     */
    private boolean isSave() {
        String str = et_indication.getText().toString().trim();
        boolean diagnoseVary = true;
        if(oriDiagnose.equals("无")){
            if(TextUtils.isEmpty(str) || "无".equals(str)){
                diagnoseVary = true;
            }else {
                diagnoseVary = false;
            }
        }else{
            diagnoseVary = str.equals(oriDiagnose);
        }
        boolean boo = (oriBeanList.size() == examineBeanList.size());
        boolean change = isDrugListChange();
        if (!diagnoseVary || !boo || !isUsage || !change) {
            return true;
        }
        return false;
    }

    /**
     * 药品列表数据是否发生改变
     */
    private boolean isDrugListChange(){
        boolean isLauchEdit = true;
        if(oriBeanList.size() > 0 && examineBeanList.size()> 0 && (oriBeanList.size() == examineBeanList.size())){
            for(int i = 0; i<oriBeanList.size();i++){
                isLauchEdit = oriBeanList.get(i).getName().equals(examineBeanList.get(i).getName())
                        && oriBeanList.get(i).getMedicineUsageBean().getUsages().equals(examineBeanList.get(i).getMedicineUsageBean().getUsages())
                        && oriBeanList.get(i).getMedicineUsageBean().getQuantity().equals(examineBeanList.get(i).getMedicineUsageBean().getQuantity())
                        && oriBeanList.get(i).getMedicineUsageBean().getBakUp().equals(examineBeanList.get(i).getMedicineUsageBean().getBakUp());
                if(!isLauchEdit){
                    return false;
                }
            }
        }
        return isLauchEdit;
    }

    /**
     * 初始化获取数据
     */
    private void getData(int lauch, Intent intent) {
        common_flag = getIntent().getIntExtra(COMMONPRESCRIPTION_INTER,0);
        commonPrescStr = getIntent().getStringExtra(COMMONPRESCRIPTION);
        if ("0".equals(commonPrescStr)) {
            if (lauch == 0) {
                recipeBean = (RecipeBean) getIntent().getSerializableExtra(RECIPE_INFO);
                if (recipeBean == null) {
                    recipeBean = new RecipeBean();
                }
            } else {
                mDrugBean = (DrugBean) intent.getSerializableExtra(UsageActivityV2.DRUG_INFO);
                recipeBean = RecomMedicineHelper.getInstance().getCommonRecipe();
                if (recipeBean == null) {
                    recipeBean = new RecipeBean();
                }
                ArrayList<DrugBean> drugBeans = new ArrayList<>();
                drugBeans.addAll(recipeBean.getDrugBeans());
                drugBeans.add(mDrugBean);
                recipeBean.setDrugBeans(drugBeans);
            }
            RecomMedicineHelper.getInstance().setCommonRecipe(recipeBean);
        } else if ("1".equals(commonPrescStr)) {
            if (lauch == 0) {
                recipeBean = (RecipeBean) getIntent().getSerializableExtra(RECIPE_INFO);
                oriBeanList.clear();
                oriBeanList.addAll(recipeBean.getDrugBeans());
            } else {
                mDrugBean = (DrugBean) intent.getSerializableExtra(UsageActivityV2.DRUG_INFO);
                recipeBean = RecomMedicineHelper.getInstance().getCommonRecipe();
                ArrayList<DrugBean> drugBeans = new ArrayList<>();
                drugBeans.addAll(recipeBean.getDrugBeans());
                drugBeans.add(mDrugBean);
                recipeBean.setDrugBeans(drugBeans);
            }
            RecomMedicineHelper.getInstance().setCommonRecipe(recipeBean);
        }
        if (recipeBean.getDiagnosisList() != null) {
            diagnosisList = (ArrayList<DiagnoseBean>) recipeBean.getDiagnosisList();
        }
        examineBeanList.clear();
        examineBeanList.addAll(recipeBean.getDrugBeans());
        initData(lauch);
    }

    /**
     * 初始化数据
     */
    private void initData(int lauch) {
        if(common_flag == 1){
            prescription_lv.setPadding(0, 0, 0, UtilScreen.dip2px(mContext, 50));
        }else {
            String titleRight = title_common_layout.getXc_id_titlebar_right2_textview().getText().toString().trim();
            if("保存".equals(titleRight)){
                prescription_lv.setPadding(0, 0, 0, UtilScreen.dip2px(mContext, 50));
            }else {
                prescription_lv.setPadding(0, 0, 0, UtilScreen.dip2px(mContext, 60));
            }
        }
        setDiagnosisText();
        if ("0".equals(commonPrescStr)) {
            iv_add.setVisibility(View.VISIBLE);
            line.setVisibility(View.GONE);
            tv_send.setVisibility(View.GONE);
            title_common_layout.setTitleRight2(true, 0, "保存");
            String str = et_indication.getText().toString().trim();
            if (TextUtils.isEmpty(str) && examineBeanList.size() == 0) {
                title_common_layout.getXc_id_titlebar_right2_textview().setEnabled(false);
            } else {
                title_common_layout.getXc_id_titlebar_right2_textview().setEnabled(true);
            }
            if(lauch == 1){
                mPrescriptionAdapter.showEdtLinearLayout();
            }
        } else if ("1".equals(commonPrescStr)) {
            if (lauch == 1) {
                isEdit = false;
                title_common_layout.setTitleRight2(true, 0, "保存");
                String commonStr = et_indication.getText().toString().trim();
                if (!TextUtils.isEmpty(commonStr) || examineBeanList.size() > 0) {
                    title_common_layout.getXc_id_titlebar_right2_textview().setEnabled(true);
                }
                mPrescriptionAdapter.showEdtLinearLayout();
                et_indication.setEnabled(true);
                iv_add.setVisibility(View.VISIBLE);
                line.setVisibility(View.GONE);
                tv_send.setVisibility(View.GONE);
                return;
            }
            iv_add.setVisibility(View.GONE);
            if(common_flag == 1){
                line.setVisibility(View.GONE);
                tv_send.setVisibility(View.GONE);
            }else {
                line.setVisibility(View.VISIBLE);
                tv_send.setVisibility(View.VISIBLE);
            }
            title_common_layout.setTitleRight2(true, 0, "编辑");
            et_indication.setEnabled(false);
            String str = et_indication.getText().toString().trim();
            if(TextUtils.isEmpty(str)){
                et_indication.setText("无");
            }
        }
        mPrescriptionAdapter.notifyDataSetChanged();
        oriDiagnose = et_indication.getText().toString().trim();
    }

    /**
     * 设置临床诊断
     */
    private void setDiagnosisText() {
        String diagnosisStr = "";
        for (int i = 0; i < diagnosisList.size(); i++) {
            if (i == diagnosisList.size() - 1) {
                diagnosisStr = diagnosisStr + diagnosisList.get(i).name;
            } else {
                diagnosisStr = diagnosisStr + diagnosisList.get(i).name + ",";
            }
        }
        et_indication.setText(diagnosisStr);
    }

    /**
     * 新建常用处方
     */
    private void addPrescription() {
        RequestParams params = new RequestParams();
        String str = UtilIMCreateJson.createCommonPrescriptionJson(recipeBean);
        params.put("commonPrescription", str);
        XCHttpAsyn.postAsync(true, true, mContext, AppConfig.getHostUrl(AppConfig.addCommonPrescription + "?doctorId=" + UtilSP.getUserId() +
                "&token=" + UtilSP.getUserToken()), str, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    RecomMedicineHelper.getInstance().setCommonRecipe(null);
                    RecomMedicineHelper.getInstance().setUpdateCommonRecipe(true);
                    finish();
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 更新常用处方
     */
    private void updatePrescription(final String diagnose) {
        RequestParams params = new RequestParams();
        final String str = UtilIMCreateJson.createCommonPrescriptionJson(recipeBean);
        params.put("commonPrescription", str);
        XCHttpAsyn.postAsync(true, true, mContext, AppConfig.getHostUrl(AppConfig.updateCommonPrescription + "?doctorId=" + UtilSP.getUserId() +
                "&token=" + UtilSP.getUserToken()), str, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    isUsage = true;
                    title_common_layout.setTitleRight2(true, 0, "编辑");
                    isEdit = true;
                    mPrescriptionAdapter.hideEdtLinearLayout();
                    if(common_flag == 1){
                        line.setVisibility(View.GONE);
                        tv_send.setVisibility(View.GONE);
                        prescription_lv.setPadding(0, 0, 0, UtilScreen.dip2px(mContext, 50));
                    }else {
                        line.setVisibility(View.VISIBLE);
                        tv_send.setVisibility(View.VISIBLE);
                        prescription_lv.setPadding(0, 0, 0, UtilScreen.dip2px(mContext, 60));
                    }
                    iv_add.setVisibility(View.GONE);
                    et_indication.setEnabled(false);
                    if(TextUtils.isEmpty(diagnose)){
                        et_indication.setText("无");
                        oriDiagnose = "无";
                    }else {
                        oriDiagnose = diagnose;
                    }
                    RecomMedicineHelper.getInstance().setUpdateCommonRecipe(true);
                    oriBeanList.clear();
                    oriBeanList.addAll(examineBeanList);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.indication_edt:
                DrCaseVOBean drCaseVOBean = new DrCaseVOBean();
                drCaseVOBean.setDoctorId(UtilSP.getUserId());
                drCaseVOBean.setDepartment(UtilSP.getFirstDepartmentName());
                if(common_flag!=1&&RecomMedicineHelper.getInstance().getXC_patientDrugInfo()!=null){
                    XC_PatientDrugInfo xc_patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
                    if(UtilSP.isRecordRecom()){
                        DrCaseVOBean drCaseVOBean1 = (DrCaseVOBean) xc_patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO();
                        drCaseVOBean.setPresentDisease(drCaseVOBean1.getPresentDisease());
                        drCaseVOBean.setGender(drCaseVOBean1.getGender());
                        drCaseVOBean.setAge(drCaseVOBean1.getAge());
                        drCaseVOBean.setAgeUnit(drCaseVOBean1.getAgeUnit());
                        drCaseVOBean.setPastHistory(drCaseVOBean1.getPastHistory());
                        drCaseVOBean.setTemperature(drCaseVOBean1.getTemperature());
                        drCaseVOBean.setWeight(drCaseVOBean1.getWeight());
                        drCaseVOBean.setHeartRete(drCaseVOBean1.getHeartRete());
                        drCaseVOBean.setSystolic(drCaseVOBean1.getSystolic());
                        drCaseVOBean.setDiastole(drCaseVOBean1.getDiastole());
                    }else {
                        drCaseVOBean.setPatientId(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getChatModel().getUserPatient().getPatientId());
                        drCaseVOBean.setGender(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getRecommendInfo().getPatientGender());
                        drCaseVOBean.setAge(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getRecommendInfo().getPatientAge());
                        drCaseVOBean.setAgeUnit(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getRecommendInfo().getPatientAgeUnit());
                    }
                }
                NativeHtml5.drCaseVOBean = drCaseVOBean;
                startActivityForResult(DiagnoseActivity.newIntent(this, diagnosisList), REQUEST_CODE_DIAGNOSE);
                overridePendingTransition(R.anim.activity_open_up, R.anim.activity_no_move);
                break;
            case R.id.ym_ordonnance_medicines_add:
                ToJumpHelp.toJumpAllMedicineClassActivity(CommonPrescriptionsActivity.this, common_flag, commonPrescStr);
                break;
            case R.id.tv_send:
                if (RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size() > 0 || RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getDiagnoseBeanList().size()>0) {
                    showOverRecipeDialog();
                } else {//替换药箱里的数据
                    RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setList
                            (examineBeanList);
                    RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setDiagnoseBeanList
                            (diagnosisList);
                    RecomMedicineHelper.getInstance().getXC_patientDrugInfo()
                            .setCheckInventoryInfo(true);
                    SQ_RecommendActivity.launch(this);
                }
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_DIAGNOSE) {
                diagnosisList = (ArrayList<DiagnoseBean>) data.getSerializableExtra(DiagnoseActivity.INTENT_KEY_DIAGNOSIS);
                setDiagnosisText();
                recipeBean.setDiagnosisList(diagnosisList);
                if (diagnosisList.size() > 0 || examineBeanList.size() > 0) {
                    title_common_layout.getXc_id_titlebar_right2_textview().setEnabled(true);
                }else {
                    title_common_layout.getXc_id_titlebar_right2_textview().setEnabled(false);
                }
            } else if (requestCode == UsageActivityV2.REQUEST_CODE_USAGE) {
                DrugBean drugBean = (DrugBean) data.getSerializableExtra(UsageActivityV2.DRUG_INFO);
                String usage = drugBean.getMedicineUsageBean().getUsages();
                String bakup = drugBean.getMedicineUsageBean().getBakUp();
                String quantity = drugBean.getMedicineUsageBean().getQuantity();
                if (editPosition != -1) {
                    if (examineBeanList.get(editPosition) != null) {
                        examineBeanList.remove(editPosition);
                        examineBeanList.add(editPosition, drugBean);
                    }
                }
                recipeBean.setDrugBeans(examineBeanList);
                mPrescriptionAdapter.notifyDataSetChanged();
                isUsage = examineBeanList.get(editPosition).getMedicineUsageBean().getUsages().equals(usage)
                        && examineBeanList.get(editPosition).getMedicineUsageBean().getQuantity().equals(quantity)
                        && examineBeanList.get(editPosition).getMedicineUsageBean().getBakUp().equals(bakup);
            }else if(requestCode == SafeMedicationActivity.REQUEST_CODE_SAFE_MEDICATION){
                if ("0".equals(commonPrescStr)) {
                    addPrescription();
                }else if("1".equals(commonPrescStr)){
                    updatePrescription(et_indication.getText().toString().trim());
                }
            }
        }
    }

    /**
     * 返回常用处方列表界面
     */
    private void backCommonPrescriptionList() {
        if ("0".equals(commonPrescStr)) {
            String str = et_indication.getText().toString().trim();
            if (!TextUtils.isEmpty(str) || examineBeanList.size() > 0) {
                new YR_CommonDialog(mContext, "退出常用处方编辑，编辑内容将不做保存，您确定退出吗？", "取消", "退出") {
                    @Override
                    public void confirmBtn() {
                        RecomMedicineHelper.getInstance().setCommonRecipe(null);
                        finish();
                        dismiss();
                    }
                }.show();
            } else {
                RecomMedicineHelper.getInstance().setCommonRecipe(null);
                finish();
            }
        } else if ("1".equals(commonPrescStr)) {
            if (!isSave()) {
                RecomMedicineHelper.getInstance().setCommonRecipe(null);
                finish();
                return;
            }
            new YR_CommonDialog(mContext, "退出常用处方编辑，编辑内容将不做保存，您确定退出吗？", "取消", "退出") {
                @Override
                public void confirmBtn() {
                    RecomMedicineHelper.getInstance().setCommonRecipe(null);
                    finish();
                    dismiss();
                }
            }.show();
        }else {
            RecomMedicineHelper.getInstance().setCommonRecipe(null);
            finish();
        }
    }

    /**
     *  编辑保存状态切换
     */
    private void switchEditState(){
        if ("0".equals(commonPrescStr)) {
            String str = et_indication.getText().toString().trim();
            if (TextUtils.isEmpty(str) && examineBeanList.size() == 0) {
                finish();
            } else {
                if(UtilSP.isRecomSafe()){
                    requestSafeMedication();
                }else {
                    addPrescription();
                }
            }
        } else if ("1".equals(commonPrescStr)) {
            if (isEdit) {
                title_common_layout.setTitleRight2(true, 0, "保存");
                isEdit = false;
                mPrescriptionAdapter.showEdtLinearLayout();
                line.setVisibility(View.GONE);
                tv_send.setVisibility(View.GONE);
                iv_add.setVisibility(View.VISIBLE);
                prescription_lv.setPadding(0, 0, 0, UtilScreen.dip2px(mContext, 50));
                et_indication.setEnabled(true);
                String str = et_indication.getText().toString().trim();
                if("无".equals(str)){
                    et_indication.setText("");
                }
            } else {
                if(common_flag == 1){
                    // created by songxin,date：2018-01-09,about：saveInfo,begin
                    BiUtil.saveBiInfo(CommonPrescriptionsActivity.class, "2", "128", "E00105","", false);
                    // created by songxin,date：2018-01-09,about：saveInfo,end
                }else {
                    // created by songxin,date：2018-01-09,about：saveInfo,begin
                    BiUtil.saveBiInfo(CommonPrescriptionsActivity.class, "2", "128", "E00100","", false);
                    // created by songxin,date：2018-01-09,about：saveInfo,end
                }
                String str = et_indication.getText().toString().trim();
                if (isSave()) {
                    if(UtilSP.isRecomSafe()){
                        requestSafeMedication();
                    }else {
                        updatePrescription(str);
                    }
                }else {
                    title_common_layout.setTitleRight2(true, 0, "编辑");
                    isEdit = true;
                    mPrescriptionAdapter.hideEdtLinearLayout();
                    if(common_flag == 1){
                        line.setVisibility(View.GONE);
                        tv_send.setVisibility(View.GONE);
                        prescription_lv.setPadding(0, 0, 0, UtilScreen.dip2px(mContext, 50));
                    }else {
                        line.setVisibility(View.VISIBLE);
                        tv_send.setVisibility(View.VISIBLE);
                        prescription_lv.setPadding(0, 0, 0, UtilScreen.dip2px(mContext, 60));
                    }
                    iv_add.setVisibility(View.GONE);
                    et_indication.setEnabled(false);
                    if(TextUtils.isEmpty(str)){
                        et_indication.setText("无");
                    }
                }
            }
        }
    }

    /**
     * 请求安全用药提醒
     */
    public void requestSafeMedication(){

        JSONObject data = new JSONObject();
        try {
            XC_PatientDrugInfo patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
            data.put("patientAge", patientDrugInfo.getRecommendInfo().getPatientAge());
            data.put("patientAgeUnit", patientDrugInfo.getRecommendInfo().getPatientAgeUnit());
            data.put("patientGender", patientDrugInfo.getRecommendInfo().getPatientGender());

            JSONArray diagnosis = new JSONArray();
            for (DiagnoseBean bean : diagnosisList) {
                diagnosis.put(bean.name);
            }
            data.put("diagnosis", diagnosis);
            JSONArray skuIds = new JSONArray();
            for (DrugBean item : examineBeanList) {
                skuIds.put(item.getSkuId());
            }
            data.put("skuIds", skuIds);
            if(null != patientDrugInfo.getChatModel()){
                UserPatient userPatient = patientDrugInfo.getChatModel().getUserPatient();
                data.put("patientId", userPatient.getPatientId());
            }

            DrRecordVOBean drRecordVOBean = patientDrugInfo.getDrRecordVOBean();
            if(drRecordVOBean != null) {
                DrCaseVOBean mDrCaseVOBean = (DrCaseVOBean) drRecordVOBean.getMdicalRecordVO();
                if(mDrCaseVOBean != null){
                    data.put("mainComplaint",mDrCaseVOBean.getMainComplaint());
                    data.put("presentDisease",mDrCaseVOBean.getPresentDisease());
                }
            }
            JSONArray recomSafeItems = new JSONArray();
            JSONObject drugItem;
            for (DrugBean item : examineBeanList){
                drugItem = new JSONObject();
                drugItem.put("commonName",item.getCommonName());
                drugItem.put("productName", item.getName());
                drugItem.put("recomName", item.getRecomName());
                drugItem.put("quantity",item.getMedicineUsageBean().getQuantity());
                drugItem.put("skuId",item.getMedicineUsageBean().getSkuId());
                recomSafeItems.put(drugItem);
            }
            data.put("recomSafeItems", recomSafeItems);
        } catch (Exception e) {
            e.printStackTrace();
            XCApplication.base_log.debugShortToast("创建json异常");
        }

        // 发送请求
        XCHttpAsyn.postAsync(true,this,AppConfig.getTuijianUrl(AppConfig.recomCheck+ "?doctorId="+UtilSP.getUserId()+
                "&token="+UtilSP.getUserToken()),data.toString(),new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean && context != null){
                    try {
                        Parse2SafeMedication parse2SafeMedication = new Parse2SafeMedication();
                        SafeMedicationBean safeMedicationBean = parse2SafeMedication.parse(result_bean.getList("data").get(0));
                        if("3".equals(safeMedicationBean.getSafeStatus())){ // 通过
                            if ("0".equals(commonPrescStr)) {
                                addPrescription();
                            }else if("1".equals(commonPrescStr)){
                                updatePrescription(et_indication.getText().toString().trim());
                            }
                        }else if("2".equals(safeMedicationBean.getSafeStatus())){ // 谨慎
                            // 若两次提醒一致
                            if(safeMedicationBean.getSn().equals(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getSn())){
                                if ("0".equals(commonPrescStr)) {
                                    addPrescription();
                                }else if("1".equals(commonPrescStr)){
                                    updatePrescription(et_indication.getText().toString().trim());
                                }
                                return;
                            }
                            // 设置安全提醒的按钮为 仍然保存
                            safeMedicationBean.setBtnTextTag(1);
                            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setSn(safeMedicationBean.getSn());
                            SafeMedicationActivity.launch(CommonPrescriptionsActivity.this,safeMedicationBean);
                        }else if("1".equals(safeMedicationBean.getSafeStatus())){ // 禁用
                            SafeMedicationActivity.launch(CommonPrescriptionsActivity.this,safeMedicationBean);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                GeneralReqExceptionProcess.checkCode(context,getCode(),getMsg());
            }
        });
    }


    /**
     * 显示覆盖处方的对话框
     */
    private void showOverRecipeDialog() {
        if (mOverRecipeDialog == null) {
            mOverRecipeDialog = new YR_CommonDialog(mContext,
                    "当前已有编辑中的处方，使用“使用处方”功能将覆盖当前编辑中的处方，是否继续？", "取消", "继续") {
                @Override
                public void confirmBtn() {
                    RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setList(examineBeanList);
                    RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setDiagnoseBeanList
                            (diagnosisList);
                    RecomMedicineHelper.getInstance().getXC_patientDrugInfo()
                            .setCheckInventoryInfo(true);
                    SQ_RecommendActivity.launch(mContext);
                    dismiss();
                }
            };
            mOverRecipeDialog.setCanceledOnTouchOutside(false);
        }
        mOverRecipeDialog.show();
    }

    @Override
    public void onBackPressed() {
        backCommonPrescriptionList();
    }
}
