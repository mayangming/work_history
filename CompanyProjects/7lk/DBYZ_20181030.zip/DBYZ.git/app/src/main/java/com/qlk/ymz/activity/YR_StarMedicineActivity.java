package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.SK_MedicineClassificationBModel;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by smile on 2017/12/18.
 * 明星药品页面
 */

public class YR_StarMedicineActivity extends DBActivity {
    /** 标题布局 */
    private XCTitleCommonLayout xcTitleCommonLayout;
    /** 搜索药品布局 */
    private LinearLayout sk_id_medicine_search;
    /** 页面标题内容 */
    private String title = "明星药品";
    /** 明星药品 */
    private GridView gv_medicine_type;
    /** 处方笺入口 */
    private RelativeLayout rl_recipe_cart;
    /** 处方笺数字 */
    private TextView tv_medicine_num;
    /** 处方笺数字布局 */
    private LinearLayout ll_medicine_num;

    /** 明星药品适配器 */
    private StarMedicineAdapter starMedicineAdapter;
    /** 明星药品列表 */
    private ArrayList<SK_MedicineClassificationBModel>  starMedicineList = new ArrayList<>();

    /** 进入页标识 */
    private int flag;
    /** 处方药品数量 (数据里读)*/
    private int num;

    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yr_activity_star_medicine);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_StarMedicineActivity.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */


    @Override
    public void initWidgets() {


        starMedicineList = (ArrayList<SK_MedicineClassificationBModel>) getIntent().getSerializableExtra(SK_MedicineClassificationResultActivity.CLASSIFICATIONRESULT_KEY);
        flag = getIntent().getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,0);

        sk_id_medicine_search = getViewById(R.id.sk_id_medicine_search);
        xcTitleCommonLayout = getViewById(R.id.xc_id_model_titlebar);
        xcTitleCommonLayout.setTitleCenter(true, title);
        xcTitleCommonLayout.setTitleLeft(true, null);

        rl_recipe_cart = getViewById(R.id.rl_recipe_cart);
        tv_medicine_num = getViewById(R.id.tv_medicine_num);
        ll_medicine_num = getViewById(R.id.ll_medicine_num);

        //显示处方笺按钮
        if (flag == 2) {
            rl_recipe_cart.setVisibility(View.VISIBLE);
        } else {
            rl_recipe_cart.setVisibility(View.GONE);
        }

        gv_medicine_type = (GridView) findViewById(R.id.gv_medicine_type);

        starMedicineAdapter = new StarMedicineAdapter(this, starMedicineList);
        gv_medicine_type.setAdapter(starMedicineAdapter);

    }

    @Override
    public void listeners() {
        sk_id_medicine_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ToJumpHelp.toJumpMedicineSearchActivity(YR_StarMedicineActivity.this,
                        flag,
                        getIntent().getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION));
            }
        });

        //跳到处方笺页面
        rl_recipe_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (num <= 0 && UtilCollection.isBlank(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getDiagnoseBeanList())) {
                    Toast.makeText(YR_StarMedicineActivity.this, "请选择药品", Toast.LENGTH_SHORT).show();
                } else {
                    SQ_RecommendActivity.launch(YR_StarMedicineActivity.this);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        //1、首次进入页面时
        //2、处方笺设置药品返回时
        try {
            num = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size();
        }catch (Exception e){
            num = 0;
        }

        tv_medicine_num.setText(num + "");
        ll_medicine_num.setVisibility(num == 0 ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onNetRefresh() {

    }

    class StarMedicineAdapter extends XCBaseAdapter<SK_MedicineClassificationBModel> {

        public StarMedicineAdapter(Context context, List<SK_MedicineClassificationBModel> list) {
            super(context, list);
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (convertView ==null) {
                convertView = LayoutInflater.from(YR_StarMedicineActivity.this).inflate(R.layout.yr_item_secondmedicinetype,null);
                viewHolder = new ViewHolder();

                viewHolder.tv_medicineName = (TextView) convertView.findViewById(R.id.tv_medicineName);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            viewHolder.tv_medicineName.setText(list.get(position).getName());

            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(YR_StarMedicineActivity.this, SK_MedicineClassificationResultActivity.class);
                    intent.putExtra(SK_MedicineClassificationResultActivity.CLASSIFICATIONRESULT_KEY, list.get(position));
                    intent.putExtra(YR_AllMedicineClassActivity.INTER_FLAG, flag);
                    intent.putExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION, getIntent().getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION));
                    myStartActivity(intent);
                }
            });
            return convertView;
        }

        class ViewHolder {
            TextView tv_medicineName;
        }
    }
}
