package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.YY_FeedbackRecordBean;
import com.qlk.ymz.util.UtilScreen;
import com.xiaocoder.android.fw.general.adapter.YYBaseExpandableListViewAdapter;

import java.util.List;

/**
 * @author shuYanYi on 2016/11/07.
 * @description 随访记录适配器
 */
public class YY_FeedbackRecordAdapter extends YYBaseExpandableListViewAdapter<YY_FeedbackRecordBean.DataBean.ResultBean,
                                                                              YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean> {

    public YY_FeedbackRecordAdapter(Context context, List<YY_FeedbackRecordBean.DataBean.ResultBean> list) {
        super(context, list);
    }

    @Override
    public List<YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean> getChildList(int groupPosition) {
        try {
            return list.get(groupPosition).getVisitInfoInMonth();
        } catch (Exception e) {
            return null;
        }
    }



    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupViewHolder holder = null;
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.yy_item_feedback_record_group,null);
            holder = new GroupViewHolder(convertView);
            convertView.setTag(holder);
        }else{
            holder = (GroupViewHolder) convertView.getTag();
        }
        groupBean = getGroup(groupPosition);
        holder.tv_year_month.setText(groupBean.getVisitMonth());
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        ChildViewHolder holder = null;
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.yy_item_feedback_record,null);
            holder = new ChildViewHolder(convertView);
            convertView.setTag(holder);
        }else{
            holder = (ChildViewHolder) convertView.getTag();
        }
        childBean = getChild(groupPosition,childPosition);
        holder.tv_day.setText(childBean.getVisitDate());
        //不同患者的回访信息
        List visitInfo = childBean.getVisitInfo();
        if(visitInfo != null && visitInfo.size() > 0){
            int infoCount = childBean.getVisitInfo().size();
            //设置高度item+分割线2dp=82dp 减少getview的重绘问题
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) holder.lv_visit_info.getLayoutParams();
            lp.height = infoCount * UtilScreen.dip2px(context,82f);
            if(holder.infoAdapter == null){
                holder.infoAdapter = new YY_FeedbackRecordInfoAdapter(context,visitInfo);
                holder.lv_visit_info.setAdapter(holder.infoAdapter);
            }else{
                holder.infoAdapter.update(visitInfo);
                holder.infoAdapter.notifyDataSetChanged();
            }

            //患者随访详情选项卡点击
            holder.lv_visit_info.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if(onVisitInfoClickListener != null){
                        YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean.VisitInfoBean visitInfoBean = (YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean.VisitInfoBean)parent.getItemAtPosition(position);
                        onVisitInfoClickListener.onClick(visitInfoBean);
                    }
                }
            });
        }

        //最后一组，最后一子项，底部水平线不显示
        if(groupPosition == getGroupCount()-1 && childPosition == getChildrenCount(groupPosition)-1){
            holder.v_bottom_line.setVisibility(View.GONE);
        }

        return convertView;
    }



    private class GroupViewHolder {
        /** 年月标题*/
        private TextView tv_year_month;
        public GroupViewHolder(View convertView){
            tv_year_month = (TextView)convertView.findViewById(R.id.tv_year_month);
        }
    }

    private class ChildViewHolder {
        /** 日*/
        private TextView tv_day;
        /** 当日多个患者的随访记录列表*/
        private ListView lv_visit_info;
        /** 患者问题列表适配器*/
        private  YY_FeedbackRecordInfoAdapter infoAdapter;
        /** 底部水平线*/
        private  View v_bottom_line;
        public ChildViewHolder(View convertView){
            tv_day = (TextView)convertView.findViewById(R.id.tv_day);
            lv_visit_info = (ListView)convertView.findViewById(R.id.lv_visit_info);
            v_bottom_line = convertView.findViewById(R.id.v_bottom_line);
        }
    }

    /**
     * 患者随访详情选项卡点击
     */
    public interface OnVisitInfoClickListener{
        void onClick(YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean.VisitInfoBean visitInfoBean);
    }

    private OnVisitInfoClickListener onVisitInfoClickListener;

    public void setOnVisitInfoClickListener(OnVisitInfoClickListener onVisitInfoClickListener) {
        this.onVisitInfoClickListener = onVisitInfoClickListener;
    }
}
