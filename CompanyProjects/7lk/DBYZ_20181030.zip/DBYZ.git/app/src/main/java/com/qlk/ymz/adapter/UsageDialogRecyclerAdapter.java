package com.qlk.ymz.adapter;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;

import java.util.List;

/**
 * Recycler列表适配器
 */
public class UsageDialogRecyclerAdapter extends RecyclerView.Adapter<UsageDialogRecyclerAdapter.UsageDialogViewHolder> {
    List<String> list;
    OnItemClickListener onItemClickListener;
    int lastPosition = -1;
    String defItem;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public UsageDialogViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new UsageDialogViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_usage_dialog, parent, false));
    }

    @Override
    public void onBindViewHolder(UsageDialogViewHolder holder, final int position) {

        if(defItem.equals(list.get(position))){
            holder.content_tv.setBackgroundResource(R.drawable.sk_dd_line_red_e2231a_bg_red_e2231a_3);
            holder.content_tv.setTextColor(Color.parseColor("#ffffff"));
            lastPosition = position;
        }else {
            holder.content_tv.setTextColor(Color.parseColor("#444444"));
            holder.content_tv.setBackgroundResource(R.drawable.sk_dd_line_gray_e5e5e5_bg_white_f6f6f6_3);

        }
        holder.content_tv.setTag(list.get(position));
        holder.content_tv.setText("" + list.get(position));
        holder.content_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onItemClickListener != null) onItemClickListener.onItemClick(view,lastPosition,position);
                lastPosition = position;
            }
        });


    }

    public String getCurrentText() {
        return defItem;
    }

    public int getLastPosition() {
        return lastPosition;
    }

    public void clearLastPosition(){
        lastPosition = -1;
    }

    public void updateAndNotify(List<String> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    public void checkItem(String item){
        defItem = item;
    }

    @Override
    public int getItemCount() {
        if (list != null) return list.size();
        return 0;
    }

    public interface OnItemClickListener {
        void onItemClick(View view,int lastPosition,int currentPosition);
    }

    public class UsageDialogViewHolder extends RecyclerView.ViewHolder {
        public TextView content_tv;

        public UsageDialogViewHolder(View itemView) {
            super(itemView);
            content_tv = (TextView) itemView.findViewById(R.id.content_tv);

        }
    }
}