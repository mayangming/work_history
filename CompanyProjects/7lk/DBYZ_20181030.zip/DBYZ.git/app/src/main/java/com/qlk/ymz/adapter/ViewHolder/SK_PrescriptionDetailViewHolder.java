package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * @author 赖善琦
 * @description 处方单详情viewholder
 */
public class SK_PrescriptionDetailViewHolder {
    public TextView tv_item_prescription_drugName;
    public TextView tv_item_prescription_drugNum;
    public TextView tv_item_prescription_drugUsage;
    public TextView tv_item_safe_dosage;
    public TextView tv_medicine_limit_time;
    public View v_line;

    public SK_PrescriptionDetailViewHolder(View convertView){
        tv_item_prescription_drugName = (TextView)convertView.findViewById(R.id.tv_item_prescription_drugName);
        tv_item_prescription_drugNum = (TextView)convertView.findViewById(R.id.tv_item_prescription_drugNum);
        tv_item_prescription_drugUsage = (TextView)convertView.findViewById(R.id.tv_item_prescription_drugUsage);
        tv_item_safe_dosage = convertView.findViewById(R.id.tv_item_safe_dosage);
        tv_medicine_limit_time = (TextView)convertView.findViewById(R.id.tv_medicine_limit_time);
        v_line = convertView.findViewById(R.id.v_line);
    }

}
