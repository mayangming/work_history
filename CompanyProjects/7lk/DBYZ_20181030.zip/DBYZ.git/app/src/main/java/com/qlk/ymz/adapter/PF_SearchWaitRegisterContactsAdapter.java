package com.qlk.ymz.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.PF_WaitRegisterContactSearchActivity;
import com.qlk.ymz.activity.PF_WaitRegisterContactsDetailActivity;
import com.qlk.ymz.model.PF_WaitRegisterContactsInfo;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.UtilAppToSystemApp;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;

/**
 * 搜索等待注册联系人结果adapter
 * @author zhangpengfei
 * @version 2.5.0
 */
public class PF_SearchWaitRegisterContactsAdapter extends XCBaseAdapter<PF_WaitRegisterContactsInfo> {

    public PF_SearchWaitRegisterContactsAdapter(Context context, List<PF_WaitRegisterContactsInfo> list){
        super(context, list);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(null == convertView){
            convertView = LayoutInflater.from(context).inflate(R.layout.pf_item_wait_register_contact,null);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)convertView.getTag();
        }
        if (null != list && null != list.get(position)){
            final PF_WaitRegisterContactsInfo contactModel = list.get(position);
            viewHolder.pf_id_item_contact_name.setText(UtilString.f(contactModel.getName()));
            viewHolder.pf_id_item_contact_again_invitation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // created by songxin,date：2016-4-25,about：saveInfo,begin
                    BiUtil.saveBiInfo(PF_WaitRegisterContactsDetailActivity.class,"2","128","pf_id_item_contact_again_invitation","",false);
                    // created by songxin,date：2016-4-25,about：saveInfo,end
                    sendSMS(contactModel.getPhone());
                }
            });
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, PF_WaitRegisterContactsDetailActivity.class);
                    intent.putExtra(PF_WaitRegisterContactsDetailActivity.CONTACTS_DETAIL, contactModel);
                    if (context instanceof XCBaseActivity){
                        ((XCBaseActivity)context).myStartActivity(intent);
                    }
                }
            });
        }
        return convertView;
    }

    static class ViewHolder{
        /**姓名*/
        private TextView pf_id_item_contact_name;
        /**电话*/
        private TextView pf_id_item_contact_again_invitation;
        public ViewHolder(View convertView){

            pf_id_item_contact_name = (TextView)convertView.findViewById(R.id.pf_id_item_contact_name);
            pf_id_item_contact_again_invitation = (TextView)convertView.findViewById(R.id.pf_id_item_contact_again_invitation);

        }
    }
    /**
     * 发送短信
     * @param phone 电话
     */
    private void sendSMS(String phone){
        if(UtilString.isBlank(GlobalConfigSP.getInvitedMsg())){
            Toast.makeText(context, "网络出了点问题，请稍后再试", Toast.LENGTH_SHORT).show();
            if (context instanceof PF_WaitRegisterContactSearchActivity){
                ((PF_WaitRegisterContactSearchActivity)context).requestContactsSMSModel();//再次请求短信模板，待用户下次点击
            }
            return;
        }
        UtilAppToSystemApp.toSendSMS(context, phone, GlobalConfigSP.getInvitedMsg());
    }
}
