package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.loopj.android.http.RequestParams;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.YR_CashHistoryBeanV2;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.adapter.XLAbsBaseExpandableListViewAdapter;
import com.xiaocoder.android.fw.general.base.XLBaseAbsExpandListFragment;
import com.xiaocoder.android.fw.general.fragment.XLExpandListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

import static com.qlk.ymz.R.id.child_income;
import static com.qlk.ymz.R.id.child_state;
import static com.qlk.ymz.R.id.child_time;
import static com.qlk.ymz.R.id.group;

/**
 * @version 2.0
 * @Created by xilinch on 2016/1/12.
 * @description 提现记录列表
 *
 * @version 2.3
 * @author cyr on 2016/4/19
 * @description 非步长医生添加提现记录页
 *
 * TODO update by cyr on 2017-1-9 修改PointInfoBean结构，及parse解析方式
 */
public class XL_CashBackListActivityV2 extends DBActivity {
    /** titlebar */
    private XCTitleCommonLayout titlebar;
    /** 通用可收缩列表 */
    private XLExpandListViewFragment expandListViewFragment;
    // ********************变量********************
    /**  适配器*/
    private MyExpandAdapter myExpandAdapter;
    /** 组数据集合 */
    private List<String> groupData = new ArrayList<>();
    /** 子数据集合 */
    private List<List<YR_CashHistoryBeanV2.DataEntity.ResultEntity.ListEntity>> childData = new ArrayList<>();
    // ********************变量 end********************

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xl_activity_point_cashedback_list);
        super.onCreate(savedInstanceState);
    }


    @Override
    public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, getString(R.string.points_cashed_history_titile));
        titlebar.setTitleLeft(true, "");
        expandListViewFragment = new XLExpandListViewFragment();
        expandListViewFragment.setBgZeroHintInfo("您当前还没有提现记录~", "", R.mipmap.xl_no_cashlist_default);
        //全展开，不可收缩
        expandListViewFragment.setGroupInterceptCollapsed(true);
        expandListViewFragment.setMode(XLBaseAbsExpandListFragment.MODE_UP_DOWN);
        myExpandAdapter = new MyExpandAdapter(groupData, childData, this);
        expandListViewFragment.setAdapter(myExpandAdapter);
        addFragment(R.id.content, expandListViewFragment);
    }

    @Override
    public void listeners() {
        titlebar.getXc_id_titlebar_left_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });

        expandListViewFragment.OnBgZeroTextViewClickToDoListener(new XLBaseAbsExpandListFragment.OnBgZeroTextViewClickToDoListener() {
            @Override
            public void onBgZeroButtonClickToDo() {
                //请求第一页数据
                requestData(1);
            }
        });

        expandListViewFragment.setOnRefreshNextPageListener(new XLBaseAbsExpandListFragment.OnRefreshNextPageListener() {
            @Override
            public void onRefreshNextPageListener(int current_page) {
                if (current_page == 1) {
                    expandListViewFragment.base_refresh_abs_listview.setMode(PullToRefreshBase.Mode.BOTH);
                }
                requestData(current_page);
            }
        });

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.xl_points_btn_call://进入手机拨号页面
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + GlobalConfigSP.getCustomerServPhone()));
                myStartActivity(intent);
                break;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        expandListViewFragment.getAbsListView().setDivider(null);
        requestData(1);

        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(XL_CashBackListActivityV2.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    @Override
    public void onNetRefresh() {
        requestData(1);
    }

    /**
     * 请求提现记录
     * @param page 请求的页数
     */
    private void requestData(final int page) {
        RequestParams params = new RequestParams();
        params.put("page", page);
        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.applyCashRecord), params, new XCHttpResponseHandler<YR_CashHistoryBeanV2>(this, YR_CashHistoryBeanV2.class) {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (!expandListViewFragment.checkGoOn()) {
                        expandListViewFragment.base_refresh_abs_listview.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
                        return;
                    }
                    List<YR_CashHistoryBeanV2.DataEntity> objLists = mResultModel.getData();
                    if (objLists != null && objLists.size() > 0) {
                        YR_CashHistoryBeanV2.DataEntity dataEntity = objLists.get(0);
                        if (dataEntity != null) {
                            //设置总页数
                            int totalPages = dataEntity.getTotalPages();
                            expandListViewFragment.setTotalPage(String.valueOf(totalPages));

                            List<YR_CashHistoryBeanV2.DataEntity.ResultEntity> resultEntityList = dataEntity.getResult();
                            //合并数据
                            renewCashBackList(resultEntityList, page);
                            //更新list
                            expandListViewFragment.updateSpecialList(groupData, childData);
                        }
                    }
                }
            }


            public void onFinish() {
                super.onFinish();
                if(expandListViewFragment != null){
                    expandListViewFragment.doRefreshComplete();
                }

                if (null != result_bean && GeneralReqExceptionProcess.checkCode(XL_CashBackListActivityV2.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 根据返回数据，进行数据合并或显示
     * @param resultEntityList 结果集合
     * @param page
     */
    private void renewCashBackList(List<YR_CashHistoryBeanV2.DataEntity.ResultEntity> resultEntityList, int page) {
        if (resultEntityList == null) {
            return;
        }
        if (page == 1) {
            //第一页，则直接显示
            groupData.clear();
            childData.clear();
        }
        //对数据进行合并操作,如果不是第一页则合并
        renewGroupDataAndChildData(resultEntityList);
    }

    /**
     * 由于数据部分需要合并不同的stage，单独处理
     * @param resultEntityList  请求页的提现历史list
     */
    private void renewGroupDataAndChildData(List<YR_CashHistoryBeanV2.DataEntity.ResultEntity> resultEntityList) {
        if (resultEntityList == null) {
            return;
        }
        int groupLast = 0;
        String groupStage = null;
        if (groupData.size() > 0) {
            groupLast = groupData.size() - 1;//获得请求前列表的最后一项位置
            groupStage = groupData.get(groupLast);//获得列表中最后一个月份
        }
        for (int i = 0; i < resultEntityList.size(); i++) {
            YR_CashHistoryBeanV2.DataEntity.ResultEntity resultEntity = resultEntityList.get(i);
            String stage = resultEntity.getStage();//获得分类月份
            if (!TextUtils.isEmpty(stage)) {
                List<YR_CashHistoryBeanV2.DataEntity.ResultEntity.ListEntity> listEntities = resultEntity.getList();
                if (listEntities != null && listEntities.size() > 0) {
                    //匹配月份，如果存储的最后一个月份和请求的月份相等，则直接添加；否则需添加group
                    if (groupStage != null && groupStage.equals(stage)) {
                        childData.get(groupLast).addAll(listEntities);
                    } else {
                        groupData.add(stage);
                        childData.add(listEntities);
                    }
                }
            }
        }
    }

    public class MyExpandAdapter extends XLAbsBaseExpandableListViewAdapter {

        private List<String> groupData;

        private List<List<YR_CashHistoryBeanV2.DataEntity.ResultEntity.ListEntity>> childData;

        private Context context;
        public ImageLoader imageloader;
        public DisplayImageOptions options;

        public MyExpandAdapter(List<String> groupData, List<List<YR_CashHistoryBeanV2.DataEntity.ResultEntity.ListEntity>> childData,Context context) {
            this.list = groupData;
            this.groupData = groupData;
            this.childData = childData;
            this.context = context;
            expandAll();

        }

        public void updateList(List list) {
            this.list = list;

            notifyDataSetChanged();
            expandAll();
        }

        private void expandAll(){
            int size  = 0;
            if(list != null){
                size = list.size();
            }
            for(int i = 0 ; i < size ; i++){
                expandListViewFragment.base_abs_listview.expandGroup(i);
            }
        }

        @Override
        public void update(List list) {
            this.list = list;
            this.groupData = list;
            notifyDataSetChanged();
            expandAll();
        }

        @Override
        public void update(List list, List childList) {
            this.list = list;
            this.childList = childList;
            this.groupData = list;
            this.childData = childList;
            notifyDataSetChanged();
            expandAll();
        }

        @Override
        public String getGroup(int i) {
            if (groupData != null) {
                return groupData.get(i);
            }
            return null;
        }

        @Override
        public int getGroupCount() {
            if (groupData != null) {
                return groupData.size();
            }
            return 0;
        }

        @Override
        public int getChildrenCount(int i) {
            if (childList != null) {

                return childData.get(i).size();
            }
            return 0;
        }

        @Override
        public YR_CashHistoryBeanV2.DataEntity.ResultEntity.ListEntity getChild(int i, int i1) {
            if (childData != null) {
                return childData.get(i).get(i1);
            }
            return null;
        }

        @Override
        public long getGroupId(int i) {
            return i;
        }

        @Override
        public long getChildId(int i, int i1) {
            return i1;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }


        @Override
        public boolean isChildSelectable(int i, int i1) {
            return true;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

            String stage = getGroup(groupPosition);
            ViewHolder holder;

            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(R.layout.xl_item_points_expandable_group, null);
                holder = new ViewHolder();
                holder.group = (TextView) convertView.findViewById(group);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            if (TextUtils.isEmpty(stage)) {
                stage = "";
            }

            // 获取和设置控件的显示值
            holder.group.setText(stage);

            return convertView;
        }

        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

            YR_CashHistoryBeanV2.DataEntity.ResultEntity.ListEntity childBean = getChild(groupPosition, childPosition);
            ChildViewHolder childViewHolder;

            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(R.layout.xl_item_points_cashedback_expandable_child, null);
                childViewHolder = new ChildViewHolder();
                childViewHolder.child_bank = (TextView) convertView.findViewById(R.id.child_bank);
                childViewHolder.child_income = (TextView) convertView.findViewById(child_income);
                childViewHolder.child_time = (TextView) convertView.findViewById(child_time);
                childViewHolder.child_state = (TextView) convertView.findViewById(child_state);
                childViewHolder.line = convertView.findViewById(R.id.line);
                childViewHolder.child_ll = (LinearLayout) convertView.findViewById(R.id.child_ll);
                convertView.setTag(childViewHolder);
            } else {
                childViewHolder = (ChildViewHolder) convertView.getTag();
            }

            // 获取和设置控件的显示值
            //设置银行卡卡号，默认取后4位
            String bankCardNum = childBean.bankCardNum;
            if (bankCardNum.length()>4) {
                bankCardNum = bankCardNum.substring(bankCardNum.length()-4,bankCardNum.length());
            }
            childViewHolder.child_bank.setText(childBean.bankName + " (尾号" + bankCardNum + ")");
            //设置显示金额，接口返回的单位（分）转为（元）
            String extraMoney = StringUtils.getMoneyString(childBean.extraMoney);//
            childViewHolder.child_income.setText(AppConfig.renminbi + " " + extraMoney);
            //设置申请时间
            childViewHolder.child_time.setText(childBean.applyTime);
            // 设置提现的审核状态描述
            childViewHolder.child_state.setText(childBean.reason);
            //设置审核状态颜色
            String stateColor = childBean.color;
            if ( TextUtils.isEmpty(stateColor)) {
                childViewHolder.child_state.setTextColor(getResources().getColor(R.color.c_blue_2b98f6));
            } else {
                try{
                    childViewHolder.child_state.setTextColor(Color.parseColor(stateColor));
                }catch (Exception e){
                    e.printStackTrace();
                    childViewHolder.child_state.setTextColor(getResources().getColor(R.color.c_blue_2b98f6));
                }
            }
            //每个group中最后一个child隐藏下划线
            childViewHolder.line.setVisibility(isLastChild?View.GONE:View.VISIBLE);

            childViewHolder.child_ll.setTag(R.id.xl_id_ll_1,childBean);
            return convertView;
        }

        class ViewHolder {
            TextView group;
        }

        class ChildViewHolder {
            TextView child_bank;
            TextView child_income;
            TextView child_time;
            TextView child_state;
            View line;
            LinearLayout child_ll;
        }

    }

}
