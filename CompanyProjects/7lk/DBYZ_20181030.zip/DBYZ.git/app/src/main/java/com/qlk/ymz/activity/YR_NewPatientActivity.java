package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.YR_NewPatientAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.NewPatientListBean;
import com.qlk.ymz.model.NewPatientModel;
import com.qlk.ymz.parse.Parse2NewPatientListBean;
import com.qlk.ymz.receiver.XC_ChatReceiver;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;
import com.xiaocoder.ptrrefresh.XCMaterialListPinRefreshLayout;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 新增患者页
 *
 * update on 2016-1-7  by cyr
 * @version 2.0
 */
public class YR_NewPatientActivity extends DBActivity {
    /** 患者列表adapter */
    private YR_NewPatientAdapter newPatientAdapter;
    /** 显示患者信息不全的对话框 */
    private YR_CommonDialog commonInfoDialog;
    /** 无新患者提示语 */
    private String NO_NEW_PATIENT = "最近没有增加新的患者";
    private NewPatientListBean newPatientListBean = new NewPatientListBean();
    private ArrayList<String> ids;//新患者id集合

    /** 搜索结果列表View，内部封装了listview的上拉和下拉 */
    private XCMaterialListPinRefreshLayout xcMaterialListPinRefreshLayout;
    /** 新患者列表 */
    private ListView medicineDrugListView;

    private View new_patient_zero;//空数据时候显示的View

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xc_l_activity_new_patient);
        super.onCreate(savedInstanceState);

        initTitle();
        initdata();
    }

    /**无网络时,点击屏幕后回调的方法*/
    @Override
    public void onNetRefresh() {
        requestPatientList(1);
    }

    /** 初始化title */
    public void initTitle(){
        findViewById(R.id.sx_id_title_left).setOnClickListener(this);
        ((TextView)findViewById(R.id.sx_id_title_center)).setText("新患者");
    }

    /**初始化控件*/
    @Override
    public void initWidgets() {
        new_patient_zero = getViewById(R.id.new_patient_zero);
        newPatientAdapter = new YR_NewPatientAdapter(this, null);
        xcMaterialListPinRefreshLayout = getViewById(R.id.xc_id_new_patient_list);
        medicineDrugListView = (ListView) xcMaterialListPinRefreshLayout.getListView();
        medicineDrugListView.setAdapter(newPatientAdapter);
        xcMaterialListPinRefreshLayout.autoRefresh(true);
        setEmptyView();
    }

    private void setEmptyView(){
        ImageView emptyImg = (ImageView) new_patient_zero.findViewById(R.id.xc_id_data_zero_imageview);
        TextView emptyTv = (TextView) new_patient_zero.findViewById(R.id.xc_id_data_zero_hint_textview);
        Button emptyBtn = (Button) new_patient_zero.findViewById(R.id.xc_id_data_zero_do_button);
        emptyImg.setImageResource(R.mipmap.js_d_icon_no_data);
        emptyTv.setText(NO_NEW_PATIENT);
        emptyBtn.setVisibility(View.VISIBLE);
        emptyBtn.setText(Html.fromHtml("快邀请<font color='#e2231a'>手机联系人</font>成为我的患者吧！"));
        emptyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myStartActivity(XL_ContactsInviteActivity.class);
            }
        });
        new_patient_zero.setVisibility(View.GONE);
    }

    private void initdata(){
        String origin = UtilSP.getNewPatientIds();
        ids = new ArrayList<>(Arrays.asList(origin.split(XC_ChatReceiver.PATIENT_IDS_SPLIT)));
    }
    @Override
    protected void onStart() {
        super.onStart();
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(YR_NewPatientActivity.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void listeners() {
        // 搜索结果的上下拉监听
        xcMaterialListPinRefreshLayout.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {
                return true;
            }

            @Override
            public boolean canLoad() {
                return true;
            }

            @Override
            public void refresh(View view, int request_page) {
                xcMaterialListPinRefreshLayout.resetCurrentPageAndList(newPatientAdapter);
                requestPatientList(request_page);
            }

            // 搜索结果的上拉监听，请求下一页数据
            @Override
            public void load(View view, int request_page) {
                requestPatientList(request_page);
            }
        });
        medicineDrugListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                XC_ChatModel bb = (XC_ChatModel) parent.getItemAtPosition(position);
                if (TextUtils.isEmpty(bb.getUserPatient().getPatientName())) { //提示患者资料不全
                    showDialog();
                    return;
                }
                bb.getUserPatient().setNewPatientStatus(false);
                newPatientAdapter.notifyDataSetChanged();
                ToJumpHelp.toJumpChatPatientInfoActivity(YR_NewPatientActivity.this,bb);
                reset(bb.getUserPatient().getPatientId());
            }
        });
    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(commonInfoDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.sx_id_title_left:
                myFinish();
                break;
        }
    }

    public void showDialog(){
        if (commonInfoDialog == null) {
            commonInfoDialog = new YR_CommonDialog(YR_NewPatientActivity.this, "患者资料不全!", "", "我知道了") {

                @Override
                public void confirmBtn() {
                    dismiss();
                }
            };
        }
        commonInfoDialog.show();
    }

    /** 请求新患者列表
     *  当无新患者时返回信息 {"code":30603,"msg":"没有新增患者","data":[]}
     * */
    public void requestPatientList(final int page) {
        RequestParams params = new RequestParams();
        params.put("page", page);//页码每次加一
        params.put("num", newPatientListBean.getPageSize());
        params.put("doctorId", UtilSP.getUserId());
        XCHttpAsyn.postAsyn(false,this, AppConfig.getHostUrl(AppConfig.newPatientList), params, new XCHttpResponseHandler(this) {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean != null) {
                        Parse2NewPatientListBean parse2NewPatientListBean = new Parse2NewPatientListBean(newPatientListBean);
                        parse2NewPatientListBean.parseJson(result_bean);
                        setNewPatientStatus(newPatientListBean.getPatientInfoList());
                        xcMaterialListPinRefreshLayout.setTotalPage(String.valueOf(newPatientListBean.getTotalPages()));
                        if (page == 1){
                            xcMaterialListPinRefreshLayout.updateListNoAdd(newPatientListBean.getPatientInfoList(),newPatientAdapter);
                        }else {
                            xcMaterialListPinRefreshLayout.updateListAdd(newPatientListBean.getPatientInfoList(),newPatientAdapter);
                        }
                        if (UtilCollection.isBlank(newPatientListBean.getPatientInfoList())){
                            new_patient_zero.setVisibility(View.VISIBLE);
                            //add by cyr on 2017-10-10 on start 修复无患者列表时，不能清掉新患者红点的bug
                            UtilSP.putNewPatientNum(0);
                            UtilSP.putNewPatientIds("");
                            //add by cyr on 2017-10-10 on end 修复无患者列表时，不能清掉新患者红点的bug
                        }else {
                            new_patient_zero.setVisibility(View.GONE);
                        }
                    }
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                if(new_patient_zero != null)
                new_patient_zero.setVisibility(View.GONE);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                xcMaterialListPinRefreshLayout.completeRefresh(result_boolean);
                GeneralReqExceptionProcess.checkCode(YR_NewPatientActivity.this,getCode(),getMsg());

            }
        });
    }

    /* 设置新患者标志 */
    private void setNewPatientStatus(List<NewPatientModel> newPatientModelList){
        for (NewPatientModel newPatientModel : newPatientModelList){
            if (ids.contains(newPatientModel.getUserPatient().getPatientId())){
                newPatientModel.getUserPatient().setNewPatientStatus(true);
            }
        }
    }
    /* 每次将原有数据中的id减去，并把总数目减一 */
    public void reset(String patientId){
        if (UtilCollection.isBlank(ids))
            return ;
        if (!ids.contains(patientId))
            return ;
        ids.remove(patientId);
        String result = ids.toString().replace(" ","");
        result = result.substring(1,result.length()-1);
        UtilSP.putNewPatientNum(ids.size());
        UtilSP.putNewPatientIds(result);
    }
}
