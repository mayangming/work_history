package com.qlk.ymz.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.CommonPrescriptionsActivity;
import com.qlk.ymz.activity.SK_MedicineClassificationResultActivity;
import com.qlk.ymz.activity.YR_AllMedicineClassActivity;
import com.qlk.ymz.adapter.SK_AddMedicineAdapter;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.parse.Parse2DrugBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTabLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;
import com.xiaocoder.ptrrefresh.XCMaterialListPinRefreshLayout;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * @description 我的药房分类结果结果显示页面
 * @author 赖善琦
 * @version 2.0.0
 */
public class SK_MyPharmacyClassificationResultFragment extends DBFragment {
    // 药品列表适配器
    private SK_AddMedicineAdapter medicineAdapter;
    // 搜索ID，流水号
    private String searchId;
    // 搜索结果排序tab
    private XCTabLayout sk_id_medicine_order_tab;
    // 搜索结果布局
    private XCMaterialListPinRefreshLayout sk_id_medicine_drug_list;
    // 搜索结果的集合
    private List<DrugBean> searchResultDataList;

    /** 一级分类名称 */
    private String aKey;
    /** 二级分类名称 */
    private String bKey;
    /**
     * 默认排序字段
     */
    private final String DEFAULT = "default";
    /**
     * 价格排序字段
     */
    private final String SALEPRICE = "salePrice";
    /**
     * 门诊医生价格排序
     */
    private final String DOCTORPRICE = "doctorPrice";
    /**
     * 销量排序字段
     */
    private final String SALENUM = "saleNum";
    /**
     * 用于记录当前排序字段，默认为default
     */
    private String orderBy = "default";
    /**
     * 升序
     */
    private final String ASC = "0";
    /**
     * 降序
     */
    private final String DESC = "1";
    /**
     * 价格排序 默认升序
     */
    private String salepriceOrder = ASC;
    /**
     * 销量排序 默认升序
     */
    private String salenumOrder = ASC;
    /**
     * 指数排序
     */
    private static String DRCOMMISSION = "sortedBy";
    /**
     * 积分排序
     */
    private static String MARKETPOTIN = "marketPoint";
    /**
     * 指数的排序，默认升序
     */
    private String drcommission_order = ASC;
    /**
     * 传给服务器的升序降序字段，默认不传
     */
    private String order = null;

    private int intentFlag;

    private String commonFlag;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return init(inflater,R.layout.sk_fragment_classification_result);
    }
    @Override
    public void initWidgets() {
        intentFlag = getActivity().getIntent().getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,0);
        commonFlag = getActivity().getIntent().getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION);

        sk_id_medicine_order_tab = getViewById(R.id.sk_id_medicine_order_tab);
        sk_id_medicine_drug_list = getViewById(R.id.sk_id_medicine_drug_list);

        // 0不显示 、1小七指数、2市场积分
        if ("1".equals(UtilSP.getShowCommission())) {
            sk_id_medicine_order_tab.setContents(new String[]{"默认", "价格", "销量", "指数"});
            sk_id_medicine_order_tab.setImageUris(new String[]{null, "drawable://" + R.mipmap.sk_arrow_def, "drawable://" + R.mipmap.sk_arrow_def, "drawable://" + R.mipmap.sk_arrow_def});
            sk_id_medicine_order_tab.setInitSelected(0, 4, true, 0);
        } else if ("2".equals(UtilSP.getShowCommission())) {
            sk_id_medicine_order_tab.setContents(new String[]{"默认", "价格", "销量", "积分"});
            sk_id_medicine_order_tab.setImageUris(new String[]{null, "drawable://" + R.mipmap.sk_arrow_def, "drawable://" + R.mipmap.sk_arrow_def, "drawable://" + R.mipmap.sk_arrow_def});
            sk_id_medicine_order_tab.setInitSelected(0, 4, true, 0);
        } else {
            sk_id_medicine_order_tab.setContents(new String[]{"默认", "价格", "销量"});
            sk_id_medicine_order_tab.setImageUris(new String[]{null, "drawable://" + R.mipmap.sk_arrow_def, "drawable://" + R.mipmap.sk_arrow_def});
            sk_id_medicine_order_tab.setInitSelected(0, 3, true, 0);
        }
        sk_id_medicine_order_tab.setIsHiddenBlock(true);
        sk_id_medicine_order_tab.setDivideLineMargin(10, 10);
        sk_id_medicine_order_tab.setTab_scrollview_item_id(R.layout.sk_l_view_item_search_sort);
        sk_id_medicine_order_tab.setItemTextPressColorAndDefaulColor(R.color.c_e2231a, R.color.c_7b7b7b);
        sk_id_medicine_order_tab.create();

        sk_id_medicine_drug_list.setBgZeroHintInfo("没有数据哟", "", R.mipmap.js_d_icon_no_data);

        medicineAdapter = new SK_AddMedicineAdapter(getActivity(),null);
        sk_id_medicine_drug_list.getListView().setAdapter(medicineAdapter);
    }

    @Override
    public void listeners() {
        // 设置排序tab的监听
        sk_id_medicine_order_tab.setOnClickMoveListener(new XCTabLayout.OnClickMoveListener() {
            @Override
            public void onClickMoveListener(int position, ViewGroup current_item, ImageView current_imageview, ViewGroup last_item, ImageView last_imageview) {
                int last_position = (int) last_item.getTag() / 2;
                switch (position) {
                    case 0:
                        // 选中默认排序
                        checkDefault(last_imageview, last_position);
                        break;
                    case 1:
                        // 选中价格排序
                        checkPrice(current_imageview, last_imageview, last_position);
                        break;

                    case 2:
                        // 选中销量排序
                        checkSales(current_imageview, last_imageview, last_position);
                        break;

                    case 3:
                        // 选中指数排序
                        checkDrcommission(current_imageview, last_imageview, last_position);
                        break;
                }
            }
        });

        // 设置分类搜索结果的监听
        sk_id_medicine_drug_list.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {return false;}
            @Override
            public boolean canLoad() {return true;}
            @Override
            public void refresh(View view, int request_page) {}
            @Override
            public void load(View view, int request_page) {
                requestSearch(aKey,bKey,request_page + "",orderBy,order);
            }
        });

        sk_id_medicine_drug_list.getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DrugBean bean = (DrugBean) parent.getItemAtPosition(position);
                UtilNativeHtml5.toJumpDrugDetail(getBaseActivity(), bean.getId());
                DrugBean.drug_id = bean.getId();
            }
        });

        medicineAdapter.setOnAddMedicineAdapterAction(new SK_AddMedicineAdapter.SK_AddMedicineAdapterAction() {
            @Override
            public void onAddBoxAction(View v) {
                DrugBean bean = (DrugBean) v.getTag();

                // 我的药房
                if(0 == intentFlag){
                    // 添加到常用药
                    bean.setAdded(true);
                    requestAddBox((Button)v,bean, bean.getId());
                    // created by songxin,date：2018-01-09,about：saveInfo,begin
                    BiUtil.saveBiInfo(SK_MedicineClassificationResultActivity.class, "2", "128", "E00104","", false);
                    // created by songxin,date：2018-01-09,about：saveInfo,end
                    // 我的药房 常用处方详情页
                }else if(1 == intentFlag){
                    // 选中
                    if (null == RecomMedicineHelper.getInstance().getCommonRecipe().getCheckMap().get(bean.getId())) {
                        ToJumpHelp.toJumpUsageActivitiy(getActivity(),bean,intentFlag,commonFlag);
                    }
                    // 推荐用药 带药箱
                }else if(2 == intentFlag){
                    // created by songxin,date：2018-01-09,about：saveInfo,begin
                    BiUtil.saveBiInfo(SK_MedicineClassificationResultActivity.class, "2", "128", "E00094","", false);
                    // created by songxin,date：2018-01-09,about：saveInfo,end
                    if (null != RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getCheckDrugMap().get(bean.getId())) {
                        RecomMedicineHelper.getInstance().removeDrugBean(bean.getId());
                        ((SK_MedicineClassificationResultActivity)getActivity()).setMedicineNum();
                        medicineAdapter.notifyDataSetChanged();
                    } else {
                        ToJumpHelp.toJumpUsageActivitiy(getActivity(),bean,intentFlag,commonFlag);
                    }

                    // 推荐用药 常用处方详情页 不带药箱
                }else if(3 == intentFlag){
                    if (null == RecomMedicineHelper.getInstance().getCommonRecipe().getCheckMap().get(bean.getId())) {
                        ToJumpHelp.toJumpUsageActivitiy(getActivity(),bean,intentFlag,commonFlag);
                    }

                    // 推荐用药 处方笺页 不带药箱
                }else if(4 == intentFlag){
                    if(null == RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getCheckDrugMap().get(bean.getId())) {
                        ToJumpHelp.toJumpUsageActivitiy(getActivity(),bean,intentFlag,commonFlag);
                    }
                }
            }

        });
    }


    /**
     * 选中默认排序
     * @param last_imageview 上一次停留的imageview
     * @param last_position  上一次停留的位置
     */
    private void checkDefault(ImageView last_imageview, int last_position) {
        if (UtilString.isBlank(bKey) || UtilString.isBlank(aKey)) {
            return;
        }
        if (last_position != 0) {
            last_imageview.setImageResource(R.mipmap.sk_arrow_def);
        }
        sk_id_medicine_drug_list.resetCurrentPageAndList(medicineAdapter);
        requestSearch(aKey,bKey, "1", DEFAULT, null);
    }


    /**
     * 请求数据
     * @param aKey 一级分类名称
     * @param bKey 二级分类名称
     */
    public void requestData(String aKey,String bKey){
        this.aKey = aKey;
        this.bKey = bKey;
        if(sk_id_medicine_order_tab != null)
            sk_id_medicine_order_tab.pressSelected(0);
        if(sk_id_medicine_drug_list != null)
            sk_id_medicine_drug_list.resetCurrentPageAndList(medicineAdapter);
        requestSearch(aKey,bKey, "1", DEFAULT, null);
    }

    /**
     * 选中价格排序
     * @param current_imageview 当前的imageview
     * @param last_imageview    上一次停留的imageview
     * @param last_position     上一次停留的位置
     */
    private void checkPrice(ImageView current_imageview, ImageView last_imageview, int last_position) {
        if (UtilString.isBlank(bKey) || UtilString.isBlank(aKey)) {
            return;
        }
        // 如果是升序
        if (ASC.equals(salepriceOrder)) {
            salepriceOrder = DESC;
            current_imageview.setImageResource(R.mipmap.sk_arrow_down);
        } else {
            salepriceOrder = ASC;
            current_imageview.setImageResource(R.mipmap.sk_arrow_top);
        }
        if (last_position == 2) {
            last_imageview.setImageResource(R.mipmap.sk_arrow_def);
        } else if (last_position == 3) {
            last_imageview.setImageResource(R.mipmap.sk_arrow_def);
        }
        sk_id_medicine_drug_list.resetCurrentPageAndList(medicineAdapter);
        if("2".equals(UtilSP.getShowCommission())){
            requestSearch(aKey, bKey, "1", DOCTORPRICE, salepriceOrder);
        }else {
            requestSearch(aKey, bKey, "1", SALEPRICE, salepriceOrder);
        }
    }

    /**
     * 选中销量排序
     * @param current_imageview 当前的imageview
     * @param last_imageview    上一次停留的imageview
     * @param last_position     上一次停留的位置
     */
    private void checkSales(ImageView current_imageview, ImageView last_imageview, int last_position) {
        if (UtilString.isBlank(bKey) || UtilString.isBlank(aKey)) {
            return;
        }
        if (ASC.equals(salenumOrder)) {
            salenumOrder = DESC;
            current_imageview.setImageResource(R.mipmap.sk_arrow_down);
        } else {
            salenumOrder = ASC;
            current_imageview.setImageResource(R.mipmap.sk_arrow_top);
        }
        if (last_position == 1) {
            last_imageview.setImageResource(R.mipmap.sk_arrow_def);
        } else if (last_position == 3) {
            last_imageview.setImageResource(R.mipmap.sk_arrow_def);
        }
        sk_id_medicine_drug_list.resetCurrentPageAndList(medicineAdapter);
        requestSearch(aKey,bKey, "1", SALENUM, salenumOrder);
    }

    /**
     * 选中指数排序
     * @param current_imageview 当前的imageview
     * @param last_imageview    上一次停留的imageview
     * @param last_position     上一次停留的位置
     */
    private void checkDrcommission(ImageView current_imageview, ImageView last_imageview, int last_position) {
        if (UtilString.isBlank(bKey) || UtilString.isBlank(aKey)) {
            return;
        }
        if (ASC.equals(drcommission_order)) {
            drcommission_order = DESC;
            current_imageview.setImageResource(R.mipmap.sk_arrow_down);
        } else {
            drcommission_order = ASC;
            current_imageview.setImageResource(R.mipmap.sk_arrow_top);
        }
        if (last_position == 1) {
            last_imageview.setImageResource(R.mipmap.sk_arrow_def);
        } else if (last_position == 2) {
            last_imageview.setImageResource(R.mipmap.sk_arrow_def);
        }
        sk_id_medicine_drug_list.resetCurrentPageAndList(medicineAdapter);
        if("2".equals(UtilSP.getShowCommission())){
            requestSearch(aKey,bKey, "1", MARKETPOTIN, drcommission_order);
        }else {
            requestSearch(aKey,bKey, "1", DRCOMMISSION, drcommission_order);
        }
    }



    /**
     * 将xcjsonbean解析为drugBean
     *
     * @param list 搜索结果的源数据
     */
    public void parseData(List<XCJsonBean> list) {
        Parse2DrugBean parse2DrugBean = new Parse2DrugBean();
        searchResultDataList = new ArrayList<>();
        DrugBean drugBean;
        for (XCJsonBean xcJsonBean : list) {
            drugBean = parse2DrugBean.parse(new DrugBean(), xcJsonBean);
            searchResultDataList.add(drugBean);
            }
    }
    /**
     * 请求搜索接口
     *
     * @param aKey     一级分类
     * @param bKey     二级分类
     * @param page    页数
     * @param orderBy 分类 （default: 默认，salePrice: 价格，saleNum : 销售， sortedBy ：指数）
     * @param order   排序 （ 0 : 升序， 1 : 降序）
     */
    public void requestSearch(String aKey,String bKey, String page, String orderBy, String order) {
        this.orderBy = orderBy;
        this.order = order;
        // 设置请求参数
        RequestParams params = new RequestParams();
        params.put("firTitle",aKey);
        params.put("secTitle", bKey);
        params.put("page", page);
        params.put("orderBy", orderBy);
        if (!UtilString.isBlank(order)) {
            params.put("order", order);
        }
        if(!UtilString.isBlank(searchId)){
            params.put("searchId",searchId);
        }
        XCHttpAsyn.postAsyn(getBaseActivity(), AppConfig.getHostUrl(AppConfig.madicine_search), params, new XCHttpResponseHandler(getBaseActivity()) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !((SK_MedicineClassificationResultActivity)getActivity()).isDestroy) {
                    try {

                        List<XCJsonBean> bean = result_bean.getList("data");
                        sk_id_medicine_drug_list.setTotalPage(bean.get(0).getString("totalPages"));
                        searchId = bean.get(0).getString("searchId");
                        List<XCJsonBean> beans = bean.get(0).getList("result");
                        parseData(beans);
                        sk_id_medicine_drug_list.updateListAdd(searchResultDataList,medicineAdapter);
                        // 是否显示排序栏（1 是 0 否）
                        if("1".equals(bean.get(0).getString("sortable"))){
                            sk_id_medicine_order_tab.setVisibility(View.VISIBLE);
                        }else{
                            sk_id_medicine_order_tab.setVisibility(View.GONE);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                sk_id_medicine_drug_list.completeRefresh(result_boolean);
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(getActivity(),
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 请求添加常用药的接口
     * @param id 药品ID
     */
    public void requestAddBox(final Button button,final DrugBean bean,String id){
        RequestParams params = new RequestParams();
        params.put("pid", id);
        XCHttpAsyn.postAsyn(getBaseActivity(),AppConfig.getHostUrl(AppConfig.madicine_addbox),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                dShortToast("添加成功");
                // 以下是已添加数加1
                int addNum = bean.getAddNum();
                bean.setAddNum(addNum + 1 );
                bean.setAdded(true);
                medicineAdapter.notifyDataSetChanged();
                button.setClickable(false);
                button.setBackgroundResource(R.mipmap.sk_dd_added);
                button.setTextColor(context.getResources().getColor(R.color.c_gray_7b7b7b));
                button.setText("已加入常用药");
                RecomMedicineHelper.getInstance().setUpdateCommonMedicine(true);
            }
            @Override
            public void onFinish() {
                super.onFinish();
                // 处理code操作
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(getActivity(),
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }


    public void notifyDataSetChanged(){
        if(medicineAdapter != null){
            medicineAdapter.notifyDataSetChanged();
        }
    }

}
