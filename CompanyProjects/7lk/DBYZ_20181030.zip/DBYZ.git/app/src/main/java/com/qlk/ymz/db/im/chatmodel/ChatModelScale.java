package com.qlk.ymz.db.im.chatmodel;

import java.io.Serializable;

/**
 * description: 聊天消息中的量表内容
 * autour: YM
 * date: 2017/7/11
 * update: $date$
 * version: $version$
 */

public class ChatModelScale implements Serializable,Cloneable{
    private String scaleType = "1";//量表的类型，1:评估分(自测表),2:无评估分(调查表)
    private String scaleId = "";//量表Id
    private String scaleTitle = "";//量表标题
    private String scalePoint = "";//量表总得分

    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
    public String getScaleType() {
        return scaleType;
    }

    /* 是否是自测表 */
    public boolean isScaleTest() {
        return "1".equals(getScaleType());
    }

    public void setScaleType(String scaleType) {
        this.scaleType = scaleType;
    }

    public String getScaleId() {
        return scaleId;
    }

    public void setScaleId(String scaleId) {
        this.scaleId = scaleId;
    }

    public String getScaleTitle() {
        return scaleTitle;
    }

    public void setScaleTitle(String scaleTitle) {
        this.scaleTitle = scaleTitle;
    }

    public String getScalePoint() {
        return scalePoint;
    }

    public void setScalePoint(String scalePoint) {
        this.scalePoint = scalePoint;
    }
}
