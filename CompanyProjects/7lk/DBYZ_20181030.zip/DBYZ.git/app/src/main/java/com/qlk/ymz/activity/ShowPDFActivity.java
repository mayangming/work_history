package com.qlk.ymz.activity;

import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.DownloadHelper;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.File;
import java.lang.ref.WeakReference;

/**
 * @author zhangpengfei.
 * @version 1.0
 */

public class ShowPDFActivity extends DBActivity {
    public static final int DOWNLOAD_FINISH = 1000;
    public static final int DOWNLOAD_FAIL = 2000;
    public static final String URL_TAG = "urlTag";
    private XCTitleCommonLayout titleLayout;
    /**下载数据布局*/
    private LinearLayout download_loading_ll;
    private TextView progress_tv;
    private PDFView pdfView;
    private DownloadHelper downloadHelper;
    /**pdf文件*/
    private File pdfFile;
    private String url = "";
    /**当前进不*/
    private int currentProgress = 0;

    private MyHandler mHandler = new MyHandler(this);

    private static class MyHandler extends Handler {
        WeakReference<ShowPDFActivity> weakReference;

        public MyHandler(ShowPDFActivity showPDFActivity){
            weakReference = new WeakReference<>(showPDFActivity);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case DOWNLOAD_FINISH:
                    weakReference.get().download_loading_ll.setVisibility(View.GONE);
                    weakReference.get().showPDF();
                    break;
                case DOWNLOAD_FAIL:
                    weakReference.get().download_loading_ll.setVisibility(View.GONE);
                    weakReference.get().shortToast("下载失败");
                    break;
            }
        }
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(ShowPDFActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void onNetRefresh() {

    }
    private void showPDF(){
        pdfView.fromFile(pdfFile).scrollHandle(new DefaultScrollHandle(this)).load();
    }
    @Override
    public void initWidgets() {
        setContentView(R.layout.activity_show_pdf);
        titleLayout = getViewById(R.id.xc_id_model_titlebar);
        download_loading_ll = getViewById(R.id.download_loading_ll);
        progress_tv = getViewById(R.id.progress_tv);
        pdfView = getViewById(R.id.pdfView);
        titleLayout.setTitleLeft(true, "");
        titleLayout.setTitleCenter(true, "");
        if (getIntent() != null && !UtilString.isBlank(getIntent().getStringExtra(URL_TAG))){
            url = getIntent().getStringExtra(URL_TAG);
        }else{
            shortToast("地址错误,请重试");
        }
        String fileName = url.substring(url.lastIndexOf("/"));
        pdfFile = UtilFiles.createFileInAndroid(XCConfig.PDF_DIR, fileName, this);
        if (pdfFile.length() > 0){
            mHandler.sendEmptyMessage(DOWNLOAD_FINISH);
        }else{
            downloadPDF(url);
        }
    }
    /**
     * 下载pfd
     *
     * @param url
     */
    public void downloadPDF(String url) {
        download_loading_ll.setVisibility(View.VISIBLE);
        downloadHelper = new DownloadHelper(url, pdfFile);
        new Thread(downloadHelper).start();
        downloadHelper.setDownloadListener(new DownloadHelper.DownloadListener() {
            @Override
            public void downloadFinished(final File file) {
                mHandler.sendEmptyMessage(DOWNLOAD_FINISH);
            }

            @Override
            public void netFail(File file) {
                mHandler.sendEmptyMessage(DOWNLOAD_FAIL);
            }

            @Override
            public void downLoadProgress(int progress, long total, long current) {
                currentProgress = progress;
                //下载大于99的时候,强制改成99,留1用来解压缩
                if (currentProgress > 99){
                    currentProgress = 99;
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progress_tv.setText(currentProgress +"%");
                    }
                });
            }
        });
    }
    @Override
    public void listeners() {

    }
}
