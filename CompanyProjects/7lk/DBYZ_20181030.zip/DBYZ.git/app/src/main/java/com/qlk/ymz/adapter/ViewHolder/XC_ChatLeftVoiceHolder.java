package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 聊天详情  医生 纯文本消息
 */
public class XC_ChatLeftVoiceHolder extends XC_ChatLeftBaseHolder {

    public TextView xc_id_adapter_left_content_text;
    public ImageView xc_id_adapter_left_voice_imageview;
    public TextView xc_id_adapter_left_voice_time;
    public ImageView xc_id_adapter_left_voice_point;

    public XC_ChatLeftVoiceHolder(View convertView) {
        super(convertView);
        xc_id_adapter_left_content_text = (TextView) convertView.findViewById(R.id.xc_id_adapter_left_content_text);
        xc_id_adapter_left_voice_imageview = (ImageView) convertView.findViewById(R.id.xc_id_adapter_left_voice_imageview);
        xc_id_adapter_left_voice_time = (TextView) convertView.findViewById(R.id.xc_id_adapter_left_voice_time);
        xc_id_adapter_left_voice_point = (ImageView) convertView.findViewById(R.id.xc_id_adapter_left_voice_point);
    }
}