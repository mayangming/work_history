package com.qlk.ymz.activity;

import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.adapter.ImageAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.record.AmcResultBean;
import com.qlk.ymz.model.record.ConclusionVOBean;
import com.qlk.ymz.model.record.DoctorDesVOBean;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.model.record.ImgListBean;
import com.qlk.ymz.model.record.PatientCaseVOBean;
import com.qlk.ymz.model.record.PatientOldCaseVOBean;
import com.qlk.ymz.model.record.PrescriptionListBean;
import com.qlk.ymz.model.record.PrescriptionVOBean;
import com.qlk.ymz.model.record.RecordVOBean;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2018/5/29.
 * 病历详情页(v2.18)&&既往病历（v2.19）
 */

public class XD_MedicalRecordDetailActivity extends DBActivity {
    public static final String RECORD_DETAIL = "recordDetail";//接受病历详情的model
    public static final String IS_DETAIL = "isDetail";//是否为详情页
    /** 标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** 提示文字*/
    private TextView tv_hint;
    /** 患者基本信息*/
    private RelativeLayout rl_patient_base_info;
    /** 患者姓名*/
    private TextView tv_patient_name;
    /** 患者年龄*/
    private TextView tv_patient_age;
    /** 患者性别*/
    private TextView tv_patient_sex;
    /** 时间*/
    private TextView tv_time;
    /** 头部科室*/
    private LinearLayout ll_department_head;
    private TextView tv_department_head;

    /** 医生填写部分*/
    private LinearLayout ll_doctor_edit;
    /** 主诉布局*/
    private LinearLayout ll_suit;
    /** 主诉*/
    private TextView tv_suit;
    /** 既往史布局*/
    private LinearLayout ll_history;
    /** 既往史*/
    private TextView tv_history;
    /** 检查指标布局*/
    private LinearLayout ll_check;
    /** 检查指标*/
    private TextView tv_check;
    /** 其它检查布局*/
    private LinearLayout ll_other_check;
    /** 其它检查*/
    private TextView tv_other_check;
    /** 诊断布局*/
    private LinearLayout ll_diagnosis;
    /** 诊断*/
    private TextView tv_diagnosis;
    /** 医嘱小结布局*/
    private LinearLayout ll_doctor_advice;
    /** 医嘱小结*/
    private TextView tv_doctor_advice;

    /** 基本病情*/
    private LinearLayout ll_base_record;
    /** 婚姻状况布局*/
    private LinearLayout ll_marriage;
    /** 婚姻状况*/
    private TextView tv_marriage;
    /** 身高布局*/
    private LinearLayout ll_height;
    /** 身高*/
    private TextView tv_height;
    /** 体重布局*/
    private LinearLayout ll_weight;
    /** 体重*/
    private TextView tv_weight;
    /** 哺乳期或孕期布局*/
    private LinearLayout ll_pregnancy;
    /** 哺乳期或孕期*/
    private TextView tv_pregnancy;
    /** 饮酒情况布局*/
    private LinearLayout ll_drink;
    /** 饮酒情况*/
    private TextView tv_drink;
    /** 过敏布局*/
    private LinearLayout ll_drug_allergy;
    /** 过敏*/
    private TextView tv_drug_allergy;
    /** 患者填写既往病史布局*/
    private LinearLayout ll_post_history;
    /** 患者填写既往病史*/
    private TextView tv_post_history;
    /** 家族病史布局*/
    private LinearLayout ll_family_history;
    /** 家族病史*/
    private TextView tv_family_history;
    /** 遗传病史布局*/
    private LinearLayout ll_heredity_history;
    /** 遗传病史*/
    private TextView tv_heredity_history;
    /** 吸烟布局*/
    private LinearLayout ll_smoke;
    /** 吸烟*/
    private TextView tv_smoke;
    /** 病情描述布局*/
    private LinearLayout ll_desc;
    private TextView tv_desc_title;
    /** 病情描述*/
    private TextView tv_desc;
    /** 自诊结果布局*/
    private LinearLayout ll_self_diag;
    /** 自诊结果*/
    private TextView tv_self_diag;

    /** 诊疗记录*/
    private LinearLayout ll_record;
    private TextView tv_record_title;
    private TextView tv_record;

    /** 图片布局*/
    private LinearLayout ll_doctor_pic;
    /** 图片列表*/
    private RecyclerView rv_doctor_pic;
    /** 医嘱图片布局*/
    private LinearLayout ll_doctor_advice_pic;
    /** 医嘱图片列表*/
    private RecyclerView rv_doctor_advice_pic;
    /** 处方单布局*/
    private LinearLayout ll_prescription_pic;
    /** 处方单列表*/
    private RecyclerView rv_prescription_pic;
    /** 检查单布局*/
    private LinearLayout ll_check_pic;
    /** 检查单列表*/
    private RecyclerView rv_check_pic;

    /** 医生科室布局*/
    private LinearLayout ll_department;
    private TextView tv_department;
    /** 医生姓名*/
    private LinearLayout ll_doctor_name;
    private TextView tv_doctor_name;
    /** 医院*/
    private LinearLayout ll_hospital;
    private TextView tv_hospital;
    /** 就诊时间*/
    private LinearLayout ll_visting_time;
    private TextView tv_visting_time;

    /** 底部布局*/
    private LinearLayout ll_bottom;
    /** 新建按钮*/
    private TextView tv_creat;
    /** 下一步完善*/
    private TextView tv_next;
    /** 分割线*/
    private View v_line;

    /** 上级页面传过来病历*/
    private DrRecordVOBean mDrRecordVOBean;
    private boolean isDetail = true;//是否为详情
    private boolean haveBaseRecord = false;
    private boolean haveDoctorEdit = false;
    private boolean haveDrug = false;//是否有药
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_medical_record_detail);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_MedicalRecordDetailActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleLeft(true, "");

        tv_hint = getViewById(R.id.tv_hint);
        rl_patient_base_info = getViewById(R.id.rl_patient_base_info);
        tv_patient_name = getViewById(R.id.tv_patient_name);
        tv_patient_age = getViewById(R.id.tv_patient_age);
        tv_patient_sex = getViewById(R.id.tv_patient_sex);
        tv_time = getViewById(R.id.tv_time);
        ll_department_head = getViewById(R.id.ll_department_head);
        tv_department_head = getViewById(R.id.tv_department_head);

        ll_doctor_edit = getViewById(R.id.ll_doctor_edit);
        ll_suit = getViewById(R.id.ll_suit);
        tv_suit = getViewById(R.id.tv_suit);
        ll_history = getViewById(R.id.ll_history);
        tv_history = getViewById(R.id.tv_history);
        ll_check = getViewById(R.id.ll_check);
        tv_check = getViewById(R.id.tv_check);
        ll_other_check = getViewById(R.id.ll_other_check);
        tv_other_check = getViewById(R.id.tv_other_check);
        ll_diagnosis = getViewById(R.id.ll_diagnosis);
        tv_diagnosis = getViewById(R.id.tv_diagnosis);
        ll_doctor_advice = getViewById(R.id.ll_doctor_advice);
        tv_doctor_advice = getViewById(R.id.tv_doctor_advice);

        ll_base_record = getViewById(R.id.ll_base_record);
        ll_height = getViewById(R.id.ll_height);
        tv_height = getViewById(R.id.tv_height);
        ll_marriage = getViewById(R.id.ll_marriage);
        tv_marriage = getViewById(R.id.tv_marriage);
        ll_weight = getViewById(R.id.ll_weight);
        tv_weight = getViewById(R.id.tv_weight);
        ll_pregnancy = getViewById(R.id.ll_pregnancy);
        tv_pregnancy = getViewById(R.id.tv_pregnancy);
        ll_drink = getViewById(R.id.ll_drink);
        tv_drink = getViewById(R.id.tv_drink);
        ll_family_history = getViewById(R.id.ll_family_history);
        tv_family_history = getViewById(R.id.tv_family_history);
        ll_post_history = getViewById(R.id.ll_post_history);
        tv_post_history = getViewById(R.id.tv_post_history);
        ll_drug_allergy = getViewById(R.id.ll_drug_allergy);
        tv_drug_allergy = getViewById(R.id.tv_drug_allergy);
        ll_heredity_history = getViewById(R.id.ll_heredity_history);
        tv_heredity_history = getViewById(R.id.tv_heredity_history);
        ll_smoke = getViewById(R.id.ll_smoke);
        tv_smoke = getViewById(R.id.tv_smoke);
        ll_desc = getViewById(R.id.ll_desc);
        tv_desc_title = getViewById(R.id.tv_desc_title);
        tv_desc = getViewById(R.id.tv_desc);
        ll_self_diag = getViewById(R.id.ll_self_diag);
        tv_self_diag = getViewById(R.id.tv_self_diag);

        ll_record = getViewById(R.id.ll_record);
        tv_record_title = getViewById(R.id.tv_record_title);
        tv_record = getViewById(R.id.tv_record);

        ll_doctor_pic = getViewById(R.id.ll_doctor_pic);
        rv_doctor_pic = getViewById(R.id.rv_doctor_pic);
        ll_doctor_advice_pic = getViewById(R.id.ll_doctor_advice_pic);
        rv_doctor_advice_pic = getViewById(R.id.rv_doctor_advice_pic);
        ll_check_pic = getViewById(R.id.ll_check_pic);
        rv_check_pic = getViewById(R.id.rv_check_pic);
        ll_prescription_pic = getViewById(R.id.ll_prescription_pic);
        rv_prescription_pic = getViewById(R.id.rv_prescription_pic);

        ll_department = getViewById(R.id.ll_department);
        tv_department = getViewById(R.id.tv_department);
        ll_doctor_name = getViewById(R.id.ll_doctor_name);
        tv_doctor_name = getViewById(R.id.tv_doctor_name);
        ll_hospital = getViewById(R.id.ll_hospital);
        tv_hospital = getViewById(R.id.tv_hospital);
        ll_visting_time = getViewById(R.id.ll_visting_time);
        tv_visting_time = getViewById(R.id.tv_visting_time);

        ll_bottom = getViewById(R.id.ll_bottom);
        v_line = getViewById(R.id.v_line);
        tv_creat = getViewById(R.id.tv_creat);
        tv_next = getViewById(R.id.tv_next);
    }

    /**
     * 初始化数据
     */
    private void initData() {
        mDrRecordVOBean = (DrRecordVOBean) getIntent().getSerializableExtra(RECORD_DETAIL);
        isDetail = getIntent().getBooleanExtra(IS_DETAIL,true);

        if(isDetail){//详情页隐藏底部按钮布局和提示文案
            ll_bottom.setVisibility(View.GONE);
            v_line.setVisibility(View.GONE);
            tv_hint.setVisibility(View.GONE);
            xc_id_model_titlebar.setTitleCenter(true, "病历详情");
        }else {
            ll_bottom.setVisibility(View.VISIBLE);
            v_line.setVisibility(View.VISIBLE);
            tv_hint.setVisibility(View.VISIBLE);
            xc_id_model_titlebar.setTitleCenter(true, "病历");
            if(!UtilCollection.isBlank(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getRecommendInfo().getDrugInfoBean())){
                haveDrug = true;
            }
        }

        if(mDrRecordVOBean!=null){
            if(mDrRecordVOBean.getName()!=null&&mDrRecordVOBean.getCreateAt()!=null){
                tv_hint.setText("查询到"+ mDrRecordVOBean.getName()+UtilDate.convertTimeToFormat(UtilString.toLong(mDrRecordVOBean.getCreateAt())) +"的病历");
            }
            switch (mDrRecordVOBean.getCaseType()){
                case CommonConfig.MEDICAL_RECORD://原诊疗记录
                case CommonConfig.MEDICAL_CONDITION_RECORD://带基本病情的原诊疗记录
                    fillOldRecord();
                    fillWidget(ll_department,tv_department,mDrRecordVOBean.getDepartment(),"");
                    break;
                case CommonConfig.MEDICAL_DOCTOR_PRESCRIPTION:
                case CommonConfig.MEDICAL_CONSULT_ROOM://线上诊室病历
                case CommonConfig.MEDICAL_DOCTOR://医生填写的病历
                    fillDoctorRecord();
                    break;
                case CommonConfig.MEDICAL_PATIENT_NEW://患者填写病历
                    fillPatientRecord();
                    break;
                case CommonConfig.MEDICAL_PATIENT_OLD://患者老病历
                    PatientOldCaseVOBean patientOldCaseVOBean = (PatientOldCaseVOBean) mDrRecordVOBean.getMdicalRecordVO();
                    tv_record_title.setText("病情描述");
                    fillWidget(ll_record,tv_record,patientOldCaseVOBean.getDescript(),"");
                    fillPicWidget(ll_doctor_pic,rv_doctor_pic, (ArrayList<String>) patientOldCaseVOBean.getImgList(),"");
                    fillWidget(ll_department,tv_department,mDrRecordVOBean.getDepartment(),"");
                    break;
                case CommonConfig.MEDICAL_CONDITION_PRESCRIPTION://带基本病情的系统处方
                    PrescriptionVOBean prescriptionVOBean = (PrescriptionVOBean) mDrRecordVOBean.getMdicalRecordVO();
                    DoctorDesVOBean doctorDesVO = prescriptionVOBean.getDoctorDesVO();
                    String url = prescriptionVOBean.getUrl();
                    if(doctorDesVO!=null){
                        fillBaseRecord(doctorDesVO);
                        ll_desc.setVisibility(View.GONE);//无病情描述
                        ll_self_diag.setVisibility(View.GONE);//无自诊结果
                        if(haveBaseRecord){
                            ll_base_record.setVisibility(View.VISIBLE);
                        }
                    }
                    ArrayList<String> urls = new ArrayList<>();
                    urls.add(url);
                    fillPicWidget(ll_doctor_pic,rv_doctor_pic,urls,prescriptionVOBean.getRecommendId());
                    fillWidget(ll_department,tv_department,mDrRecordVOBean.getDepartment(),"");
                    break;
                default:
                    dShortToast("暂不支持当前病例。请升级后查看!");
                    break;
            }
            fillWidget(ll_doctor_name,tv_doctor_name,mDrRecordVOBean.getDoctorName(),"");
            fillWidget(ll_hospital,tv_hospital,mDrRecordVOBean.getHospitalName(),"");
        }
    }

    /**
     * 填充患者填写病历
     */
    private void fillPatientRecord() {
        fillBaseInfo();
        PatientCaseVOBean patientCaseVOBean = (PatientCaseVOBean) mDrRecordVOBean.getMdicalRecordVO();
        tv_time.setText("创建："+ DateUtils.DateFormat(patientCaseVOBean.getFinishTime(), "yyyy/MM/dd"));
        tv_hint.setText("查询到"+ mDrRecordVOBean.getName()+UtilDate.convertTimeToFormat(UtilString.toLong(patientCaseVOBean.getFinishTime())) +"的病历");
        ll_marriage.setVisibility(View.GONE);//患者填写无婚姻情况
        fillBaseRecordWidget(ll_height,tv_height,patientCaseVOBean.getHeight(),"cm");
        fillBaseRecordWidget(ll_weight,tv_weight,patientCaseVOBean.getWeight(),"kg");
        fillBaseRecordWidget(ll_pregnancy,tv_pregnancy,patientCaseVOBean.getPregnancy(),"");
        fillBaseRecordWidget(ll_drink,tv_drink,patientCaseVOBean.getDrink(),"");
        fillBaseRecordWidget(ll_drug_allergy,tv_drug_allergy,patientCaseVOBean.getMedicAllergys(),"");
        fillBaseRecordWidget(ll_post_history,tv_post_history,patientCaseVOBean.getPastDiseases(),"");
        fillBaseRecordWidget(ll_family_history,tv_family_history,patientCaseVOBean.getFamilyDiseases(),"");
        fillBaseRecordWidget(ll_heredity_history,tv_heredity_history,patientCaseVOBean.getHereditaryDiseases(),"");
        fillBaseRecordWidget(ll_smoke,tv_smoke,patientCaseVOBean.getSmoke(),"");
        fillBaseRecordWidget(ll_desc,tv_desc,patientCaseVOBean.getDescription(),"");
        fillBaseRecordWidget(ll_self_diag,tv_self_diag,getAcmStr(patientCaseVOBean.getAcmResult()),"");
        if(haveBaseRecord){
            ll_base_record.setVisibility(View.VISIBLE);//展示患者填写信息
        }
        //展示图片
        fillPicWidget(ll_doctor_advice_pic,rv_doctor_advice_pic,patientCaseVOBean.getAdviceList());
        fillPicWidget(ll_prescription_pic,rv_prescription_pic,patientCaseVOBean.getPrescriptionList());
        fillPicWidget(ll_check_pic,rv_check_pic,patientCaseVOBean.getCheckList());

        fillWidget(ll_visting_time,tv_visting_time,DateUtils.DateFormat(patientCaseVOBean.getVistingTime(),"yyyy/MM/dd"),"");
    }

    /**
     * 填写患者头部信息
     */
    private void fillBaseInfo() {
        //展示患者信息
        rl_patient_base_info.setVisibility(View.VISIBLE);
        tv_patient_name.setText("姓名："+mDrRecordVOBean.getName());
        tv_patient_age.setText("年龄："+mDrRecordVOBean.getAge()+mDrRecordVOBean.getAgeUnit());
        tv_time.setText("时间："+ DateUtils.DateFormat(mDrRecordVOBean.getCreateAt(),"yyyy/MM/dd"));
        if("0".equals(mDrRecordVOBean.getGender())){
            tv_patient_sex.setText("性别：女");
        }else if("1".equals(mDrRecordVOBean.getGender())){
            tv_patient_sex.setText("性别：男");
        }
        fillWidget(ll_department_head,tv_department_head,mDrRecordVOBean.getDepartment(),"");
    }

    /**
     * 填充医生填写病历
     */
    private void fillDoctorRecord() {
        //展示患者信息
        fillBaseInfo();
        DrCaseVOBean drCaseVOBean = (DrCaseVOBean) mDrRecordVOBean.getMdicalRecordVO();
        if(UtilString.isAllBlank(drCaseVOBean.getMainComplaint(),drCaseVOBean.getPresentDisease())){
            ll_suit.setVisibility(View.GONE);
        }else {
            haveDoctorEdit = true;
            ll_suit.setVisibility(View.VISIBLE);
            String suitStr = "";
            if (!TextUtils.isEmpty(drCaseVOBean.getMainComplaint())) {
                suitStr = getTrimStr("",drCaseVOBean.getMainComplaint(),"") +"\n"+
                          getTrimStr("现病史：", drCaseVOBean.getPresentDisease(),"");
            }else {
                suitStr = getTrimStr("现病史：", drCaseVOBean.getPresentDisease(),"");
            }
            tv_suit.setText(clearEnd(suitStr));
        }
        fillDoctorEditWidget(ll_history,tv_history,drCaseVOBean.getPastHistory(),"");
        if(UtilString.isAllBlank(drCaseVOBean.getTemperature(), drCaseVOBean.getWeight(),
                drCaseVOBean.getHeartRete(),drCaseVOBean.getDiastole(),
                drCaseVOBean.getSystolic(),drCaseVOBean.getMoreExamin())){
            ll_check.setVisibility(View.GONE);
        }else {
            haveDoctorEdit = true;
            ll_check.setVisibility(View.VISIBLE);
            String str = getTrimStr("体温：",drCaseVOBean.getTemperature(),"度")+
                    getTrimStr("体重：", drCaseVOBean.getWeight(),"kg")+
                    getTrimStr("心率：",drCaseVOBean.getHeartRete(),"bpm")+
                    getTrimStr("收缩压：", drCaseVOBean.getSystolic(),"mmhg")+
                    getTrimStr("舒张压：",drCaseVOBean.getDiastole(),"mmhg")+
                    getTrimStr("",drCaseVOBean.getMoreExamin(),"");
            tv_check.setText(clearEnd(str));
        }
        if("1".equals(drCaseVOBean.getTemplateType())||UtilString.isAllBlank(drCaseVOBean.getAlt(), drCaseVOBean.getAst(),drCaseVOBean.getHbvDna())){
            ll_other_check.setVisibility(View.GONE);
        }else {
            haveDoctorEdit = true;
            ll_other_check.setVisibility(View.VISIBLE);
            String str = getTrimStr("谷丙转氨酶(ALT)：",drCaseVOBean.getAlt(),"IU/ml")+
                    getTrimStr("谷草转氨酶(AST)：",drCaseVOBean.getAst(),"IU/ml")+
                    getTrimStr("HBV-DNA：",drCaseVOBean.getHbvDna(),"IU/ml");
            tv_other_check.setText(clearEnd(str));
        }
        fillDoctorEditWidget(ll_diagnosis,tv_diagnosis,drCaseVOBean.getDiagnosis(),"");
        if(TextUtils.isEmpty(drCaseVOBean.getDoctorOrder())&&"2".equals(drCaseVOBean.getRevisitFalg())){
            ll_doctor_advice.setVisibility(View.GONE);
        }else {
            haveDoctorEdit = true;
            ll_doctor_advice.setVisibility(View.VISIBLE);
            String str = "";
            if("2".equals(drCaseVOBean.getRevisitFalg())){
                str= drCaseVOBean.getDoctorOrder();
            }else {
                if("月".equals(drCaseVOBean.getRevisitDateUnit())){
                    str= getTrimStr("下次复诊时间：",drCaseVOBean.getRevisitNumber() +"个"+drCaseVOBean.getRevisitDateUnit(),"后")+
                         getTrimStr( "", drCaseVOBean.getDoctorOrder(),"");
                }else {
                    str= getTrimStr("下次复诊时间：",drCaseVOBean.getRevisitNumber() +drCaseVOBean.getRevisitDateUnit(),"后")+
                         getTrimStr( "", drCaseVOBean.getDoctorOrder(),"");
                }
            }
            tv_doctor_advice.setText(clearEnd(str));
        }
        //展示医生填写信息
        if(haveDoctorEdit){
            ll_doctor_edit.setVisibility(View.VISIBLE);
        }
        //展示图片
        List<ImgListBean> imgList = drCaseVOBean.getImgList();
        ArrayList<String> stringList = new ArrayList<>();
        if(imgList!=null&&imgList.size()>0){
            for (ImgListBean imgListBean:imgList){
                stringList.add(imgListBean.getImgUrl());
            }
            fillPicWidget(ll_doctor_pic,rv_doctor_pic,stringList,"");
        }
    }

    /**
     * 填写旧的诊疗记录
     */
    private void fillOldRecord() {
        RecordVOBean recordVOBean = (RecordVOBean) mDrRecordVOBean.getMdicalRecordVO();
        final ArrayList<String> imgList = (ArrayList<String>) recordVOBean.getImgList();
        String record = recordVOBean.getRecord();
        DoctorDesVOBean doctorDesVO = recordVOBean.getDoctorDesVO();
        if(doctorDesVO!=null){
            fillBaseRecord(doctorDesVO);
            tv_desc_title.setText("诊疗记录");
            fillBaseRecordWidget(ll_desc,tv_desc,record,"");
            ll_self_diag.setVisibility(View.GONE);
            if(haveBaseRecord){
                ll_base_record.setVisibility(View.VISIBLE);
            }
        }else {
            fillWidget(ll_record,tv_record,record,"");
        }
        fillPicWidget(ll_doctor_pic,rv_doctor_pic,imgList,"");
    }

    /**
     * 填写基本病情
     * @param doctorDesVO
     */
    private void fillBaseRecord(DoctorDesVOBean doctorDesVO){
        if(TextUtils.isEmpty(doctorDesVO.getMaritalStatus())){
            ll_marriage.setVisibility(View.GONE);
        }else {
            haveBaseRecord = true;
            ll_marriage.setVisibility(View.VISIBLE);
            if("0".equals(doctorDesVO.getMaritalStatus())){
                tv_marriage.setText("未婚");
            }else if("1".equals(doctorDesVO.getMaritalStatus())){
                tv_marriage.setText("已婚");
            }
        }
        fillBaseRecordWidget(ll_height,tv_height,doctorDesVO.getHeight(),"cm");
        fillBaseRecordWidget(ll_weight,tv_weight,doctorDesVO.getWeight(),"kg");
        ll_pregnancy.setVisibility(View.GONE);//无孕期
        fillBaseRecordWidget(ll_drink,tv_drink,doctorDesVO.getDrinkHistory(),"");
        fillBaseRecordWidget(ll_drug_allergy,tv_drug_allergy,doctorDesVO.getAllergy(),"");
        fillBaseRecordWidget(ll_post_history,tv_post_history,doctorDesVO.getPastDisease(),"");
        fillBaseRecordWidget(ll_family_history,tv_family_history,doctorDesVO.getFamilyHistory(),"");
        fillBaseRecordWidget(ll_heredity_history,tv_heredity_history,doctorDesVO.getHereditaryDisease(),"");
        fillBaseRecordWidget(ll_smoke,tv_smoke,doctorDesVO.getSmokeHistory(),"");
    }

    /**
     * 填写基本病情的控件
     * @param viewGroup
     * @param textView
     * @param str
     * @param unit
     */
    private void fillBaseRecordWidget(ViewGroup viewGroup, TextView textView, String str, String unit){
        if(TextUtils.isEmpty(str)){
            viewGroup.setVisibility(View.GONE);
        }else {
            haveBaseRecord = true;
            viewGroup.setVisibility(View.VISIBLE);
            textView.setText(str+unit);
        }
    }

    /**
     * 填充控件ui
     * @param viewGroup
     * @param textView
     * @param str
     * @param unit
     */
    private void fillWidget(ViewGroup viewGroup, TextView textView, String str, String unit){
        if(TextUtils.isEmpty(str)){
            viewGroup.setVisibility(View.GONE);
        }else {
            viewGroup.setVisibility(View.VISIBLE);
            textView.setText(str+unit);
        }
    }

    /**
     * 填写医生输入的控件
     * @param viewGroup
     * @param textView
     * @param str
     * @param unit
     */
    private void fillDoctorEditWidget(ViewGroup viewGroup, TextView textView, String str, String unit){
        if(TextUtils.isEmpty(str)){
            viewGroup.setVisibility(View.GONE);
        }else {
            haveDoctorEdit =true;
            viewGroup.setVisibility(View.VISIBLE);
            textView.setText(str+unit);
        }
    }

    /**
     * 填充图片控件
     * @param viewGroup
     * @param rv
     * @param prescriptionListBeans
     */
    private void fillPicWidget(ViewGroup viewGroup,RecyclerView rv,List<PrescriptionListBean> prescriptionListBeans){
        ArrayList<String> imgList = new ArrayList<>();
        if(prescriptionListBeans!=null&&prescriptionListBeans.size()>0){
            for(PrescriptionListBean prescriptionListBean:prescriptionListBeans){
                imgList.add(prescriptionListBean.getImgUrl());
            }
            fillPicWidget(viewGroup,rv,imgList,"");
        }
    }

    /**
     * 填充图片控件
     * @param viewGroup
     * @param rv
     * @param strings
     * @param recomId
     */
    private void fillPicWidget(ViewGroup viewGroup, RecyclerView rv, final ArrayList<String> strings, final String recomId){
        if(strings!=null&&strings.size()>0){
            viewGroup.setVisibility(View.VISIBLE);
            //此设置优化recyclerview
            rv.setHasFixedSize(true);
            //设置recyclerview的布局方式
            rv.setLayoutManager(new GridLayoutManager(this, 4));
            //设置适配器
            ImageAdapter imageAdapter = new ImageAdapter(this,strings);
            imageAdapter.setOnItemClickListener(new ImageAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(int position) {
                    if(TextUtils.isEmpty(recomId)){
                        ToJumpHelp.toJumpChatImageShowActivity(XD_MedicalRecordDetailActivity.
                                this, strings,position);
                    }else {
                        ToJumpHelp.toJumpRecommendDetailActivity(XD_MedicalRecordDetailActivity
                                .this,recomId,mDrRecordVOBean.getPatientId());
                    }
                }
            });
            rv.setAdapter(imageAdapter);
        }
    }

    /**
     * 拼接自诊结果
     * @param acmResult
     * @return
     */
    private String getAcmStr(AmcResultBean acmResult) {
        String acm ="";
        if(acmResult!=null){
            acm = getTrimStr(acm,acmResult.getInquirySymptom(),"");
            List<ConclusionVOBean> conclusions = acmResult.getConclusions();
            if(conclusions!=null){
                for(ConclusionVOBean conclusionVOBean:conclusions){
                    if(conclusions!=null){
                        acm = getTrimStr(acm,conclusionVOBean.getTitle(),"");
                        acm = getTrimStr(acm,conclusionVOBean.getContent(),"");
                    }
                }
            }
        }
        return clearEnd(acm);
    }

    private String getTrimStr(String str,String values,String unit){
        String s ="";
        s +=TextUtils.isEmpty(values)? "":str+values+unit+"\n";
        return s;
    }

    private String clearEnd(String str){
        while (str.endsWith("\n")){
            str = UtilString.getStringWithoutLast(str,"\n");
        }
        return str;
    }


    @Override
    public void listeners() {
        tv_creat.setOnClickListener(this);
        tv_next.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_creat://新建病历
                ToJumpHelp.toJumpEditMedicalRecordActivity(this,null,mDrRecordVOBean.getPatientId(),haveDrug);
                break;
            case R.id.tv_next://完善病历
                ToJumpHelp.toJumpEditMedicalRecordActivity(this,mDrRecordVOBean,null, haveDrug);
                break;
        }
        super.onClick(v);
    }
}
