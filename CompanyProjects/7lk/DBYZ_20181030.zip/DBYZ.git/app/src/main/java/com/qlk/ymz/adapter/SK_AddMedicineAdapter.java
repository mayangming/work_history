package com.qlk.ymz.adapter;

import android.app.Activity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.YR_AllMedicineClassActivity;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;

import java.util.List;

/**
 * 搜索结果的适配器
 */
public class SK_AddMedicineAdapter extends XCBaseAdapter<DrugBean> {
    private int intentFlag;


    public SK_AddMedicineAdapter(Activity context, List<DrugBean> list) {
        super(context, list);
        intentFlag = context.getIntent().getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,0);
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        final DrugBean bean = list.get(i);

        ViewHolder viewHolder;
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.sk_l_adapter_search_medicine_item, null);
            viewHolder = new ViewHolder(view);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();

        }
        if (list.size() - 1 == i) {
            viewHolder.line.setVisibility(View.GONE);
        } else {
            viewHolder.line.setVisibility(View.VISIBLE);
        }

        viewHolder.checkBox.setTag(bean);
        viewHolder.sk_id_medichine_item_name.setText(bean.getManufacturer());

        // 是否推荐商品（1 是 0否）
        if("1".equals(bean.getIsRecommend())){
            view.setBackgroundResource(R.drawable.sk_dd_selector_img_red_fff4ee);
            viewHolder.sk_id_medichine_item_recommend.setVisibility(View.VISIBLE);
        }else {
            view.setBackgroundResource(R.drawable.sk_dd_selector_img_gray_eeeeee);
            viewHolder.sk_id_medichine_item_recommend.setVisibility(View.GONE);
        }
        // 显示库存数量
        viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.VISIBLE);
        try {
            if(Integer.parseInt(bean.getStockNum()) <= 99)
                viewHolder.sk_id_medichine_item_stock_num.setText("剩余" + bean.getStockNum() + "件");
            else
                viewHolder.sk_id_medichine_item_stock_num.setText("剩余99+件");
        }catch (Exception e){e.printStackTrace();}

        // 是否缺货，1 是，0 否
        if ("1".equals(bean.getIsShort())) {
            // 显示缺货view
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.GONE);
        } else {
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.GONE);
        }

        // 是否为预售，1 是，0 否
        if ("1".equals(bean.getIsPresell())) {
            // 显示预售view，隐藏库存状态
            viewHolder.sk_id_medichine_item_presell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    XCApplication.base_log.shortToast(bean.getPresellInfo());
                }
            });
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_item_presell.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.GONE);
        } else {
            viewHolder.sk_id_medichine_item_presell.setVisibility(View.GONE);
        }

        // 是否已经下架  （true：否；false：是）
        if (bean.isSale()) {
            viewHolder.sk_id_medichine_item_sale_ll.setVisibility(View.GONE);
        } else {
            // 已下架，隐藏库存状态
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_item_sale_ll.setVisibility(View.VISIBLE);
        }

        viewHolder.sk_id_medichine_change_price.setTag(bean);
        if(bean.isModified()){
            viewHolder.sk_id_medichine_change_price.setText("已调价");
        }else {
            viewHolder.sk_id_medichine_change_price.setText("调价");
        }

        // 获取调价后的价格，用完后情况静态值
        if(!TextUtils.isEmpty(DrugBean.drug_id)
                && bean.getId().equals(DrugBean.drug_id)
                && !TextUtils.isEmpty(DrugBean.drug_price)){
            bean.setSalePrice(DrugBean.drug_price);
            bean.setModified(true);
            viewHolder.sk_id_medichine_change_price.setText("已调价");
            DrugBean.drug_id = "";
            DrugBean.drug_price = "";
        }

        viewHolder.sk_id_medichine_item_common_name.setText(bean.getName());
        XCApplication.displayImage(bean.getImage(), viewHolder.sk_id_medichine_item_img);
        viewHolder.sk_id_medichine_item_pprice.setText(bean.getSalePrice());
        if (0 > bean.getAddNum()) {
            viewHolder.sk_id_medichine_item_addnum.setText(0 + "个医生已经添加");
        } else {
            viewHolder.sk_id_medichine_item_addnum.setText(bean.getAddNum() + "个医生已经添加");
        }

        // 是否显示小七指数或市场积分,0：不显示，1小七指数、2市场积分 ,3：显示病历数据收集
        if ("0".equals(bean.getShowCommission())) {
            viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.GONE);
        } else if("2".equals(bean.getShowCommission())){
            viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medicine_drcommission.setText(bean.getMarketPoint());
            viewHolder.sk_id_medicine_point_name.setText(context.getResources().getText(R.string.medicine_MarketPoint));

        }else if("1".equals(bean.getShowCommission())){
            viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medicine_drcommission.setText(bean.getDrCommission());
            viewHolder.sk_id_medicine_point_name.setText(context.getResources().getText(R.string.medicine_commission));
        }
        if("1".equals(bean.getShowRecomCollect())){
            viewHolder.sk_id_medichine_item_collect.setVisibility(View.VISIBLE);
        }else {
            viewHolder.sk_id_medichine_item_collect.setVisibility(View.GONE);
        }
        viewHolder.sk_id_medichine_item_collect.setTag(bean);

        // 是否显示调价按钮
        if(bean.getModifyFlag()){
            viewHolder.sk_id_medichine_change_price.setVisibility(View.VISIBLE);
        }else {
            viewHolder.sk_id_medichine_change_price.setVisibility(View.GONE);
        }

        // 我的药房
        if(0 == intentFlag){
            // 是否已经添加到常用药
            if (bean.isAdded()) {
                viewHolder.checkBox.setClickable(false);
                viewHolder.checkBox.setBackgroundResource(R.drawable.xd_gray_round_shape_2);
                viewHolder.checkBox.setTextColor(context.getResources().getColor(R.color.c_gray_7b7b7b));
                viewHolder.checkBox.setText("已加入常用药");
            } else {
                viewHolder.checkBox.setClickable(true);
                viewHolder.checkBox.setBackgroundResource(R.drawable.xd_red_round_shape_2);
                viewHolder.checkBox.setTextColor(context.getResources().getColor(R.color.c_white_ffffff));
                viewHolder.checkBox.setText("加入常用药");
            }
            // 我的药房 常用处方详情页
        }else if(1 == intentFlag){
            if (null != RecomMedicineHelper.getInstance().getCommonRecipe().getCheckMap().get(bean.getId())) {
                viewHolder.checkBox.setClickable(false);
                viewHolder.checkBox.setBackgroundResource(R.drawable.xd_gray_round_shape_2);
                viewHolder.checkBox.setTextColor(context.getResources().getColor(R.color.c_gray_7b7b7b));
                viewHolder.checkBox.setText("已加入常用处方");
            } else {
                viewHolder.checkBox.setClickable(true);
                viewHolder.checkBox.setBackgroundResource(R.drawable.xd_red_round_shape_2);
                viewHolder.checkBox.setTextColor(context.getResources().getColor(R.color.c_white_ffffff));
                viewHolder.checkBox.setText("加入常用处方");
            }
            // 推荐用药 带药箱
        }else if(2 == intentFlag){
            if (null != RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getCheckDrugMap().get(bean.getId())) {
                viewHolder.checkBox.setBackgroundResource(R.drawable.xd_white_red_shape_2);
                viewHolder.checkBox.setTextColor(context.getResources().getColor(R.color.c_f84b62));
                viewHolder.checkBox.setText("移出处方笺");
            } else {
                viewHolder.checkBox.setBackgroundResource(R.drawable.xd_red_round_shape_2);
                viewHolder.checkBox.setTextColor(context.getResources().getColor(R.color.c_white_ffffff));
                viewHolder.checkBox.setText("加入处方笺");
            }

            // 推荐用药 常用处方详情页
        }else if(3 == intentFlag){
            if (null != RecomMedicineHelper.getInstance().getCommonRecipe().getCheckMap().get(bean.getId())) {
                viewHolder.checkBox.setClickable(false);
                viewHolder.checkBox.setBackgroundResource(R.drawable.xd_gray_round_shape_2);
                viewHolder.checkBox.setTextColor(context.getResources().getColor(R.color.c_gray_7b7b7b));
                viewHolder.checkBox.setText("已加入常用处方");
            } else {
                viewHolder.checkBox.setClickable(true);
                viewHolder.checkBox.setBackgroundResource(R.drawable.xd_red_round_shape_2);
                viewHolder.checkBox.setTextColor(context.getResources().getColor(R.color.c_white_ffffff));
                viewHolder.checkBox.setText("加入常用处方");
            }

            // 推荐用药 处方笺页
        }else if(4 == intentFlag){
            if(null != RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getCheckDrugMap().get(bean.getId())) {
                viewHolder.checkBox.setClickable(false);
                viewHolder.checkBox.setBackgroundResource(R.drawable.xd_gray_round_shape_2);
                viewHolder.checkBox.setTextColor(context.getResources().getColor(R.color.c_gray_7b7b7b));
                viewHolder.checkBox.setText("已加入处方笺");
            } else {
                viewHolder.checkBox.setClickable(true);
                viewHolder.checkBox.setBackgroundResource(R.drawable.xd_red_round_shape_2);
                viewHolder.checkBox.setTextColor(context.getResources().getColor(R.color.c_white_ffffff));
                viewHolder.checkBox.setText("加入处方笺");
            }
        }

        return view;
    }

    SK_AddMedicineAdapterAction skAddMedicineAdapterAction;

    public void setOnAddMedicineAdapterAction(SK_AddMedicineAdapterAction skAddMedicineAdapterAction) {
        this.skAddMedicineAdapterAction = skAddMedicineAdapterAction;
    }

    public interface SK_AddMedicineAdapterAction{
        void onAddBoxAction(View v);
    }

    /**
     * ViewHolder类
     */
    private class ViewHolder {
        /**
         * 勾选按钮
         */
        private Button checkBox;
        /**
         * 调价按钮
         */
        private Button sk_id_medichine_change_price;
        /**
         * 药品图片
         */
        private ImageView sk_id_medichine_item_img;
        /**
         * 公司名字
         */
        private TextView sk_id_medichine_item_name;
        /**
         * 药品名 + （常用名）
         */
        private TextView sk_id_medichine_item_common_name;
        /**
         * 价格
         */
        private TextView sk_id_medichine_item_pprice;
        /**
         * 是否在销售的浮层
         */
        private LinearLayout sk_id_medichine_item_sale_ll;

        /**
         * 加入药房按钮
         */
        private TextView sk_id_medichine_item_addnum;
        LinearLayout sk_id_medicine_drcommission_ll;
        TextView sk_id_medicine_drcommission;
        /**
         * 预售图片
         */
        public ImageView sk_id_medichine_item_presell;
        /**
         * 库存数量
         */
        public TextView sk_id_medichine_item_stock_num;
        /**
         * 无货标识
         */
        public ImageView sk_id_medichine_item_short_iv;
        /**
         * 小七推荐
         */
        public ImageView sk_id_medichine_item_recommend;
        public TextView sk_id_medicine_point_name;
        /**
         * 病历收集
         */
        public ImageView sk_id_medichine_item_collect;
        /** 底部线 */
        View line;

        ViewHolder(View convertView) {
            checkBox = (Button) convertView.findViewById(R.id.sk_id_medichine_cb);
            sk_id_medichine_change_price = (Button) convertView.findViewById(R.id.sk_id_medichine_change_price);
            sk_id_medichine_item_img = (ImageView) convertView.findViewById(R.id.sk_id_medichine_item_img);
            sk_id_medichine_item_name = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_name);
            sk_id_medichine_item_common_name = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_common_name);
            sk_id_medichine_item_pprice = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_pprice);
            sk_id_medichine_item_addnum = (TextView) convertView.findViewById(R.id.sk_id_medichine_item_addnum);
            sk_id_medichine_item_sale_ll = (LinearLayout) convertView.findViewById(R.id.sk_id_medichine_item_sale_ll);
            sk_id_medicine_drcommission_ll = (LinearLayout) convertView.findViewById(R.id.sk_id_medicine_drcommission_ll);
            sk_id_medicine_drcommission = (TextView) convertView.findViewById(R.id.sk_id_medicine_drcommission);
            sk_id_medichine_item_presell = (ImageView)convertView.findViewById(R.id.sk_id_medichine_item_presell);
            sk_id_medichine_item_stock_num = (TextView)convertView.findViewById(R.id.sk_id_medichine_item_stock_num);
            sk_id_medichine_item_short_iv = (ImageView)convertView.findViewById(R.id.sk_id_medichine_item_short_iv);
            sk_id_medichine_item_recommend = (ImageView) convertView.findViewById(R.id.sk_id_medichine_item_recommend);
            sk_id_medichine_item_collect = (ImageView) convertView.findViewById(R.id.sk_id_medichine_item_collect);
            line = convertView.findViewById(R.id.line);
            sk_id_medicine_point_name = (TextView) convertView.findViewById(R.id.sk_id_medicine_point_name);
            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(skAddMedicineAdapterAction != null){
                        skAddMedicineAdapterAction.onAddBoxAction(v);
                    }
                }
            });

            sk_id_medichine_change_price.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DrugBean bean = (DrugBean) v.getTag();
                    DrugBean.drug_id = bean.getId();
                    if(!UtilCollection.isBlank(bean.getSkus()))
                        ToJumpHelp.toJumpPriceCalculatorActivity((Activity) context,bean.getSkuId());
                }
            });
            sk_id_medichine_item_collect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DrugBean bean = (DrugBean) v.getTag();
                    UtilNativeHtml5.toJumpSunlightPage(context,bean.getId());
                }
            });
        }
    }
}
