package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.view.XCNoScrollListview;

/**
 * 聊天详情  医生 纯文本消息
 */
public class XC_ChatLeftBuyMedicineHolder extends XC_ChatLeftBaseHolder {

    public XCNoScrollListview id_left_medichine_patient_listview;
    public TextView id_left_patient_medicine_confirm,left_show_ellipsis;

    public TextView totalNum;

    public XC_ChatLeftBuyMedicineHolder(View convertView) {
        super(convertView);
        id_left_medichine_patient_listview = (XCNoScrollListview) convertView.findViewById(R.id.id_left_medichine_patient_listview);
        id_left_patient_medicine_confirm = (TextView) convertView.findViewById(R.id.id_left_patient_medicine_confirm);

        totalNum = (TextView) convertView.findViewById(R.id.totalNum);
        left_show_ellipsis = (TextView) convertView.findViewById(R.id.left_show_ellipsis);
    }
}