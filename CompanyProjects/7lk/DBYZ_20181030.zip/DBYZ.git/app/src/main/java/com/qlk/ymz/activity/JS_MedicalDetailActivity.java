package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.MedicalDetailBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * 病历档案详情页
 * @author 徐金山
 * @version 1.2.0
 */
public class JS_MedicalDetailActivity extends DBActivity {
    // ********************适配数据********************
    /** 病历档案详情信息对象 */
    private MedicalDetailBean medicalDetailBean = new MedicalDetailBean();

    // ********************变量********************
    /** 患者ID */
    private String patientId = "";
    /** 病历ID */
    private String caseId = "";

    /**
     * 医嘱控件列表
     */
    private ArrayList<ImageView> doctorAdviceViews = new ArrayList<ImageView>();
    /**
     * 处方单控件列表
     */
    private ArrayList<ImageView> recipeListViews = new ArrayList<ImageView>();
    /**
     * 检验单控件列表
     */
    private ArrayList<ImageView> checkListViews = new ArrayList<ImageView>();

    // ********************页面控件********************
    /** 页面体布局 */
    private ScrollView sv_pageBodyLayout;

    /**
     * 返回按钮
     */
    private ImageView sx_id_title_left;

    /**
     * 病情描述
     */
    private TextView tv_medicalRecordInfo;

    /**
     * 医嘱（布局）
     */
    private LinearLayout ll_doctor_advice;
    /**
     * 医嘱图片01
     */
    private ImageView iv_doctor_advice_image01;
    /**
     * 医嘱图片02
     */
    private ImageView iv_doctor_advice_image02;
    /**
     * 医嘱图片03
     */
    private ImageView iv_doctor_advice_image03;
    /**
     * 医嘱图片04
     */
    private ImageView iv_doctor_advice_image04;

    /**
     * 处方单（布局）
     */
    private LinearLayout ll_recipe_list;
    /**
     * 处方单图片01
     */
    private ImageView iv_recipe_list_image01;
    /**
     * 处方单图片02
     */
    private ImageView iv_recipe_list_image02;
    /**
     * 处方单图片03
     */
    private ImageView iv_recipe_list_image03;
    /**
     * 处方单图片04
     */
    private ImageView iv_recipe_list_image04;

    /**
     * 检验单（布局）
     */
    private LinearLayout ll_check_list;
    /**
     * 检验单图片01
     */
    private ImageView iv_check_list_image01;
    /**
     * 检验单图片02
     */
    private ImageView iv_check_list_image02;
    /**
     * 检验单图片03
     */
    private ImageView iv_check_list_image03;
    /**
     * 检验单图片04
     */
    private ImageView iv_check_list_image04;
    /**
     * 检验单图片05
     */
    private ImageView iv_check_list_image05;
    /**
     * 检验单图片06
     */
    private ImageView iv_check_list_image06;
    /**
     * 检验单图片07
     */
    private ImageView iv_check_list_image07;
    /**
     * 检验单图片08
     */
    private ImageView iv_check_list_image08;

    /**
     * 就诊时间
     */
    private TextView tv_time;
    /**
     * 就诊医院
     */
    private TextView tv_hospital;
    /**
     * 就诊科室
     */
    private TextView tv_department;
    /**
     * 医生
     */
    private TextView tv_doctor;

    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.js_activity_medical_detail);
        initData();
        super.onCreate(savedInstanceState);

        pricessBiz();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(JS_MedicalDetailActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        sx_id_title_left = (ImageView) findViewById(R.id.sx_id_title_left);
        ((TextView)findViewById(R.id.sx_id_title_center)).setText("病历详情");

        sv_pageBodyLayout = (ScrollView) findViewById(R.id.sv_pageBodyLayout);
        tv_medicalRecordInfo = (TextView) findViewById(R.id.tv_medicalRecordInfo);

        ll_doctor_advice = (LinearLayout) findViewById(R.id.ll_doctor_advice);
        iv_doctor_advice_image01 = (ImageView) findViewById(R.id.iv_doctor_advice_image01);
        iv_doctor_advice_image02 = (ImageView) findViewById(R.id.iv_doctor_advice_image02);
        iv_doctor_advice_image03 = (ImageView) findViewById(R.id.iv_doctor_advice_image03);
        iv_doctor_advice_image04 = (ImageView) findViewById(R.id.iv_doctor_advice_image04);
        doctorAdviceViews.add(iv_doctor_advice_image01);
        doctorAdviceViews.add(iv_doctor_advice_image02);
        doctorAdviceViews.add(iv_doctor_advice_image03);
        doctorAdviceViews.add(iv_doctor_advice_image04);

        ll_recipe_list = (LinearLayout) findViewById(R.id.ll_recipe_list);
        iv_recipe_list_image01 = (ImageView) findViewById(R.id.iv_recipe_list_image01);
        iv_recipe_list_image02 = (ImageView) findViewById(R.id.iv_recipe_list_image02);
        iv_recipe_list_image03 = (ImageView) findViewById(R.id.iv_recipe_list_image03);
        iv_recipe_list_image04 = (ImageView) findViewById(R.id.iv_recipe_list_image04);
        recipeListViews.add(iv_recipe_list_image01);
        recipeListViews.add(iv_recipe_list_image02);
        recipeListViews.add(iv_recipe_list_image03);
        recipeListViews.add(iv_recipe_list_image04);

        ll_check_list = (LinearLayout) findViewById(R.id.ll_check_list);
        iv_check_list_image01 = (ImageView) findViewById(R.id.iv_check_list_image01);
        iv_check_list_image02 = (ImageView) findViewById(R.id.iv_check_list_image02);
        iv_check_list_image03 = (ImageView) findViewById(R.id.iv_check_list_image03);
        iv_check_list_image04 = (ImageView) findViewById(R.id.iv_check_list_image04);
        iv_check_list_image05 = (ImageView) findViewById(R.id.iv_check_list_image05);
        iv_check_list_image06 = (ImageView) findViewById(R.id.iv_check_list_image06);
        iv_check_list_image07 = (ImageView) findViewById(R.id.iv_check_list_image07);
        iv_check_list_image08 = (ImageView) findViewById(R.id.iv_check_list_image08);
        checkListViews.add(iv_check_list_image01);
        checkListViews.add(iv_check_list_image02);
        checkListViews.add(iv_check_list_image03);
        checkListViews.add(iv_check_list_image04);
        checkListViews.add(iv_check_list_image05);
        checkListViews.add(iv_check_list_image06);
        checkListViews.add(iv_check_list_image07);
        checkListViews.add(iv_check_list_image08);

        tv_time = (TextView) findViewById(R.id.tv_time);
        tv_hospital = (TextView) findViewById(R.id.tv_hospital);
        tv_department = (TextView) findViewById(R.id.tv_department);
        tv_doctor = (TextView) findViewById(R.id.tv_doctor);

        sv_pageBodyLayout.setVisibility(View.INVISIBLE);
    }

    @Override
    public void listeners() {
        // 返回
        sx_id_title_left.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                myFinish();
            }
        });

        // 医嘱图片
        for (int i = 0; i < doctorAdviceViews.size(); i++) {
            final int finalI = i;
            doctorAdviceViews.get(i).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    int index = finalI;
                    Intent intent = new Intent(JS_MedicalDetailActivity.this, XC_ChatImageShowActivity.class); // TODO
                    intent.putExtra(XC_ChatImageShowActivity.PICTURES_KEY, medicalDetailBean.getAdviceList());
                    intent.putExtra(XC_ChatImageShowActivity.INDEX, index);
                    myStartActivity(intent);
                }
            });
        }

        // 处方单图片
        for (int i = 0; i < recipeListViews.size(); i++) {
            final int finalI = i;
            recipeListViews.get(i).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    int index = finalI;
                    Intent intent = new Intent(JS_MedicalDetailActivity.this, XC_ChatImageShowActivity.class);
                    intent.putExtra(XC_ChatImageShowActivity.PICTURES_KEY, medicalDetailBean.getPrescriptionList());
                    intent.putExtra(XC_ChatImageShowActivity.INDEX, index);
                    myStartActivity(intent);
                }
            });
        }

        // 检验单图片
        for (int i = 0; i < checkListViews.size(); i++) {
            final int finalI = i;
            checkListViews.get(i).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    int index = finalI;
                    Intent intent = new Intent(JS_MedicalDetailActivity.this, XC_ChatImageShowActivity.class);
                    intent.putExtra(XC_ChatImageShowActivity.PICTURES_KEY, medicalDetailBean.getCheckList());
                    intent.putExtra(XC_ChatImageShowActivity.INDEX, index);
                    myStartActivity(intent);
                }
            });
        }
    }

    /**
     * 获取上个页面透传过来的数据
     */
    private void initData() {
        Intent intent = getIntent();
        patientId = intent.getStringExtra("patientId");
        caseId = intent.getStringExtra("caseId");
    }

    private void trueProcess() {
        RequestParams params = new RequestParams();
        params.put("patientId", patientId); // 患者ID
        params.put("caseId", caseId); // 病历ID
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.medicalDetail), params, new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                sv_pageBodyLayout.setVisibility(View.VISIBLE);

                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                        XCJsonBean tempObj = jsonBeans.get(0);
                        medicalDetailBean.setId(tempObj.getString("id"));
                        medicalDetailBean.setDiscription(tempObj.getString("description"));

                        List<XCJsonBean> doctorAdviceList = tempObj.getList("adviceList");
                        int doctorAdviceListSize = doctorAdviceList.size();
                        for(int i=0; i<doctorAdviceListSize; i++) {
                            medicalDetailBean.getAdviceList().add(doctorAdviceList.get(i).getString("imgUrl"));
                        }

                        List<XCJsonBean> prescriptionList = tempObj.getList("prescriptionList");
                        int prescriptionListSize = prescriptionList.size();
                        for(int i=0; i<prescriptionListSize; i++) {
                            medicalDetailBean.getPrescriptionList().add(prescriptionList.get(i).getString("imgUrl"));
                        }

                        List<XCJsonBean> checkList = tempObj.getList("checkList");
                        int checkListSize = checkList.size();
                        for(int i=0; i<checkListSize; i++) {
                            medicalDetailBean.getCheckList().add(checkList.get(i).getString("imgUrl"));
                        }

                        medicalDetailBean.setVistingTime(tempObj.getString("vistingTime"));
                        medicalDetailBean.setHospital(tempObj.getString("hospital"));
                        medicalDetailBean.setDepartment(tempObj.getString("department"));
                        medicalDetailBean.setDoctor(tempObj.getString("doctor"));

                        setDataToViews();
                    }
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(JS_MedicalDetailActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 业务处理
     */
    private void pricessBiz() {
        // 真实处理
        trueProcess();
    }

    /**
     * 将数据设置到页面控件上
     */
    private void setDataToViews() {
        // 病情描述
        tv_medicalRecordInfo.setText(medicalDetailBean.getDiscription());

        // 医嘱
        ArrayList<String> doctorAdvice = medicalDetailBean.getAdviceList();
        int doctorAdvice_size = doctorAdvice.size();
        if (doctorAdvice_size > 0) {
            // 医嘱（布局）可见
            ll_doctor_advice.setVisibility(View.VISIBLE);

            // 所有图片控件不可见
            for (int i = 0; i < doctorAdviceViews.size(); i++) {
                doctorAdviceViews.get(i).setVisibility(View.INVISIBLE);
            }

            // 将图片设置到图片控件上
            for (int i = 0; i < doctorAdvice_size; i++) {
                if(i < doctorAdviceViews.size()) {
                    doctorAdviceViews.get(i).setVisibility(View.VISIBLE);
                    XCApplication.base_imageloader.displayImage(doctorAdvice.get(i), doctorAdviceViews.get(i));
                }
            }
        } else {
            // 医嘱（布局）不可见
            ll_doctor_advice.setVisibility(View.GONE);
        }

        // 处方单
        ArrayList<String> recipeList = medicalDetailBean.getPrescriptionList();
        int recipeList_size = recipeList.size();
        if (recipeList_size > 0) {
            // 处方单（布局）可见
            ll_recipe_list.setVisibility(View.VISIBLE);

            // 所有图片控件不可见
            for (int i = 0; i < recipeListViews.size(); i++) {
                recipeListViews.get(i).setVisibility(View.INVISIBLE);
            }

            // 将图片设置到图片控件上
            for (int i = 0; i < recipeList_size; i++) {
                if(i < recipeListViews.size()) {
                    recipeListViews.get(i).setVisibility(View.VISIBLE);
                    XCApplication.base_imageloader.displayImage(recipeList.get(i), recipeListViews.get(i));
                }
            }
        } else {
            ll_recipe_list.setVisibility(View.GONE);
        }

        // 检验单
        ArrayList<String> checkList = medicalDetailBean.getCheckList();
        int checkList_size = checkList.size();
        if (checkList_size > 0) {
            // 检验单（布局）可见
            ll_check_list.setVisibility(View.VISIBLE);

            // 所有图片控件不可见
            for (int i = 0; i < checkListViews.size(); i++) {
                checkListViews.get(i).setVisibility(View.INVISIBLE);
            }

            // 将图片设置到图片控件上
            for (int i = 0; i < checkList_size; i++) {
                if(i < checkListViews.size()) {
                    checkListViews.get(i).setVisibility(View.VISIBLE);
                    XCApplication.base_imageloader.displayImage(checkList.get(i), checkListViews.get(i));
                }
            }
        } else {
            ll_check_list.setVisibility(View.GONE);
        }

        // 就诊日期
        tv_time.setText(DateUtils.DateFormat(medicalDetailBean.getVistingTime()));

        // 就诊医院
        tv_hospital.setText(medicalDetailBean.getHospital());

        // 就诊科室
        tv_department.setText(medicalDetailBean.getDepartment());

        // 就诊医生
        tv_doctor.setText(medicalDetailBean.getDoctor());
    }

    @Override
    public void onNetRefresh() {

    }
}
