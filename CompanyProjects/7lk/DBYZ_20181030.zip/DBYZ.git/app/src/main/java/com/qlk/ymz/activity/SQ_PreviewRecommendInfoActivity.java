package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gdca.sdk.casign.model.GdcaCertModel;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.application.DBApplication;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.drCase.DrCaseVOBeanDb;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.fragment.XD_CasePreviewFragment;
import com.qlk.ymz.fragment.XD_RecipePreviewFragment;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.RecommendInfo;
import com.qlk.ymz.model.RecommendMedicineResultBean;
import com.qlk.ymz.model.SafeMedicationBean;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.ImgListBean;
import com.qlk.ymz.parse.Parse2SafeMedication;
import com.qlk.ymz.parse.Parser2RecomMedResultBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.ElectronicSignatureHelper;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.HospitalBackupsBeanSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.UtilInsertMsg2JsDb;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.UtilPackMsg;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.MedicalServiceFeeDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SQ_PreviewRecommendInfoActivity extends DBActivity{
    /** 标题 */
    private XCTitleCommonLayout title_bar;
    private TextView tv_medicition_send;
    /** tab布局*/
    private LinearLayout ll_tab;
    /** 病历tab*/
    private TextView tv_case;
    /** 处方*/
    private TextView tv_recipe;
    private RelativeLayout rl_click_here;
    private ImageView iv_edit;

    private XCBaseActivity mContext;//上下文对象

    private XD_CasePreviewFragment mXD_casePreviewFragment;
    private XD_RecipePreviewFragment mXD_recipePreviewFragment;

    private XC_PatientDrugInfo patientDrugInfo;
    private RecommendInfo recommendInfo;

    private MedicalServiceFeeDialog medicalServiceFeeDialog;

    private int mCurrentTab =1;//当前显示的tab  1,2
    public static String OpenTab = "openTab";
    /** tab1编辑的引导图片显示 */
    public String showCurrentTab1 = "showCurrentTab1";
    /** tab2编辑的引导图片显示 */
    public String showCurrentTab2 = "showCurrentTab2";

    /**
     * 电子签名签署监听
     */
    private ElectronicSignatureHelper.signListener signListener = new ElectronicSignatureHelper.signListener() {
        @Override
        public void onSuccess(String msg) {
            requestSendRecommendMedicine();
        }

        @Override
        public void onFail(String msg) {
            new YR_CommonDialog(SQ_PreviewRecommendInfoActivity.this,"电子签名异常，是否继续发送处方","继续发送","取消"){
                @Override
                public void confirmBtn() {
                    dismiss();
                }

                @Override
                public void cancelBtn() {
                    // 签署异常 强制推荐
                    patientDrugInfo.getChatModel().setForce(true);
                    requestSendRecommendMedicine();
                }
            }.show();
        }
    };

    /**
     * 启动预览病历和处方页面
     * @param activity 上一个页面的activity
     * @param openTab 打开页面时默认选中的tab 1：病历，2：处方
     */
    public static void launch(DBActivity activity,int openTab){
        Intent intent = new Intent(activity,SQ_PreviewRecommendInfoActivity.class);
        intent.putExtra(OpenTab,openTab);
        activity.myStartActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_preview_recommend);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SQ_PreviewRecommendInfoActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    protected void onResume() {
        super.onResume();
        setData();
    }

    private void setData() {
        DrCaseVOBean mDrCaseVOBean = (DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO();
        mXD_casePreviewFragment.setDrRecordVOBean(patientDrugInfo.getDrRecordVOBean());
        mXD_casePreviewFragment.initData();
        recommendInfo.setPatientName(mDrCaseVOBean.getName());
        recommendInfo.setPatientAge(mDrCaseVOBean.getAge());
        recommendInfo.setPatientAgeUnit(mDrCaseVOBean.getAgeUnit());
        recommendInfo.setDiagnosis(mDrCaseVOBean.getDiagnosis());
        recommendInfo.setPatientGender(mDrCaseVOBean.getGender());
        mXD_recipePreviewFragment.setRecommendInfo(recommendInfo);
        mXD_recipePreviewFragment.setDate(recommendInfo);
    }

    @Override
    public void initWidgets() {
        mContext = this;
        patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
        recommendInfo = patientDrugInfo.getRecommendInfo();

        title_bar = getViewById(R.id.title_bar);
        tv_medicition_send = getViewById(R.id.tv_medicition_send);
        title_bar.findViewById(R.id.line).setVisibility(View.GONE);

        ll_tab = getViewById(R.id.ll_tab);
        tv_case = getViewById(R.id.tv_case);
        tv_recipe = getViewById(R.id.tv_recipe);

        rl_click_here = getViewById(R.id.rl_click_here);
        iv_edit = getViewById(R.id.iv_edit);

        title_bar.setTitleCenter(true,"预览病历和处方");

        medicalServiceFeeDialog = new MedicalServiceFeeDialog(this);
        medicalServiceFeeDialog.getWindow().setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        medicalServiceFeeDialog.setSendBtnOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSave();
            }
        });

        mCurrentTab = getIntent().getIntExtra(OpenTab,1);
        mXD_casePreviewFragment = new XD_CasePreviewFragment();
        mXD_casePreviewFragment.setDrRecordVOBean(patientDrugInfo.getDrRecordVOBean());
        addFragment(R.id.xc_id_model_content,mXD_casePreviewFragment);
        mXD_recipePreviewFragment = new XD_RecipePreviewFragment();
        mXD_recipePreviewFragment.setRecommendInfo(recommendInfo);
        addFragment(R.id.xc_id_model_content,mXD_recipePreviewFragment);
        switchTab(mCurrentTab);

    }

    @Override
    public void listeners() {
        tv_medicition_send.setOnClickListener(this);
        tv_case.setOnClickListener(this);
        tv_recipe.setOnClickListener(this);
        rl_click_here.setOnClickListener(this);
        iv_edit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.tv_case:
                if(mCurrentTab ==2){
                    switchTab(1);
                    mCurrentTab = 1;
                    if(UtilSP.get(showCurrentTab1,true)) {
                        rl_click_here.setVisibility(View.VISIBLE);
                    }
                }
                break;
            case R.id.tv_recipe:
                if(mCurrentTab ==1){
                    switchTab(2);
                    mCurrentTab = 2;
                    if(UtilSP.get(showCurrentTab2,true)) {
                        rl_click_here.setVisibility(View.VISIBLE);
                    }
                }
                break;
            case R.id.tv_medicition_send:
                if(isFastClick()) return;
                send();
                break;
            case R.id.iv_edit:
                if(mCurrentTab == 1){
                   ToJumpHelp.toJumpEditMedicalRecordActivity(this);
                }else {
                    // 返回处方详情
                    SQ_RecommendActivity.launch(this);
                }
                break;
            case R.id.rl_click_here:
                if(mCurrentTab == 1){
                    UtilSP.put(showCurrentTab1,false);
                }else {
                    UtilSP.put(showCurrentTab2,false);
                }
                rl_click_here.setVisibility(View.GONE);
                break;
        }
    }

    private void switchTab(int tab) {
        switch (tab){
            case 1:
                showFragment(mXD_casePreviewFragment);
                hideFragment(mXD_recipePreviewFragment);
                ll_tab.setBackgroundResource(R.mipmap.case_tag_left_bg);
                tv_case.setTextColor(getResources().getColor(R.color.c_444444));
                tv_recipe.setTextColor(getResources().getColor(R.color.c_7f444444));
                if(UtilSP.get(showCurrentTab1,true)){
                    rl_click_here.setVisibility(View.VISIBLE);
                }else {
                    rl_click_here.setVisibility(View.GONE);
                }
                break;
            case 2:
                showFragment(mXD_recipePreviewFragment);
                hideFragment(mXD_casePreviewFragment);
                ll_tab.setBackgroundResource(R.mipmap.case_tag_right_bg);
                tv_recipe.setTextColor(getResources().getColor(R.color.c_444444));
                tv_case.setTextColor(getResources().getColor(R.color.c_7f444444));
                if(UtilSP.get(showCurrentTab2,true)){
                    rl_click_here.setVisibility(View.VISIBLE);
                }else {
                    rl_click_here.setVisibility(View.GONE);
                }
                break;
        }
    }

    @Override
    public void onNetRefresh() {

    }

    private void send(){
        //  要求备案
        if ("4".equals(UtilSP.getDoctorStatus())) {
            // 校验状态
            requestRecomCheck();
            return;
        }else if ("2".equals(UtilSP.getDoctorStatus())) {
            // 备案成功 查询电子签名
            getCertInfo();
            return;
        }
        if(UtilSP.isRecomSafe()) {
            requestSafeMedication();
        }else {
            uploadCaseImg();
        }
    }

    /**
     * 备案dialog
     * @param status 状态
     * @param text 对话框内容
     * @param forbidenRecom 是否禁止推药，（1：允许，2：禁止，0：无文案（历史数据）禁止推送，）
     */
    private void showSHospitalBackupsDialog(final int status, String text,final String forbidenRecom ) {
        if("0".equals(forbidenRecom)){
            text = "根据卫健委要求，也是为了保障您的处方行为真实有效，请提交互联网医院备案资料";
        }
        new YR_CommonDialog(this, text, "取消", "去备案") {
            @Override
            public void confirmBtn() {
                HospitalBackupsBeanSP.TO_ACTIVITY = NativeHtml5.RECOMMEND_DETAIL;
                UtilNativeHtml5.toJumpNativeH5(SQ_PreviewRecommendInfoActivity.this, UtilNativeHtml5.INTERNET_HOSPITAL_RECORD);
                dismiss();
            }

            @Override
            public void cancelBtn() {
                if(status == 4){
                    if("1".equals(forbidenRecom)){  // 允许推荐
                        // 推药
                        dismiss();

                    }else if("0".equals(forbidenRecom)){ // 旧版本处理
                        dismiss();
                        medicineFifterDialog(CommonConfig.RECOMMEND_PATH);
                    }else { // 禁止推荐
                        dismiss();
                    }
                }
            }
        }.show();
    }

    /**
     * 组建save接口请求json，提交给服务器
     */
    private JSONObject createJson(XC_PatientDrugInfo patientDrugInfo) {
        JSONObject recomData = new JSONObject();
        try {
            // 病历
            DrCaseVOBean mDrCaseVOBean = (DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO();
            // 诊断
            JSONArray diagnosis = new JSONArray();
            for (String s : ((DrCaseVOBean) patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getDiagnosisList()) {
                diagnosis.put(s);
            }
            JSONArray imgJSONArray = new JSONArray();
            for (String s : imgList) {
                imgJSONArray.put(s);
            }

            JSONObject caseParams = new JSONObject();
            caseParams.put("imgList", imgJSONArray);
            caseParams.put("diagnosisList",diagnosis);
            caseParams.put("patientId",mDrCaseVOBean.getPatientId());
            caseParams.put("patientName",mDrCaseVOBean.getName());
            caseParams.put("patientGender",mDrCaseVOBean.getGender());
            caseParams.put("age",mDrCaseVOBean.getAge());
            caseParams.put("ageUnit",mDrCaseVOBean.getAgeUnit());
            if(!TextUtils.isEmpty(mDrCaseVOBean.getMainComplaint())){
                caseParams.put("mainComplaint",mDrCaseVOBean.getMainComplaint());
            }
            if(!TextUtils.isEmpty(patientDrugInfo.getDrRecordVOBean().getRelation())){
                caseParams.put("relation",patientDrugInfo.getDrRecordVOBean().getRelation());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getPresentDisease())){
                caseParams.put("presentDisease",mDrCaseVOBean.getPresentDisease());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getPastHistory())){
                caseParams.put("pastHistory",mDrCaseVOBean.getPastHistory());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getTemperature())){
                caseParams.put("temperature",mDrCaseVOBean.getTemperature());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getWeight())){
                caseParams.put("weight",mDrCaseVOBean.getWeight());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getHeartRete())){
                caseParams.put("heartRete",mDrCaseVOBean.getHeartRete());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getSystolic())){
                caseParams.put("systolic",mDrCaseVOBean.getSystolic());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getDiastole())){
                caseParams.put("diastole",mDrCaseVOBean.getDiastole());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getMoreExamin())){
                caseParams.put("moreExamin",mDrCaseVOBean.getMoreExamin());
            }
            if("2".equals(mDrCaseVOBean.getTemplateType())){
                if(!TextUtils.isEmpty(mDrCaseVOBean.getHbvDna())){
                    caseParams.put("hbvDna",mDrCaseVOBean.getHbvDna());
                }
                if(!TextUtils.isEmpty(mDrCaseVOBean.getAlt())){
                    caseParams.put("alt",mDrCaseVOBean.getAlt());
                }
                if(!TextUtils.isEmpty(mDrCaseVOBean.getAst())){
                    caseParams.put("ast",mDrCaseVOBean.getAst());
                }
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getDiagnosis())){
                caseParams.put("diagnosis",mDrCaseVOBean.getDiagnosis());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getTemplateType())){
                caseParams.put("templateType",mDrCaseVOBean.getTemplateType());
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getDoctorOrder())){
                caseParams.put("doctorOrder",mDrCaseVOBean.getDoctorOrder());
            }
            if("1".equals(mDrCaseVOBean.getRevisitFalg())){
                caseParams.put("revisitNumber",mDrCaseVOBean.getRevisitNumber());
                caseParams.put("revisitDateUnit",mDrCaseVOBean.getRevisitDateUnit());
            }
            caseParams.put("revisitFalg",mDrCaseVOBean.getRevisitFalg());
            recomData.put("caseParams",caseParams);

            UserPatient userPatient = patientDrugInfo.getChatModel().getUserPatient();
            if(!TextUtils.isEmpty(patientDrugInfo.getRecommendInfo().getOriginRecom())){//3.4新加续方来源
                recomData.put("originRecom",patientDrugInfo.getRecommendInfo().getOriginRecom());
            }
            recomData.put("patientAge", mDrCaseVOBean.getAge());
            recomData.put("patientAgeUnit", mDrCaseVOBean.getAgeUnit());
            recomData.put("patientGender", mDrCaseVOBean.getGender());
            recomData.put("patientId", userPatient.getPatientId());
            recomData.put("patientName", mDrCaseVOBean.getName());
            recomData.put("timestamp", System.currentTimeMillis()); // 请求时间戳
            // 患者自主购药id ，主动推荐传 0
            if ("".equals(patientDrugInfo.getChatModel().getRequireId())
                    || "0".equals(patientDrugInfo.getChatModel().getRequireId())) {
                recomData.put("requireId", 0);
                recomData.put("type", 1);  //推荐类型(1:普通推荐,2:求药推荐)

            } else {
                recomData.put("requireId", patientDrugInfo.getChatModel().getRequireId());
                recomData.put("type", 2);
            }
            recomData.put("diagnosis", diagnosis);
            // collectStatus (integer, optional): 病历数据收集状态 1：同意， 2：不同意，3：不提示，4：暂不同意
            recomData.put("collectStatus", medicalServiceFeeDialog.getCollectStatus());

            JSONArray drugItems = getDrugInfoJsonArray();
            recomData.put("items", drugItems);

        } catch (Exception e) {
            e.printStackTrace();
            XCApplication.base_log.debugShortToast("创建json异常");
        }
        return recomData;

    }
    @NonNull
    private JSONArray getDrugInfoJsonArray(){
        List<DrugBean> drugBeanList = patientDrugInfo.getList();
        JSONArray drugItems = new JSONArray();
        try{
            JSONObject drugItem;
            for (DrugBean bean : drugBeanList) {
                drugItem = new JSONObject();
                drugItem.put("backup", bean.getMedicineUsageBean().getBakUp());
                drugItem.put("commonName", bean.getCommonName());
                drugItem.put("productId", bean.getId());
                drugItem.put("productName", bean.getName());
                drugItem.put("quantity", bean.getMedicineUsageBean().getQuantity());
                drugItem.put("skuId", bean.getMedicineUsageBean().getSkuId());
                drugItem.put("usage", bean.getMedicineUsageBean().getUsages());
                drugItem.put("dosageCount", bean.getMedicineUsageBean().getDosageCount());
                drugItem.put("dosageCycle", bean.getMedicineUsageBean().getDosageCycle());
                drugItem.put("dosageCycleUnit", bean.getMedicineUsageBean().getDosageCycleUnit());
                drugItem.put("drugCycle", bean.getMedicineUsageBean().getDrugCycle());
                drugItem.put("drugCycleUnit", bean.getMedicineUsageBean().getDrugCycleUnit());
                drugItem.put("eachDosageCount", bean.getMedicineUsageBean().getEachDosageCount());
                drugItem.put("eachDoseUnit", bean.getMedicineUsageBean().getEachDoseUnit());
                drugItem.put("quantityUnit", bean.getMedicineUsageBean().getQuantityUnit());
                drugItem.put("usageMethod", bean.getMedicineUsageBean().getUsageMethod());
                drugItem.put("usageTime", bean.getMedicineUsageBean().getUsageTime());
                drugItem.put("containUsageDetail", bean.isContainUsageDetail());
                drugItems.put(drugItem);
            }
        }catch (Exception e){e.printStackTrace();}
        return drugItems;
    }

    /** 保存患者图片的地址 */
    private List<String> imgList = new ArrayList<>();
    /**
     * 上传图片
     */
    private void uploadCaseImg() {
        List<ImgListBean> mImageList = ((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getImgList();
        if (!UtilCollection.isBlank(mImageList)) {
            try {
                imgList.clear();
                List<File> imageList = new ArrayList<>();
                for(int i = 0 ; i < mImageList.size(); i ++ ){
                    if(!mImageList.get(i).getImgUrl().contains("http")) {
                        imageList.add(new File(mImageList.get(i).getImgUrl()));
                    }else {
                        imgList.add(mImageList.get(i).getImgUrl());
                    }
                }
                if(UtilCollection.isBlank(imageList)){
                    // 阳光化状态  1：否；2：是
                    if("2".equals(UtilSP.getDoctorSunshine())){
                        requestCollectPrompt();
                    }else {
                        requestSave();
                    }
                    return;
                }
                List<File> uploadFiles = UtilFile.ChangeImgsToUploadFiles(imageList);
                File[] pics = new File[uploadFiles.size()];
                RequestParams params = new RequestParams();
                params.put("file", uploadFiles.toArray(pics));
                XCHttpAsyn.postAsyn(true,this, AppConfig.getRecordUrl(AppConfig.UPLOAD_CASE_IMG), params,
                        new XCHttpResponseHandler()  {
                            @Override
                            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                                super.onSuccess(code, headers, arg2);
                                showContentLayout();
                                if (result_boolean) {
                                    imgList.addAll(result_bean.getStringList("data"));
                                    // 阳光化状态  1：否；2：是
                                    if("2".equals(UtilSP.getDoctorSunshine())){
                                        requestCollectPrompt();
                                    }else {
                                        requestSave();
                                    }
                                }
                            }

                            @Override
                            public void onFinish() {
                                // super.onFinish();
                                // 处理code操作
                                if (!GeneralReqExceptionProcess.checkCode(SQ_PreviewRecommendInfoActivity.this,
                                        getCode(), getMsg())) {
                                    XCHttpAsyn.closeLoadingDialog();
                                }
                            }
                        });
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }else {
            // 阳光化状态  1：否；2：是
            if("2".equals(UtilSP.getDoctorSunshine())){
                requestCollectPrompt();
            }else {
                requestSave();
            }
        }

    }
    /**
     * 创建推荐单
     */
    public void requestSave() {
        JSONObject jsonObject = createJson(patientDrugInfo);
        XCHttpAsyn.postAsync(true,true,mContext, AppConfig.getTuijianUrl(AppConfig.recomSave+ "?doctorId="+UtilSP.getUserId()+
                        "&token="+UtilSP.getUserToken()),
                jsonObject.toString(), new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        try {

                            if (result_boolean && !mContext.isDestroy) {

                                // eSignSerial (Array[string]): 电子签名签署单号
                                // recomId (integer): 推荐ID
                                // changedRemarkName (boolean): 是否更新备注名

                                if (result_bean.getList("data").get(0).getBoolean("changedRemarkName"))
                                    // 2.9版本 更新患者备注名
                                    requestPatientSimple();

                                patientDrugInfo.getChatModel().setRecommandId(result_bean.getList("data").get(0).getString("recomId"));
                                patientDrugInfo.getChatModel().getChatModelMedicalRecord().setMedicalRecordId(result_bean.getList("data").get(0).getString("recordId"));
                                DrCaseVOBean mDrCaseVOBean = (DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO();
                                patientDrugInfo.getChatModel().getChatModelMedicalRecord().setAge(mDrCaseVOBean.getAge() + mDrCaseVOBean.getAgeUnit());
                                patientDrugInfo.getChatModel().getChatModelMedicalRecord().setDoctorsSummary(UtilChat.doctorAdvice(mDrCaseVOBean,true));
                                patientDrugInfo.getChatModel().getChatModelMedicalRecord().setGender(UtilChat.parserGender(mDrCaseVOBean.getGender()));
                                patientDrugInfo.getChatModel().getChatModelMedicalRecord().setPatientName(mDrCaseVOBean.getName());
                                patientDrugInfo.getChatModel().getChatModelMedicalRecord().setMainComplaint(mDrCaseVOBean.getMainComplaint());
                                patientDrugInfo.getChatModel().getChatModelMedicalRecord().setDiagnosis(mDrCaseVOBean.getDiagnosis());

                                if (!"2".equals(UtilSP.getDoctorStatus())) {
                                    requestSendRecommendMedicine();
                                }else {
                                    XCHttpAsyn.closeLoadingDialog();
                                    List<String> list = result_bean.getList("data").get(0).getStringList("eSignSerial");
                                    ElectronicSignatureHelper.getInstance().signFile(SQ_PreviewRecommendInfoActivity.this, list, signListener);
                                }

                            }
                        } catch (Exception e) {
                            XCHttpAsyn.closeLoadingDialog();
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFinish() {
                        // super.onFinish();
                        //符合正大天晴项目拦截规则，则弹出对话框(之所以在这里返回是为了防止弹出Toast)，否则进行下一步操作，
                        if (CommonConfig.MEDICINE_FIFTER_CODE.equals(getCode())) {
                            XCHttpAsyn.closeLoadingDialog();
                            medicineFifterDialog(getMsg());

                        }else if (!GeneralReqExceptionProcess.checkCode(mContext,getCode(),getMsg())) {
                            XCHttpAsyn.closeLoadingDialog();
                        }
                    }
                });

    }

    /**
     * 请求医事服务费接口
     */
    public void requestCollectPrompt() {
        JSONArray jsonArray = getDrugInfoJsonArray();
        XCHttpAsyn.postAsync(true,true,mContext, AppConfig.getTuijianUrl(AppConfig.COLLECT_PROMPT + "?doctorId="+UtilSP.getUserId()+
                        "&token="+UtilSP.getUserToken()),
                jsonArray.toString(), new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        // -------------- 以下为该接口返回参数 ---------------------
                        // cost (integer, optional): 平台补贴医事服务费 ,
                        // flag (integer, optional): 是否提示病历数据收集标识： 0 不提示， 1 提示 ,
                        // reward (integer, optional): 病历数据收集费
                        // ------------------------------------------------------
                        try {
                            if (result_boolean && !mContext.isDestroy) {
                                XCJsonBean jsonBean = result_bean.getList("data").get(0);
                                String cost = jsonBean.getString("cost");
                                String flag = jsonBean.getString("flag");
                                String reward = jsonBean.getString("reward");

                                medicalServiceFeeDialog.getTv_medical_service_fee().setText("平台将补贴给您"+ cost +"元医事服务费");
                                // 显示是否同意布局
                                medicalServiceFeeDialog.setCollectStatus(flag);
                                medicalServiceFeeDialog.setReward(reward);
                                medicalServiceFeeDialog.show();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        //符合正大天晴项目拦截规则，则弹出对话框(之所以在这里返回是为了防止弹出Toast)，否则进行下一步操作，
                        if (CommonConfig.MEDICINE_FIFTER_CODE.equals(getCode())) {
                            medicineFifterDialog(getMsg());

                        }else if(null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                                getCode(),
                                getMsg())) {
                        }
                    }
                });

    }


    /**
     * 2.9版本需求
     * 获取患者姓名更新患者数据库
     */
    public void requestPatientSimple() {
        RequestParams params = new RequestParams();
        params.put("patientId", RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getChatModel().getUserPatient().getPatientId());

        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.patientSimple), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {

                    try {

                        // id (integer),
                        // name (string): 患者姓名或昵称 ,
                        // remarkName (string): 患者备注名

                        JS_ChatListModel chatListModel = JS_ChatListDB.getInstance(
                                context, UtilSP.getUserId()).getPatientInfo(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getChatModel().getUserPatient().getPatientId());
                        chatListModel.getUserPatient().setPatientName(result_bean.getList("data").get(0).getString("name"));
                        chatListModel.getUserPatient().setPatientMemoName(result_bean.getList("data").get(0).getString("remarkName"));
                        JS_ChatListDB.getInstance(context, UtilSP.getUserId()).updatePatientInfo(chatListModel);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }

            @Override
            public void onFinish() {
                // super.onFinish();
                if (!GeneralReqExceptionProcess.checkCode(mContext,getCode(),getMsg())) {
                    XCHttpAsyn.closeLoadingDialog();
                }
            }
        });
    }

    private YR_CommonDialog medicineFifterDialog;
    private void medicineFifterDialog(String medicines) {
        medicineFifterDialog = new YR_CommonDialog(this, medicines, "", "我知道了") {
            @Override
            public void confirmBtn() {
                medicineFifterDialog.dismiss();
            }
        };
        medicineFifterDialog.setCanceledOnTouchOutside(false);
        medicineFifterDialog.show();
    }

    /**
     * 查询是否设置电子签名
     */
    public void getCertInfo(){
        ElectronicSignatureHelper.getInstance().getCertInfo(true,this,new ElectronicSignatureHelper.CertInfoListener() {
            @Override
            public void onCertInfo(GdcaCertModel var1) {
                // 已经设置电子签名
                if(UtilSP.isRecomSafe()) {
                    requestSafeMedication();
                }else {
                    uploadCaseImg();
                }
            }

            @Override
            public void onFail(String msg, int code) {
                if (code == ElectronicSignatureHelper.UNSET_CERT) {
                    //未设置证书
                    YR_CommonDialog mSetCertDialog = new YR_CommonDialog(SQ_PreviewRecommendInfoActivity.this, "根据卫健委要求，您是互联网医院备案医生\n请先设置电子签名后处方",
                            "暂不处理", "设置电子签名") {
                        @Override
                        public void confirmBtn() {
                            this.dismiss();
                            ToJumpHelp.toJumpHospitalBackupsActivity(SQ_PreviewRecommendInfoActivity.this);//去备案页
                        }
                    };
                    mSetCertDialog.show();
                }else {
                    shortToast(msg);
                }
            }
        });

    }

    //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
    private void sendGIO(){
        List<DrugBean> mDrugBeanList = patientDrugInfo.getList();
        try {
            for(int i = 0;i < mDrugBeanList.size(); i++){
                Map<String,String> track = new HashMap<>();
                //患者id
                track.put("patientID", patientDrugInfo.getChatModel().getUserPatient().getPatientId());
                //是否为处方药
                track.put("ifOTC", mDrugBeanList.get(i).isPrescribed()? "是":"不是");
                //通用名称
                track.put("name", mDrugBeanList.get(i).getCommonName());
                //生产厂家
                track.put("manufacturer", mDrugBeanList.get(i).getManufacturer());
                //规格
                track.put("specification", mDrugBeanList.get(i).getSpec());
                //剂型
                track.put("specification", mDrugBeanList.get(i).getMedicineUsageBean().getQuantityUnit());
                //用量
                track.put("effectiveDuration", mDrugBeanList.get(i).getMedicineUsageBean().getLocalDosageStr());
                //用法
                track.put("certification", (mDrugBeanList.get(i).getMedicineUsageBean().getUsageTime())+ mDrugBeanList.get(i).getMedicineUsageBean().getUsageMethod());
                //药品数量
                track.put("amount", mDrugBeanList.get(i).getMedicineUsageBean().getQuantity());
                //金额
                track.put("units", mDrugBeanList.get(i).getSalePrice());
                //医生ID
                track.put("docID", UtilSP.getUserId());
                GrowingIOUtil.track("patientDrugConsultation", track);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 请求安全用药提醒
     */
    public void requestSafeMedication(){

        JSONObject data = new JSONObject();
        try {
            // 病历
            DrCaseVOBean mDrCaseVOBean = (DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO();
            XC_PatientDrugInfo patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
            UserPatient userPatient = patientDrugInfo.getChatModel().getUserPatient();
            data.put("patientAge", patientDrugInfo.getRecommendInfo().getPatientAge());
            data.put("patientAgeUnit", patientDrugInfo.getRecommendInfo().getPatientAgeUnit());
            data.put("patientGender", patientDrugInfo.getRecommendInfo().getPatientGender());
            data.put("mainComplaint",mDrCaseVOBean.getMainComplaint());
            data.put("presentDisease",mDrCaseVOBean.getPresentDisease());
            data.put("patientId", userPatient.getPatientId());
            JSONArray diagnosis = new JSONArray();
            for (DiagnoseBean bean : patientDrugInfo.getDiagnoseBeanList()) {
                diagnosis.put(bean.name);
            }
            data.put("diagnosis", diagnosis);
            JSONArray skuIds = new JSONArray();
            for (DrugBean item : patientDrugInfo.getRecommendInfo().getDrugInfoBean()) {
                skuIds.put(item.getSkuId());
            }
            data.put("skuIds", skuIds);
            List<DrugBean> drugBeans = patientDrugInfo.getList();
            JSONArray recomSafeItems = new JSONArray();
            JSONObject drugItem;
            for (DrugBean item : drugBeans){
                drugItem = new JSONObject();
                drugItem.put("commonName",item.getCommonName());
                drugItem.put("productName", item.getName());
                drugItem.put("recomName", item.getRecomName());
                drugItem.put("quantity",item.getMedicineUsageBean().getQuantity());
                drugItem.put("skuId",item.getMedicineUsageBean().getSkuId());
                recomSafeItems.put(drugItem);
            }
            data.put("recomSafeItems", recomSafeItems);
        } catch (Exception e) {
            e.printStackTrace();
            XCApplication.base_log.debugShortToast("创建json异常");
        }

        // 发送请求
        XCHttpAsyn.postAsync(true,this,AppConfig.getTuijianUrl(AppConfig.recomCheck+ "?doctorId="+UtilSP.getUserId()+
                "&token="+UtilSP.getUserToken()),data.toString(),new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean && context != null){
                    try {
                        Parse2SafeMedication parse2SafeMedication = new Parse2SafeMedication();
                        SafeMedicationBean safeMedicationBean = parse2SafeMedication.parse(result_bean.getList("data").get(0));
                        if("3".equals(safeMedicationBean.getSafeStatus())){ // 通过
                            uploadCaseImg();
                        }else if("2".equals(safeMedicationBean.getSafeStatus())){ // 谨慎
                            // 若两次提醒一致
                            if(safeMedicationBean.getSn().equals(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getSn())){
                                uploadCaseImg();
                                return;
                            }
                            XCHttpAsyn.closeLoadingDialog();
                            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setSn(safeMedicationBean.getSn());
                            SafeMedicationActivity.launch(SQ_PreviewRecommendInfoActivity.this,safeMedicationBean);
                        }else if("1".equals(safeMedicationBean.getSafeStatus())){ // 禁用
                            XCHttpAsyn.closeLoadingDialog();
                            SafeMedicationActivity.launch(SQ_PreviewRecommendInfoActivity.this,safeMedicationBean);
                        }
                    }catch (Exception e){
                        XCHttpAsyn.closeLoadingDialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                // super.onFinish();
                if(!GeneralReqExceptionProcess.checkCode(context,getCode(),getMsg())){
                    XCHttpAsyn.closeLoadingDialog();
                }
            }
        });
    }

    /**
     *  发送处方
     */
    private void requestSendRecommendMedicine(){
        XC_ChatModel model = patientDrugInfo.getChatModel();
        RequestParams params = new RequestParams();
        params.put("doctorId", UtilSP.getUserId());
        params.put("recomId", model.getRecommandId());
        params.put("recordId", model.getChatModelMedicalRecord().getMedicalRecordId());
        params.put("force", model.isForce());
        XCHttpAsyn.postAsyn(true,this,AppConfig.getTuijianUrl(AppConfig.recomConfirm),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    RecommendMedicineResultBean resultBean = new RecommendMedicineResultBean();
                    Parser2RecomMedResultBean parser2RecomMedResultBean = new Parser2RecomMedResultBean(resultBean);
                    parser2RecomMedResultBean.parseJson(result_bean);
                    patientDrugInfo.getChatModel().setMsgTime(resultBean.getSendTime());
                    patientDrugInfo.getChatModel().setMessageId(resultBean.getMessageId());
                    // 推荐用药的审核状态
                    patientDrugInfo.getChatModel().setRecommandStatus(resultBean.getCheckingStatus());
                    patientDrugInfo.getChatModel().setSessionId(resultBean.getSessionId());
                    patientDrugInfo.getChatModel().setSessionBeginTime(resultBean.getBeginTime());
                    patientDrugInfo.getChatModel().getChatModelMedicalRecord().setCheckingStatus(resultBean.getCheckingStatus());
                    patientDrugInfo.getChatModel().getUserPatient().setConsultPayType(resultBean.getConsultPayType());
                    patientDrugInfo.getChatModel().getChatSession().setConsultSourceType(resultBean.getConsultSourceType());
                    String content = UtilIMCreateJson.createMedicalJson(patientDrugInfo.getChatModel());
                    XC_ChatModel chatModel = UtilPackMsg.packMedicalRecordPrescriptionMsg(content,patientDrugInfo);
                    chatModel.setMsgTime(resultBean.getSendTime());
                    new DrCaseVOBeanDb(SQ_PreviewRecommendInfoActivity.this).deleteById(chatModel.getUserPatient().getPatientId(),UtilSP.getUserId());
                    XCChatModelDb.getInstance(getApplicationContext(), UtilSP.getIMDetailDbName(UtilSP.getUserId(), chatModel.getUserPatient().getPatientId())).insert(chatModel);
                    UtilInsertMsg2JsDb.insert(getApplicationContext(), chatModel);
                    if("2".equals(RecomMedicineHelper.getInstance().getFlag())){
                        DBApplication.finishActivities(XD_CaseRecipeDetailActivity.class);
                        DBApplication.finishActivities(YM_ExplainActivity.class);
                        DBApplication.finishActivities(XD_MedicalRecordDetailActivity.class);
                        DBApplication.finishActivities(XD_EditMedicalRecordActivity.class);
                        DBApplication.finishActivities(SQ_RecommendActivity.class);
                        myFinish();
                        //通知患者病例页刷新诊疗记录
                        Intent intent = new Intent();
                        intent.setAction(XL_PatientInfoAActivity.NewMedicalReceiver.NEW_MEDICAL_ACTION);
                        context.sendBroadcast(intent);
                    }else {
                        UtilChat.launchChatDetail(SQ_PreviewRecommendInfoActivity.this, chatModel.getUserPatient().getPatientId(), null);
                    }
                    //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
                    sendGIO();
                    //add by songxin,date：2018-3-29,about：GrowingIO banner track,end
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                // 处理code操作
                if (CommonConfig.MEDICINE_FIFTER_CODE.equals(getCode())){//符合正大天晴项目拦截规则，则弹出对话框(之所以在这里返回是为了防止弹出Toast)，否则进行下一步操作，
                    medicineFifterDialog(getMsg());
                    return;
                }
                GeneralReqExceptionProcess.checkCode(SQ_PreviewRecommendInfoActivity.this, getCode(), getMsg());
            }
        });
    }

    /**
     * 2.16 版本
     * 发送处方前校验备案
     */
    public void requestRecomCheck() {
        RequestParams params = new RequestParams();
        XCHttpAsyn.postAsyn(true, this, AppConfig.getTuijianUrl(AppConfig.recordCheck), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {
                    try {
                        // forbidenRecom (integer, optional): 是否禁止推药，1：允许，2：禁止，0：历史数据 ,3:继续发送
                        // remindInfo (string, optional): 提示信息
                        String forbidenRecom = result_bean.getList("data").get(0).getString("forbidenRecom");
                        String remindInfo = result_bean.getList("data").get(0).getString("remindInfo");
                        if("3".equals(forbidenRecom)){
                            if(UtilSP.isRecomSafe()) {
                                requestSafeMedication();
                            }else {
                                uploadCaseImg();
                            }
                            return;
                        }
                        XCHttpAsyn.closeLoadingDialog();
                        showSHospitalBackupsDialog(4,remindInfo,forbidenRecom);
                    } catch (Exception e) {
                        XCHttpAsyn.closeLoadingDialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                // super.onFinish();
                if (!GeneralReqExceptionProcess.checkCode(mContext,getCode(),getMsg())) {
                    XCHttpAsyn.closeLoadingDialog();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        if(requestCode == SafeMedicationActivity.REQUEST_CODE_SAFE_MEDICATION){
            uploadCaseImg();
        }
    }

    /**
     * 记录点击时候的时间
     */
    private long lastClickTime;

    /**
     * 防止500毫秒内重复点击的方法
     *
     * @return true：重复点击，false：不是重复点击
     */
    public boolean isFastClick() {
        long time = System.currentTimeMillis();
        if (time - lastClickTime < 1000) {
            return true;
        }
        lastClickTime = time;
        return false;
    }
}
