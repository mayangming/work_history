package com.qlk.ymz.db.mqttlog;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.xiaocoder.android.fw.general.util.UtilFiles;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author jingyu on 2016/10/31 14:34
 * @description
 */

public class MqttLogDb extends SQLiteOpenHelper {

    public static String mDefaultDbName = "mqttLog.db";
    public static int mVersion = 1;
    public static String mOperatorTableName = "mqttLogTable";

    /**
     * 排序常量
     */
    public static String SORT_DESC = " DESC";// 有个空格符号，勿删
    public static String SORT_ASC = " ASC";// 有个空格符号，勿删

    /**
     * 以下是表字段
     */
    public static final String _ID = "_id";
    public static final String MSG = "msg";
    public static final String TIME = "time";
    public static final String BACK1 = "back1";
    public static final String BACK2 = "back2";
    public static final String BACK3 = "back3";
    public static final String BACK4 = "back4";
    public static final String BACK5 = "back5";
    public static final String BACK6 = "back6";

    /**
     * 装db集合的
     */
    public static Map<String, MqttLogDb> map = new LinkedHashMap<String, MqttLogDb>();

    public static MqttLogDb getInstance(Context context) {

        return getInstance(context, mDefaultDbName);
    }

    public static MqttLogDb getInstance(Context context, String dbName) {

        MqttLogDb db = map.get(dbName);

        if (db != null) {
            return db;
        }

        synchronized (MqttLogDb.class) {
            if (map.get(dbName) == null) {
                map.put(dbName, new MqttLogDb(context, dbName));
            }
            return map.get(dbName);
        }

    }

    private MqttLogDb(Context context) {
        super(context, mDefaultDbName, null, mVersion);
    }

    private MqttLogDb(Context context, String dbName) {
        super(context, dbName, null, mVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + mOperatorTableName
                + "(" + _ID + " integer primary key autoincrement,"
                + MSG + " text, "
                + TIME + " text, "
                + BACK1 + " text, "
                + BACK2 + " text, "
                + BACK3 + " text, "
                + BACK4 + " text, "
                + BACK5 + " text, "
                + BACK6 + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

    }

    public ContentValues createContentValue(MqttLogModel model) {
        ContentValues values = new ContentValues();
        values.put(MSG, model.getMsg());
        values.put(TIME, model.getTime());
        values.put(BACK1, model.getBack1());
        values.put(BACK2, model.getBack2());
        values.put(BACK3, model.getBack3());
        values.put(BACK4, model.getBack4());
        values.put(BACK5, model.getBack5());
        values.put(BACK6, model.getBack6());
        return values;
    }

    public MqttLogModel createModel(Cursor c) {
        MqttLogModel model = new MqttLogModel();
        model.set_id(c.getString(c.getColumnIndex(_ID)));
        model.setMsg(c.getString(c.getColumnIndex(MSG)));
        model.setTime(c.getString(c.getColumnIndex(TIME)));
        model.setBack1(c.getString(c.getColumnIndex(BACK1)));
        model.setBack2(c.getString(c.getColumnIndex(BACK2)));
        model.setBack3(c.getString(c.getColumnIndex(BACK3)));
        model.setBack4(c.getString(c.getColumnIndex(BACK4)));
        model.setBack5(c.getString(c.getColumnIndex(BACK5)));
        model.setBack6(c.getString(c.getColumnIndex(BACK6)));
        return model;
    }

    public void checkLogMsgNum() {
        int total = queryCount();
        if (total >= 125) {
            int deleteCount = total - 100;
            // 只保留100条数据
            List<MqttLogModel> mqttLogModelList = queryPageByIdAsc(1, deleteCount);
            for (MqttLogModel bean : mqttLogModelList) {
                deleteById(bean.get_id());
            }
        }
    }

    public synchronized int deleteById(String id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(mOperatorTableName, _ID + "=?", new String[]{id + ""});
        //XCApplication.base_log.i(XCConfig.TAG_DB, "deleteByMsg->" + rows + "行");
        db.close();
        return rows;
    }

    /**
     * 插入一条记录
     */
    public synchronized long insert(MqttLogModel model) {
        checkLogMsgNum();
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = createContentValue(model);
        long id = db.insert(mOperatorTableName, _ID, values);
        model.set_id(id + "");
        //XCApplication.base_log.i(XCConfig.TAG_DB, "insert->" + id + "行");
        db.close();
        return id;
    }

    /**
     * 删除所有记录
     */
    public synchronized int deleteAll() {
        SQLiteDatabase db = getWritableDatabase();
        int raw = db.delete(mOperatorTableName, null, null);
        db.close();
        return raw;
    }

    /**
     * 查询共有多少条记录
     */
    public synchronized int queryCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, new String[]{"COUNT(*)"}, null, null, null, null, null, null);
        c.moveToNext();
        int count = c.getInt(0);
        c.close();
        db.close();
        return count;
    }

    /**
     * 分页查找
     */
    public synchronized List<MqttLogModel> queryPageByIdDesc(int pageNum, int capacity) {
        String offset = (pageNum - 1) * capacity + ""; // 偏移量
        String len = capacity + ""; // 个数
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_DESC, offset + "," + len);
        List<MqttLogModel> beans = new ArrayList<MqttLogModel>();
        while (c.moveToNext()) {
            MqttLogModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /**
     * 分页查找
     */
    public synchronized List<MqttLogModel> queryPageByIdAsc(int pageNum, int capacity) {
        String offset = (pageNum - 1) * capacity + ""; // 偏移量
        String len = capacity + ""; // 个数
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_ASC, offset + "," + len);
        List<MqttLogModel> beans = new ArrayList<MqttLogModel>();
        while (c.moveToNext()) {
            MqttLogModel bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    public synchronized String queryLogString() {
        try {
            List<MqttLogModel> mqttLogModels = queryPageByIdDesc(1, 100);
            StringBuilder sb = new StringBuilder();

            for (MqttLogModel model : mqttLogModels) {
                sb.append(model.getMsg() + "->" + model.getTime() + UtilFiles.LINE_SEPARATOR);
            }

            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

}

