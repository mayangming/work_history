package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.qlk.ymz.R;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.Utils;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * 患者添加成员页list
 *
 * @author 崔毅然
 * @version 2.0
 */
public class YR_AddGroupPatientAdapter extends BaseExpandableListAdapter {
    private List<List<XC_ChatModel>> childrenData;
    private List<String> groupData;
    private Context context;
    private LayoutInflater inflater;
    /** 记录已添加的待提交成员 */
    private List<XC_ChatModel> addPatient = new ArrayList<>();

    LinkedHashMap<String, Integer> sava_letter_position_map = new LinkedHashMap<>();

    public YR_AddGroupPatientAdapter(List<List<XC_ChatModel>> childrenData, List<String> groupData
            , Context context) {
        this.groupData = groupData;
        this.childrenData = childrenData;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    public List<XC_ChatModel> getAddPatient() {
        return addPatient;
    }

    /** PinnedHeaderExpandableListView2页需要调用 */
    public List<String> getGroupDate() {
        return groupData;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return childrenData.get(groupPosition).get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return 0;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        if (groupPosition < 0)
            return 0;
        return childrenData.get(groupPosition).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return groupData.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return groupData.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    class GroupViewHolder {
        TextView xc_id_fragment_search_letter_view;
    }

    class ChildViewHolder {
        RelativeLayout rl;
        XCRoundedImageView xc_id_patient_imagehead;
        TextView xc_id_patient_name;
        ImageView iv_patient_gender;
        TextView xc_id_patient_age;
        TextView xc_id_patient_time;
        View v_bottom_line;//底部分割线
    }

    @Override
    public View getGroupView(int groupPosition, boolean b, View convertView, ViewGroup viewGroup) {
        GroupViewHolder groupViewHolder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.xc_l_adapter_patient_letter_out_item, null);
            groupViewHolder = new GroupViewHolder();
            groupViewHolder.xc_id_fragment_search_letter_view = (TextView) convertView.findViewById(R.id.xc_id_fragment_search_letter_view);
            convertView.setTag(groupViewHolder);
        } else {
            groupViewHolder = (GroupViewHolder) convertView.getTag();
        }
        groupViewHolder.xc_id_fragment_search_letter_view.setText(groupData.get(groupPosition));
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean b, View convertView, ViewGroup viewGroup) {
        ChildViewHolder childViewHolder;
        final XC_ChatModel bean = childrenData.get(groupPosition).get(childPosition);

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.xc_l_adapter_patientadd_item, null);
            childViewHolder = new ChildViewHolder();
            childViewHolder.rl = (RelativeLayout) convertView.findViewById(R.id.rl);
            childViewHolder.xc_id_patient_imagehead = (XCRoundedImageView) convertView.findViewById(R.id.xc_id_patient_imagehead);
            childViewHolder.xc_id_patient_name = (TextView) convertView.findViewById(R.id.xc_id_patient_name);
            childViewHolder.iv_patient_gender = (ImageView) convertView.findViewById(R.id.iv_patient_gender);
            childViewHolder.xc_id_patient_age = (TextView) convertView.findViewById(R.id.xc_id_patient_age);
            childViewHolder.xc_id_patient_time = (TextView) convertView.findViewById(R.id.xc_id_patient_time);
            childViewHolder.v_bottom_line = convertView.findViewById(R.id.v_bottom_line);
            convertView.setTag(childViewHolder);
        } else {
            childViewHolder = (ChildViewHolder) convertView.getTag();
        }

//      设置底部分割线，如果是当前字母最后一个则隐藏
        childViewHolder.v_bottom_line.setVisibility(View.VISIBLE);
        if (childrenData.get(groupPosition).size() - 1 == childPosition) {
            childViewHolder.v_bottom_line.setVisibility(View.INVISIBLE);
        }
//      性别
        if (CommonConfig.GENDER_MALE.equals(bean.getUserPatient().getPatientGender())) {
            childViewHolder.iv_patient_gender.setBackgroundResource(R.mipmap.icon_patient_man);
            childViewHolder.iv_patient_gender.setVisibility(View.VISIBLE);
        } else if (CommonConfig.GENDER_FEMALE.equals(bean.getUserPatient().getPatientGender())) {
            childViewHolder.iv_patient_gender.setBackgroundResource(R.mipmap.icon_patient_women);
            childViewHolder.iv_patient_gender.setVisibility(View.VISIBLE);
        } else {
            childViewHolder.iv_patient_gender.setVisibility(View.GONE);
        }
//      姓名
        childViewHolder.xc_id_patient_name.setText(Utils.getPatientDisplayName(bean.getUserPatient().getPatientMemoName()
                , bean.getUserPatient().getPatientName()));
//      年龄
        if (!TextUtils.isEmpty(bean.getUserPatient().getPatientAge())) {
            childViewHolder.xc_id_patient_age.setText(bean.getUserPatient().getPatientAge() + "岁");
        } else {
            childViewHolder.xc_id_patient_age.setText("");
        }
        // 加载患者头像
        String patientIcon = bean.getUserPatient().getPatientImgHead();
        if (!TextUtils.isEmpty(patientIcon) && URLUtil.isValidUrl(patientIcon)) {
            XCApplication.displayImage(patientIcon, childViewHolder.xc_id_patient_imagehead, XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default));
        } else {
            childViewHolder.xc_id_patient_imagehead.setImageResource(R.mipmap.xc_d_chat_patient_default);
        }
        // 添加患者功能
        if (addPatient != null && addPatient.contains(bean)) {
            childViewHolder.xc_id_patient_time.setText("已添加");
            childViewHolder.xc_id_patient_time.setTextColor(context.getResources().getColor(R.color.c_white_ffffff));
            childViewHolder.xc_id_patient_time.setSelected(true);
        } else {
            childViewHolder.xc_id_patient_time.setText("添加");
            childViewHolder.xc_id_patient_time.setTextColor(context.getResources().getColor(R.color.c_e2231a));
            childViewHolder.xc_id_patient_time.setSelected(false);
        }

        childViewHolder.rl.setTag(R.id.xc_id_patient_rl, bean);
        childViewHolder.rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                XC_ChatModel bean = (XC_ChatModel) v.getTag(R.id.xc_id_patient_rl);
                TextView tv = ((TextView) v.findViewById(R.id.xc_id_patient_time));
                if (addPatient.contains(bean)) {
                    tv.setText("添加");
                    tv.setTextColor(context.getResources().getColor(R.color.c_e2231a));
                    tv.setSelected(false);
                    addPatient.remove(bean);
                } else {
                    tv.setTextColor(context.getResources().getColor(R.color.c_white_ffffff));
                    tv.setText("已添加");
                    tv.setSelected(true);
                    addPatient.add(bean);
                }

            }
        });
       return convertView;
    }

    /** 获取字母的位置 */
    public Integer getPositionFromLetter(String letter) {
        return sava_letter_position_map.get(letter);
    }

    /** 保存字母的位置 */
    public LinkedHashMap<String, Integer> initLettersPosition(List<String> listParent, List<List<XC_ChatModel>> listChild) {
        String record_last_letter = null;
        for (int i = 0; i < listParent.size(); i++) {
            String letter = listParent.get(i);
            if (!letter.equals(record_last_letter)) {
                if (listChild.get(i) != null) {
                    if (i == 0) {
                        sava_letter_position_map.put(letter, 0);
                    } else {
                        // position等于上一个字母的位置+改字母的子项的数量
                        int position = 1 + sava_letter_position_map.get(record_last_letter) + listChild.get(i - 1).size();
                        sava_letter_position_map.put(letter, position);
                    }
                }
            }
            record_last_letter = letter;
        }
        return sava_letter_position_map;
    }

    /** 更新字母位置关系map */
    public void updateABCPosition() {
        sava_letter_position_map.clear();
        if (groupData != null && groupData.size() != 0) {
            initLettersPosition(groupData, childrenData);
        }
    }
}
