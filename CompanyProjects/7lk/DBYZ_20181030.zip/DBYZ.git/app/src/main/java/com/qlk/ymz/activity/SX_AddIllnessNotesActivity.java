package com.qlk.ymz.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.patientnote.PatientInfoModel;
import com.qlk.ymz.db.patientnote.PatientNoteDB;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

/**
 * SX_AddIllnessNotesActivity
 * 添加病情备注
 * @author songxin on 2016/1/9.
 * @version 1.2.0
 *
 *
 * @update author zhangpengfei on 2016/4/15
 * @version 2.2.0
 */
public class SX_AddIllnessNotesActivity extends DBActivity implements View.OnClickListener{
    /** title左边按钮*/
    private ImageView sx_id_title_left;
    /** title中间文字*/
    private TextView sx_id_title_center;
    /** title右边button*/
    private TextView sx_id_title_right_btn;
    /** 日期显示*/
    private TextView sx_id_date_show;
    /** 输入计数*/
    private TextView sx_id_word_count_record;
    /** 内容输入框*/
    private EditText sx_id_condition_record_edit;
    /** 患者id*/
    private String mPatientId = "";
    /**患者病情备注信息*/
    private PatientInfoModel patientInfoModelObj;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// 设置布局
		setContentView(R.layout.sx_add_illness_notes);
		super.onCreate(savedInstanceState);
        sx_id_title_center.setText("病情备注");
        mPatientId = getIntent().getStringExtra("PATIENT_ID");
        sx_id_title_right_btn.setVisibility(View.VISIBLE);
        sx_id_title_right_btn.setText("保存");
        sx_id_date_show.setText(UtilDate.getNow(UtilDate.FORMAT_SHORT_CN));
        patientInfoModelObj = new PatientInfoModel();
//        getNote();
        patientInfoModelObj = PatientNoteDB.getInstance(this).getInfo(mPatientId, UtilSP.getUserId());
        sx_id_condition_record_edit.setText(UtilString.isBlank(patientInfoModelObj.getPatientNote()) ? "" : patientInfoModelObj.getPatientNote());
	}

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_AddIllnessNotesActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

	// 无网络时,点击屏幕后回调的方法
	@Override
	public void onNetRefresh() {
	}

	// 初始化控件
	@Override
	public void initWidgets() {
        sx_id_title_left = getViewById(R.id.sx_id_title_left);
        sx_id_title_center = getViewById(R.id.sx_id_title_center);
        sx_id_title_right_btn = getViewById(R.id.sx_id_title_right_btn);
        sx_id_date_show = getViewById(R.id.sx_id_date_show);
        sx_id_word_count_record = getViewById(R.id.sx_id_word_count_record);
        sx_id_condition_record_edit = getViewById(R.id.sx_id_condition_record_edit);
	}

	// 设置监听
	@Override
	public void listeners() {
        sx_id_title_left.setOnClickListener(this);
        sx_id_title_right_btn.setOnClickListener(this);
        sx_id_condition_record_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                sx_id_word_count_record.setText(s.length()+"");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
	}

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.sx_id_title_left:{
                finish();
                break;
            }
            case R.id.sx_id_title_right_btn:{
                addNote(sx_id_condition_record_edit.getText().toString().trim());
                break;
            }
            default:{
                break;
            }
        }
    }

    private void addNote(final String note) {
        if(UtilString.isBlank(note)){
            XCApplication.base_log.shortToast("病情备注内容不能为空");
            return;
        }
        RequestParams params = new RequestParams();
        params.put("patientId", mPatientId);
        params.put("content", note);
        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.addRemark), params, new XCHttpResponseHandler() {


            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    shortToast("添加成功");
                    patientInfoModelObj.setDoctorSelfId( UtilSP.getUserId());
                    patientInfoModelObj.setPatientId(mPatientId);
                    patientInfoModelObj.setPatientNote(note);
                    patientInfoModelObj.setPatientNoteCreateTime(System.currentTimeMillis() + "");
                    PatientNoteDB.getInstance(SX_AddIllnessNotesActivity.this).saveInfo(patientInfoModelObj);
                    finish();
                } else {
                    shortToast(getMsg());

                }
            }
        });
    }

//    private void getNote() {
//        RequestParams params = new RequestParams();
//        params.put("patientId", mPatientId);
//        XCHttpAsyn.getAsyn(true, true, this, AppConfig.getHostUrl(AppConfig.daylist), params, new XCHttpResponseHandler(null) {
//
//
//            @Override
//            public void onSuccess(int code, Header[] headers, byte[] arg2) {
//                super.onSuccess(code, headers, arg2);
//                if (result_boolean) {
//                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
//                    if (jsonBeans != null && jsonBeans.size() > 0) {
//                        String content = jsonBeans.get(jsonBeans.size() - 1).getString("content");
//                        sx_id_condition_record_edit.setText(UtilString.isBlank(content) ? "" : content);
//                    }
//                }
//            }
//        });
//    }
}
