package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SafeMedicationAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.SafeMedicationBean;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;

/**
 * 安全用药提醒页
 */
public class SafeMedicationActivity extends DBActivity {
    private XCTitleCommonLayout title_bar;
    private RecyclerView rv_safe_medication;
    /** 继续 */
    private TextView tv_continue;
    /** 返回 */
    private TextView tv_back;
    private SafeMedicationAdapter adapter;
    private SafeMedicationBean safeMedicationBean;
    /** 0:显示仍然发送，1：显示仍然保存 */
    public static final int BTNTEXTTAG_1 = 1;

    // 请求码
    public static final int REQUEST_CODE_SAFE_MEDICATION = 104;
    public static final String SAFE_MEDICATION_BEAN_KEY = "safeMedicationBean";

    public static void launch(Activity activity, SafeMedicationBean safeMedicationBean){
        Intent intent = new Intent(activity,SafeMedicationActivity.class);
        intent.putExtra(SAFE_MEDICATION_BEAN_KEY,safeMedicationBean);
        activity.startActivityForResult(intent, REQUEST_CODE_SAFE_MEDICATION);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_safe_medication);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SafeMedicationActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void initWidgets() {
        title_bar = getViewById(R.id.title_bar);
        rv_safe_medication = getViewById(R.id.rv_safe_medication);
        tv_continue = getViewById(R.id.tv_continue);
        tv_back = getViewById(R.id.tv_back);

        title_bar.getXc_id_titlebar_left_imageview().setVisibility(View.GONE);
        title_bar.getXc_id_titlebar_left_textview().setText("关闭");

        adapter = new SafeMedicationAdapter(this);

        safeMedicationBean = (SafeMedicationBean) getIntent().getSerializableExtra(SAFE_MEDICATION_BEAN_KEY);
        adapter.update(safeMedicationBean.getSafeMedicationItemInfoList());

        rv_safe_medication.setLayoutManager(new LinearLayoutManager(this));
        rv_safe_medication.setAdapter(adapter);

        if(BTNTEXTTAG_1 == safeMedicationBean.getBtnTextTag()){
            tv_continue.setText("仍然保存");
        }else {
            tv_continue.setText("仍然发送");
        }

        if ("1".equals(safeMedicationBean.getShow())){
            tv_continue.setVisibility(View.VISIBLE);
        }else {
            tv_continue.setVisibility(View.GONE);
        }

    }

    @Override
    public void listeners() {
        tv_continue.setOnClickListener(this);
        tv_back.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch(v.getId()){
            //  继续
            case R.id.tv_continue :
                // created by songxin,date：2018-10-29,about：saveInfo,begin
                BiUtil.saveBiInfo(SafeMedicationActivity.class, "2", "128", "E00106","", false);
                // created by songxin,date：2018-10-29,about：saveInfo,end
                setResult(Activity.RESULT_OK);
                myFinish();
                break;
            //  返回
            case R.id.tv_back :
                // created by songxin,date：2018-10-29,about：saveInfo,begin
                BiUtil.saveBiInfo(SafeMedicationActivity.class, "2", "128", "E00107","", false);
                // created by songxin,date：2018-10-29,about：saveInfo,end
                myFinish();
                break;

        }
    }

    @Override
    public void onNetRefresh() {

    }


}
