package com.qlk.ymz.db.medicineUageDosage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;
import android.util.Log;

import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

/**
 * @author xilinch on 2015/10/23.
 * @version 1.2.0
 * @modifier xilinch 2015/10/23.
 * @description
 */
public class XLMedicineUseageDosageDAO {
    /**
     * 数据库版本
     */
    private static final int VERSION_MEDICINEUSAGEDOSAGE = 12;
    /**
     * 用法用量helper
     */
    private XLMedicineUseageDosageDBHelper medicineUseageDosageDBHelper;
    // ********************常量********************
    /**
     * 数据库名字
     */
    private static final String DBNAME = "medicineUseageDosage.db";
    /**
     * 数据表名字
     */
    private static final String TABLENAME = "medicineUseageDosage";

    /**
     * id
     */
    public static final String COLUMNS_ID = "id";

    /**
     * 患者id
     */
    public static final String COLUMNS_PATIENT_ID = "patient_id";

    /**
     * 药品id
     */
    public static final String COLUMNS_MEDICINE_ID = "medicine_id";
    /**
     * 名字
     */
    public static final String COLUMNS_NAME = "name";
    /**
     * 通用名
     */
    public static final String COLUMNS_COMMONNAME = "commonName";
    /**
     * 生产单位
     */
    public static final String COLUMNS_MANUFACTURER = "manufacturer";
    /**
     * 规格
     */
    public static final String COLUMNS_SPEC = "spec";

    /**
     * 产品图片
     */
    public static final String COLUMNS_IMAGE = "image";
    /**
     * 购买数量
     */
    public static final String COLUMNS_COUNT = "count";
    /**
     * 一日
     */
    public static final String COLUMNS_EVERYDAY = "everyDay";

    /**
     * 一次
     */
    public static final String COLUMNS_EVERYTIME = "everyTime";
    /**
     * 服用时间
     */
    public static final String COLUMNS_USAGETIME = "usageTime";
    /**
     * 服用单位
     */
    public static final String COLUMNS_UNIT = "unit";
    /**
     * 服用方法
     */
    public static final String COLUMNS_TAKING_METHOD = "method";
    /**
     * 备注
     */
    public static final String COLUMNS_NOTE = "note";

    /**
     * 时间  单位毫秒
     */
    public static final String COLUMNS_TIME = "time";
    /**
     * 备用字段
     */
    public static final String COLUMNS_BAK1 = "BAK1";
    /**
     * 备用字段
     */
    public static final String COLUMNS_BAK2 = "BAK2";

    private static final String[] COLUMES_ALL = new String[]{
            COLUMNS_ID,
            COLUMNS_PATIENT_ID,
            COLUMNS_MEDICINE_ID,
            COLUMNS_NAME,
            COLUMNS_COMMONNAME,
            COLUMNS_MANUFACTURER,
            COLUMNS_SPEC,
            COLUMNS_IMAGE,
            COLUMNS_USAGETIME,
            COLUMNS_COUNT,
            COLUMNS_EVERYDAY,
            COLUMNS_EVERYTIME,
            COLUMNS_UNIT,
            COLUMNS_TAKING_METHOD,
            COLUMNS_NOTE,
            COLUMNS_TIME,
            COLUMNS_BAK1,
            COLUMNS_BAK2,

    };

    /**
     * 建立表
     */
    public static String SQL_CREATE_SCRIPT_IF_NOT_EXIST;

    /**
     * 表删除脚本。
     */
    public static String SQL_DROP_SCRIPT;

    private String docotorId;

    public XLMedicineUseageDosageDAO(Context context, String docotorId) {
//        String[] sql = new String[]{createSql, createTable};
        this.docotorId = docotorId;
        initCreateTabScript(docotorId);
        String[] sql = new String[]{SQL_CREATE_SCRIPT_IF_NOT_EXIST};
        medicineUseageDosageDBHelper = new XLMedicineUseageDosageDBHelper(context, DBNAME, VERSION_MEDICINEUSAGEDOSAGE,SQL_CREATE_SCRIPT_IF_NOT_EXIST,SQL_DROP_SCRIPT);
        //建立医生表，
        medicineUseageDosageDBHelper.getWritableDatabase().execSQL(SQL_CREATE_SCRIPT_IF_NOT_EXIST);

    }

    /**
     * tabName: medicineUseageDosage_docotorId
     *
     * @param doctorId 医生id
     */
    private void initCreateTabScript(String doctorId) {
        SQL_CREATE_SCRIPT_IF_NOT_EXIST = "CREATE TABLE IF NOT EXISTS [" + TABLENAME + "_" + doctorId + "] ("
                + "[" + COLUMNS_ID + "] INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "[" + COLUMNS_COMMONNAME + "] VARCHAR(50),"
                + "[" + COLUMNS_COUNT + "] VARCHAR(10),"
                + "[" + COLUMNS_EVERYDAY + "] VARCHAR(50),"
                + "[" + COLUMNS_EVERYTIME + "] VARCHAR(50),"
                + "[" + COLUMNS_IMAGE + "] VARCHAR(50),"
                + "[" + COLUMNS_MANUFACTURER + "] VARCHAR(50),"
                + "[" + COLUMNS_MEDICINE_ID + "] VARCHAR(10),"
                + "[" + COLUMNS_NAME + "] VARCHAR(50),"
                + "[" + COLUMNS_NOTE + "] VARCHAR(50),"
                + "[" + COLUMNS_SPEC + "] VARCHAR(50),"
                + "[" + COLUMNS_UNIT + "] VARCHAR(50),"
                + "[" + COLUMNS_TIME + "] INTEGER(50),"
                + "[" + COLUMNS_TAKING_METHOD + "] INTEGER(50),"
                + "[" + COLUMNS_PATIENT_ID + "] VARCHAR(50),"
                + "[" + COLUMNS_BAK1 + "] VARCHAR(50),"
                + "[" + COLUMNS_BAK2 + "] VARCHAR(50),"
                + "[" + COLUMNS_USAGETIME + "] VARCHAR(50) )";

        SQL_DROP_SCRIPT = "DROP TABLE IF EXISTS [" + TABLENAME + "_" + doctorId
                + "]";
    }

    /**
     * 获取该患者该药物的上一次的用法用量
     * @param medicineId
     * @return 医药对象
     */
    public XCJsonBean getLastUsageDosage(String medicineId) {
        XCJsonBean bean = queryLastMedicineUsageDosage(medicineId);
        return bean;
    }


    /**
     * 查询该药品上一次的用法用量
     *
     * @param medicineId 药品id
     * @return 用法用量对象
     */
    private XCJsonBean queryLastMedicineUsageDosage(String medicineId) {
        XCJsonBean bean = null;
        if (TextUtils.isEmpty(medicineId)) {
            Log.e("my", "queryLastMedicineUsageDosage --- invalid medicineId:" + medicineId);
        } else {

            Cursor cursor = medicineUseageDosageDBHelper.getReadableDatabase()
                    .query(TABLENAME + "_" + docotorId, COLUMES_ALL,
                            COLUMNS_MEDICINE_ID + " = " + medicineId
                            , null, null, null, COLUMNS_TIME + " DESC");
            if (cursor != null && cursor.getCount() > 0) {
                cursor.moveToFirst();
                bean = readFromCursor(cursor);

            } else {
                //没有查询到 则为null
            }
            System.out.println("queryLastMedicineUsageDosage():" + bean);
            if (cursor != null) {
                cursor.close();
            }

        }
        return bean;
    }

    /**
     * 插入用法用量
     * @param bean 用法用量对象
     * @return 影响的列
     */
    public long insertMedicineUsageDosage(XCJsonBean bean) {
        System.out.println("insertMedicineUsageDosage:" + bean.toString());
        long index = -1;
        if (bean != null) {
            ContentValues contentValues = getContentValues(bean);
            //插入数据
            index = medicineUseageDosageDBHelper.getWritableDatabase()
                    .insert(TABLENAME + "_" + docotorId, null, contentValues);
        }
        System.out.println("index:" + index);
        return index;
    }

    /**
     * 更新药物的用法用量
     *
     * @param bean 用法用量对象
     * @return 影响的列
     */
    public long updateMedicineUsageDosage(XCJsonBean bean) {
        long rowId = -1;
        String patient_id = bean.getString(COLUMNS_PATIENT_ID);
        String medicine_id = bean.getString(COLUMNS_MEDICINE_ID);
        //首先查询是否存在记录，如果存在则更新
        Cursor cursor = medicineUseageDosageDBHelper.getReadableDatabase()
                .query(TABLENAME + "_" + docotorId,
                        COLUMES_ALL
                        , COLUMNS_PATIENT_ID + " = " + patient_id + " and " + COLUMNS_MEDICINE_ID + " = " + medicine_id
                        , null, null, null, COLUMNS_TIME + " DESC");

        if (cursor != null && cursor.getCount() > 0) {
            //更新该记录
            cursor.moveToFirst();
            String id = cursor.getString(cursor.getColumnIndex(COLUMNS_ID));
            ContentValues values = getContentValues(bean);
            rowId = medicineUseageDosageDBHelper.getWritableDatabase()
                    .update(TABLENAME + "_" + docotorId, values, COLUMNS_ID + " = " + id, null);

        } else {
            //插入记录
            rowId = insertMedicineUsageDosage(bean);
        }
        if (cursor != null) {
            cursor.close();
        }
        return rowId;
    }

    /**
     * 读取游标的一行
     *
     * @param cursor  游标
     * @return 用法用量对象
     */
    private XCJsonBean readFromCursor(Cursor cursor) {
        XCJsonBean bean = null;
        if (cursor != null) {
            bean = new XCJsonBean();
            String id = cursor.getString(cursor.getColumnIndex(COLUMNS_ID));
            String patient_id = cursor.getString(cursor.getColumnIndex(COLUMNS_PATIENT_ID));
            String medicine_id = cursor.getString(cursor.getColumnIndex(COLUMNS_MEDICINE_ID));
            String name = cursor.getString(cursor.getColumnIndex(COLUMNS_NAME));
            String commonname = cursor.getString(cursor.getColumnIndex(COLUMNS_COMMONNAME));
            String manufacture = cursor.getString(cursor.getColumnIndex(COLUMNS_MANUFACTURER));
            String spec = cursor.getString(cursor.getColumnIndex(COLUMNS_SPEC));
            String image = cursor.getString(cursor.getColumnIndex(COLUMNS_IMAGE));
            String usageTime = cursor.getString(cursor.getColumnIndex(COLUMNS_USAGETIME));
            String count = cursor.getString(cursor.getColumnIndex(COLUMNS_COUNT));
            String everyday = cursor.getString(cursor.getColumnIndex(COLUMNS_EVERYDAY));
            String everyTime = cursor.getString(cursor.getColumnIndex(COLUMNS_EVERYTIME));
            String unit = cursor.getString(cursor.getColumnIndex(COLUMNS_UNIT));
            String method = cursor.getString(cursor.getColumnIndex(COLUMNS_TAKING_METHOD));
            String note = cursor.getString(cursor.getColumnIndex(COLUMNS_NOTE));
            String time = cursor.getString(cursor.getColumnIndex(COLUMNS_TIME));
            String bak1 = cursor.getString(cursor.getColumnIndex(COLUMNS_BAK1));
            String bak2 = cursor.getString(cursor.getColumnIndex(COLUMNS_BAK2));
            bean.set(COLUMNS_ID, id);
            bean.set(COLUMNS_PATIENT_ID, patient_id);
            bean.set(COLUMNS_MEDICINE_ID, medicine_id);
            bean.set(COLUMNS_NAME, name);
            bean.set(COLUMNS_COMMONNAME, commonname);
            bean.set(COLUMNS_MANUFACTURER, manufacture);
            bean.set(COLUMNS_SPEC, spec);
            bean.set(COLUMNS_IMAGE, image);
            bean.set(COLUMNS_USAGETIME, usageTime);
            bean.set(COLUMNS_COUNT, count);
            bean.set(COLUMNS_EVERYDAY, everyday);
            bean.set(COLUMNS_EVERYTIME, everyTime);
            bean.set(COLUMNS_UNIT, unit);
            bean.set(COLUMNS_TAKING_METHOD, method);
            bean.set(COLUMNS_NOTE, note);
            bean.set(COLUMNS_TIME, time);
            bean.set(COLUMNS_BAK1, bak1);
            bean.set(COLUMNS_BAK2, bak2);
        }

        return bean;
    }

    /**
     * 测试代码
     * 主要目的建立用法用量对象，用于测试修改、插入。删除等操作
     * @return 测试用法用量对象
     */
    private XCJsonBean testInitBean() {
        XCJsonBean bean = new XCJsonBean();
        bean.set(COLUMNS_PATIENT_ID, "1");
        bean.set(COLUMNS_NAME, "藿香正气水");
        bean.set(COLUMNS_COMMONNAME, "藿香正气水，通用名");
        bean.set(COLUMNS_COUNT, "12");
        bean.set(COLUMNS_EVERYDAY, "3");
        bean.set(COLUMNS_EVERYTIME, "1");
        bean.set(COLUMNS_IMAGE, "http://f.hiphotos.baidu.com/image/pic/item/14ce36d3d539b600078f2676eb50352ac75cb7a9.jpg");
        bean.set(COLUMNS_MANUFACTURER, "吉林敖东");
        bean.set(COLUMNS_MEDICINE_ID, "3");
        bean.set(COLUMNS_NOTE, "谨遵医嘱");
        bean.set(COLUMNS_SPEC, "3");
        bean.set(COLUMNS_TAKING_METHOD, "口服");
        bean.set(COLUMNS_UNIT, "支");
        bean.set(COLUMNS_TIME, System.currentTimeMillis());
        bean.set(COLUMNS_USAGETIME, "三个小时");
        return bean;

    }

    /**
     * 对象到contentValue
     *
     * @param bean 用法用量对象
     * @return 键值对
     */
    private ContentValues getContentValues(XCJsonBean bean) {
        ContentValues contentValues = null;
        if (bean != null) {
            contentValues = new ContentValues();
            contentValues.put(COLUMNS_BAK1, bean.getString(COLUMNS_BAK1));
            contentValues.put(COLUMNS_BAK2, bean.getString(COLUMNS_BAK2));
            contentValues.put(COLUMNS_COMMONNAME, bean.getString(COLUMNS_COMMONNAME));
            contentValues.put(COLUMNS_COUNT, bean.getString(COLUMNS_COUNT));
            contentValues.put(COLUMNS_EVERYDAY, bean.getString(COLUMNS_EVERYDAY));
            contentValues.put(COLUMNS_EVERYTIME, bean.getString(COLUMNS_EVERYTIME));
            contentValues.put(COLUMNS_IMAGE, bean.getString(COLUMNS_IMAGE));
            contentValues.put(COLUMNS_MANUFACTURER, bean.getString(COLUMNS_MANUFACTURER));
            contentValues.put(COLUMNS_MEDICINE_ID, bean.getString(COLUMNS_MEDICINE_ID));
            contentValues.put(COLUMNS_NAME, bean.getString(COLUMNS_NAME));
            contentValues.put(COLUMNS_NOTE, bean.getString(COLUMNS_NOTE));
            contentValues.put(COLUMNS_TAKING_METHOD, bean.getString(COLUMNS_TAKING_METHOD));
            contentValues.put(COLUMNS_PATIENT_ID, bean.getString(COLUMNS_PATIENT_ID));
            contentValues.put(COLUMNS_SPEC, bean.getString(COLUMNS_SPEC));
            contentValues.put(COLUMNS_UNIT, bean.getString(COLUMNS_UNIT));
            contentValues.put(COLUMNS_TIME, System.currentTimeMillis());
            contentValues.put(COLUMNS_USAGETIME, bean.getString(COLUMNS_USAGETIME));
        }
        return contentValues;
    }


}
