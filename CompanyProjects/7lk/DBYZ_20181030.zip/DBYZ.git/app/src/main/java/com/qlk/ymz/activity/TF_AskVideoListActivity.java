package com.qlk.ymz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.TF_VideoListAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.TF_VideoListContent;
import com.qlk.ymz.model.YY_RejectVideoReson;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilVideo;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.util.qlkserivce.QlkServiceHelper;
import com.qlk.ymz.view.YR_CommonDialog;
import com.qlk.ymz.view.YY_RejectVideoResonDialog;
import com.qlk.ymz.view.YY_VideoStatusDialog;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilBroadcast;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

import static com.qlk.ymz.model.TF_VideoListBean.TF_VideoListPageBean;

/**
 * TF_AskVideoListActivity
 * <p>
 * 视频列表页
 *
 * @author wangtengfei
 * @date 2016-07-21
 */
public class TF_AskVideoListActivity extends DBActivity {

    /**
     * 左边返回layout
     */
    private LinearLayout tf_ask_video_left_layout;
    /**
     * 左边返回按钮
     */
    private ImageView tf_ask_video_back_iv;
    /**
     * 可结束、可接通按钮
     */
    private RadioGroup tf_ask_video_rg;
    private RadioButton tf_can_start_rb;
    private RadioButton tf_old_end_rb;
    /**
     * 可接通fragment
     */
    private XCListViewFragment mVideoCanStartFragment;
    /**
     * 已结束fragment
     */
    private XCListViewFragment mVideoListOldEndFragment;
    /**
     * 当前展示内容标记  0、可接通  1、已结束
     */
    private int isCanStartView = 0;
    /**
     * 可接通list
     */
    private List<TF_VideoListContent> mCanStartBeans;
    /**
     * 已結束list
     */
    private List<TF_VideoListContent> mFinishBeans;
    /**
     * 可接通adapter
     */
    private TF_VideoListAdapter mVideoCanStartAdapter;
    /**
     * 已結束adapter
     */
    private TF_VideoListAdapter mVideoFinishAdapter;
    /**
     * 视频列表默认请求10条数据
     */
    public static int PAGE_NUM = 10;
    /**
     * 是否有下一页的数据
     */
    private boolean hasNext;
    /**
     * 发起视频的dialog
     */
    private YY_VideoStatusDialog mVideoStatusDialog;
    /**
     * 弹出我知道了对话框
     */
    private YR_CommonDialog mKnowDialog;
    /**
     * 拒绝原因选择对话框
     */
    public YY_RejectVideoResonDialog resonDialog;
    /**
     * 添加接收push消息广播如果有新的患者加入或者患者手动取消刷新列表状态
     */
    private NewVideoListReceiver mNewVideoListReceiver;
    /**
     * 判断是否第一次进入界面
     */
    private boolean isFirstStart = true;
    /** 视频设置入口 add by cyr on 2016-11-17 */
    private TextView iv_video_set;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.tf_activity_ask_video_list);
        super.onCreate(savedInstanceState);
        //显示待接通页面
        tf_can_start_rb.setChecked(true);
        //接收服务器push消息   1、患者手动取消预约  2、视频超时  刷新预约列表
        mNewVideoListReceiver = new NewVideoListReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000, JS_MainActivity.NewVideoReceiver.NEW_VIDEO_ACTION, mNewVideoListReceiver);
    }

    @Override
    public void initWidgets() {
        iv_video_set = getViewById(R.id.iv_video_set);

        tf_ask_video_rg = getViewById(R.id.tf_ask_video_rg);
        tf_ask_video_left_layout = getViewById(R.id.tf_ask_video_left_layout);
        tf_ask_video_back_iv = getViewById(R.id.tf_ask_video_back_iv);
        tf_can_start_rb = getViewById(R.id.tf_can_start_rb);
        tf_old_end_rb = getViewById(R.id.tf_old_end_rb);
        initContentFragment();
    }

    @Override
    protected void onStart() {
        super.onStart();
        /** created by songxin,date：2016-8-16,about：bi,begin */
        BiUtil.savePid(TF_AskVideoListActivity.class);
        /** created by songxin,date：2016-8-16,about：bi,end */
        refreshVideoList();
        // UI要求在列表顶部添加一个5px的灰色 listview向上滑动时去隐藏这个头部
        //第一次进行添加headerview  因为在oncreate执行时base_abs_listview为空  所以在此添加
//        if (isFirstStart) {
//            View view = new View(this);
//            view.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UtilScreen.dip2px(this,5)));
//            view.setBackgroundColor(getResources().getColor(R.color.c_gray_f0f1f5));
//            mVideoListOldEndFragment.base_abs_listview.addHeaderView(view);
//            mVideoCanStartFragment.base_abs_listview.addHeaderView(view);
//            isFirstStart = false;
//        }

    }

    /**
     * 刷新列表数据
     */
    public void refreshVideoList() {
        mVideoCanStartFragment.reset();
        mVideoListOldEndFragment.reset();
        //请求第一页数据  刷新列表
        requestStartVideoList(1);
        requestOldVideoList(1);
    }

    @Override
    public void listeners() {
        iv_video_set.setOnClickListener(this);
        tf_ask_video_left_layout.setOnClickListener(this);
        //头部选择按钮监听
        tf_ask_video_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    //待接通
                    case R.id.tf_can_start_rb: {
                        //更改状态
                        tf_can_start_rb.setTextColor(Color.WHITE);
                        tf_old_end_rb.setTextColor(getResources().getColor(R.color.c_e2231a));
                        isCanStartView = 0;
                        showFragment(mVideoCanStartFragment);
                        hideFragment(mVideoListOldEndFragment);
                        break;
                    }
                    //已结束
                    case R.id.tf_old_end_rb: {
                        tf_old_end_rb.setTextColor(Color.WHITE);
                        tf_can_start_rb.setTextColor(getResources().getColor(R.color.c_e2231a));
                        isCanStartView = 1;
                        showFragment(mVideoListOldEndFragment);
                        hideFragment(mVideoCanStartFragment);
                        break;
                    }
                }
            }
        });
        //已结束视频列表
        mVideoListOldEndFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                TF_VideoListContent videoListContent = (TF_VideoListContent) arg0.getItemAtPosition(arg2);
                int status = videoListContent.getStatus();
                if (status == 3) {
                    //showNormalDialog("该咨询已被取消不可再发起",null);
                    //新测试用例，点击知道了都刷新列表
                    UtilVideo.videoFailRefreshData(TF_AskVideoListActivity.this, "该咨询已被取消不可再发起");
                } else if (status == 4) {
                    //视频
                    if (videoListContent.getTimeOut() == 0) {
                        if (mVideoStatusDialog == null) {
                            mVideoStatusDialog = new YY_VideoStatusDialog(TF_AskVideoListActivity.this);

                        }
                        mVideoStatusDialog.show(videoListContent);
                    } else {
                        //showNormalDialog("该咨询已超过预约时间30分钟不可再发起",null);
                        //新测试用例，点击知道了都刷新列表
                        UtilVideo.videoFailRefreshData(TF_AskVideoListActivity.this, "该咨询已超过预约时间30分钟不可再发起");

                    }
                }
            }
        });
        //已结束分頁加載
        mVideoListOldEndFragment.setOnRefreshNextPageListener(new XCBaseAbsListFragment.OnRefreshNextPageListener() {
            @Override
            public void onRefreshNextPageListener(int current_page) {
                if (current_page == 1) {
                    mVideoCanStartFragment.base_refresh_abs_listview.setMode(PullToRefreshBase.Mode.BOTH);
                }
                requestOldVideoList(current_page);
            }
        });


        // 可接通 判断视频是否在视频通话的预约时间内 进行提示
        mVideoCanStartFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                TF_VideoListContent videoListContent = (TF_VideoListContent) arg0.getItemAtPosition(arg2);
                if (mVideoStatusDialog == null) {
                    mVideoStatusDialog = new YY_VideoStatusDialog(TF_AskVideoListActivity.this);
                }
                mVideoStatusDialog.show(videoListContent);
            }

        });
        //  可接通分頁加載
        mVideoCanStartFragment.setOnRefreshNextPageListener(new XCBaseAbsListFragment.OnRefreshNextPageListener() {
            @Override
            public void onRefreshNextPageListener(int current_page) {
                if (current_page == 1) {
                    mVideoCanStartFragment.base_refresh_abs_listview.setMode(PullToRefreshBase.Mode.BOTH);
                }
                requestStartVideoList(current_page);

            }
        });

    }


    @Override
    public void onNetRefresh() {
        //网络刷新
        refreshVideoList();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.tf_ask_video_left_layout:{ // 返回按钮
                TF_AskVideoListActivity.this.finish();
                break;
            }
            case R.id.iv_video_set:{//视频设置入口
                myStartActivity(TF_VideoSettingsActivity.class);
                break;
            }
        }
    }

    // 创建content
    private void initContentFragment() {

        //可接通fragment
        mVideoCanStartFragment = new XCListViewFragment();
        mCanStartBeans = new ArrayList<>();
        mVideoCanStartAdapter = new TF_VideoListAdapter(this, mCanStartBeans, isCanStartView);
        mVideoCanStartFragment.setAdapter(mVideoCanStartAdapter);
        mVideoCanStartFragment.setMode(XCListViewFragment.MODE_UP_DOWN);
        mVideoCanStartFragment.setListViewStyleParam(null, 0, false);//设置分隔线和progressbar
        mVideoCanStartFragment.setPerPageNum(TF_AskVideoListActivity.PAGE_NUM + "");
        addFragment(R.id.video_list, mVideoCanStartFragment);
        //已结束fragment
        mVideoListOldEndFragment = new XCListViewFragment();
        mFinishBeans = new ArrayList<>();
        mVideoFinishAdapter = new TF_VideoListAdapter(this, mFinishBeans, isCanStartView);
        mVideoListOldEndFragment.setAdapter(mVideoFinishAdapter);
        mVideoListOldEndFragment.setMode(XCListViewFragment.MODE_UP_DOWN);  //设置可上下拉
        mVideoListOldEndFragment.setListViewStyleParam(null, 0, false);//设置分隔线和progressbar
        mVideoListOldEndFragment.setPerPageNum(TF_AskVideoListActivity.PAGE_NUM + "");
        addFragment(R.id.video_list, mVideoListOldEndFragment);
    }

    /**
     * 待接通视频列表数据
     *
     * @param page 请求的页数
     */
    public void requestStartVideoList(final int page) {
        RequestParams params = new RequestParams();
        params.put("page", page);                                         //请求页数
        params.put("status", 0);
        params.put("num", TF_AskVideoListActivity.PAGE_NUM);               //每页条数（默认为10）
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.videoReservation_list), params, new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                //刷新待接通页面数据
                if (result_boolean) {
                    TF_VideoListPageBean videoListpageBean = TF_VideoListPageBean.parserJsonBean(result_bean.getList("data").get(0));
                    if(videoListpageBean!=null){
                        List<TF_VideoListContent> videoListContents = videoListpageBean.getResult();
                        if (!mVideoCanStartFragment.checkGoOn()) {
                            mVideoCanStartFragment.base_refresh_abs_listview.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
                            return;
                        }
                        if (page == 1) {  //如果请求的是第一页的数据将数据清除掉
                            mCanStartBeans.clear();
                            mVideoCanStartFragment.base_all_beans.clear();
                        }
                        if (videoListContents != null && videoListContents.size() > 0) {
                            mCanStartBeans.addAll(videoListContents);
                        }
                        mVideoCanStartFragment.updateSpecialList(mCanStartBeans);
                        mVideoCanStartFragment.setTotalPage(videoListpageBean.getTotalPages() + "");
                    }else{
                        shortToast(QlkServiceHelper.NETWOK_FAIL);
                    }
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(mVideoCanStartFragment != null){
                    mVideoCanStartFragment.doRefreshComplete();
                }
                if (null != result_bean&& GeneralReqExceptionProcess.checkCode(TF_AskVideoListActivity.this,
                        getCode(),
                        getMsg())){

                }
            }

        });

    }

    @Override
    protected void onPause() {
        // add by 崔毅然 on 2016-8-10 根据需求，在视频列表页返回的时候，需要清空个人中心的气泡显示，
        // 根据activity的生命周期，在此处设置清空，返回时先走onpause,再走onstart
        UtilSP.putNewVideoNum(0);
        super.onPause();
    }

    /**
     * 已结束视频列表数据
     *
     * @param page 请求第几页数据
     */
    public void requestOldVideoList(final int page) {
        RequestParams params = new RequestParams();
        params.put("page", page);                                         //请求页数
        params.put("status", 1);
        params.put("num", TF_AskVideoListActivity.PAGE_NUM);               //每页条数（默认为10）
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.videoReservation_list), params, new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                //刷新已结束页面数据
                if (result_boolean) {
                    TF_VideoListPageBean videoListpageBean = TF_VideoListPageBean.parserJsonBean(result_bean.getList("data").get(0));
                    if(videoListpageBean!=null){
                        List<TF_VideoListContent> videoListContents = videoListpageBean.getResult();
                        if (!mVideoListOldEndFragment.checkGoOn()) {
                            mVideoListOldEndFragment.setMode(XCListViewFragment.MODE_DOWN);  //设置只可以下拉
                            return;
                        }
                        if (page == 1) {
                            mFinishBeans.clear();
                            mVideoListOldEndFragment.base_all_beans.clear();
                        }
                        if (videoListContents != null && videoListContents.size() > 0) {
                            mFinishBeans.addAll(videoListContents);
                        }
                        mVideoListOldEndFragment.updateSpecialList(mFinishBeans);
                        mVideoListOldEndFragment.setTotalPage(videoListpageBean.getTotalPages() + "");
                    }else{
                        shortToast(QlkServiceHelper.NETWOK_FAIL);
                    }
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(mVideoListOldEndFragment != null){
                    mVideoListOldEndFragment.doRefreshComplete();
                }
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(TF_AskVideoListActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }

        });
    }

    /**
     * 我知道提示dialog
     *
     * @param content
     */
    public void showNormalDialog(String content) {
        if (mKnowDialog == null) {
            mKnowDialog = new YR_CommonDialog(TF_AskVideoListActivity.this, content, "", "我知道了") {
                @Override
                public void confirmBtn() {
                    mKnowDialog.dismiss();
                    refreshVideoList();
                }
            };
        }
        mKnowDialog.getContentTV().setText(content);
        mKnowDialog.show();
    }

    /**
     * 拒绝原因选择框
     *
     * @param list
     * @param reservationId
     */
    public void showReason(List<YY_RejectVideoReson.DataBean> list, String reservationId) {
        if (resonDialog == null) {
            resonDialog = new YY_RejectVideoResonDialog(this);
        }
        resonDialog.show(list, reservationId);
    }

    /**
     * 接受新视频消息的广播，在底部个人中心标签和个人中心的视频咨询显示数量
     */
    public class NewVideoListReceiver extends BroadcastReceiver {

        public void onReceive(Context context, Intent intent) {
            refreshVideoList();
        }
    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mKnowDialog,resonDialog,mVideoStatusDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        UtilBroadcast.myUnregisterReceiver(this, mNewVideoListReceiver);
        super.onDestroy();
    }

}
