package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.YY_VideoDetailPicAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.TF_VideoListContent;
import com.qlk.ymz.model.YY_RejectVideoReson;
import com.qlk.ymz.model.YY_VideoDetailBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilVideo;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.qlk.ymz.view.YY_RejectVideoResonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import org.apache.http.Header;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * @author shuYanYi on 2016/7/21.
 * @description 视频咨询详情页
 */
public class YY_VideoDetailActivity extends DBActivity {

    /**标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** 患者头像*/
    private XCRoundedImageView xl_patientinfo_ic;
    /**患者姓名*/
    private TextView xl_patientinfo_tv_name;
    /**昵称*/
    private TextView xl_patientinfo_tv_nick_name;
    /**性别图标*/
    private ImageView xl_patientinfo_tv_sex;
    /**年龄*/
    private TextView xl_patientinfo_tv_age;
    /**地区*/
    private TextView xl_patientinfo_tv_area;
    /**患者症状*/
    private LinearLayout ll_patient_symptom;
    /**患者图片*/
    private GridView gv_patient_photo;
//    /**基本信息 */
//    private RelativeLayout xl_patientinfo_tv_basic;
    /** 患者症状文字*/
    private TextView tv_symptom;
    /**诊疗记录 */
    private View rl_video_detail_note;

    /** 两个按钮布局*/
    private View ll_btn2;
    /** 拒绝视频按钮2*/
    private View btn_video_refuse2;
    /** 发送视频通话2 */
    private View btn_video_request2;
    /** 发送图文消息2 */
    private View btn_send_msg2;

    /** 3个按钮布局*/
    private View ll_btn3;
    /** 拒绝视频按钮3 */
    private View btn_video_refuse3;
    /** 发送视频通话3 */
    private View btn_video_request3;
    /** 发送图文消息3 */
    private View btn_send_msg3;

    /** 视频预约id*/
    private String mReservationId;
    /** 患者头像显示设置*/
    private DisplayImageOptions options1 = XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.xc_d_chat_patient_default);

    /** 跳转到聊天/诊疗记录必须封装的对象*/
    private XC_ChatModel xc_chatModel;
    /*** 患者症状图片适配器*/
    private YY_VideoDetailPicAdapter picAdapter;
    /** 普通提示dialog*/
    public YR_CommonDialog normalDialog;

    /** 视频详情数据pojo*/
    YY_VideoDetailBean.DataBean obj;
    /** TF视频列表item bean*/
    private TF_VideoListContent videoItem;
    /** 是否有发送视频按钮*/
    private boolean showRequestVideo = false;
    /** 是否有拒绝视频按钮*/
    private boolean showRefuseVideo = false;
    /** 是否有发送消息按钮*/
    private boolean showSendMsg = false;

    /** 拒绝原因选择对话框*/
    public YY_RejectVideoResonDialog resonDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yy_l_video_detail);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-22,about：saveInfo,begin
        BiUtil.saveBiInfo(YY_VideoDetailActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-22,about：saveInfo,end

        obj = new YY_VideoDetailBean.DataBean();
        Intent intent = getIntent();
        if (intent != null && intent.getSerializableExtra("videoBean") != null) {
            videoItem = (TF_VideoListContent)intent.getSerializableExtra("videoBean");
            mReservationId = String.valueOf(videoItem.getReservationId());
            obj.setStatus(videoItem.getStatus());
            obj.setPatientId(videoItem.getPatientId() + "");
        }

    }


    /** created by songxin,date：2016-8-16,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YY_VideoDetailActivity.class);
    }
    /** created by songxin,date：2016-8-16,about：bi,end */

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xl_patientinfo_ic = getViewById(R.id.xl_patientinfo_ic);
        xl_patientinfo_tv_name = getViewById(R.id.xl_patientinfo_tv_name);
        xl_patientinfo_tv_nick_name = getViewById(R.id.xl_patientinfo_tv_nick_name);
        xl_patientinfo_tv_sex = getViewById(R.id.xl_patientinfo_tv_sex);
        xl_patientinfo_tv_age = getViewById(R.id.xl_patientinfo_tv_age);
        xl_patientinfo_tv_area = getViewById(R.id.xl_patientinfo_tv_area);
        ll_patient_symptom = getViewById(R.id.ll_patient_symptom);
        gv_patient_photo = getViewById(R.id.gv_patient_photo);
//        xl_patientinfo_tv_basic = getViewById(R.id.xl_patientinfo_tv_basic);
        rl_video_detail_note = getViewById(R.id.rl_video_detail_note);

        ll_btn2 = getViewById(R.id.ll_btn2);
        ll_btn3 = getViewById(R.id.ll_btn3);
        btn_video_request2 = getViewById(R.id.btn_video_request2);
        btn_video_request3 = getViewById(R.id.btn_video_request3);
        btn_video_refuse2 = getViewById(R.id.btn_video_refuse2);
        btn_video_refuse3 = getViewById(R.id.btn_video_refuse3);
        btn_send_msg2 = getViewById(R.id.btn_send_msg2);
        btn_send_msg3 = getViewById(R.id.btn_send_msg3);

        tv_symptom = getViewById(R.id.tv_symptom);
        xc_id_model_titlebar.setTitleCenter(true, "视频咨询详情");
        xc_id_model_titlebar.setTitleLeft(true, null);
    }

    @Override
    public void listeners() {
        xl_patientinfo_ic.setOnClickListener(this);
//        xl_patientinfo_tv_basic.setOnClickListener(this);
        rl_video_detail_note.setOnClickListener(this);
        btn_video_request2.setOnClickListener(this);
        btn_video_request3.setOnClickListener(this);
        btn_video_refuse2.setOnClickListener(this);
        btn_video_refuse3.setOnClickListener(this);
        btn_send_msg2.setOnClickListener(this);
        btn_send_msg3.setOnClickListener(this);
    }

    @Override
    public void onNetRefresh() {
        requestVideoDetail();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //请求视频详情
        requestVideoDetail();


    }

    @Override
    public void onClick(final View v) {
        super.onClick(v);
        Intent intent;
        switch(v.getId()){
//            // 基本信息
//            case R.id.xl_patientinfo_tv_basic :
//                intent = new Intent(YY_VideoDetailActivity.this, WY_PatientBasicInfoActivity.class);
//                intent.putExtra(CommonConfig.PATIENT_ID, obj.getPatientId());
//                myStartActivity(intent);
//                break;
            // 诊疗记录
            case R.id.rl_video_detail_note :
                BiUtil.saveBiInfo(YY_VideoDetailActivity.class,"2","128","rl_video_detail_note","",false);
//                intent = new Intent();
                if(xc_chatModel == null){
                    xc_chatModel = new XC_ChatModel();
                    xc_chatModel.getUserPatient().setPatientId(obj.getPatientId() + "");
                }
               /* intent.putExtra(CommonConfig.CHAT_PARAMS_MODEL, xc_chatModel);
                intent.setClass(YY_VideoDetailActivity.this, SX_MedicalRecordsActivity.class);
                startActivity(intent);*/
               toAddMedicRecordList(xc_chatModel);//v2.8 add by xd 直接到添加诊疗记录页
                break;
            //患者头像
            case R.id.xl_patientinfo_ic:
                showBigPic();
                break;
        }

        //发送消息按钮
        if(v.getId() == R.id.btn_send_msg2 || v.getId() == R.id.btn_send_msg3){
            v.setEnabled(false);
            UtilChat.launchChatDetail(YY_VideoDetailActivity.this,obj.getPatientId() + "",new UtilChat.LaunchChatDetailListener(){
                @Override
                public void onError() {
                    shortToast("网络错误,不能发送消息,请您稍后重试!");
                }
                @Override
                public void onFinish() {
                    //使发送按钮变回可按
                    v.setEnabled(true);
                }
            });
            return;
        }

        //请求视频通话按钮
        if(v.getId() == R.id.btn_video_request2 || v.getId() == R.id.btn_video_request3){
            UtilVideo.requestVideo(YY_VideoDetailActivity.this,mReservationId,String.valueOf(obj.getPatientId()));
            return;
        }

        //拒绝视频按钮
        if(v.getId() == R.id.btn_video_refuse2 || v.getId() == R.id.btn_video_refuse3){
            UtilVideo.requestRefuseReson(YY_VideoDetailActivity.this,mReservationId);
            return;
        }

    }


    /**
     * 请求视频预约详情
     */
    public void requestVideoDetail(){
        if(UtilString.isBlank(mReservationId)){
            shortToast("参数异常：视频预约id为空");
            return;
        }
        RequestParams params = new RequestParams();
        params.put("reservationId",mReservationId);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.video_detail), params, new XCHttpResponseHandler<YY_VideoDetailBean>(this, YY_VideoDetailBean.class) {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<YY_VideoDetailBean.DataBean> objLists = mResultModel.getData();
                    if (objLists != null && objLists.size() > 0) {
                        obj = objLists.get(0);
                        String name = obj.getName();//姓名
                        String photo = obj.getPhoto();//头像
                        String gender = obj.getGender();//性别
                        String city = obj.getCity();//城市
                        List<String> files = obj.getFile();//患者症状图片
                        String remarkName = obj.getRemarkName();//备注名
                        String age = obj.getAge();//年龄
                        String detailContent = obj.getDetailContent();
                        //备注名逻辑
                        if (UtilString.isBlank(remarkName)) {
                            xl_patientinfo_tv_name.setText(name);
                            xl_patientinfo_tv_nick_name.setVisibility(View.GONE);
                        } else {
                            xl_patientinfo_tv_name.setText(remarkName);
                            xl_patientinfo_tv_nick_name.setText("昵称: " + name);
                            xl_patientinfo_tv_nick_name.setVisibility(View.VISIBLE);
                        }
                        xl_patientinfo_tv_age.setText(!UtilString.isBlank(age) ? age + "岁" : "");
                        xl_patientinfo_tv_area.setText(city);
                        if (!UtilString.isBlank(gender) && !"未知".equals(gender)) {
                            xl_patientinfo_tv_sex.setImageResource("男".equals(gender) ? R.mipmap.icon_patient_man : R.mipmap.icon_patient_women);
                            xl_patientinfo_tv_sex.setVisibility(View.VISIBLE);
                        }
                        XCApplication.displayImage(photo, xl_patientinfo_ic, options1);

                        //患者症状文字
                        if(!UtilString.isBlank(detailContent)){
                            tv_symptom.setText(detailContent);
                        }

                        //患者症状图片
                        if(files != null && files.size() > 0){
                            if(picAdapter == null){
                                picAdapter = new YY_VideoDetailPicAdapter(YY_VideoDetailActivity.this,files);
                                gv_patient_photo.setAdapter(picAdapter);
                            }else{
                                picAdapter.update(files);
                                picAdapter.notifyDataSetChanged();
                            }
                        }

                        //底排按钮：发起/拒绝按钮的显示隐藏、初/复诊的布局控制
                        refreshBottomBtns(obj);
                    }
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YY_VideoDetailActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }



    /**
     * 底排按钮控制：发起/拒绝按钮的显示隐藏、初/复诊的布局控制
     * @param obj YY_VideoDetailBean.DataBean
     * @return
     */
    public void refreshBottomBtns(YY_VideoDetailBean.DataBean obj){
        int status = obj.getStatus();//状态
        int timeOfAdvent = obj.getTimeOfAdvent();//是否到达预约时间
        int timeOut = obj.getTimeOut();//是否超时
        int firstisit = obj.getFirstisit();//是否初诊

        showSendMsg = firstisit == YY_VideoDetailBean.ViSIT_FIRST ? false : true;
        //根据视频咨询.xmind 用例文档——操作入口——显示 进行处理
        //发送消息按钮
        UtilViewShow.setGone(showSendMsg,btn_send_msg2);
        UtilViewShow.setGone(showSendMsg,btn_send_msg3);
        //发起、拒绝视频按钮
        boolean[] btnStatus = changeVideoBtnStatus(status,timeOut,timeOfAdvent);
        showRequestVideo = btnStatus[0];
        showRefuseVideo = btnStatus[1];
        UtilViewShow.setGone(showRequestVideo,btn_video_request2);
        UtilViewShow.setGone(showRequestVideo,btn_video_request3);
        UtilViewShow.setGone(showRefuseVideo,btn_video_refuse2);
        UtilViewShow.setGone(showRefuseVideo,btn_video_refuse3);

        //两个和3个按钮区分不同布局 这里直接控制按钮父布局显示/隐藏即可
        if(showSendMsg && showRequestVideo && showRefuseVideo){
            //3个按钮
            UtilViewShow.setGone(true,ll_btn3);
            UtilViewShow.setGone(false,ll_btn2);
        }else{
            //2个按钮
            UtilViewShow.setGone(true,ll_btn2);
            UtilViewShow.setGone(false,ll_btn3);
        }
    }


    /**
     * 发起/拒绝按钮的可显示状态（详情页专用逻辑）
     * @param status 状态
     * @param timeOut 是否超时
     * @param timeOfAdvent 是否到预约时间
     * @return boolean {showRequestVideo 是否显示发送视频按钮,showRefuseVideo 是否显示拒绝视频按钮}
     */
    private boolean[] changeVideoBtnStatus(int status,int timeOut,int timeOfAdvent){
        //一开始默认都不显示
        boolean showRequestVideo = false;
        boolean showRefuseVideo = false;

        if(status == YY_VideoDetailBean.STATUS_CANCLE){
            //状态已取消 都不显示
        }else if(status == YY_VideoDetailBean.STATUS_WAIT_ASK){
            //状态待咨询
            if(timeOfAdvent == YY_VideoDetailBean.TIMEOFADVENT_NO){
                //未到预约时间（ 9:00前） 只有拒绝按钮
                showRefuseVideo = true;
            }else if(timeOfAdvent == YY_VideoDetailBean.TIMEOFADVENT_YES && timeOut == YY_VideoDetailBean.TIMEOUT_NO){
                //已到预约时间，未超时（ 9:00-9:30） 有发起和拒绝
                showRequestVideo = true;
                showRefuseVideo = true;
            }
        }else if(status == YY_VideoDetailBean.STATUS_DONE){
            //状态已完成(有有效对话) 没有拒绝按钮
            if(timeOut == YY_VideoDetailBean.TIMEOUT_NO){
                //没超时（9:00-9:30） 有发起
                showRequestVideo = true;
            }
        }

        return new boolean[]{showRequestVideo,showRefuseVideo};
    }


    /**
     * 我知道提示dialog
     * @param content
     */
    public void showNormalDialog(String content){
        if(normalDialog == null){
            normalDialog = new YR_CommonDialog(YY_VideoDetailActivity.this,content,"","我知道了") {
                @Override
                public void confirmBtn() {
                    normalDialog.dismiss();
                    requestVideoDetail();
                }
            };
        }
        normalDialog.show();
    }

    /**
     * 拒绝原因选择框
     */
    public void showReason(List<YY_RejectVideoReson.DataBean> list,String reservationId){
        if(resonDialog == null){
            resonDialog = new YY_RejectVideoResonDialog(this);
        }
        resonDialog.show(list,reservationId);
    }
    /**
     * 跳转到大图
     */
    private void showBigPic() {
        if(UtilString.isBlank(obj.getPhoto())){
            return;
        }
        List pics = new LinkedList();
        pics.add(obj.getPhoto());
        Intent intent = new Intent(YY_VideoDetailActivity.this, XC_ChatImageShowActivity.class);
        intent.putExtra(XC_ChatImageShowActivity.PICTURES_KEY, (Serializable)pics);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        UtilViewShow.destoryDialogs(normalDialog,resonDialog);
    }

    /**
     * 跳转添加诊疗记录
     * v2.8 add by xd
     */
    private void toAddMedicRecordList(XC_ChatModel chatModel) {
        Intent intent = new Intent();
        intent.putExtra(CommonConfig.CHAT_PARAMS_MODEL, chatModel);
        intent.setClass(this, SX_AddMedicalRecordActivity.class);
        myStartActivity(intent);
    }
}
