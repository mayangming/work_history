package com.qlk.ymz.db.noticeRecord;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * 公告操作记录数据库
 * @author zhangpengfei
 * @version 2.3.0
 */
public class NoticeRecordDB {
    // ==========变量==========
    /** 数据库处理对象 */
    private static NoticeRecordDB dbProcessObj = null;
    /** 数据库对象 */
    private SQLiteDatabase db = null;
    /** 上下文对象 */
    private Context context = null;

    // ==========数据库表结构相关数据==========
    /** 数据库版本号 */
    private final int DB_VERSION = 1;
    /** 数据库名 */
    private final static String DATABASE_NAME = "db_noticeRecord";

    // 病情备注信息表
    /** 病情备注信息表名 */
    private static final String TB_NAME_PATIENT_NOTE = "table_noticeRecord";
    /** 主键 */
    private static final String F_ID = "_id";
    /** 医生id */
    public static final String F_DOCTOR_SELF_ID = "doctorSelfId";
    /** 公告类型 */
    public static final String F_TOPIC = "topic";
    /** 最新时间 */
    public static final String F_TIME = "time";
    /** 删除时间 */
    public static final String F_DELETE_TIME = "deleteTime";
    /** 公告状态 0 没有删除 1删除 */
    public static final String F_STATE = "state";
    /** 备用字段1 至 备用字段30 */
    public static final String F_BACK1 = "back1";
    public static final String F_BACK2 = "back2";
    public static final String F_BACK3 = "back3";
    public static final String F_BACK4 = "back4";
    public static final String F_BACK5 = "back5";
    public static final String F_BACK6 = "back6";
    public static final String F_BACK7 = "back7";
    public static final String F_BACK8 = "back8";
    public static final String F_BACK9 = "back9";
    public static final String F_BACK10 = "back10";
    public static final String F_BACK11 = "back11";
    public static final String F_BACK12 = "back12";
    public static final String F_BACK13 = "back13";
    public static final String F_BACK14 = "back14";
    public static final String F_BACK15 = "back15";
    public static final String F_BACK16 = "back16";
    public static final String F_BACK17 = "back17";
    public static final String F_BACK18 = "back18";
    public static final String F_BACK19 = "back19";
    public static final String F_BACK20 = "back20";

    /**
     * 数据库助手类
     */
    private class DbHelper extends SQLiteOpenHelper {
        /**
         * 构造方法
         * @param context 上下文对象
         */
        public DbHelper(Context context) {
            super(context, DATABASE_NAME, null, DB_VERSION);
        }

        /**
         * 初始化数据库
         * @param db 数据库对象
         */
        public void onCreate(SQLiteDatabase db) {
            // sql文
            String sql = new String();

            // 创建“咨询列表信息表”
            sql = "create table " + TB_NAME_PATIENT_NOTE +
                    "(" +
                    F_ID + " integer primary key AUTOINCREMENT," +
                    F_DOCTOR_SELF_ID + " text, " +
                    F_TOPIC + " text, " +
                    F_TIME + " text, " +
                    F_DELETE_TIME + " text, " +
                    F_STATE + " text, " +
                    F_BACK1 + " text, " +
                    F_BACK2 + " text, " +
                    F_BACK3 + " text, " +
                    F_BACK4 + " text, " +
                    F_BACK5 + " text, " +
                    F_BACK6 + " text, " +
                    F_BACK7 + " text, " +
                    F_BACK8 + " text, " +
                    F_BACK9 + " text, " +
                    F_BACK10 + " text, " +
                    F_BACK11 + " text, " +
                    F_BACK12 + " text, " +
                    F_BACK13 + " text, " +
                    F_BACK14 + " text, " +
                    F_BACK15 + " text, " +
                    F_BACK16 + " text, " +
                    F_BACK17 + " text, " +
                    F_BACK18 + " text, " +
                    F_BACK19 + " text, " +
                    F_BACK20 + " text" +
                    ")";
            db.execSQL(sql);
        }

        /**
         * 更新数据库
         * @param db 数据库对象
         * @param oldVersion 数据库的旧版本号
         * @param newVersion 数据库的新版本号
         */
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            if(newVersion > oldVersion) {
                db.execSQL("drop table if exists " + TB_NAME_PATIENT_NOTE);
                onCreate(db);
            }
        }
    }

    /**
     * 构造方法
     * @param context 上下文
     */
    private NoticeRecordDB(Context context) {
        this.context = context;
    }

    /**
     * 获取数据库适配器对象
     * @param context 上下文对象
     * @return 数据库处理对象
     */
    public static NoticeRecordDB getInstance(Context context) {
        if(null == dbProcessObj) {
            dbProcessObj = new NoticeRecordDB(context);
        }
        return dbProcessObj.openDataBase(context);
    }

    /**
     * 获取数据库操作权限
     * @param context 上下文对象
     * @return 数据库操作操作对象
     */
    private NoticeRecordDB openDataBase(Context context) {
        DbHelper dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
        return dbProcessObj;
    }

    /**
     * 关闭数据库
     */
    private void closeDataBase() {
        try {
            if(null != db && db.isOpen()) {
                db.close();
            }
        }catch(Exception e) {
            System.out.println("---close database happened exception---");
            e.printStackTrace();
        }
    }

    /**
     * 保存公告操作信息
     * 保存的时候deleteTime不需要传
     * @param noticeRecordModel 公告操作信息BEAN
     * @return 被操作记录的主键。当发生错误时，返回-1。
     */
    public long saveInfo(NoticeRecordModel noticeRecordModel) {
        if(null == noticeRecordModel) {
            closeDataBase();
            return -1;
        }

        // 行记录的主键值
        long rowId = 0;
        // 表中是否存在相同信息的标示（true：存在，false：不存在，默认值：false）
        boolean flag = false;

        String queryClause = F_TOPIC + "=?" + " AND " + F_DOCTOR_SELF_ID + "=?"; // 查询条件
        String[] queryClauseParamStrings = new String[]{noticeRecordModel.getTopic(), noticeRecordModel.getDoctorSelfId()}; // 查询条件的参数值
        Cursor queryCursor = db.query(TB_NAME_PATIENT_NOTE, null, queryClause, queryClauseParamStrings, null, null, null);
        flag = queryCursor.moveToNext();

        // 以“公告类型”及“医生ID”联合作为判断条件，若表中没有相同的信息，则进行插入操作
        if(flag == false) {
            ContentValues values = noticeRecordModel2ContentValues(noticeRecordModel);
            rowId = db.insert(TB_NAME_PATIENT_NOTE, F_ID, values);
        }
        // 若表中有相同的信息，则进行更新操作
        else {
            // 要更新的记录主键
            long tempRowId = queryCursor.getInt(queryCursor.getColumnIndex(F_ID));

            // 进行更新操作
            String updateClause = F_TOPIC + "=?" + " AND " + F_DOCTOR_SELF_ID + "=?"; // 更新条件
            String[] updateClauseParamStrings = new String[]{noticeRecordModel.getTopic(), noticeRecordModel.getDoctorSelfId()}; // 更新条件的参数值
            ContentValues contentValues = noticeRecordModel2ContentValues(noticeRecordModel);
            int numberOfRowsAffected = db.update(TB_NAME_PATIENT_NOTE, contentValues, updateClause, updateClauseParamStrings);

            if(numberOfRowsAffected > 0) {
                rowId = tempRowId;
            }
        }

        queryCursor.close();
        closeDataBase();
        return rowId;
    }
    /**
     * 更新公告操作信息
     * topic 和 doctorId 不能为空,必须传
     * @param noticeRecordModel 公告操作信息BEAN
     * @return 被操作记录的主键。当发生错误时，返回-1。
     */
    public boolean updateNoticeState(NoticeRecordModel noticeRecordModel) {
        boolean flag = false;
        if(null == noticeRecordModel && UtilString.isBlank(noticeRecordModel.getTopic()) && UtilString.isBlank(noticeRecordModel.getDoctorSelfId())) {
            closeDataBase();
            return flag;
        }
        // 进行更新操作
        String updateClause = F_TOPIC + "=?" + " AND " + F_DOCTOR_SELF_ID + "=?"; // 更新条件
        String[] updateClauseParamStrings = new String[]{noticeRecordModel.getTopic(), noticeRecordModel.getDoctorSelfId()}; // 更新条件的参数值

        ContentValues contentValues = new ContentValues();
        contentValues.put(F_STATE, noticeRecordModel.getState());
        if (!UtilString.isBlank(noticeRecordModel.getDeleteTime())){
            contentValues.put(F_DELETE_TIME, noticeRecordModel.getDeleteTime());
        }
        if (!UtilString.isBlank(noticeRecordModel.getTime())){
            contentValues.put(F_TIME, noticeRecordModel.getTime());
        }
        int numberOfRowsAffected = db.update(TB_NAME_PATIENT_NOTE, contentValues, updateClause, updateClauseParamStrings);
        if(numberOfRowsAffected > 0) {
            flag = true;
        }
        closeDataBase();
        return flag;
    }
    /**
     * 根据“公告类型”及“医生id”查询公告信息”
     * @param topic 公告类型
     * @param doctorId 医生id
     * @return 公告操作记录
     */
    public NoticeRecordModel getInfo(String topic, String doctorId) {
        NoticeRecordModel patientInfoModel = new NoticeRecordModel();

        String[] columns = null;
        String selection = F_TOPIC + "=?" + " AND " + F_DOCTOR_SELF_ID + "=?";
        String[] selectionArgs = new String[]{topic, doctorId};
        Cursor cursor = db.query(TB_NAME_PATIENT_NOTE, columns, selection, selectionArgs, null, null, null);

        if(cursor.moveToNext()) {
            patientInfoModel = cursor2PatientInfoModel(cursor);
        }

        cursor.close();
        closeDataBase();
        return patientInfoModel;
    }

    /**
     * 将NoticeRecordModel业务信息对象转换成ContentValues对象
     * @param noticeRecordModel 公告操作信息BEAN
     * @return 转换后得到的ContentValues对象
     */
    private ContentValues noticeRecordModel2ContentValues(NoticeRecordModel noticeRecordModel) {
        ContentValues contentValuesObj = new ContentValues();

        contentValuesObj.put(F_DOCTOR_SELF_ID, noticeRecordModel.getDoctorSelfId()); // 医生id
        contentValuesObj.put(F_TOPIC, noticeRecordModel.getTopic()); // 公告类型
        contentValuesObj.put(F_TIME, noticeRecordModel.getTime()); // 最新时间
        if (!UtilString.isBlank(noticeRecordModel.getDeleteTime())){
            contentValuesObj.put(F_DELETE_TIME, noticeRecordModel.getDeleteTime()); // 删除时间
        }
        contentValuesObj.put(F_STATE, noticeRecordModel.getState()); // 公告状态
        contentValuesObj.put(F_BACK1, ""); // 备用字段1
        contentValuesObj.put(F_BACK2, ""); // 备用字段2
        contentValuesObj.put(F_BACK3, ""); // 备用字段3
        contentValuesObj.put(F_BACK4, ""); // 备用字段4
        contentValuesObj.put(F_BACK5, ""); // 备用字段5
        contentValuesObj.put(F_BACK6, ""); // 备用字段6
        contentValuesObj.put(F_BACK7, ""); // 备用字段7
        contentValuesObj.put(F_BACK8, ""); // 备用字段8
        contentValuesObj.put(F_BACK9, ""); // 备用字段9
        contentValuesObj.put(F_BACK10, ""); // 备用字段10
        contentValuesObj.put(F_BACK11, ""); // 备用字段11
        contentValuesObj.put(F_BACK12, ""); // 备用字段12
        contentValuesObj.put(F_BACK13, ""); // 备用字段13
        contentValuesObj.put(F_BACK14, ""); // 备用字段14
        contentValuesObj.put(F_BACK15, ""); // 备用字段15
        contentValuesObj.put(F_BACK16, ""); // 备用字段16
        contentValuesObj.put(F_BACK17, ""); // 备用字段17
        contentValuesObj.put(F_BACK18, ""); // 备用字段18
        contentValuesObj.put(F_BACK19, ""); // 备用字段19
        contentValuesObj.put(F_BACK20, ""); // 备用字段20

        return contentValuesObj;
    }


    private NoticeRecordModel cursor2PatientInfoModel(Cursor cursor) {
        NoticeRecordModel noticeRecordModel = new NoticeRecordModel();

        noticeRecordModel.setDoctorSelfId(cursor.getString(cursor.getColumnIndex(F_DOCTOR_SELF_ID))); // 医生id
        noticeRecordModel.setTopic(cursor.getString(cursor.getColumnIndex(F_TOPIC))); // 公告类型
        noticeRecordModel.setTime(cursor.getString(cursor.getColumnIndex(F_TIME))); // 最新时间
        noticeRecordModel.setDeleteTime(cursor.getString(cursor.getColumnIndex(F_DELETE_TIME))); // 删除时间
        noticeRecordModel.setState(cursor.getString(cursor.getColumnIndex(F_STATE))); // 公告状态
        noticeRecordModel.setBack1(cursor.getString(cursor.getColumnIndex(F_BACK1))); // 备用字段1
        noticeRecordModel.setBack2(cursor.getString(cursor.getColumnIndex(F_BACK2))); // 备用字段2
        noticeRecordModel.setBack3(cursor.getString(cursor.getColumnIndex(F_BACK3))); // 备用字段3
        noticeRecordModel.setBack4(cursor.getString(cursor.getColumnIndex(F_BACK4))); // 备用字段4
        noticeRecordModel.setBack5(cursor.getString(cursor.getColumnIndex(F_BACK5))); // 备用字段5
        noticeRecordModel.setBack6(cursor.getString(cursor.getColumnIndex(F_BACK6))); // 备用字段6
        noticeRecordModel.setBack7(cursor.getString(cursor.getColumnIndex(F_BACK7))); // 备用字段7
        noticeRecordModel.setBack8(cursor.getString(cursor.getColumnIndex(F_BACK8))); // 备用字段8
        noticeRecordModel.setBack9(cursor.getString(cursor.getColumnIndex(F_BACK9))); // 备用字段9
        noticeRecordModel.setBack10(cursor.getString(cursor.getColumnIndex(F_BACK10))); // 备用字段10
        noticeRecordModel.setBack11(cursor.getString(cursor.getColumnIndex(F_BACK11))); // 备用字段11
        noticeRecordModel.setBack12(cursor.getString(cursor.getColumnIndex(F_BACK12))); // 备用字段12
        noticeRecordModel.setBack13(cursor.getString(cursor.getColumnIndex(F_BACK13))); // 备用字段13
        noticeRecordModel.setBack14(cursor.getString(cursor.getColumnIndex(F_BACK14))); // 备用字段14
        noticeRecordModel.setBack15(cursor.getString(cursor.getColumnIndex(F_BACK15))); // 备用字段15
        noticeRecordModel.setBack16(cursor.getString(cursor.getColumnIndex(F_BACK16))); // 备用字段16
        noticeRecordModel.setBack17(cursor.getString(cursor.getColumnIndex(F_BACK17))); // 备用字段17
        noticeRecordModel.setBack18(cursor.getString(cursor.getColumnIndex(F_BACK18))); // 备用字段18
        noticeRecordModel.setBack19(cursor.getString(cursor.getColumnIndex(F_BACK19))); // 备用字段19
        noticeRecordModel.setBack20(cursor.getString(cursor.getColumnIndex(F_BACK20))); // 备用字段20

        return noticeRecordModel;
    }
}
