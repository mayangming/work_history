package com.qlk.ymz.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.PF_PayServieceInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.OtherSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.view.XCSwitchButton;

import org.apache.http.Header;

import java.util.List;

/**
 * 付费服务
 * @author zhangpengfei
 * @version 2.0
 */
public class PF_PayServiceActivity extends DBActivity {
    /** title */
    private RelativeLayout xc_id_model_titlebar;
    /** 左边的image */
    private LinearLayout xc_id_titlebar_left_layout;
    private ImageView xc_id_titlebar_left_imageview;
    /**title上面文字*/
    private TextView xc_id_titlebar_center_textview;
    /**title下面文字*/
    private TextView xc_id_titlebar_bottom_textview;
    /**保存*/
    private TextView xc_id_titlebar_save;
    /**付费咨询*/
    private XCSwitchButton pr_id_pay_service_btn;
    private LinearLayout pr_id_pay_service_price_ll;
    /**加*/
    private ImageView pr_id_pay_service_price_sub;
    /**价格*/
    private TextView pr_id_pay_service_price;
    /**减*/
    private ImageView pr_id_pay_service_price_add;
    /**收费状态 true=收费  false=不收费*/
    private boolean isPay = false;
    /**金额*/
    private int price;
    private PF_PayServieceInfo.DataEntity.MessageConsultEntity dataEntity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_activity_pay_service);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_PayServiceActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        dataEntity = new PF_PayServieceInfo.DataEntity.MessageConsultEntity();
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_titlebar_left_layout = getViewById(R.id.xc_id_titlebar_left_layout);
        xc_id_titlebar_left_imageview = getViewById(R.id.xc_id_titlebar_left_imageview);
        xc_id_titlebar_center_textview = getViewById(R.id.xc_id_titlebar_center_textview);
        xc_id_titlebar_bottom_textview = getViewById(R.id.xc_id_titlebar_bottom_textview);
        xc_id_titlebar_save = getViewById(R.id.xc_id_titlebar_save);
        pr_id_pay_service_btn = getViewById(R.id.pr_id_pay_service_btn);
        pr_id_pay_service_price_ll = getViewById(R.id.pr_id_pay_service_price_ll);
        pr_id_pay_service_price_sub = getViewById(R.id.pr_id_pay_service_price_sub);
        pr_id_pay_service_price = getViewById(R.id.pr_id_pay_service_price);
        pr_id_pay_service_price_add = getViewById(R.id.pr_id_pay_service_price_add);
        if (isPay){
            pr_id_pay_service_btn.setState(true);
        }else {
            pr_id_pay_service_btn.setState(false);
        }
        requestData();
    }

    @Override
    public void listeners() {
        xc_id_titlebar_save.setOnClickListener(this);
        pr_id_pay_service_price_sub.setOnClickListener(this);
        pr_id_pay_service_price_add.setOnClickListener(this);
        xc_id_titlebar_left_imageview.setOnClickListener(this);
        pr_id_pay_service_btn.setSlideListener(new XCSwitchButton.SwitchButtonListener() {
            @Override
            public void open() {
                pr_id_pay_service_price_ll.setVisibility(View.VISIBLE);
                isPay = true;
            }

            @Override
            public void close() {
                pr_id_pay_service_price_ll.setVisibility(View.GONE);
                isPay = false;
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch(v.getId()){
            // 保存
            case R.id.xc_id_titlebar_save :
                saveData();
                break;
            // 加
            case R.id.pr_id_pay_service_price_add :
                price ++;
                if (price > dataEntity.getMaxCharge()/100){
                    price = dataEntity.getMaxCharge()/100;
                }
                pr_id_pay_service_price.setText(price + ".00");
                break;
            // 减
            case R.id.pr_id_pay_service_price_sub :
                price --;
                if (price < dataEntity.getMinCharge()/100){
                    price = dataEntity.getMinCharge()/100;
                }
                pr_id_pay_service_price.setText(price + ".00");
                break;
            case R.id.xc_id_titlebar_left_imageview :
                myFinish();
                break;
            default:

                break;

        }
    }

    /**
     * 请求数据
     */
    private void requestData() {
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.charge_query),  new RequestParams(), new XCHttpResponseHandler<PF_PayServieceInfo>(this, PF_PayServieceInfo.class) {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<PF_PayServieceInfo.DataEntity> objLists = mResultModel.getData();
                    if (null != objLists && objLists.size() > 0) {
                        if (null != objLists.get(0) && null != objLists.get(0).getMessageConsult()) {
                            dataEntity = objLists.get(0).getMessageConsult();
                            if (dataEntity.isIsCharge()) {
                                pr_id_pay_service_btn.setState(true);
                            } else {
                                pr_id_pay_service_btn.setState(false);
                            }
                            OtherSP.putIsCharge(dataEntity.isIsCharge());
                            pr_id_pay_service_price.setText(dataEntity.getCurrentCharge() / 100 + ".00");
                            price = dataEntity.getCurrentCharge() / 100;
                        }
                    }
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(PF_PayServiceActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    /**
     * 保存数据
     */
    private void saveData() {
        RequestParams params = new RequestParams();
        params.put("type", 1);
        if (isPay){
            params.put("isCharge", 1);
            params.put("charge", price * 100);
        }else{
            params.put("isCharge", 0);
            params.put("charge", dataEntity.getDefaultCharge());
        }
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.charge_setting), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(PF_PayServiceActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                    OtherSP.putIsCharge(isPay);
                    onBackPressed();
                }
            }
        });
    }
}
