package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 聊天详情  患者 个性化服务收费确认UI
 */
public class XC_ChatLeftIndividuationCostHolder extends XC_ChatLeftBaseHolder {

    public View id_left_individuation_cost_layout;
    public TextView id_left_individuation_cost_title;
    public TextView id_left_individuation_cost_content;

    public XC_ChatLeftIndividuationCostHolder(View convertView) {
        super(convertView);
        id_left_individuation_cost_layout = convertView.findViewById(R.id.id_left_individuation_cost_layout);
        id_left_individuation_cost_title = (TextView) convertView.findViewById(R.id.id_left_individuation_cost_title);
        id_left_individuation_cost_content = (TextView) convertView.findViewById(R.id.id_left_individuation_cost_content);
    }
}