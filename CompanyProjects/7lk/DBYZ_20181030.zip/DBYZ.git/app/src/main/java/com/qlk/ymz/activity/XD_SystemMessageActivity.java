package com.qlk.ymz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SystemMessageAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.SystemMessageBean;
import com.qlk.ymz.parse.Parse2SystemMessageBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.SystemMessageUtil;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilBroadcast;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2018/8/1.
 * 系统消息页（医生学院、系统公告、系统通知、行业新闻）
 */

public class XD_SystemMessageActivity extends DBActivity {
    public static final String SYSTEM_MESSAGE = "systemMessage";
    private XCTitleCommonLayout xc_id_model_titlebar;
    private RecyclerView mRecyclerView;
    private SystemMessageAdapter mSystemMessageAdapter;
    private List<SystemMessageBean> mSystemMessageBeanList = new ArrayList<>();
    private List<SystemMessageBean> mSystemMessageBeans = new ArrayList<>();//此数据用于展示
    /** 两次收到聊天咨询信息时间差（单位：毫秒） */
    private final int timeGap = 700;
    /** 记录上一次收到咨询push消息的时间（单位：毫秒） */
    private long last_message_time;
    private SystemMessageReceiver chat_detail_receiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_system_message);
        super.onCreate(savedInstanceState);
        // 注册“聊天消息广播接收器”
        chat_detail_receiver = new SystemMessageReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000,SYSTEM_MESSAGE, chat_detail_receiver);
        // 注册“有新患者广播接收器”
        requestData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_SystemMessageActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    private void requestData() {
        RequestParams params = new RequestParams();
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.NOTICE_LIST), params,
                new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            Parse2SystemMessageBean parse2SystemMessageBean = new Parse2SystemMessageBean(mSystemMessageBeanList);
                            parse2SystemMessageBean.parseJson(result_bean);
                            covertData();
                            mSystemMessageAdapter.notifyDataSetChanged();
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        showNoNetLayout();
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        // 处理code操作
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_SystemMessageActivity.this, getCode(), getMsg())) {
                        }
                    }

                });
    }

    private void covertData() {
        mSystemMessageBeans.clear();
        for(SystemMessageBean systemMessageBean:mSystemMessageBeanList){
            if(!TextUtils.isEmpty(systemMessageBean.getTitle())){
                mSystemMessageBeans.add(systemMessageBean);
            }
        }
    }

    @Override
    public void onNetRefresh() {
        requestData();
    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "系统消息");
        xc_id_model_titlebar.setTitleLeft(true, "");
        mRecyclerView = getViewById(R.id.rv_message);
        mRecyclerView.setHasFixedSize(true);
        //设置recyclerview的布局方式
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mSystemMessageAdapter = new SystemMessageAdapter(this,mSystemMessageBeans);
        mRecyclerView.setAdapter(mSystemMessageAdapter);
    }

    @Override
    public void listeners() {
    }

    private void updateData(){
        List<SystemMessageBean> systemMessageList = SystemMessageUtil.getSystemMessageList(UtilSP.getSystemMessage());
        if(!UtilCollection.isBlank(systemMessageList)){
            SystemMessageBean systemMessageBean = systemMessageList.get(systemMessageList.size() - 1);
            for(SystemMessageBean messageBean :mSystemMessageBeanList){
                if(systemMessageBean.getNoticeType().equals(messageBean.getNoticeType())){
                    if(TextUtils.isEmpty(messageBean.getTitle())||UtilString.toLong(systemMessageBean.getSendTime()) >UtilString.toLong(messageBean.getSendTime())){
                        messageBean.setTitle(systemMessageBean.getTitle());
                        messageBean.setSendTime(systemMessageBean.getSendTime());
                    }
                }
            }
            covertData();
        }
    }

    public class SystemMessageReceiver extends BroadcastReceiver {
        public void onReceive(Context context, Intent intent) {
            if (System.currentTimeMillis() - last_message_time > timeGap) {
                updateData();
                mSystemMessageAdapter.notifyDataSetChanged();
            } else {
                mHandler.removeCallbacks(temp);
                mHandler.postDelayed(temp, timeGap);
            }

            last_message_time = System.currentTimeMillis();
        }
    }
    @Override
    public void myFinish() {
        super.myFinish();
        UtilSP.setNoticeDot(false);
    }

    @Override
    protected void onDestroy() {
        UtilBroadcast.myUnregisterReceiver(this, chat_detail_receiver);
        super.onDestroy();
    }

    private Runnable temp = new Runnable() {
        public void run() {
            updateData();
            mSystemMessageAdapter.notifyDataSetChanged();
        }
    };

    private Handler mHandler = new Handler(Looper.getMainLooper());
}
