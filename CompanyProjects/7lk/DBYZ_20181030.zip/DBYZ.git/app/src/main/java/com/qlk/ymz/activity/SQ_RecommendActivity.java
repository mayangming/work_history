package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SQ_RecommendAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.InventoryInfo;
import com.qlk.ymz.model.RecipeBean;
import com.qlk.ymz.model.RecommendInfo;
import com.qlk.ymz.model.SK_RecommendInfo;
import com.qlk.ymz.model.SafeMedicationBean;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.parse.Parse2InventoryInfo;
import com.qlk.ymz.parse.Parse2SafeMedication;
import com.qlk.ymz.parse.Parser2SQRecommendInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.UtilNum;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author 赖善琦
 *
 * 推荐用药界面
 *
 */
public class SQ_RecommendActivity extends DBActivity {

    private XCTitleCommonLayout title_common_layout;
    private XCBaseActivity mContext;//上下文对象
    private ListView ordonnance_medicines_lv;//药品名称显示列表
    private View ym_ordonnance_head_view;// 头布局
    private View ym_ordonnance_foot_view;// 尾部局
    private TextView ordonnance_patient_date;//诊断时间(时间从本地获取)
    private TextView tv_recommend_tltle; // 处方笺标题
    private TextView ym_ordonnance_patient_name;//患者姓名(单行显示,显示不完显示...)
    private TextView ym_ordonnance_patient_age;//患者年龄
    private TextView ym_ordonnance_number;//处方单编号(共16位,长度固定，分四部分)
    private TextView ym_ordonnance_patient_sex;//患者性别(获取不到显示空)
    private TextView ym_ordonnance_diacrisis_edt;//临床诊断输入框(字符长度限制为19字)
    private ImageView ym_ordonnance_medicines_add;//处方笺的添加药品按钮
    private TextView ym_ordonnance_medicition_send;//发送按钮
    private TextView ym_ordonnance_doctor_name;//医师姓名
    private TextView ym_ordonnance_department_name;//科室
    private TextView sq_id_ordonnance_edit;//编辑按钮
    private TextView tv_total_price; // 总金额

    private RecommendInfo recommendInfo;

    public static int REQUEST_CODE_DIAGNOSE = 101;
    /**
     * 用药确认列表的adapter
     */
    private SQ_RecommendAdapter recommendAdapter;
    /**
     * IM传过来的model
     */
    private XC_PatientDrugInfo patientDrugInfo;
    /**
     * 用药确认列表的数据
     */
    private List<DrugBean> mDrugBeanList = new ArrayList<>();

    private String ordonnanceNumber = "";//处方单编号
    private XC_ChatModel chatModel;//聊天实体类

    private YR_CommonDialog mYR_commonDialog;//用法用量提示对话框

    /**
     * 药品是否勾选的map集合
     */
    private Map<String, Boolean> checkDrugMap = new HashMap<>();
    private List<String> diagnosisList = new ArrayList<>();
    // 编辑按钮对应的当前文案，true ： 编辑，false：完成
    private boolean isEdit = true;

    // 点击了哪个item的修改用法  position = 位置
    private int editPosition = -1;

    @Override
    protected void onStart() {
        super.onStart();
        //created by songxin,date：2017-9-26,about：bi,begin
        BiUtil.savePid(SQ_RecommendActivity.class);
        //created by songxin,date：2017-9-26,about：bi,end
        // 查询库存信息
        requestGetInventoryInfo(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(!UtilSP.isRecomSafe()) {
            requestRemind();
        }
        recommendAdapter.notifyDataSetChanged();
    }


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        DrugBean drugBean = (DrugBean) intent.getSerializableExtra(UsageActivityV2.DRUG_INFO);
        if(null == drugBean) {
            getData();
            setDataToViews();
        }else {
            // 添加药品
            sq_id_ordonnance_edit.setVisibility(View.VISIBLE);
            setSaveTextViewState(0);
            mDrugBeanList.add(drugBean);
            checkDrugMap.put(drugBean.getId(),true);
            computeTotalPrice();
        }
    }

    /**
     * 启动此activity
     */
    public static void launch(Context context) {
        // 是否为灰度医生，true：是
        if(UtilSP.isRecordRecom()) {
            Intent intent = new Intent(context, SQ_RecommendActivity.class);
            (context).startActivity(intent);
        }else {
            // 2.18以前的推药流程
            Intent intent = new Intent(context, SQ_RecommendActivity218.class);
            (context).startActivity(intent);
        }
    }
    /**
     * 启动此activity
     */
    public static void launch(Context context,DrugBean bean) {
        // 是否为灰度医生，true：是
        if(UtilSP.isRecordRecom()) {
            Intent intent = new Intent(context, SQ_RecommendActivity.class);
            intent.putExtra(UsageActivityV2.DRUG_INFO, bean);
            (context).startActivity(intent);
        }else {
            Intent intent = new Intent(context, SQ_RecommendActivity218.class);
            intent.putExtra(UsageActivityV2.DRUG_INFO, bean);
            (context).startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sq_activity_recommend);
        super.onCreate(savedInstanceState);
    }

    /**
     * 从intent获取数据
     */
    private void getData() {
        patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
        recommendInfo = patientDrugInfo.getRecommendInfo();
        recommendInfo.setPatientName(((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getName());
        recommendInfo.setPatientAge(((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getAge());
        recommendInfo.setPatientAgeUnit(((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getAgeUnit());
        recommendInfo.setPatientGender(((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getGender());
        recommendInfo.setDiagnosis(((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getDiagnosis());

        diagnosisList = ((DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO()).getDiagnosisList();

        if (UtilString.isBlank(recommendInfo.getTitle())) {
            requestInitData();
        }

        mDrugBeanList = patientDrugInfo.getList();
        checkDrugMap = patientDrugInfo.getCheckDrugMap();
        chatModel = patientDrugInfo.getChatModel();
    }

    /**
     *  计算总金额
     */
    private void computeTotalPrice() {

        if(UtilCollection.isBlank(mDrugBeanList)){
            tv_total_price.setVisibility(View.GONE);
            return;
        }else {
            tv_total_price.setVisibility(View.VISIBLE);
        }

        long total = 0;
        for (DrugBean drugBean : mDrugBeanList){

            total = total + UtilNum.yuan2FenBigDecimal(UtilString.toDouble(drugBean.getSalePrice()))
                        * UtilString.toLong(drugBean.getMedicineUsageBean().getQuantity());
        }
        tv_total_price.setText("总金额："+AppConfig.renminbi+" "+StringUtils.getMoneyString(total));
        recommendInfo.setTotalPrice(StringUtils.getMoneyString(total));

    }

    /**
     * 初始化控件
     */
    @Override
    public void initWidgets() {
        mContext = this;
        getData();

        title_common_layout = getViewById(R.id.title_common_layout);
        ordonnance_medicines_lv = getViewById(R.id.ym_ordonnance_medicines_lv);
        ym_ordonnance_medicition_send = getViewById(R.id.ym_ordonnance_medicition_send);

        //以下为药品显示列表的HeadView的控件初始化 start
        ym_ordonnance_head_view = getLayoutInflater().inflate(R.layout.sq_view_ordonnance_head2, null);
        ordonnance_patient_date = (TextView) ym_ordonnance_head_view.findViewById(R.id.ordonnance_patient_date);
        tv_recommend_tltle = (TextView) ym_ordonnance_head_view.findViewById(R.id.tv_recommend_tltle);
        ym_ordonnance_patient_name = (TextView) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_patient_name);
        ym_ordonnance_patient_age = (TextView) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_patient_age);
        ym_ordonnance_number = (TextView) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_number);
        ym_ordonnance_patient_sex = (TextView) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_patient_sex);
        ym_ordonnance_diacrisis_edt = (TextView) ym_ordonnance_head_view.findViewById(R.id.ym_ordonnance_diacrisis_edt);
        sq_id_ordonnance_edit = (TextView) ym_ordonnance_head_view.findViewById(R.id.sq_id_ordonnance_edit);
        if(!UtilCollection.isBlank(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getRecommendInfo().getDrugInfoBean())){
            sq_id_ordonnance_edit.setVisibility(View.VISIBLE);
        }else {
            sq_id_ordonnance_edit.setVisibility(View.GONE);
        }

        //以上为药品显示列表的HeadView的控件初始化 end

        //以下为药品显示列表的FootView的控件初始化 start
        ym_ordonnance_foot_view = getLayoutInflater().inflate(R.layout.sq_dialog_ordonnance_foot, null);
        ym_ordonnance_medicines_add = (ImageView) ym_ordonnance_foot_view.findViewById(R.id.ym_ordonnance_medicines_add);
        ym_ordonnance_doctor_name = (TextView) ym_ordonnance_foot_view.findViewById(R.id.ym_ordonnance_doctor_name);
        ym_ordonnance_department_name = (TextView) ym_ordonnance_foot_view.findViewById(R.id.ym_ordonnance_department_name);
        tv_total_price = (TextView) ym_ordonnance_foot_view.findViewById(R.id.tv_total_price);
        //以上为药品显示列表的FootView的控件初始化 end

        ordonnance_medicines_lv.addHeaderView(ym_ordonnance_head_view);
        ordonnance_medicines_lv.addFooterView(ym_ordonnance_foot_view);
        ym_ordonnance_medicition_send.setText("下一步，预览病历和处方");
        title_common_layout.getXc_id_titlebar_center_textview().setTextSize(TypedValue.COMPLEX_UNIT_DIP,18);
        title_common_layout.setTitleLeft(true, null);
        title_common_layout.setTitleCenter(true, "处方详情");
        title_common_layout.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returnToChoiceMedicineActivity();
            }
        });

        setSaveTextViewState(0);

        title_common_layout.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if("保存常用".equals(title_common_layout.getXc_id_titlebar_right2_textview().getText().toString())){
                    // created by songxin,date：2018-01-09,about：saveInfo,begin
                    BiUtil.saveBiInfo(SQ_RecommendActivity.class, "2", "128", "E00098","", false);
                    // created by songxin,date：2018-01-09,about：saveInfo,end
                    if (UtilSP.isRecomSafe()){
                        requestSafeMedication();
                    }else {
                        addPrescription();
                    }
                }
            }
        });

        recommendAdapter = new SQ_RecommendAdapter(mContext, mDrugBeanList);
        ordonnance_medicines_lv.setAdapter(recommendAdapter);

        setDataToViews();
        computeTotalPrice();

    }

    /**
     * 初始化列表数据
     */
    private void setDataToViews() {
        tv_recommend_tltle.setText(recommendInfo.getTitle());

        if (null == chatModel) {
            chatModel = new XC_ChatModel();
        }
        String patientGender = recommendInfo.getPatientGender() + "";
        if (CommonConfig.GENDER_MALE.equals(patientGender)) {
            patientGender = "男";
        } else if (CommonConfig.GENDER_FEMALE.equals(patientGender)) {
            patientGender = "女";
        } else {
            patientGender = "";
        }
        try {
            String date = DateFormat.format("yyyy/MM/dd", Long.parseLong(recommendInfo.getRecomTime())).toString();
            ordonnance_patient_date.setText(date);
            ym_ordonnance_patient_name.setText(recommendInfo.getPatientName());
            ym_ordonnance_patient_age.setText(recommendInfo.getPatientAge() + recommendInfo.getPatientAgeUnit());
            ym_ordonnance_number.setText(recommendInfo.getSerialNumber());
            ym_ordonnance_patient_sex.setText(patientGender);
            ym_ordonnance_doctor_name.setText(recommendInfo.getDoctorName());
            ym_ordonnance_department_name.setText(recommendInfo.getDepartmentName());
            setDiagnosisText();
        } catch (Exception e) {
            //防止获取的值为""，导致的异常警告
            e.printStackTrace();
        }

        recommendAdapter.setRecommendAdapterOnClickListener(new SQ_RecommendAdapter.RecommendAdapterOnClickListener() {
            @Override
            public void OnRemoveClickListener(final View v, final int position) {
                new YR_CommonDialog(mContext, "请确认是否删除", "取消", "确认") {
                    @Override
                    public void confirmBtn() {
                        DrugBean bean = (DrugBean) v.getTag();
                        bean.setCheck(false);
                        mDrugBeanList.remove(position);
                        checkDrugMap.remove(bean.getId());
                        if (UtilCollection.isBlank(mDrugBeanList)) {
                            sq_id_ordonnance_edit.setText("编辑");
                            isEdit = true;
                            recommendAdapter.hideEdtLinearLayout();
                            sq_id_ordonnance_edit.setVisibility(View.GONE);
                            setSaveTextViewState(0);
                            if(UtilCollection.isBlank(diagnosisList)){
                                setSaveTextViewState(2);
                            }
                        }else {
                            setSaveTextViewState(0);
                        }
                        recommendAdapter.notifyDataSetChanged();
                        computeTotalPrice();
                        dismiss();
                    }
                }.show();
            }

            @Override
            public void OnEditUsageDataClickListener(View v,int position) {
                // created by songxin,date：2018-01-09,about：saveInfo,begin
                BiUtil.saveBiInfo(SQ_RecommendActivity.class, "2", "128", "E00096","", false);
                // created by songxin,date：2018-01-09,about：saveInfo,end
                editPosition = position;
                DrugBean drugBean = (DrugBean) v.getTag();
                drugBean.setEditUsage(true);
                UsageActivityV2.launch(SQ_RecommendActivity.this, drugBean,CommonConfig.ALL_MEDICINE_FLAG_2,"");
            }

        });
    }

    /**
     * 设置保存按钮状态
     * @param state 0:保存为常用 可点击， 1：已保存，2：保存为常用 不可点击
     */
    public void setSaveTextViewState(int state){
        if(0 == state){
            title_common_layout.setTitleRight2(true,0,"保存常用");
            title_common_layout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
            title_common_layout.getXc_id_titlebar_right2_layout().setClickable(true);
            title_common_layout.getXc_id_titlebar_right2_layout().setFocusable(true);
        }else if(1 == state){
            title_common_layout.setTitleRight2(true,0,"已添加常用");
            title_common_layout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        }else if(2 == state){
            title_common_layout.setTitleRight2(true,0,"保存常用");
            title_common_layout.getXc_id_titlebar_right2_layout().setClickable(false);
            title_common_layout.getXc_id_titlebar_right2_layout().setFocusable(false);
            title_common_layout.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_gray_ececec));
        }
    }

    @Override
    public void onNetRefresh() {
    }

    @Override
    public void listeners() {
        ym_ordonnance_medicines_add.setOnClickListener(this);
        ym_ordonnance_medicition_send.setOnClickListener(this);
        sq_id_ordonnance_edit.setOnClickListener(this);

    }

    /**
     * 刷新页面
     */
    public void notifyDataSetChanged() {
        if (null != recommendAdapter) {
            recommendAdapter.notifyDataSetChanged();
        }
    }

    /**
     * 请求配伍禁忌
     */
    public void requestMatching() {
        String goodsIds = "";
        for (DrugBean bean : mDrugBeanList) {
            goodsIds = goodsIds + bean.getId() + ",";
        }
        String goodsId = UtilString.getStringWithoutLast(goodsIds);
        RequestParams params = new RequestParams();

        XCHttpAsyn.getAsyn(false, true, true, mContext, AppConfig.MatchingApi + goodsId, params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (mContext == null) {
                    return;
                }
                XCHttpAsyn.closeLoadingDialog();
                try {
                    if (result_boolean && !mContext.isDestroy) {
                        List<XCJsonBean> beanList = result_bean.getList("data");
                        XCJsonBean bean = beanList.get(0);
                        XCJsonBean dismatchBean = bean.getModel("dismatch");
                        JSONObject jsonObject = new JSONObject(dismatchBean.toString());
                        Iterator iterator = jsonObject.keys();
                        String key = "";
                        while (iterator.hasNext()) {
                            key = (String) iterator.next(); // 得到key（key是药名）
                        }
                        List<String> list = dismatchBean.getStringList(key);

                        // 如果可以匹配 （无冲突） ，去推荐
                        if (list.size() < 1) {

                            savePatientDrugInfo();
                            SQ_PreviewRecommendInfoActivity.launch(SQ_RecommendActivity.this,2);

                        } else {    // 如果不能匹配 （有冲突）
                            String names = "";
                            for (String name : list) {   // 遍历起冲突的药品名字
                                names = names + name + ",";  // 拼接字符串
                            }
                            names = UtilString.getStringWithoutLast(names);
                            XCApplication.longToast(key + "与" + names + "存在冲突，请重新检查药物清单后再进行推荐。");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    XCApplication.longToast("配伍禁忌解析错误");
                }
            }

            @Override
            public void onFinish() {
//                super.onFinish();
                // 处理code操作
                if (mContext == null) {
                    return;
                }
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }

        });
    }

    /**
     * 将用药确认列表数据返回给推荐用药页
     */
    private void returnToChoiceMedicineActivity() {
        try {
            savePatientDrugInfo();
            myFinish();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void savePatientDrugInfo() {
        patientDrugInfo.setList(mDrugBeanList);
        patientDrugInfo.setChatModel(chatModel);//防止chatModel为null
        patientDrugInfo.getChatModel().setDiagnosis(ym_ordonnance_diacrisis_edt.getText().toString().trim());
        patientDrugInfo.getChatModel().setSerialNumber(ordonnanceNumber);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ym_ordonnance_medicines_add:
                UtilInputMethod.hiddenInputMethod(ym_ordonnance_diacrisis_edt, mContext);
                ToJumpHelp.toJumpAllMedicineClassActivity(this,CommonConfig.ALL_MEDICINE_FLAG_4
                ,getIntent().getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION));

                break;
            case R.id.ym_ordonnance_medicition_send:

                // created by songxin,date：2018-01-09,about：saveInfo,begin
                BiUtil.saveBiInfo(SQ_RecommendActivity.class, "2", "128", "E00099","", false);

                if (isFastClick()) {
                    return;
                }

                // 检查勾选的药品列表
                if (mDrugBeanList.size() < 1) {
                    mContext.shortToast("药品为空请添加药品");
                    return;
                }
                // 效验用法用量
                if (!checkUsage()) {
                    return;
                }
                // 查询库存，下一步
                checkInventoryInfo();
                break;

            case R.id.sq_id_ordonnance_edit:
                if (isEdit) {
                    sq_id_ordonnance_edit.setText("完成");
                    isEdit = false;
                    recommendAdapter.showEdtLinearLayout();
                } else {
                    sq_id_ordonnance_edit.setText("编辑");
                    isEdit = true;
                    recommendAdapter.hideEdtLinearLayout();
                    if (mDrugBeanList.size() == 0) {
                        sq_id_ordonnance_edit.setVisibility(View.GONE);
                    }
                }
                break;

        }
    }

    /**
     * 检查是否需要校验库存，不需要则去发送
     */
    private void checkInventoryInfo() {
        if (patientDrugInfo.isCheckInventoryInfo()) {
            requestGetInventoryInfo(patientDrugInfo.isCheckInventoryInfo());
            return;
        }
        // 校验正大天晴
        requestCttqVerify();
    }

    /**
     * 我知道提示dialog
     *
     * @param content
     */
    public void showCheckUsageDialog(String content) {
        if (mYR_commonDialog == null) {
            mYR_commonDialog = new YR_CommonDialog(mContext, content, "", "知道了") {
                @Override
                public void confirmBtn() {
                    mYR_commonDialog.dismiss();
                }
            };
        }
        mYR_commonDialog.setContentStr(content);
        mYR_commonDialog.show();
    }

    private YR_CommonDialog mInventoryInfoDialog;
    /**
     * 库存信息dialog
     */
    public void showInventoryInfoDialog(int index,String name) {
        String content;
        if(1 == index){
            content = "当前处方中的"+ name +"已下架，请确认是否继续发送该处方？";
        }else {
            content = "当前处方中的"+ name +"库存不足，请确认是否继续发送该处方？";
        }

        if (mInventoryInfoDialog == null) {
            mInventoryInfoDialog = new YR_CommonDialog(mContext, content, "取消", "继续发送") {
                @Override
                public void cancelBtn() {
                    dismiss();
                }

                @Override
                public void confirmBtn() {
                    requestCttqVerify();
                    mInventoryInfoDialog.dismiss();
                }
            };
        }
        mInventoryInfoDialog.setContentStr(content);
        mInventoryInfoDialog.show();
    }

    /**
     * 效验用法用量
     *
     * @return true 通过
     */
    private boolean checkUsage() {
        boolean result = true;
        StringBuilder dialogContentSB = new StringBuilder();
        boolean isFirst = true;
        for (DrugBean bean : mDrugBeanList) {
            if (UtilString.isBlank(bean.getMedicineUsageBean().getBakUp()) && UtilString.isBlank(bean.getMedicineUsageBean().getUsages())) {
                String name = bean.getName();
                if (isFirst) {
                    isFirst = false;
                } else {
                    dialogContentSB.append("\n");
                }
                dialogContentSB.append(name);
            }
        }
        String dialogContent = dialogContentSB.toString();
        if (!UtilString.isBlank(dialogContent)) {
            dialogContent = "以下药品未填写用法用量，请先补充：\n" + dialogContent;
            showCheckUsageDialog(dialogContent);
            result = false;
        }
        return result;
    }

    /**
     * 请求查询库存信息
     */
    public void requestGetInventoryInfo(final boolean isShowInventoryInfoDialog) {
        // 如果药品集合为空则不请求
        if(UtilCollection.isBlank(mDrugBeanList)) return;
        String skuIds = "";
        String buyNums = "";
        // 拼接skuid和购买数量
        for (DrugBean bean : mDrugBeanList) {
            String skuId = bean.getSkuId();
            String num = bean.getMedicineUsageBean().getQuantity();
            skuIds = skuIds + skuId + ",";
            buyNums = buyNums + num + ",";
        }
        skuIds = UtilString.getStringWithoutLast(skuIds);
        buyNums = UtilString.getStringWithoutLast(buyNums);

        RequestParams params = new RequestParams();
        params.put("skuIds", skuIds);
        params.put("nums", buyNums);
        params.put("patientId",patientDrugInfo.getChatModel().getUserPatient().getPatientId());

        XCHttpAsyn.postAsyn(mContext, AppConfig.getHostUrl(AppConfig.inventory_info), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {
                    Parse2InventoryInfo parse2InventoryInfo = new Parse2InventoryInfo();
                    List<InventoryInfo> list = parse2InventoryInfo.parse(result_bean);
                    try {
                        int salaCount = 0;
                        int shortCount = 0;
                        String drugName = "";
                        for (int i = 0; i < mDrugBeanList.size(); i++) {
                            mDrugBeanList.get(i).getInventoryInfo().setStockNum(list.get(i).getStockNum());
                            mDrugBeanList.get(i).getInventoryInfo().setIsPresell(list.get(i).getIsPresell());
                            mDrugBeanList.get(i).getInventoryInfo().setIsShort(list.get(i).getIsShort());
                            mDrugBeanList.get(i).getInventoryInfo().setPresellInfo(list.get(i).getPresellInfo());
                            mDrugBeanList.get(i).getInventoryInfo().setSale(list.get(i).isSale());
                            mDrugBeanList.get(i).getInventoryInfo().setIslimit(list.get(i).getIslimit());
                            mDrugBeanList.get(i).getInventoryInfo().setPatientLimitInfo(list.get(i).getPatientLimitInfo());
                            mDrugBeanList.get(i).getInventoryInfo().setSkuLimitInfo(list.get(i).getSkuLimitInfo());
                            mDrugBeanList.get(i).setSale(list.get(i).isSale());
                            mDrugBeanList.get(i).setSixtyDosage(list.get(i).getSixtyDosage());
                            mDrugBeanList.get(i).setDosageMonth(list.get(i).getDosageMonth());
                            mDrugBeanList.get(i).setDosageWeek(list.get(i).getDosageWeek());
                            // 控制是否校验库存，显示对话框
                            if(!isShowInventoryInfoDialog) {
                                continue;
                            }
                            // 以下是续方和常用处方发送前校验库存逻辑
                            if(salaCount == 0 && "1".equals(list.get(i).getIsShort())) {
                                // 缺货
                                shortCount++;
                                if (shortCount == 1) {
                                    drugName = mDrugBeanList.get(i).getName();
                                } else if (shortCount == 2) {
                                    drugName = drugName + "等药品";
                                }
                            }else if(shortCount == 0 && !list.get(i).isSale()){
                                // 下架
                                salaCount++;
                                if(salaCount == 1){
                                    drugName = mDrugBeanList.get(i).getName();
                                }else if (salaCount == 2){
                                    if(!"1".equals(list.get(i).getIsShort())){
                                        drugName = drugName + "等药品";
                                    }else { // 即是下架又是库存不足
                                        salaCount --;
                                    }
                                }
                            }
                        }
                        // 是否校验库存，显示对话框
                        if(isShowInventoryInfoDialog) {
                            if (shortCount > 0) {
                                showInventoryInfoDialog(2, drugName);
                            }else if (salaCount > 0) {
                                showInventoryInfoDialog(1, drugName);
                            }else {
                                requestCttqVerify();
                            }
                        }
                        recommendAdapter.notifyDataSetChanged();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     *  校验正大天晴
     */
    public void requestCttqVerify(){
        // 如果药品集合为空则不请求
        if(UtilCollection.isBlank(mDrugBeanList)) return;
        String pids = "";
        // 拼接商品Id
        for (DrugBean bean : mDrugBeanList) {
            String pid = bean.getId();
            pids = pids + pid + ",";
        }
        pids = UtilString.getStringWithoutLast(pids);
        RequestParams params = new RequestParams();
        params.put("pids", pids);

        XCHttpAsyn.postAsyn(mContext, AppConfig.getTuijianUrl(AppConfig.cttqVerify), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {
                    // 配伍禁忌
                    if(UtilSP.isRecomSafe()){
                        savePatientDrugInfo();
                        SQ_PreviewRecommendInfoActivity.launch(SQ_RecommendActivity.this,2);
                    }else {
                        requestMatching();

                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (CommonConfig.MEDICINE_FIFTER_CODE.equals(getCode())){//符合正大天晴项目拦截规则，则弹出对话框(之所以在这里返回是为了防止弹出Toast)，否则进行下一步操作，
                    showCheckUsageDialog(getMsg());
                    return;
                }
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        returnToChoiceMedicineActivity();
    }

    /**
     * 初始化处方单数据
     */
    public void requestInitData() {
        RequestParams params = new RequestParams();
        params.put("patientId", patientDrugInfo.getChatModel().getUserPatient().getPatientId());
        XCHttpAsyn.postAsyn(mContext, AppConfig.getTuijianUrl(AppConfig.prescriptionInit), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {
                    SK_RecommendInfo sk_recommendInfo = new SK_RecommendInfo();
                    Parser2SQRecommendInfo parser2SQRecommendInfo = new Parser2SQRecommendInfo(sk_recommendInfo);
                    parser2SQRecommendInfo.parseJson(result_bean);

                    recommendInfo.setTitle(sk_recommendInfo.getTitle());
                    recommendInfo.setSerialNumber(sk_recommendInfo.getSerialNumber());
                    recommendInfo.setRecomTime(sk_recommendInfo.getRecomTime());
                    recommendInfo.setExpireDesc(sk_recommendInfo.getExpireDesc());
                    recommendInfo.setDepartmentName(sk_recommendInfo.getDepartmentName());
                    recommendInfo.setDoctorName(sk_recommendInfo.getDoctorName());

                    setDataToViews();

                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 用药安全提示
     */
    public void requestRemind() {

        if(TextUtils.isEmpty(ym_ordonnance_patient_age.getText().toString().trim())){
            return;
        }

        RequestParams params = new RequestParams();
        params.put("patientId", chatModel.getUserPatient().getPatientId());
        String age = ym_ordonnance_patient_age.getText().toString().trim();
        if(age.contains("周")){
            params.put("age",UtilString.getStringWithoutLast(age,"周"));
            params.put("patientAgeUnit","周");
        }else if(age.contains("个月")){
            params.put("age",UtilString.getStringWithoutLast(age,"个月"));
            params.put("patientAgeUnit","个月");
        }else if(age.contains("岁")){
            params.put("age",UtilString.getStringWithoutLast(age,"岁"));
            params.put("patientAgeUnit","岁");
        }

        // 患者性别：0.女 1.男
        int gender;
        if ("女".equals(ym_ordonnance_patient_sex.getText().toString().trim())) {
            gender = 0;
            params.put("gender", gender);
        } else if ("男".equals(ym_ordonnance_patient_sex.getText().toString().trim())){
            gender = 1;
            params.put("gender", gender);
        }

        XCHttpAsyn.postAsyn(false, this, AppConfig.getTuijianUrl(AppConfig.recomRemind), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean && !mContext.isDestroy) {
                    try {

                        //content (string,): 提醒内容 ,
                        //remind (integer): 是否提示：0.不提示 1.提示
                        if ("1".equals(result_bean.getList("data").get(0).getString("remind"))) {
                            XCApplication.base_log.shortToast(result_bean.getList("data").get(0).getString("content"));
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
            // 从用法用量返回
        if (requestCode == UsageActivityV2.REQUEST_CODE_USAGE) {
            DrugBean drugBean = (DrugBean)data.getSerializableExtra(UsageActivityV2.DRUG_INFO);
            if(editPosition != -1){
                if(mDrugBeanList.get(editPosition) != null) {
                    // 判断数据是否有修改
                    if(!mDrugBeanList.get(editPosition).getMedicineUsageBean().getUsages().equals(
                            drugBean.getMedicineUsageBean().getUsages())
                            || !mDrugBeanList.get(editPosition).getMedicineUsageBean().getBakUp().equals(
                            drugBean.getMedicineUsageBean().getBakUp())
                            || !mDrugBeanList.get(editPosition).getMedicineUsageBean().getQuantity().equals(
                            drugBean.getMedicineUsageBean().getQuantity())
                            ) {
                        setSaveTextViewState(0);
                    }
                    mDrugBeanList.remove(editPosition);
                    mDrugBeanList.add(editPosition,drugBean);
                    editPosition = -1;
                }
            }
            computeTotalPrice();
            notifyDataSetChanged();
        }else if(requestCode == SafeMedicationActivity.REQUEST_CODE_SAFE_MEDICATION){
            addPrescription();
        }
    }

    /**
     * 设置临床诊断
     */
    private void setDiagnosisText() {
        String diagnosisStr = "";
        for (int i = 0; i < diagnosisList.size(); i++) {
            if (i == diagnosisList.size() - 1) {
                diagnosisStr = diagnosisStr + diagnosisList.get(i);
            } else {
                diagnosisStr = diagnosisStr + diagnosisList.get(i) + ",";
            }
        }
        ym_ordonnance_diacrisis_edt.setText(diagnosisStr);
    }

    /**
     * 记录点击时候的时间
     */
    private long lastClickTime;

    /**
     * 防止500毫秒内重复点击的方法
     *
     * @return true：重复点击，false：不是重复点击
     */
    public boolean isFastClick() {
        long time = System.currentTimeMillis();
        if (time - lastClickTime < 1000) {
            return true;
        }
        lastClickTime = time;
        return false;
    }

    /**
     * 新建常用处方
     */
    private void addPrescription() {
        RecipeBean recipeBean = new RecipeBean();
        List<DiagnoseBean> diagnosisBeanList = new ArrayList<>();

        for (String s : diagnosisList){
            DiagnoseBean diagnoseBean = new DiagnoseBean();
            diagnoseBean.name = s;
            diagnosisBeanList.add(diagnoseBean);
        }
        recipeBean.setDiagnosisList(diagnosisBeanList);
        recipeBean.setDrugBeans((ArrayList<DrugBean>) mDrugBeanList);

        RequestParams params = new RequestParams();
        String str = UtilIMCreateJson.createCommonPrescriptionJson(recipeBean);
        params.put("commonPrescription", str);
        XCHttpAsyn.postAsync(true, true, mContext, AppConfig.getHostUrl(AppConfig.addCommonPrescription + "?doctorId=" + UtilSP.getUserId() +
                "&token=" + UtilSP.getUserToken()), str, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    setSaveTextViewState(1);
                    RecomMedicineHelper.getInstance().setUpdateCommonRecipe(true);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(mContext,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 请求安全用药提醒
     */
    public void requestSafeMedication(){

        JSONObject data = new JSONObject();
        try {
            XC_PatientDrugInfo patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
            UserPatient userPatient = patientDrugInfo.getChatModel().getUserPatient();
            data.put("patientAge", patientDrugInfo.getRecommendInfo().getPatientAge());
            data.put("patientAgeUnit", patientDrugInfo.getRecommendInfo().getPatientAgeUnit());
            data.put("patientGender", patientDrugInfo.getRecommendInfo().getPatientGender());
            data.put("patientId", userPatient.getPatientId());
            JSONArray diagnosis = new JSONArray();
            for (DiagnoseBean bean : patientDrugInfo.getDiagnoseBeanList()) {
                diagnosis.put(bean.name);
            }
            data.put("diagnosis", diagnosis);
            JSONArray skuIds = new JSONArray();
            for (DrugBean item : patientDrugInfo.getRecommendInfo().getDrugInfoBean()) {
                skuIds.put(item.getSkuId());
            }
            data.put("skuIds", skuIds);
            DrCaseVOBean mDrCaseVOBean = (DrCaseVOBean)patientDrugInfo.getDrRecordVOBean().getMdicalRecordVO();
            if(mDrCaseVOBean != null){
                data.put("mainComplaint",mDrCaseVOBean.getMainComplaint());
                data.put("presentDisease",mDrCaseVOBean.getPresentDisease());
            }
            List<DrugBean> drugBeans = patientDrugInfo.getList();
            JSONArray recomSafeItems = new JSONArray();
            JSONObject drugItem;
            for (DrugBean item : drugBeans){
                drugItem = new JSONObject();
                drugItem.put("commonName",item.getCommonName());
                drugItem.put("productName", item.getName());
                drugItem.put("recomName", item.getRecomName());
                drugItem.put("quantity",item.getMedicineUsageBean().getQuantity());
                drugItem.put("skuId",item.getMedicineUsageBean().getSkuId());
                recomSafeItems.put(drugItem);
            }
            data.put("recomSafeItems", recomSafeItems);
        } catch (Exception e) {
            e.printStackTrace();
            XCApplication.base_log.debugShortToast("创建json异常");
        }

        // 发送请求
        XCHttpAsyn.postAsync(true,this,AppConfig.getTuijianUrl(AppConfig.recomCheck+ "?doctorId="+UtilSP.getUserId()+
                "&token="+UtilSP.getUserToken()),data.toString(),new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean && context != null){
                    try {
                        Parse2SafeMedication parse2SafeMedication = new Parse2SafeMedication();
                        SafeMedicationBean safeMedicationBean = parse2SafeMedication.parse(result_bean.getList("data").get(0));
                        if("3".equals(safeMedicationBean.getSafeStatus())){ // 通过
                            addPrescription();
                        }else if("2".equals(safeMedicationBean.getSafeStatus())){ // 谨慎
                            // 若两次提醒一致
                            if(safeMedicationBean.getSn().equals(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getSn())){
                                addPrescription();
                                return;
                            }
                            safeMedicationBean.setBtnTextTag(1);
                            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setSn(safeMedicationBean.getSn());
                            SafeMedicationActivity.launch(SQ_RecommendActivity.this,safeMedicationBean);
                        }else if("1".equals(safeMedicationBean.getSafeStatus())){ // 禁用
                            safeMedicationBean.setBtnTextTag(1);
                            SafeMedicationActivity.launch(SQ_RecommendActivity.this,safeMedicationBean);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                GeneralReqExceptionProcess.checkCode(context,getCode(),getMsg());
            }
        });
    }

}
