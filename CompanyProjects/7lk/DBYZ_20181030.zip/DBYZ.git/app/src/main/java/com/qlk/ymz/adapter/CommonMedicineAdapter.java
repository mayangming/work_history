package com.qlk.ymz.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.adapter.ViewHolder.SK_DrugViewHolder;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.view.SwipeLayout.PullSwipeLayoutAdapter;
import com.qlk.ymz.view.SwipeLayout.SwipeOnTouchListener;
import com.qlk.ymz.view.SwipeLayout.SwipeViewHolder;
import com.xiaocoder.android.fw.general.application.XCApplication;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by xiedong on 2017/12/14.
 */

public class CommonMedicineAdapter extends PullSwipeLayoutAdapter<DrugBean> {

    /**
     * 监听
     */
    private CommonMedicineActionListener mCommonMedicineActionListener;
    /**
     * 是否为推荐用药界面的标识 true是推荐用药 flase 常用处方
     */
    private boolean isRecomend;
    /**
     * 判断是否为推荐用药首页
     */
    private boolean isHome;

    /**
     * 药品是否勾选的map集合
     * K：药品ID
     * V：（true,false）true：已勾选 false：未勾选
     */
    private Map<String, Boolean> mCheckDrugMap = new HashMap<>();

    /**
     * 构造函数
     *
     * @param context
     * @param contentViewResourceId
     * @param actionViewResourceId
     * @param itemWidth
     * @param contentWidth
     * @param list
     */
    public CommonMedicineAdapter(Context context, int contentViewResourceId, int actionViewResourceId, int itemWidth, int contentWidth, List<DrugBean> list) {
        super(context, contentViewResourceId, actionViewResourceId, itemWidth, contentWidth, list);
    }

    @Override
    public void setContentView(View contentView, final int position, HorizontalScrollView parent, SwipeViewHolder holder, SwipeOnTouchListener swipeOnTouchListener) {
        final DrugBean bean = list.get(position);
        SK_DrugViewHolder viewHolder = (SK_DrugViewHolder) contentView.getTag();
        if (viewHolder == null) {
            viewHolder = new SK_DrugViewHolder(context, contentView);
            contentView.setTag(viewHolder);
        }
        viewHolder.sk_id_medichine_cb.setTag(R.id.sk_id_medichine_img, viewHolder.sk_id_medichine_item_img);
        viewHolder.sk_id_medichine_cb.setTag(bean);

        if (mCommonMedicineActionListener != null) {
            viewHolder.sk_id_medichine_cb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (bean.isCheck()) {
                        mCommonMedicineActionListener.subRecipe(position);
                    } else {
                        mCommonMedicineActionListener.addRecipe(position);
                    }
                }
            });
        }
        viewHolder.sk_id_medichine_cb.setFocusable(false);

        // 判断是否被勾选，mCheckDrugMap.get(bean.getId())为空和false表示未勾选，true表示已勾选
        if (null == mCheckDrugMap.get(bean.getId())) {
            bean.setCheck(false);
        } else {
            bean.setCheck(mCheckDrugMap.get(bean.getId()));
        }
        // 选中状态
        if (bean.isCheck()) {
            if (isRecomend && isHome) {
                viewHolder.sk_id_medichine_cb.setClickable(true);
                viewHolder.sk_id_medichine_cb.setText("移出处方笺");
                viewHolder.sk_id_medichine_cb.setTextColor(context.getResources().getColor(R.color.c_e2231a));
                viewHolder.sk_id_medichine_cb.setBackgroundResource(R.drawable.xd_white_red_shape_2);
            } else {
                if(isRecomend){
                    viewHolder.sk_id_medichine_cb.setText("已加入处方笺");
                }else {
                    viewHolder.sk_id_medichine_cb.setText("已加入常用处方");
                }
                viewHolder.sk_id_medichine_cb.setClickable(false);
                viewHolder.sk_id_medichine_cb.setTextColor(context.getResources().getColor(R
                        .color.c_7b7b7b));
                viewHolder.sk_id_medichine_cb.setBackgroundResource(R.drawable.xd_gray_round_shape_2);
            }

        } else {
            viewHolder.sk_id_medichine_cb.setClickable(true);
            viewHolder.sk_id_medichine_cb.setTextColor(context.getResources().getColor(R.color.c_white_ffffff));
            viewHolder.sk_id_medichine_cb.setBackgroundResource(R.drawable.xd_red_round_shape_2);
            if(isRecomend){
                viewHolder.sk_id_medichine_cb.setText("加入处方笺");
            }else {
                viewHolder.sk_id_medichine_cb.setText("加入常用处方");
            }

        }

        // 是否显示小七指数或市场积分,0：不显示，1小七指数、2市场积分
        if ("0".equals(bean.getShowCommission())) {
            viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.GONE);
        } else if ("2".equals(bean.getShowCommission())) {
            viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medicine_drcommission.setText(bean.getMarketPoint());
            viewHolder.sk_id_medicine_point_name.setText(context.getResources().getText(R.string.medicine_MarketPoint));

        } else if ("1".equals(bean.getShowCommission())) {
            viewHolder.sk_id_medicine_drcommission_ll.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medicine_drcommission.setText(bean.getDrCommission());
            viewHolder.sk_id_medicine_point_name.setText(context.getResources().getText(R.string.medicine_commission));
        }

        // 是否显示病历数据收集标签,0:不显示,1：显示
        if("1".equals(bean.getShowRecomCollect())){
            viewHolder.sk_id_medichine_item_collect.setVisibility(View.VISIBLE);
        }else {
            viewHolder.sk_id_medichine_item_collect.setVisibility(View.GONE);
        }
        viewHolder.sk_id_medichine_item_collect.setTag(bean);

        // 是否显示调价按钮
        if (bean.getModifyFlag()) {
            viewHolder.sk_id_medichine_change_price.setVisibility(View.VISIBLE);
        } else {
            viewHolder.sk_id_medichine_change_price.setVisibility(View.GONE);
        }

        viewHolder.sk_id_medichine_change_price.setTag(bean);
        // 是否已经调价
        if (bean.isModified()) {
            viewHolder.sk_id_medichine_change_price.setText("已调价");
        } else {
            viewHolder.sk_id_medichine_change_price.setText("调价");
        }

        // 是否推荐商品（1 是 0否）
        if ("1".equals(bean.getIsRecommend())) {
            viewHolder.sk_id_medichine_item_rl.setBackgroundResource(R.drawable.sk_dd_selector_img_red_fff4ee);
            viewHolder.sk_id_medichine_item_recommend.setVisibility(View.VISIBLE);
        } else {
            viewHolder.sk_id_medichine_item_rl.setBackgroundResource(R.drawable.sk_dd_selector_img_gray_eeeeee);
            viewHolder.sk_id_medichine_item_recommend.setVisibility(View.GONE);
        }

        // 显示库存数量
        viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.VISIBLE);
        try {
            if (Integer.parseInt(bean.getStockNum()) <= 99)
                viewHolder.sk_id_medichine_item_stock_num.setText("剩余" + bean.getStockNum() + "件");
            else
                viewHolder.sk_id_medichine_item_stock_num.setText("剩余99+件");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 是否缺货，1 是，0 否
        if ("1".equals(bean.getIsShort())) {
            // 显示缺货view
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.GONE);
        } else {
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.GONE);
        }

        // 是否为预售，1 是，0 否
        if ("1".equals(bean.getIsPresell())) {
            // 显示预售view
            viewHolder.sk_id_medichine_item_presell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    XCApplication.base_log.shortToast(bean.getPresellInfo());
                }
            });
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_item_presell.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.GONE);
        } else {
            viewHolder.sk_id_medichine_item_presell.setVisibility(View.GONE);
        }

        // 是否在销售
        if (bean.isSale()) {
            viewHolder.sk_id_medichine_item_sale_ll.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_cb.setVisibility(View.VISIBLE);

        } else {
            // 已下架
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_item_stock_num.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_item_sale_ll.setVisibility(View.VISIBLE);
            viewHolder.sk_id_medichine_item_short_iv.setVisibility(View.GONE);
            viewHolder.sk_id_medichine_cb.setVisibility(View.GONE);
        }

        // 获取调价后的价格，用完后情况静态值
        if (!TextUtils.isEmpty(DrugBean.drug_id) && bean.getId().equals(DrugBean.drug_id)
                && !TextUtils.isEmpty(DrugBean.drug_price)) {
            bean.setSalePrice(DrugBean.drug_price);
            bean.setModified(true);
            viewHolder.sk_id_medichine_change_price.setText("已调价");
            DrugBean.drug_id = "";
            DrugBean.drug_price = "";
        }

        XCApplication.displayImage(bean.getImage(), viewHolder.sk_id_medichine_item_img);

        viewHolder.sk_id_medichine_item_name.setText(bean.getManufacturer());
        viewHolder.sk_id_medichine_item_common_name.setText(bean.getName());
        viewHolder.sk_id_medichine_item_oprice.setText(AppConfig.renminbi + bean.getMarketPrice());
        viewHolder.sk_id_medichine_item_pprice.setText(bean.getSalePrice());

        viewHolder.sk_id_medichine_item_oprice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG); //删除线
        viewHolder.sk_id_medichine_item_oprice.getPaint().setAntiAlias(true); //抗锯齿

        if(isHome){
//            showFooterView(viewHolder.sk_id_medichine_item_footerView, bean);
        }

        if (mCommonMedicineActionListener != null) {
            viewHolder.sk_id_medichine_item_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCommonMedicineActionListener.onItemClick(position);
                }
            });
        }
    }

    @Override
    public void setActionView(View actionView, final int position, HorizontalScrollView parent) {
        ActionViewHolder viewHolder = ActionViewHolder.getViewHolder(actionView);
        viewHolder.tv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCommonMedicineActionListener != null) {
                    mCommonMedicineActionListener.delete(position);
                }
            }
        });
    }


    /**
     * 显示底部布局，处理不能选择药品的BUG
     *
     * @param view 底部布局
     * @param bean 药品bean
     */
    public void showFooterView(View view, DrugBean bean) {
        if (list.size() > 0) {
            DrugBean lastBean = list.get(list.size() - 1);
            if (bean == lastBean) {
                view.setVisibility(View.VISIBLE);
            } else {
                view.setVisibility(View.GONE);
            }
        }

    }

    /**
     * 设置已勾选集合
     *
     * @param mCheckDrugMap
     */
    public void setCheckDrugMap(Map<String, Boolean> mCheckDrugMap) {
        this.mCheckDrugMap = mCheckDrugMap;
    }

    /**
     * 设置常用药动作的监听
     *
     * @param commonMedicineActionListener
     */
    public void setCommonMedicineActionListener(CommonMedicineActionListener commonMedicineActionListener) {
        this.mCommonMedicineActionListener = commonMedicineActionListener;
    }

    /**
     * 是否推荐用药界面
     */
    public void setIsRecomend(boolean isRecomend) {
        this.isRecomend = isRecomend;
    }

    public void setIsHome(boolean isHome) {
        this.isHome = isHome;
    }

    static class ActionViewHolder {
        //删除
        TextView tv_delete;

        public ActionViewHolder(View convertView) {
            tv_delete = (TextView) convertView.findViewById(R.id.tv_delete);
        }

        public static ActionViewHolder getViewHolder(View convertview) {
            ActionViewHolder holder = (ActionViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new ActionViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }

    public interface CommonMedicineActionListener {
        void delete(int position);

        void addRecipe(int position);

        void subRecipe(int position);

        void onItemClick(int position);
    }
}
