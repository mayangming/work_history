package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

/**
 * @author jingyu on 2016/6/24 15:34
 * @description
 */
public class XC_ChatRightBaseHolder {
    /**
     * 医生头像
     */
    public XCRoundedImageView xc_id_adapter_right_head;
    /**
     * 时间
     */
    public TextView xc_id_adapter_right_time;
    /**
     * 消息发送失败的布局
     */
    public RelativeLayout xc_id_chat_right_net_layout;
    /**
     * 消息发送失败的提示image
     */
    public ImageView xc_id_chat_right_net_fail_hint_imageview;
    /**
     * 消息正在发送的进度条
     */
    public ProgressBar xc_id_chat_right_net_progress_bar;

    public XC_ChatRightBaseHolder(View convertView) {
        xc_id_adapter_right_head = (XCRoundedImageView) convertView.findViewById(R.id.xc_id_adapter_right_head);
        xc_id_adapter_right_time = (TextView) convertView.findViewById(R.id.xc_id_adapter_right_time);
        xc_id_chat_right_net_layout = (RelativeLayout) convertView.findViewById(R.id.xc_id_chat_right_net_layout);
        xc_id_chat_right_net_fail_hint_imageview = (ImageView) convertView.findViewById(R.id.xc_id_chat_right_net_fail_hint_imageview);
        xc_id_chat_right_net_progress_bar = (ProgressBar) convertView.findViewById(R.id.xc_id_chat_right_net_progress_bar);
    }
}
