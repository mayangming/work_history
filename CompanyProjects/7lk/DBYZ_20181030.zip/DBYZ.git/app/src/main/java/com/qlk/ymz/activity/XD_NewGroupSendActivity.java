package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.AddresseeInfoBean;
import com.qlk.ymz.model.MassHistoryBean;
import com.qlk.ymz.model.PatientGroupBean;
import com.qlk.ymz.parse.Parse2PatientGroupBean;
import com.qlk.ymz.parse.Parse2PublicityBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.AddresseeTextShowView;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by xiedong on 2017/2/21.
 * 新建群发
 */

public class XD_NewGroupSendActivity extends DBActivity {
    /**
     * 标题栏
     */
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**
     * 时间日期
     */
    private TextView tv_doctor_advice_time;
    /**
     * 医嘱内容
     */
    private EditText et_doctor_advice_content;
    /**
     * 医嘱字数
     */
    private TextView tv_doctor_advice_num;
    /**
     * 宣教链接
     */
    private RelativeLayout rl_missionary;
    /**
     * 宣教标题
     */
    private TextView tv_missionary;
    /**
     * 收件人item
     */
    private RelativeLayout rl_addressee;
    /**
     * 收件人名称外布局
     */
    private LinearLayout ll_addressee;
    /**
     * 收件人名称
     */
    private TextView tv_addressee;
    /**
     * 可发送条数
     */
    private TextView tv_send_remind;
    /**
     * 发送
     */
    private TextView tv_send;
    /**
     * 发送日期
     */
    private String sendTime = "1月6日";
    /**
     * 剩余发送次数
     */
    private int sendNum = 3;
    /**
     * 患者分组列表数据
     */
    private List<PatientGroupBean> patientGroupBeenList = new ArrayList<>();
    /**
     * 所有患者分组列表数据
     */
    private List<PatientGroupBean> allPatientGroupBeenList = new ArrayList<>();
    /**
     * 个别患者集合
     */
    private List<XC_ChatModel> currentChoosePatientBean = new ArrayList<>();
    /**
     * 收件人类型
     */
    private int currentType = 1;
    /**
     * 历史列表model
     */
    private MassHistoryBean massHistoryBean;
    /**
     * 宣教信息标签
     */
    public static final String PRO_EDU = "pro_edu";
    /**
     * 宣教信息
     */
    private Parse2PublicityBean mParse2PublicityBean;
    /**
     * 当前时间
     */
    private String currentTime = "";
    /**
     * 可发送总次数
     */
    private int totalNum = 3;
    /**
     * 可输入数字
     */
    private int editMaxNum = 180;
    /**
     * 输入的内容
     */
    private String editContext = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_new_group_send);
        super.onCreate(savedInstanceState);
        //初始化编辑内容  无宣教时
        if(mParse2PublicityBean ==null){
            editContext = UtilSP.getGroupSendText();
            et_doctor_advice_content.setText(editContext);
            et_doctor_advice_content.setSelection(editContext.length());
            tv_doctor_advice_num.setText(editContext.length()+ "/" + editMaxNum);
        }
        //请求基本数据
        requstBaseInfo();
        //请求所有患者分组数据
        requestPatientGroupList(false);
    }

    /** created by songxin,date：2017-4-10,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_NewGroupSendActivity.class);
    }

    /** created by songxin,date：2016-4-10,about：bi,end */

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "新建群发");
        xc_id_model_titlebar.setTitleLeft(true, "");
        xc_id_model_titlebar.setTitleRight2(true, 0, "群发历史");
        tv_doctor_advice_time = getViewById(R.id.tv_doctor_advice_time);
        et_doctor_advice_content = getViewById(R.id.et_doctor_advice_content);
        rl_missionary = getViewById(R.id.rl_missionary);
        tv_missionary = getViewById(R.id.tv_missionary);
        rl_addressee = getViewById(R.id.rl_addressee);
        ll_addressee = getViewById(R.id.ll_addressee);
        tv_addressee = getViewById(R.id.tv_addressee);
        tv_doctor_advice_num = getViewById(R.id.tv_doctor_advice_num);
        tv_send_remind = getViewById(R.id.tv_send_remind);
        tv_send = getViewById(R.id.tv_send);

        //初始化默认显示
        et_doctor_advice_content.setHint(GlobalConfigSP.getDefaultMsg());
        editMaxNum = GlobalConfigSP.getLimitValue(GlobalConfigSP.BATCH_MESSAGE_CONTENT, 0, 180);
        et_doctor_advice_content.setFilters(new InputFilter[]{new InputFilter.LengthFilter(editMaxNum)});

        //是否显示宣教
        rl_missionary.setVisibility(View.GONE);
        if (getIntent() != null && getIntent().getSerializableExtra(PRO_EDU) != null) {
            mParse2PublicityBean = (Parse2PublicityBean) getIntent().getSerializableExtra(PRO_EDU);
            if (mParse2PublicityBean != null) {
                rl_missionary.setVisibility(View.VISIBLE);
                tv_missionary.setText(mParse2PublicityBean.getEduTitle());
            }
        }
    }


    @Override
    public void listeners() {
        xc_id_model_titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        xc_id_model_titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View
                .OnClickListener() {
            @Override
            public void onClick(View view) {
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(XD_NewGroupSendActivity.class, "2", "128", "MassHistory","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end
                // 进入群发历史
                myStartActivityForResult(SX_MassHistoryActivity.class, 0);
            }
        });
        //宣教链接监听
        rl_missionary.setOnClickListener(this);
        //收件人item监听
        rl_addressee.setOnClickListener(this);
        //发送按钮监听
        tv_send.setOnClickListener(this);
        //输入监听
        et_doctor_advice_content.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                tv_doctor_advice_num.setText(et_doctor_advice_content.getText().length() + "/" + editMaxNum);
                editContext = et_doctor_advice_content.getText().toString().trim();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_addressee:
                if(UtilString.toInt(UtilSP.getPatientSum(),0) == 0){
                    shortToast("群发需要至少添加一个患者，请先添加患者再进行群发");
                    return;
                }
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(XD_NewGroupSendActivity.class, "2", "128", "rl_addressee","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end
                // 选择收件人
                Intent intent = new Intent();
                //所有患者
                intent.putExtra("type", currentType);
                if (AddresseeInfoBean.ALL_PATIENTS == currentType) {
                    //能收到患者组
                } else if (AddresseeInfoBean.CAN_RECEIVE == currentType) {
                    intent.putExtra("patientGroupBeanList", (Serializable) patientGroupBeenList);
                    //收不到患者组
                } else if (AddresseeInfoBean.CANNOT_RECEIVE == currentType) {
                    intent.putExtra("patientGroupBeanList", (Serializable) patientGroupBeenList);
                    //个别患者组
                } else if (AddresseeInfoBean.INDIVIDUAL == currentType) {
                    intent.putExtra("currentChoosePatientBeanList", (Serializable) currentChoosePatientBean);
                }
                intent.setClass(this, SX_AddresseeActivity.class);
                myStartActivityForResult(intent, 0);
                break;
            case R.id.tv_send:
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(XD_NewGroupSendActivity.class, "2", "128", "tv_send","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end

                //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
                if (mParse2PublicityBean == null) {
                    GrowingIOUtil.track("adviceGroupMessage", null);
                }else{
                    Map<String,String> track = new HashMap<>();
                    track.put("contentTitle", tv_missionary.getText().toString().trim());
                    GrowingIOUtil.track("knowledgeGroupMessage", track);
                }
                //add by songxin,date：2018-3-29,about：GrowingIO banner track,end

                //发送消息
                sendMsg();
                break;
            case R.id.rl_missionary:
                ToJumpHelp.toJumpMyMissionaryActivity(this,"0",mParse2PublicityBean);
                break;
        }
        super.onClick(v);
    }

    /**
     * 发送消息
     */
    private void sendMsg() {
        //首先判断是否有患者
        if(UtilString.toInt(UtilSP.getPatientSum(),0) == 0){
            shortToast("群发需要至少添加一个患者，请先添加患者再进行群发");
            return;
        }
        RequestParams params = new RequestParams();
        XC_ChatModel xc_chatModel = new XC_ChatModel();
        xc_chatModel.getUserPatient().setPatientId("1");
        xc_chatModel.setMsgTime(System.currentTimeMillis() + "");
        xc_chatModel.getUserDoctor().setDoctorSelfId(UtilSP.getUserId());
        //判断是否有宣教
        if (mParse2PublicityBean == null) {
            printi("http", "null");
            if (TextUtils.isEmpty(editContext)) {
                shortToast("您好像什么也没写啊！");
                return;
            }
            xc_chatModel.setMsgType("1");
            xc_chatModel.setMessageText(editContext);
            params.add("message", UtilIMCreateJson.createTextJson(xc_chatModel));
        } else {
            printi("http", "!null");
            xc_chatModel.setMsgType("2048");
            xc_chatModel.getChatModelEdu().setEduOrigin(mParse2PublicityBean.getEduOrigin());
            xc_chatModel.getChatModelEdu().setEduId(mParse2PublicityBean.getEduId());
            xc_chatModel.getChatModelEdu().setEduTitle(mParse2PublicityBean.getEduTitle());
            xc_chatModel.getChatModelEdu().setEduUrl(mParse2PublicityBean.getEduUrl());
            if (!TextUtils.isEmpty(editContext)) {
                xc_chatModel.getChatModelEdu().setEduText(editContext);
            }
            params.add("message", UtilIMCreateJson.createPublicityEducationJson(xc_chatModel));
        }
        params.add("receiveType", "" + currentType);

        //根据接收类型选择上传数据
        if (currentType == AddresseeInfoBean.CAN_RECEIVE || currentType == AddresseeInfoBean.CANNOT_RECEIVE) {
            //添加分组id数据
            if (patientGroupBeenList.size() > 0) {
                String s = "";
                for (int i = 0; i < patientGroupBeenList.size(); i++) {
                    if (i == patientGroupBeenList.size() - 1) {
                        s += patientGroupBeenList.get(i).getId();
                    } else {
                        s += patientGroupBeenList.get(i).getId() + ",";
                    }
                }
                params.add("groupIds", s);
            }
        } else if (currentType == AddresseeInfoBean.INDIVIDUAL) {
            //添加患者id数据
            if (currentChoosePatientBean.size() > 0) {
                String s = "";
                for (int i = 0; i < currentChoosePatientBean.size(); i++) {
                    if (i == currentChoosePatientBean.size() - 1) {
                        s += currentChoosePatientBean.get(i).getUserPatient().getPatientId();
                    } else {
                        s += currentChoosePatientBean.get(i).getUserPatient().getPatientId() + ",";
                    }
                }
                params.add("patientIds", s);
            }
        }
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.groupSend), params, new
                XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            List<XCJsonBean> jsonBeans = result_bean.getList("data");
                            if (jsonBeans != null && jsonBeans.size() > 0) {
                                totalNum = jsonBeans.get(0).getInt("totalNum");
                                sendNum = jsonBeans.get(0).getInt("lastNum");
                                //初始化
                                initBaseInfo();
                                //清楚编辑内容 收件人
                                et_doctor_advice_content.setText("");
                                ll_addressee.removeAllViews();
                                ll_addressee.addView(tv_addressee);
                                patientGroupBeenList.clear();
                                currentChoosePatientBean.clear();
                                currentType = 1;

                                shortToast("发送成功");
                                //跳转到发送历史页面
                                myStartActivityForResult(SX_MassHistoryActivity.class, 0);
                            }
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        // 发送失败
                        shortToast("发送失败");
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_NewGroupSendActivity.this,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

    /**
     * 请求日期 发送次数等
     */
    private void requstBaseInfo() {
        RequestParams params = new RequestParams();
        XCHttpAsyn.postAsyn(true, this, AppConfig.getHostUrl(AppConfig.groupSendNum), params, new
                XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            List<XCJsonBean> jsonBeans = result_bean.getList("data");
                            if (jsonBeans != null && jsonBeans.size() > 0) {
                                XCJsonBean xcJsonBean = jsonBeans.get(0);
                                currentTime = xcJsonBean.getString("currentTime");
                                totalNum = xcJsonBean.getInt("totalNum");
                                sendNum = xcJsonBean.getInt("lastNum");
                                //初始化
                                initBaseInfo();
                            }
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        showNoNetLayout();
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_NewGroupSendActivity.this,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

    /**
     * 初始化次数 日期等控件内容
     */
    private void initBaseInfo() {
        if (!TextUtils.isEmpty(currentTime)) {
            sendTime = DateUtils.DateFormat(currentTime, DateUtils.FORMAT_MMDD_STRIPING);
            tv_doctor_advice_time.setText(sendTime);
        } else {
            tv_doctor_advice_time.setText("无数据");
        }
        if (sendNum > 0) {
            if (GlobalConfigSP.getGreenMsg().contains("%s")) {
                tv_send_remind.setText(GlobalConfigSP.getGreenMsg().replace("%s", sendNum + ""));
            }
            tv_send.setClickable(true);
            tv_send.setTextColor(getResources().getColor(R.color.c_e2231a));
        } else {
            tv_send_remind.setText(GlobalConfigSP.getRedMsg());
            tv_send.setClickable(false);
            tv_send.setTextColor(getResources().getColor(R.color.c_f6cecd));
        }
        tv_send.setText("发送消息(" + (totalNum - sendNum) + "/" + totalNum + ")");
    }

    @Override
    public void onNetRefresh() {
        //请求基本信息
        requstBaseInfo();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 1) {
            if (data != null) {
                ll_addressee.removeAllViews();
                currentType = data.getIntExtra("type", 0);
                //所有患者
                if (AddresseeInfoBean.ALL_PATIENTS == currentType) {
                    ll_addressee.addView(tv_addressee);

                    //能收到患者组
                } else if (AddresseeInfoBean.CAN_RECEIVE == currentType) {
                    patientGroupBeenList.clear();
                    patientGroupBeenList.addAll((List<PatientGroupBean>) data.getSerializableExtra("patientGroupBeanList"));
                    AddresseeTextShowView.settingAddresseeTextShow(XD_NewGroupSendActivity.this, patientGroupBeenList, ll_addressee, currentType);
                    //收不到患者组
                } else if (AddresseeInfoBean.CANNOT_RECEIVE == currentType) {
                    patientGroupBeenList.clear();
                    patientGroupBeenList.addAll((List<PatientGroupBean>) data.getSerializableExtra("patientGroupBeanList"));
                    AddresseeTextShowView.settingAddresseeTextShow(XD_NewGroupSendActivity.this, patientGroupBeenList, ll_addressee, currentType);

                    //个别患者组
                } else if (AddresseeInfoBean.INDIVIDUAL == currentType) {
                    currentChoosePatientBean.clear();
                    currentChoosePatientBean.addAll((List<XC_ChatModel>) data.getSerializableExtra("currentChoosePatientBeanList"));
                    AddresseeTextShowView.settingAddresseeTextShow(XD_NewGroupSendActivity.this, currentChoosePatientBean, ll_addressee, currentType);

                }
            }
            //从群发历史页面返回
        } else if (resultCode == 2) {
            printi("http","resultCode==2");
            if (data != null) {
                ll_addressee.removeAllViews();
                massHistoryBean = (MassHistoryBean) data.getSerializableExtra("MassHistoryBean");
                if (massHistoryBean != null) {
                    if ("1".equals(massHistoryBean.getReceiveType())) {
                        currentType = AddresseeInfoBean.ALL_PATIENTS;
                    } else if ("2".equals(massHistoryBean.getReceiveType())) {
                        currentType = AddresseeInfoBean.CAN_RECEIVE;
                    } else if ("3".equals(massHistoryBean.getReceiveType())) {
                        currentType = AddresseeInfoBean.CANNOT_RECEIVE;
                    } else if ("4".equals(massHistoryBean.getReceiveType())) {
                        currentType = AddresseeInfoBean.INDIVIDUAL;
                    }

                    //所有患者
                    if (AddresseeInfoBean.ALL_PATIENTS == currentType) {
                        ll_addressee.addView(tv_addressee);

                        //能收到患者组
                    } else if (AddresseeInfoBean.CAN_RECEIVE == currentType) {
                        patientGroupBeenList.clear();
                        for(PatientGroupBean patientGroupBean : massHistoryBean.getPatientGroupBeanList()){
                            for(PatientGroupBean allPatientGroupBean : allPatientGroupBeenList){
                                if(allPatientGroupBean.getId().equals(patientGroupBean.getId())){
                                    patientGroupBeenList.add(patientGroupBean);
                                }
                            }
                        }
                        //如果患者分组回传的被删除掉了，显示为所有患者
                        if(patientGroupBeenList.size() == 0){
                            currentType = AddresseeInfoBean.ALL_PATIENTS;
                            ll_addressee.addView(tv_addressee);
                        }else {
                            AddresseeTextShowView.settingAddresseeTextShow(XD_NewGroupSendActivity.this, patientGroupBeenList, ll_addressee, currentType);
                        }
                        //收不到患者组
                    } else if (AddresseeInfoBean.CANNOT_RECEIVE == currentType) {
                        patientGroupBeenList.clear();
                        for(PatientGroupBean patientGroupBean : massHistoryBean.getPatientGroupBeanList()){
                            for(PatientGroupBean allPatientGroupBean : allPatientGroupBeenList){
                                if(allPatientGroupBean.getId().equals(patientGroupBean.getId())){
                                    patientGroupBeenList.add(patientGroupBean);
                                }
                            }
                        }
                        //如果患者分组回传的被删除掉了，显示为所有患者
                        if(patientGroupBeenList.size() == 0){
                            currentType = AddresseeInfoBean.ALL_PATIENTS;
                            ll_addressee.addView(tv_addressee);
                        }else {
                            AddresseeTextShowView.settingAddresseeTextShow(XD_NewGroupSendActivity.this, patientGroupBeenList, ll_addressee, currentType);
                        }

                        //个别患者组
                    } else if (AddresseeInfoBean.INDIVIDUAL == currentType) {
                        currentChoosePatientBean.clear();
                        currentChoosePatientBean.addAll(massHistoryBean.getChoosePatientBeanList());
                        AddresseeTextShowView.settingAddresseeTextShow(XD_NewGroupSendActivity.this, currentChoosePatientBean, ll_addressee, currentType);

                    }
                    //更新内容
                    if (!TextUtils.isEmpty(massHistoryBean.getMsgContent())) {
                        et_doctor_advice_content.setText(massHistoryBean.getMsgContent());
                        et_doctor_advice_content.setSelection(massHistoryBean.getMsgContent().length());
                    } else {
                        et_doctor_advice_content.setText("");
                    }
                    //判断是否有宣教
                    if (!TextUtils.isEmpty(massHistoryBean.getEduId())) {
                        printi("http","massHistoryBean.getEduId() != null");
                        Parse2PublicityBean parse2PublicityBean = new Parse2PublicityBean();
                        parse2PublicityBean.setEduId(massHistoryBean.getEduId());
                        parse2PublicityBean.setEduTitle(massHistoryBean.getEduTitle());
                        parse2PublicityBean.setEduUrl(massHistoryBean.getEduUrl());
                        parse2PublicityBean.setEduText(massHistoryBean.getEduTitle());
                        mParse2PublicityBean = parse2PublicityBean;
                        rl_missionary.setVisibility(View.VISIBLE);
                        tv_missionary.setText(mParse2PublicityBean.getEduTitle());
                    } else {
                        rl_missionary.setVisibility(View.GONE);
                        tv_missionary.setText("");
                    }
                }
            }
        }
    }

    /** 获得分组列表
     * @param isDialog 是否显示进度条
     * */
    public void  requestPatientGroupList(boolean isDialog) {
        XCHttpAsyn.postAsyn(isDialog, this, AppConfig.getHostUrl(AppConfig.patient_group_list), new RequestParams(), new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<XCJsonBean> result_list = result_bean.getList("data");
                    if (result_list != null) {
                        //解析患者分组列表数据
                        Parse2PatientGroupBean parse2PatientGroupBean = new Parse2PatientGroupBean();
                        allPatientGroupBeenList.clear();
                        allPatientGroupBeenList.addAll(parse2PatientGroupBean.parse(result_bean));
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_NewGroupSendActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // created by songxin,date：2017-4-15,about：DBYZ-5385,begin
        //判断是否是宣教
        if (mParse2PublicityBean == null) {
            //保存输入内容
            UtilSP.setGroupSendText(editContext);
        }
        // created by songxin,date：2017-4-15,about：DBYZ-5385,end
        myFinish();
    }
}
