package com.qlk.ymz.db.bi;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.qlk.ymz.util.bi.BiBean;
import com.xiaocoder.android.fw.general.application.XCApplication;

import java.util.ArrayList;
import java.util.List;

/**
 * SX_BiUpdateFailDao
 * bi统计失败数据库操作类
 * @author songxin on 2016/4/27.
 * @version 2.3.0
 */
public class SX_BiUpdateFailDao {
    /** 数据库名 */
    private final static String DATABASE_NAME = "db_biUpdateFail";
    /** 咨询列表信息表名 */
    private static final String TB_NAME = "tb_bi_update_fail";
    /** 数据库版本*/
    public static final int DB_VERSION = 1;
    /** 主键*/
    public static final String _ID = "_id";
    /** bi统计上传失败内容*/
    public static final String BI_CONTENT = "bi_content";
    /** bi失败内容存入时间*/
    public static final String SAVE_TIME = "save_time";
    /** 排序常量 降序*/
    public static String SORT_DESC = "DESC";
    /** 排序常量 升序*/
    public static String SORT_ASC = "ASC";
    /** 数据库处理对象 */
    private static SX_BiUpdateFailDao dbProcessObj = null;
    /** 数据库对象 */
    private SQLiteDatabase db = null;
    /** 上下文对象 */
    private Context context = null;

    /**
     * 构造方法
     * @param context 上下文
     */
    private SX_BiUpdateFailDao(Context context) {
        this.context = context;
    }

    /**
     * 获取数据库适配器对象
     * @param context 上下文对象
     * @return 数据库处理对象
     */
    public static SX_BiUpdateFailDao getInstance(Context context) {
        if(null == dbProcessObj) {
            dbProcessObj = new SX_BiUpdateFailDao(context);
        }
        return dbProcessObj.openDataBase(context);
    }

    /**
     * 获取数据库操作权限
     * @param context 上下文对象
     * @return 数据库操作操作对象
     */
    private SX_BiUpdateFailDao openDataBase(Context context) {
        DbHelper dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
        return dbProcessObj;
    }

    /**
     * 插入bi数据
     * @param sx_biUpdateFailModel bi数据
     * @return 新插入行的rowId，或 发生错误返回-1
     */
    public long insertBiData(SX_BiUpdateFailModel sx_biUpdateFailModel){
         XCApplication.base_log.i("DB","==========insertBiData=============");
        try {
            //先检查大小，大于一定条数
            int rowId = 0;
            Cursor cursor =  getAll();
            if(null != cursor){
                XCApplication.base_log.i("DB","cursor---->"+cursor.getCount());
                if(cursor.getCount() + 1 >= 500){
                    if(cursor.moveToFirst()){
                        rowId = cursor.getInt(cursor.getColumnIndexOrThrow(_ID));
                        deleteDataForId(rowId);
                    }
                }
                cursor.close();
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put(BI_CONTENT, sx_biUpdateFailModel.getBi_content());
            contentValues.put(SAVE_TIME, sx_biUpdateFailModel.getSave_time());
            return db.insert(TB_NAME, null, contentValues);
        } catch(Exception e) {
            e.printStackTrace();
            XCApplication.base_log.i("DB"," e.printStackTrace()---->"+ e.toString());
        } finally{
            closeDataBase();
        }

        return -1;
    }

    /**
     * 获取数据库中所有数据
     * @return 返回一个数据集合
     */
    public  List<SX_BiUpdateFailModel> getAllBiData(){
        List<SX_BiUpdateFailModel> sx_biUpdateFailModelList = new ArrayList<>();
        try {
            Cursor cursor =  getAll();
            if(null != cursor && cursor.getCount() > 0){
                XCApplication.base_log.i("http","cursor.getCount==>"+cursor.getCount());
                while (cursor.moveToNext()){
                    SX_BiUpdateFailModel sx_biUpdateFailModel = new SX_BiUpdateFailModel();
                    sx_biUpdateFailModel.setBi_content(cursor.getString(cursor.getColumnIndexOrThrow(BI_CONTENT)));
                    sx_biUpdateFailModel.setSave_time(cursor.getString(cursor.getColumnIndexOrThrow(SAVE_TIME)));
                    sx_biUpdateFailModelList.add(sx_biUpdateFailModel);
                }
                cursor.close();
            }
        } catch(Exception e) {
            e.printStackTrace();
        }finally {
            closeDataBase();
        }
        return sx_biUpdateFailModelList;
    }

    /**
     * 获取所有数据
     * @return 数据集合
     */
    public Cursor getAll(){
        String col[] = new String[] { _ID, BI_CONTENT, SAVE_TIME};
        return db.query(TB_NAME, col, null, null, null, null, SAVE_TIME +" "+ SORT_ASC);
    }

    public long deleteDataForId(int rowId){
        String where = _ID + "=\"" + rowId + "\"";
        return db.delete(TB_NAME, where, null);
    }

    /**
     * @return 删除数据库中全部数据
     */
    public long deleteData(){
        return db.delete(TB_NAME, null, null);
    }

    /**
     * 关闭数据库
     */
    private void closeDataBase() {
        try {
            if(null != db && db.isOpen()) {
                db.close();
            }
        }catch(Exception e) {
            System.out.println("---close database happened exception---");
            e.printStackTrace();
        }
    }

    /**
     * 数据库助手类
     */
    private class DbHelper extends SQLiteOpenHelper {
        /**
         * 构造方法
         * @param context 上下文对象
         */
        public DbHelper(Context context) {
            super(context, DATABASE_NAME, null, DB_VERSION);
        }

        /**
         * 初始化数据库
         * @param db 数据库对象
         */
        public void onCreate(SQLiteDatabase db) {
            // sql文
            String sql = "";

            // 创建“咨询列表信息表”
            sql = "create table " + TB_NAME +
                    "(" +
                    _ID + " integer primary key AUTOINCREMENT," +
                    BI_CONTENT + " text, " +
                    SAVE_TIME + " text" +
                    ")";
            db.execSQL(sql);
        }

        /**
         * 更新数据库
         * @param db 数据库对象
         * @param oldVersion 数据库的旧版本号
         * @param newVersion 数据库的新版本号
         */
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            if(newVersion > oldVersion) {
                db.execSQL("drop table if exists " + TB_NAME);
                onCreate(db);
            }
        }
    }

}
