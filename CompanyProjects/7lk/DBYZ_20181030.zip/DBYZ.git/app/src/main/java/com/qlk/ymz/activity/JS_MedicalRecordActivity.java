package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.JS_MedicalRecordAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.MedicalDetailBean;
import com.qlk.ymz.model.MedicalRecordBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * 病历档案列表页
 * @author 徐金山
 * @version 1.2.0
 */
public class JS_MedicalRecordActivity extends DBActivity implements AbsListView.OnScrollListener {
    // ********************变量********************
    /** 患者ID */
    private String patientId;
    /** 当前页号（默认值：1） */
    private int pageIndex = 1;
    /** 每页记录条数（默认值：10） */
    private String num = "10";
    /** 最后的可视项索引（默认值：0） */
    private int visibleLastIndex = 0;

    // ********************页面控件********************
    /** title左边按钮*/
    private ImageView sx_id_title_left;
    /** title中间文字*/
    private TextView sx_id_title_center;
    /** 病历档案列表控件 */
    private ListView lv_medicalRecordList;
    /** 没有数据时的UI显示内容（布局） */
    private LinearLayout rl_noData;

    /** 病历档案信息Bean */
    private MedicalRecordBean medicalRecordBean = new MedicalRecordBean();
    /** 病历档案适配器 */
    private JS_MedicalRecordAdapter medicalRecordAdapter;

    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.js_activity_medical_record);
        initData();
        super.onCreate(savedInstanceState);

        pricessBiz();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(JS_MedicalRecordActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    /**
     * 获取控件对象
     */
    @Override
    public void initWidgets() {
        sx_id_title_left = (ImageView)findViewById(R.id.sx_id_title_left);
        sx_id_title_center = (TextView)findViewById(R.id.sx_id_title_center);
        lv_medicalRecordList = (ListView) findViewById(R.id.lv_medicalRecordList);

        rl_noData = (LinearLayout) findViewById(R.id.rl_noData);
        ((TextView)getViewById(R.id.id_zero_data_tv)).setText("此患者目前没有病历档案");

        medicalRecordAdapter = new JS_MedicalRecordAdapter(JS_MedicalRecordActivity.this, patientId, medicalRecordBean.getMedicalRecordList());
        lv_medicalRecordList.setAdapter(medicalRecordAdapter);
        lv_medicalRecordList.setOnScrollListener(JS_MedicalRecordActivity.this);
        sx_id_title_center.setText("病历档案");
    }

    /**
     * 设置监听事件
     */
    @Override
    public void listeners() {
        // 返回
        sx_id_title_left.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                myFinish();
            }
        });

        // 病历档案列表
        lv_medicalRecordList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            }
        });
    }

    private void initData() {
        Intent intent = getIntent();
        patientId = intent.getStringExtra("patientId");
        if(null == patientId) {
            patientId = "";
        }
    }

    /**
     * 业务处理
     */
    private void pricessBiz() {
        getDataFromServer(pageIndex);
    }

    /**
     * 从服务器端获取病历档案列表信息
     * @param pageIndex 请求的号页
     */
    private void getDataFromServer(int pageIndex) {
        RequestParams params = new RequestParams();
        if (UtilString.isBlank(patientId)){
            rl_noData.setVisibility(View.VISIBLE);
            return;
        }
        params.put("patientId", patientId);
        params.put("page", String.valueOf(pageIndex));
        params.put("num", num);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.medicalRecord), params, new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);

                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                         // System.out.println("获取病历档案列表接口" + jsonBeans.get(0).toString());

                        XCJsonBean tempObj = jsonBeans.get(0);

                        medicalRecordBean.setPageNo(tempObj.getString("pageNo"));
                        medicalRecordBean.setPageSize(tempObj.getString("pageSize"));
                        medicalRecordBean.setOrderBy(tempObj.getString("orderBy"));
                        medicalRecordBean.setOrder(tempObj.getString("order"));
                        medicalRecordBean.setTotalCount(tempObj.getString("totalCount"));
                        medicalRecordBean.setFirst(tempObj.getString("first"));
                        medicalRecordBean.setOrderBySetted(tempObj.getString("orderBySetted"));
                        medicalRecordBean.setTotalPages(tempObj.getString("totalPages"));
                        medicalRecordBean.setHasNext(tempObj.getString("hasNext"));
                        medicalRecordBean.setNextPage(tempObj.getString("nextPage"));
                        medicalRecordBean.setHasPre(tempObj.getString("hasPre"));
                        medicalRecordBean.setPrePage(tempObj.getString("prePage"));

                        ArrayList<XCJsonBean> medicalRecordList = (ArrayList<XCJsonBean>) tempObj.getList("result");
                        int medicalRecordListSize = medicalRecordList.size();
                        for (int i = 0; i < medicalRecordListSize; i++) {
                            MedicalDetailBean medicalDetailBean = new MedicalDetailBean();
                            XCJsonBean tempResultObj = medicalRecordList.get(i);
                            medicalDetailBean.setId(tempResultObj.getString("id"));
                            medicalDetailBean.setHospital(tempResultObj.getString("hospital"));
                            medicalDetailBean.setDepartment(tempResultObj.getString("department"));
                            medicalDetailBean.setVistingTime(tempResultObj.getString("vistingTime"));
                            medicalDetailBean.setDiscription(tempResultObj.getString("description"));
                            List<XCJsonBean> imgsList = tempResultObj.getList("imgs");
                            int imgsListSize = imgsList.size();
                            for (int j = 0; j < imgsListSize; j++) {
                                medicalDetailBean.getImgList().add(imgsList.get(j).getString("imgUrl"));
                            }

                            medicalRecordBean.getMedicalRecordList().add(medicalDetailBean);
                        }

                        setDataToViews();
                    }
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(JS_MedicalRecordActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 将数据设置到页面控件上
     */
    private void setDataToViews() {
        if(medicalRecordBean.getMedicalRecordList().size() == 0) {
            rl_noData.setVisibility(View.VISIBLE);
            lv_medicalRecordList.setVisibility(View.GONE);
        }else {
            rl_noData.setVisibility(View.GONE);
            lv_medicalRecordList.setVisibility(View.VISIBLE);
            medicalRecordAdapter.notifyDataSetChanged();
        }
    }

    public void onScrollStateChanged(AbsListView view, int scrollState) {
        // 数据集最后一项的索引
        int lastIndex = medicalRecordAdapter.getCount() - 1;

        if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE && visibleLastIndex == lastIndex) {
            int totalPages = Integer.valueOf(medicalRecordBean.getTotalPages());
            if(pageIndex < totalPages) {
                pageIndex++;
                getDataFromServer(pageIndex);
            }else if(pageIndex == totalPages) {
                // Toast.makeText(JS_MedicalRecordActivity.this, "已是最后一页", Toast.LENGTH_SHORT).show(); // deleted by xjs 修复JIRA上编号为1312的问题
            }
        }
    }

    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        this.visibleLastIndex = firstVisibleItem + visibleItemCount - 1;
    }

    @Override
    public void onNetRefresh() {

    }
}
