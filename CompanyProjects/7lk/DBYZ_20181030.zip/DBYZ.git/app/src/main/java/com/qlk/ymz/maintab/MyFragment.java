package com.qlk.ymz.maintab;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gdca.sdk.casign.model.GdcaCertModel;
import com.loopj.android.http.RequestParams;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.JS_WebViewActivity;
import com.qlk.ymz.activity.SK_SettingActivityV2;
import com.qlk.ymz.activity.TF_AskVideoListActivity;
import com.qlk.ymz.activity.XD_ServiceChatActivity;
import com.qlk.ymz.activity.XL_PointsActivityV2;
import com.qlk.ymz.activity.YY_FeedbackVisitActivity;
import com.qlk.ymz.activity.YY_PersonalDataActivityV2;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.model.YY_UserCenterBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.ElectronicSignatureHelper;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.HospitalBackupsBeanSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import org.apache.http.Header;

import java.util.List;

/**
 * MyFragment
 * 石榴云医-个人中心
 * @author songxin on 2018/8/1.
 * @version 3.0.0
 */
public class MyFragment extends DBFragment {
    /** Setting*/
    private ImageView iv_setting;
    /** 头像*/
    private XCRoundedImageView riv_my_head;
    /** 医生姓名*/
    private TextView tv_doctor_name;
    /** 医生科室，职称*/
    private TextView tv_department_and_title;
    /** 医生所属医院*/
    private TextView tv_hospital;
    /** 去认证layout*/
    private LinearLayout ll_goto_auth;
    /** 去认证text*/
    private TextView tv_goto_auth;
    /** 患者layout*/
    private LinearLayout ll_patient;
    /** 患者数量显示*/
    private TextView tv_patient_size;
    /** 线*/
    private View v_maybe_gone;
    /** 我的积分显示最外层rl*/
    private RelativeLayout rl_my_integral;
    /** 我的积分显示内层ll，点击跳转使用*/
    private LinearLayout ll_my_integral;
    /** 是否显示积分*/
    private ImageView iv_see_integral;
    /** 积分*/
    private TextView tv_integral_size;
    /** 评价数量显示*/
    private TextView tv_evaluate_size;
    /** 评价Layout*/
    private LinearLayout ll_evaluate;
    /** 互联网医院layout*/
    private RelativeLayout rl_hospital_record;
    /** 未备案显"去备案"*/
    private TextView tv_goto_hospital_record;
    /** 付费咨询layout*/
    private RelativeLayout rl_pay_consulting;
    /** 视频咨询layout*/
    private RelativeLayout rl_video_consulting;
    /** 随访量表layout*/
    private RelativeLayout rl_follow_scale;
    /** 邀请医生layout*/
    private RelativeLayout rl_invite_doctors;
    /** 医生助手layout*/
    private RelativeLayout rl_help_center;
    /** 使用教程layout*/
    private RelativeLayout rl_use_tutorial;
    /** 帮助中心数量显示*/
    private TextView tv_service_num;
    /** 视频咨询数量显示*/
    private TextView tv_video_num;
    /** 认证状态显示*/
    private ImageView iv_auth_show;
    /** 认证状态临时变量*/
    private String authStatus = "";
    /** 是否可以申请备案 0：不能备案，1：可以备案 */
    private String recordAble = "";
    /** 自定义dialg*/
    private YR_CommonDialog mYR_commonDialog;
    /** 积分是否可见*/
    private boolean isSeeIntegral = false;
    /** 总积分数*/
    private String totalPoint = "";
    /** 图片显示设置*/
    private DisplayImageOptions default_options = XCImageLoaderHelper.getDisplayImageOptions2(R.mipmap.sx_d_identity_personal_head_icon_v2);

    @Override
    public boolean isBodyFragment() {
        return true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // 设置布局
        return init(inflater, R.layout.fragment_my);
    }


    @Override
    public void onResume() {
        super.onResume();
        initEyeStatus();
        if (!this.isHidden()) {
            mContainer.postDelayed(new Runnable() {
                @Override
                public void run() {
                    requestDoctorData();
                }
            }, 200);
        }
    }

    @Override
    public void initWidgets() {
        iv_setting = getViewById(R.id.iv_setting);
        riv_my_head = getViewById(R.id.riv_my_head);
        tv_doctor_name = getViewById(R.id.tv_doctor_name);
        tv_department_and_title = getViewById(R.id.tv_department_and_title);
        tv_hospital = getViewById(R.id.tv_hospital);
        v_maybe_gone = getViewById(R.id.v_maybe_gone);
        ll_patient = getViewById(R.id.ll_patient);
        iv_auth_show = getViewById(R.id.iv_auth_show);
        ll_goto_auth = getViewById(R.id.ll_goto_auth);
        tv_goto_auth = getViewById(R.id.tv_goto_auth);
        tv_patient_size = getViewById(R.id.tv_patient_size);
        rl_my_integral = getViewById(R.id.rl_my_integral);
        ll_my_integral = getViewById(R.id.ll_my_integral);
        iv_see_integral = getViewById(R.id.iv_see_integral);
        tv_integral_size = getViewById(R.id.tv_integral_size);
        tv_evaluate_size = getViewById(R.id.tv_evaluate_size);
        ll_evaluate = getViewById(R.id.ll_evaluate);
        rl_hospital_record = getViewById(R.id.rl_hospital_record);
        tv_goto_hospital_record = getViewById(R.id.tv_goto_hospital_record);
        rl_pay_consulting = getViewById(R.id.rl_pay_consulting);
        rl_video_consulting = getViewById(R.id.rl_video_consulting);
        rl_follow_scale = getViewById(R.id.rl_follow_scale);
        rl_invite_doctors = getViewById(R.id.rl_invite_doctors);
        rl_help_center = getViewById(R.id.rl_doctor_helper);
        tv_service_num = getViewById(R.id.tv_service_num);
        tv_video_num = getViewById(R.id.tv_video_num);
        rl_use_tutorial = getViewById(R.id.rl_use_tutorial);
        showVideoConsultNum();
        showDoctorAsstantNum();
        // 1.从首页接口获得的状态；2.如果个人中心接口请求失败，此处取得是本地存储状态
        // 阳光化显示策略（网路请求失败，如果本地没有ispublic的记录，不显示随访；如果本地有记录，显示存储的状态）
        rl_follow_scale.setVisibility("2".equals(UtilSP.getDoctorSunshine()) ? View.VISIBLE :View.GONE);
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        initEyeStatus();
    }

    @Override
    public void listeners() {
        iv_setting.setOnClickListener(this);
        ll_goto_auth.setOnClickListener(this);
        ll_patient.setOnClickListener(this);
        ll_my_integral.setOnClickListener(this);
        iv_see_integral.setOnClickListener(this);
        rl_hospital_record.setOnClickListener(this);
        rl_pay_consulting.setOnClickListener(this);
        rl_video_consulting.setOnClickListener(this);
        rl_follow_scale.setOnClickListener(this);
        rl_invite_doctors.setOnClickListener(this);
        rl_help_center.setOnClickListener(this);
        ll_evaluate.setOnClickListener(this);
        rl_use_tutorial.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            //setting
            case R.id.iv_setting:
                myStartActivity(SK_SettingActivityV2.class);
                break;
            //去认证
            case R.id.ll_goto_auth:
                HospitalBackupsBeanSP.TO_ACTIVITY = NativeHtml5.DOCTOR_MINE;
                Intent personalDataIntent = new Intent();
                personalDataIntent.putExtra("authStatus",authStatus);
                personalDataIntent.setClass(getActivity(), YY_PersonalDataActivityV2.class);
                startActivity(personalDataIntent);
                break;
            //患者
            case R.id.ll_patient:
                Intent intent = new Intent(getActivity(), JS_MainActivity.class);
                intent.putExtra(JS_MainActivity.TAB_TAG,JS_MainActivity.TAB_PATIENT);
                myStartActivity(intent);
                break;
            //我的积分
            case R.id.ll_my_integral:
                myStartActivity(XL_PointsActivityV2.class);
                break;
            //积分是否可视
            case R.id.iv_see_integral:
                if(!isSeeIntegral){
                    iv_see_integral.setImageResource(R.mipmap.open_eyes);
                    tv_integral_size.setText(totalPoint);
                }else {
                    iv_see_integral.setImageResource(R.mipmap.close_eyes);
                    tv_integral_size.setText("***");
                }
                isSeeIntegral = !isSeeIntegral;
                break;
            //跳转到互联网医院备案
            case R.id.rl_hospital_record:
                // 备案入口
                if("5".equals(UtilSP.getDoctorStatus())){ // 不需要备案
                    showCommonDialog("您好，根据卫健委要求，您暂时不需要进行互联网医院备案，谢谢");
                    break;
                }
                HospitalBackupsBeanSP.TO_ACTIVITY = NativeHtml5.DOCTOR_MINE;
                if("0".equals(recordAble)){//不能备案
                    shortToast("请先在个人资料页提交认证后备案");
                    break;
                }
                if("0".equals(UtilSP.getDoctorStatus()) || "3".equals(UtilSP.getDoctorStatus()) || "4".equals(UtilSP.getDoctorStatus())){
                    UtilNativeHtml5.toJumpNativeH5(getActivity(), UtilNativeHtml5.INTERNET_HOSPITAL_RECORD);
                }else {
                    ToJumpHelp.toJumpBackupsOrProtocolActivity(getActivity());
                }
                break;
            //评价
            case R.id.ll_evaluate:
                GlobalConfigSP.setEvaluateClick(true);
                UtilNativeHtml5.toJumpNativeH5(getActivity(), UtilNativeHtml5.EVALUATE);
                break;
            //付费咨询
            case R.id.rl_pay_consulting:
                ToJumpHelp.toJumpSetConsultFeesActivity(getActivity());
                break;
            //视频咨询
            case R.id.rl_video_consulting:
                UtilSP.putNewVideoNum(0);
                tv_video_num.setVisibility(View.INVISIBLE);
                myStartActivity(TF_AskVideoListActivity.class);
                break;
            //随访量表
            case R.id.rl_follow_scale:
                myStartActivity(YY_FeedbackVisitActivity.class);
                break;
            //邀请医生
            case R.id.rl_invite_doctors:
                UtilNativeHtml5.toJumpQRcode(getActivity(), "1");
                break;
            //医生助手
            case R.id.rl_doctor_helper:
                tv_service_num.setVisibility(View.INVISIBLE);
                Intent intent1 = new Intent();
                intent1.setClass(getActivity(),XD_ServiceChatActivity.class);
                intent1.putExtra(JS_MainActivity.TAB_TAG,JS_MainActivity.TAB_MY);
                Log.i("tab_tag",JS_MainActivity.TAB_MY+"目前状态");
                myStartActivity(intent1);
                break;
            //使用教程
            case R.id.rl_use_tutorial:
                myStartActivity(JS_WebViewActivity.newIntent(getActivity(),new WebviewBean(AppConfig.getH5Url(AppConfig.USINGHELP))));
                break;
        }
    }

    /**
     * 获取个人中心数据
     * update on 2016-8-2 by 崔毅然 去掉进度条
     */
    public void requestDoctorData() {
        XCHttpAsyn.getAsyn(false, getActivity(), AppConfig.getHostUrl(AppConfig.user_center), new RequestParams(), new XCHttpResponseHandler<YY_UserCenterBean>(null, YY_UserCenterBean.class) {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<YY_UserCenterBean.DataEntity> objLists = mResultModel.getData();
                    if (objLists != null && objLists.size() > 0) {
                        YY_UserCenterBean.DataEntity obj = objLists.get(0);
                        String doctorName = obj.getName();
                        String headUrl = obj.getHeaderImageUrl();
                        authStatus = obj.getStatus();
                        recordAble = obj.getRecordable();
                        //put sp
                        UtilSP.setUserName(doctorName);
                        if (!TextUtils.isEmpty(headUrl)) {
                            UtilSP.putUserHeader(headUrl);
                        }
                        // 保存医生合法备案状态
                        UtilSP.setDoctorStatus(obj.getRecordStatus());
                        //设置备案的ui显示
                        setRecordStatus(obj.getRecordStatus());
                        //姓名职称
                        String title = obj.getTitle();
                        if (!UtilString.isBlank(doctorName)) {
                            tv_doctor_name.setText(doctorName);
                        }
                        if (!UtilString.isBlank(title) && !UtilString.isBlank(UtilSP.getDepartmentName())) {
                            String currentTitle = UtilSP.getDepartmentName() + " | " + title;
                            tv_department_and_title.setText(currentTitle);
                        }else {
                            String currentTitle = UtilSP.getDepartmentName()  + title;
                            tv_department_and_title.setText(currentTitle);
                        }
                        tv_hospital.setText(UtilSP.getHospitalName());
                        //首页和个人中心认证了才显示医生头像，而聊天页则认不认证都用医生头像(jira 1988)
                        UtilSP.setAuthStatus(authStatus);
                        setAuthStatus(headUrl, authStatus);

                        String isPublic = obj.getIsPublic();
                        UtilSP.putDoctorSunshine(isPublic);
                        // 显示随访记录按钮
                        rl_follow_scale.setVisibility("2".equals(isPublic) ? View.VISIBLE :View.GONE);
                        //判断是否显示我的积分入口
                        rl_my_integral.setVisibility("1".equals(obj.getShowPoint()) ? View.VISIBLE :View.GONE);


                        tv_integral_size.setText("***");
                        totalPoint = obj.getTotalPoint();
                        try {
                            if(Integer.valueOf(totalPoint) > 999999){
                                totalPoint = "100万+";
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }

                        tv_patient_size.setText(UtilSP.getPatientSum());
                        tv_evaluate_size.setText(UtilSP.getCommentCount());
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && getActivity() != null) {
                    GeneralReqExceptionProcess.checkCode(getActivity(),
                            getCode(),
                            getMsg());
                }
            }


        });
    }

    /**
     * add by xd 2017/8/2
     * 设置医生备案状态
     * @param recordStatus 备案状态
     */
    public void setRecordStatus(String recordStatus){
        //未申请备案或者要求备案不显示文案
        if("0".equals(recordStatus)||"4".equals(recordStatus)){
            tv_goto_hospital_record.setText("去备案");
        }else if("1".equals(recordStatus)){
            tv_goto_hospital_record.setText("备案审核中");
        }else if("5".equals(recordStatus)){ // 不需要备案
            tv_goto_hospital_record.setText("");
        }else if("3".equals(recordStatus)){
            tv_goto_hospital_record.setText("备案失败");
        }else if("2".equals(recordStatus)){
            ElectronicSignatureHelper.getInstance().getCertInfo(false,getActivity(), new
                    ElectronicSignatureHelper.CertInfoListener() {
                        @Override
                        public void onCertInfo(GdcaCertModel gdcaCertModel) {
                            tv_goto_hospital_record.setText("");//电子签名已设置
                        }

                        @Override
                        public void onFail(String s,int code) {
                            if(code == ElectronicSignatureHelper.UNSET_CERT){
                                tv_goto_hospital_record.setText("电子签名待设置");
                            }else {
                                tv_goto_hospital_record.setText("");
                            }
                        }
                    });
        }
    }

    /**
     * 设置医生认证状态 （0、第一次认证中；1、已认证；2、认证失败；3、再次认证中；4、未认证；5、信息不全，没有上传医生头像、资质认证等图片）
     * @param headUrl 医生头像地址
     * */
    public void setAuthStatus(String headUrl, String authStatus){
        if ("1".equals(authStatus)) {
            XCApplication.displayImage(headUrl, riv_my_head, default_options);
        }
        //已认证
        if ("1".equals(authStatus)) {
            iv_auth_show.setVisibility(View.VISIBLE);
            tv_goto_auth.setVisibility(View.INVISIBLE);
            //未认证或认证失败
        } else if("4".equals(authStatus) || "2".equals(authStatus)){
            iv_auth_show.setVisibility(View.GONE);
            tv_goto_auth.setVisibility(View.VISIBLE);
            tv_goto_auth.setText("去认证");
        }else {
            iv_auth_show.setVisibility(View.GONE);
            tv_goto_auth.setVisibility(View.INVISIBLE);
        }
    }

    /** V2.6 设置视频咨询的小红点 */
    public void showVideoConsultNum(){
        ( (JS_MainActivity)getActivity()).setBubbleNum(tv_video_num,UtilSP.getNewVideoNum());
    }
    /** V2.6.2 医生助手的小红点 */
    public void showDoctorAsstantNum(){
        ( (JS_MainActivity)getActivity()).setBubbleNum(tv_service_num,UtilSP.getDoctorAsstantNum());
    }

    /**
     * 我知道提示dialog
     *
     * @param content
     */
    public void showCommonDialog(String content) {
        if (mYR_commonDialog == null) {
            mYR_commonDialog = new YR_CommonDialog(getActivity(), content, "", "知道了") {
                @Override
                public void confirmBtn() {
                    mYR_commonDialog.dismiss();
                }
            };
        }
        mYR_commonDialog.setContentStr(content);
        mYR_commonDialog.show();
    }

    public void initEyeStatus(){
        iv_see_integral.setImageResource(R.mipmap.close_eyes);
        tv_integral_size.setText("***");
        isSeeIntegral = false;
    }
}
