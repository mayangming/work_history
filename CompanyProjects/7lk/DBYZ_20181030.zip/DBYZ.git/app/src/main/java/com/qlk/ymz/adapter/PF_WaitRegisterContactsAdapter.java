package com.qlk.ymz.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.qlk.ymz.R;
import com.qlk.ymz.activity.PF_WaitRegisterContactsActivity;
import com.qlk.ymz.activity.PF_WaitRegisterContactsDetailActivity;
import com.qlk.ymz.model.PF_WaitRegisterContactsInfo;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.UtilAppToSystemApp;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.PinnedHeaderExpandableListView;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhangpengfei.
 * @version 1.0
 */
public class PF_WaitRegisterContactsAdapter extends BaseExpandableListAdapter {
    /**字母集合*/
    private List<String> parentList;
    /**联系人内容*/
    private List<List<PF_WaitRegisterContactsInfo>> childList;
    private PinnedHeaderExpandableListView expandableListView;
    private Context mContext;

    public PF_WaitRegisterContactsAdapter(List<List<PF_WaitRegisterContactsInfo>> childList, PinnedHeaderExpandableListView expandableListView, List<String> parentList, Context mContext) {
        this.childList = childList;
        this.expandableListView = expandableListView;
        this.parentList = parentList;
        this.mContext = mContext;
    }

    @Override
    public int getGroupCount() {
        if(parentList != null){
            return parentList.size();
        }
        return 0;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        if(childList != null){
            return childList.get(groupPosition).size();
        }
        return 0;
    }

    @Override
    public Object getGroup(int groupPosition) {
        if(parentList != null){
            return parentList.get(groupPosition);
        }
        return null;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return childList.get(groupPosition).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupViewHolder groupViewHolder;
        if (convertView != null) {
            groupViewHolder = (GroupViewHolder) convertView.getTag();
        } else {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.xc_l_adapter_patient_letter_out_item, null);
            groupViewHolder = new GroupViewHolder();
            groupViewHolder.xc_id_fragment_search_letter_view = (TextView) convertView.findViewById(R.id.xc_id_fragment_search_letter_view);
            convertView.setTag(groupViewHolder);
        }
        if (null != parentList && parentList.size() > 0){
            groupViewHolder.xc_id_fragment_search_letter_view.setText(parentList.get(groupPosition));
        }
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        ChildViewHolder childViewHolder;
        if (convertView != null) {
            childViewHolder = (ChildViewHolder) convertView.getTag();
        } else {
            childViewHolder = new ChildViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.pf_item_wait_register_contact, null);
            childViewHolder.pf_id_item_contact_name = (TextView) convertView.findViewById(R.id.pf_id_item_contact_name);
            childViewHolder.pf_id_item_contact_again_invitation = (TextView) convertView.findViewById(R.id.pf_id_item_contact_again_invitation);
            childViewHolder.tv_bottom_line =  convertView.findViewById(R.id.tv_bottom_line);
            convertView.setTag(childViewHolder);
        }
        if (null != childList && childList.get(groupPosition).size() > 0){
            if (childList.get(groupPosition).size()-1 == childPosition) {
                childViewHolder.tv_bottom_line.setVisibility(View.GONE);
            } else {
                childViewHolder.tv_bottom_line.setVisibility(View.VISIBLE);
            }

            final PF_WaitRegisterContactsInfo contactModel = childList.get(groupPosition).get(childPosition);
            childViewHolder.pf_id_item_contact_name.setText(contactModel.getName());
            childViewHolder.pf_id_item_contact_again_invitation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // created by songxin,date：2016-4-25,about：saveInfo,begin
                    BiUtil.saveBiInfo(PF_WaitRegisterContactsDetailActivity.class,"2","128","pf_id_item_contact_again_invitation","",false);
                    // created by songxin,date：2016-4-25,about：saveInfo,end
                    sendSMS(contactModel.getPhone());
                }
            });
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, PF_WaitRegisterContactsDetailActivity.class);
                    intent.putExtra(PF_WaitRegisterContactsDetailActivity.CONTACTS_DETAIL, contactModel);
                    if (mContext instanceof XCBaseActivity){
                        ((XCBaseActivity)mContext).myStartActivity(intent);
                    }
                }
            });
        }

        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    /**
     * 更新数据
     * @param parentList 组列表
     * @param childList 子列表
     */
    public void update(List<String> parentList,List<List<PF_WaitRegisterContactsInfo>> childList){
        if(parentList == null){
            this.parentList = new ArrayList<>();
        } else {
            this.parentList = parentList;
        }
        if(childList == null){
            this.childList = new ArrayList<>();
        }else {
            this.childList = childList ;

        }
        //清除对应字母分组联系人数据为空的分组以及字母索引。
        notifyDataSetChanged();
        expanAll();
    }

    /**
     * 展开所有的组
     */
    public void expanAll(){
        int size = parentList.size();
        for(int i = 0 ; i < size ; i++){
            expandableListView.expandGroup(i);
        }
    }

    class GroupViewHolder {
        TextView xc_id_fragment_search_letter_view;
    }

    class ChildViewHolder {
        /**姓名*/
        TextView pf_id_item_contact_name;
        /**再次邀请*/
        TextView pf_id_item_contact_again_invitation;
        View tv_bottom_line;//底部分割线
    }

    /**
     * 发送短信
     * @param phone 电话
     */
    private void sendSMS(String phone){
        if(UtilString.isBlank(GlobalConfigSP.getInvitedMsg())){
            Toast.makeText(mContext, "网络出了点问题，请稍后再试", Toast.LENGTH_SHORT).show();
            if (mContext instanceof PF_WaitRegisterContactsActivity){
                ((PF_WaitRegisterContactsActivity)mContext).requestContactsSMSModel();//再次请求短信模板，待用户下次点击
            }
            return;
        }
        UtilAppToSystemApp.toSendSMS(mContext, phone, GlobalConfigSP.getInvitedMsg());
    }


}
