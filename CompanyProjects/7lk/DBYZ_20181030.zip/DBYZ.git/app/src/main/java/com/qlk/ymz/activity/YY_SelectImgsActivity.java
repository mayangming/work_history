package com.qlk.ymz.activity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.selectImgs.FolderItemDecoration;
import com.qlk.ymz.view.selectImgs.ImageFolderAdapter;
import com.qlk.ymz.view.selectImgs.ImageListAdapter;
import com.qlk.ymz.view.selectImgs.LocalMedia;
import com.qlk.ymz.view.selectImgs.LocalMediaFolder;
import com.qlk.ymz.view.selectImgs.LocalMediaLoader;
import com.qlk.ymz.view.selectImgs.SelectImgsItemDecoration;
import com.qlk.ymz.view.zoomimageview.XCViewPagerFragment;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author shuYanYi on 2016-09-20.
 * @description 本地图片选择 七乐康医生UI界面版（可设置参数：显示拍照功能、多选/单选模式、点击图片预览、是否裁剪等）
 * 图片列表会过滤掉医生端压缩处理完的专用上传文件夹 app_ymz/uploadImage下的图片(UtilFile.PATH_UPLOAD)，避免重复显示/与重复压缩
 * <p>
 * 使用：
 * YY_SelectImgsActivity.start(....) 方法启动
 * 调用的页面的onActivityResult请求码：requestCode == YY_SelectImgsActivity.REQUEST_IMAGE
 * 获取被选择的原始图片文件集合：ArrayList<File> files = (ArrayList<File>) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
 * 最终调用接口上传前，可调用UtilFile.ChangeImgsToUploadFiles 生成压缩图
 */
public class YY_SelectImgsActivity extends DBActivity {
    /** 选择图片的请求*/
    public final static int REQUEST_IMAGE = 66;
    /**拍照的请求*/
    public final static int REQUEST_CAMERA = 67;
    /**裁剪的请求*/
    public final static int REQUEST_CROP = 68;
    public final static String BUNDLE_CAMERA_PATH = "CameraPath";
    /**被选择的图片列表回调参数key*/
    public final static String REQUEST_OUTPUT = "outputList";

    /**
     * 传递参数key
     */
    public final static String EXTRA_SELECT_MODE = "SelectMode";//选择模式
    public final static String EXTRA_SHOW_CAMERA = "ShowCamera";//是否显示拍照功能项
    public final static String EXTRA_ENABLE_PREVIEW = "EnablePreview";//是否可预览
    public final static String EXTRA_ENABLE_CROP = "EnableCrop";//是否可裁剪
    public final static String EXTRA_MAX_SELECT_NUM = "MaxSelectNum";//最大选择张数
    public final static String EXTRA_SHOW_FOLDERS = "showFolders";//是否显示图片文件夹选项，可切换其他图片的文件夹

    /**标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**多选模式*/
    public final static int MODE_MULTIPLE = 1;
    /**单选模式*/
    public final static int MODE_SINGLE = 2;
    /**最多选择张数*/
    private int maxSelectNum = 6;
    /**选择模式*/
    private int selectMode = MODE_MULTIPLE;
    /**是否显示拍照选项*/
    private boolean showCamera = true;
    /**是否点击图片进入预览*/
    private boolean enablePreview = true;
    /**是否显示图片文件夹选项，用于切换其他图片文件夹*/
    private boolean showFolders = false;
    /**是否裁剪（对于单选模式有效）*/
    private boolean enableCrop = false;
    /**每列图片数量*/
    private int spanCount = 4;
    /**选择图片完成的按钮*/
    private TextView tv_doneText;
    /**预览按钮*/
    private TextView previewText;
    /**选择图片文件夹的按钮布局*/
    private RelativeLayout rl_select_folder;
    /**图片RecyclerView*/
    private RecyclerView rv_pic;
    /**文件夹列表父布局*/
    private LinearLayout ll_folder;
    /**文件夹列表*/
    private RecyclerView rv_folder;
    /** 文件夹适配器*/
    private ImageFolderAdapter mImageFolderAdapter;
    /** 图片列表适配器*/
    private ImageListAdapter imageAdapter;
    /**所有图片文件夹布局*/
    private LinearLayout folderLayout;
    /**文件夹名称*/
    private TextView folderName;
    /** 照相路径*/
    private String cameraPath;
    /**拍照文件*/
    public File cameraFile;
    /** 显示的大图*/
    private XCViewPagerFragment mXCViewPagerFragment;
    /**是否正在预览*/
    private boolean isPreviewing = false;
    /** 文件夹布局是否显示*/
    private boolean isFolderShow =false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yy_l_activity_select_imgs);
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            cameraPath = savedInstanceState.getString(BUNDLE_CAMERA_PATH);
        }
        new LocalMediaLoader(this, LocalMediaLoader.TYPE_IMAGE).loadAllImage(new LocalMediaLoader.LocalMediaLoadListener() {

            @Override
            public void loadComplete(List<LocalMediaFolder> folders) {
                mImageFolderAdapter.bindFolder(folders);
                List<LocalMedia> defaultImages = folders.get(0).getImages();
                //默认显示相机胶卷的图片
                String cameraPicPath = UtilFile.getSystemCameraPath();
                if (!UtilString.isBlank(cameraPicPath)) {
                    int index = 0;
                    for (LocalMediaFolder folder : folders) {
                        if (!UtilString.isBlank(folder.getPath()) && folder.getPath().equals(cameraPicPath)) {
                            defaultImages = folder.getImages();
                            mImageFolderAdapter.checkedIndex = index;
                            folderName.setText(folder.getName());
                            break;
                        }
                        index++;
                    }
                }
                imageAdapter.bindImages(defaultImages);
                rv_pic.smoothScrollToPosition(0);
            }
        });

    }

    /**
     * created by songxin,date：2017-4-10,about：bi,begin
     */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YY_SelectImgsActivity.class);
    }

    /**
     * created by songxin,date：2016-4-10,about：bi,end
     */

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "相机胶卷");
        xc_id_model_titlebar.setTitleLeft(true, null);
        xc_id_model_titlebar.setTitleRight2(true, -1, "取消");

        rl_select_folder = getViewById(R.id.rl_select_folder);
        tv_doneText = getViewById(R.id.tv_doneText);
        previewText = getViewById(R.id.preview_text);
        folderLayout = getViewById(R.id.folder_layout);
        folderName = getViewById(R.id.folder_name);
        rv_pic = getViewById(R.id.rv_pic);
        ll_folder = getViewById(R.id.ll_folder);
        rv_folder = getViewById(R.id.rv_folder);

        maxSelectNum = getIntent().getIntExtra(EXTRA_MAX_SELECT_NUM, 9);
        selectMode = getIntent().getIntExtra(EXTRA_SELECT_MODE, MODE_MULTIPLE);
        showCamera = getIntent().getBooleanExtra(EXTRA_SHOW_CAMERA, true);
        enablePreview = getIntent().getBooleanExtra(EXTRA_ENABLE_PREVIEW, true);
        enableCrop = getIntent().getBooleanExtra(EXTRA_ENABLE_CROP, false);
        showFolders = getIntent().getBooleanExtra(EXTRA_SHOW_FOLDERS, true);

        if (selectMode == MODE_MULTIPLE) {
            tv_doneText.setText(getString(R.string.select_imgs_done, "0", maxSelectNum + ""));
        } else {
            tv_doneText.setText("完成");
            tv_doneText.setClickable(false);
            tv_doneText.setTextColor(getResources().getColor(R.color.c_login_text_bg));
        }

        UtilViewShow.setGone(showFolders, rl_select_folder);

        imageAdapter = new ImageListAdapter(this, rv_pic, maxSelectNum, selectMode,
                showCamera, enablePreview);
        rv_pic.setHasFixedSize(true);
        rv_pic.addItemDecoration(new SelectImgsItemDecoration(this));
        rv_pic.setLayoutManager(new GridLayoutManager(this, spanCount));
        rv_pic.setAdapter(imageAdapter);

        mImageFolderAdapter = new ImageFolderAdapter(this);
        rv_folder.addItemDecoration(new FolderItemDecoration(this));
        rv_folder.setLayoutManager(new LinearLayoutManager(this));
        rv_folder.setAdapter(mImageFolderAdapter);
    }

    @Override
    public void listeners() {
        xc_id_model_titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        folderLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFolderShow) {
                    dismissFolder();
                    isFolderShow = false;
                } else {
                    if(!isPreviewing){
                        showFloder();
                        isFolderShow = true;
                    }
                }
            }
        });
        imageAdapter.setOnImageSelectChangedListener(new ImageListAdapter.OnImageSelectChangedListener() {
            @Override
            public void onChange(List<LocalMedia> selectImages) {
//                boolean hadSelectImg = selectImages.size() > 0;
//                previewText.setEnabled(hadSelectImg);
                //多选才会出现完成和预览按钮
                if (selectMode == MODE_MULTIPLE) {
                    tv_doneText.setText(getString(R.string.select_imgs_done, String.valueOf(selectImages.size()), maxSelectNum + ""));
//                    previewText.setText(getString(R.string.select_imgs_preview, selectImages.size()));
                } else {
                    if (selectImages.size() > 0) {
                        tv_doneText.setClickable(true);
                        tv_doneText.setTextColor(getResources().getColor(R.color.c_e2231a));
                    } else {
                        tv_doneText.setClickable(false);
                        tv_doneText.setTextColor(getResources().getColor(R.color.c_login_text_bg));
                    }
                }

            }

            @Override
            public void onTakePhoto() {
                startCamera();
            }

            @Override
            public void onPictureClick(LocalMedia media, int position) {
                if (enablePreview) {
//                    startPreview(position);
                    previewImage(position);
                } else if (enableCrop) {
                    startCrop(media.getPath());
                } else {
                    onSelectDone(media.getPath());
                }
            }
        });
        tv_doneText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isPreviewing){
                    onSelectDone(imageAdapter.getSelectedImages());
                }
            }
        });
        //文件夹切换
        mImageFolderAdapter.setOnItemClickListener(new ImageFolderAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(String name, List<LocalMedia> images) {
                dismissFolder();
                isFolderShow = false;
                //绑定切换到新的文件夹下的图片
                imageAdapter.bindImages(images);
                rv_pic.smoothScrollToPosition(0);
                folderName.setText(name);
            }
        });
        previewText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startPreview(0);
            }
        });
        ll_folder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isFolderShow){
                    isFolderShow = false;
                    dismissFolder();
                }
            }
        });
    }


    @Override
    public void onNetRefresh() {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK) {
            return;
        }
        //照相的回调
        if (requestCode == REQUEST_CAMERA) {
            if (cameraFile == null) {
                shortToast("获取图片失败");
                return;
            }
            if (enableCrop) {
                //裁剪
                startCrop(cameraPath);
            } else {
                onSelectDone(cameraPath);
            }
            //裁剪的回调
        } else if (requestCode == YY_SelectImgsActivity.REQUEST_CROP) {
            if (data != null) { // 加入data不等于空,即可以去到bitmap
                File cropFile = getCropFile(data);
                onSelectDone(cropFile);
            }
        }

    }

    /**
     * 显示文件夹列表
     */
    private void showFloder(){
        ll_folder.setVisibility(View.VISIBLE);
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.activity_open_up);
        rv_folder.startAnimation(animation);
    }

    /**
     * 隐藏文件夹列表
     */
    private void dismissFolder(){
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.activity_close_down);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                ll_folder.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        rv_folder.startAnimation(animation);
    }


    /**
     * 这里获得裁剪后 图片数据，
     *
     * @param data 按照预定规格对图片进行大小700*700以及显示质量90%的调整。目的降低OOM
     */
    public File getCropFile(Intent data) {
        Bundle extras = data.getExtras();
        if (extras == null) {
            return null;
        }
        File file = UtilFile.createCROPFile();
        Bitmap bitmap = extras.getParcelable("data");
        // 保存到本地
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(file);
            bitmap = Bitmap.createScaledBitmap(bitmap, 700, 700, true);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                    if (null != bitmap) {
                        bitmap.recycle();
                        bitmap = null;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return file;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString(BUNDLE_CAMERA_PATH, cameraPath);
    }

    /**
     * 拍照取图
     */
    private void startCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) == null) {
            shortToast("您的手机没拍照功能");
            return;
        }

        cameraFile = UtilFile.createCameraFile();
        cameraPath = cameraFile.getAbsolutePath();
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cameraFile));
        cameraIntent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
        startActivityForResult(cameraIntent, REQUEST_CAMERA);
    }

    /**
     * 点击预览
     *
     * @param position
     */
    public void previewImage(int position) {
        List<String> urlList = new ArrayList<String>();
        List<LocalMedia> allImages = imageAdapter.getImages();
        //被点击图片的路径
        String clickImgPath = allImages.get(position).getPath();
        clickImgPath = "file://" + clickImgPath;
        if (mXCViewPagerFragment == null) {
            mXCViewPagerFragment = new XCViewPagerFragment();
            mXCViewPagerFragment.setDefaultSelectedIndex(0);
        }
        ArrayList<String> list = new ArrayList<>();
        list.add(clickImgPath);
        mXCViewPagerFragment.setData(list);
        mXCViewPagerFragment.setIsShowIndex(false);
        mXCViewPagerFragment.setOnImageClickListener(new XCViewPagerFragment.OnImageClickListener() {
            @Override
            public void onImageClickListener(int position) {
                if (mXCViewPagerFragment != null) {
                    removeFragment();
                    isPreviewing = false;
                }
            }
        });
        mXCViewPagerFragment.setOnLoadImageListener(new XCViewPagerFragment.OnLoadImage() {
            @Override
            public void onLoadImage(ImageView imageview, String url) {
                XCApplication.displayImage(url, imageview, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_photo_default));
            }
        });
        addFragment();
    }

    /**
     * 禁止添加移除Fragment的动画，除非能解决以下问题
     * 当对一个Fragment进行移除添加频繁以及够快的时候，如果移除动画没有执行完毕就进行再次添加会出现以下错误:
     * java.lang.IllegalStateException: No host
     */
    private void removeFragment() {
        if (base_fm.isDestroyed()){
            /* 参考链接:https://blog.csdn.net/jhope/article/details/53426014
             * Returns true if the final {@link android.app.Activity#onDestroy() Activity.onDestroy()}
             * call has been made on the FragmentManager's Activity, so this instance is now dead.
             */
            return;
        }
        FragmentTransaction ft = base_fm.beginTransaction();
//        ft.setCustomAnimations(R.anim.fragment_scale_in, R.anim.fragment_scale_out);
        ft.remove(mXCViewPagerFragment);
        ft.commitAllowingStateLoss();
        base_fm.executePendingTransactions();
    }

    private void addFragment() {
        if(!isPreviewing){
            isPreviewing = true;
            FragmentTransaction ft = base_fm.beginTransaction();
            ft.setCustomAnimations(R.anim.fragment_scale_in, R.anim.fragment_scale_out);
            ft.add(R.id.xc_id_model_layout, mXCViewPagerFragment, mXCViewPagerFragment.getClass().getSimpleName());
            ft.commitAllowingStateLoss();
            base_fm.executePendingTransactions();
        }
    }

    /**
     * 预览选中的图片
     *
     * @param position 被点击图片在所有图片中的索引
     */
    public void startPreview(int position) {
        List<String> urlList = new ArrayList<String>();
        List<LocalMedia> allImages = imageAdapter.getImages();
        List<LocalMedia> selectedImgs = imageAdapter.getSelectedImages();

        //被点击图片的路径
        String clickImgPath = allImages.get(position).getPath();
        //被点击图片在选中图片集合中的位置
        int clickIndex = 0;
        int selectIndex = 0;
        for (LocalMedia selectedImg : selectedImgs) {
            urlList.add("file://" + selectedImg.getPath());
            if (selectedImg.getPath().equals(clickImgPath)) {
                clickIndex = selectIndex;
            }
            selectIndex++;
        }
        XC_ChatImageShowActivity.showPic(this, clickIndex, urlList);
    }

    /**
     * 裁剪
     *
     * @param path 图片路径
     */
    public void startCrop(String path) {
        try {
            File file = new File(path);
            Uri uri = Uri.fromFile(file);
            Intent intent = new Intent("com.android.camera.action.CROP");
            intent.setDataAndType(uri, "image/*");
            intent.putExtra("crop", "true");
            intent.putExtra("aspectX", 1);
            intent.putExtra("aspectY", 1);
            intent.putExtra("outputX", 150);
            intent.putExtra("outputY", 150);
            intent.putExtra("return-data", true);
            startActivityForResult(intent, REQUEST_CROP);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "您没有相册功能，此功能不能正常进行！", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 多选模式的选择图片完成
     *
     * @param medias 被选中的媒体
     */
    public void onSelectDone(List<LocalMedia> medias) {
        if (medias == null || medias.size() == 0) {
            shortToast("请选择图片");
            return;
        }
        ArrayList<File> imgFiles = new ArrayList<>();
        for (LocalMedia media : medias) {
            //未处理前原图片
            File imgFile = new File(media.getPath());
            //过滤未异步加载完成就被点击异常情况
            if (imgFile != null && imgFile.length() > 0) {
                imgFiles.add(imgFile);
            }
        }
        onResult(imgFiles);
    }

    /**
     * 单个图片路径选择图片完成
     *
     * @param path
     */
    public void onSelectDone(String path) {
        ArrayList<File> imgFiles = new ArrayList<>();
        //未处理前原图片
        File imgFile = new File(path);
        //过滤未异步加载完成就被点击异常情况
        if (imgFile != null && imgFile.length() > 0) {
            imgFiles.add(imgFile);
        }
        onResult(imgFiles);
    }

    /**
     * 图片选择完成
     *
     * @param imgFile
     */
    public void onSelectDone(File imgFile) {
        ArrayList<File> imgFiles = new ArrayList<>();
        //未处理前原图片
        //过滤未异步加载完成就被点击异常情况
        if (imgFile != null && imgFile.length() > 0) {
            imgFiles.add(imgFile);
        }
        onResult(imgFiles);
    }

    /**
     * 回调选择的图片信息给请求页面。（回传的是原图片路径，最终确定上传前再进行压缩、生成小图片处理）
     *
     * @param imgFiles 原图片路径集合
     */
    public void onResult(ArrayList<File> imgFiles) {
        if (selectMode == MODE_MULTIPLE) {
            setResult(RESULT_OK, new Intent().putExtra(REQUEST_OUTPUT, imgFiles));
        } else {
            setResult(RESULT_OK, new Intent().putExtra(REQUEST_OUTPUT, imgFiles.get(0)));
        }
        finish();
    }

    @Override
    public void onBackPressed() {
        if (isPreviewing) {
            removeFragment(mXCViewPagerFragment);
            isPreviewing = false;
            return;
        }
        if(isFolderShow){
            isFolderShow = false;
            dismissFolder();
            return;
        }
        super.onBackPressed();
    }

    @Override
    public void finish() {
        if(isFolderShow){
            isFolderShow = false;
            dismissFolder();
            return;
        }
        super.finish();
    }
}
