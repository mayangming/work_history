package com.qlk.ymz.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.XD_CaseRecipeDetailActivity;
import com.qlk.ymz.activity.XL_PatientInfoAActivity;
import com.qlk.ymz.adapter.CaseDetailAdapter;
import com.qlk.ymz.adapter.ImageAdapter;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.model.record.ImgListBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.view.WaterMarkBg;
import com.qlk.ymz.view.WatermarkDecoration;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2018/6/25.
 * v2.19 病历详情fragment
 */

public class XD_CaseDetailFragment extends DBFragment {
    /** 病历布局*/
    private RecyclerView rv_content;
    /** 患者姓名*/
    private TextView tv_patient_name;
    /** 患者年龄*/
    private TextView tv_patient_age;
    /** 患者性别*/
    private TextView tv_patient_sex;
    /** 时间*/
    private TextView tv_time;

    /** 医生填写部分*/
    private LinearLayout ll_doctor_edit;
    /** 主诉布局*/
    private LinearLayout ll_suit;
    /** 主诉*/
    private TextView tv_suit;
    /** 既往史布局*/
    private LinearLayout ll_history;
    /** 既往史*/
    private TextView tv_history;
    /** 检查指标布局*/
    private LinearLayout ll_check;
    /** 检查指标*/
    private TextView tv_check;
    /** 其它检查布局*/
    private LinearLayout ll_other_check;
    /** 其它检查*/
    private TextView tv_other_check;
    /** 诊断布局*/
    private LinearLayout ll_diagnosis;
    /** 诊断*/
    private TextView tv_diagnosis;
    /** 医嘱小结布局*/
    private LinearLayout ll_doctor_advice;
    /** 医嘱小结*/
    private TextView tv_doctor_advice;

    /** 图片布局*/
    private LinearLayout ll_doctor_pic;
    /** 图片列表*/
    private RecyclerView rv_doctor_pic;

    /** 医生科室*/
    private TextView tv_department;
    /** 医生姓名*/
    private LinearLayout ll_doctor_name;
    private TextView tv_doctor_name;
    /** 医院*/
    private LinearLayout ll_hospital;
    private TextView tv_hospital;
    /** 作废按钮*/
    private LinearLayout ll_invalid;
    /** 页面背景*/
    private RelativeLayout rl_bg;
    /** 引导*/
    private RelativeLayout rl_guide;

    private DrRecordVOBean mDrRecordVOBean;
    private boolean haveDoctorEdit = false;
    private YR_CommonDialog invalidDialog;//作废确认对话框
    private CaseDetailAdapter mCaseDetailAdapter;
    private WatermarkDecoration mWatermarkDecoration;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return init(inflater, R.layout.xd_fragment_case_detail);
    }

    @Override
    public void initWidgets() {
        rv_content = getViewById(R.id.rv_content);

        View headView = LayoutInflater.from(getActivity()).inflate(R.layout.xd_fragment_case_detail_head, null);
        tv_patient_name = headView.findViewById(R.id.tv_patient_name);
        tv_patient_age = headView.findViewById(R.id.tv_patient_age);
        tv_patient_sex = headView.findViewById(R.id.tv_patient_sex);
        tv_time = headView.findViewById(R.id.tv_time);

        ll_doctor_edit = headView.findViewById(R.id.ll_doctor_edit);
        ll_suit = headView.findViewById(R.id.ll_suit);
        tv_suit = headView.findViewById(R.id.tv_suit);
        ll_history = headView.findViewById(R.id.ll_history);
        tv_history = headView.findViewById(R.id.tv_history);
        ll_check = headView.findViewById(R.id.ll_check);
        tv_check = headView.findViewById(R.id.tv_check);
        ll_other_check = headView.findViewById(R.id.ll_other_check);
        tv_other_check = headView.findViewById(R.id.tv_other_check);
        ll_diagnosis = headView.findViewById(R.id.ll_diagnosis);
        tv_diagnosis = headView.findViewById(R.id.tv_diagnosis);
        ll_doctor_advice = headView.findViewById(R.id.ll_doctor_advice);
        tv_doctor_advice = headView.findViewById(R.id.tv_doctor_advice);

        ll_doctor_pic = headView.findViewById(R.id.ll_doctor_pic);
        rv_doctor_pic = headView.findViewById(R.id.rv_doctor_pic);

        tv_department = headView.findViewById(R.id.tv_department);
        ll_doctor_name = headView.findViewById(R.id.ll_doctor_name);
        tv_doctor_name = headView.findViewById(R.id.tv_doctor_name);
        ll_hospital = headView.findViewById(R.id.ll_hospital);
        tv_hospital = headView.findViewById(R.id.tv_hospital);

        ll_invalid = getViewById(R.id.ll_invalid);
        rl_bg = getViewById(R.id.rl_bg);
        rl_guide = getViewById(R.id.rl_guide);

        rv_content.setHasFixedSize(true);
        //设置recyclerview的布局方式
        rv_content.setLayoutManager(new LinearLayoutManager(getActivity()));
        mCaseDetailAdapter = new CaseDetailAdapter();
        mCaseDetailAdapter.addHeadView(headView);
        rv_content.setAdapter(mCaseDetailAdapter);
        mWatermarkDecoration= new WatermarkDecoration.Builder("").setColumnNum(3).builder(getActivity());
        rv_content.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                //设置水印滚动位置
                mWatermarkDecoration.setScrollY(dy);
            }
        });
    }

    @Override
    public void listeners() {
        ll_invalid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInvalidCaseDialog();
            }
        });
        rl_guide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rl_guide.setVisibility(View.GONE);
            }
        });
        initData();
    }

    /**
     * 作废病历对话框
     */
    private void showInvalidCaseDialog() {
        if(invalidDialog==null){
            invalidDialog = new YR_CommonDialog(getActivity(),"作废后患者看到的病历将打上作废水印","取消","确定") {
                @Override
                public void confirmBtn() {
                    invalidCase();
                    dismiss();
                }
            };
            invalidDialog.setTitle("确认作废该病历吗?");
            invalidDialog.setCanceledOnTouchOutside(false);
        }
        invalidDialog.show();
    }

    /**
     * 作废病历
     */
    private void invalidCase() {
        RequestParams params = new RequestParams();
        params.put("recordId", mDrRecordVOBean.getId());
        params.put("status", "1");
        XCHttpAsyn.getAsyn(getActivity(), AppConfig.getRecordUrl(AppConfig.CASE_INVALID), params, new
                XCHttpResponseHandler() {

                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (result_boolean) {
                            XCJsonBean xcJsonBean = result_bean.getList("data").get(0);
                            mDrRecordVOBean.setShowInvalidBtn("1");
                            ((DrCaseVOBean)mDrRecordVOBean.getMdicalRecordVO()).setInvalid("1");
                            ((DrCaseVOBean)mDrRecordVOBean.getMdicalRecordVO()).setInvalidTime(xcJsonBean.getString("invalidTime"));
                            ((XD_CaseRecipeDetailActivity)getActivity()).setCaseInvalid("1");
                            initData();
                            //  修改im状态
                            String invalid = ((XD_CaseRecipeDetailActivity)getActivity()).getRecipeInvalid();
                           if("0".equals(invalid)){//处方未作废
                               ((XD_CaseRecipeDetailActivity)getActivity()).setImStaus("2");
                           }else {
                               ((XD_CaseRecipeDetailActivity)getActivity()).setImStaus("3");
                           }

                            //通知患者病例页刷新诊疗记录
                            Intent intent = new Intent();
                            intent.setAction(XL_PatientInfoAActivity.NewMedicalReceiver.NEW_MEDICAL_ACTION);
                            context.sendBroadcast(intent);
                        }
                    }

                    // 对账户冻结情况的判断处理
                    public void onFinish() {
                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(getActivity(),
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

    public void initData() {
        if(mDrRecordVOBean!=null){
            tv_patient_name.setText("姓名："+mDrRecordVOBean.getName());
            tv_patient_age.setText("年龄："+mDrRecordVOBean.getAge()+mDrRecordVOBean.getAgeUnit());
            tv_time.setText("时间："+ DateUtils.DateFormat(mDrRecordVOBean.getCreateAt(), "yyyy/MM/dd HH:mm"));
            if("0".equals(mDrRecordVOBean.getGender())){
                tv_patient_sex.setText("性别：女");
            }else if("1".equals(mDrRecordVOBean.getGender())){
                tv_patient_sex.setText("性别：男");
            }
            if(!TextUtils.isEmpty(mDrRecordVOBean.getDepartment())){
                tv_department.setVisibility(View.VISIBLE);
                tv_department.setText("科室："+mDrRecordVOBean.getDepartment());
            }
            DrCaseVOBean drCaseVOBean = (DrCaseVOBean) mDrRecordVOBean.getMdicalRecordVO();

            if(UtilString.isAllBlank(drCaseVOBean.getMainComplaint(),drCaseVOBean.getPresentDisease())){
                ll_suit.setVisibility(View.GONE);
            }else {
                haveDoctorEdit = true;
                ll_suit.setVisibility(View.VISIBLE);
                String suitStr = "";
                if (!TextUtils.isEmpty(drCaseVOBean.getMainComplaint())) {
                    suitStr = getTrimStr("",drCaseVOBean.getMainComplaint(),"") +"\n"+
                            getTrimStr("现病史：", drCaseVOBean.getPresentDisease(),"");
                }else {
                    suitStr = getTrimStr("现病史：", drCaseVOBean.getPresentDisease(),"");
                }
                tv_suit.setText(clearEnd(suitStr));
            }
            fillDoctorEditWidget(ll_history,tv_history,drCaseVOBean.getPastHistory(),"");
            if(UtilString.isAllBlank(drCaseVOBean.getTemperature(), drCaseVOBean.getWeight(),
                    drCaseVOBean.getHeartRete(),drCaseVOBean.getDiastole(),
                    drCaseVOBean.getSystolic(),drCaseVOBean.getMoreExamin())){
                ll_check.setVisibility(View.GONE);
            }else {
                haveDoctorEdit = true;
                ll_check.setVisibility(View.VISIBLE);
                String str = getTrimStr("体温：",drCaseVOBean.getTemperature(),"度")+
                        getTrimStr("体重：", drCaseVOBean.getWeight(),"kg")+
                        getTrimStr("心率：",drCaseVOBean.getHeartRete(),"bpm")+
                        getTrimStr("收缩压：", drCaseVOBean.getSystolic(),"mmhg")+
                        getTrimStr("舒张压：",drCaseVOBean.getDiastole(),"mmhg")+
                        getTrimStr("",drCaseVOBean.getMoreExamin(),"");
                tv_check.setText(clearEnd(str));
            }
            if("1".equals(drCaseVOBean.getTemplateType())||UtilString.isAllBlank(drCaseVOBean.getAlt(), drCaseVOBean.getAst(),drCaseVOBean.getHbvDna())){
                ll_other_check.setVisibility(View.GONE);
            }else {
                haveDoctorEdit = true;
                ll_other_check.setVisibility(View.VISIBLE);
                String str = getTrimStr("谷丙转氨酶(ALT)：",drCaseVOBean.getAlt(),"IU/ml")+
                        getTrimStr("谷草转氨酶(AST)：",drCaseVOBean.getAst(),"IU/ml")+
                        getTrimStr("HBV-DNA：",drCaseVOBean.getHbvDna(),"IU/ml");
                tv_other_check.setText(clearEnd(str));
            }
            fillDoctorEditWidget(ll_diagnosis,tv_diagnosis,drCaseVOBean.getDiagnosis(),"");
            if(TextUtils.isEmpty(drCaseVOBean.getDoctorOrder())&&"2".equals(drCaseVOBean.getRevisitFalg())){
                ll_doctor_advice.setVisibility(View.GONE);
            }else {
                haveDoctorEdit = true;
                ll_doctor_advice.setVisibility(View.VISIBLE);
                String str = "";
                if("2".equals(drCaseVOBean.getRevisitFalg())){
                    str= drCaseVOBean.getDoctorOrder();
                }else {
                    if("月".equals(drCaseVOBean.getRevisitDateUnit())){
                        str= getTrimStr("下次复诊时间：",drCaseVOBean.getRevisitNumber() +"个"+drCaseVOBean.getRevisitDateUnit(),"后")+
                                getTrimStr( "", drCaseVOBean.getDoctorOrder(),"");
                    }else {
                        str= getTrimStr("下次复诊时间：",drCaseVOBean.getRevisitNumber() +drCaseVOBean.getRevisitDateUnit(),"后")+
                                getTrimStr( "", drCaseVOBean.getDoctorOrder(),"");
                    }
                }
                tv_doctor_advice.setText(clearEnd(str));
            }

            //展示医生填写信息
            if(haveDoctorEdit){
                ll_doctor_edit.setVisibility(View.VISIBLE);
            }
            //展示图片
            List<ImgListBean> imgList = drCaseVOBean.getImgList();
            fillPicWidget(ll_doctor_pic,rv_doctor_pic,imgList);

            fillDoctorEditWidget(ll_doctor_name,tv_doctor_name,UtilSP.getUserName(),"");
            fillDoctorEditWidget(ll_hospital,tv_hospital,UtilSP.getHospitalName(),"");

            if("0".equals(mDrRecordVOBean.getShowInvalidBtn())){//显示作废按钮
                ll_invalid.setVisibility(View.VISIBLE);
                if(UtilSP.isCaseGuide()){
                    rl_guide.setVisibility(View.VISIBLE);
                    UtilSP.setCaseGuide(false);
                }
            }else {
                ll_invalid.setVisibility(View.GONE);
            }
            if("1".equals(drCaseVOBean.getInvalid())){//作废背景设置
                // 设置作废背景
//                rl_bg.setBackground(new WaterMarkBg(getActivity(),drCaseVOBean.getInvalidTime(),-45));
                mWatermarkDecoration.setWaterText(drCaseVOBean.getInvalidTime());
                rv_content.addItemDecoration(mWatermarkDecoration);
            }
        }
    }

    public void setDrRecordVOBean(DrRecordVOBean drRecordVOBean) {
        mDrRecordVOBean = drRecordVOBean;
    }

    /**
     * 填写医生输入的控件
     * @param viewGroup
     * @param textView
     * @param str
     * @param unit
     */
    private void fillDoctorEditWidget(ViewGroup viewGroup, TextView textView, String str, String unit){
        if(TextUtils.isEmpty(str)){
            viewGroup.setVisibility(View.GONE);
        }else {
            haveDoctorEdit =true;
            viewGroup.setVisibility(View.VISIBLE);
            textView.setText(str+unit);
        }
    }

    /**
     * 填充图片控件
     * @param viewGroup
     * @param rv
     * @param strings
     */
    private void fillPicWidget(ViewGroup viewGroup, RecyclerView rv, List<ImgListBean> imgListBeans){
        if(imgListBeans!=null&&imgListBeans.size()>0){
            ArrayList<String> imgList = new ArrayList<>();
            final ArrayList<String> urls = new ArrayList<>();
            for(ImgListBean imgListBean:imgListBeans){
                imgList.add(imgListBean.getImgUrl());
                if(!imgListBean.getImgUrl().startsWith("http")){
                    urls.add("file://"+imgListBean.getImgUrl());
                }else {
                    urls.add(imgListBean.getImgUrl());
                }
            }
            viewGroup.setVisibility(View.VISIBLE);
            //此设置优化recyclerview
            rv.setHasFixedSize(true);
            //设置recyclerview的布局方式
            rv.setLayoutManager(new GridLayoutManager(getActivity(), 4));
            //设置适配器
            ImageAdapter imageAdapter = new ImageAdapter(getActivity(),imgList);
            imageAdapter.setOnItemClickListener(new ImageAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(int position) {
                    ToJumpHelp.toJumpChatImageShowActivity(getActivity(), urls,position);}
            });
            rv.setAdapter(imageAdapter);
        }
    }

    private String getTrimStr(String str,String values,String unit){
        String s ="";
        s +=TextUtils.isEmpty(values)? "":str+values+unit+"\n";
        return s;
    }

    private String clearEnd(String str){
        while (str.endsWith("\n")){
            str = UtilString.getStringWithoutLast(str,"\n");
        }
        return str;
    }

}
