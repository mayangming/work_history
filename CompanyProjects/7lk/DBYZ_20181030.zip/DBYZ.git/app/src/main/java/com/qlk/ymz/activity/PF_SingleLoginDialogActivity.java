package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.CheckLoginDevice;
import com.qlk.ymz.util.RoughDraftUtils;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.UtilLoginOut;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * 单设备登录对话框
 *
 * @author zhangpengfei
 * @version 2.0
 */
public class PF_SingleLoginDialogActivity extends DBActivity {
    private TextView pf_id_dialog_content;
    private TextView pf_id_dialog_query_confirm;
    public static String PUSH_ACTION = "com.ymz.sin";
    public static final String SIGLE_LOGIN = "single_login";
    private CheckLoginDevice checkLoginDevice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_single_login_dialog);
        super.onCreate(savedInstanceState);
    }

    /**
     * created by songxin,date：2016-4-23,about：bi,begin
     */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_SingleLoginDialogActivity.class);
    }

    /**
     * created by songxin,date：2016-4-23,about：bi,end
     */
    @Override
    public void initWidgets() {
        if (null != getIntent()) {
            checkLoginDevice = (CheckLoginDevice) getIntent().getSerializableExtra(SIGLE_LOGIN);
        }
        if (null == checkLoginDevice) {
            checkLoginDevice = new CheckLoginDevice();
        }
        pf_id_dialog_content = (TextView) findViewById(R.id.pf_id_dialog_content);
        pf_id_dialog_query_confirm = (TextView) findViewById(R.id.pf_id_dialog_query_confirm);
        StringBuilder builder = new StringBuilder();
        builder.append("当前账号");
        if (!UtilString.isBlank(checkLoginDevice.getLoginTime())) {
            builder.append("于");
            builder.append(checkLoginDevice.getLoginTime());
        }
        if (!UtilString.isBlank(checkLoginDevice.getLoginAddr())) {
            builder.append("于");
            builder.append(checkLoginDevice.getLoginAddr());
        }
        if (!UtilString.isBlank(checkLoginDevice.getModel())) {
            builder.append("使用");
            builder.append(checkLoginDevice.getModel());
            builder.append("设备");
        }
        builder.append("登录。若非本人操作，你的登录密码可能已经泄漏，请及时更改密码。紧急情况请致电客服热线");
        String phone = "<a href='tel:%@'><font  size=16 color='#2c89f5'>%@</font></a>";
        phone = phone.replace("%@", GlobalConfigSP.getCustomerServPhone());
        builder.append(phone);
        pf_id_dialog_content.setText(Html.fromHtml(builder.toString()));
        pf_id_dialog_content.setMovementMethod(LinkMovementMethod.getInstance());
        UtilLoginOut.loginOut(this);
        RoughDraftUtils.clearRoughDraft();
    }

    @Override
    public void listeners() {
        pf_id_dialog_query_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PF_SingleLoginDialogActivity.this, LoginAndRegisterActivity.class);
                startActivity(intent);
                if (getApplication() instanceof XCApplication) {
                    ((XCApplication) getApplication()).finishAllActivity();
                }
                finish();
            }
        });
    }


    @Override
    public void onBackPressed() {
    }

    @Override
    public void onNetRefresh() {

    }
}
