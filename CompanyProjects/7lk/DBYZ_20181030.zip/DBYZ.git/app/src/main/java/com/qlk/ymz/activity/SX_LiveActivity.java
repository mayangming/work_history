package com.qlk.ymz.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.VideoFinishBean;
import com.qlk.ymz.parse.Parse2VideoFinishBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.tencent.TIMCustomElem;
import com.tencent.TIMMessage;
import com.tencent.callsdk.ILVBCallMemberListener;
import com.tencent.callsdk.ILVCallConstants;
import com.tencent.callsdk.ILVCallListener;
import com.tencent.callsdk.ILVCallManager;
import com.tencent.callsdk.ILVCallOption;
import com.tencent.ilivesdk.ILiveCallBack;
import com.tencent.ilivesdk.ILiveConstants;
import com.tencent.ilivesdk.core.ILiveLoginManager;
import com.tencent.ilivesdk.view.AVRootView;
import com.tencent.ilivesdk.view.AVVideoView;
import com.tencent.qcloud.presenters.LoginHelper;
import com.tencent.qcloud.utils.Constants;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilBroadcast;
import com.xiaocoder.android.fw.general.util.UtilMedia;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * SX_LiveActivity
 * 医生视频页面
 * @author songxin on 2016/7/20.
 * @version 2.6.0
 */
public class SX_LiveActivity extends DBActivity implements ILVCallListener, ILVBCallMemberListener {
    /** TAG*/
    private static final String TAG = SX_LiveActivity.class.getSimpleName();
    /** 静态常量*/
    private static final int UPDATE_WALL_TIME_TIMER_TASK = 1;
    /** 摄像头转换*/
    private ImageView camera_change;
    /** 视频时间显示*/
    private TextView broadcasting_time;
    /** 视频退出*/
    private ImageView live_back;
    /** 主播不在提示布局*/
    private LinearLayout ll_host_leave;
    /** 直播负责显示的surfaceView，加载视频的控件*/
    private AVRootView avRootView;
    /** 媒体播放器*/
    private MediaPlayer mediaPlayer;
    /** 是否继续播放音频*/
    public boolean isContinue = true;
    /** 开启视频返回的ID */
    private String videoDurationId = "";
    /** 患者id */
    private String patientId = "";
    /** 视频预约id */
    private String reservationId = "";
    /** 网络监听广播*/
    private NetChangeReceiver netChangeReceiver;
    /** 网络切换dialog */
    private ConfirmDialog mNetChangeDialog;
    private TextView sx_id_cancel_button;
    private TextView sx_id_confirm_button;
    private TextView sx_id_custom_text;
    /** 视频时间*/
    private String formatTime;
    private long mSecond = 0;
    private int mCurCameraId = ILiveConstants.FRONT_CAMERA;
    private int mCallId = 0;
    /** 计时器*/
    private VideoTimerTask mVideoTimerTask;
    /** Timer*/
    private Timer mVideoTimer;
    private boolean bFirstRender = true;
    /** 是否主动退出*/
    private boolean isActiveExit = false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //不锁屏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        //去掉信息栏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //载入页面布局
        setContentView(R.layout.sx_l_activity_live);
        //执行父类onCreate中方法
        super.onCreate(savedInstanceState);
        //初始化MediaPlayer
        mediaPlayer = new MediaPlayer();
        //数据初始化
        initData();
        //时间显示位置
        broadcasting_time.setText("等待对方接听...");
        //初始化网络切换dialog
        initDialog();
        //网络状态变更广播注册
        netChangeReceiver = new NetChangeReceiver();
        UtilBroadcast.myRegisterReceiver(this, 1000, ConnectivityManager.CONNECTIVITY_ACTION, netChangeReceiver);
        UtilBroadcast.myRegisterReceiver(this, 1000, Constants.ACTION_TENCENT_IM_LOGIN_SUCCESS, netChangeReceiver);
        UtilBroadcast.myRegisterReceiver(this, 1000, Constants.ACTION_TENCENT_IM_LOGIN_FAIL, netChangeReceiver);
        if(UtilString.isBlank(ILiveLoginManager.getInstance().getMyUserId())){
            LoginHelper.getLoginHelper(this).imLogin("dr_" + UtilSP.getUserId(),UtilSP.getUserSig());
        }else{
            initLive();
        }
    }

    /** created by songxin,date：2016-8-16,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_LiveActivity.class);
    }
    /** created by songxin,date：2016-8-16,about：bi,end */
    /**
     * 控件初始化
     */
    @Override
    public void initWidgets() {
        camera_change = getViewById(R.id.camera_change);
        broadcasting_time = getViewById(R.id.broadcasting_time);
        live_back = getViewById(R.id.live_back);
        ll_host_leave = getViewById(R.id.ll_host_leave);
        avRootView = getViewById(R.id.av_root_view);
        avRootView.setGravity(AVRootView.LAYOUT_GRAVITY_RIGHT);
    }


    /**
     * 监听
     */
    @Override
    public void listeners() {
        camera_change.setOnClickListener(this);
        live_back.setOnClickListener(this);
    }


    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    protected void onPause() {
        super.onPause();

    }

    /**
     * 数据初始化
     */
    public void initData() {
        patientId = "pt_" + getIntent().getStringExtra("patientId");
        reservationId = getIntent().getStringExtra("reservationId");
        videoDurationId =  getIntent().getStringExtra("videoDurationId");
        // 获取callid
        mCallId = getIntent().getIntExtra("CallId", 0);
        printi("http","patientId---->"+patientId+"reservationId----->"+reservationId
        +"videoDurationId--------->"+videoDurationId+"mCallId----->"+mCallId);
    }

    /**
     * dialog初始化
     */
    private void initDialog(){
        int srceenW = this.getWindowManager().getDefaultDisplay().getWidth();
        mNetChangeDialog = new ConfirmDialog(SX_LiveActivity.this, srceenW, 180
                , R.layout.sx_l_custom_dialog, R.style.xc_s_dialog);
        mNetChangeDialog.setCanceledOnTouchOutside(false);
        sx_id_custom_text = (TextView) mNetChangeDialog.findViewById(R.id.sx_id_custom_text);
        sx_id_cancel_button = (TextView) mNetChangeDialog.findViewById(R.id.sx_id_cancel_button);
        sx_id_confirm_button = (TextView) mNetChangeDialog.findViewById(R.id.sx_id_confirm_button);
        sx_id_custom_text.setText("当前网络环境处于非Wifi环境，继续播放将消耗手机流量");
        sx_id_cancel_button.setText("退出");
        sx_id_confirm_button.setText("继续");
        sx_id_cancel_button.setOnClickListener(this);
        sx_id_confirm_button.setOnClickListener(this);
    }

    private void initLive(){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("reservationId",reservationId);
            jsonObject.put("doctor_name",UtilSP.getUserName());
            jsonObject.put("videoDurationId",videoDurationId);
            printi("http","jsonObject---------->"+jsonObject.toString());
            // 添加通话回调
            ILVCallManager.getInstance().addCallListener(this);
            ILVCallOption option = new ILVCallOption(UtilSP.getUserId())
                    .callTips("CallSDK")
                    .setMemberListener(this)
                    .customParam(jsonObject.toString())
                    .heartBeatInterval(5)
                    .setCallType(ILVCallConstants.CALL_TYPE_VIDEO);
            List<String> nums = new ArrayList<>();
            if(!UtilString.isBlank(patientId)){
                nums.add(patientId);
            }
            if(nums.size() == 0){
                shortToast("呼叫失败，请重试");
                finish();
            }
            if (0 == mCallId) { // 发起呼叫
                if (nums.size() > 1){
                    mCallId = ILVCallManager.getInstance().makeMutiCall(nums, option);
                }else{
                    printi("http","nums.get(0)---->"+nums.get(0));
                    mCallId = ILVCallManager.getInstance().makeCall(nums.get(0), option);
                    printi("http","mCallId---->"+mCallId);
                    sendC2CMessage(patientId);
                }
                startPlayVoice();
            }else {// 接听呼叫
                ILVCallManager.getInstance().acceptCall(mCallId, option);
            }
            //用户状态获取
            ILiveLoginManager.getInstance().setUserStatusListener(new ILiveLoginManager.TILVBStatusListener() {
                @Override
                public void onForceOffline(int error, String message) {
                    shortToast("呼叫失败，用户不在线");
                    finish();
                }
            });

            //初始化视频渲染view
            ILVCallManager.getInstance().initAvView(avRootView);
        }catch (Exception e){
            e.printStackTrace();
            finish();
        }
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            //摄像头切换事件
            case R.id.camera_change:{
                switchCamera();
                break;
            }
            //视频结束按钮
            case R.id.live_back:{
                onBackPressed();
                break;
            }
            //dialog 退出
            case R.id.sx_id_cancel_button:{
                if(null != mNetChangeDialog && mNetChangeDialog.isShowing()){
                    mNetChangeDialog.dismiss();
                }
                onBackPressed();
                break;
            }
            //dialog 继续
            case R.id.sx_id_confirm_button:{
                if(null != mNetChangeDialog && mNetChangeDialog.isShowing()){
                    mNetChangeDialog.dismiss();
                }
                break;
            }
            default:
                break;
        }
    }

    @Override
    public void onNetRefresh() {

    }

    /**
     * 摄像头事件
     * @param id 用户id
     * @param bEnable 开关
     */
    @Override
    public void onCameraEvent(String id, boolean bEnable) {
        printi("http","CallSDK : ["+id+"] "+(bEnable?"open":"close")+" camera");
    }

    /**
     * 麦克风事件
     * @param id 用户id
     * @param bEnable 开关
     */
    @Override
    public void onMicEvent(String id, boolean bEnable) {
        printi("http","CallSDK : ["+id+"] "+(bEnable?"open":"close")+" mic");
    }

    /**
     * 成员进出事件，这个能判断两端离开的，是主动离开还是患者先离开
     * @param id 用户id
     * @param bEnter 加入/退出
     */
    @Override
    public void onMemberEvent(String id, boolean bEnter) {
        printi("http","CallSDK : ["+id+"] "+(bEnter?"join":"exit")+" call");
        if(id.equals(patientId)){
            if(bEnter){
                //连接成功，患者进入房间，停止音频
                isContinue = false;
            }else {
                if(!isActiveExit){
                    finish();
                }
            }
        }
    }

    /**
     * 视频通话建立成功
     * @param callId
     */
    @Override
    public void onCallEstablish(int callId) {
        Log.d("http", "CallSDK : onCallEstablish->0:"+avRootView.getViewByIndex(0).getIdentifier()+"/"+avRootView.getViewByIndex(1).getIdentifier());
        avRootView.swapVideoView(0, 1);
        // 设置点击小屏切换及可拖动
        for (int i=1; i<ILiveConstants.MAX_AV_VIDEO_NUM; i++) {
            final int index = i;
            AVVideoView minorView = avRootView.getViewByIndex(i);
            if (ILiveLoginManager.getInstance().getMyUserId().equals(minorView.getIdentifier())) {
                minorView.setMirror(true);      // 本地镜像
            }
            minorView.setDragable(true);    // 小屏可拖动
            minorView.setGestureListener(new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapConfirmed(MotionEvent e) {
                    avRootView.swapVideoView(0, index);     // 与大屏交换
                    return false;
                }
            });
        }
        //连接成功，患者进入房间，开始音频
        isContinue = false;
        //开始计时
        mVideoTimer = new Timer(true);
        mVideoTimerTask = new VideoTimerTask();
        mVideoTimer.schedule(mVideoTimerTask, 1000, 1000);
        bFirstRender = false;
    }

    /**
     * 视频通话结束
     * @param callId
     * @param endResult
     * @param endInfo
     */
    @Override
    public void onCallEnd(int callId, int endResult, String endInfo) {
        if(endResult == ILVCallConstants.ERR_CALL_RESPONDER_REFUSE){
            shortToast("对方拒绝接听");
        }else if(endResult == ILVCallConstants.ERR_CALL_RESPONDER_REFUSE){
            shortToast("对方已挂断");
        }else if(endResult == ILVCallConstants.ERR_CALL_RESPONDER_LINEBUSY){
            shortToast("对方占线");
        }else if(endResult == ILVCallConstants.ERR_CALL_HANGUP){
            shortToast("会话已结束");
        }else if(endResult == ILVCallConstants.ERR_CALL_SPONSOR_TIMEOUT){
            shortToast("暂时无人接听，请稍后再试");
        }
        printi("http", "CallSDK onCallEnd->id: "+callId+"|"+endResult+"|"+endInfo);
        endVideoUploadTime(videoDurationId,mSecond * 1000 + "","1");
    }

    @Override
    public void onException(int iExceptionId, int errCode, String errMsg) {
        printi("http","CallSDK : iExceptionId :"+iExceptionId+"errCode:"+errCode+"errMsg:"+errMsg);
        shortToast("呼叫失败，视频建立发生异常，请重试");
        finish();
    }

    /**
     * 网络状态变更广播监听
     */
    private class NetChangeReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {

            String action = intent.getAction();
            if (action.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
                printi("http","============CONNECTIVITY_ACTION================");
                ConnectivityManager mConnectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = mConnectivityManager.getActiveNetworkInfo();
                if(null != netInfo && netInfo.isAvailable()) {
                    printi("http","netInfo.getType()====>"+netInfo.getType());
                    //WiFi网络
                    if(netInfo.getType()==ConnectivityManager.TYPE_WIFI){
                        if(null != mNetChangeDialog && mNetChangeDialog.isShowing()){
                            mNetChangeDialog.dismiss();
                        }
                    }else if(netInfo.getType()==ConnectivityManager.TYPE_MOBILE){
                        if(null != mNetChangeDialog && !mNetChangeDialog.isShowing()){
                            mNetChangeDialog.show();
                        }
                    }
                    //网络断开
                } else {
//                    shortToast("网络异常，请检查网络后重试。");
//                    finish();

                }
            }else if(action.equals(Constants.ACTION_TENCENT_IM_LOGIN_SUCCESS)){
                initLive();
            }else if(action.equals(Constants.ACTION_TENCENT_IM_LOGIN_FAIL)){
                shortToast("医生用户登录失败，请重试");
                finish();
            }

        }
    }



    /**
     * 时间格式化
     */
    private void updateWallTime() {
        String hs, ms, ss;

        long h, m, s;
        h = mSecond / 3600;
        m = (mSecond % 3600) / 60;
        s = (mSecond % 3600) % 60;
        if (h < 10) {
            hs = "0" + h;
        } else {
            hs = "" + h;
        }

        if (m < 10) {
            ms = "0" + m;
        } else {
            ms = "" + m;
        }

        if (s < 10) {
            ss = "0" + s;
        } else {
            ss = "" + s;
        }
        if (hs.equals("00")) {
            formatTime = ms + ":" + ss;
        } else {
            formatTime = hs + ":" + ms + ":" + ss;
        }
        broadcasting_time.setText(formatTime);
    }

    /**
     * 切换摄像头
     */
    private void switchCamera() {
        mCurCameraId = (ILiveConstants.FRONT_CAMERA==mCurCameraId) ? ILiveConstants.BACK_CAMERA : ILiveConstants.FRONT_CAMERA;
        ILVCallManager.getInstance().switchCamera(mCurCameraId);
    }
    /**
     * 记时器
     */
    private class VideoTimerTask extends TimerTask {
        public void run() {
            ++mSecond;
            mHandler.sendEmptyMessage(UPDATE_WALL_TIME_TIMER_TASK);
        }
    }


    /**
     * 消息处理
     */
    private Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                //时间刷新
                case UPDATE_WALL_TIME_TIMER_TASK:
                    updateWallTime();
                    break;
            }
            return false;
        }
    });


    /**
     * 视频结束上报时间
     * @param videoDurationId 开启视频返回的ID
     * @param openMs 视频开启时间，秒数
     * @param ringOff 1：医生 2:患者 3:网络异常
     */
    private void endVideoUploadTime(String videoDurationId,String openMs,final String ringOff){
        //发送请求
        RequestParams params = new RequestParams();
        params.put("videoDurationId", videoDurationId);
        params.put("openMs", openMs);
        params.put("ringOff", ringOff);
        params.put("token", UtilSP.getUserToken());

        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.endVideo), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){
                    //被踢出之后不弹出结束页面直接退出
                    if("5".equals(ringOff)){
                        return;
                    }
                    VideoFinishBean videoFinishBean = new VideoFinishBean();
                    Parse2VideoFinishBean parse2VideoFinishBean = new Parse2VideoFinishBean(videoFinishBean);
                    parse2VideoFinishBean.parseJson(result_bean);
                    videoFinishBean.setPatientId(patientId);
                    videoFinishBean.setReservationId(reservationId);
                    //如果是一个有效视频，跳转
                    if("0".equals(videoFinishBean.getValid())){
                        Intent intent = new Intent();
                        intent.putExtra("videoFinish",videoFinishBean);
                        intent.setClass(SX_LiveActivity.this,SX_VideoFinishActivity.class);
                        startActivity(intent);
                    }
                }
            }

            public void onFinish() {
                super.onFinish();
                finish();
            }
        });
    }


    public void sendC2CMessage(final String sendId) {
        TIMMessage msg = new TIMMessage();
        TIMCustomElem elem = new TIMCustomElem();
        elem.setDesc(UtilSP.getUserName()+"发起的视频");
        msg.addElement(elem);
        //      发送消息
        ILVCallManager.getInstance().sendC2CMessage(sendId, msg, new ILiveCallBack<TIMMessage>() {
            @Override
            public void onSuccess(TIMMessage data) {
                Log.i("http", "SendMsg ok! peer:" + sendId);
            }

            @Override
            public void onError(String module, int errCode, String errMsg) {
                Log.e("http", "send message failed. code: " + errCode + " errmsg: " + errMsg);
            }
        });
    }

    /**
     * 开启接听音频
     */
    private void startPlayVoice(){
        try {

            UtilMedia.openVoice(mediaPlayer,SX_LiveActivity.this,R.raw.wechat);

            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    if(!isContinue){
                        if (mediaPlayer != null) {
                            mediaPlayer.stop();
                            mediaPlayer.release();
                        }
                    }else{
                        UtilMedia.openVoice(mediaPlayer,SX_LiveActivity.this,R.raw.wechat);
                    }

                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        isActiveExit = true;
        ILVCallManager.getInstance().endCall(mCallId);
    }

    @Override
    protected void onDestroy() {
        //设置显示push信息
        GlobalConfigSP.setSendNotice(true);
        try {
            isContinue = false;
            if(null != mediaPlayer){
                mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
//        SxbLog.i(TAG, "================onDestroy================ ");
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mNetChangeDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        if (null != mVideoTimer) {
            mVideoTimer.purge();
            mVideoTimer.cancel();
            mVideoTimer = null;
        }
        if(null != netChangeReceiver){
            UtilBroadcast.myUnregisterReceiver(this,netChangeReceiver);
        }
        ILVCallManager.getInstance().removeCallListener(this);
        ILVCallManager.getInstance().onDestory();
        super.onDestroy();
    }
}
