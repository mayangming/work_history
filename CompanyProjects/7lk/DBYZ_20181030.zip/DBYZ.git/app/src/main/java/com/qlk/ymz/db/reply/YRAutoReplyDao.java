package com.qlk.ymz.db.reply;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import java.util.ArrayList;

/**
 * 回复信息的dao
 *
 * @author 崔毅然
 * @version 1.5.0
 */
public class YRAutoReplyDao {
    private YRAutoReplyHelper helper;

    public YRAutoReplyDao(Context context) {
        this.helper = new YRAutoReplyHelper(context);
    }

    /**
     * 获取数据库适配器对象
     * @param context 上下文对象
     * @return 数据库处理对象
     */
    public static YRAutoReplyDao getInstance(Context context) {
        return new YRAutoReplyDao(context);
    }



    /** 当前登录医生，删除不定个数的回复内容 */
    public void deleteReply(String[] ids){
        SQLiteDatabase db = helper.getWritableDatabase();
        for (int i = 0 ;i <ids.length;i++) {
            db.delete(YRAutoReplyHelper.AUTO_REPLY, YRAutoReplyHelper.ID +"=?",
                    new String[]{ids[i]});
        }
        db.close();
    }

    /** 当前登录医生，插入新的回复内容 */
    public void insertReply(YRAutoReplyModel replyModel) {
        SQLiteDatabase db = helper.getWritableDatabase();

        db.execSQL("insert into " + YRAutoReplyHelper.AUTO_REPLY +
                        " (" + YRAutoReplyHelper.CONTENT +") values (?)",
                new Object[]{replyModel.getContent()});
        db.close();
    }

    /** 查询当前登录医生回复列表
     * 仿服务器请求结果，主要为适应写好的基类 */
    public ArrayList<XCJsonBean> selectReplies(){
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = null;
        ArrayList<XCJsonBean> replyList = new ArrayList<>();
        try {
            if (db.isOpen()) {
                c = db.rawQuery("select * from " + YRAutoReplyHelper.AUTO_REPLY
                         + " order by "+YRAutoReplyHelper.ID+" desc", null);

                XCJsonBean jsonBean = null;
                if (c.getCount()> 0) {
                    while (c.moveToNext()) {
                        jsonBean = new XCJsonBean();
                        jsonBean.setString(YRAutoReplyHelper.CONTENT, c.getString(1));
                        jsonBean.setString(YRAutoReplyHelper.ID, c.getString(0));
                        replyList.add(jsonBean);
                    }
                }
            }
        } catch (Exception e) {
        } finally {
            c.close();
            db.close();
        }
        return replyList;
    }

    /** 当前登录医生，查询回复列表的第一条数据 */
    public YRAutoReplyModel selectReplyFirst(){
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = null;
        YRAutoReplyModel replyModel = new YRAutoReplyModel();
        try {
            if (db.isOpen()) {
                c = db.rawQuery("select * from " + YRAutoReplyHelper.AUTO_REPLY
                        + " order by "+YRAutoReplyHelper.ID+" desc limit 1", null);
                if (c.getCount()>0 && c.moveToNext()) {
                    replyModel.setContent(c.getString(1));
                    replyModel.setId(c.getString(0));
                }
            }
        } catch (Exception e) {
        } finally {
            c.close();
            db.close();
        }
        return replyModel;
    }

    /** 当前登录医生，将服务器获得的回复内容和本地所有信息比较，没有，则插入*/
    public void insertSelectedInfo(String content) {
        if (getSelectedInfo(content) == null) {
            YRAutoReplyModel replyModel = new YRAutoReplyModel();
            replyModel.setContent(content);
            insertReply(replyModel);
        }
    }

    /** 将服务器获得的回复内容和本地所有信息比较 */
    public XCJsonBean getSelectedInfo (String content) {
        ArrayList<XCJsonBean> replyList = selectReplies();
        if (replyList.size() > 0) {
            for (int i = 0; i < replyList.size(); i++) {
                if (replyList.get(i).getString(YRAutoReplyHelper.CONTENT).equals(content)) {
                    return replyList.get(i);
                }
            }
        }
        return null;
    }

}
