package com.qlk.ymz.db.im.chatmodel;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;
/**
 * description: 聊天Session信息，这里面保存的字段主要用于展示使用，
 *              里面的信息会存成一个json存储到数据库里面，
 *              倘若使用某个字段进行数据库增删改查，需要单独存储到数据库里面
 * autour: YM
 * date: 2017/7/5
 * version:
 */
public class ChatSession implements Serializable, Cloneable{
    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
    private String consultSourceType = "";//2--线上诊所

    public String getConsultSourceType() {
        return UtilString.f(consultSourceType);
    }

    public void setConsultSourceType(String consultSourceType) {
        this.consultSourceType = consultSourceType;
    }

    /** 是否是线上诊室 */
    public boolean isConsultRoom(){
        return getConsultSourceType().equals("2");
    }

}