package com.qlk.ymz.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.CommonPrescriptionsActivity;
import com.qlk.ymz.activity.SQ_RecommendActivity;
import com.qlk.ymz.activity.XD_RecommendedMedicationActivity;
import com.qlk.ymz.adapter.CommonRecipeAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.RecipeBean;
import com.qlk.ymz.parse.Parse2CommonRecipeBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.view.XCImageView;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;
import com.xiaocoder.ptrrefresh.XCMaterialListPinRefreshLayout;
import com.xiaocoder.ptrrefresh.XCRefreshLayout;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2017/12/12.
 * 常用处方
 */

public class XD_CommonRecipeFragment extends XD_BaseFragment implements CommonRecipeAdapter
        .CommonRecipeActionListener {
    /**
     * 添加常用处方
     */
    private XCImageView tv_creat_common_recipe;
    /**
     * 常用处方刷新列表
     */
    private XCMaterialListPinRefreshLayout mXCMaterialListPinRefreshLayout;
    /**
     * 处方列表
     */
    private ListView mListView;
    /**
     * 常用处方列表适配
     */
    private CommonRecipeAdapter mCommonRecipeAdapter;
    /**
     * 常用处方集合
     */
    private ArrayList<RecipeBean> mRecipeBeans = new ArrayList<>();
    /**
     * 宿主
     */
    private DBActivity mActivity;
    /**
     * 判断是否为推荐用药首页
     */
    private boolean isRecom = false;
    private int offset;//后台判断
    private int nextPage = 1;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return init(inflater, R.layout.xd_fragment_common_recipe);
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    public void onStart() {
        super.onStart();
        BiUtil.savePid(XD_CommonRecipeFragment.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */

    @Override
    public void initWidgets() {
        super.initWidgets();

        mActivity = (DBActivity) getActivity();

        mXCMaterialListPinRefreshLayout = getViewById(R.id.rfl_common_recipe);
        mXCMaterialListPinRefreshLayout.setBgZeroHintInfo("无常用处方数据", "", R.mipmap
                .js_d_icon_no_data);
        mXCMaterialListPinRefreshLayout.base_zero_button.setVisibility(View.VISIBLE);
        mXCMaterialListPinRefreshLayout.base_zero_button.setBackgroundResource(R.mipmap.creat_common_recipe);
        ViewGroup.LayoutParams params = mXCMaterialListPinRefreshLayout.base_zero_button.getLayoutParams();
        params.width = UtilScreen.getScreenWidthPx(mActivity) - UtilScreen.dip2px(mActivity, 40);
        params.height = params.width*80/670;

        mListView = (ListView) mXCMaterialListPinRefreshLayout.getListView();
        View headView = View.inflate(getContext(), R.layout.xd_fragment_common_recipe_head, null);
        tv_creat_common_recipe = (XCImageView) headView.findViewById(R.id.tv_creat_common_recipe);
        mListView.addHeaderView(headView);

        int itemWidth = UtilScreen.getScreenWidthPx(getContext()) - UtilScreen.dip2px(getContext(),
                10);
        mCommonRecipeAdapter = new CommonRecipeAdapter(getContext(), R.layout.xd_item_common_recipe, R.layout.xd_item_recipe_delete, itemWidth, itemWidth, null);
        mCommonRecipeAdapter.setCommonRecipeActionListener(this);
        if (mActivity.getClass().getSimpleName().equals(XD_RecommendedMedicationActivity.class
                .getSimpleName())) {
            isRecom = true;
            mCommonRecipeAdapter.setRecom(isRecom);
        }
        mListView.setAdapter(mCommonRecipeAdapter);
    }

    @Override
    public void listeners() {
        tv_creat_common_recipe.setOnClickListener(this);

        mXCMaterialListPinRefreshLayout.setOnBgZeroButtonClickToDoListener(new XCRefreshLayout.OnBgZeroButtonClickToDoListener() {
            @Override
            public void onBgZeroButtonClickToDo() {
                if (isRecom) {
                    CommonPrescriptionsActivity.launch(getContext(), "0", 3);
                } else {
                    CommonPrescriptionsActivity.launch(getContext(), "0", 1);
                }
            }
        });

        mXCMaterialListPinRefreshLayout.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {
                return false;
            }

            @Override
            public boolean canLoad() {
                return true;
            }

            @Override
            public void refresh(View view, int request_page) {
            }

            @Override
            public void load(View view, int request_page) {
                getCommonRecipeData(nextPage);
            }
        });
        getCommonRecipeData(nextPage);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_creat_common_recipe:
                if (isRecom) {
                    CommonPrescriptionsActivity.launch(getContext(), "0", 3);
                } else {
                    CommonPrescriptionsActivity.launch(getContext(), "0", 1);
                }
                break;
        }
        super.onClick(v);
    }

    @Override
    public void onNetRefresh() {
        refresData();
    }

    /**
     * 获取常用处方列表
     *
     * @param page
     */
    private void getCommonRecipeData(int page) {
        RequestParams params = new RequestParams();
        params.put("page", page);
        params.put("offset",offset);
        XCHttpAsyn.postAsyn(mActivity, AppConfig.getHostUrl(AppConfig.commonPrescriptionList), params, new
                XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        showContentLayout();
                        if (result_boolean) {
                            RecomMedicineHelper.getInstance().setUpdateCommonRecipe(false);
                            List<XCJsonBean> data = result_bean.getList("data");
                            mXCMaterialListPinRefreshLayout.setTotalPage(data.get(0).getInt("totalPages") + "");
                            offset = data.get(0).getInt("offset");
                            nextPage = data.get(0).getInt("nextPage");
                            ArrayList<RecipeBean> recipeBeans = new ArrayList<>();
                            Parse2CommonRecipeBean parse2CommonRecipeBean = new Parse2CommonRecipeBean(recipeBeans);
                            parse2CommonRecipeBean.parseJson(data.get(0));
                            mRecipeBeans.addAll(recipeBeans);
                            mXCMaterialListPinRefreshLayout.updateListAdd(recipeBeans, mCommonRecipeAdapter);
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        if(mXCMaterialListPinRefreshLayout.base_currentPage ==1){
                            showNoNetLayout();
                        }
                    }

                    // 对账户冻结情况的判断处理
                    public void onFinish() {
                        super.onFinish();
                        mXCMaterialListPinRefreshLayout.completeRefresh(result_boolean);
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(mActivity,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

    /**
     * 刷新数据
     */
    public void refresData() {
        mXCMaterialListPinRefreshLayout.resetCurrentPageAndList(mCommonRecipeAdapter);
        mRecipeBeans.clear();
        offset = 0 ;
        nextPage = 1;
        getCommonRecipeData(nextPage);
    }

    /**
     * 删除常用处方
     *
     * @param position
     */
    public void deleteRecipe(final int position) {
        RequestParams params = new RequestParams();
        params.put("id", mRecipeBeans.get(position).getId());
        XCHttpAsyn.postAsyn(mActivity, AppConfig.getHostUrl(AppConfig.deleteCommonPrescription), params,
                new XCHttpResponseHandler() {
                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        XCHttpAsyn.httpFinish();
                        if (result_boolean) {
                            mRecipeBeans.remove(position);//从集合中删除
                            mXCMaterialListPinRefreshLayout.updateListNoAdd(mRecipeBeans, mCommonRecipeAdapter);
                            if (mRecipeBeans.size() == 0) {
                                mXCMaterialListPinRefreshLayout.whichShow(0);
                            }else if(!mXCMaterialListPinRefreshLayout.isLastRequestResult()){
                                getCommonRecipeData(nextPage);
                            } else if(mRecipeBeans.size()<10 && mXCMaterialListPinRefreshLayout
                                    .base_currentPage <mXCMaterialListPinRefreshLayout.base_totalPage){
                                mXCMaterialListPinRefreshLayout.setBase_currentPage(nextPage);
                                getCommonRecipeData(nextPage);
                            }
                        }
                    }

                    // 对账户冻结情况的判断处理
                    public void onFinish() {
//                        super.onFinish();
                        if (null != result_bean && GeneralReqExceptionProcess.checkCode(mActivity,
                                getCode(),
                                getMsg())) {
                            // 接口请求业务成功时的处理
                        }
                    }
                });
    }

    @Override
    public void delete(int position) {
        deleteRecipe(position);//删除处方
    }

    @Override
    public void onItemClick(int position) {
        //进入常用处方详情
        if (mActivity.getClass().getSimpleName().equals(XD_RecommendedMedicationActivity.class
                .getSimpleName())) {
            CommonPrescriptionsActivity.launch(getContext(), mRecipeBeans.get(position), "1", 3);
        } else {
            CommonPrescriptionsActivity.launch(getContext(), mRecipeBeans.get(position), "1", 1);
        }

    }

    @Override
    public void useRecipe(int position) {//使用处方
        if (RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getList().size() > 0
                || RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getDiagnoseBeanList()
                .size() > 0) {
            showOverRecipeDialog(mRecipeBeans.get(position));
        } else {//替换药箱里的数据
            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setList
                    (mRecipeBeans.get(position).getDrugBeans());
            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setDiagnoseBeanList
                    (mRecipeBeans.get(position).getDiagnosisList());
            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setCheckInventoryInfo(true);
            SQ_RecommendActivity.launch(mActivity);
        }
    }

    /**
     * 显示覆盖处方的对话框
     *
     * @param recipeBean
     */
    private void showOverRecipeDialog(final RecipeBean recipeBean) {
        YR_CommonDialog mOverRecipeDialog = new YR_CommonDialog(mActivity,
                "当前已有编辑中的处方，使用“使用处方”功能将覆盖当前编辑中的处方，是否继续？", "取消", "继续") {
            @Override
            public void confirmBtn() {
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setList(recipeBean
                        .getDrugBeans());
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setDiagnoseBeanList
                        (recipeBean.getDiagnosisList());
                RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setCheckInventoryInfo(true);
                SQ_RecommendActivity.launch(mActivity);
                dismiss();
            }
        };
        mOverRecipeDialog.setCanceledOnTouchOutside(false);
        mOverRecipeDialog.show();
    }

}
