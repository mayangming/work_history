package com.qlk.ymz.db.im.chatmodel;

import com.xiaocoder.android.fw.general.util.UtilString;

import java.io.Serializable;

/**
 * description: 聊天消息中的相片内容
 * autour: YM
 * date: 2017/7/7
 * update:
 */

public class ChatModelPhoto implements Serializable,Cloneable{
    protected String photoLocalUri = "";//图片的本地缓存
    protected String photoHttpUri = "";//图片的网络地址
    public ChatModelPhoto(){
    }
    @Override
    protected Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
    public String getPhotoLocalUri() {
        return UtilString.f(photoLocalUri);
    }

    public void setPhotoLocalUri(String photoLocalUri) {
        this.photoLocalUri = photoLocalUri;
    }

    public String getPhotoHttpUri() {
        return UtilString.f(photoHttpUri);
    }

    public void setPhotoHttpUri(String photoHttpUri) {
        this.photoHttpUri = photoHttpUri;
    }

}