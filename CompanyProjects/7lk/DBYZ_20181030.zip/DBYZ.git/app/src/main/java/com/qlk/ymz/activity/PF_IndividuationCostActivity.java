package com.qlk.ymz.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.UtilInsertMsg2JsDb;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.UtilPackMsg;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 个性化服务费
 * @author zhangpengfei.
 * @version 1.0
 */

public class PF_IndividuationCostActivity extends DBActivity {
    /**患者信息tag*/
    public static final String PATIENT_INFO_TAG = "patientInfoTag";
    /**入口tag*/
    public static final String ENTRY_TAG = "entryTag";
    /**Gone个性化服务入口*/
    public static final String GONE_VIEW = "goneView";
    /**title*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**预览*/
    private LinearLayout pr_id_individuation_cost_preview;
    /**费用名称标题*/
    private TextView pr_id_individuation_cost_name_title;
    /**费用名称*/
    private EditText pr_id_individuation_cost_name;
    /**费用名称数量*/
    private TextView pr_id_individuation_cost_name_sum;
    /**费用价格标题*/
    private TextView pr_id_individuation_cost_price_title;
    /**费用价格*/
    private EditText pr_id_individuation_cost_price;
    /**费用介绍*/
    private EditText pr_id_individuation_cost_introduce;
    /**立即推荐*/
    private TextView pr_id_individuation_cost_recommend;
    /**患者信息*/
    private XC_ChatModel chatModel;
    private WebView pr_id_individuation_cost_explain_web;
    /**表示那个位置调整进来的 1 聊天信息  2 底部功能  默认底部功能*/
    private int type = 2;
    private int nameCount = 50;
    /**我的常用服务*/
    private TextView lt_id_individuation_cost_my_usual_service;
    /**我的常用服务入口  1是显示，0是隐藏*/
    private String goneView = "1";
    private boolean isUpdateData;
    /**存储页面*/
    public static ArrayList<Activity> listSave = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_activity_individuation_cost);
        super.onCreate(savedInstanceState);

    }

    /** created by songxin,date：2017-4-10,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_IndividuationCostActivity.class);
    }

    /** created by songxin,date：2016-4-10,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @SuppressLint({"AddJavascriptInterface", "SetJavaScriptEnabled"})
    @Override
    public void initWidgets() {
        listSave.add(this);
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        pr_id_individuation_cost_preview = getViewById(R.id.pr_id_individuation_cost_preview);
        pr_id_individuation_cost_name_title = getViewById(R.id.pr_id_individuation_cost_name_title);
        pr_id_individuation_cost_name = getViewById(R.id.pr_id_individuation_cost_name);
        pr_id_individuation_cost_price_title = getViewById(R.id.pr_id_individuation_cost_price_title);
        pr_id_individuation_cost_price = getViewById(R.id.pr_id_individuation_cost_price);
        pr_id_individuation_cost_introduce = getViewById(R.id.pr_id_individuation_cost_introduce);
        pr_id_individuation_cost_recommend = getViewById(R.id.pr_id_individuation_cost_recommend);
        pr_id_individuation_cost_name_sum = getViewById(R.id.pr_id_individuation_cost_name_sum);
        pr_id_individuation_cost_explain_web = getViewById(R.id.pr_id_individuation_cost_explain_web);
        //add by litao 2017-12-12
        lt_id_individuation_cost_my_usual_service = getViewById(R.id.lt_id_individuation_cost_my_usual_service);
        WebSettings wSettings = pr_id_individuation_cost_explain_web.getSettings();
        wSettings.setJavaScriptEnabled(true);
        wSettings.setBuiltInZoomControls(true);
        wSettings.setDisplayZoomControls(false);
        wSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); // 不进行缓存，总是使用网络数据
        String url = GlobalConfigSP.getHtml5NativePath() + "/html/" + UtilNativeHtml5.INDIVIDUATION_COST_EXPLAIN;
        if (UtilFiles.fileIsExists(url)){
            url = GlobalConfigSP.getHtml5NativePath() + "/html/" + UtilNativeHtml5.INDIVIDUATION_COST_EXPLAIN;
            pr_id_individuation_cost_explain_web.loadUrl("file://" + url);
        }
        pr_id_individuation_cost_explain_web.setBackgroundColor(0);
        // add by xjs on 20151014 20:56 start
        // 增加web与native交互的代码
        pr_id_individuation_cost_explain_web.addJavascriptInterface(NativeHtml5.newInstance(this), JS_WebViewActivity.JS_INTERACTION_NAME);
        pr_id_individuation_cost_name_title.setText(Html.fromHtml("产品或服务名称<font color = '#e2231a'>*</font> "));
        pr_id_individuation_cost_price_title.setText(Html.fromHtml("价格(元)<font color = '#e2231a'>*</font> "));
        xc_id_model_titlebar.setTitleLeft(true, "");
        xc_id_model_titlebar.setTitleCenter(true, "个性化服务费");
        xc_id_model_titlebar.setTitleRight2(true, 0, "功能介绍");
        //名称长度
        nameCount = GlobalConfigSP.getLimitValue(GlobalConfigSP.CUSTOM_CHARGE_NAME, 0, 50);
        pr_id_individuation_cost_name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(nameCount)});
        if (null != getIntent() && null != getIntent().getSerializableExtra(PATIENT_INFO_TAG)){
            chatModel = (XC_ChatModel) getIntent().getSerializableExtra(PATIENT_INFO_TAG);
            type = getIntent().getIntExtra(ENTRY_TAG, 2);
            goneView = getIntent().getStringExtra(GONE_VIEW);
            setViewData();
        }else{
            chatModel = new XC_ChatModel();
        }
        if (type == 1){
            pr_id_individuation_cost_recommend.setText("再次推荐"+chatModel.getUserPatient().getPatientDisplayName());
        }else{
            pr_id_individuation_cost_recommend.setText("立即推荐给" + chatModel.getUserPatient().getPatientDisplayName());
        }
        //个性化服务页面进入需要Gone掉入口
        if("0".equals(goneView)){
            lt_id_individuation_cost_my_usual_service.setVisibility(View.GONE);
        }

        //设置简介的长度
        int maxIntroduceCount = GlobalConfigSP.getLimitValue(GlobalConfigSP.CUSTOM_CHARGE_SYNOPSIS, 0, 1000);
        pr_id_individuation_cost_introduce.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxIntroduceCount)});
    }


    private  void  setViewData(){
        if(!TextUtils.isEmpty(chatModel.getChatModelCustomAdvisory().getCustomAdvisoryName())
             &&!TextUtils.isEmpty(chatModel.getChatModelCustomAdvisory().getCustomPrice())){
            pr_id_individuation_cost_name.setText(UtilString.f(chatModel.getChatModelCustomAdvisory().getCustomAdvisoryName()));
            pr_id_individuation_cost_name_sum.setText(UtilString.f(chatModel.getChatModelCustomAdvisory().getCustomAdvisoryName()).length() + "/" + nameCount);
            pr_id_individuation_cost_introduce.setText(UtilString.f(chatModel.getChatModelCustomAdvisory().getCustomProductDesc()));
            long price = UtilString.toLong(chatModel.getChatModelCustomAdvisory().getCustomPrice())/100;
            pr_id_individuation_cost_price.setText(price + "");
            saveInfo(chatModel.getChatModelCustomAdvisory().getCustomAdvisoryName(), price + "", chatModel.getChatModelCustomAdvisory().getCustomProductDesc());
        }else {
            saveInfo("", "", "");
        }

    }




    /**
     * 保存页面信息
     * @param productName 名称
     * @param price 价格
     * @param synopsis 简介
     */
    private void saveInfo(String productName, String price, String synopsis) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.putOpt("productName", UtilString.f(productName));
            jsonObject.putOpt("synopsis", UtilString.f(synopsis));
            jsonObject.putOpt("price", UtilString.f(price));
            GlobalConfigSP.setSaveIndividuationCostInfo(jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void listeners() {
        pr_id_individuation_cost_recommend.setOnClickListener(this);
        pr_id_individuation_cost_preview.setOnClickListener(this);
        lt_id_individuation_cost_my_usual_service.setOnClickListener(this);
        //功能介绍
        xc_id_model_titlebar.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UtilNativeHtml5.toJumpNativeH5(PF_IndividuationCostActivity.this, UtilNativeHtml5.PERSONALIZED_SERVE);
            }
        });
        //费用名称
        pr_id_individuation_cost_name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {


            }

            @Override
            public void afterTextChanged(Editable s) {
                //费用名称输入数量
                pr_id_individuation_cost_name_sum.setText(s.length() + "/" + nameCount);
            }
        });

        pr_id_individuation_cost_explain_web.setWebViewClient(new WebViewClient(){
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                pr_id_individuation_cost_explain_web.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.pr_id_individuation_cost_recommend:
                if(type == 1){
                    // created by songxin,date：2017-4-10,about：saveInfo,begin
                    BiUtil.saveBiInfo(PF_IndividuationCostActivity.class, "2", "128", "pr_id_individuation_cost_recommend_again","", false);
                    // created by songxin,date：2017-4-10,about：saveInfo,end
                }else{
                    // created by songxin,date：2017-4-10,about：saveInfo,begin
                    BiUtil.saveBiInfo(PF_IndividuationCostActivity.class, "2", "128", "pr_id_individuation_cost_recommend","", false);
                    // created by songxin,date：2017-4-10,about：saveInfo,end
                }
                //立即推荐
                requestRecommend();
                break;
            case R.id.pr_id_individuation_cost_preview:
                //预览
                saveInfo(pr_id_individuation_cost_name.getText().toString().trim(),
                        UtilString.toLong(pr_id_individuation_cost_price.getText().toString().trim()) + "",
                        pr_id_individuation_cost_introduce.getText().toString().trim());
                UtilNativeHtml5.toJumpNativeH5(this, UtilNativeHtml5.SERVICE_CHARGE);
                break;
            case R.id.lt_id_individuation_cost_my_usual_service:
                //跳转到我的常用服务页
                if(!TextUtils.isEmpty(pr_id_individuation_cost_name.getText().toString())||!TextUtils.isEmpty(pr_id_individuation_cost_price.getText().toString())||!TextUtils.isEmpty(pr_id_individuation_cost_introduce.getText().toString())){
                    isUpdateData = true;
                }else{
                    isUpdateData = false;
                }
                ToJumpHelp.toJumpUsualServiceActivity(PF_IndividuationCostActivity.this,chatModel,CommonConfig.INDIVIDUATION_COST_REQUESED_CODE,isUpdateData);
                break;
                default:
                    break;
        }
    }

    /**
     * 请求推荐
     */
    private void requestRecommend(){
        String costName = pr_id_individuation_cost_name.getText().toString().trim();
        String introduce = pr_id_individuation_cost_introduce.getText().toString().trim();
        String showPrice = pr_id_individuation_cost_price.getText().toString().trim();
        if (UtilString.isBlank(costName)){
            shortToast("请填写名称信息");
            return;
        }
        int maxprice = GlobalConfigSP.getLimitValue(GlobalConfigSP.CUSTOM_CHARGE_AMOUNT, 0, 5000000);
        int minprice = GlobalConfigSP.getLimitValue(GlobalConfigSP.CUSTOM_CHARGE_AMOUNT, 1, 1);
        long price = UtilString.toLong(showPrice) * 100; //元转分
        if (UtilString.isBlank(showPrice) || minprice > price){
            shortToast("请填写价格信息");
            return;
        }else if (price > maxprice){
            shortToast("单笔最大限额为"+ (UtilString.toInt(maxprice) / 100) +"元");
            return;
        }else if (StringUtils.containsEmoji(costName)){
            shortToast("请勿在名称处输入表情");
            return;
        }else if (StringUtils.containsEmoji(introduce)){
            shortToast("请勿在简介处输入表情");
            return;
        }
        //add by songxin,date：2018-3-29,about：GrowingIO banner track,begin
        Map<String,String> track = new HashMap<>();
        track.put("patientID", chatModel.getUserPatient().getPatientId());
        track.put("serviceID", costName);
        track.put("fee", price+"");
        GrowingIOUtil.track("patientServiceConsultation", track);
        //add by songxin,date：2018-3-29,about：GrowingIO banner track,end

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.putOpt("productId", chatModel.getUserPatient().getPatientId());
            jsonObject.putOpt("productName", costName);
            jsonObject.putOpt("synopsis", UtilString.f(introduce));
            jsonObject.putOpt("price", price);
            jsonObject.putOpt("advisImageUrl", "");
            //如果点击推荐 需要返回的是聊天页面
            XC_ChatModel chatModel2 = UtilPackMsg.packIndividuationMsg(jsonObject.toString(),chatModel);
            requestSendMessage(chatModel2,UtilIMCreateJson.getImJson(chatModel2));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    /**
     * 发送消息接口
     *
     * @param model   发送的那条信息model，发送成功和失败都会更新该model里的一些值
     * @param message 给服务器的json串
     */
    private void requestSendMessage(final XC_ChatModel model, final String message) {
        RequestParams params = new RequestParams();
        params.put("message", message);
        XCHttpAsyn.postAsyn(true, this, AppConfig.getChatUrl(AppConfig.chat_sendMessage), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);

                if (result_boolean) {
                    for( Activity activity:listSave){
                        activity.finish();
                    }
                    model.setSessionBeginTime(result_bean.getList("data").get(0).getString("beginTime"));
                    model.setMessageId(result_bean.getList("data").get(0).getString("messageId"));
                    model.setMsgTime(result_bean.getList("data").get(0).getString("sendTime"));
                    model.setSessionId(result_bean.getList("data").get(0).getString("sessionId"));
                    model.getChatSession().setConsultSourceType(result_bean.getList("data").get(0).getString("consultSourceType"));
                    model.setSessionJson(UtilIMCreateJson.createSessionJson(model));
                    XCChatModelDb.getInstance(getApplicationContext(), UtilSP.getIMDetailDbName(model.getUserDoctor().getDoctorSelfId(), model.getUserPatient().getPatientId())).insert(model);
                    UtilInsertMsg2JsDb.insert(getApplicationContext(), model);
                    UtilChat.launchChatDetail(PF_IndividuationCostActivity.this, model.getUserPatient().getPatientId(), null);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                // 处理code操作
                GeneralReqExceptionProcess.checkCode(PF_IndividuationCostActivity.this, getCode(), getMsg());
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != pr_id_individuation_cost_explain_web){
            pr_id_individuation_cost_explain_web.removeAllViews();
            pr_id_individuation_cost_explain_web.destroy();
        }
    }
}
