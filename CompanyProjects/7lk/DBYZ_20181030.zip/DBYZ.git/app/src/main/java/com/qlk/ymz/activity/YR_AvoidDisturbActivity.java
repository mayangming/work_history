package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.db.reply.YRAutoReplyDao;
import com.qlk.ymz.db.reply.YRAutoReplyHelper;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import java.util.List;

/**
 * 免打扰回复信息列表页
 *
 * @author 崔毅然
 * @version 1.4
 */
public class YR_AvoidDisturbActivity extends  SK_BaseChoiceAllActivityV2{
    /** 自动回复Dao */
    private YRAutoReplyDao replyDao ;
    /**  默认回复信息model */
    private XCJsonBean replyModel;
    /** 默认回复信息id */
    private String defaultId = "";
    /** 关闭时返回上一页面标示 ,0表示无操作返回，1标示删除了默认回复信息，RESULT_OK标示选择了新的回复选项*/
    public int FINISH_STATUS = 0;
    /** 选中的回复内容 */
    public String select_content = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBeanId("id");
        replyDao = YRAutoReplyDao.getInstance(this);

        //从上个页面获得回复默认内容，如果不为空，在db中检查，获得默认内容的id
       String content =  getIntent().getStringExtra(YRAutoReplyHelper.CONTENT);
        if (!TextUtils.isEmpty(content)) {
            replyModel = replyDao.getSelectedInfo(content);
            if (replyModel != null) {
                defaultId = replyModel.getString(YRAutoReplyHelper.ID);
            }
        }
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_AvoidDisturbActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        super.initWidgets();

        listViewFragment.setBgZeroHintInfo("无免打扰添加记录", "", R.mipmap.js_d_icon_no_data);

    }

    @Override
    public void initAdapter() {
        adapter = new AvoidDisturbAdapter(this,dataList);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateListView();
        initChioseTitle();
    }

    @Override
    public void initChioseItemListenr() {
        listViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                XCJsonBean bean = (XCJsonBean) arg0.getItemAtPosition(arg2);
                FINISH_STATUS = RESULT_OK;
                select_content = bean.getString(YRAutoReplyHelper.CONTENT);
                finish();
            }
        });
    }

    @Override
    public void initChioseTitle() {
        titleCommonFragment.setTitleCenter(true,"自动回复");
        if(dataList == null || dataList.size() < 1){
            titleCommonFragment.setTitleRight2(false,0,"编辑");
        }else{
            titleCommonFragment.setTitleRight2(true,0,"编辑");
        }
        sk_id_choise_add_tv.setText("添加自动回复");

        //清空，防止编辑状态选中后，退出编辑状态，再返回编辑状态，点击删除按钮，弹出删除提示框
        ids = "";
        checkCount = 0;
    }

    @Override
    public void initEditTitle() {
        titleCommonFragment.setTitleCenter(true, "编辑");
        titleCommonFragment.setTitleRight2(true, 0, "保存");
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.sk_id_add_rl:
                myStartActivity(YR_AddAvoidDisturbActivity.class);
                overridePendingTransition(R.anim.activity_open_up, R.anim.activity_no_move);
                break;
        }
    }

    /** 更新回复列表，重置每项的选择状态 */
    public void updateListView(){
        dataList = replyDao.selectReplies();
        for (int i = 0; i < dataList.size(); i++) {
            dataList.get(i).setBoolean("isCheck", false);
        }
        adapter.update(dataList);
        adapter.notifyDataSetChanged();

        listViewFragment.whichShow(dataList.size(), listViewFragment.zero_text_hint,
        listViewFragment.zero_imageview_hint, listViewFragment.zero_button_hint);
    }

    /** 编辑状态，点击完成按钮，批量删除选中的信息列表 */
    public void requestCommit() {
        if (!TextUtils.isEmpty(ids)){
            ids = ids.substring(0,ids.length()-1);
            requestQuickReplyDelete();
        } else {
            shortToast("请选择删除至少一条信息");
        }
    }

    /** 删除免打扰回复信息 */
    public void requestQuickReplyDelete() {
        String[] id = ids.split(",");
        replyDao.deleteReply(id);

        //检查删除项中是否有默认内容，有则将FINISH_STATUS设成1
        if (!TextUtils.isEmpty(defaultId)) {
            for (int i = 0;i<id.length;i++) {
                if (id[i].equals(defaultId)) {
                    FINISH_STATUS = 1;
                    break;
                }
            }
        }

        shortToast("删除成功");

        //清空
        ids = "";
        checkCount = 0;

        initChioseView();
        updateListView();
    }

    class AvoidDisturbAdapter extends SK_BaseChoiseAdapter {

        public AvoidDisturbAdapter(Context context, List<XCJsonBean> list) {
            super(context, list);
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            XCJsonBean bean = list.get(i);
            ViewHolder holder;

            if(view == null){
                view = LayoutInflater.from(context).inflate(R.layout.yr_activity_avoid_disturb,null);
                holder = new ViewHolder();
                holder.contentTv = (TextView)view.findViewById(R.id.tv_content);
                holder.checkBox = (CheckBox)view.findViewById(R.id.cb_disturb);
                holder.id_content_line = (LinearLayout) view.findViewById(R.id.id_content_line);
                holder.v_bottom_line = view.findViewById(R.id.v_bottom_line);
                holder.v_bottom = view.findViewById(R.id.v_bottom);
                view.setTag(holder);
            }else{
                holder = (ViewHolder) view.getTag();
            }
//          设置底部分割线，如果是当前字母最后一个则隐藏,最后一个底部加一块，防止按钮挡住
            if (list.size() - 1 == i) {
                holder.v_bottom_line.setVisibility(View.GONE);
                holder.v_bottom.setVisibility(View.VISIBLE);
            } else {
                holder.v_bottom_line.setVisibility(View.VISIBLE);
                holder.v_bottom.setVisibility(View.GONE);
            }

            holder.contentTv.setText(bean.getString("content"));
            holder.checkBox.setVisibility(View.VISIBLE);

            holder.id_content_line.setBackgroundColor(getResources().getColor(R.color.c_white_ffffff));
            if(isEdit && bean.getBoolean("isCheck")){
                holder.id_content_line.setBackgroundColor(getResources().getColor(R.color.c_blue_e9f4fe));
            }

            initCheckBox(bean,holder.checkBox);

            return view;
        }
        class ViewHolder extends SK_BaseChoiceAllActivityV2.ViewHolder{
            LinearLayout id_content_line;
        }
    }

    @Override
    public void finish() {//所有页面关闭操作都走这，返回上个页面传值，将选中内容和操作标示传回上个页面，没有则传空
        Intent intent = new Intent();
        intent.putExtra(SX_DisturbModeActivity.AVOID_DISTURB_CONTENT, select_content);
        setResult(FINISH_STATUS, intent);
        super.finish();
    }
}
