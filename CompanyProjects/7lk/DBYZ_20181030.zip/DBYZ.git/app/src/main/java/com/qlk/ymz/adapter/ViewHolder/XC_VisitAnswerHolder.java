package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * @author jingyu on 2016/6/25 0:29
 * @description dialog的listview用的
 */
public class XC_VisitAnswerHolder {

    public ImageView select;
    public TextView answer;

    public XC_VisitAnswerHolder(View convertView) {
        this.select = (ImageView) convertView.findViewById(R.id.id_suifang_select);
        this.answer = (TextView) convertView.findViewById(R.id.id_suifang_answer);
    }
}
