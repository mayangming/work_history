package com.qlk.ymz.db.reply;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.qlk.ymz.util.SP.UtilSP;

/**
 * 回复信息的DB
 *
 * @author 崔毅然
 * @version 1.5.0
 */
public class YRAutoReplyHelper extends SQLiteOpenHelper {
    public static final String AUTO_REPLY = "auto_reply";
    public static final String CONTENT = "content";
    public static final String ID = "id";
    public static final int DB_VERSION = 10;


    public String[] defaultContent = {
            "您好，我正吃饭，稍后给您回复",
            "您好，我正查房，稍后给您回复",
            "您好，我正手术，稍后给您回复",
            "您好，我正门诊，稍后给您回复",
            "您好，我正在忙，稍后给您回复"};


    public YRAutoReplyHelper(Context context) {
        super(context, UtilSP.getUserId() + "_autoReplyDB", null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table " + AUTO_REPLY + " (" + ID + " Integer primary key autoincrement" +
                "," + CONTENT + " text" +
                ",free1 text" +
                ",free2 text" +
                ",free3 text" +
                ",free4 text" +
                ",free5 text)");

        insertDefault(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(newVersion > oldVersion) {
            db.execSQL("drop table if exists " + AUTO_REPLY);
            onCreate(db);
        }

    }

    /** 默认插入5条信息 */
    public void insertDefault(SQLiteDatabase db) {
        String sql = "insert into " + YRAutoReplyHelper.AUTO_REPLY +
                " (" + YRAutoReplyHelper.CONTENT + ") values (?)";
        for (int i = 0; i < defaultContent.length; i++) {
            db.execSQL(sql, new Object[]{defaultContent[i]});
        }
    }
}
