package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.DrugBean;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.application.XCApplication;

import java.util.List;

/**
 * @description 聊天页的推荐药品列表适配器
 * @author 赖善琦
 * @version 2.2.0
 */
public class SK_ChatMedichineAdapter extends XCBaseAdapter<DrugBean> {

    /**
     * 构造方法
     * @param context 上下文
     * @param list 数据
     */
    public SK_ChatMedichineAdapter(Context context, List<DrugBean> list) {
        super(context, list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        DrugBean bean = list.get(position);
        SK_ChatMedichineAdapter_Holder holder;

        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.sk_adapter_chat_medichine,null);
            holder = new SK_ChatMedichineAdapter_Holder(convertView);
            convertView.setTag(holder);
        }else{
            holder = (SK_ChatMedichineAdapter_Holder) convertView.getTag();
        }

        String bakup = bean.getMedicineUsageBean().getBakUp();
        if(TextUtils.isEmpty(bakup)){ // 备注为空
            holder.sk_id_tv_chat_medichine_usage.setText(bean.getMedicineUsageBean().getUsages());

        }else{ // 备注不为空
            if(TextUtils.isEmpty(bean.getMedicineUsageBean().getUsages())){ // 用法用量为空
                holder.sk_id_tv_chat_medichine_usage.setText(bakup);
            }else {
                holder.sk_id_tv_chat_medichine_usage.setText(bean.getMedicineUsageBean().getUsages() + "," + bakup);
            }
        }

        holder.sk_id_tv_chat_medichine_name.setText(bean.getName());
        holder.sk_id_tv_chat_medichine_quantity.setText(bean.getMedicineUsageBean().getQuantity());
//        String content = !"".equals(bean.getImUsage()) ? bean.getImUsage() : "";// 用法用量 + 备注
//        content = content + "，" + bean.getBakup();
//        holder.sk_id_tv_chat_medichine_usage.setText(content);
        //holder.sk_id_tv_chat_medichine_spec.setText(bean.getSpec());
        //holder.sk_id_tv_chat_medichine_bakup.setText(!"".equals(bean.getBakup()) ? bean.getBakup() : "无");

        return convertView;
    }

    class SK_ChatMedichineAdapter_Holder{
        /**商品名*/
        TextView sk_id_tv_chat_medichine_name;
        /**通用名*/
        TextView sk_id_tv_chat_medichine_commonname;
        /**购买数量*/
        TextView sk_id_tv_chat_medichine_quantity;
        /**规格*/
        TextView sk_id_tv_chat_medichine_spec;
        /** 用法用量*/
        TextView sk_id_tv_chat_medichine_usage;
        /** 备注*/
        TextView sk_id_tv_chat_medichine_bakup;

        public SK_ChatMedichineAdapter_Holder(View convertView){

            sk_id_tv_chat_medichine_name = (TextView)convertView.findViewById(R.id.sk_id_tv_chat_medichine_name);
            //sk_id_tv_chat_medichine_commonname = (TextView)convertView.findViewById(R.id.sk_id_tv_chat_medichine_commonname);
            sk_id_tv_chat_medichine_quantity = (TextView)convertView.findViewById(R.id.sk_id_tv_chat_medichine_quantity);
            sk_id_tv_chat_medichine_spec = (TextView)convertView.findViewById(R.id.sk_id_tv_chat_medichine_spec);
            sk_id_tv_chat_medichine_usage = (TextView)convertView.findViewById(R.id.sk_id_tv_chat_medichine_usage);
            sk_id_tv_chat_medichine_bakup = (TextView)convertView.findViewById(R.id.sk_id_tv_chat_medichine_bakup);

        }
    }
}
