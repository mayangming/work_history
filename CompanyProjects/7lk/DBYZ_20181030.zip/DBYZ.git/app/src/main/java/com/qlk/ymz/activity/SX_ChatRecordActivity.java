package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.emoji.util.EmojiSpanUtils;
import com.handmark.pulltorefresh.library.ILoadingLayout;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_ChatRecordAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.SX_ChatRecordInfo;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * SX_ChatRecordActivity
 * 聊天记录(会话列表)
 * @author songxin on 2016/1/11.
 * @version 2.0
 */
public class SX_ChatRecordActivity extends DBActivity implements View.OnClickListener{
    /** title左边按钮*/
    private ImageView sx_id_title_left;
    /** title中间文字*/
    private TextView sx_id_title_center;
    /** 聊天记录listView*/
    private PullToRefreshListView sx_id_chat_record_list;
    private ListView myListView;
    /** 跳转到聊天必须封装的对象*/
    private XC_ChatModel xc_chatModel;
    /** 当前页号*/
    private String mPageNo = "";
    /** 每页记录数*/
    private String mPageSize = "";
    /** 总记录数*/
    private String mTotalCount = "";
    /** 总页数*/
    private String mTotalPages = "";
    /** 会话列表数据集合*/
    private List<SX_ChatRecordInfo> mSX_ChatRecordInfo;
    /** 会话列表适配器*/
    private SX_ChatRecordAdapter mSX_ChatRecordAdapter;
    /** 没有网络时显示*/
    private LinearLayout sx_id_no_net_rl;


    @Override
	protected void onCreate(Bundle savedInstanceState) {
		// 设置布局
		setContentView(R.layout.sx_l_activity_chat_record);
		super.onCreate(savedInstanceState);
        sx_id_title_center.setText("会话列表");
        mSX_ChatRecordInfo = new ArrayList<>();
        xc_chatModel = (XC_ChatModel)getIntent().getSerializableExtra(CommonConfig.CHAT_PARAMS_MODEL);
        if(null == xc_chatModel){
            xc_chatModel = new XC_ChatModel();
        }
        sx_id_chat_record_list.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
        ILoadingLayout startLabels = sx_id_chat_record_list
                .getLoadingLayoutProxy(true, false);
        startLabels.setPullLabel("下拉刷新...");// 刚下拉时，显示的提示
        startLabels.setRefreshingLabel("正在载入...");// 刷新时
        startLabels.setReleaseLabel("放开刷新...");// 下来达到一定距离时，显示的提示

        ILoadingLayout endLabels = sx_id_chat_record_list.getLoadingLayoutProxy(
                false, true);
        endLabels.setPullLabel("上拉刷新...");// 刚下拉时，显示的提示
        endLabels.setRefreshingLabel("正在载入...");// 刷新时
        endLabels.setReleaseLabel("放开刷新...");// 下来达到一定距离时，显示的提示
        getChatRecordList("2",1,"20");
	}

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_ChatRecordActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

	// 无网络时,点击屏幕后回调的方法
	@Override
	public void onNetRefresh() {
	}

	// 初始化控件
	@Override
	public void initWidgets() {
        sx_id_title_left = getViewById(R.id.sx_id_title_left);
        sx_id_title_center = getViewById(R.id.sx_id_title_center);
        sx_id_chat_record_list = getViewById(R.id.sx_id_chat_record_list);

        sx_id_no_net_rl = getViewById(R.id.sx_id_no_net_rl);
        ((TextView)sx_id_no_net_rl.findViewById(R.id.id_zero_data_tv)).setText("还没有聊天数据哦~");

        myListView = sx_id_chat_record_list.getRefreshableView();

	}

	// 设置监听
	@Override
	public void listeners() {
        sx_id_title_left.setOnClickListener(this);
        sx_id_chat_record_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                if("-1".equals(mSX_ChatRecordInfo.get(position - 1).getPayStatus())){
                    // 咨询中
                    xc_chatModel.setSessionLifeCycle(XC_ChatModel.SESSION_ING);
                }else{
                    // 会话结束
                    xc_chatModel.setSessionLifeCycle(XC_ChatModel.SESSION_END);
                }
                xc_chatModel.setSessionId(mSX_ChatRecordInfo.get(position - 1).getSessionId());
                xc_chatModel.setSessionBeginTime(mSX_ChatRecordInfo.get(position - 1).getBeginTime());
                xc_chatModel.setPayMode(mSX_ChatRecordInfo.get(position - 1).getPayType());
                xc_chatModel.setSessionEndTime(mSX_ChatRecordInfo.get(position - 1).getEndTime());
                intent.putExtra(CommonConfig.CHAT_PARAMS_MODEL, xc_chatModel);
                intent.setClass(SX_ChatRecordActivity.this,XC_ChatDetailActivity.class);
                startActivity(intent);
            }
        });

        sx_id_chat_record_list.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                if(null != mSX_ChatRecordInfo){
                    mSX_ChatRecordInfo.clear();
                }
                getChatRecordList("2", 1, "20");
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                getChatRecordList("2", Integer.valueOf("".equals(mPageNo) ? "0" : mPageNo) + 1, "20");
            }
        });
	}

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.sx_id_title_left:{
                finish();
                break;
            }
            default:{
                break;
            }
        }
    }

    /**
     * 获得会话列表
     * @param status 1:未完成的会话;2全部的会话
     * @param pageNo 页码 默认1
     * @param pageSize 每页记录数 默认20
     */
    private  void getChatRecordList(String status,int pageNo,String pageSize){
        RequestParams params = new RequestParams();
        params.put("patientId", xc_chatModel.getUserPatient().getPatientId());
        params.put("status", status);
        params.put("pageNo", pageNo);
        params.put("pageSize", pageSize);
        params.put("orderBy", "1");
        XCHttpAsyn.postAsyn(this, AppConfig.getChatUrl(AppConfig.chatRecordList), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                        //当前页号
                        mPageNo = jsonBeans.get(0).getString("pageNo");
                        //每页记录数
                        mPageSize = jsonBeans.get(0).getString("pageSize");
                        //总记录数
                        mTotalCount = jsonBeans.get(0).getString("totalCount");
                        //总页数
                        mTotalPages = jsonBeans.get(0).getString("totalPages");
                        //拿到会话列表json
                        List<XCJsonBean> jsonResultBeans = jsonBeans.get(0).getList("result");
                        if (jsonResultBeans.size() > 0) {
                            for (int i = 0; i < jsonResultBeans.size(); i++) {
                                SX_ChatRecordInfo sx_chatRecordInfo = new SX_ChatRecordInfo();
                                sx_chatRecordInfo.setChat_record_head_image_url(xc_chatModel.getUserPatient().getPatientImgHead());
                                sx_chatRecordInfo.setChat_record_patient_name(xc_chatModel.getUserPatient().getPatientDisplayName());
                                //判断是付费还是免费
                                if ("0".equals(jsonResultBeans.get(i).getString("payType"))) {
                                    sx_chatRecordInfo.setChat_spend("免费");
                                } else {
                                    //问诊价格
                                    sx_chatRecordInfo.setChat_spend(jsonResultBeans.get(i).getString("price"));
                                }
                                //2.2版本只有两个状态 付费状态修改 -1 咨询中; 1 已结束;
                                if ("-1".equals(jsonResultBeans.get(i).getString("payStatus"))) {
                                    sx_chatRecordInfo.setChat_status_show("咨询中");
                                }else if ("1".equals(jsonResultBeans.get(i).getString("payStatus"))) {
                                    sx_chatRecordInfo.setChat_status_show("已结束");
                                }
                                sx_chatRecordInfo.setPayStatus(jsonResultBeans.get(i).getString("payStatus"));
                                sx_chatRecordInfo.setPrice(jsonResultBeans.get(i).getString("price"));
                                sx_chatRecordInfo.setBeginTime(jsonResultBeans.get(i).getString("beginTime"));
                                sx_chatRecordInfo.setEndTime(jsonResultBeans.get(i).getString("endTime"));
                                sx_chatRecordInfo.setRelation(jsonResultBeans.get(i).getString("relation"));
                                sx_chatRecordInfo.setPayType(jsonResultBeans.get(i).getString("payType"));
                                //时间处理
                                sx_chatRecordInfo.setChat_over_time(UtilDate.chatRecoderListTime(Long.valueOf(jsonResultBeans.get(i).getString("beginTime")), System.currentTimeMillis()));
                                if (null != jsonResultBeans.get(i).getModel("lastMsg")) {
                                    XCJsonBean lastMsg = jsonResultBeans.get(i).getModel("lastMsg");
                                    int type = UtilString.toInt(lastMsg.getString("type"));
                                    XCApplication.base_log.i("http","type====>"+type);
                                    if (XC_ChatModel.TEXT == type) {
                                        sx_chatRecordInfo.setContent(EmojiSpanUtils.getPatternEmojiMean(jsonResultBeans.get(i).getModel("lastMsg").getString("content")));
                                    } else if (XC_ChatModel.PHOTO == type) {
                                        sx_chatRecordInfo.setContent("[图片消息]");
                                    } else if (XC_ChatModel.VOICE == type) {
                                        sx_chatRecordInfo.setContent("[语音消息]");
                                    } else if (XC_ChatModel.MOVIE == type) {
                                        sx_chatRecordInfo.setContent("[视频消息]");
                                    } else if (XC_ChatModel.RECOMMAND_MEDICINE == type) {
                                        sx_chatRecordInfo.setContent("[药方消息]");
                                    } else if (XC_ChatModel.ASSISTANT_MEDICINE == type) {
                                        sx_chatRecordInfo.setContent("[链接消息]");
                                    } else if (XC_ChatModel.PATIENT_BUY == type) {
                                        sx_chatRecordInfo.setContent("您有一段<font color = '#ff0000'>[购药咨询]</font>消息");
                                    } else if (XC_ChatModel.VISIT == type) {
                                        sx_chatRecordInfo.setContent("[随访消息]");
                                    } else if (XC_ChatModel.PUBLICITY_EDUCATION == type) {
                                        sx_chatRecordInfo.setContent("[宣教]");
                                    } else if (XC_ChatModel.INDIVIDUATION_COST == type) {
                                        sx_chatRecordInfo.setContent("[已推荐个性化服务费]");
                                    } else if (XC_ChatModel.SCALE == type) {
                                        sx_chatRecordInfo.setContent("[量表]");
                                    }else if(XC_ChatModel.CHECK_HEALTH == type){
                                        sx_chatRecordInfo.setContent("[检查信息]");
                                    }else if(XC_ChatModel.MEDICINE_RECORD == type){
                                        XCJsonBean content = lastMsg.getModel("content");
                                        sx_chatRecordInfo.setContent(content.getString("text"));
                                    }else if(XC_ChatModel.MEDICINE_RECORD_LAST == type){
                                        XCJsonBean content = lastMsg.getModel("content");
                                        sx_chatRecordInfo.setContent(content.getString("text"));
                                    }else if(XC_ChatModel.MEDICINE_RECORD_REMIND == type){
                                        XCJsonBean content = lastMsg.getModel("content");
                                        sx_chatRecordInfo.setContent(content.getString("text"));
                                    }else if(XC_ChatModel.MEDICAL_RECORD == type){
                                        XCJsonBean content = lastMsg.getModel("content");
                                        String recommandId = content.getString("recommandId");
                                        if (UtilString.isBlank(recommandId)){//如果推荐处方ID不为null，则表示有处方
                                            sx_chatRecordInfo.setContent("[病历]");
                                        }else {
                                            sx_chatRecordInfo.setContent("[病历处方]");
                                        }
                                    }else if(XC_ChatModel.SCALE_NEW == type){
                                        XCJsonBean content = lastMsg.getModel("content");
                                        String title = content.getString("title");
                                        sx_chatRecordInfo.setContent("填写了["+  title +"]");
                                    }
                                    else if (XC_ChatModel.CHECK_REPORT == type){
                                        XCJsonBean content = lastMsg.getModel("content");
                                        sx_chatRecordInfo.setContent("<font color= '#444444'>[检查报告]</font>"+content.getString("text"));
                                    }
                                    else if (0 == type){//0是type对象为空时，取出的默认值，一般在会话进行中出现这个默认值
                                        sx_chatRecordInfo.setContent("");
                                    }else {
                                        sx_chatRecordInfo.setContent("当前版本暂不支持查看此类消息，请更新APP至最新版本查看!");
                                    }
                                    sx_chatRecordInfo.setSessionId(jsonResultBeans.get(i).getString("sessionId"));
                                    sx_chatRecordInfo.setFromId(jsonResultBeans.get(i).getString("fromId"));
                                    sx_chatRecordInfo.setToId(jsonResultBeans.get(i).getString("toId"));
                                    mSX_ChatRecordInfo.add(sx_chatRecordInfo);
                                }

                            }
                        }
                        sx_id_chat_record_list.onRefreshComplete();
                        if(null != mSX_ChatRecordInfo){
                            if(mSX_ChatRecordInfo.size() == 0){
                                sx_id_no_net_rl.setVisibility(View.VISIBLE);
                            }else {
                                sx_id_no_net_rl.setVisibility(View.GONE);
                            }
                            //如果不够一页，不显示下拉加载
                            if(mSX_ChatRecordInfo.size() >= UtilString.toInt(mTotalCount)){
                                sx_id_chat_record_list.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
                            }else{
                                sx_id_chat_record_list.setMode(PullToRefreshBase.Mode.BOTH);
                            }
                        }
                        //适配数据
                        if(null == mSX_ChatRecordAdapter){
                            mSX_ChatRecordAdapter = new SX_ChatRecordAdapter(SX_ChatRecordActivity.this,mSX_ChatRecordInfo);
                            myListView.setAdapter(mSX_ChatRecordAdapter);
                        }else{
                            mSX_ChatRecordAdapter.notifyDataSetChanged();
                        }

                    }
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_ChatRecordActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }
}
