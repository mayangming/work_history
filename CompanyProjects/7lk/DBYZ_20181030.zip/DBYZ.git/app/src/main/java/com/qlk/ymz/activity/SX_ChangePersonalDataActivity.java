package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.YY_DoctorlInfoBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.UtilLoginOut;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_ErrorPromptEditText;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilMd5;
import com.xiaocoder.android.fw.general.util.UtilRSA;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by songxin on 2015/6/17.
 *
 * SX_ChangePersonalDataActivity
 * 修改个人信息页面
 * @author  Changed by songxin on 2016/3/29.
 * @version 2.3
 */
public class SX_ChangePersonalDataActivity extends DBActivity {
    /** Title*/
    private XCTitleCommonLayout titlebar;
    /** 修改真实姓名layout*/
    private RelativeLayout sx_id_true_name_rl;
    /** 填写真实姓名输入框*/
    private YR_ErrorPromptEditText sx_id_change_true_name_edit;
    /** 修改性别layout*/
    private RelativeLayout sx_id_sex_rl;
    /** 性别选择(男)*/
    private ImageView sx_id_male_choose;
    /** 性别选择(女)*/
    private ImageView sx_id_female_choose;
    /** 性别选择(男)布局*/
    private RelativeLayout sx_id_male_rl;
    /** 性别选择(女)布局*/
    private RelativeLayout sx_id_female_rl;
    /** 修改电话号码layout*/
    private LinearLayout sx_id_phone_number_rl;
    /** 填写手机号*/
    private EditText sx_id_phone_number_edit;
    /** 填写验证码*/
    private EditText sx_id_verification_code_edit;
    /** 点击获取验证码*/
    private TextView sx_id_get_verification_code_textView;
    /** 个人简介layout*/
    private RelativeLayout sx_id_personal_profile_rl;
    /** 个人简介编辑框*/
    private EditText sx_id_personal_profile_edit;
    /** 个人简介编辑框的字数限制提示 */
    private TextView sx_id_personal_profile_tv;
    /** 擅长layout*/
    private RelativeLayout sx_id_be_good_at_rl;
    /** 擅长编辑框*/
    private EditText sx_id_be_good_at_edit;
    /** 擅长编辑框的字数限制提示*/
    private TextView sx_id_be_good_at_tv;
    /** dialog 取消按钮*/
    private TextView sx_id_cancel_button;
    /** dialog 确定按钮*/
    private TextView sx_id_pw_confirm_button;
    /** dialog 输入框*/
    private EditText sx_id_dialog_pw_edit;
    /** dialog*/
    private ConfirmDialog mConfirmPwDialog;
    /** Intent*/
    private Intent mIntent;
    /** 标记flag*/
    private int mIntentFlags;
    /** 选择项临时变量*/
    private String mChooseSex;
    /** Timer*/
    private Timer mTimer;
    private TimerTask mTask;
    private int mTime = 60;

    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_personal_data_change);
        super.onCreate(savedInstanceState);
        mIntent = new Intent();
        mTimer = new Timer();
        mIntentFlags = getIntent().getFlags();
        printi("songxin","mIntentFlags======>"+mIntentFlags);
        titlebar.setTitleLeft(true, "");
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        //Dialog初始化
        int srceenW =  this.getWindowManager().getDefaultDisplay().getWidth();
        mConfirmPwDialog = new ConfirmDialog(SX_ChangePersonalDataActivity.this, srceenW,150
                ,R.layout.sx_l_pw_edit_dialog,R.style.xc_s_dialog);
        mConfirmPwDialog.setCanceledOnTouchOutside(false);
        sx_id_cancel_button = (TextView) mConfirmPwDialog.findViewById(R.id.sx_id_cancel_button);
        sx_id_pw_confirm_button = (TextView) mConfirmPwDialog.findViewById(R.id.sx_id_pw_confirm_button);
        sx_id_dialog_pw_edit = (EditText) mConfirmPwDialog.findViewById(R.id.sx_id_dialog_pw_edit);
        sx_id_cancel_button.setOnClickListener(this);
        sx_id_pw_confirm_button.setOnClickListener(this);
        //根据不同的flag值做相应的处理
        switch (mIntentFlags){
            case 0:{
                sx_id_true_name_rl.setVisibility(View.VISIBLE);
                titlebar.setTitleCenter(true, "填写真实姓名");
                titlebar.setTitleRight2(true,0,"确定");
                String intentData = getIntent().getStringExtra("TRUE_NAME");
                sx_id_change_true_name_edit.sx_clearEditText.setText(intentData);
                break;
            }
            case 1:{
                sx_id_sex_rl.setVisibility(View.VISIBLE);
                titlebar.setTitleCenter(true, "选择性别");
                titlebar.setTitleRight2(true, 0, "确定");
                String intentData = getIntent().getStringExtra("SEX");
                mChooseSex = intentData;
                if(intentData.equals("男")){
                    sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_sure);
                    sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                }else if(intentData.equals("女")){
                    sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                    sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_sure);
                }else{
                    sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                    sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                }
                sx_id_change_true_name_edit.sx_clearEditText.setText(intentData);
                break;
            }
            case 2:{
                sx_id_phone_number_rl.setVisibility(View.VISIBLE);
                titlebar.setTitleCenter(true, "更换手机号码");
                titlebar.setTitleRight2(true, 0, "确定");
//                String intentData = getIntent().getStringExtra("PHONE_NUMBER");
//                sx_id_phone_number_edit.setText(intentData);
                break;
            }

            case 6:{
                sx_id_be_good_at_rl.setVisibility(View.VISIBLE);
                titlebar.setTitleCenter(true, "编辑擅长");
                titlebar.setTitleRight2(true, 0, "确定");
                String intentData = getIntent().getStringExtra("BE_GOOD_AT");
                sx_id_be_good_at_edit.setText(intentData.trim());
                sx_id_be_good_at_edit.setSelection(intentData.trim().length());
                break;
            }
            case 7:{
                sx_id_personal_profile_rl.setVisibility(View.VISIBLE);
                titlebar.setTitleCenter(true, "编辑个人简介");
                titlebar.setTitleRight2(true, 0, "保存");
                String intentData = getIntent().getStringExtra("PERSONAL_PROFILE");
                sx_id_personal_profile_edit.setText(intentData.trim());
                sx_id_personal_profile_edit.setSelection(intentData.trim().length());
                break;
            }
        }
        //title右侧的按钮事件处理
        titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (mIntentFlags) {
                    case 0: {
                        // update by 崔毅然 on 2016-8-2
                        if (!sx_id_change_true_name_edit.setErrorText()){
                            sx_id_change_true_name_edit.errorInfo_tv.setVisibility(View.VISIBLE);
                            return;
                        }
                        //此处改成返回时去掉前后和中间的空格
                        String name = sx_id_change_true_name_edit.sx_clearEditText.getText().toString().trim();
                        name = name.replaceAll(" ","");
                        YY_DoctorlInfoBean.DataEntity currentData = new YY_DoctorlInfoBean.DataEntity();
                        currentData.setName(name);
                        mIntent.putExtra("TRUE_NAME", currentData);
                        SX_ChangePersonalDataActivity.this.setResult(0, mIntent);
                        SX_ChangePersonalDataActivity.this.myFinish();
                        break;
                    }
                    case 1: {
                        String currentSex = "";
                        if (mChooseSex.equals("女")) {
                            currentSex = "0";
                        } else if (mChooseSex.equals("男")){//改为else if；因为有不选性别的情况 jira3653
                            currentSex = "1";
                        }
                        YY_DoctorlInfoBean.DataEntity currentData = new YY_DoctorlInfoBean.DataEntity();
                        currentData.setGender(currentSex);
                        mIntent.putExtra("SEX", currentData);
                        SX_ChangePersonalDataActivity.this.setResult(1,mIntent);
                        SX_ChangePersonalDataActivity.this.myFinish();
                        break;
                    }
                    case 2: {

                        String phoneNumber = sx_id_phone_number_edit.getText().toString().trim();
                        String vCode = sx_id_verification_code_edit.getText().toString().trim();
                        if (UtilString.isBlank(phoneNumber)) {
                            shortToast("请输入手机号");
                            return;
                        }
                        if (UtilString.isBlank(vCode)) {
                            shortToast("请输入验证码");
                            return;
                        }
                        if (!UtilString.isPhoneNum(phoneNumber)) {
                            shortToast("手机号格式不对，请重新输入");
                            return;
                        }
                        mConfirmPwDialog.show();
                        break;
                    }

                    case 6: {
                        String personalProfile = sx_id_be_good_at_edit.getText().toString().trim();
                        if (!StringUtils.isAccordPattern(personalProfile,StringUtils.getValidateRegexOthers())) {
                            shortToast("您的擅长内容含有特殊字符或者长度不符合规范,请重新输入");
                            return;
                        }
                        RequestParams params = new RequestParams();
                        params.put("id", UtilSP.getUserId());
                        if(UtilString.isBlank(personalProfile)){
                            params.put("delType", "1");
                        }
                        params.put("expertise", sx_id_be_good_at_edit.getText().toString().trim());
                        changeInfo(params);
                        break;
                    }
                    case 7: {
                        String personalProfile = sx_id_personal_profile_edit.getText().toString().trim();
                        String pattern = StringUtils.getValidateRegexOthers();
                        if (!StringUtils.isAccordPattern(personalProfile,pattern)) {
                            shortToast("您的个人简介含有特殊字符或者长度不符合规范,请重新输入");
                            return;
                        }
                        RequestParams params = new RequestParams();
                        params.put("id", UtilSP.getUserId());
                        if(UtilString.isBlank(personalProfile)){
                            params.put("delType", "2");
                        }
                        params.put("introduction", sx_id_personal_profile_edit.getText().toString().trim());
                        changeInfo(params);
                        break;

                    }
                }
            }
        });

        initWidgetsData();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_ChangePersonalDataActivity.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        //修改真实姓名
        sx_id_true_name_rl = getViewById(R.id.sx_id_true_name_rl);
        sx_id_change_true_name_edit = getViewById(R.id.sx_id_change_true_name_edit);
        //修改性别
        sx_id_sex_rl = getViewById(R.id.sx_id_sex_rl);
        sx_id_male_choose = getViewById(R.id.sx_id_male_choose);
        sx_id_female_choose = getViewById(R.id.sx_id_female_choose);
        sx_id_male_rl = getViewById(R.id.sx_id_male_rl);
        sx_id_female_rl  = getViewById(R.id.sx_id_female_rl);
        //修改手机号
        sx_id_phone_number_rl = getViewById(R.id.sx_id_phone_number_rl);
        sx_id_phone_number_edit = getViewById(R.id.sx_id_phone_number_edit);
        sx_id_verification_code_edit = getViewById(R.id.sx_id_verification_code_edit);
        sx_id_get_verification_code_textView = getViewById(R.id.sx_id_get_verification_code_textView);
        //个人简介
        sx_id_personal_profile_rl = getViewById(R.id.sx_id_personal_profile_rl);
        sx_id_personal_profile_edit = getViewById(R.id.sx_id_personal_profile_edit);
        sx_id_personal_profile_tv = getViewById(R.id.sx_id_personal_profile_tv);
        //擅长
        sx_id_be_good_at_rl = getViewById(R.id.sx_id_be_good_at_rl);
        sx_id_be_good_at_edit = getViewById(R.id.sx_id_be_good_at_edit);
        sx_id_be_good_at_tv = getViewById(R.id.sx_id_be_good_at_tv);
    }

    int beGoodAtMaxLength = 0;//擅长最大长度
    int maxLength = 0;//个人简介最大长度

    /** update by cyr on 2016/7/7 初始化设置控件长度限制 */
    private void initWidgetsData() {
        switch (mIntentFlags) {
            case 0:
                // update by 崔毅然 on 2016-8-2  V2.6 修改输入框错误提示方式  start
                int nameMaxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.REALNAME, 0, 19);
                int nameMinLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.REALNAME, 1, 1);
                sx_id_change_true_name_edit.sx_clearEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(nameMaxLength)});
                sx_id_change_true_name_edit.setLimitAttrs(nameMinLength, nameMaxLength);
                // update by 崔毅然 on 2016-8-2  V2.6 修改输入框错误提示方式  end
                break;
            case 7:
                maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.INTRODUCTION, 0, 300);
                sx_id_personal_profile_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
                sx_id_personal_profile_tv.setText("(" + maxLength + "字符以内)");
                break;
            case 6:
                beGoodAtMaxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.EXPERTISE, 0, 300);
                sx_id_be_good_at_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(beGoodAtMaxLength)});
                sx_id_be_good_at_tv.setText("(" + beGoodAtMaxLength + "字符以内)");
                break;
        }
    }

    public void listeners() {
        sx_id_male_rl.setOnClickListener(this);
        sx_id_female_rl.setOnClickListener(this);
        sx_id_get_verification_code_textView.setOnClickListener(this);
    }

    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.sx_id_male_rl:{
                mChooseSex = "男";
                sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_sure);
                sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                break;
            }
            case R.id.sx_id_female_rl:{
                mChooseSex = "女";
                sx_id_male_choose.setImageResource(R.mipmap.sx_d_register_no_sure);
                sx_id_female_choose.setImageResource(R.mipmap.sx_d_register_sure);
                break;
            }
            case R.id.sx_id_get_verification_code_textView:{
                String username = sx_id_phone_number_edit.getText().toString().trim();
                if(UtilString.isBlank(username)){
                    shortToast("手机号不能为空");
                    return;
                }
                if(!UtilString.isPhoneNum(username)){
                    shortToast("手机号格式不正确");
                    return;
                }
                getCurtentTime(username);
                break;
            }
            case R.id.sx_id_cancel_button:{
                if(null != mConfirmPwDialog){
                    mConfirmPwDialog.dismiss();
                }
                break;
            }
            case R.id.sx_id_pw_confirm_button:{
                String phoneNumber = sx_id_phone_number_edit.getText().toString().trim();
                String vCode = sx_id_verification_code_edit.getText().toString().trim();
                String password = sx_id_dialog_pw_edit.getText().toString().trim();
                if (UtilString.isBlank(phoneNumber)) {
                    shortToast("请输入手机号");
                    return;
                }
                if (UtilString.isBlank(vCode)) {
                    shortToast("请输入验证码");
                    return;
                }
                if (UtilString.isBlank(password)) {
                    shortToast("请输入密码");
                    return;
                }
                if(!UtilString.isPhoneNum(phoneNumber)){
                    shortToast("手机号格式不对，请重新输入");
                    return;
                }
                RequestParams params = new RequestParams();
                params.put("id", UtilSP.getUserId());
                params.put("phone", phoneNumber);
                params.put("verifyCode", vCode);
                params.put("password", UtilRSA.encryByRSA(UtilSP.getPublicKey(), password));
                changeInfo(params);
                break;
            }
        }
    }

    public void onNetRefresh() {
    }

    /**
     * 修改信息
     * @param params 需要传递的参数
     */
    private void changeInfo(RequestParams params){
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.user_save), params, new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    switch(mIntentFlags){
                        case 2:{
                            logout();
                            break;
                        }

                        case 6:{
                            String personalProfile = sx_id_be_good_at_edit.getText().toString().trim();
                            mIntent.putExtra("BE_GOOD_AT", personalProfile);
                            SX_ChangePersonalDataActivity.this.setResult(6,mIntent);
                            SX_ChangePersonalDataActivity.this.myFinish();
                            break;
                        }
                        case 7:{
                            String personalProfile = sx_id_personal_profile_edit.getText().toString().trim();
                            mIntent.putExtra("PERSONAL_PROFILE", personalProfile);
                            SX_ChangePersonalDataActivity.this.setResult(7,mIntent);
                            SX_ChangePersonalDataActivity.this.myFinish();
                            break;
                        }
                    }
                }else{
                    //验证码错误。关闭窗口
                    if("30005".equals(getCode())){
                        if(null != mConfirmPwDialog){
                            mConfirmPwDialog.dismiss();
                        }
                    }
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_ChangePersonalDataActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 请求验证码
     * @param phoneNumber :医生输入手机号码
     * @param actionType ：功能类型(1/注册；2/忘记密码；3/修改手机号)
     */
    private void requestVcode(final String phoneNumber,String actionType,String currentTime){
        //发送请求
        RequestParams params = new RequestParams();
        params.put("phoneNum", phoneNumber);
        params.put("actionType", actionType);
        params.put("t", currentTime);
        params.put("sign", UtilMd5.MD5Encode("actionType="+actionType+"&phoneNum="+phoneNumber+"&t="+currentTime+AppConfig.SECRET_KEY));

        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.sendSms), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if(result_boolean){
                    sx_id_get_verification_code_textView.setEnabled(false);
                    mTask = new TimerTask() {
                        public void run() {

                            runOnUiThread(new Runnable() { // UI thread
                                public void run() {
                                    if (mTime <= 0) {
                                        sx_id_get_verification_code_textView.setEnabled(true);
                                        sx_id_get_verification_code_textView.setText("重新获取");
                                        sx_id_get_verification_code_textView.setTextColor(getResources().getColor(R.color.c_e2231a));
                                        mTask.cancel();
                                    } else {
                                        sx_id_get_verification_code_textView.setText(mTime + "s后重新获取");
                                        sx_id_get_verification_code_textView.setTextColor(getResources().getColor(R.color.c_7b7b7b));
                                    }
                                    mTime--;
                                }
                            });
                        }
                    };
                    mTime = 60;
                    mTimer.schedule(mTask, 0, 1000);
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_ChangePersonalDataActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    private void getCurtentTime(final String username) {
        try {
            //发送请求
            RequestParams params = new RequestParams();
            XCHttpAsyn.postAsyn(false, SX_ChangePersonalDataActivity.this, AppConfig.getHostUrl(AppConfig.get_time), params, new XCHttpResponseHandler() {
                @Override
                public void onSuccess(int code, Header[] headers, byte[] arg2) {
                    super.onSuccess(code, headers, arg2);
                    if (result_boolean) {
                        long time = ((List<Long>) result_bean.get("data")).get(0);
                        requestVcode(username, "3",time+"");
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 登出操作
     */
    private void logout(){
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.login_logout), new RequestParams(), new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    UtilLoginOut.loginOut(SX_ChangePersonalDataActivity.this);
                    // add by xjs on 20151215-1015 start
                    // 修复JIRA上编号为179的BUG
                    Toast.makeText(SX_ChangePersonalDataActivity.this, "更改手机号需要您重新登录", Toast.LENGTH_LONG).show();
                    // add by xjs on 20151215-1015 end
                    XCApplication.finishAllActivity();
                    myStartActivity(LoginAndRegisterActivity.class);
                }
            }
            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_ChangePersonalDataActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:{
                break;
            }
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs( mConfirmPwDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }
}
