package com.qlk.ymz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.contrarywind.view.WheelView;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.UtilScreen;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ArrayTextWheelAdapter;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2018/5/28.
 * 医嘱小结
 */

public class XD_EditDoctorAdviceActivity extends DBActivity {
    /** 标题栏*/
    private XCTitleCommonLayout xc_id_model_titlebar;
    /** 保存按钮*/
    private TextView tv_save;
    /** 复诊时间选择*/
    private RelativeLayout rl_check_time;
    /** 复诊时间*/
    private TextView tv_time;
    /** 医嘱小结*/
    private EditText et_doctor_acvice;
    /** 医嘱小结字数*/
    private TextView tv_doctor_acvice_count;
    /** 选择复诊时间对话框*/
    private ConfirmDialog mTimeDialog;
    /** 对话框取消按钮*/
    private TextView tv_dialog_cancel;
    /** 对话框确定按钮*/
    private TextView tv_dialog_confirm;
    /** 滚轮控件*/
    private WheelView wv_num;
    private WheelView wv_unit;
    /** 返回阻挡dialog*/
    private YR_CommonDialog mBackDialog;

    /** 时间数据集合*/
    private List<String> mNumList = new ArrayList<>();
    /** 时间单位集合*/
    private List<String> mUnitList = new ArrayList<>();
    /** 当前时间数据*/
    private String mCurrentNum ="";
    /** 当前时间单位*/
    private String mCurrentUnit ="";
    /** 屏幕宽*/
    private int mScreenWidth = 720;
    /** 填写病历数据 上级页面传*/
    private DrCaseVOBean mDrCaseVOBean;
    /** 上级页面是否传来数据*/
    private boolean hasData = false;
    private int mMaxLength;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_edit_doctor_advice);
        super.onCreate(savedInstanceState);
        initData();
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_EditDoctorAdviceActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    private void initData() {
        mDrCaseVOBean = (DrCaseVOBean) getIntent().getSerializableExtra(XD_EditMedicalRecordActivity.DR_CASE_VO_BEAN);
        if(mDrCaseVOBean!=null){
            if("1".equals(mDrCaseVOBean.getRevisitFalg())){//有复诊时间
                hasData = true;
                if("月".equals(mDrCaseVOBean.getRevisitDateUnit())){
                    tv_time.setText(mDrCaseVOBean.getRevisitNumber()+"个"+mDrCaseVOBean.getRevisitDateUnit()+"后");
                }else {
                    tv_time.setText(mDrCaseVOBean.getRevisitNumber()+mDrCaseVOBean.getRevisitDateUnit()+"后");
                }
                mCurrentNum=mDrCaseVOBean.getRevisitNumber();
                mCurrentUnit = mDrCaseVOBean.getRevisitDateUnit();
            }
            if(!TextUtils.isEmpty(mDrCaseVOBean.getDoctorOrder())){//有医嘱小结
                hasData = true;
                et_doctor_acvice.setText(mDrCaseVOBean.getDoctorOrder());
            }
        }
        if(hasData){
            tv_save.setTextColor(getResources().getColor(R.color.c_gray_7b7b7b));
        }else {
            tv_save.setTextColor(getResources().getColor(R.color.c_7f7b7b7b));
        }
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.setTitleCenter(true, "医嘱小结");
        xc_id_model_titlebar.setTitleLeft(true,"取消");
        xc_id_model_titlebar.getXc_id_titlebar_left_imageview().setVisibility(View.GONE);
        xc_id_model_titlebar.setTitleRight2(true,0,"保存");
        tv_save = xc_id_model_titlebar.getXc_id_titlebar_right2_textview();
        xc_id_model_titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(hasData || !TextUtils.isEmpty(et_doctor_acvice.getText().toString().trim())
                        ||!"无".equals(tv_time.getText().toString().trim())){
                    showBackDialog();
                }else {
                    myFinish();
                }
            }
        });

        rl_check_time = getViewById(R.id.rl_check_time);
        tv_time = getViewById(R.id.tv_time);
        et_doctor_acvice = getViewById(R.id.et_doctor_acvice);
        tv_doctor_acvice_count = getViewById(R.id.tv_doctor_acvice_count);
        mMaxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.CASE_DOCTOR_ORDER, 0, 1000);
        et_doctor_acvice.setFilters(new InputFilter[]{new InputFilter.LengthFilter(mMaxLength)});

        initTimeDialog();
    }

    @Override
    public void listeners() {
        rl_check_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTimeDialog.show();
            }
        });
        tv_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String content = et_doctor_acvice.getText().toString().trim();
                if(!hasData &&TextUtils.isEmpty(content)&& "无".equals(tv_time.getText().toString().trim())){
                    return;
                }
                if(StringUtils.containsEmoji(content)){
                    shortToast("医嘱小结不能输入表情");
                    return;
                }
                mDrCaseVOBean.setDoctorOrder(content);
                Intent intent = new Intent();
                intent.putExtra(XD_EditMedicalRecordActivity.DR_CASE_VO_BEAN,mDrCaseVOBean);
                setResult(RESULT_OK,intent);
                myFinish();
                shortToast("保存成功");
            }
        });

        et_doctor_acvice.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                tv_doctor_acvice_count.setText(et_doctor_acvice.getText().toString().trim().length() + "/"+mMaxLength);
                updateSaveUI();
            }
        });

    }

    /**
     * 更新保存按钮ui
     */
    private void updateSaveUI() {
        if(!hasData &&et_doctor_acvice.getText().toString().trim().length()==0&&
            "无".equals(tv_time.getText().toString().trim())){
            tv_save.setTextColor(getResources().getColor(R.color.c_7f7b7b7b));
        }else {
            tv_save.setTextColor(getResources().getColor(R.color.c_7b7b7b));
        }
    }

    /**
     * 初始化复诊时间对话框
     */
    private void initTimeDialog() {
        creatDialogData();
        mScreenWidth = UtilScreen.getScreenWidthPx(this);
        mTimeDialog = new ConfirmDialog(this, mScreenWidth, R.layout.dialog_diagnosis_time_select, R.style.xc_s_dialog);
        mTimeDialog.setCanceledOnTouchOutside(false);
        Window window = mTimeDialog.getWindow();
        window.setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        tv_dialog_cancel = (TextView) mTimeDialog.findViewById(R.id.tv_dialog_cancel);
        tv_dialog_confirm = (TextView) mTimeDialog.findViewById(R.id.tv_dialog_confirm);

        wv_num = (WheelView) mTimeDialog.findViewById(R.id.wv_num);
        wv_unit = (WheelView) mTimeDialog.findViewById(R.id.wv_unit);
        wv_num.setCyclic(false);//不循环
        wv_unit.setCyclic(false);//不循环
        wv_num.setAdapter(new ArrayTextWheelAdapter(mNumList));
        wv_unit.setAdapter(new ArrayTextWheelAdapter(mUnitList));

        tv_dialog_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mTimeDialog.dismiss();
            }
        });
        tv_dialog_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCurrentNum = mNumList.get(wv_num.getCurrentItem());
                mCurrentUnit = mUnitList.get(wv_unit.getCurrentItem());
                if(mCurrentNum.equals("无")){
                    mCurrentUnit = "";
                    mDrCaseVOBean.setRevisitFalg("2");
                    mDrCaseVOBean.setRevisitNumber("");
                    mDrCaseVOBean.setRevisitDateUnit("");
                    tv_time.setText(mCurrentNum+mCurrentUnit);
                }else {
                    mDrCaseVOBean.setRevisitFalg("1");
                    mDrCaseVOBean.setRevisitNumber(mCurrentNum);
                    mDrCaseVOBean.setRevisitDateUnit(mCurrentUnit);
                    if("月".equals(mCurrentUnit)){
                        tv_time.setText(mCurrentNum+"个"+mCurrentUnit+"后");
                    }else {
                        tv_time.setText(mCurrentNum+mCurrentUnit+"后");
                    }
                    shortToast("复诊时间到来前会提醒患者注意复诊");
                }
                updateSaveUI();
                mTimeDialog.dismiss();
            }
        });

        mTimeDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                if(mCurrentNum.equals("")){
                    wv_num.setCurrentItem(0);
                }else {
                    for(int i=0;i<mNumList.size();i++){
                        if(mCurrentNum.equals(mNumList.get(i))){
                            wv_num.setCurrentItem(i);
                        }
                    }
                }
                if(mCurrentUnit.equals("")){
                    wv_unit.setCurrentItem(0);
                }else {
                    for(int i=0;i<mUnitList.size();i++){
                        if(mCurrentUnit.equals(mUnitList.get(i))){
                            wv_unit.setCurrentItem(i);
                        }
                    }
                }
            }
        });
    }

    /**
     * 创建数据
     */
    private void creatDialogData(){
        mNumList.add("无");
        for (int i = 1; i<13 ;i++){
            mNumList.add(i + "");
        }
        mUnitList.add("天");
        mUnitList.add("周");
        mUnitList.add("月");
    }

    /**
     * 显示返回阻断dialog
     */
    private void showBackDialog(){
        if(mBackDialog == null){
            mBackDialog = new YR_CommonDialog(this,"放弃保存吗?","放弃",
                    "取消") {
                @Override
                public void confirmBtn() {
                    dismiss();
                }

                @Override
                public void cancelBtn() {
                    super.cancelBtn();
                    myFinish();
                }
            };
            mBackDialog.setCanceledOnTouchOutside(false);
        }
        if(mBackDialog != null && !mBackDialog.isShowing()){
            mBackDialog.show();
        }
    }

    @Override
    public void onBackPressed() {
        if(hasData || !TextUtils.isEmpty(et_doctor_acvice.getText().toString().trim())
                ||!"无".equals(tv_time.getText().toString().trim())){
            showBackDialog();
        }else {
            super.onBackPressed();
        }
    }
}
