package com.qlk.ymz.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.contrarywind.listener.OnItemSelectedListener;
import com.contrarywind.view.WheelView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ArrayTextWheelAdapter;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by xiedong on 2017/3/28.
 * 设置咨询费
 */

public class XD_SetConsultingFeesActivity extends DBActivity {

    /**
     * 标题栏
     */
    private XCTitleCommonLayout xc_id_model_titlebar;
    /**
     * 设置价格
     */
    private RelativeLayout rl_set_price;
    /**
     * 价格
     */
    private TextView tv_price;
    /**
     * 批量选择患者
     */
    private RelativeLayout rl_choice_patient;
    /**
     * 选择的患者
     */
    private TextView tv_choice_patient;

    /**
     * 功能介绍
     */
    private RelativeLayout rl_function_explain;
    /**
     * 规则说明
     */
    private WebView wv_explain;
    /**
     * 屏幕宽
     */
    private int mScreenWidth = 720;
    /**
     * 选择价格对话框
     */
    private ConfirmDialog mSetPriceDialog;

    /**
     * 选择价格控件
     */
    private WheelView mWheelView;
    /**
     * 选择价格对话框取消按钮
     */
    private TextView tv_set_price_cancel;
    /**
     * 选择价格对话框确定按钮
     */
    private TextView tv_set_price_confirm;
    /**
     * 当前选择的价格
     */
    private String mCurrentPrice = "0";
    /**
     * 自定义价格对话框
     */
    private ConfirmDialog mCustomPriceDialog;
    /**
     * 自定义价格对话框确定按钮
     */
    private TextView tv_custom_price_confirm;
    /**
     * 自定义价格对话框输入
     */
    private EditText et_custom_price;
    /**
     * 选择的患者集合
     */
    private ArrayList<String> mCheckPatients = new ArrayList<>();

    /**
     * 价格集合
     */
    private List<String> mPrices = new ArrayList<>();
    /**
     * 最大价格
     */
    private long maxPrice;
    /**
     * 最小价格
     */
    private long minPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xd_activity_set_consulting_fees);
        //获取屏幕信息
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        mScreenWidth = dm.widthPixels;
        super.onCreate(savedInstanceState);
        //初始化极限值
        maxPrice = GlobalConfigSP.getLimitValue(GlobalConfigSP.MESSAGE_CHARGE_AMOUNT, 0,
                50000000);
        minPrice = GlobalConfigSP.getLimitValue(GlobalConfigSP.MESSAGE_CHARGE_AMOUNT, 1, 0);
        //初始化价格对话框
        initSetPriceDialog();
        requstBaseInfo();
    }

    /**
     * created by songxin,date：2017-4-10,about：bi,begin
     */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XD_SetConsultingFeesActivity.class);
    }

    /**
     * created by songxin,date：2016-4-10,about：bi,end
     */


    @Override
    public void initWidgets() {
        xc_id_model_titlebar = getViewById(R.id.xc_id_model_titlebar);
        xc_id_model_titlebar.getXc_id_titlebar_left_imageview().setVisibility(View.GONE);
        xc_id_model_titlebar.setTitleCenter(true, "设置咨询费");
        xc_id_model_titlebar.setTitleLeft(true, "取消");
        xc_id_model_titlebar.getXc_id_titlebar_left_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        xc_id_model_titlebar.setTitleRight2(true, 0, "保存");
        rl_set_price = getViewById(R.id.rl_set_price);
        tv_price = getViewById(R.id.tv_price);
        rl_choice_patient = getViewById(R.id.rl_choice_patient);
        tv_choice_patient = getViewById(R.id.tv_choice_patient);
        rl_function_explain = getViewById(R.id.rl_function_explain);
        wv_explain = getViewById(R.id.wv_explain);
    }

    @Override
    public void listeners() {
        xc_id_model_titlebar.getXc_id_titlebar_left_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myFinish();
            }
        });
        xc_id_model_titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(XD_SetConsultingFeesActivity.class, "2", "128", "SetConsultingFees","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end
                saveSetting(UtilString.toLong(mCurrentPrice) * 100);
            }
        });
        rl_set_price.setOnClickListener(this);
        rl_choice_patient.setOnClickListener(this);
        rl_function_explain.setOnClickListener(this);

        wv_explain.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                wv_explain.setVisibility(View.GONE);
            }
        });
    }

    /**
     * 保存修改
     *
     * @param price 分
     */
    private void saveSetting(final long price) {
        if (minPrice > price || price > maxPrice) {
            shortToast("单笔最大限额为" + maxPrice / 100 + "元，请重新输入");
            return;
        }
        if (mCheckPatients.size() < 1) { //没有选择患者
            shortToast("请选择患者");
            return;
        }
        RequestParams params = new RequestParams();
        params.put("charge", price);
        params.put("selectedAll", "0");

        StringBuilder patientIds = new StringBuilder();

        for (String patientId : mCheckPatients) {
            patientIds.append(patientId).append(",");
        }
        params.put("patientIds", patientIds.toString());

        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.consultSetting), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    Intent intent = new Intent();
                    intent.putExtra(JS_MainActivity.ChatNewPatientReceiver.REFRESH_TYPE, "1");
                    intent.setAction(JS_MainActivity.ChatNewPatientReceiver.CHAT_NEW_PATIENT_ACTION);
                    context.sendBroadcast(intent);
                    shortToast("已完成" + mCheckPatients.size() + "个患者的图文咨询付费设置");
                    myFinish();
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(XD_SetConsultingFeesActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_set_price:
                //设置价格
                if (mSetPriceDialog != null) {
                    mSetPriceDialog.show();
                }
                break;
            case R.id.rl_choice_patient:
                //进入批量选择患者
                ToJumpHelp.toJumpBatchSelectPatientsActivity(this, mCheckPatients, 1);
                break;
            case R.id.rl_function_explain:
                //进入功能介绍
                UtilNativeHtml5.toJumpNativeH5(this, UtilNativeHtml5.GRAPHIC_CONSULTING);
                break;
            case R.id.tv_set_price_cancel:
                mSetPriceDialog.dismiss();
                break;
            case R.id.tv_set_price_confirm:
                mSetPriceDialog.dismiss();
                if (isCustomPrice(mPrices.get(mWheelView.getCurrentItem()).replace("元/次",""))) {
                    //弹出自定义价格框
                    showCustomPriceDialog();
                } else {
                    mCurrentPrice = mPrices.get(mWheelView.getCurrentItem()).replace("元/次","");
                    setShowPrice(mCurrentPrice);
                }
                break;
            case R.id.tv_custom_price_confirm:
                //自定义价格对话框确定按钮
                String s = et_custom_price.getText().toString();
                if (!TextUtils.isEmpty(s)) {
                    mCurrentPrice = UtilString.toLong(s) + "";
                    setShowPrice(mCurrentPrice);
                } else {
                    shortToast("自定义价格为" + minPrice / 100 + "-" + maxPrice / 100 + "元");
                }
//                mTempPrice = mCurrentPrice;
                mCustomPriceDialog.dismiss();
                break;
        }
        super.onClick(v);
    }

    /**
     * 显示自定义价格对话框
     */
    private void showCustomPriceDialog() {
        if (mCustomPriceDialog == null) {
            mCustomPriceDialog = new ConfirmDialog(this, mScreenWidth, 55
                    , R.layout.xd_dialog_custom_price, R.style.xc_s_dialog);
            mCustomPriceDialog.setCanceledOnTouchOutside(false);
            Window window = mCustomPriceDialog.getWindow();
            window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
            et_custom_price = (EditText) mCustomPriceDialog.findViewById(R.id.et_custom_price);
            tv_custom_price_confirm = (TextView) mCustomPriceDialog.findViewById(R.id.tv_custom_price_confirm);
            //初始化
            et_custom_price.setHint("自定义价格为" + minPrice / 100 + "-" + maxPrice / 100 + "元");
            //确定按钮监听
            tv_custom_price_confirm.setOnClickListener(this);
            mCustomPriceDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    et_custom_price.setText("");
                }
            });
            mCustomPriceDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialog) {
                    //获取焦点
                    et_custom_price.setFocusableInTouchMode(true);
                    et_custom_price.requestFocus();
                    //弹出软键盘
                    UtilInputMethod.openInputMethod(et_custom_price, XD_SetConsultingFeesActivity
                            .this);
                }
            });
        }

        mCustomPriceDialog.show();
    }

    /**
     * 设置显示的价格
     *
     * @param showPrice
     */
    private void setShowPrice(String showPrice) {
        long price = UtilString.toLong(showPrice);
        if (price > 0) {
            tv_price.setText(showPrice + "元/次");
        } else {
            tv_price.setText("免费");
        }

    }


    /**
     * 请求规则说明
     */
    private void requstBaseInfo() {
        initBaseInfo();
    }

    /**
     * 初始化数据和显示
     */
    private void initBaseInfo() {
        /*//获取上次保存的价格
        long price = UtilString.toLong(UtilSP.getSaveConsultingFees());
        mCurrentPrice = price + "";
        mTempPrice = price + "";*/
        setShowPrice(mCurrentPrice);

        WebSettings wSettings = wv_explain.getSettings();
        wSettings.setJavaScriptEnabled(true);
        wSettings.setBuiltInZoomControls(true);
        wSettings.setDisplayZoomControls(false);
        wSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); // 不进行缓存，总是使用网络数据
        String url = GlobalConfigSP.getHtml5NativePath() + "/html/" + UtilNativeHtml5.SINGLE_PAY_SETTING_EXPLAIN;
        if (UtilFiles.fileIsExists(url)) {
            url = GlobalConfigSP.getHtml5NativePath() + "/html/" + UtilNativeHtml5.SINGLE_PAY_SETTING_EXPLAIN;
            wv_explain.loadUrl("file://" + url);
        }
        wv_explain.setBackgroundColor(0);

    }

    /**
     * 初始化选择价格对话框
     */
    private void initSetPriceDialog() {
        String[] consultChargeList = GlobalConfigSP.getConsultChargeList();
        mPrices.add("自定义");
        if (consultChargeList != null) {
            for (int i = 0; i < consultChargeList.length; i++) {
                long price = UtilString.toLong(consultChargeList[i]) / 100;
                mPrices.add(price + "元/次");
            }
        }
        mSetPriceDialog = new ConfirmDialog(this, mScreenWidth, R.layout
                .dialog_roll_select, R.style.xc_s_dialog);
        mSetPriceDialog.setCanceledOnTouchOutside(false);
        Window window = mSetPriceDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);  //此处可以设置dialog显示的位置
        window.setWindowAnimations(R.style.dialog_from_bottom_up_exit_bottom);
        mWheelView = (WheelView) mSetPriceDialog.findViewById(R.id.wheelview);
        mWheelView.setCyclic(false);
        tv_set_price_cancel = (TextView) mSetPriceDialog.findViewById(R.id.tv_set_price_cancel);
        tv_set_price_confirm = (TextView) mSetPriceDialog.findViewById(R.id.tv_set_price_confirm);
        tv_set_price_cancel.setOnClickListener(this);
        tv_set_price_confirm.setOnClickListener(this);
        mWheelView.setAdapter(new ArrayTextWheelAdapter(mPrices));

        mSetPriceDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                mWheelView.setCurrentItem(0);

            }
        });
    }

    /**
     * 判断是否为自定义价格
     *
     * @param currentPrice
     * @return
     */
    private boolean isCustomPrice(String currentPrice) {
        if ("自定义".equals(currentPrice)) {
            return true;
        } else {
            for (int i = 0; i < mPrices.size(); i++) {
                if (currentPrice.equals(mPrices.get(i).replace("元/次", ""))) {
                    return false;
                }
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (RESULT_OK == resultCode) {
            switch (requestCode) {
                case 1:
                    mCheckPatients = data.getStringArrayListExtra(XD_BatchSelctPatientsActivity.SELECT_INFO);
                    if (mCheckPatients.size() > 0) {
                        tv_choice_patient.setTextColor(getResources().getColor(R.color.c_e2231a));
                        if (mCheckPatients.size() > 999) {
                            tv_choice_patient.setText("99+");
                        } else {
                            tv_choice_patient.setText(mCheckPatients.size() + "");
                        }
                    }
                    break;
            }
        }
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != wv_explain) {
            wv_explain.destroy();
            wv_explain.removeAllViews();
        }
    }
}
