package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.YY_FeedbackRecordBean;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import java.util.List;

/**
 * @author shuYanYi on 2016/11/08.
 * @description 随访记录列表里不同患者的随访信息
 */
public class YY_FeedbackRecordInfoAdapter extends XCBaseAdapter<YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean.VisitInfoBean> {

    public YY_FeedbackRecordInfoAdapter(Context context, List<YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean.VisitInfoBean> list){
        super(context,list);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.yy_item_feedback_record_info,null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }
        YY_FeedbackRecordBean.DataBean.ResultBean.VisitInfoInMonthBean.VisitInfoBean bean = list.get(position);
        if(position == 0){
            holder.v_line.setVisibility(View.GONE);
        }

        holder.tv_patient_name.setText(bean.getPatientName());
        holder.tv_datetime.setText(bean.getVisitTime());

        //右侧随访图标
        boolean hadFill = bean.getVisitStatus() == YY_FeedbackRecordBean.VISITSTATUS_HAD_FILL;
        UtilViewShow.setGone(hadFill,holder.ll_had_feed);
        UtilViewShow.setGone(!hadFill,holder.ll_not_feed);
        return convertView;
    }


    private class ViewHolder {
        /** 患者姓名*/
        private TextView tv_patient_name;
        /** 时间*/
        private TextView tv_datetime;
        /** 已反馈的图标*/
        private View ll_had_feed;
         /** 未反馈的图标*/
        private View ll_not_feed;
        /** 分割线*/
        private View v_line;
        public ViewHolder(View convertView){
            tv_patient_name = (TextView)convertView.findViewById(R.id.tv_patient_name);
            tv_datetime = (TextView)convertView.findViewById(R.id.tv_datetime);
            ll_had_feed = convertView.findViewById(R.id.ll_had_feed);
            ll_not_feed = convertView.findViewById(R.id.ll_not_feed);
            v_line = convertView.findViewById(R.id.v_line);
        }
    }
}
