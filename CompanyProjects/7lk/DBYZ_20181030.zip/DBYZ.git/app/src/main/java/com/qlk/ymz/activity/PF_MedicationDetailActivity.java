package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.PF_MedicationDetailAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.model.PF_medicationDetailBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.view.XCRoundedImageView;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 *
 *  用药详情
 * @author zhangpengfei
 * @version 2.0
 *
 * @version 2.6.0  改成h5
 */
public class PF_MedicationDetailActivity extends DBActivity {
    XCTitleCommonLayout titleLayout;
    /**患者信息*/
    private RelativeLayout pr_id_chat_setting_patient_detail;
    /**患者头像*/
    private XCRoundedImageView pr_id_chat_setting_header;
    /**患者姓名*/
    private TextView pr_id_chat_setting_name;
    /**患者性别*/
    private TextView pr_id_chat_setting_sex;
    /**患者年龄*/
    private TextView pr_id_chat_setting_age;
    /**用药内容*/
    private ListView pf_id_medication_detail_content;
    /** 患者名字 */
    public static final String PATIENT_NAME = "patientName";
    /**总额布局*/
    private View footerView;
    /**总额*/
    private TextView pf_id_footer_medication_detail_price;
    /**时间*/
    private TextView pf_id_footer_medication_detail_time;
    private PF_MedicationDetailAdapter adapter;
    private List<PF_medicationDetailBean.DataEntity.SkusEntity> medicationDetailList;
    public static final int TO_PATIENT_DETAIL = 232;
    private JS_ChatListModel chatListModel;
    /** 单号id */
    private String orderId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_activity_medication_detail);
        super.onCreate(savedInstanceState);

        titleLayout.setTitleLeft(true, "");
        titleLayout.setTitleCenter(true, "用药详情");

    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_MedicationDetailActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        if (null != getIntent()){
            orderId = getIntent().getStringExtra(YR_MedicationRecordActivity.ORDERID);
        }
        medicationDetailList = new ArrayList();
        titleLayout = getViewById(R.id.xc_id_model_titlebar);
        pr_id_chat_setting_patient_detail = getViewById(R.id.pr_id_chat_setting_patient_detail);
        pr_id_chat_setting_header = getViewById(R.id.pr_id_chat_setting_header);
        pr_id_chat_setting_name = getViewById(R.id.pr_id_chat_setting_name);
        pr_id_chat_setting_sex = getViewById(R.id.pr_id_chat_setting_sex);
        pr_id_chat_setting_age = getViewById(R.id.pr_id_chat_setting_age);
        pf_id_medication_detail_content = getViewById(R.id.pf_id_medication_detail_content);

        footerView = LayoutInflater.from(this).inflate(R.layout.pf_footer_medication_detail, null);
        pf_id_footer_medication_detail_price = (TextView)footerView.findViewById(R.id.pf_id_footer_medication_detail_price);
        pf_id_footer_medication_detail_time = (TextView)footerView.findViewById(R.id.pf_id_footer_medication_detail_time);
        pf_id_medication_detail_content.addFooterView(footerView);
        footerView.setVisibility(View.GONE);
        adapter = new PF_MedicationDetailAdapter(this,medicationDetailList);
        pf_id_medication_detail_content.setAdapter(adapter);
        pf_id_medication_detail_content.setVisibility(View.GONE);
        if (!UtilString.isBlank(orderId)){
            requestData();
        }
    }

    @Override
    public void listeners() {
        pr_id_chat_setting_patient_detail.setOnClickListener(this);

    }

    @Override
    public void onNetRefresh() {
        if (!UtilString.isBlank(orderId)){
            requestData();
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.pr_id_chat_setting_patient_detail:
                //modify by xilinch 2016.3.8修复jira 2049 bug
                if(chatListModel != null){
                    Intent intent = new Intent();
                    intent.setClass(this, XL_PatientInfoAActivity.class);
//                intent.putExtra(UtilSP.CHAT_PARAMS_MODEL, chatListModel);
                    intent.putExtra(CommonConfig.PATIENT_ID, chatListModel.getUserPatient().getPatientId());
                    myStartActivityForResult(intent,TO_PATIENT_DETAIL);
                } else {
                    shortToast("对不起,获取数据异常,请重新进入页面或者检查网络!");
                }
                //end---
                break;

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (RESULT_OK == resultCode){
            switch (requestCode){
                //患者详情返回的
                case TO_PATIENT_DETAIL:
                    if(data != null && data.getExtras()!= null){
                        String name = data.getExtras().getString(PATIENT_NAME);
                        if(!TextUtils.isEmpty(name) && pr_id_chat_setting_name != null){
                            pr_id_chat_setting_name.setText(name);
                        }
                    }
                    break;
            }
        }
    }
    private void requestData() {
        RequestParams params = new RequestParams();
        params.put("id", orderId);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.medicationRecom_detail), params, new XCHttpResponseHandler<PF_medicationDetailBean>(this, PF_medicationDetailBean.class) {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<PF_medicationDetailBean.DataEntity> objLists = mResultModel.getData();
                    if (null != objLists && objLists.size() > 0) {
                        if (null != objLists.get(0)) {
                            chatListModel = JS_ChatListDB.getInstance(PF_MedicationDetailActivity.this, UtilSP.getUserId()).getPatientInfo(objLists.get(0).getPatientId());
                            if (!UtilString.isBlank(chatListModel.getUserPatient().getPatientId())){
                                pr_id_chat_setting_patient_detail.setVisibility(View.VISIBLE);
                                //名字
                                if (!UtilString.isBlank(chatListModel.getUserPatient().getPatientDisplayName())) {
                                    pr_id_chat_setting_name.setVisibility(View.VISIBLE);
                                    pr_id_chat_setting_name.setText(chatListModel.getUserPatient().getPatientDisplayName());
                                } else {
                                    pr_id_chat_setting_name.setVisibility(View.GONE);
                                }
                                //年龄
                                if (!UtilString.isBlank(chatListModel.getUserPatient().getPatientAge())) {
                                    pr_id_chat_setting_age.setVisibility(View.VISIBLE);
                                    pr_id_chat_setting_age.setText(chatListModel.getUserPatient().getPatientAge().concat("岁"));
                                } else {
                                    pr_id_chat_setting_age.setVisibility(View.GONE);
                                }
                                //性别
                                if (CommonConfig.GENDER_MALE.equals(chatListModel.getUserPatient().getPatientGender())) {
                                    pr_id_chat_setting_sex.setBackgroundResource(R.mipmap.icon_patient_man);
                                    pr_id_chat_setting_sex.setVisibility(View.VISIBLE);
                                } else if (CommonConfig.GENDER_FEMALE.equals(chatListModel.getUserPatient().getPatientGender())) {
                                    pr_id_chat_setting_sex.setBackgroundResource(R.mipmap.icon_patient_women);
                                    pr_id_chat_setting_sex.setVisibility(View.VISIBLE);
                                } else {
                                    pr_id_chat_setting_sex.setVisibility(View.GONE);
                                }
                                //头像
                                String patientIcon = chatListModel.getUserPatient().getPatientImgHead();
                                if (!UtilString.isBlank(patientIcon) && URLUtil.isValidUrl(patientIcon)) {
                                    XCApplication.displayImage(patientIcon, pr_id_chat_setting_header, XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.xc_d_chat_patient_default));
                                } else {
                                    pr_id_chat_setting_header.setImageResource(R.mipmap.xc_d_chat_patient_default);
                                }
                            }else{
                                pr_id_chat_setting_patient_detail.setVisibility(View.GONE);
                            }
                            if (null != objLists.get(0).getSkus() && objLists.get(0).getSkus().size() >0){
                                medicationDetailList = objLists.get(0).getSkus();
                                adapter.setmList(medicationDetailList);
                                String price  = "¥ " + StringUtils.getMoneyString(objLists.get(0).getTotalSalePrice());
                                pf_id_footer_medication_detail_price.setText(Html.fromHtml(price));
                                pf_id_footer_medication_detail_time.setText("推荐用药时间:  " + UtilString.f(objLists.get(0).getCreatedAt()));
                                footerView.setVisibility(View.VISIBLE);
                            }
                            pf_id_medication_detail_content.setVisibility(View.VISIBLE);
                        }
                    }
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(PF_MedicationDetailActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
        });
    }


}
