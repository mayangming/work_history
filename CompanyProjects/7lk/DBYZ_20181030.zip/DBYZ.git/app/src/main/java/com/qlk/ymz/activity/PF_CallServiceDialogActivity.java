package com.qlk.ymz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * 联系客服
 * @author zhangpengfei
 * @version 2.0
 */
public class PF_CallServiceDialogActivity extends DBActivity{
    private LinearLayout pf_id_call_service_rl;
    public static final String CALL_PHONE = "call_phone";
    /**内容*/
    private TextView pf_id_call_service_msg;
    /**@客服电话*/
    private TextView pf_id_call_service_phone;
    /**取消*/
    private TextView pf_id_call_service_cancel;
    private String phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_call_service_dialog);
        super.onCreate(savedInstanceState);
        initWidgets();
        listeners();

    }
    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_CallServiceDialogActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */
    public void initWidgets() {
        pf_id_call_service_rl = (LinearLayout)findViewById(R.id.pf_id_call_service_rl);
        pf_id_call_service_msg = (TextView)findViewById(R.id.pf_id_call_service_msg);
        pf_id_call_service_phone = (TextView)findViewById(R.id.pf_id_call_service_phone);
        pf_id_call_service_cancel = (TextView)findViewById(R.id.pf_id_call_service_cancel);
        pf_id_call_service_msg.setText(UtilSP.getName() + "医生，你好！如有任何疑问请与我联系；我的工作时间：" + GlobalConfigSP.getServerTime());
        if (null != getIntent()){
            phone = getIntent().getStringExtra(CALL_PHONE);
            if (!UtilString.isBlank(phone)){
                pf_id_call_service_phone.setText(phone);
            }
        }
        if (UtilString.isBlank(phone)){
            pf_id_call_service_phone.setText(GlobalConfigSP.getCustomerServPhone());
        }
        pf_id_call_service_phone.setMovementMethod(LinkMovementMethod.getInstance());
    }

    public void listeners() {
        pf_id_call_service_cancel.setOnClickListener(this);
        pf_id_call_service_rl.setOnClickListener(this);
        pf_id_call_service_phone.setOnClickListener(this);

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(0, R.anim.pop_down);
    }

    @Override
    public void onClick(View view) {
        if (view == pf_id_call_service_cancel){
            onBackPressed();
        }else if (view == pf_id_call_service_rl){
            onBackPressed();
        }else if (view == pf_id_call_service_phone){
            if (UtilString.isBlank(phone)){
                phone = GlobalConfigSP.getCustomerServPhone();
            }
            Uri uri = Uri.parse("tel:" + phone);
            Intent intent = new Intent(Intent.ACTION_DIAL, uri);
            myStartActivity(intent);
        }
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (null != intent){
            phone = intent.getStringExtra(CALL_PHONE);
            if (!UtilString.isBlank(phone)){
                pf_id_call_service_phone.setText(phone);
            }
        }
    }
}
