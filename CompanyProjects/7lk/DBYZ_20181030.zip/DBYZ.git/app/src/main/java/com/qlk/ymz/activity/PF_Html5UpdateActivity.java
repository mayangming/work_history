package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.DownloadHelper;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilLoginOut;
import com.qlk.ymz.util.UtilZip;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.upgrade.YR_UpgradeDialogActivity_v2;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonParse;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilSystem;

import org.apache.http.Header;

import java.io.File;
import java.io.IOException;

/**
 * h5升级
 * @author zhangpengfei.
 * @version 2.5
 */
public class PF_Html5UpdateActivity extends DBActivity {
    /**解压assets目录下文件完毕*/
    public static final int UNZIP_ASSETS_OVER = 0;
    /**下一个页面*/
    public static final int NEXT_PAGE = 1;
    /**页面标识*/
    public static final String PAGE_Tag = "pageTag";
    /**哪个页面过来的 1 app升级页面过来的 0 默认*/
    private int pageTag = 0;
    /**等待对话框*/
    private LinearLayout pf_id_html5_update_loading;
    /**横版等待对话框*/
    private RelativeLayout Horizontal_html5_update_loading;
    private ProgressBar pb_html5_update_progress;
    /**提示文案*/
    private TextView xc_id_dialog_sys_v_textview;
    /**进度*/
    private TextView progress_tv;
    /**html5文件*/
    private File htmlFile;
    /**html5路径*/
    private String htmlpath;
    /**当前进不*/
    private int currentProgress = 0;
    public static final String H5_FILE_NAME = "/config";
    /**下载h5zip包*/
    private DownloadHelper downloadHelper;
    /**升级以后是否第一次进入h5页面(true 不回欢迎页,直接进入首页或者登录页面)*/
    private boolean isFirstOpen = false;
    private String html5PackageName = "doctor_app.zip";
    private Handler handler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case UNZIP_ASSETS_OVER:
                    checkH5Update();
                    break;
                case NEXT_PAGE:
                    progress_tv.setText("100%");
                    pb_html5_update_progress.setProgress(100);
                    //通过读取本地文件来保存h5版本
                    String html5Version = readNativeH5Version(htmlFile.getParent() + H5_FILE_NAME);
                    //保存h5版本
                    GlobalConfigSP.setHtml5Version(html5Version);
                    GlobalConfigSP.setHtml5NativePath(htmlFile.getParent());
                    //update by cyr on 2017-4-19 添加是否处在安装页面，如果是在安装页面，不走正常逻辑，并且关闭当前页面
                    if (!YR_UpgradeDialogActivity_v2.isInstall) {
                        if (isFirstOpen){
                            if (UtilSP.isLogin()) {
                                //首页
                                Intent intent = new Intent(PF_Html5UpdateActivity.this, JS_MainActivity.class);
                                intent.putExtra(JS_MainActivity.TAB_TAG,JS_MainActivity.TAB_HOME);
                                intent.putExtra(JS_MainActivity.FROM_PAGE,JS_MainActivity.FROM_H5UPDATE);
                                myStartActivity(intent);
                            }else{
                                UtilLoginOut.loginOut(PF_Html5UpdateActivity.this);
                                XCApplication.finishAllActivity();
                                myStartActivity(LoginAndRegisterActivity.class);
                            }
                            sendBroadcast(new Intent(SK_LoadActivity.JUMP_TO_MAIN));
                        }else {
                            SK_LoadActivity.isupdate = 1;
                        }
                    }else {
                        // add by cyr on 2016-9-2 同时关闭启动页 start
                        sendBroadcast(new Intent(SK_LoadActivity.JUMP_TO_MAIN));
                        // add by cyr on 2016-9-2 同时关闭启动页 end
                    }
                    finish();
//                    finishLoadPage();
                    overridePendingTransition(0, R.anim.pop_down);
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.pf_activity_html5_update);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PF_Html5UpdateActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    /**
     * 启动页面
     * @param context 上下文对象
     * @param code 哪个页面过来的 1 app升级页面过来的 0 默认
     */
    public static void launch(Activity context, int code) {
        Intent intent = new Intent(context, PF_Html5UpdateActivity.class);
        intent.putExtra(PAGE_Tag,code);
        context.startActivity(intent);
        context.overridePendingTransition(R.anim.pop_up, R.anim.pop_down);
    }

    @Override
    public void initWidgets() {
        if (null != getIntent()){
            pageTag = getIntent().getIntExtra(PAGE_Tag,0);
        }
        pf_id_html5_update_loading = getViewById(R.id.pf_id_html5_update_loading);
        progress_tv = getViewById(R.id.progress_tv);
        xc_id_dialog_sys_v_textview = getViewById(R.id.xc_id_dialog_sys_v_textview);
        Horizontal_html5_update_loading = getViewById(R.id.Horizontal_html5_update_loading);
        pb_html5_update_progress = getViewById(R.id.pb_html5_update_progress);
        pb_html5_update_progress.setProgress(0);
        xc_id_dialog_sys_v_textview.setVisibility(View.VISIBLE);
        xc_id_dialog_sys_v_textview.setText("数据更新中...");
        progress_tv.setText("0%");
        pf_id_html5_update_loading.setAlpha(0.8f);

        //在sd卡根目录创建html5zip文件
//        htmlFile = xcioAndroid.createFileInAndroid("html5", "h5.zip", this);
        //在项目根目录创建html5zip文件
        try {
            htmlFile = UtilFiles.createFileInside("html5", "h5.zip", this);
            downHtml();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void listeners() {

    }

    @Override
    public void onNetRefresh() {

    }
    /**
     * 检测assets有没有基本配置
     */
    private void downHtml(){
        htmlpath = htmlFile.getParent() + "/assets/";
        // 若当前版本等于本地版本，则不解压         sk 修改于 2016年8月18日23:27:43
        if(UtilSystem.getVersionName(this).equals(GlobalConfigSP.getApp_version())){
            handler.sendEmptyMessage(UNZIP_ASSETS_OVER);
        }else{
            isFirstOpen = true;
            GlobalConfigSP.setApp_version(UtilSystem.getVersionName(this));
            new Thread(new Runnable() {
                @Override
                public void run() {
                    UtilZip.unZip(PF_Html5UpdateActivity.this, html5PackageName, htmlFile.getParent(), true);
                    //通过读取本地文件来保存h5版本
                    String html5Version = readNativeH5Version(htmlFile.getParent() + H5_FILE_NAME);
                    //保存h5版本
                    GlobalConfigSP.setHtml5Version(html5Version);
                    handler.sendEmptyMessage(UNZIP_ASSETS_OVER);
                }
            }).start();
        }
    }
    /**
     *
     * 检查html文件是否需要升级
     */
    private void checkH5Update(){
        RequestParams params = new RequestParams();
        //h5版本
        params.put("h5_v", UtilString.isBlank(GlobalConfigSP.getHtml5Version()) ? "1.0" : GlobalConfigSP.getHtml5Version());
        //app版本
        params.put("app_v", UtilSystem.getVersionName(this));
        XCHttpAsyn.getAsyn(false, this, AppConfig.getH5Url(AppConfig.html5_update), params, new XCHttpResponseHandler() {

            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);

                if (result_boolean) {
                    XCJsonBean data = (XCJsonBean) result_bean.get("data");
                    String url = data.getString("zip");
//                    String html5Version = data.getString("h5_v");
                    //如果url为空的话,不需要升级
                    if (!UtilString.isBlank(url)){
                        if (pageTag == 1) {
                            pf_id_html5_update_loading.setVisibility(View.GONE);
                            Horizontal_html5_update_loading.setVisibility(View.VISIBLE);
                        }else{
                            pf_id_html5_update_loading.setVisibility(View.VISIBLE);
                            Horizontal_html5_update_loading.setVisibility(View.GONE);

                        }
                        downloadHelper = new DownloadHelper(url, htmlFile);
                        new Thread(downloadHelper).start();
                        downloadHelper.setDownloadListener(new DownloadHelper.DownloadListener() {
                            @Override
                            public void downloadFinished(final File file) {
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        UtilZip.unzip(PF_Html5UpdateActivity.this, file, htmlFile.getParent() ,true);
                                        handler.sendEmptyMessage(NEXT_PAGE);
                                    }
                                }).start();
                            }

                            @Override
                            public void netFail(File file) {
                                handler.sendEmptyMessage(NEXT_PAGE);
                            }

                            @Override
                            public void downLoadProgress(int progress, long total, long current) {
//                                XCApplication.base_log.i(XCConfig.TAG_HTML5, "下载进度: " +progress + ";总K: " + total + ";下载K: " + current);
                                currentProgress = progress;
                                //下载大于99的时候,强制改成99,留1用来解压缩
                                if (currentProgress > 99){
                                    currentProgress = 99;
                                }
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        progress_tv.setText(currentProgress +"%");
                                        pb_html5_update_progress.setProgress(currentProgress + 5);
                                    }
                                });


                            }
                        });
                    }else {
                        handler.sendEmptyMessage(NEXT_PAGE);
                    }
                }else {
                    handler.sendEmptyMessage(NEXT_PAGE);
                }
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                handler.sendEmptyMessage(NEXT_PAGE);
            }
        });
    }

    @Override
    public void onBackPressed() {
    }

    /**
     * 读取本地文件,并进行解析
     * @param name
     * @return
     */
    private String readNativeH5Version(String name){
        String h5_V = GlobalConfigSP.getHtml5Version(); // 读取当前版本号，sk 添加于 2016年8月18日23:29:02
        String h5Json = UtilFiles.readFile(name);
        if (!UtilString.isBlank(h5Json)){
            XCJsonBean result_bean = XCJsonParse.getJsonParseData(h5Json);
            if (null == result_bean) {
                return h5_V;
            }
            h5_V = result_bean.getString("h5_v");
        }
        XCApplication.base_log.i(XCConfig.TAG_HTML5, "h5本地版本: " + h5_V);
        return h5_V;
    }

//    /**
//     * fininsh loading页，(解决内存不足系统重新启动后，退出首页又被重启的bug)
//     */
//    private void finishLoadPage(){
//        Stack<Activity> stack = ((XCApplication) getApplication()).getStack();
//        for (Activity activity : stack) {
//            if (activity != null && activity instanceof SK_LoadActivity) {
//                activity.finish();
//                break;
//            }
//        }
//    }
}
