package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 聊天详情  医生 宣教功能
 */
public class XC_ChatRightPublicityEducationHolder extends XC_ChatRightBaseHolder  {
    public TextView xc_id_adapter_right_publicity_education_title;
    public TextView xc_id_right_publicity_education_content;
    public TextView xc_id_right_publicity_education_read_status;
    public View id_right_publicity_education_layout;
    public XC_ChatRightPublicityEducationHolder(View convertView) {
        super(convertView);
        id_right_publicity_education_layout = convertView.findViewById(R.id.id_right_publicity_education_layout);
        xc_id_adapter_right_publicity_education_title = (TextView) convertView.findViewById(R.id.id_right_publicity_education_title);
        xc_id_right_publicity_education_content = (TextView) convertView.findViewById(R.id.id_right_publicity_education_content);
        xc_id_right_publicity_education_read_status = (TextView) convertView.findViewById(R.id.id_right_publicity_education_read_status);
    }
}
