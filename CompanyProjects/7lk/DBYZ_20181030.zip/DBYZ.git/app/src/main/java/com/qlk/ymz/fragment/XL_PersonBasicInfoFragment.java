package com.qlk.ymz.fragment;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshScrollView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.activity.XL_PatientInfoBasicActivity;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.modelflag.XL_PatientBasicBean;
import com.qlk.ymz.parse.Parse2PatientBasicBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.UtilCollection;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.http.XCIHttpResult;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.List;

/**
 * Created by xilinch on 2015/6/22.
 *
 * @version 1.0
 * @description 患者基本信息fragment
 */
public class XL_PersonBasicInfoFragment extends DBFragment implements XCIHttpResult {
    /**
     * 婚姻状态
     */
    TextView xc_id_personbasicinfo_tv_marry;
    /**
     * 身高
     */
    TextView xc_id_personbasicinfo_tv_height;
    /**
     * 体重
     */
    TextView xc_id_personbasicinfo_tv_weight;
    /**
     * 过敏史
     */
    TextView xc_id_personbasicinfo_tv_allergy;
    /**
     * 疾病历史
     */
    TextView xc_id_personbasicinfo_tv_anamnesis;
    /**
     * 家庭病史
     */
    TextView xc_id_personbasicinfo_tv_family_history;
    /**
     * 遗传病史
     */
    TextView xc_id_personbasicinfo_tv_genetic_history;
    /**
     * 抽烟
     */
    TextView xc_id_personbasicinfo_tv_smoke;
    /**
     * 是否饮酒
     */
    TextView xc_id_personbasicinfo_tv_drink;
    /**
     * 上下啦刷新
     */
    public PullToRefreshScrollView pullToRefreshScrollView;
    /**
     * 患者id不可少哦
     */
    private String mPatientId = "";
    /**
     * 患者基本信息
     */
    private XL_PatientBasicBean petientBasicBeanFlag = new XL_PatientBasicBean();
    public static final String PATIENT_INFO = "patient_info";
    /**
     * 采用患者信息控件
     */
    private TextView make_patient_tv;
    /**
     * 无网络时显示的界面
     */
    public RelativeLayout xc_id_model_no_net;
    /**
     * 提示布局
     */
    private LinearLayout tipLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return init(inflater, R.layout.xl_fragment_personbasicinfo);
    }

    @Override
    public void initWidgets() {
        xc_id_personbasicinfo_tv_marry = getViewById(R.id.xc_id_personbasicinfo_tv_marry);
        xc_id_personbasicinfo_tv_height = getViewById(R.id.xc_id_personbasicinfo_tv_height);
        xc_id_personbasicinfo_tv_weight = getViewById(R.id.xc_id_personbasicinfo_tv_weight);
        xc_id_personbasicinfo_tv_allergy = getViewById(R.id.xc_id_personbasicinfo_tv_allergy);
        xc_id_personbasicinfo_tv_anamnesis = getViewById(R.id.xc_id_personbasicinfo_tv_anamnesis);
        xc_id_personbasicinfo_tv_family_history = getViewById(R.id.xc_id_personbasicinfo_tv_family_history);
        xc_id_personbasicinfo_tv_genetic_history = getViewById(R.id.xc_id_personbasicinfo_tv_genetic_history);
        xc_id_personbasicinfo_tv_smoke = getViewById(R.id.xc_id_personbasicinfo_tv_smoke);
        xc_id_personbasicinfo_tv_drink = getViewById(R.id.xc_id_personbasicinfo_tv_drink);
        pullToRefreshScrollView = getViewById(R.id.pullToRefreshScrollView);
        pullToRefreshScrollView.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
        make_patient_tv = getViewById(R.id.make_patient_text);
        xc_id_model_no_net = getViewById(R.id.xc_id_model_no_net);
        tipLayout = getViewById(R.id.tip_layout);
        getViewById(R.id.xc_id_no_net_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onNetRefresh();
            }
        });
        requestData();
    }

    public void setPatientId(String patientId) {
        mPatientId = patientId;
    }

    @Override
    public void listeners() {
        pullToRefreshScrollView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ScrollView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ScrollView> refreshView) {
                requestData();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ScrollView> refreshView) {

            }
        });
        make_patient_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getActivity() instanceof XL_PatientInfoBasicActivity) {
                    ((XL_PatientInfoBasicActivity) getActivity()).setResultForEditPatientBasicInfo(petientBasicBeanFlag);
                }
            }
        });
    }

    /**
     * 请求个人基本信息
     */
    private void requestData() {
        if (TextUtils.isEmpty(mPatientId)) {
            pullToRefreshScrollView.onRefreshComplete();
            return;
        }
        RequestParams params = new RequestParams();
        params.put("patientId", mPatientId);
        XCHttpAsyn.postAsyn(getActivity(), AppConfig.getHostUrl(AppConfig.patient_basic_disease), params, new XCHttpResponseHandler(this) {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    petientBasicBeanFlag = Parse2PatientBasicBean.parsePatientBasic(result_bean,false);
                    List<XCJsonBean> result_list = result_bean.getList(petientBasicBeanFlag.data);
                    if (!TextUtils.isEmpty(petientBasicBeanFlag.getMaritalStatus()) || !TextUtils.isEmpty(petientBasicBeanFlag.getHeight()) || !TextUtils.isEmpty(petientBasicBeanFlag.getWeight())
                            || !TextUtils.isEmpty(petientBasicBeanFlag.getMedicationAllergy()) || !TextUtils.isEmpty(petientBasicBeanFlag.getFamilyHistory()) || !TextUtils.isEmpty(petientBasicBeanFlag.getPastDisease())
                            || !TextUtils.isEmpty(petientBasicBeanFlag.getHereditaryDisease()) || !TextUtils.isEmpty(petientBasicBeanFlag.getSmokeHistory()) || !TextUtils.isEmpty(petientBasicBeanFlag.getDrinkHstory())) {
                        make_patient_tv.setVisibility(View.VISIBLE);
                        tipLayout.setVisibility(View.VISIBLE);
                    } else {
                        make_patient_tv.setVisibility(View.GONE);
                        tipLayout.setVisibility(View.GONE);
                    }
                    showPatientInfo(result_list);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (pullToRefreshScrollView != null) {
                    pullToRefreshScrollView.onRefreshComplete();
                }

                // 对账户冻结情况的判断处理
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(getActivity(),
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }

        });
    }

    /**
     * 显示患者信息界面
     *
     * @param result_list 患者信息
     */
    private void showPatientInfo(List<XCJsonBean> result_list) {
        if (UtilCollection.isBlank(result_list)) {
            shortToast("数据错误!");
            return;
        }
        if (petientBasicBeanFlag != null) {
            String familyHistory = petientBasicBeanFlag.getFamilyHistory();
            if (!TextUtils.isEmpty(familyHistory)) {
                familyHistory = familyHistory.trim();
            }
//            familyHistory = familyHistory.replaceAll(";",";\n");

            String smokeHistory = petientBasicBeanFlag.getSmokeHistory();
            if (!TextUtils.isEmpty(smokeHistory)) {
                smokeHistory = smokeHistory.trim();
            }
//            smokeHistory = smokeHistory.replaceAll(";",";\n");

            String drinkHstory = petientBasicBeanFlag.getDrinkHstory();
            if (!TextUtils.isEmpty(drinkHstory)) {
                drinkHstory = drinkHstory.trim();
            }
//            drinkHstory = drinkHstory.replaceAll(";",";\n");

            String pastDisease = petientBasicBeanFlag.getPastDisease();
            if (!TextUtils.isEmpty(pastDisease)) {
                pastDisease = pastDisease.trim();
            }
//            pastDisease = pastDisease.replaceAll(";",";\n");


            // 身高
            String height = petientBasicBeanFlag.getHeight();
            if (!TextUtils.isEmpty(height)) {
                height = height.trim();
            }
//            height = height.replaceAll(";",";\n");

            // 体重
            String weight = petientBasicBeanFlag.getWeight();
            if (!TextUtils.isEmpty(weight)) {
                weight = weight.trim();
            }
//            weight = weight.replaceAll(";",";\n");

            String medicationAllergy = petientBasicBeanFlag.getMedicationAllergy();
            if (!TextUtils.isEmpty(medicationAllergy)) {
                medicationAllergy = medicationAllergy.trim();
            }
//            medicationAllergy = medicationAllergy.replaceAll(";",";\n");

            String hereditaryDisease = petientBasicBeanFlag.getHereditaryDisease();
            if (!TextUtils.isEmpty(hereditaryDisease)) {
                hereditaryDisease = hereditaryDisease.trim();
            }
//            hereditaryDisease = hereditaryDisease.replaceAll(";",";\n");

            String maritalStatus = petientBasicBeanFlag.getMaritalStatus();

            xc_id_personbasicinfo_tv_height.setText(height);
            xc_id_personbasicinfo_tv_weight.setText(weight);
            xc_id_personbasicinfo_tv_allergy.setText(medicationAllergy);
            xc_id_personbasicinfo_tv_anamnesis.setText(pastDisease);
            xc_id_personbasicinfo_tv_drink.setText(drinkHstory);
            xc_id_personbasicinfo_tv_family_history.setText(familyHistory);
            xc_id_personbasicinfo_tv_genetic_history.setText(hereditaryDisease);
            xc_id_personbasicinfo_tv_smoke.setText(smokeHistory);
            if ("0".equals(maritalStatus)) {
                xc_id_personbasicinfo_tv_marry.setText("未婚");
            } else if ("1".equals(maritalStatus)) {
                xc_id_personbasicinfo_tv_marry.setText("已婚");
            }
        }
    }

    @Override
    public void onNetFail() {
        if (xc_id_model_no_net != null) {
            UtilViewShow.setVisible(true, xc_id_model_no_net);
            pullToRefreshScrollView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onNetSuccess() {
        if (xc_id_model_no_net != null) {
            UtilViewShow.setVisible(false, xc_id_model_no_net);
            pullToRefreshScrollView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onNetRefresh() {
        requestData();
    }

}
