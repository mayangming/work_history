package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Paint;
import android.graphics.drawable.AnimationDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewStub;
import android.view.inputmethod.EditorInfo;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.emoji.util.EmojiSpanUtils;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.XC_ChatAdapter;
import com.qlk.ymz.application.DBApplication;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.maintab.JS_HomeFragment;
import com.qlk.ymz.model.AuthDataInfo;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.model.XC_SendMessageBackModel;
import com.qlk.ymz.model.XC_ServerTimeModel;
import com.qlk.ymz.model.XC_SessionInfo;
import com.qlk.ymz.model.XC_UploadFileModel;
import com.qlk.ymz.model.YM_ConsultInfoModel;
import com.qlk.ymz.model.YM_PushModel;
import com.qlk.ymz.parse.Parse2ConsultInfoModel;
import com.qlk.ymz.parse.Parse2PatientDrugInfoModel;
import com.qlk.ymz.parse.Parse2PublicityBean;
import com.qlk.ymz.parse.Parse2RecentSessionId;
import com.qlk.ymz.parse.Parse2RecoderList;
import com.qlk.ymz.parse.Parse2SendMessageBackModel;
import com.qlk.ymz.parse.Parse2ServerTimeModel;
import com.qlk.ymz.parse.Parse2UploadFileModel;
import com.qlk.ymz.receiver.XC_PushReceiver;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.DateUtils;
import com.qlk.ymz.util.DownloadHelper;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.GrowingIOUtil;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.RoughDraftUtils;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.StringUtils;
import com.qlk.ymz.util.ToJumpHelp;
import com.qlk.ymz.util.UtiDoctorCheck;
import com.qlk.ymz.util.UtilBasicInfo;
import com.qlk.ymz.util.UtilChat;
import com.qlk.ymz.util.UtilChatPhoto;
import com.qlk.ymz.util.UtilCollection;
import com.qlk.ymz.util.UtilDoctorTime;
import com.qlk.ymz.util.UtilFile;
import com.qlk.ymz.util.UtilIMCreateJson;
import com.qlk.ymz.util.UtilInsertMsg2JsDb;
import com.qlk.ymz.util.UtilNativeHtml5;
import com.qlk.ymz.util.UtilPackMsg;
import com.qlk.ymz.util.UtilToast;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.InputMethodEventView;
import com.qlk.ymz.view.TimeLayout;
import com.qlk.ymz.view.XCChatBottomLayout;
import com.qlk.ymz.view.XCIMMenuDialog;
import com.qlk.ymz.view.XCMoveView;
import com.qlk.ymz.view.XCRecoderVoiceDialog;
import com.qlk.ymz.view.XCRecordVoiceButtonPlus;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.XC_VisitDialog;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.fragment.XCCameraPhotoFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilAbsList;
import com.xiaocoder.android.fw.general.util.UtilBroadcast;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilFiles;
import com.xiaocoder.android.fw.general.util.UtilInputMethod;
import com.xiaocoder.android.fw.general.util.UtilNet;
import com.xiaocoder.android.fw.general.util.UtilSound;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;
import com.xiaocoder.ptrrefresh.XCIRefreshHandler;
import com.xiaocoder.ptrrefresh.XCMaterialListRefreshLayout;

import org.apache.http.Header;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by jingyu on 2015/6/16.
 * 聊天详情页
 * @version 1.0
 */
public class XC_ChatDetailActivity extends DBActivity {
    /** 日志输出 */
    public static final String TAG_CHAT = "tag_chat";
    /** 可移动的view */
    private TimeLayout timeLayout;
    /** 底部键盘控制等 */
    private XCChatBottomLayout bottombar;
    /** 可以下拉的聊天列表布局 */
    private XCMaterialListRefreshLayout refreshListview;
    /** 聊天列表 */
    private ListView chatListview;
    /** 聊天列表adapter，有三种类型 */
    private XC_ChatAdapter adapter;
    /** 可以监听键盘隐藏的布局 */
    private InputMethodEventView keyBoardLayout;
    /** 可以监听拍照 */
    private XCCameraPhotoFragment camera;

    private Handler handler = new Handler(Looper.getMainLooper());
    /** 聊天的数据库 */
    private XCChatModelDb chat_dao;
    /** 检测是否认证的dialog */
    private YR_CommonDialog toCheckDialog;
    /** 录音倒计时的视图 */
    private XCRecoderVoiceDialog voiceTimeDialog;
    /**
     * 前面页面传来的参数,也是进入聊天设置页面的参数
     * 这个对象里面不包含聊天数据，只有部分医生和患者的相关信息
     */
    private XC_ChatModel sessionInfo = new XC_ChatModel();
    /** 用于区别如果是当前正在聊天的用户且在前台，则不发通知
     *  这个ID同时负责判断其它页面是否发送刷新患者信息的通知
     * */
    public static String recoder_which_patient_id = "0";
    /** 重新发起会话 */
    private LinearLayout sessionEndLayout;
    private TextView reopenSessionTextView;
    /** 会话结束的文本提示（本次咨询结束） */
    private TextView sessionEndNoticeTextView;
    /** 复制文本、扬声器模式的切换选择的dialog */
    private XCIMMenuDialog dialog;
    /** titlebar */
    private XCTitleCommonLayout titlebar;
    /** 底部新消息提示，滑动到底部后消失 */
    private TextView chatNewMsg;
    private View space;//控件悬浮在整个页面之上，防止当加载时候进行其他操作，这个操作只在第一次进入页面的时候才进行遮罩
    /**
     * 无网络背景
     */
    private RelativeLayout noNetLayout;
    /** 接收患者来信息的广播 */
    private ChatDetailReceiver receiver;
    /** 更新宣教阅读状态的广播 */
    private UpdateEduReceiver updateEduReceiver;

    /** 更新患者信息的广播 */
    private UpdatePatientReceiver updatePatientReceiver;
    /** 删除患者信息的广播 */
    private DelPatientReceiver delPatientReceiver;
    /** 更新作废的广播 */
    private UpdateInvalidReceiver updateInvalidReceiver;
    /**
     * 音频焦点切换的监听
     */
    AudioManager.OnAudioFocusChangeListener mAudioFocusChangeListener;

    /**
     * add by mym on 2017/4/8
     * 更新宣教阅读状态
     */
    public class UpdateEduReceiver extends BroadcastReceiver {
        public final static String UPDATE_EDU_ACTION = "update_edu_action";
        public final static String UPDATE_MODEL = "update_model";
        @Override
        public void onReceive(Context context, Intent intent) {
            YM_PushModel updateEduModel = (YM_PushModel) intent.getSerializableExtra(UPDATE_MODEL);
            if (!updateEduModel.getPatientId().equals(sessionInfo.getUserPatient().getPatientId())){//比较是否和当前的患者ID一致
                return;
            }
            adapter.updateEduReadStatus(updateEduModel);
        }
    }
    /**
     * add by mym on 2018/7/2
     * 删除患者的通知
     */
    public class DelPatientReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            myFinish();
        }
    }
    /**
     * add by mym on 2018/4/3
     * 更新患者信息
     */
    public class UpdatePatientReceiver extends BroadcastReceiver {
        public final static String UPDATE_PATIENT_ACTION = "update_patient_action";
        public final static String UPDATE_PATIENT = "update_patient";
        @Override
        public void onReceive(Context context, Intent intent) {
                UserPatient userPatient = (UserPatient) intent.getSerializableExtra(UPDATE_PATIENT);
                if (!userPatient.getPatientId().equals(sessionInfo.getUserPatient().getPatientId())){//比较是否和当前的患者ID一致
                    return;
                }
                updatePatientMsg(userPatient);
                updateTitleAndSpeaker();
                updateListRunnable.setScroolToBottom(false);
                refreshList();
        }
    }
    /**
     * add by mym on 2018/4/3
     * 更新作废信息
     */
    public class UpdateInvalidReceiver extends BroadcastReceiver {
        public final static String UPDATE_IVALID_ACTION = "update_ivalid_action";
        public final static String UPDATE_IVALID_RECOMMAND_ID = "update_ivalid_recommand_id";//用于查找某一条消息
        public final static String UPDATE_IVALID_STATUS = "update_ivalid_status";//用于更改消息内的作废标记
        @Override
        public void onReceive(Context context, Intent intent) {
            String recommandId = intent.getStringExtra(UPDATE_IVALID_RECOMMAND_ID);
            String invalidStatus = intent.getStringExtra(UPDATE_IVALID_STATUS);
            if (adapter == null) {//可能消息发过来的时候，列表还没初始化完呢...
                return;
            }
            //更新聊天列表的患者信息
            for (XC_ChatModel chatModel : adapter.getList()){
                if (recommandId.equals(chatModel.getRecommandId())){
                    chatModel.setInvalid(invalidStatus);
                }
            }
            updateListRunnable.setScroolToBottom(false);
            refreshList();
        }
    }
    /**
     * add by cyr on 2016/7/4
     * 医生状态实时更新接收器 V2.5需求
     * 未认证的医生，当"检查是否认证的dialog"处在显示状态时，医生通过了认证，从首页发push消息，关闭dialog
     */
    private BroadcastReceiver update_auth_status_receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if ("1".equals(UtilSP.getAuthStatus())) {
                if (toCheckDialog != null && toCheckDialog.isShowing()) {
                    toCheckDialog.dismiss();
                }
            }
        }
    };

    /**
     * 检测网络状态的广播，用于显示无网络的设置
     */
    private BroadcastReceiver mConnectivityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            UtilViewShow.setGone(!UtilNet.isNetworkAvailable(XC_ChatDetailActivity.this), noNetLayout);
        }
    };

    /**
     * 接收患者的信息
     */
    public class ChatDetailReceiver extends BroadcastReceiver {

        public final static String CHAT_DETAIL_ACTION = "chat_detail_action";
        public final static String CHAT_DETAIL_MODEL = "chat_detail_model";

        @Override
        public void onReceive(Context context, Intent intent) {
            XC_ChatModel model = (XC_ChatModel) intent.getSerializableExtra(CHAT_DETAIL_MODEL);
            if (model == null) {
                return;
            }

            if (isUserIdDifferent(model)) {
                return;
            }

            if (UtilString.isBlank(model.getSessionId())) {
                // 传进来的会话id为空，返回；有效的消息是一定有sessionId的
                // sessionInfo里的sessionId是有可能为空的，比如进入会话但未发起
                return;
            }

            // 医生先进页面，正准备发（还没有发,这时sessionID为""），这时收到患者来的信息则更新sessionId 和 beginTime
            updateSessionAndStartTimer(model.getSessionId(), model.getSessionBeginTime(), model.getPayMode());

            // 如果不是同一个会话
            // 从聊天列表查看以前的记录时，这时收到消息
            // 换设备登录的时候
            if (!model.getSessionId().equals(sessionInfo.getSessionId())) {
                return;
            }

            if (sessionEndLogic(model)) {
                return;
            }

            resetUnReadNum(model);

            //-----------------上线前的bug修复，careful----start-----------------
            try {
                if (null != adapter && adapter.containsSameModel(model)) {
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            //-----------------上线前的bug修复，careful----end-----------------

            if (de_duplication(model)){
                return;
            }

            if (!UtilString.isBlank(model.getLastPlatform())) {
                sessionInfo.setLastPlatform(model.getLastPlatform());
            }

            // 一般情况下，这里是不会收到医生发的消息，这里收到了医生发来的推荐用药消息或者病历处方（用药审核）
            // 病历处方(或者推荐用药)审核流程解释：
            // 1、本地发送医生消息，服务器返回审核中状态，保存消息到本地并进行显示，
            // 2、审核通过后，服务器发送IM消息更改状态，本地数据库根据recommendId查询数据库删除旧数据并保存新的数据，
            // 3、遍历聊天页面消息集合，删除旧的数据，并添加新的消息进行展示
            checkRecommandStatus(model);
            checkRecommandForRecordStatus(model);

            //更新在线诊室的状态
            sessionInfo.setSessionJson(model.getSessionJson());
            sessionInfo.getChatSession().setConsultSourceType(model.getChatSession().getConsultSourceType());

            // 性能的优化--可能医生很久没登录，该患者来了100条信息，防止刷新一百次
            addList(model,isBottom(chatListview));
            UtilViewShow.setGone(!isBottom(chatListview), chatNewMsg);
        }
    }

    private UpdateListRunnable updateListRunnable = new UpdateListRunnable();

    private class UpdateListRunnable implements Runnable{
        private boolean isScroolToBottom = true;
        void setScroolToBottom(boolean isScroolToBottom){
            this.isScroolToBottom = isScroolToBottom;
        }
        @Override
        public void run() {
            if (adapter != null && adapter.getList() != null) {
                adapter.getList().addAll(tempSaveMsg);
                tempSaveMsg.clear();
                adapter.notifyDataSetChanged();
                if (isScroolToBottom){
                    scrollToBottom(60);
                }
            }
        }
    }

    /* ListView 是否滚动到了底部 */
    private boolean isBottom(AbsListView listView){
        if (null == listView){
            return true;
        }
        return listView.getLastVisiblePosition() == listView.getCount() - 1;
    }

    /* 更新患者信息 */
    private void updatePatientMsg(UserPatient userPatient){
        //更新sessionInfo的信息
        updatePatientMsg(sessionInfo.getUserPatient(),userPatient);
        if (adapter == null) {//可能消息发过来的时候，列表还没初始化完呢...
            return;
        }
        //更新聊天列表的患者信息
        for (XC_ChatModel chatModel : adapter.getList()){
            updatePatientMsg(chatModel.getUserPatient(),userPatient);
        }
    }
    /* 把after的值赋值给before */
    private void updatePatientMsg(UserPatient before,UserPatient after){
        before.setPatientName(after.getPatientName());
        before.setPatientImgHead(after.getPatientImgHead());
        before.setPatientGender(after.getPatientGender());
        before.setPatientLetter(after.getPatientLetter());
        before.setPatientAge(after.getPatientAge());
        before.setPatientMemoName(after.getPatientMemoName());
        before.setPatientName(after.getPatientName());
        before.setCityName(after.getCityName());
        before.setPayAmount(after.getPayAmount());//这个字段在XCChatModelDb中没有存储，只能从其它地方传进来

    }

    /**
     * 删除之前推荐用药审核的消息
     */
    public void checkRecommandStatus(XC_ChatModel model) {

        if (model.isDoctorRecommandMedicineType() && !UtilString.isBlank(model.getRecommandId())) {
            if (adapter != null && adapter.getList() != null) {
                List<XC_ChatModel> list = adapter.getList();
//                boolean isRemoved = false;
                for (Iterator<XC_ChatModel> it = list.iterator(); it.hasNext(); ) {
                    XC_ChatModel item = it.next();
                    if (model.getRecommandId().equals(item.getRecommandId())) {
                        it.remove();
//                        isRemoved = true;
                    }
                }
//                if (isRemoved) {
//                    adapter.notifyDataSetChanged();
//                }
            }
        }
    }
    /**
     * 删除之前病历处方审核的消息
     */
    public void checkRecommandForRecordStatus(XC_ChatModel model) {
        if (model.isDoctorMedicineRecordType() && !UtilString.isBlank(model.getRecommandId())) {
            if (adapter != null && adapter.getList() != null) {
                List<XC_ChatModel> list = adapter.getList();
//                boolean isRemoved = false;
                for (Iterator<XC_ChatModel> it = list.iterator(); it.hasNext(); ) {
                    XC_ChatModel item = it.next();
                    if (model.getRecommandId().equals(item.getRecommandId())) {
                        it.remove();
//                        isRemoved = true;
                    }
                }
//                if (isRemoved) {
//                    adapter.notifyDataSetChanged();
//                }
            }
        }
    }

    private boolean isUserIdDifferent(XC_ChatModel model) {
        if (UtilString.isBlank(model.getUserDoctor().getDoctorSelfId()) || !model.getUserDoctor().getDoctorSelfId().equals(sessionInfo.getUserDoctor().getDoctorSelfId())) {
            return true;
        }
        return UtilString.isBlank(model.getUserPatient().getPatientId()) || !model.getUserPatient().getPatientId().equals(sessionInfo.getUserPatient().getPatientId());//无效的患者id 或者 不是同一个患者
    }

    private void updateSessionAndStartTimer(String sessionId, String sessionBeginTime, String payMode) {
        if (UtilString.isBlank(sessionInfo.getSessionId()) || UtilString.isBlank(sessionInfo.getSessionBeginTime())) {
            if (!UtilString.isBlank(sessionId)) {
                sessionInfo.setSessionId(sessionId);
            }

            if (!UtilString.isBlank(sessionBeginTime)) {
                sessionInfo.setSessionBeginTime(sessionBeginTime);
            }

            if (!UtilString.isBlank(payMode)) {
                sessionInfo.setPayMode(payMode);
            }
            startReqTimer();
            sessionInfo.getUserPatient().setConsultPayType("0");//如果是第一次发送消息则把付费状态改为免费--0，并更新数据库
            JS_ChatListDB.getInstance(getApplicationContext(), sessionInfo.getUserDoctor().getDoctorSelfId()).updatePatientConsultPayType(sessionInfo);//第一次发的时候才更改付费状态
        }
    }

    /**
     * 单例更新界面
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        launch(intent);
    }

    /**
     * 当点击信息通知后，会来到该界面，则更新通知集合
     */
    private void removeNotice() {
        try {
            // 聊天信息删除
            XC_PushReceiver.clearNoticeByPatientId(this, sessionInfo.getUserPatient().getPatientId());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 停止录音 onPause
     */
    private void clearRecoderWhenPause() {
        bottombar.getXc_id_chat_bottom_recoder_button().onActivityPaused();
    }

    @Override
    protected void onPause() {
        super.onPause();
        clearRecoderWhenPause();
        if (!isSessionEnd() && !UtilString.isBlank(sessionInfo.getSessionId())){
            saveRoughtDraft();
        }
        JS_ChatListDB.getInstance(getApplicationContext(), sessionInfo.getUserDoctor().getDoctorSelfId()).deleteBuyMedicineRequireInfo(sessionInfo);
    }
    /* 保存草稿内容 */
    private void saveRoughtDraft(){
        if (null != bottombar && null != bottombar.getXc_id_chat_bottom_edittext_input()){
            String content = bottombar.getXc_id_chat_bottom_edittext_input().getText().toString().trim();
            RoughDraftUtils.putRoughtDraft(sessionInfo.getUserPatient().getPatientId(),content);
        }
    }
    @Override
    protected void onStop() {
        super.onStop();
        // 结束录音
        finishVoicePlaying();
        // add by xjs on 20160513 start
        // 当离开聊天页面时，要将“咨询列表DB”中的“特别的消息类型”字段，“购药咨询id”字段及“购药咨询信息”字段内容清空
//        JS_ChatListDB.getInstance(getApplicationContext(), sessionInfo.getUserDoctor().getDoctorSelfId()).deleteBuyMedicineRequireInfo(sessionInfo);
        // add by xjs on 20160513 end
    }

    @Override
    public void onBackPressed() {
        if (UtilChat.isTwoOnclick()){
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xc_l_activity_chat);
        super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-22,about：saveInfo,begin
        BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "1", "", "","", false);
        // created by songxin,date：2016-4-22,about：saveInfo,end
    }

    //created by songxin,date：2016-4-23,about：bi,begin
    @Override
    protected void onStart() {
        super.onStart();
        // 移除通知
        removeNotice();
        BiUtil.savePid(XC_ChatDetailActivity.class);
    }
    // created by songxin,date：2016-4-23,about：bi,end

    /**
     * 更新title和模式 如勿扰扬声器的图标
     */
    private void updateTitleAndSpeaker() {
        // 2016-03-09  sk  最新需求title改成5个字了。。。
        String patientDisplayName = sessionInfo.getUserPatient().getPatientDisplayName();

        if (patientDisplayName != null && patientDisplayName.length() > 5) {
            patientDisplayName = patientDisplayName.substring(0, 5) + "...";
        }
        titlebar.setTitleCenter(true, patientDisplayName);
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleRight(true, R.mipmap.chat_setting_menu);
        titlebar.setTitleLeft(R.mipmap.xc_d_chat_back, "");
        titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 当双击退出时，栈的activity为null，这时来了push，点击打开
                if (!XCApplication.isActivityExist(JS_MainActivity.class)) {
                    startActivity(new Intent(XC_ChatDetailActivity.this, JS_MainActivity.class));
                }
                if (UtilChat.isTwoOnclick()){
                    return;
                }
                myFinish();
            }
        });

        setTitleMode();
        setTitleTip(sessionInfo);
    }

    /**
     * title勿扰状态和播放声音模式,付费状态设置
     */
    private void setTitleMode() {
        JS_ChatListModel chatListModel = JS_ChatListDB.getInstance(getApplicationContext(), UtilSP.getUserId()).getChatStatus(sessionInfo.getUserPatient().getPatientId());
        // 对于播放声音时的模式控制不在此进行处理，而放到播放时即时处理（修复JIRA上编号为955的问题）
        if (UtilSP.getIsSpeakLoud() && "1".equals(chatListModel.getUserPatient().getIsShield())) {
            // 扬声器 && 屏蔽
            //UtilSound.setSpeakerphoneOn(this, true);
            titlebar.setTitleCenterRightDrawable(R.mipmap.chat_shield);
        } else if (UtilSP.getIsSpeakLoud() && "0".equals(chatListModel.getUserPatient().getIsShield())) {
            // 扬声器 && 不屏蔽
            //UtilSound.setSpeakerphoneOn(this, false);
            titlebar.setTitleCenterRightDrawable(0);
        } else if (!UtilSP.getIsSpeakLoud() && "1".equals(chatListModel.getUserPatient().getIsShield())) {
            // 听筒 && 屏蔽
            titlebar.setTitleCenterRightDrawable(R.mipmap.chat_headphone_shield);
        } else if (!UtilSP.getIsSpeakLoud() && "0".equals(chatListModel.getUserPatient().getIsShield())) {
            // 听筒 && 不屏蔽
            titlebar.setTitleCenterRightDrawable(R.mipmap.chat_title_headphone);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 处理免打扰状态页面返回时的头部显示
        setTitleMode();
    }

    @Override
    public void initWidgets() {
        // 注册广播
        UtilBroadcast.myRegisterReceiver(this, 1000, receiver = new ChatDetailReceiver(), ChatDetailReceiver.CHAT_DETAIL_ACTION);
        UtilBroadcast.myRegisterReceiver(this, 1000, mConnectivityReceiver, ConnectivityManager.CONNECTIVITY_ACTION);
        UtilBroadcast.myRegisterReceiver(this, 1000, update_auth_status_receiver, JS_HomeFragment.UPDATE_AUTHSTATUS_ACTION);
        UtilBroadcast.myRegisterReceiver(this, 1000, updateEduReceiver = new UpdateEduReceiver(), UpdateEduReceiver.UPDATE_EDU_ACTION);
        UtilBroadcast.myRegisterReceiver(this, 1000, updatePatientReceiver = new UpdatePatientReceiver(), UpdatePatientReceiver.UPDATE_PATIENT_ACTION);
        UtilBroadcast.myRegisterReceiver(this, 1000, delPatientReceiver = new DelPatientReceiver(), CommonConfig.DEL_PATIENT_ACTION);
        UtilBroadcast.myRegisterReceiver(this, 1000, updateInvalidReceiver = new UpdateInvalidReceiver(), UpdateInvalidReceiver.UPDATE_IVALID_ACTION);

        //title
        titlebar = getViewById(R.id.xc_id_model_titlebar);

        //网络背景提示
        noNetLayout = getViewById(R.id.xc_id_model_no_net_main);

        // move
        timeLayout = getViewById(R.id.timeLayout);

        //bottom
        bottombar = getViewById(R.id.xc_id_model_bottombar);
        sessionEndLayout = getViewById(R.id.xc_id_bottombar_session_end);
        reopenSessionTextView = getViewById(R.id.reopenSession);
        sessionEndNoticeTextView = getViewById(R.id.xc_id_session_end_notice);

        chatNewMsg = getViewById(R.id.chat_new_msg);

        // 图片
        camera = new XCCameraPhotoFragment();
        addFragment(R.id.xc_id_temp_add_fragment, camera);

        // 监听键盘的布局
        keyBoardLayout = getViewById(R.id.xc_id_model_layout);

        space = getViewById(R.id.transv);

        // 聊天的内容布局
        refreshListview = getViewById(R.id.xc_id_chat_refresh_listview);
        chatListview = (ListView) (refreshListview.getListView());
        chatListview.setBackgroundColor(getResources().getColor(R.color.c_gray_f0f1f5));
        UtilAbsList.setListViewStyle(chatListview, null, 1, false);

        launch(getIntent());
    }

    /**
     * 该界面逻辑的启动入口
     *
     * @param intent 该 intent 里有一个model参数
     */
    private void launch(Intent intent) {
        if (intent == null) {
            finish();
            return;
        }
        //这段对于sessionInfo的赋值理论上这里接受传入的参数仅仅需要一个patientId就可以了
        XC_ChatModel params = (XC_ChatModel) intent.getSerializableExtra(CommonConfig.CHAT_PARAMS_MODEL);
        if (params == null || UtilString.isBlank(params.getUserPatient().getPatientId()) || UtilString.isBlank(UtilSP.getUserId())) {
            finish();
            return;
        }

        sessionInfo = UtilBasicInfo.getAllBasicInfo(params, params.getUserPatient().getPatientId(), UtilSP.getUserId());
        // 初始化参数值、数据库、通知等
        init(intent);
        // 清除adapter里面的数据
        clearAdapterMessage();
        // 自动刷新，聊天记录在这里开始，在listener里面
        refreshListview.autoRefresh(true);
    }

    public boolean isTimeRequested = false;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        // 原本是在onCreate里请求的，但是视频结束后，跳聊天，然后立即调推荐用药，返回到聊天页时，time布局无动画
        if (!isTimeRequested) {
            isTimeRequested = true;
            startReqTimer();
        }
    }
    /* 设置推荐安用药的tab名字 */
    private void setRecommandTableName(){

        if (UtilSP.isRecordRecom()){//是否是医嘱处方用户，是的话设置为医嘱处方的图标
            bottombar.getXc_d_chat_bottom_recommand_imageview().setImageResource(R.drawable.record_recom);
            return;
        }
        if ("2".equals(UtilSP.getDoctorStatus())){//备案成功 显示 "开处方"
            bottombar.getXc_d_chat_bottom_recommand_imageview().setImageResource(R.drawable.chat_bottom_prescribe);
        }else {//备案失败显示 "推荐用药"
            bottombar.getXc_d_chat_bottom_recommand_imageview().setImageResource(R.drawable.xc_d_chat_bottom_recommand);
        }
    }

    /**
     * 场景：会话结束了，从首页进来显示的是上一次的会话记录，这时点击了重新发起会话，
     * 如果会话正在进行，但又换了设备，本地无记录，就会请求网络，这时就需要清除adapter里之前的记录
     */
    private void clearAdapterMessage() {
        if (adapter != null && adapter.getList() != null) {
            adapter.getList().clear();
            adapter.notifyDataSetChanged();
        }
    }

    /**
     * 获取dao，以及初始化id name等值
     *
     * @param intent 从前一个页面或刷新时传递过来的
     */
    private void init(Intent intent) {
        String roughtDraftContent = RoughDraftUtils.getRoughtDraftByPatientId(sessionInfo.getUserPatient().getPatientId());
        bottombar.getXc_id_chat_bottom_edittext_input().setText(roughtDraftContent);
        bottombar.getXc_id_chat_bottom_edittext_input().setSelection(roughtDraftContent.length());
        isFirstComeHere = true;// 重置
        isTimeRequested = false;// 重置
        isAdd = false;
        // 记录当前正在聊天的患者id
        recoder_which_patient_id = sessionInfo.getUserPatient().getPatientId();
        // 初始化数据库
        chat_dao = XCChatModelDb.getInstance(getApplicationContext(), UtilSP.getIMDetailDbName(sessionInfo.getUserDoctor().getDoctorSelfId(), sessionInfo.getUserPatient().getPatientId()));
        // 该患者的消息未读数量置为0
        JS_ChatListDB.getInstance(getApplicationContext(), UtilSP.getUserId()).setUnReadMessageNum2Zero(sessionInfo.getUserPatient().getPatientId());
        // 判断是否显示会话结束视图
        updateDue();
        // 更新title
        updateTitleAndSpeaker();
        keyboardWillShow();
        // 如果是从视频页跳转来的，则直接进入推荐用药界面
        setRecommandTableName();
        if (CommonConfig.COME_FROM_VIDEO.equals(intent.getStringExtra(CommonConfig.COME_FROM_VIDEO))) {
//            toChoiceMedicineActivity("");
//            ToJumpHelp.toJumpRecommendedMedicationActivity(XC_ChatDetailActivity.this,sessionInfo);
            if (!UtiDoctorCheck.isVertify()) {
                // 未认证
                if (isOutUnCheckSendLinkMedicineTimes()) {
                    // 未认证，且已经超过了试用的次数,去认证提示
                    toCheck(true);
                    return;
                }
            }
            if (!UtilSP.isRecordRecom()){//是否是医嘱处方用户
                ToJumpHelp.toJumpRecommendedMedicationActivity(XC_ChatDetailActivity.this,sessionInfo);
                return;
            }
            //视频咨询过来的Flag也用CommonConfig.RECOMMEND_BOTTOM，和底部推荐流程一样
            UtilChat.requestMedicalRecord(XC_ChatDetailActivity.this,sessionInfo.getUserPatient().getPatientId(),CommonConfig.RECOMMEND_BOTTOM,sessionInfo);
        }
    }

    private void saveMessageToDb(XC_ChatModel msg) {
        // 存入数据库
        chat_dao.checkChatMsgNum();
        chat_dao.insert(msg);

        UtilInsertMsg2JsDb.insert(getApplicationContext(), msg);
    }

    private void updateDbMsg(XC_ChatModel msg) {
        // 如果是医生发会话的第一条信息，则model里的sessionId为空
        msg.setSessionId(sessionInfo.getSessionId());
        msg.setSessionBeginTime(sessionInfo.getSessionBeginTime());
        chat_dao.update(msg);
        UtilInsertMsg2JsDb.insert(getApplicationContext(), msg);

        // 刷新列表
        if (adapter != null) {
            adapter.notifyDataSetChanged();
            scrollToBottom(60);
        }
    }

    /**
     * 会话是否结束（以前的版本是以24小时判断的）
     */
    public boolean isSessionEnd() {
        return XC_ChatModel.SESSION_END.equals(sessionInfo.getSessionLifeCycle());
    }

    /**
     * 发送消息：存入数据库 、更新列表、发给服务器
     */
    private void sendMsg(XC_ChatModel model) {
        if (model == null) {
            return;
        }
        saveMessageToDb(model);
        // 刷新列表
        addListToBottom(model);
        // 发送消息给服务器
        upload2Server(model);
    }
    /**
     * 更新普通文本信息为推荐搜索
     * updateTextBeanToMedicineAssistantTextBean(message_bean, "板蓝根"+MEDICINE_ASSISTANT_SPLIT+"云南白药"+MEDICINE_ASSISTANT_SPLIT+"六味地黄丸");
     */
    private void updateTextBeanToMedicineAssistantTextBean(XC_ChatModel message_bean, String messageRecommand) {
        message_bean.setMsgType(XC_ChatModel.ASSISTANT_MEDICINE + "");
        message_bean.setMessageTextRecommand(messageRecommand);
    }

    /**
     * 为了防止刷新的频率过高,用集合临时存储,否则可能会crash,listview的集合会改变
     */
    private List<XC_ChatModel> tempSaveMsg = new ArrayList<>();

    /**
     * 本地更新列表，还没有请求网络
     * 刷新列表并滚动到底部
     * @param model 当前发送的信息model
     */
    private void addListToBottom(XC_ChatModel model) {
        if (model != null && adapter != null && adapter.getList() != null) {
            tempSaveMsg.add(model);
            updateListRunnable.setScroolToBottom(true);
            refreshList();
            //长按再次推荐用药的引导图 （叠在聊天信息的用药推荐上面)
            /*if (model.getMsgType().equals("" + XC_ChatModel.RECOMMAND_MEDICINE)
                    && !UtilsGuide.hadReadGuide(XC_ChatDetailActivity.this, GlobalConfigSP.GUIDE_LONG_CLICK_RECOMMEND)) {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        UtilsGuide.showGuide_longClickRecommend(XC_ChatDetailActivity.this);
                    }
                }, 500);
            }*/
        }
    }
    /**
     * 刷新列表，但不滚动到底部
     * @param model 当前发送的信息model
     * @param isScroolToBottom 是否滚动到底部
     */
    private void addList(XC_ChatModel model,boolean isScroolToBottom) {
        if (model != null && adapter != null && adapter.getList() != null) {
            tempSaveMsg.add(model);
            updateListRunnable.setScroolToBottom(isScroolToBottom);
            refreshList();
        }
    }
    /* 消息去重
     * true 为重复，false为不重复
     * */
    private boolean  de_duplication(XC_ChatModel model){
        if (model == null || adapter == null || adapter.getList() == null) {
            return false;
        }
        if (UtilCollection.isBlank(adapter.getList())){
            return false;
        }
        XC_ChatModel lastChatModel = adapter.getList().get(adapter.getList().size()-1);
        return model.getMsgTime().equals(lastChatModel.getMsgTime());
    }

    /* 刷新聊天列表 */
    private void refreshList(){
        // 性能的优化--可能医生很久没登录，该患者来了100条信息，防止刷新一百次了
        handler.removeCallbacks(updateListRunnable);
        handler.postDelayed(updateListRunnable, 60);
    }
    /**
     * 请求医生给患者设置的图文咨询费用
     */
    private void requestConsultInfo(final XC_ChatModel messagebean) {
        RequestParams params = new RequestParams();
        params.put("doctorId", sessionInfo.getUserDoctor().getDoctorSelfId());
        params.put("patientId", sessionInfo.getUserPatient().getPatientId());

        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.consult_info), params, new XCHttpResponseHandler() {
            @Override
            public void yourCompanyLogic() {
                result_boolean = HTTP_OK.equals(getCode());
            }

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                YM_ConsultInfoModel consultInfoModel = Parse2ConsultInfoModel.parse(result_bean);
                if (null == consultInfoModel){
                    return;
                }
                messagebean.getUserPatient().setPayAmount(consultInfoModel.getPrice());
                JS_ChatListDB.getInstance(getApplicationContext(), UtilSP.getUserId()).updatePatientPayAmount2(Collections.singletonList(messagebean));
                setTitleTip(messagebean);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                GeneralReqExceptionProcess.checkCode(XC_ChatDetailActivity.this, getCode(), getMsg());
            }
        });
    }

    /**
     * 获取发送给服务器的json
     * @param messagebean 发送的那条信息model
     */
    private void upload2Server(XC_ChatModel messagebean) {
        try {
            if (messagebean == null) {
                return;
            }
            if ((XC_ChatModel.VOICE + "").equals(messagebean.getMsgType())) {
                requestUploadFile(messagebean, new FileInputStream(new File(messagebean.getVoiceLocalUri())));
            } else if ((XC_ChatModel.PHOTO + "").equals(messagebean.getMsgType())) {
                requestUploadFile(messagebean, new FileInputStream(new File(messagebean.getChatModelPhoto().getPhotoLocalUri())));
            }
            else {
                // 除了 VOICE PHOTO (MOVIE暂没有这个需求)需要先上传文件外，别的类型直接上传json
                requestSendMessage(messagebean, UtilIMCreateJson.getImJson(messagebean));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * 如果是发送文件，先请求该上传文件接口，再请求requestSendMessage接口
     *
     * @param messagebean 消息model
     * @param inputStream 文件流
     */
    private void requestUploadFile(final XC_ChatModel messagebean, FileInputStream inputStream) {
        RequestParams params = new RequestParams();
        params.put("type", messagebean.getMsgType());
        params.put("file", inputStream);
        params.put("fromId", messagebean.getUserDoctor().getDoctorSelfId());
        params.put("toId", messagebean.getUserPatient().getPatientId());

        XCHttpAsyn.postAsyn(false, this, AppConfig.getChatUrl(AppConfig.chat_mediaUpload), params, new XCHttpResponseHandler() {
            @Override
            public void yourCompanyLogic() {
                result_boolean = HTTP_OK.equals(getCode());
            }

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {

                    XC_UploadFileModel model = Parse2UploadFileModel.parse(result_bean);

                    // 更新本地数据库
                    switch (messagebean.getMsgType()) {
                        case XC_ChatModel.MOVIE + "":
                            messagebean.setMoveHttpUri(model.getHttpPath());
                            break;
                        case XC_ChatModel.VOICE + "":
                            messagebean.setVoiceHttpUri(model.getHttpPath());
                            break;
                        case XC_ChatModel.PHOTO + "":
                            messagebean.getChatModelPhoto().setPhotoHttpUri(model.getHttpPath());
                            break;
                        default:
                            break;
                    }
                    String message = UtilIMCreateJson.getImJson(messagebean);
                    requestSendMessage(messagebean, message);
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (!result_boolean) {
                    messagebean.setIsSendSuccess(XC_ChatModel.SEND_FAIL);
                    updateDbMsg(messagebean);
                }
                // 处理code操作
                GeneralReqExceptionProcess.checkCode(XC_ChatDetailActivity.this, getCode(), getMsg());
            }
        });
    }

    /**
     * 发送消息接口
     *
     * @param model   发送的那条信息model，发送成功和失败都会更新该model里的一些值
     * @param message 给服务器的json串
     */
    private void requestSendMessage(final XC_ChatModel model, String message) {
        RequestParams params = new RequestParams();
        params.put("message", message);
        XCHttpAsyn.postAsyn(false, this, AppConfig.getChatUrl(AppConfig.chat_sendMessage), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);

                if (isUserIdDifferent(model)) {
                    return;
                }

                if (result_boolean) {
                    // endTime非空表示会话已结束，不再以code判断（之前改了很多次了。。）
                    // 这个XC_SendMessageBackModel接口的返回规则：会话结束了（没有新的会话），endtime不为空，sessionId空,beginTime空；会话的第一条信息，endtime空，sessionId不为空，beginTime不为空；以上两种之外的会话消息，endtime空，sessionId空，beginTime空
                    XC_SendMessageBackModel sendMessageBackModel = Parse2SendMessageBackModel.parse(result_bean);

                    if (checkSessionStatus(sendMessageBackModel)) {
                        return;
                    }

                    // 如果未认证，更新x次
                    updateUnCheckSendLinkMedicineTimes(model);
                    // 检测是否有用药助手的信息
                    medicineAssistant(sendMessageBackModel);
                    // adapter中会关闭发送的进度dialog
                    model.setIsSendSuccess(XC_ChatModel.SEND_SUCCESS);
                    // 更新信息的时间，这个时间是用来向服务器请求历史记录的
                    model.setMsgTime(sendMessageBackModel.getSendTime());
                    // 重新推荐用药时会用到该字段
                    model.setRecommandId(sendMessageBackModel.getRecommandId());
                    // 处方单会用到该字段
                    model.setSerialNumber(sendMessageBackModel.getSerialNumber());
                    // 推荐用药的审核状态
                    model.setRecommandStatus(sendMessageBackModel.getRecommandStatus());
                    //宣教的消息ID
                    model.setMessageId(sendMessageBackModel.getMessageId());
                    // 比如医生主动发，此时该聊天的sessionId和beginTime是空的，需要更新
                    updateSessionAndStartTimer(sendMessageBackModel.getSessionId(), sendMessageBackModel.getBeginTime(), "");
                    model.getUserPatient().setConsultPayType(sessionInfo.getUserPatient().getConsultPayType());//同步更新付费状态
                    model.getChatSession().setConsultSourceType(sendMessageBackModel.getConsultSourceType());
                    model.setSessionJson(UtilIMCreateJson.createSessionJson(model));
                }
            }

            private boolean checkSessionStatus(XC_SendMessageBackModel sendMessageBackModel) {
                // 在测试环境出现了0, 杨茗发现的,后杨茗与亮亮确认, null 和 0都是会话没过期
                if (!UtilString.isBlank(sendMessageBackModel.getEndTime())) {
                    // 会话过期了
                    model.setIsSendSuccess(XC_ChatModel.SEND_FAIL);

                    // 换设备登录 或者 没有接收到会话结束的推送时
                    XC_ChatModel sessionEndModel = UtilPackMsg.getSessionEndMsg(getApplicationContext(), sessionInfo.getUserDoctor().getDoctorSelfId()
                            , sessionInfo.getUserPatient().getPatientId(), sessionInfo.getSessionId(), sessionInfo.getSessionBeginTime(), sessionInfo.getPayMode(),
                            sendMessageBackModel.getEndTime());

                    sessionEndLogic(sessionEndModel);
                    // 平移会话，在新的会话里发送这条信息
                    requestNewSessionInfo(model);
                    return true;
                }
                // 会话未结束
                return false;
            }

            /**
             * 检测是否含有用药助手的信息
             */
            private void medicineAssistant(XC_SendMessageBackModel xcSendMessageBackModel) {
                if ((XC_ChatModel.TEXT + "").equals(model.getMsgType())) {
                    // 用药助手检测
                    if (UtiDoctorCheck.isVertify()) {
                        // 已认证
                        checkMedicineAssistant(model, xcSendMessageBackModel.getDrugNamesStr());
                    } else {
                        // 这里是1.5之后的需求，1.5之前的需求这里是不同的即ifelse里的逻辑都不同，这部分变动的非常多的次数，为了防止这部分的需求再次改动，没有删除if else的格式判断
                        // +patientId 与 doctorSelfId -->可能医生切换账户，又有相同的患者
                        // 如果没有该值，表示是当天第一次发送信息，这里是到day，而不是秒
                        if (UtiDoctorCheck.isFirstSendCurrentDay(sessionInfo.getUserPatient().getPatientId())) {
                            // 到这里，表示是当天的第一条文本,如果有药名，发送UNCHECK_HINT_MEDICINE；没有药名，发送UNCHECK_HINT
                            UtiDoctorCheck.update2SendedStatus(sessionInfo.getUserPatient().getPatientId());// 重置记录
                            checkMedicineAssistant(model, xcSendMessageBackModel.getDrugNamesStr());
                        } else {
                            checkMedicineAssistant(model, xcSendMessageBackModel.getDrugNamesStr());
                        }
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                sendMsgFinish(result_boolean,model);
                // 处理code操作
                GeneralReqExceptionProcess.checkCode(XC_ChatDetailActivity.this, getCode(), getMsg());
            }
        });
    }

    /* 消息发送成功后的后续处理操作 */
    private void sendMsgFinish(boolean result_boolean, XC_ChatModel model){
        if (!result_boolean) {
            model.setIsSendSuccess(XC_ChatModel.SEND_FAIL);
        }

        //更新在线诊室的状态
        sessionInfo.setSessionJson(model.getSessionJson());
        sessionInfo.getChatSession().setConsultSourceType(model.getChatSession().getConsultSourceType());

        updateDbMsg(model);

        try {
            // 场景:网络很差,消息正在发,还在发送中,这时退出聊天页,js_homefragment只会在onResume中更新一次,过了一段时间消息发送成功,首页的列表没更新
            // 没退出,还在聊天页,待退出聊天页时首页的onResume方法里js_homefragment更新聊天列表
            if (isFinishing()) {
                // 退出了聊天页
                List<Activity> listActivity = DBApplication.getActivity(JS_MainActivity.class);
                if (listActivity != null && listActivity.size() > 0 && listActivity.get(0) instanceof JS_MainActivity) {
                    JS_HomeFragment fragment = ((JS_MainActivity) listActivity.get(0)).getFragmentByTag(JS_HomeFragment.class.getSimpleName());
                    if (fragment != null && fragment.getActivity() != null) {
                        fragment.updateInfoListData();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private YR_CommonDialog medicineFifterDialog;
    private void medicineFifterDialog(String medicines){
        medicineFifterDialog = new YR_CommonDialog(this,medicines,"","我知道了") {
            @Override
            public void confirmBtn() {
                medicineFifterDialog.dismiss();
            }
        };
        medicineFifterDialog.setCanceledOnTouchOutside(false);
        medicineFifterDialog.show();
    }
    /**
     * 未认证的用户只能推荐用药服务端定的次数,待推荐成功后，调用该更新方法
     */
    private void updateUnCheckSendLinkMedicineTimes(XC_ChatModel model) {
        if ((XC_ChatModel.RECOMMAND_MEDICINE + "").equals(model.getMsgType()) && !UtiDoctorCheck.isVertify()) {
            // 如果是推荐用药发送成功 且是未认证的
            int times = UtilSP.getLinkMedicineSuccessTimes();
            UtilSP.putLinkMedicineSuccessTimes(times - 1);
        }
    }

    /**
     * 是否超出了推荐用药的次数
     */
    private boolean isOutUnCheckSendLinkMedicineTimes() {
        return UtilSP.getLinkMedicineSuccessTimes() <= 0;
    }

    /**
     * 2.0 以前的当天的第一条文本信息，如果有用药提示，显示UNCHECK_HINT_MEDICINE，拼两个MEDICINE_ASSISTANT作为标识
     * 如果没有用药提示，显示 UNCHECK_HINT，拼一个MEDICINE_ASSISTANT作为标识
     * 2.0 没有UNCHECK_HINT
     * "data":[{"sessionId":"7581_10_1452862632496","endTime":1302238374929 ,"drugNames":["ss","ss"]}]
     */
    private void checkMedicineAssistant(XC_ChatModel model, String drugsNameStr) {
        if (!UtilString.isBlank(drugsNameStr)) {
            updateTextBeanToMedicineAssistantTextBean(model, drugsNameStr);
        }
    }

    /**
     * 出诊时间dialog
     */
    YR_CommonDialog mYR_commonDialog;

    /**
     * 关闭出诊时间的对话框
     */
    private void closeSelectTimeDialog() {
        if (mYR_commonDialog != null) {
            mYR_commonDialog.dismiss();
        }
    }
    /**
     * 显示出诊时间的dialog
     */
    private void showSelectTimeDialog() {
        String time_content = UtilDoctorTime.getOutTime();
        if (UtilString.isBlank(time_content)) {
            shortToast("请设置您的出诊时间");
            myStartActivity(SX_OutOfTimeActivity.class);
        } else {
            showTimeDialog(time_content);
        }
    }

    private void showTimeDialog(final String time_content) {
        if (mYR_commonDialog == null) {
            mYR_commonDialog = new YR_CommonDialog(XC_ChatDetailActivity.this, time_content, "修改出诊时间", "确定") {
                @Override
                public void confirmBtn() {
                    bottombar.getXc_id_chat_bottom_edittext_input().append(UtilDoctorTime.modifyTimeMessage(mYR_commonDialog.getContentTV().getText().toString().trim()));
                    closeSelectTimeDialog();
                }

                @Override
                public void cancelBtn() {
                    closeSelectTimeDialog();
                    myStartActivity(SX_OutOfTimeActivity.class);
                }
            };
        } else {
            mYR_commonDialog.setContentStr(time_content);
        }
        mYR_commonDialog.show();
    }

    public String getHistoryMsgTimeV2() {

        if (adapter != null && adapter.getList() != null && adapter.getList().size() > 0) {
            List<XC_ChatModel> list = adapter.getList();

            for (XC_ChatModel model : list) {
                if (XC_ChatModel.SEND_SUCCESS.equals(model.getIsSendSuccess())) {
                    return model.getMsgTime();
                }
            }
        }

        if (!UtilString.isBlank(sessionInfo.getSessionEndTime())) {
            return sessionInfo.getSessionEndTime();
        }

        // 传空对应服务器的当前时间
        return "";
    }

    /**
     * 从网络获取到的消息是没有_id的,所以返回"",数据库里对""做了判断,返回0的集合
     */
    public String getHistoryMsg_IdV2() {
        XC_ChatModel target;

        if (adapter != null && adapter.getList() != null && adapter.getList().size() > 0) {
            target = adapter.getList().get(0);
            return target.get_id();
        } else {
            if (UtilString.isBlank(sessionInfo.getSessionEndTime())) {
                //会话未结束,查询数据库的最后一条信息
                target = chat_dao.queryLastChatMessage();
            } else {
                //会话结束,有可能是从会话列表中跳转过来的,只能取该会话的最后一条信息
                target = chat_dao.queryLastMsgBySessionIdV2(sessionInfo.getSessionId());
            }
            if (UtilString.isBlank(target.get_id())) {
                // 如果数据库没查到
                return target.get_id();
            } else {
                // 数据库分页查的结果不包括传入的id的这条信息,所以这里加1
                return (UtilString.toLong(target.get_id()) + 1) + "";
            }
        }
    }

    public String getHistoryMsgSessionIdV2() {
        if (adapter != null && adapter.getList() != null && adapter.getList().size() > 0) {

            List<XC_ChatModel> list = adapter.getList();

            for (XC_ChatModel model : list) {
                if (XC_ChatModel.SEND_SUCCESS.equals(model.getIsSendSuccess())) {
                    return model.getSessionId();
                }
            }
        }
        return sessionInfo.getSessionId();
    }

    /**
     * @param isFirstCome 是否第一次进入页面，这个值会随着重新发起会话而重置
     * @return 聊天页面显示的数据集合
     */
    @NonNull
    private List<XC_ChatModel> recoverDataPageFromDbV2(boolean isFirstCome) {
        String currentSessionId = sessionInfo.getSessionId();
        String lastMsgSessionId = chat_dao.queryLastChatMessage().getSessionId();
        // 场景: 点击重新发起会话按钮(从已结束的聊天详情页 或 患者信息页的 或onNewIntent),进入到聊天详情页
        if (isFirstCome && UtilString.isBlank(currentSessionId) && UtilString.isBlank(lastMsgSessionId)) {
            return chat_dao.queryPageByIdV2(true, 1, 20, getHistoryMsg_IdV2());
        } else {
            // sessionId不为空,表示有正在进行中的会话 或 从会话结束的item点击进入的,查库
            return chat_dao.queryPageByIdV2(false, 1, 20, getHistoryMsg_IdV2());
        }

    }

    /**
     * 把未读的消息数量重置为0
     * 如果是当前页，来信息的时候就调用，在receiver里有调用
     *
     * @param model 收到的消息model
     */
    private void resetUnReadNum(XC_ChatModel model) {
        model.setUnReadMessageNum("0");
        chat_dao.update(model);
    }

    /**
     * 是否是刚打开这个界面（调用onNewIntent时也算是刚打开这个界面），会初始化adapter，设置adapter的监听等操作
     */
    private boolean isFirstComeHere = true;
    /** 是否添加过药品过期的数据 */
    private boolean isAdd = false;
    /**
     * 从服务器获取消息记录
     */
    private void getHistoryFromServer() {
        String sessionId = getHistoryMsgSessionIdV2();

        if (UtilString.isBlank(sessionId)) {
            // 请求列表获取上一次的sessionId
            requestRecentSessionId();
        } else {
            requestHistoryFromSever(sessionId);
        }
    }

    public void requestRecentSessionId() {
        RequestParams params = new RequestParams();
        params.put("patientId", sessionInfo.getUserPatient().getPatientId());
        // 状态2 表示所有会话
        params.put("status", "2");
        params.put("orderBy", "1");
        params.put("pageNo", 1);
        params.put("pageSize", 1);
        XCHttpAsyn.postAsyn(this, AppConfig.getChatUrl(AppConfig.chatRecordList), params, new XCHttpResponseHandler() {

                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (result_boolean) {
                            // status =2 ,所有会话中,查找一条最近的会话
                            XC_SessionInfo xcSessionInfo = Parse2RecentSessionId.parse2SessionModel(result_bean);

                            if (xcSessionInfo != null && !UtilString.isBlank(xcSessionInfo.getSessionId())) {
                                requestHistoryFromSever(xcSessionInfo.getSessionId());
                            } else {
                                refreshFinish(false);
                            }
                        }
                    }

                    @Override
                    public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                        super.onFailure(code, headers, arg2, e);
                        refreshFinish(false);
                    }
                }
        );
    }

    private void requestHistoryFromSever(final String sessionId) {
        RequestParams params = new RequestParams();
        params.put("pageNo", 1);
        params.put("pageSize", 20);
        params.put("sessionId", sessionId);
        params.put("endTime", getHistoryMsgTimeV2());

        XCHttpAsyn.postAsyn(false, this, AppConfig.getChatUrl(AppConfig.session_details), params, new XCHttpResponseHandler() {

            @Override
            public void fail() {
                shortToast("数据加载失败");
            }

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<XC_ChatModel> recoderList = Parse2RecoderList.parse(result_bean);
                    if (recoderList != null && recoderList.size() > 0) {
                        XC_ChatModel model = recoderList.get(0);
                        // 取一条数据验证是否是当前这个patient 和 doctor的
                        if (isUserIdDifferent(model)) {
                            return;
                        }
                        if (sessionInfo.getSessionId().equals(model.getSessionId())){//若持一致则认为是同一个会话，session保持的sessionId认为是正在进行中的会话
                            sessionInfo.getUserPatient().setConsultPayType(model.getUserPatient().getConsultPayType());
                        }
                        Collections.reverse(recoderList);
                        showRecordList(recoderList);
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                refreshFinish(result_boolean);
                // 处理code操作
                GeneralReqExceptionProcess.checkCode(XC_ChatDetailActivity.this,getCode(),getMsg());
            }
        });
    }

    /**
     * 刷新结束
     * @param recoderList 是否刷新成功
     */
    private void showRecordList(List<XC_ChatModel> recoderList) {
        if (recoderList != null && recoderList.size() > 0) {
            adapter.getList().addAll(0, recoderList);
            adapter.notifyDataSetChanged();
            chatListview.setSelection(recoderList.size());
        }
    }
    private void refreshFinish(final boolean isSuccess) {
        if (sessionInfo.isShowExpire() && !isAdd){
            XC_ChatModel temp = (XC_ChatModel) sessionInfo.clone();
            temp.setSender(String.valueOf(XC_ChatModel.MSG_MEDICINE_TIME_LIMIT));
            addList(temp,true);
            isAdd = true;
        }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                refreshListview.completeRefresh(isSuccess, false);
                space.setVisibility(View.GONE);
            }
        }, 350);
    }

    @Override
    public void listeners() {
        space.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        chatNewMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scrollToBottom(60);
                UtilViewShow.setGone(false, chatNewMsg);

            }
        });
        // 结束会话的可移动view
        timeLayout.setOnClickListenerPlus(new XCMoveView.OnClickListenerPlus() {
            @Override
            public void onClickListenerPlus(View view) {
                ToJumpHelp.toJumpSessionEndActivity(XC_ChatDetailActivity.this,sessionInfo);
                overridePendingTransition(R.anim.pop_up, R.anim.pop_down);
            }
        });

        // 联系人详情
        titlebar.getXc_id_titlebar_right_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (UtilChat.isTwoOnclick()){
                    return;
                }
                ToJumpHelp.toJumpChatSettingDialogActivity(XC_ChatDetailActivity.this,sessionInfo,CommonConfig.CHAT_SETTING_FROM_CHAT);
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "XC_ChatDetailActivity_getXc_id_titlebar_right_layout","", false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
            }
        });
        // 点击小加号
        bottombar.setOnClickAddAction(new XCChatBottomLayout.OnClickAddAction() {
            @Override
            public void onClickAddAction() {
                scrollToBottom(50);
            }
        });
        // 点击小喇叭
        bottombar.setOnClickRecoderAction(new XCChatBottomLayout.OnClickRecoderAction() {
            @Override
            public void onClickRecoderAction() {
                scrollToBottom(50);
            }
        });

        // 底部相册按钮
        bottombar.getXc_d_chat_bottom_album_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "xc_d_chat_bottom_album_imageview","", false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
//                ablum.getLocalPhoto();修改图片选择 add by xd 2017/11/27
                ToJumpHelp.toJumpSelctImgsActivity(XC_ChatDetailActivity.this,1, YY_SelectImgsActivity.MODE_SINGLE,
                        false,true,false,true);
            }
        });

        // 底部摄像头按钮
        bottombar.getXc_d_chat_bottom_camera_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                camera.getTakePhoto();
            }
        });

        // 底部的添加按钮
        bottombar.getXc_id_chat_bottom_patient_info_image().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "xc_d_chat_bottom_back_imageview","", false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
//                toMedicRecordList();
                ToJumpHelp.toJumpEditMedicalRecordActivity(XC_ChatDetailActivity.this, sessionInfo.getUserPatient().getPatientId(),1);
            }
        });

        // 底部的推荐用药按钮
        bottombar.getXc_d_chat_bottom_recommand_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "xc_d_chat_bottom_recommand_imageview","", false);
                // created by songxin,date：2016-4-25,about：saveInfo,end

                //点击事件逻辑：
                //1、首先判断是否为医嘱处方的用户，如果不是按照旧的流程处理
                //2、其次判断是否显示过先写病历后开处方的规则说明页
                //3、如果显示过开处方的规则说明页，则查询最近的病历
                //4、如果没有病历则跳转至新建病历页，有病历的话则跳转至查看病历页
                inToUseMedicine();

            }
        });
        // 底部个性化服务费的按钮
        bottombar.getc_d_chat_bottom_individuation_cost_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到个性化服务费
                ToJumpHelp.toJumpIndividuationCostActivity(XC_ChatDetailActivity.this, sessionInfo, 2,CommonConfig.INDIVIDUATION_COST_REQUESED_CODE,"1");
            }
        });
        // 底部的出诊时间按钮
        bottombar.getXc_id_chat_bottom_outtime_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "xc_id_chat_bottom_outtime_layout","", false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                showSelectTimeDialog();
            }
        });

        // 底部的快速回复按钮
        bottombar.getXc_id_chat_bottom_reply_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "xc_id_chat_bottom_reply_layout","", false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                myStartActivityForResult(SK_QuickReplyActivity.class, CommonConfig.REQUEST_CODE_QUICK_REPLY);
            }
        });
        // 底部宣教的按钮
        bottombar.getXc_id_chat_bottom_publicity_education_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "chat_bottom_publicity_education_layout","", false);
                // created by songxin,date：2016-4-25,abou t：saveInfo,end
                ToJumpHelp.toJumpPublicityActivity(XC_ChatDetailActivity.this, sessionInfo,1);
            }
        });
        bottombar.getXc_id_chat_bottom_check_health_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2017-10-30,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "chat_bottom_check_health_layout","", false);
                // created by songxin,date：2016-10-30,abou t：saveInfo,end
                inToCheckHealth();
            }
        });
        // 发送消息按钮
        bottombar.getXc_id_chat_right_send_button().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //add by songxin,date：2018-3-12,about：GrowingIO banner track,begin
                Map<String,String> track = new HashMap<>();
                track.put("patientID", sessionInfo.getUserPatient().getPatientId());
                GrowingIOUtil.track("patientConsultation", track);
                //add by songxin,date：2018-3-12,about：GrowingIO banner track,end
                sendInputEditTextString();
            }
        });

        // 键盘
        bottombar.getXc_id_chat_bottom_edittext_input().setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendInputEditTextString();
                    return true;
                }
                return false;
            }
        });

        // 录音按钮
        bottombar.getXc_id_chat_bottom_recoder_button().setOnButtonStatus(new XCRecordVoiceButtonPlus.OnButtonStatus() {

            @Override
            public boolean isEffectiveVoiceFileWhenTimeOut() {
                return true;
            }

            @Override
            public boolean isIntercept() {
                finishVoicePlaying();
                if (isSessionEnd()) {
                    shortToast("会话已结束，请重新发起会话");
                    return true;
                }
                return false;
            }

            @Override
            public void onTouchDown() {
                if (voiceTimeDialog == null) {
                    voiceTimeDialog = new XCRecoderVoiceDialog(XC_ChatDetailActivity.this);
                }
            }

            @Override
            public void onUpdateTime(int time) {
                voiceTimeDialog.getTextView().setText(String.valueOf(time));
            }

            @Override
            public void onStart() {
                bottombar.getXc_id_chat_bottom_recoder_button_texthint().setText("松开 发送");
                bottombar.getXc_id_chat_bottom_recoder_button().setBackgroundResource(R.drawable.xc_d_chat_recoder_button_s);
                if (voiceTimeDialog != null) {
                    voiceTimeDialog.show();
                }
            }

            @Override
            public void onMoveOut() {
                bottombar.getXc_id_chat_bottom_recoder_button_texthint().setText("取消 发送");
            }

            @Override
            public void onMoveIn() {
                bottombar.getXc_id_chat_bottom_recoder_button_texthint().setText("松开 发送");
            }

            @Override
            public void onEnd(RecoderStop stop) {
                bottombar.getXc_id_chat_bottom_recoder_button_texthint().setText("按住 说话");
                bottombar.getXc_id_chat_bottom_recoder_button().setBackgroundResource(R.drawable.xc_d_chat_recoder_button);

                if (stop == RecoderStop.LESS_TIME_STOP) {
                    shortToast("录音时间太短");
                }

                if (voiceTimeDialog != null && voiceTimeDialog.isShowing()) {
                    // activity的生命周期方法，会调用到这里，如果进入该activity就立即退出，则dialog为null
                    voiceTimeDialog.cancel();
                }
            }

            @Override
            public void onSuccessFile(File file, final double time) {
                if (file != null) {
                    dShortToast(time + "---" + file.getAbsolutePath());
                    sendMsg(UtilPackMsg.packVoiceMsg(file, (float) time, sessionInfo));
                }
            }
        });

        // 会话结束视图
        reopenSessionTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestNewSessionInfo(null);
            }
        });

        keyBoardLayout.setmInputMethodChangeLinstener(new InputMethodEventView.InputMethodChangeLinstener() {
            @Override
            public void onInputMethodOpen(int softinputHeight) {
                keyboardWillShow();
            }

            @Override
            public void onInputMethodClose() {
                keyboardWillHidden();
            }
        });

        camera.setOnCaremaSelectedFileListener(new XCCameraPhotoFragment.OnCaremaSelectedFileListener() {

            @Override
            public void onCaremaSelectedFile(File file) {
                dealPhoto(file);
            }
        });


        // 点击item时，隐藏键盘
        chatListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                UtilInputMethod.hiddenInputMethod(XC_ChatDetailActivity.this);
            }
        });

        refreshListview.setHandler(new XCIRefreshHandler() {
            @Override
            public boolean canRefresh() {
                return true;
            }

            @Override
            public boolean canLoad() {
                return false;
            }

            @Override
            public void refresh(View view, int request_page) {
                List<XC_ChatModel> dbModels = recoverDataPageFromDbV2(isFirstComeHere);
                if (isFirstComeHere) {
                    // 第一次进入该页面,或单实例进入该页面,或重新发起会话时
                    isFirstComeHere = false;
                    // 重新创建adapter
                    adapter = new XC_ChatAdapter(XC_ChatDetailActivity.this, dbModels);
                    adapter.setPatientInfo(sessionInfo.getUserPatient().getPatientId());
                    addAdapterActionListener();
                    chatListview.setAdapter(adapter);
                    // 是否有跨会话的消息(当重新推荐用药时,如发送信息接口判断出会话结束了则跨会话发送,,会调用onNewIntent())
                    reSendMsg(getIntent() != null ? (XC_ChatModel) getIntent().getSerializableExtra(CommonConfig.SESSION_END_REOPEN_MESSAGE) : null);

                    if (UtilCollection.isBlank(dbModels)) {
                        getHistoryFromServer();
                        return;
                    }
                    // 第一次进入界面,如果sessionId为空，models为空，没有正在进行中的会话,显示空界面
                    refreshFinish(true);
                    scrollToBottom(60);
                } else {
                    if (UtilCollection.isBlank(dbModels)) {
                        getHistoryFromServer();
                    } else {
                        // 非第一次加载数据,滚动到这一次下拉刷新取得数据的位置
                        showRecordList(dbModels);
                        refreshFinish(true);
                    }
                }
            }

            @Override
            public void load(View view, int request_page) {

            }

        });
        chatListview.setOnScrollListener(new AbsListView.OnScrollListener(){
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState){
                // 当不滚动时
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE && isBottom(chatListview)) {
                    // 判断是否滚动到底部
                    UtilViewShow.setGone(false, chatNewMsg);
                }
            }

            @Override
            public void onScroll(AbsListView listView, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
//                int lastItem = firstVisibleItem + visibleItemCount;
//                if(lastItem == totalItemCount) {
//                    System.out.println("Scroll to the listview last item");
//                    View lastItemView = listView.getChildAt(listView.getChildCount()-1);
//                    if ((listView.getBottom())==lastItemView.getBottom()) {
//                        XCApplication.base_log.newE("MYM-------->滑到底部了");
//                    }
//                }
            }
        });
        //音频焦点切换监听
        mAudioFocusChangeListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int focusChange) {
                //暂不做什么
            }
        };
    }

    public void dealPhoto(File file) {
        if (file != null) {
            dShortToast(file.getAbsolutePath());
            if (UtilPackMsg.checkFileSize(file)) {
                sendMsg(UtilPackMsg.packPhotoMsg(file, sessionInfo));
            }
        }
    }

    /**
     * 会话结束后，重新发起会话，model为null如从点击重新发起会话进入聊天页，model不为null如重新推荐用药
     */
    private void requestNewSessionInfo(final XC_ChatModel model) {
        RequestParams params = new RequestParams();
        params.put("patientId", sessionInfo.getUserPatient().getPatientId());
        // 状态1 表示未完成的会话
        params.put("status", "1");
        params.put("orderBy", "1");
        params.put("pageNo", 1);
        params.put("pageSize", 1);

        XCHttpAsyn.postAsyn(this, AppConfig.getChatUrl(AppConfig.chatRecordList), params, new XCHttpResponseHandler() {

            @Override
            public void fail() {
                // 不弹出网络有误的土司
            }

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    startNewSession();
                } else {
                    shortToast("不能发送消息,请您稍后重试!");
                }
            }

            private void startNewSession() {
                // 新建一个model参数，传递给下一个界面做参数
                XC_ChatModel tempSessionInfo = new XC_ChatModel();
                UtilBasicInfo.getAllBasicInfo(tempSessionInfo, sessionInfo.getUserPatient().getPatientId(), UtilSP.getUserId());
                // 这里解析的是status=1 ,未完成的会话
                XC_SessionInfo sessionModel = Parse2RecentSessionId.parse2SessionModel(result_bean);
                if (sessionModel != null) {
                    tempSessionInfo.setSessionId(sessionModel.getSessionId());
                    tempSessionInfo.setSessionBeginTime(sessionModel.getBeginTime());
                    tempSessionInfo.setPayMode(sessionModel.getPayType());
                    tempSessionInfo.setSessionLifeCycle(sessionModel.getSessionLifeCycle());
                    tempSessionInfo.setSessionEndTime(sessionModel.getEndTime());
                }
                // 重开一个会话,onNewIntent()中的launch方法中接收tempSessionInfo参数
                Intent intent = new Intent(XC_ChatDetailActivity.this, XC_ChatDetailActivity.class);
                // 如果没有未发出去的消息(model == null)，cloneMessage()返回null,否则cloneMessage()最后一条未发出去的消息，在新的会话里重发
                intent.putExtra(CommonConfig.SESSION_END_REOPEN_MESSAGE, cloneMessage());
                intent.putExtra(CommonConfig.CHAT_PARAMS_MODEL, tempSessionInfo);
                startActivity(intent);
            }

            @Nullable
            private XC_ChatModel cloneMessage() {
                XC_ChatModel waitingReSendMsg = null;

                if (model != null) {
                    // 不为null，表示有消息因为会话结束了没有发出去
                    Object obj = model.clone();
                    waitingReSendMsg = (XC_ChatModel) obj;
                }
                return waitingReSendMsg;
            }


            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                shortToast("网络错误,不能发送消息,请您稍后重试!");
            }
        });
    }

    /**
     * 键盘将显示，这里可移动的view将设置为不可见
     */
    private void keyboardWillShow() {
        bottombar.getXc_d_chat_bottom_add_imageview().setSelected(false);
        bottombar.getXc_d_chat_bottom_recoder_imageview().setSelected(false);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                UtilViewShow.setGone(false, bottombar.getXc_id_chat_bottom_add_layout());
                UtilViewShow.setGone(false, bottombar.getXc_id_chat_bottom_recoder_layout());
                UtilViewShow.setGone(false, bottombar.getEmojiKeyboard());
                scrollToBottom(70);
            }
        }, 70);
        UtilViewShow.setVisible(false, timeLayout);
    }

    /**
     * 键盘将隐藏
     */
    private void keyboardWillHidden() {
        updateDue();
    }

    /**
     * 如果过期了，显示过期的视图
     * 如果没过期，没回话，显示空白视图
     * 如果没过期，有回话，显示记录
     * <p/>
     * 这里的过期并不是百分百的准确，比如会话结束的push只会推送一次，如果没登录没有收到或者换设备来回登录了，下次服务端是不会推的，这时只能通过发送消息时后台再次返回状态来验证
     */
    private void updateDue() {
        if (isSessionEnd()) {
            // 过期
            XC_ChatModel xc_chatModel = UtilPackMsg.getSessionEndMsg(getApplicationContext(), sessionInfo.getUserDoctor().getDoctorSelfId(), sessionInfo.getUserPatient().getPatientId(), sessionInfo.getSessionId(), sessionInfo.getSessionBeginTime()
                    , sessionInfo.getPayMode(), sessionInfo.getSessionEndTime());
            sessionEndLogic(xc_chatModel);
        } else {
            // 没过期
            // 无sessionId 会话未发起 不显示timelayout, 有sessionId 会话进行中 显示timeLayout
            UtilViewShow.setVisible(!UtilString.isBlank(sessionInfo.getSessionId()), timeLayout);
            UtilViewShow.setGone(true, bottombar);
            UtilViewShow.setGone(false, sessionEndLayout);
        }
    }

    /**
     * 点击文本发送时调用
     */
    private void sendInputEditTextString() {
        String text_content = bottombar.getXc_id_chat_bottom_edittext_input().getText().toString().trim();
        text_content = EmojiSpanUtils.getPatternEmojiMean(text_content);//将表情符号转义成中文意思发给微信
        if (!UtilString.isBlank(text_content)) {
            dShortToast(text_content);
            bottombar.getXc_id_chat_bottom_edittext_input().setText("");

            if (isSessionEnd()) {
                shortToast("会话已结束，请重新发起会话");
                return;
            }
            sendMsg(UtilPackMsg.packTextMsg(text_content, sessionInfo));
        }
    }

    /**
     * 进入健康检查的界面
     */
    private void inToCheckHealth() {
        if (UtiDoctorCheck.isVertify()) {
            ToJumpHelp.toJumpInspectActivity(this,sessionInfo);
        }else {
            keyboardWillHidden();
            toCheck(false);
        }
    }

    /**
     * 进入推荐用药的界面
     */
    private void inToUseMedicine() {
        //dShortToast(searchKey + "");

        if (UtiDoctorCheck.isVertify()) {
            if (!UtilSP.isRecordRecom()){
                ToJumpHelp.toJumpRecommendedMedicationActivity(XC_ChatDetailActivity.this,sessionInfo);
                return;
            }
            UtilChat.requestMedicalRecord(XC_ChatDetailActivity.this,sessionInfo.getUserPatient().getPatientId(),CommonConfig.RECOMMEND_BOTTOM,sessionInfo);
            //医嘱处方埋点
            //add by songxin,date：2018-7-10,about：GrowingIO banner track,begin
            GrowingIOUtil.track("advicePrescriptionclck", null);
            //add by songxin,date：2018-7-10,about：GrowingIO banner track,end
        } else if (!isOutUnCheckSendLinkMedicineTimes()) {
            toCheckDialog = new YR_CommonDialog(XC_ChatDetailActivity.this, YR_CommonDialog.HINT_TRY, "继续推荐", "去认证") {
                @Override
                public void confirmBtn() {
                    toCheckDialog.dismiss();
                    myStartActivity(YY_PersonalDataActivityV2.class);
                }

                @Override
                public void cancelBtn() {
                    super.cancelBtn();
                    if (!UtilSP.isRecordRecom()){
                        ToJumpHelp.toJumpRecommendedMedicationActivity(XC_ChatDetailActivity.this,sessionInfo);
                        return;
                    }
                    //查询最近的病历
                    UtilChat.requestMedicalRecord(XC_ChatDetailActivity.this,sessionInfo.getUserPatient().getPatientId(),CommonConfig.RECOMMEND_BOTTOM,sessionInfo);
                }
            };
            toCheckDialog.show();
        } else {
            keyboardWillHidden();
            toCheck(true);
        }
    }

//    private void toChoiceMedicineActivity(String searchKey) {
//        XC_PatientDrugInfo info = new XC_PatientDrugInfo();
//        info.setChatModel(UtilBasicInfo.getAllBasicInfo(new XC_ChatModel(), sessionInfo.getUserPatient().getPatientId(), UtilSP.getUserId()));
//        RecomMedicineHelper.getInstance().setXC_patientDrugInfo(info);
//        Intent intent = new Intent(this, XD_RecommendedMedicationActivity.class);
//        intent.putExtra(XD_RecommendedMedicationActivity.RECOMMENDED_TYPE,1);
////        startActivityForResult(intent, CommonConfig.REQUEST_CODE_CHOICE_MEDICINE);
//        startActivity(intent);
//    }

    /**
     * 检测审核状态
     *
     * @param isMedicine true 是推荐用药 false 是健康检查
     */
    private void toCheck(boolean isMedicine) {
        if (UtiDoctorCheck.isFailOrNoVerfy()) {
            if (isMedicine) {
                showNoCheckDialog(YR_CommonDialog.HINT_UNCHECK, YY_PersonalDataActivityV2.class);
            } else {
                showNoCheckDialog(YR_CommonDialog.HINT_UNCHECK_HEALTH, YY_PersonalDataActivityV2.class);
            }
        } else if (UtiDoctorCheck.isCheckingOrAgain()) {
            if (isMedicine) {
                showCheckingDialog(YR_CommonDialog.HINT_CHECKING);
            } else {
                showCheckingDialog(YR_CommonDialog.HINT_UNCHECK_HEALTH);
            }
        }
    }

    /**
     * 显示未认证的dialog
     *
     * @param hint 为认证的提示
     * @param cls  跳转到那个activity的class
     */
    private void showNoCheckDialog(String hint, final Class<? extends XCBaseActivity> cls) {
        toCheckDialog = new YR_CommonDialog(XC_ChatDetailActivity.this, hint, "暂不认证", "去认证") {
            @Override
            public void confirmBtn() {
                toCheckDialog.dismiss();
                myStartActivity(cls);
            }
        };
        toCheckDialog.show();
    }

    // add by xjs on 20151119 22:23 start
// 修复JIRA上　http://jira.7lk.me/browse/DBYZ-1024　的问题
    private void showCheckingDialog(String hint) {
        toCheckDialog = new YR_CommonDialog(XC_ChatDetailActivity.this, hint, "", "我知道了") {
            @Override
            public void confirmBtn() {
                toCheckDialog.dismiss();
            }
        };
        toCheckDialog.show();
    }
// add by xjs on 20151119 22:23 end

    /**
     * 跳转到视频播放界面
     */
    private void toVideoActivity(final XC_ChatModel videoMsg) {

        String movieLocalUri = videoMsg.getMoveLocalUri();

        if (!UtilString.isBlank(movieLocalUri) && new File(movieLocalUri).exists() && new File(movieLocalUri).length() > 0) {
            XCApplication.base_log.i(TAG_CHAT, "视频读本地缓存了");
            playVideo(movieLocalUri);
            return;
        }

        // 本地没有,获取网络连接
        String movieHttpUrl = videoMsg.getMoveHttpUri();

        String name = UtilString.getStringFromLastIndex(movieHttpUrl, "/");

        if (UtilString.isBlank(name)) {
            return;
        }

        File cacheFile = UtilFiles.createFileInAndroid(XCConfig.CHAT_MOIVE_DIR, "video_" + name, DBApplication.getInstance());

        if (cacheFile == null) {
            return;
        }

        DownloadHelper downloadHelper = new DownloadHelper(movieHttpUrl, cacheFile);

        downloadHelper.setDownloadListener(new DownloadHelper.DownloadListener() {
            @Override
            public void downloadFinished(final File file) {
                XCApplication.base_log.i(TAG_CHAT, "开始更新数据库中的视频路径--" + file.getAbsolutePath());
                videoMsg.setMoveLocalUri(file.getAbsolutePath());
                chat_dao.update(videoMsg);

                // 播放
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        adapter.notifyDataSetChanged();
                        playVideo(file.getAbsolutePath());//playVideo("/storage/emulated/0/app_ymz/chat/moive/video_6313739020882598395.mp4");
                    }
                });
            }

            public void netFail(File file) {
                if (file != null && file.exists()) {
                    XCApplication.base_log.i(file.getAbsoluteFile() + "--下载视频异常,删除文件了");
                    file.delete();
                }
            }

            @Override
            public void downLoadProgress(int progress, long total, long current) {

            }
        });
        new Thread(downloadHelper).start();
    }

    /**
     * 播放音频
     *
     * @param url 音频文件的url
     */
    private void playVideo(String url) {
        if (XCApplication.isActivityExist(XC_VideoActivity.class)) {
            return;
        }

        Intent intent = new Intent(this, XC_VideoActivity.class);
        Uri uri = Uri.parse(url);
        intent.setData(uri);
        myStartActivity(intent);
    }

    /**
     * 列表在发送消息 后 滚动到底部
     *
     * @param time 延迟多少秒后滚动到底部
     */
    private void scrollToBottom(int time) {
        if (null == adapter){
            return;
        }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                chatListview.setSelection(adapter.getCount());
                UtilViewShow.setGone(false,chatNewMsg);
            }
        }, time);
    }

    @Override
    public void onNetRefresh() {
    }

    /**
     * 记录上一次的播放模式的toast的显示时间，控制频繁弹出
     */
    private long recoderLastShowSpeakerTime;

    /**
     * 仅控制喇叭toast的显示
     */
    private void showSpeakerHint() {
        if (System.currentTimeMillis() - recoderLastShowSpeakerTime > 3000) {
            UtilToast.showChatToast(XC_ChatDetailActivity.this, UtilSP.getIsSpeakLoud(), 2000);
            recoderLastShowSpeakerTime = System.currentTimeMillis();
        }
    }

    private void showLongClickDialog(final XC_ChatModel model) {
        if (dialog == null) {
            dialog = new XCIMMenuDialog(this);
        }

        if ((XC_ChatModel.TEXT + "").equals(model.getMsgType())) {
            // dialog.update("", new String[]{XCIMMenuDialog.LONG_COPY_TEXT, XCIMMenuDialog.DELETE});
            dialog.update("", new String[]{XCIMMenuDialog.LONG_COPY_TEXT});
        } else if ((XC_ChatModel.VOICE + "").equals(model.getMsgType())) {
            if (UtilSP.getIsSpeakLoud()) {
                //dialog.update("", new String[]{XCIMMenuDialog.SMALLSPEAKER, XCIMMenuDialog.DELETE});
                dialog.update("", new String[]{XCIMMenuDialog.SMALLSPEAKER});
            } else {
                //dialog.update("", new String[]{XCIMMenuDialog.LOUDSPEAKER, XCIMMenuDialog.DELETE});
                dialog.update("", new String[]{XCIMMenuDialog.LOUDSPEAKER});
            }
        }
//        else if ((XC_ChatModel.PHOTO + "").equals(model.getMsgType())) {
//            dialog.update("", new String[]{XCIMMenuDialog.DELETE});
//        } else if (UtilPackMsg.isPatientBuyCome(model) || UtilPackMsg.isPatientBuyEnd(model)) {
//            // 提示信息
//            dialog.update("", new String[]{XCIMMenuDialog.DELETE});
//        }
        else {
            return;
        }

        dialog.setOnDialogItemClickListener(new XCIMMenuDialog.OnDialogItemClickListener() {
            public void onClick(View view, String hint) {
                if (XCIMMenuDialog.LONG_COPY_TEXT.equals(hint)) {
                    UtilInputMethod.copyText(XC_ChatDetailActivity.this, model.getMessageText());
                } else if (XCIMMenuDialog.LOUDSPEAKER.equals(hint)) {
                    UtilSP.setIsSpeakLoud(true);
                    updateTitleAndSpeaker();
                    showSpeakerHint();
                } else if (XCIMMenuDialog.SMALLSPEAKER.equals(hint)) {
                    UtilSP.setIsSpeakLoud(false);
                    updateTitleAndSpeaker();
                    showSpeakerHint();
                }
//                else if (XCIMMenuDialog.DELETE.equals(hint)) {
//                    deleteMsg(model);
//                }
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void deleteMsg(final XC_ChatModel model) {
        RequestParams requestParams = new RequestParams();
        requestParams.put("message", UtilIMCreateJson.getImJson(model));

        XCHttpAsyn.postAsyn(this, AppConfig.getChatUrl(AppConfig.chat_delete_msg), requestParams, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    chat_dao.delete(model);
                    if (adapter != null && adapter.getList() != null) {
                        adapter.getList().remove(model);
                        adapter.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();

            }
        });
    }

    /**
     * 快捷回复
     */
    private void quickReply(String message) {
        bottombar.getXc_id_chat_bottom_edittext_input().append(message);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        // 快捷回复
        if (requestCode == CommonConfig.REQUEST_CODE_QUICK_REPLY) {
            quickReply(data.getStringExtra(CommonConfig.QUICK_REPLY_KEY));
            return;
        }

        // 个性化服务收费
        if (requestCode == CommonConfig.INDIVIDUATION_COST_REQUESED_CODE) {
            // created by songxin,date：2017-4-10,about：saveInfo,begin
            BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "INDIVIDUATION_COST_REQUESED_CODE","", false);
            // created by songxin,date：2017-4-10,about：saveInfo,end

            String individuationCostJson = data.getStringExtra(CommonConfig.INDIVIDUATION_COST_JSON);
            if (!TextUtils.isEmpty(individuationCostJson)) {
                if (isSessionEnd()) {
                    requestNewSessionInfo(UtilPackMsg.packIndividuationMsg(individuationCostJson, sessionInfo));
                } else {
                    sendMsg(UtilPackMsg.packIndividuationMsg(individuationCostJson, sessionInfo));
                }
            }
            return;
        }
        // 宣教功能
        if (requestCode == CommonConfig.PUBLICITY_EDUCATION_CODE) {
            Parse2PublicityBean publicityBean = (Parse2PublicityBean)data.getSerializableExtra(CommonConfig.PUBLICITY_EDUCATION_DATA);
            if (null != publicityBean) {
                if (isSessionEnd()) {
                    requestNewSessionInfo(UtilPackMsg.packEduMsg(publicityBean, sessionInfo));
                } else {
                    sendMsg(UtilPackMsg.packEduMsg(publicityBean, sessionInfo));
                }
            }
            return;
        }

        //图文咨询价格设置完之后这里会进行刷新
        if (requestCode == CommonConfig.SET_PERSONAL_CONSULTING_FEES_CODE || requestCode ==
                CommonConfig.REQUEST_CODE_CHAT_SETTING ){
            String payAmount = data.getStringExtra(CommonConfig.PERSONAL_CONSULTING_FEES);
            sessionInfo.getUserPatient().setPayAmount(payAmount);
            setTitleTip(sessionInfo);
        }

        // 会话结束
        if (requestCode == CommonConfig.REQUEST_CODE_SESSION_END) {
            try {
                XC_ChatModel sessionEndModel = (XC_ChatModel) data.getSerializableExtra(SX_SessionEndActivity.SESSION_END_MODEL);
                sessionEndLogic(sessionEndModel);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }

        //聊天页点头像进入患者详情或点右上角图标进入患者设置，改完备注名再回退回来要显示最新患者名
        if (requestCode == CommonConfig.REQUEST_CODE_PATIENT_INFO) {
            if (data != null && data.getExtras() != null) {
                String name = data.getExtras().getString(PF_ChatSetting.PATIENT_NAME);
                if (!TextUtils.isEmpty(name)) {
                    titlebar.setTitleCenter(true, name);
                    sessionInfo.getUserPatient().setPatientMemoName(name);
                    adapter.setPatientInfo(sessionInfo.getUserPatient().getPatientId());
                    adapter.notifyDataSetChanged();
                }
            }
        }

        //用户选择图片完成 add by xd 2017/11/27
        if(requestCode == YY_SelectImgsActivity.REQUEST_IMAGE){
            if(data == null || data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT) == null){
                return;
            }
            File file = (File) data.getSerializableExtra(YY_SelectImgsActivity.REQUEST_OUTPUT);
            if(file!=null){
                File toUploadFile = UtilFile.ChangeImgsToUploadFile(file);//压缩图片
                dealPhoto(toUploadFile);
            }
        }
    }
    @Override
    public void finish() {
        super.finish();
        // 停止正在进行的录音
        closeRecoderWhenDestroy();
        // 停止倒计时
        stopTimer();
        // 重置患者id为空
        resetPatientId();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 解绑绑定
        quitReceiver();
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(toCheckDialog, voiceTimeDialog, dialog,
                mYR_commonDialog,medicineFifterDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        handler.removeCallbacks(null);
    }

    /**
     * 停止录音
     */
    private void closeRecoderWhenDestroy() {
        bottombar.getXc_id_chat_bottom_recoder_button().onActivityDestroy();
    }

    /**
     * 重置患者id
     */
    private void resetPatientId() {
        recoder_which_patient_id = "0";
    }

    /**
     * 解绑广播
     */
    private void quitReceiver() {
        UtilBroadcast.myUnregisterReceiver(this, receiver);
        UtilBroadcast.myUnregisterReceiver(this, mConnectivityReceiver);
        UtilBroadcast.myUnregisterReceiver(this, update_auth_status_receiver);
        UtilBroadcast.myUnregisterReceiver(this, updateEduReceiver);
        UtilBroadcast.myUnregisterReceiver(this, updatePatientReceiver);
        UtilBroadcast.myUnregisterReceiver(this, delPatientReceiver);
        UtilBroadcast.myUnregisterReceiver(this, updateInvalidReceiver);
    }

    /**
     * 计时器
     */
    private CountDownTimer timer;

    /**
     * 请求服务器的时间(该接口不管是会话中还是会话结束，除了服务器时间字段 和 status字段有值外，别的字段都为null)
     */
    private void requestServierTime() {
        if (isDestroy) {
            return;
        }
        final long mOneDaySecond = UtilString.toLong(GlobalConfigSP.getSessionTimeOut());//获取会话过期时间(就是倒计时开始时间)
        RequestParams params = new RequestParams();
        params.put("sessionId", sessionInfo.getSessionId());
        XCHttpAsyn.postAsyn(false, this, AppConfig.getChatUrl(AppConfig.serverTimeAndStatus), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    XC_ServerTimeModel serverTimeModel = Parse2ServerTimeModel.parse(result_bean);

                    // 确定停止
                    stopTimer();

                    if (UtilString.isBlank(serverTimeModel.getSysTime()) || UtilString.isBlank(serverTimeModel.getStatus())) {
                        return;
                    }

                    long serverTime = UtilString.toLong(serverTimeModel.getSysTime());
                    long sessionBeginTimeLong = UtilString.toLong(sessionInfo.getSessionBeginTime());
                    long surplusTime = mOneDaySecond - (serverTime - sessionBeginTimeLong);
                    // 这里再次电话东强确认了，-1咨询中，非-1就表示会话已结束
                    if (!(XC_ServerTimeModel.CONSULT_ING.equals(serverTimeModel.getStatus())) || surplusTime <= 0) {
                        // 场景，换设备登录时A到B再到A手机，B手机时，会话结束，登录回A手机时，列表是未结束的，此时点击进入详情页
                        XC_ChatModel sessionEndModel = UtilPackMsg.getSessionEndMsg(getApplicationContext()
                                , sessionInfo.getUserDoctor().getDoctorSelfId(), sessionInfo.getUserPatient().getPatientId(), sessionInfo.getSessionId(), sessionInfo.getSessionBeginTime(), sessionInfo.getPayMode(), (sessionBeginTimeLong + mOneDaySecond) + "");

                        sessionEndLogic(sessionEndModel);
                    } else {
                        UtilViewShow.setVisible(true, timeLayout);

                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                timeLayout.startAnim();
                            }
                        }, 11000);

                        timer = new CountDownTimer(surplusTime, 1000) {
                            @Override
                            public void onTick(long millisUntilFinished) {
                                timeLayout.setTime("距离结束还剩\n" + UtilDate.formatTime(millisUntilFinished));
                            }

                            @Override
                            public void onFinish() {
                                // 不做处理，全部从服务端获取
                                UtilViewShow.setVisible(false, timeLayout);
                            }
                        };
                        timer.start();
                    }
                }
            }

            // 不显示失败的土司
            @Override
            public void fail() {
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (!result_boolean) {
                    // 如果访问失败了，两秒后继续访问
                    if (!isDestroy) {
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                requestServierTime();
                            }
                        }, 2000);
                    }
                }
            }
        });
    }

    /**
     * destroy的时候记得调用，防止内存泄露
     */
    private void stopTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    /**
     * @param sessionEndMsg 收到会话结束的PUSH 或者 http发送确认会话结束 或者是 会话结束确认页面返回时调用
     */
    private boolean sessionEndLogic(XC_ChatModel sessionEndMsg) {
        if (sessionEndMsg == null) {
            return false;
        }
        if (!sessionEndMsg.isSessionEndType()) {
            return false;
        }
        sessionInfo.setSessionEndTime(sessionEndMsg.getSessionEndTime());
        sessionInfo.setSessionLifeCycle(XC_ChatModel.SESSION_END);
        UtilViewShow.setGone(false, bottombar);
        UtilViewShow.setGone(true, sessionEndLayout);
        UtilViewShow.setVisible(false, timeLayout);
        sessionEndNoticeTextView.setText(sessionEndMsg.getMessageText() + ",   用时" + DateUtils.getTakingTime(sessionEndMsg.getSessionBeginTime(), sessionEndMsg.getMsgTime()));
        stopTimer();

        resetPatientId();
        // 会话结束时，如果正在录音，则停止并发送该条录音(如果该条录音时间符合要求)
        toStopAndSendVoice();
        saveRoughtDraft();
        return true;
    }

    private void toStopAndSendVoice() {
        bottombar.getXc_id_chat_bottom_recoder_button().toStop();
    }

    /**
     * 开始执行动画和请求剩余时间接口
     */
    private void startReqTimer() {
        // sessionid为空（在医生主动发起的时候或是患者主动发起会话时，会返回sessionId,然后再请求requestServierTime（））
        // 没请求成功前，该视图不可见，以防在没请求到服务器时间的时候，用户点击结束会话，可能返回消息属性不完整
        UtilViewShow.setVisible(false, timeLayout);
        if (!UtilString.isBlank(sessionInfo.getSessionId())) {
            requestServierTime();
        }
    }
    XC_VisitDialog visitDialog;
    /**
     * adapter中一系列手势动作的监听
     */
    private void addAdapterActionListener() {
        adapter.setOnItemActionListener(new XC_ChatAdapter.OnItemActionListener() {

            @Override
            public void onRightClickVisitAction(XC_ChatModel model) {
                showVisitDialog(model);
            }

            @Override
            public void onLeftClickVisitAction(XC_ChatModel model) {
                showVisitDialog(model);
            }

            private void showVisitDialog(XC_ChatModel model) {
                if (model != null) {
                    if (visitDialog == null) {
                        visitDialog = new XC_VisitDialog(XC_ChatDetailActivity.this);
                    }
                    visitDialog.show(model.getVisitId(), sessionInfo.getUserPatient().getPatientId());
                }
            }

            @Override
            public void onHintLongClickAction(XC_ChatModel model) {
                showLongClickDialog(model);
            }

            @Override
            public void onRightLongClickPhotoAction(XC_ChatModel model) {
                showLongClickDialog(model);
            }

            @Override
            public void onLeftLongClickPhotoAction(XC_ChatModel model) {
                showLongClickDialog(model);
            }

            @Override
            public void onRightLongClickTextAction(View view, XC_ChatModel model) {
                // 长按复制文本
                showLongClickDialog(model);
            }

            @Override
            public void onLeftLongClickTextAction(View view, XC_ChatModel model) {
                showLongClickDialog(model);
            }

            @Override
            public void onRightLongClickVoiceAction(TextView textView, ImageView imageview, XC_ChatModel model) {
                showLongClickDialog(model);
            }

            @Override
            public void onLeftLongClickVoiceAction(TextView textView, ImageView imageview, XC_ChatModel model) {
                showLongClickDialog(model);
            }

            @Override
            public void onLeftClickPaientPaid(XC_ChatModel model) {
                //点击患者支付图文咨询的通知消息
            }

            @Override
            public void onRightClickResendMsgAction(View view, XC_ChatModel model) {
                // 如果会话结束了，则不能重发
                if (isSessionEnd()) {
                    shortToast("会话已结束，请重新发起会话");
                    return;
                }
                RelativeLayout xc_id_chat_right_net_layout = (RelativeLayout) view.getParent();
                UtilViewShow.setGone(true, xc_id_chat_right_net_layout);
                UtilViewShow.setGone(true, xc_id_chat_right_net_layout.findViewById(R.id.xc_id_chat_right_net_progress_bar));
                UtilViewShow.setGone(false, xc_id_chat_right_net_layout.findViewById(R.id.xc_id_chat_right_net_fail_hint_imageview));
                reSendMsg(model);
            }

            @Override
            public void onRightClickHeadImgAction(View view, XC_ChatModel model) {
                Intent personalDataIntent = new Intent();
                personalDataIntent.putExtra("AuthDataInfo", new AuthDataInfo());
                personalDataIntent.setClass(XC_ChatDetailActivity.this, YY_PersonalDataActivityV2.class);
                startActivity(personalDataIntent);
            }

            @Override
            public void onLeftClickHeadImgAction(View view, XC_ChatModel model) {
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "xc_id_adapter_left_head","", false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                dShortToast("患者--" + sessionInfo.getUserPatient().getPatientId());
                Intent intent = new Intent();
                intent.putExtra(CommonConfig.PATIENT_ID, sessionInfo.getUserPatient().getPatientId());
                intent.setClass(XC_ChatDetailActivity.this, XL_PatientInfoAActivity.class);
                myStartActivityForResult(intent, CommonConfig.REQUEST_CODE_PATIENT_INFO);
            }

            @Override
            public void onRightClickVoiceAction(TextView textView, ImageView horn, XC_ChatModel model) {
                printi(TAG_CHAT, "点击了声音item，传入url，准备播" + "----local：" + model.getVoiceLocalUri() + "-----http:" + model.getVoiceHttpUri());
                showSpeakerHint();
                preparePlayVoice(XC_ChatModel.DOCTOR, model, horn);
            }

            @Override
            public void onLeftClickVoiceAction(TextView textView, ImageView horn, ImageView point, XC_ChatModel model) {
                printi(TAG_CHAT, "点击了声音item，传入url，准备播" + "----local：" + model.getVoiceLocalUri() + "-----http:" + model.getVoiceHttpUri());
                showSpeakerHint();
                preparePlayVoice(XC_ChatModel.PATIENT, model, horn);
                model.setIsRead(XC_ChatModel.READED);
                chat_dao.update(model);
            }

            @Override
            public void onRightClickPhotoAction(View view, XC_ChatModel model) {
                showImages(model);
            }

            @Override
            public void onRightClickPublicityEducationAction(View view, XC_ChatModel model) {
                ToJumpHelp.toJumpPublicityActivity(XC_ChatDetailActivity.this, model,2);
            }

            @Override
            public void onRightClickIndividuationCostAction(View view, XC_ChatModel model) {
                ToJumpHelp.toJumpIndividuationCostActivity(XC_ChatDetailActivity.this, model, 1,CommonConfig.INDIVIDUATION_COST_REQUESED_CODE,"0");
            }
            @Override
            public void onRightClickIndividuationCostSave(View view, XC_ChatModel model) {
                UtilChat.customeAdd(XC_ChatDetailActivity.this,model.getChatModelCustomAdvisory());
            }
            @Override
            public void onRightClickIndividuationCostAgain(View view, XC_ChatModel model) {
                ToJumpHelp.toJumpIndividuationCostActivity(XC_ChatDetailActivity.this, model, 1,CommonConfig.INDIVIDUATION_COST_REQUESED_CODE,"1");
            }

            @Override
            public void onLeftClickPhotoAction(View view, XC_ChatModel model) {
                showImages(model);
            }

            @Override
            public void onLeftClickMovieAction(View view, XC_ChatModel model) {
                toVideoActivity(model);
            }
            @Override
            public void onLeftClickDrugItemAction(String drugId, XC_ChatModel model) {
                UtilNativeHtml5.toJumpDrugDetail(XC_ChatDetailActivity.this, drugId);
            }

            @Override
            public void onRightClickShowAction(XC_ChatModel model) {//需要判断类型
                ToJumpHelp.toJumpRecommendDetailActivity(XC_ChatDetailActivity.this,model.getRecommandId(),model.getUserPatient(),"1");
            }

            @Override
            public void onRightClickShowCheckHealthAction(XC_ChatModel model) {
                InspectOrdonnanceSuccessActivity.launch(XC_ChatDetailActivity.this,model.getRecommandId());
            }

            @Override
            public void onRightClickAssistantKeyAction(String medicineKey) {//联想药品名进行搜索这种类型已经废弃，如果删除请再次和后端以及IOS确认
                if (isSessionEnd()) {
                    shortToast("会话已结束，请重新发起会话");
                    return;
                }
                inToUseMedicine();
            }

            @Override
            public void onLeftClickComfirmMedicineAction(View view, XC_ChatModel model) {
                submit(model,AppConfig.getTuijianUrl(AppConfig.medicationRequireAnswer));
            }

            @Override
            public void onLeftClickScleTestAction(XC_ChatModel model) {
                UtilNativeHtml5.toJumpViagraText(XC_ChatDetailActivity.this, model.getChatModelScale().getScaleId());
            }

            @Override
            public void onLeftClickScleSurveyAction(XC_ChatModel model) {//量表调查表和新的量表UI一样，点击事件在这里根据msgType进行区分
                switch (model.getMsgType()){
                    case XC_ChatModel.SCALE+"":
                        UtilNativeHtml5.toJumpViagraSurvey(XC_ChatDetailActivity.this, model.getChatModelScale().getScaleId());
                        break;
                    case XC_ChatModel.SCALE_NEW+"":
                        UtilNativeHtml5.toJumpScaleNewDetail(XC_ChatDetailActivity.this, model.getChatModelScaleNew().getScaleId());
                        break;
                }
            }

            @Override
            public void onClickMedicineTimeLimitAction(XC_ChatModel model) {
                ToJumpHelp.toJumpRecommendDetailActivity(XC_ChatDetailActivity.this,sessionInfo);
            }

            @Override
            public void onClickMedicalShowAction(XC_ChatModel model) {//根据具体消息类型进行区分,
                boolean isIncludePrescription = !UtilString.isBlank(model.getRecommandId());//为空则表示不带处方的病历
                UtilChat.requestMedicalRecordByRecordId(XC_ChatDetailActivity.this,model,model.getChatModelMedicalRecord().getMedicalRecordId(),model.getRecommandId(),isIncludePrescription,CommonConfig.RECOMMEND_PERSCIPTION,true);
            }

            @Override
            public void onClickMedicalShowPreserctionAction(XC_ChatModel model) {
                //查看处方详情
                UtilChat.requestMedicalRecordByRecordId(XC_ChatDetailActivity.this,model,model.getChatModelMedicalRecord().getMedicalRecordId(),model.getRecommandId(),true,CommonConfig.RECOMMEND_SHOW,true);
                //add by songxin,date：2018-7-10,about：GrowingIO banner track,begin
                GrowingIOUtil.track("viewPrescriptionclck", null);
                //add by songxin,date：2018-7-10,about：GrowingIO banner track,end
            }

            @Override
            public void onClickMedicalAgainSendAction(XC_ChatModel model) {
                //续方
                if (!UtilSP.isRecordRecom()){//假如不是灰度医生
                    final XC_ChatModel modelClone = (XC_ChatModel) model.clone();
                    // 与亮亮沟通->如果是重复推荐，不传requireId或者传0
                    modelClone.setRequireId("0");
                    if (!UtilString.isBlank(modelClone.getRecommandId())) {
                        // 兼容版本升级，2.5之前的历史记录里是没有这个字段的
                        modelClone.setRecommandId(modelClone.getRecommandId());
                        submit(modelClone, AppConfig.getTuijianUrl(AppConfig.repeatRecommand));
                    }
                    return;
                }
                boolean isShowDialog = true;
                if (!UtiDoctorCheck.isVertify()) {
                    // 未认证
                    if (isOutUnCheckSendLinkMedicineTimes()) {
                        // 未认证，且已经超过了试用的次数
                        isShowDialog = false;
                        // 去认证提示
                        toCheck(true);
                        return;
                    }
                }
                UtilChat.requestMedicalRecordByRecordId(XC_ChatDetailActivity.this,model,model.getChatModelMedicalRecord().getMedicalRecordId(),model.getRecommandId(),true,CommonConfig.RECOMMEND_NEW,isShowDialog);
            }

            @Override
            public void onRightClickRecommandAction(final XC_ChatModel bean) {
                // if (isSessionEnd()) { shortToast("会话已结束，请重新发起会话");return} // jira 3198bug，测试提出的期望是，会话结束也可以重新推荐
                // created by songxin,date：2016-4-25,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "onRightLongClickRecommandAction","", false);
                // created by songxin,date：2016-4-25,about：saveInfo,end
                if (bean == null) {
                    return;
                }
                final XC_ChatModel model = (XC_ChatModel) bean.clone();
                // 与亮亮沟通->如果是重复推荐，不传requireId或者传0
                model.setRequireId("0");

                if (!UtilString.isBlank(model.getRecommandId())) {
                    // 兼容版本升级，2.5之前的历史记录里是没有这个字段的
                    submit(model, AppConfig.getTuijianUrl(AppConfig.repeatRecommand));
                }
            }

            /* 因为确认用药和重新推荐除了请求接口和请求参数不一样，其它业务逻辑一样，所以这里把请求参数放在一起 */
            /* 重新推荐的参数(POST /recom/repeat)：token，doctorId,  patientId, recommendId */
            /* 购药咨询确认用药的参数 (POST /medicationRequire/answer) : token，doctorId, requireId, invoker */
            private void submit(XC_ChatModel bean, String url) {
                // 点击确认用药按钮
                RequestParams params = new RequestParams();
                params.put("doctorId", bean.getUserDoctor().getDoctorSelfId());
                params.put("patientId",bean.getUserPatient().getPatientId());
                params.put("requireId", bean.getRequireId());//推荐用药的时候，服务端会接收这个值，其实传0也可以
                params.put("recommendId", bean.getRecommandId());//重新推荐用药的时候，服务端会接收这个值
                // add by xjs on 20160504 start
                // 后端为了区分调用是在什么情况下发生的，要求增加这个参数
                params.put("invoker", "0");
                // add by xjs on 20160504 end

                boolean isShowDialog = true;
                if (!UtiDoctorCheck.isVertify()) {
                    // 未认证
                    if (isOutUnCheckSendLinkMedicineTimes()) {
                        // 未认证，且已经超过了试用的次数
                        isShowDialog = false;
                        // 去认证提示
                        toCheck(true);
                        return;
                    }
                }
                requestUsage(isShowDialog, bean, params, url);
            }
        });
    }
    /**
     * 在会话过期的时候，不可以重新发送，除非是重新开启一个会话
     */
    public void reSendMsg(XC_ChatModel reSendMsg) {
        if (reSendMsg == null) {
            return;
        }
        if (isSessionEnd()) {
            shortToast("会话已结束，请重新发起会话");
            return;
        }

        // 从数据库删除这条信息，必须放前面，否则msgUnique更新后，就找不到这条消息了
        chat_dao.delete(reSendMsg);

        // 从列表集合里删除这条信息
        if (adapter != null && !UtilCollection.isBlank(adapter.getList())) {
            adapter.getList().remove(reSendMsg);
            adapter.notifyDataSetChanged();
        }
        // 重发信息时,如重新推荐用药的信息就需要更新sessionId(下拉的历史记录里可能有别的会话的推荐用药的消息)
        sendMsg(UtilPackMsg.packSendCommon(reSendMsg, sessionInfo));
    }

    /**
     * 当是自主购药、重复推荐的时候会运行到这里，自主购药和重复推荐是一样的逻辑
     */
    private void requestUsage(final boolean isShowDialog, final XC_ChatModel bean, RequestParams params, final String url) {

        XCHttpAsyn.postAsyn(isShowDialog, this, url, params, new XCHttpResponseHandler() {

                    @Override
                    public void success() {
                        super.success();
                    }

                    @Override
                    public void onSuccess(int code, Header[] headers, byte[] arg2) {
                        super.onSuccess(code, headers, arg2);
                        if (CommonConfig.MEDICINE_FIFTER_CODE.equals(getCode())){//假如符合正大天晴项目规则，则弹出对话框并终止下一步操作
                            medicineFifterDialog(getMsg());
                            return;
                        }
                        // 后台约定，如果是未认证且超过了使用次数，请求该接口，但是不做处理
                        if (isShowDialog) {
                            XC_PatientDrugInfo patientDrugInfo = Parse2PatientDrugInfoModel.parse(result_bean, bean);
                            if (result_boolean) {
                                //该接口是没有数量的， 与后台沟通了，最后是客户端从bean里获取
                                patientDrugInfo.obtQuantity(UtilIMCreateJson.recommandMedicineMsg2Drugs(bean));
                                if(url.equals(AppConfig.getTuijianUrl(AppConfig.repeatRecommand))){
                                    patientDrugInfo.setCheckInventoryInfo(true);
                                    patientDrugInfo.setPatientBuy(false);
                                }else {
                                    patientDrugInfo.setPatientBuy(true);
                                }
                                if(!UtilCollection.isBlank(patientDrugInfo.getDiagnoseBeanList())){//如果诊断信息不为空，则认为患者是从医生的处方那里进行购买的
                                    patientDrugInfo.setCheckInventoryInfo(true);
                                }
                                RecomMedicineHelper.getInstance().setFlag("1");
                                RecomMedicineHelper.getInstance().setXC_patientDrugInfo(patientDrugInfo);
//                                Intent intent = new Intent(XC_ChatDetailActivity.this, XD_RecommendedMedicationActivity.class);
//                                intent.putExtra(XD_RecommendedMedicationActivity.RECOMMENDED_TYPE,2);
//                                myStartActivityForResult(intent, CommonConfig.REQUEST_CODE_CHOICE_MEDICINE);
//                                startActivity(intent);
                                if (!UtilSP.isRecordRecom()){//假如不是医嘱处方用户，沿用旧的逻辑
                                    SQ_RecommendActivity.launch(XC_ChatDetailActivity.this);
                                    return;
                                }
                                if(url.equals(AppConfig.getTuijianUrl(AppConfig.repeatRecommand))){//重新推荐
                                    UtilChat.requestMedicalRecord(XC_ChatDetailActivity.this,sessionInfo.getUserPatient().getPatientId(),CommonConfig.RECOMMEND_OLD,sessionInfo);
                                }else {
                                    UtilChat.requestMedicalRecord(XC_ChatDetailActivity.this,sessionInfo.getUserPatient().getPatientId(),CommonConfig.RECOMMEND,sessionInfo);
                                }
                            }
                        }
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        GeneralReqExceptionProcess.checkCode(XC_ChatDetailActivity.this, getCode(), getMsg());
                    }
                }
        );
    }

    private MediaPlayer mediaplayer;
    /**
     * 记录当前是播放到哪一个url了
     */
    private String recoder_voice_url;
    private AnimationDrawable recoder_playing_drawable;
    /**
     * 记录当前是哪一个imageview在播放动画
     */
    private ImageView recoder_playing_imageview;
    private int recoder_type;

    /**
     * 准备播放语音消息
     *
     * @param sender    发送则
     * @param bean      点击了那一条信息
     * @param imageview 点击语音信息的喇叭
     */
    private void preparePlayVoice(final int sender, final XC_ChatModel bean, final ImageView imageview) {
        String voiceLocalUri = bean.getVoiceLocalUri();

        if (!UtilString.isBlank(voiceLocalUri) && new File(voiceLocalUri).exists()) {
            // 有本地则直接读缓存
            DBApplication.base_log.i(TAG_CHAT, "读语音缓存--url--" + voiceLocalUri);
            playVoice(sender, imageview, voiceLocalUri);
            return;
        }
        // 本地没有,获取网络连接
        String voiceHttpUri = bean.getVoiceHttpUri();
        String name = UtilString.getStringFromLastIndex(voiceHttpUri, "/");
        if (UtilString.isBlank(name)) {
            return;
        }
        File cacheFile = UtilFiles.createFileInAndroid(XCConfig.CHAT_VOICE_DIR, "voice_" + name, DBApplication.getInstance());
        if (cacheFile == null) {
            return;
        }
        DownloadHelper helper = new DownloadHelper(voiceHttpUri, cacheFile);
        helper.setDownloadListener(new DownloadHelper.DownloadListener() {
            @Override
            public void downloadFinished(File file) {
                DBApplication.base_log.i(TAG_CHAT, "开始更新数据库中的音频路径--" + file.getAbsolutePath());
                bean.setVoiceLocalUri(file.getAbsolutePath());
                chat_dao.update(bean);
                // 播放  add by cyr on 2016-7-16  修复加载后 首次点击音频没反应的bug
                playVoice(sender, imageview, file.getAbsolutePath());
            }

            @Override
            public void netFail(File file) {
                if (file != null && file.exists()) {
                    DBApplication.base_log.i(file.getAbsoluteFile() + "--下载音频异常,删除文件了");
                    file.delete();
                }
            }
            @Override
            public void downLoadProgress(int progress, long total, long current) {

            }
        });
        new Thread(helper).start();
    }

    /**
     * 播放音频
     *
     * @param sender    发送者
     * @param imageview 喇叭ui，喇叭会有个动画
     * @param url       音频的路径
     */
    private void playVoice(int sender, ImageView imageview, String url) {
        AnimationDrawable temp_drawable;

        if (sender == XC_ChatModel.DOCTOR) {
            temp_drawable = (AnimationDrawable) ContextCompat.getDrawable(this,R.drawable.xc_dd_anim_chat_greenbg_framelist);
        } else {
            temp_drawable = (AnimationDrawable) ContextCompat.getDrawable(this,R.drawable.xc_dd_anim_chat_whitebg_framelist);
        }

        if (url != null) {
            if (!url.equals(recoder_voice_url)) {
                // 如果不是同一个url，可能是第一次播放（current_voice_url为null），也可能是切换到另外一个播放
                DBApplication.base_log.i(TAG_CHAT, "点击了不是同一个url");
                voiceRecordAndOpen(temp_drawable, imageview, sender, url);
            } else {
                // 同一个url ， 两个情况， 一个是正在播放，一个是已经播放完了
                DBApplication.base_log.i(TAG_CHAT, "点击了同一个url");
                if (mediaplayer == null) {
                    // 已经播放完了
                    voiceRecordAndOpen(temp_drawable, imageview, sender, url);
                } else {
                    // 正在播放，如果再次点击播放，则停止
                    finishVoicePlaying();
                }
            }
        } else {
            DBApplication.base_log.i(TAG_CHAT, "传过来准备播放的语音url为空");
        }
    }

    private void voiceRecordAndOpen(final AnimationDrawable temp_drawable, final ImageView imageview, final int type, final String url) {
        try {
            // 1 播放完了后，再次点击播放， 确认停止播放
            // 2 先结束上一个播放
            finishVoicePlaying();
            // 记录当前正准备播放的item信息
            recoder_playing_drawable = temp_drawable;
            recoder_playing_imageview = imageview;
            recoder_type = type;
            printi(TAG_CHAT, "音频播放器正在创建中--" + url);
            mediaplayer = new MediaPlayer();
            recoder_voice_url = url;
            // 置为初始状态
            mediaplayer.reset();
            // 设置文件路径
            mediaplayer.setDataSource(url);
            // 设置缓冲完成监听(当缓冲完成的时候,调用该监听器)
            mediaplayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(MediaPlayer mediaPlayer) {
                    try {
                        // add by xjs on 20151121 11:17 start
                        // 在此要添加设置播放模式的处理（如果用户选择的播放模式是“听筒模式”，则设置成听筒模式播放），修复JIRA上编号为955的问题。
                        if (!(UtilSP.getIsSpeakLoud())) {
                            UtilSound.setSpeakerphoneOn(XC_ChatDetailActivity.this, false);
                        }
                        // add by xjs on 20151121 11:17 end

                        printi(TAG_CHAT, "音频播放器缓冲完了---开始播放" + url);

                        //请求音频焦点，暂停第三方播放器 add by syy 2016-05-06 jira2041
                        UtilSound.requestAudioFocus(XC_ChatDetailActivity.this, mAudioFocusChangeListener);

                        mediaplayer.start();
                        imageview.setImageDrawable(temp_drawable);
                        temp_drawable.start();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            mediaplayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer mediaPlayer) {
                    printi(TAG_CHAT, "音频播放器播放结束了" + url);
                    finishVoicePlaying();

                    //放弃音频焦点，使第三方播放器继续播放 add by syy 2016-05-06 jira2041
                    UtilSound.abandonAudioFocus(XC_ChatDetailActivity.this, mAudioFocusChangeListener);
                }
            });
            mediaplayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    try {
                        if (url != null) {
                            File file = new File(url);
                            if (file.exists()) {
                                // 可能是文件损坏了等原因,删掉缓存
                                file.delete();
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return false;
                }
            });
            // 准备(缓冲)
            mediaplayer.prepare();
        } catch (Exception e) {
            e.printStackTrace();
            printi(TAG_CHAT, "调用voiceRecordAndOpen方法异常");
        }
    }
    /**
     * 结束音频的播放
     */
    private void finishVoicePlaying() {
        if (mediaplayer != null) {
            mediaplayer.stop();
            mediaplayer.release();
            mediaplayer = null;
            printi(TAG_CHAT, "finishVoicePlaying()---语音播放器销毁了，下一步关闭动画");
        }
        if (recoder_playing_drawable != null) {
            recoder_playing_drawable.stop();
            recoder_playing_drawable = null;
            printi(TAG_CHAT, "finishVoicePlaying()---语音动画销毁了，下一步恢复静态的语音视图");
        }
        if (recoder_playing_imageview != null) {
            if (XC_ChatModel.DOCTOR == recoder_type) {
                recoder_playing_imageview.setImageResource(R.drawable.xc_d_chat_voice_for_greenbg_launch3);
            } else {
                recoder_playing_imageview.setImageResource(R.drawable.xc_d_chat_voice_for_whitebg_launch3);
            }
            recoder_playing_imageview = null;
            recoder_type = -1;
            printi(TAG_CHAT, "finishVoicePlaying()---恢复静态的语音视图");
        }
        // add by xjs on 20151121 11:17 start
        // 在此要添加还原播放模式为扬声器模式的处理（修复JIRA上编号为955的问题）
        UtilSound.setSpeakerphoneOn(XC_ChatDetailActivity.this, true);
        // add by xjs on 20151121 11:17 end
    }
    /**
     * 点击图片的时候跳入到另外一个activity展示
     * @param model 点击的图片消息的model
     */
    private void showImages(XC_ChatModel model) {
        ArrayList<String> images = new ArrayList<>();
        List<XC_ChatModel> list = adapter.getList();
        String first_imageurl = UtilChatPhoto.getPhotoUrl(model);
        if (UtilString.isBlank(first_imageurl)) {
            // 网络与本地都为空时
            return;
        }
        int count = 0;
        int index = 0;
        for (XC_ChatModel bean : list) {
            int msgType = UtilString.toInt(bean.getMsgType());
            if (XC_ChatModel.PHOTO != msgType){
                continue;
            }
            String uri = UtilChatPhoto.getPhotoUrl(bean);
            if (first_imageurl.equals(uri)) {
                index = count;
            }
            if (!UtilString.isBlank(uri)) {
                images.add(uri);
                count++;
            }
        }
        ToJumpHelp.toJumpChatImageShowActivity(this,images,index);
    }
    /**
     * add by 马杨茗 on 20160616
     * 重写该方法解决部分三星手机拍照时屏幕旋转导致activity重新绘制引起无法获取拍照后的数据
     * AndroidManifest.xml中对此类有相应改变
     */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
    //设置Title的Tip显示内容
    //关于2.7版本收费模式的解释，原则来说收费只针对患者进行收费，所以医生发起的会话均认为是免费的
    View titleTipRootView;
    private void setTitleTip(final XC_ChatModel model){
        if (!UtilChat.isOpenTitleTip(model.getTitleTipCloseTime())){
            return;
        }
        String titleTipContent =  "当前咨询为免费，您可以设置图文咨询收费。";
        String titleTipSetting = "立即设置 >";
        if (!TextUtils.isEmpty(model.getUserPatient().getPayAmount()) && StringUtils.getMoneyLong(model.getUserPatient().getPayAmount()) > 0){//价格为0认为是免费, 字符串为空也认为是免费
            titleTipContent = "当前患者已设置图文咨询收费（"+ StringUtils.getMoney(model.getUserPatient().getPayAmount()) +"元/次）";
            titleTipSetting = "查看详情 >";
        }
        if (TextUtils.isEmpty(model.getUserPatient().getPayAmount())){
            requestConsultInfo(model);
        }
        if (null == titleTipRootView){
            ViewStub titleTipViewStub = (ViewStub) findViewById(R.id.title_tip_vs);
            titleTipRootView = titleTipViewStub.inflate();
        }
        ImageView titleTipCloseIv = (ImageView) findViewById(R.id.title_tip_close);
        TextView titleTipContentTv = (TextView) findViewById(R.id.title_tip_content);
        final TextView titleTipSettingTv = (TextView) findViewById(R.id.title_tip_setting);
        titleTipContentTv.setText(titleTipContent);
        titleTipSettingTv.setText(titleTipSetting);
        titleTipSettingTv.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG );
        titleTipCloseIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "titleTipCloseIv","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end
                titleTipRootView.setVisibility(View.GONE);
                //更新关闭收费通知的时间
                model.setTitleTipCloseTime(String.valueOf(System.currentTimeMillis()));
                JS_ChatListDB.getInstance(getApplicationContext(), sessionInfo.getUserDoctor().getDoctorSelfId()).updateTitleTipCloseTime(model);
            }
        });
        titleTipSettingTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // created by songxin,date：2017-4-10,about：saveInfo,begin
                BiUtil.saveBiInfo(XC_ChatDetailActivity.class, "2", "128", "titleTipSettingTv","", false);
                // created by songxin,date：2017-4-10,about：saveInfo,end
                //add by xd  设置个人咨询费
                ToJumpHelp.toJumpSetPersonalConsultFeesActivity(XC_ChatDetailActivity.this, sessionInfo, CommonConfig.SET_PERSONAL_CONSULTING_FEES_CODE);
            }
        });
    }

}
