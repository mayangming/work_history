package com.qlk.ymz.db.medicineUageDosage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.qlk.ymz.model.medicine.MedicineUsageBean;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MedicineUsageBeanDb extends SQLiteOpenHelper{

    public static String mDefaultDbName = "medicineUsageBean.db";
    public static int mVersion = 1;
    public static String mOperatorTableName = "medicineUsageBeanTable";

    /** 排序常量 */
    public static String SORT_DESC = " DESC";// 有个空格符号，勿删
    public static String SORT_ASC = " ASC";// 有个空格符号，勿删

    /**以下是表字段*/
    public static final String _ID = "_id";
    /**
     dosageCount (integer, optional): 次数 ,
     dosageCycle (number, optional): 几月、几日 、几小时 注：有0.5小时的情况 ,
     dosageCycleUnit (string, optional): 单位：日、隔日、小时、周、月等 ,
     dosageStr (integer, optional): 默认用量字符串 ,
     eachDosageCount (number, optional): 每次几片,几毫克,几粒等等 ,
     eachDoseUnit (string, optional): 药品服用单位 ,
     packagSpec (number, optional): 最小规格包装数（如：一盒有多少片 ） ,
     skuId (integer, optional):  ,
     quantityUnit (string, optional): 药品单位:盒、瓶 ,
     usageMethod (string, optional): 服用方式 ,
     usageTime (string, optional): 服用时间
     usages 用法用量文本
     drugCycle (integer, optional): 用药周期([2]周) ,
     drugCycleUnit (string, optional): 用药周期单位(2[周]) ,
     bakUp (string, optional): 备注 ,
     */
    public static final String DOSAGE_COUNT = "dosageCount";
    public static final String DOSAGE_CYCLE = "dosageCycle";
    public static final String DOSAGE_CYCLE_UNIT = "dosageCycleUnit";
    public static final String DOSAGE_STR = "dosageStr";
    public static final String EACH_DOSAGE_COUNT = "eachDosageCount";
    public static final String EACH_DOSE_UNIT = "eachDoseUnit";
    public static final String PACKAG_SPEC = "packagSpec";
    public static final String SKU_ID = "skuId";
    public static final String QUANTITY_UNIT = "quantityUnit";
    public static final String USAGE_METHOD = "usageMethod";
    public static final String USAGE_TIME = "usageTime";
    public static final String DRUG_CYCLE = "drugCycle";
    public static final String DRUG_CYCLE_UNIT = "drugCycleUnit";
    public static final String USAGES = "usages";
    public static final String QUANTITY = "quantity";
    public static final String BAK_UP = "bakUp";

    /**
     * 装db集合的
     */
    public static Map<String,MedicineUsageBeanDb> map = new LinkedHashMap<String,MedicineUsageBeanDb>();

    public static MedicineUsageBeanDb getInstance(Context context, String userId) {
        String dbName = mDefaultDbName + "_" + userId;
        MedicineUsageBeanDb db = map.get(dbName);

        if (db != null) {
            return db;
        }

        synchronized (MedicineUsageBeanDb.class) {
            if (map.get(dbName) == null) {
                map.put(dbName, new MedicineUsageBeanDb(context, dbName));
            }
            return map.get(dbName);
        }

    }

    private MedicineUsageBeanDb (Context context) {
        super(context, mDefaultDbName, null, mVersion);
    }

    private MedicineUsageBeanDb (Context context,String dbName) {
        super(context, dbName, null, mVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " +  mOperatorTableName
                + "("+_ID +" integer primary key autoincrement,"
                + DOSAGE_COUNT + " text, "
                + DOSAGE_CYCLE + " text, "
                + DOSAGE_CYCLE_UNIT + " text, "
                + DOSAGE_STR + " text, "
                + EACH_DOSAGE_COUNT + " text, "
                + EACH_DOSE_UNIT + " text, "
                + PACKAG_SPEC + " text, "
                + SKU_ID + " text, "
                + QUANTITY_UNIT + " text, "
                + USAGE_METHOD + " text, "
                + USAGE_TIME + " text, "
                + DRUG_CYCLE + " text, "
                + DRUG_CYCLE_UNIT + " text, "
                + USAGES + " text, "
                + QUANTITY + " text, "
                + BAK_UP + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

    }

    public ContentValues createContentValue(MedicineUsageBean model) {
        ContentValues values = new ContentValues();
        values.put(DOSAGE_COUNT, model.getDosageCount());
        values.put(DOSAGE_CYCLE, model.getDosageCycle());
        values.put(DOSAGE_CYCLE_UNIT, model.getDosageCycleUnit());
        values.put(DOSAGE_STR, model.getDosageStr());
        values.put(EACH_DOSAGE_COUNT, model.getEachDosageCount());
        values.put(EACH_DOSE_UNIT, model.getEachDoseUnit());
        values.put(PACKAG_SPEC, model.getPackagSpec());
        values.put(SKU_ID, model.getSkuId());
        values.put(QUANTITY_UNIT, model.getQuantityUnit());
        values.put(USAGE_METHOD, model.getUsageMethod());
        values.put(USAGE_TIME, model.getUsageTime());
        values.put(DRUG_CYCLE, model.getDrugCycle());
        values.put(DRUG_CYCLE_UNIT, model.getDrugCycleUnit());
        values.put(USAGES, model.getUsages());
        values.put(QUANTITY, model.getQuantity());
        values.put(BAK_UP, model.getBakUp());
        return values;
    }

    public MedicineUsageBean createModel(Cursor c){
        MedicineUsageBean model = new MedicineUsageBean();
        model.setDosageCount(c.getString(c.getColumnIndex(DOSAGE_COUNT)));
        model.setDosageCycle(c.getString(c.getColumnIndex(DOSAGE_CYCLE)));
        model.setDosageCycleUnit(c.getString(c.getColumnIndex(DOSAGE_CYCLE_UNIT)));
        model.setDosageStr(c.getString(c.getColumnIndex(DOSAGE_STR)));
        model.setEachDosageCount(c.getString(c.getColumnIndex(EACH_DOSAGE_COUNT)));
        model.setEachDoseUnit(c.getString(c.getColumnIndex(EACH_DOSE_UNIT)));
        model.setPackagSpec(c.getString(c.getColumnIndex(PACKAG_SPEC)));
        model.setSkuId(c.getString(c.getColumnIndex(SKU_ID)));
        model.setQuantityUnit(c.getString(c.getColumnIndex(QUANTITY_UNIT)));
        model.setUsageMethod(c.getString(c.getColumnIndex(USAGE_METHOD)));
        model.setUsageTime(c.getString(c.getColumnIndex(USAGE_TIME)));
        model.setDrugCycle(c.getString(c.getColumnIndex(DRUG_CYCLE)));
        model.setDrugCycleUnit(c.getString(c.getColumnIndex(DRUG_CYCLE_UNIT)));
        model.setUsages(c.getString(c.getColumnIndex(USAGES)));
        model.setQuantity(c.getString(c.getColumnIndex(QUANTITY)));
        model.setBakUp(c.getString(c.getColumnIndex(BAK_UP)));
        return model;
    }

    /** 插入一条记录 */
    public synchronized  long insert(MedicineUsageBean model) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = createContentValue(model);
        long id ;
        id = db.insert(mOperatorTableName, _ID, values);

        //XCLog.i(XCConfig.TAG_DB, "insert()插入的记录的id是: " + id);
        db.close();
        return id;
    }

    /** 更新一条记录 */
    public synchronized  long update(MedicineUsageBean model) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = createContentValue(model);
        long id ;
        // 查询
        Cursor c = db.query(mOperatorTableName, null,SKU_ID + "=?",new String[]{model.getSkuId()}, null, null, null, null);
        if(c != null && c.getCount() > 0) {
            // 如果存在 则更新
            id = db.update(mOperatorTableName,values,SKU_ID + "=?",new String[]{model.getSkuId()});
        }else {
            // 否则插入
            id = db.insert(mOperatorTableName, _ID, values);
        }

        //XCLog.i(XCConfig.TAG_DB, "insert()插入的记录的id是: " + id);
        if(c != null)c.close();
        db.close();
        return id;
    }

    /** 查询一条记录
     * 查询不到返回null
     * */
    public synchronized MedicineUsageBean query(String skuId) {
        MedicineUsageBean bean = null;
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null,SKU_ID + "=?",new String[]{skuId}, null, null, null, null);
        if(c != null && c.getCount() > 0) {
            c.moveToFirst();
            bean = createModel(c);
        }
        if(c != null)c.close();
        db.close();
        return bean;
    }

    public synchronized  long inserts(List<MedicineUsageBean> list) {
        int count = 0;
        SQLiteDatabase db = getWritableDatabase();
        for(MedicineUsageBean model : list){
            ContentValues values = createContentValue(model);
            long id = db.insert(mOperatorTableName, _ID, values);
            //XCLog.i(XCConfig.TAG_DB, "insert()插入的记录的id是: " + id);
            count++;
        }
        db.close();
        return count;
    }

    /** 删除所有记录 */
    public synchronized int deleteAll() {
        SQLiteDatabase db = getWritableDatabase();
        int raw = db.delete(mOperatorTableName, null, null);
        db.close();
        return raw;
    }

    /** 查询共有多少条记录 */
    public synchronized int queryCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, new String[]{"COUNT(*)"},null, null, null, null, null, null);
        c.moveToNext();
        int count = c.getInt(0);
        c.close();
        db.close();
        return count;
    }

    /** 查询所有*/
    public synchronized List<MedicineUsageBean> queryAllByIdDesc() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null,_ID + SORT_DESC); // 条件为null可以查询所有
        List<MedicineUsageBean> beans = new ArrayList<MedicineUsageBean>();
        while (c.moveToNext()) {
            MedicineUsageBean bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /** 查询所有*/
    public synchronized List<MedicineUsageBean> queryAllByIdAsc() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null,_ID + SORT_ASC);
        List<MedicineUsageBean> beans = new ArrayList<MedicineUsageBean>();
        while (c.moveToNext()) {
            MedicineUsageBean bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /** 分页查找 */
    public synchronized List<MedicineUsageBean> queryPageByIdAsc(int pageNum, int capacity){
        String offset = (pageNum - 1) * capacity + ""; // 偏移量
        String len = capacity + ""; // 个数
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_ASC , offset + "," + len);
        List<MedicineUsageBean> beans = new ArrayList<MedicineUsageBean>();
        while (c.moveToNext()) {
            MedicineUsageBean bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }

    /** 分页查找 */
    public synchronized List<MedicineUsageBean> queryPageByIdDesc(int pageNum, int capacity){
        String offset = (pageNum - 1) * capacity + ""; // 偏移量
        String len = capacity + ""; // 个数
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_DESC , offset + "," + len);
        List<MedicineUsageBean> beans = new ArrayList<MedicineUsageBean>();
        while (c.moveToNext()) {
            MedicineUsageBean bean = createModel(c);
            beans.add(bean);
        }
        c.close();
        db.close();
        return beans;
    }
}