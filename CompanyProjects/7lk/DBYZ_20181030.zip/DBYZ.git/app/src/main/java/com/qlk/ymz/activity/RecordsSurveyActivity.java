package com.qlk.ymz.activity;

import android.content.Intent;
import android.view.View;
import android.widget.LinearLayout;

import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.HospitalBackupsBeanSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.tencent.smtt.sdk.WebSettings;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;

/**
 * 备案调查页
 * @author zhangpengfei.
 * @version 1.0
 */

public class RecordsSurveyActivity extends DBActivity {
    XCTitleCommonLayout titleLayout;
    private WebView webview;
    /** 加载loading布局 */
    private LinearLayout ll_loading;
    /**备案调查地址*/
    private String url = "https://jinshuju.net/f/GANxHC";
    private Intent intent;
    public static boolean isReturnMainActivity;

    /** created by songxin,date：2018-10-29,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(RecordsSurveyActivity.class);
    }

    /** created by songxin,date：2018-10-29,about：bi,end */

    @Override
    public void initWidgets() {
        setContentView(R.layout.activity_records_survey);
        titleLayout = getViewById(R.id.xc_id_model_titlebar);
        webview = getViewById(R.id.webview);
        ll_loading = getViewById(R.id.ll_loading);
        titleLayout.setTitleLeft(true, "关闭");
        titleLayout.getXc_id_titlebar_left_imageview().setVisibility(View.INVISIBLE);
        // 设置loading半透明
        ll_loading.setAlpha(0.5f);
        WebSettings settings = webview.getSettings();
        // 自适应屏幕
        // 设置webview推荐使用的窗口
        settings.setUseWideViewPort(true);
        // 设置webview加载的页面的模式
        settings.setLoadWithOverviewMode(true);
        // 不进行缓存，总是使用网络数据
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        //开启 DOM 存储功能
        settings.setDomStorageEnabled(true);
        webview.loadUrl(url);
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void listeners() {
        titleLayout.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        webview.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView webView, String s) {
                super.onPageFinished(webView, s);
                ll_loading.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if(NativeHtml5.QLK_HOME.equals(HospitalBackupsBeanSP.TO_ACTIVITY)) {
            intent = new Intent(RecordsSurveyActivity.this, JS_MainActivity.class);
            intent.putExtra(JS_MainActivity.IS_SHOWN_IDENTYFY_DIALOG, true);
            intent.putExtra(JS_MainActivity.TAB_TAG,JS_MainActivity.TAB_HOME);
            startActivity(intent);
            finish();
        }else if(NativeHtml5.DOCTOR_MINE.equals(HospitalBackupsBeanSP.TO_ACTIVITY)){
            intent = new Intent(RecordsSurveyActivity.this, JS_MainActivity.class);
            intent.putExtra(JS_MainActivity.TAB_TAG,JS_MainActivity.TAB_MY);
            startActivity(intent);
            finish();
        }else if(NativeHtml5.RECOMMEND_DETAIL.equals(HospitalBackupsBeanSP.TO_ACTIVITY)){
            SQ_RecommendActivity.launch(this);
            finish();
        }else if(NativeHtml5.QLK_JIFEN_MANAGE.equals(HospitalBackupsBeanSP.TO_ACTIVITY)){
            intent = new Intent(RecordsSurveyActivity.this, XL_PointsActivityV2.class);
            startActivity(intent);
            finish();
        }else {
            super.onBackPressed();
        }

    }
}
