package com.qlk.ymz.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.PF_PaBean;
import com.qlk.ymz.util.NativeHtml5;
import com.xiaocoder.android.fw.general.base.XCBaseActivity;
import com.xiaocoder.android.fw.general.util.UtilDate;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 私人助理adapter
 * @author zhangpengfei on 2016/1/13.
 * @version 1.2.0
 */
public class PF_PaAdapter extends BaseAdapter {
    private Context mContext;
    private List<PF_PaBean.DataEntity.ResultEntity> mList;
    private LayoutInflater mLayoutInflater;

    public void setmList(List<PF_PaBean.DataEntity.ResultEntity> mList) {
        if (null != mList && mList.size() > 0){
            this.mList = mList;
            notifyDataSetChanged();
        }
    }

    public PF_PaAdapter(Context context, List<PF_PaBean.DataEntity.ResultEntity> mList){
        this.mContext = context;
        this.mList = mList;
        this.mLayoutInflater = LayoutInflater.from(context);

    }
    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(null == convertView){
            convertView = mLayoutInflater.inflate(R.layout.pf_item_pa,null);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)convertView.getTag();
        }
        if (null != mList){
            final PF_PaBean.DataEntity.ResultEntity entity= mList.get(position);
            if (null != entity){

                String time = UtilDate.convertTimeToFormat(UtilString.toLong(entity.getSysTime()));
                viewHolder.pf_id_item_pa_time.setText(time+"");
                viewHolder.pf_id_item_pa_message.setText(Html.fromHtml(entity.getContent()));
                viewHolder.pf_id_item_pa_message.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String url = "";
                        Pattern pattern;
                        Matcher matcher;
                        pattern = Pattern.compile("<a(?: [^>]*)+href=([^ >]*)(?: [^>]*)*>");
                        matcher = pattern.matcher(entity.getContent());
                        while (matcher.find()) {
                            String str = matcher.group();
                            int index_start = str.indexOf("href='") + "href='".length();
                            int index_end = str.indexOf("'>");
                            url = str.substring(index_start, index_end);
                            if (mContext instanceof XCBaseActivity){
                                //需要通过nativehtml5配置协议来跳转到指定页面(不止h5页面)
                                NativeHtml5.newInstance((XCBaseActivity) mContext).webToAppPage(url);
                            }
                        }
                    }
                });
                if ((mList.size() - 1) == position){
                    viewHolder.pf_id_item_place_zone.setVisibility(View.VISIBLE);
                }else {
                    viewHolder.pf_id_item_place_zone.setVisibility(View.GONE);
                }

            }
        }
        return convertView;
    }

    static class ViewHolder{
        /**时间*/
        private TextView pf_id_item_pa_time;
        /**消息*/
        private TextView pf_id_item_pa_message;
        /**占位*/
        private View pf_id_item_place_zone;
        public ViewHolder(View convertView){

            pf_id_item_pa_time = (TextView)convertView.findViewById(R.id.pf_id_item_pa_time);
            pf_id_item_pa_message = (TextView)convertView.findViewById(R.id.pf_id_item_pa_message);
            pf_id_item_place_zone = convertView.findViewById(R.id.pf_id_item_place_zone);

        }


    }
}
