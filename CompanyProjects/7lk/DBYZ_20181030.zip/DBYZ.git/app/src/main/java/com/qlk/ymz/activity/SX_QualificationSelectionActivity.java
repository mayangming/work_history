package com.qlk.ymz.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.RelativeLayout;

import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * SX_QualificationAelectionActivity
 * 职业资格证选择页面
 * @author songxin on 2017/7/20.
 * @version 2.9.0
 */
public class SX_QualificationSelectionActivity extends DBActivity {
    /** 通用标题 */
    private XCTitleCommonLayout titlebar;
    /** 新版选择 */
    private RelativeLayout sx_id_doctor_practice_certificate_new_rl;
    /** 旧版选择 */
    private RelativeLayout sx_id_doctor_practice_certificate_old_rl;
    /** 文件路径 */
    private String filePath = "";
    /** 执业资格证号码 */
    private String doctorPracticeCertificateString = "";
    /** 启动标识，从备案页传进来的时候，值为“4”，医生认证页为空*/
    private String startCode;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_qualification_selection);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_QualificationSelectionActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleCenter(true, "医师执业证");

        sx_id_doctor_practice_certificate_new_rl = getViewById(R.id.sx_id_doctor_practice_certificate_new_rl);
        sx_id_doctor_practice_certificate_old_rl = getViewById(R.id.sx_id_doctor_practice_certificate_old_rl);

        doctorPracticeCertificateString = getIntent().getStringExtra("doctorPracticeCertificateString");
        filePath = getIntent().getStringExtra("filePath");
        startCode = getIntent().getStringExtra("startCode");
        printi("http","filePath--->"+filePath);
        if(!TextUtils.isEmpty(startCode) && !UtilString.isBlank(filePath) && "1".equals(UtilSP.getDoctorStatus())){
            if(filePath.contains("http")){
                if(filePath.contains(",")){
                    // 旧版
                    sx_id_doctor_practice_certificate_new_rl.setVisibility(View.GONE);
                  }else {
                    // 新版
                    sx_id_doctor_practice_certificate_old_rl.setVisibility(View.GONE);
                }
            }else{
                if(filePath.contains(",")){
                    // 旧版
                    sx_id_doctor_practice_certificate_new_rl.setVisibility(View.GONE);
                 }else {
                    // 新版
                    sx_id_doctor_practice_certificate_old_rl.setVisibility(View.GONE);
                }
            }
        }
    }

    @Override
    public void listeners() {
        sx_id_doctor_practice_certificate_new_rl.setOnClickListener(this);
        sx_id_doctor_practice_certificate_old_rl.setOnClickListener(this);
        titlebar.getXc_id_titlebar_left_layout().setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.xc_id_titlebar_left_layout:{
                finish();
                break;
            }
            //新版入口
            case R.id.sx_id_doctor_practice_certificate_new_rl:{
                Intent intent = new Intent();
                if(filePath.contains(",")){
                    intent.putExtra("filePath","");
                    intent.putExtra("doctorPracticeCertificateString","");
                }else {
                    intent.putExtra("filePath",filePath);
                    intent.putExtra("doctorPracticeCertificateString",doctorPracticeCertificateString);
                }

                intent.setClass(SX_QualificationSelectionActivity.this,SX_NewQualificationSelectionActivity.class);
                if(TextUtils.isEmpty(startCode)){
                    startActivity(intent);
                    finish();
                }else {
                    intent.putExtra("startCode",startCode);
                    startActivityForResult(intent,4);
                }

                break;
            }
            //旧版入口
            case R.id.sx_id_doctor_practice_certificate_old_rl:{
                Intent intent = new Intent();

                if(!filePath.contains(",")){
                    intent.putExtra("filePath","");
                    intent.putExtra("doctorPracticeCertificateString","");
                }else {
                    intent.putExtra("filePath",filePath);
                    intent.putExtra("doctorPracticeCertificateString",doctorPracticeCertificateString);
                }

                intent.setClass(SX_QualificationSelectionActivity.this,SX_OldQualificationSelectionActivity.class);
                if(TextUtils.isEmpty(startCode)){
                    startActivity(intent);
                    finish();
                }else {
                    intent.putExtra("startCode",startCode);
                    startActivityForResult(intent,4);
                }
                break;
            }

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK){
            doctorPracticeCertificateString = data.getStringExtra("doctorPracticeCertificateString");
            filePath = data.getStringExtra("filePath");
            setResult(Activity.RESULT_OK,data);
            finish();
        }
    }
}
