package com.qlk.ymz.activity;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.emoji.util.UtilScreen;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.SK_MedicineClassificationBModel;
import com.qlk.ymz.util.bi.BiUtil;

import java.util.ArrayList;

/**
 * Created by smile on 2017/12/14.
 * 药品二级分类页面
 */

public class YR_SecondMedicineTypeActivity extends DBActivity {
    /**
     * 取消按钮
     */
    TextView tv_cancel;
    /**
     * 二级药品分类列表
     */
    RecyclerView gv_secondMedicineType;
    /**
     * 二级药品分类列表
     */
    ArrayList<SK_MedicineClassificationBModel> secondTypeList = new ArrayList<>();
    /**
     * 二级药品适配器
     */
    RecyclerviewAdapter adapter;

    /**
     * 分类列表的父控件
     */
    LinearLayout ll_medicinetype;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setWindowAnimations(R.style.pop_from_up_to_down);
        View view = View.inflate(this, R.layout.yr_activity_secondmedicinetype, null);
        setContentView(view);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(YR_SecondMedicineTypeActivity.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */

    @Override
    public void initWidgets() {
        secondTypeList = (ArrayList<SK_MedicineClassificationBModel>) getIntent().getSerializableExtra(SK_MedicineClassificationResultActivity.CLASSIFICATIONRESULT_KEY);

        tv_cancel = (TextView) findViewById(R.id.tv_cancel);
        gv_secondMedicineType = (RecyclerView) findViewById(R.id.rv_layout);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3);
        gv_secondMedicineType.setLayoutManager(gridLayoutManager);

        adapter = new RecyclerviewAdapter();
        gv_secondMedicineType.setAdapter(adapter);

        ll_medicinetype = (LinearLayout) findViewById(R.id.ll_medicinetype);

//        Animation in = AnimationUtils.loadAnimation(this, R.anim.activity_open_up);
//        ll_medicinetype.startAnimation(in);

        gv_secondMedicineType.addItemDecoration(new RecyclerView.ItemDecoration() {

            int mSpace;

            @Override
            public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                super.getItemOffsets(outRect, view, parent, state);
                mSpace = UtilScreen.dip2px(YR_SecondMedicineTypeActivity.this, 5);
                outRect.left = mSpace;
                outRect.bottom = mSpace;
                if (parent.getChildAdapterPosition(view) % 3 == 2) {
                    outRect.right = mSpace;
                }
            }
        });

    }

    @Override
    public void listeners() {
        tv_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation out = AnimationUtils.loadAnimation(YR_SecondMedicineTypeActivity.this, R.anim.activity_close_down);
                out.setFillAfter(true);
                out.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        YR_SecondMedicineTypeActivity.this.finish();
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });
                ll_medicinetype.startAnimation(out);
            }
        });

    }

    @Override
    public void onNetRefresh() {

    }

    class RecyclerviewAdapter extends RecyclerView.Adapter<RecyclerviewAdapter.ViewHolder> {

        SK_MedicineClassificationBModel bean;

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(YR_SecondMedicineTypeActivity.this).inflate(R.layout.yr_item_secondmedicinetype, null);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(YR_SecondMedicineTypeActivity.this, SK_MedicineClassificationResultActivity.class);
                    intent.putExtra(YR_AllMedicineClassActivity.INTER_FLAG, YR_SecondMedicineTypeActivity.this.getIntent().getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG, 0));
                    intent.putExtra(SK_MedicineClassificationResultActivity.CLASSIFICATIONRESULT_KEY, bean);
                    myStartActivity(intent);
                }
            });

            ViewHolder viewHolder = new ViewHolder(view);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            bean = secondTypeList.get(position);
            holder.tv_medicineName.setText(bean.getName());
        }

        @Override
        public int getItemCount() {
            return secondTypeList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            TextView tv_medicineName;

            public ViewHolder(View itemView) {
                super(itemView);
                tv_medicineName = (TextView) itemView.findViewById(R.id.tv_medicineName);
            }
        }
    }


}
