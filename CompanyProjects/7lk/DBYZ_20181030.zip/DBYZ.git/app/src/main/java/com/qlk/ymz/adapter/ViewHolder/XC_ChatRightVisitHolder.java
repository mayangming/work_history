package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;

/**
 * 随访
 */
public class XC_ChatRightVisitHolder extends XC_ChatRightBaseHolder {
    public TextView id_right_suifang_title;
    public TextView id_right_suifang_content;
    public RelativeLayout id_right_suifang_layout;

    public XC_ChatRightVisitHolder(View convertView) {
        super(convertView);
        id_right_suifang_title = (TextView) convertView.findViewById(R.id.id_right_suifang_title);
        id_right_suifang_content = (TextView) convertView.findViewById(R.id.id_right_suifang_content);
        id_right_suifang_layout = (RelativeLayout) convertView.findViewById(R.id.id_right_suifang_layout);
    }
}