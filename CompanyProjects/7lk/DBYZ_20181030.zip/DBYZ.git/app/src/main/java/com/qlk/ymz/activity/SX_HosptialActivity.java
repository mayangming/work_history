package com.qlk.ymz.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.adapter.SX_HospitalAdapter;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.YY_DoctorlInfoBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.ConfirmDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by songxin on 2015/6/18.
 *
 * SX_HosptialActivity
 * 医院列表页面
 * @author  Changed by songxin on 2016/3/29.
 * @version 2.3
 */
public class SX_HosptialActivity extends DBActivity {
    /** 填充list的layout*/
    private RelativeLayout sx_id_hosptial_rl;
    /** 搜索内容输入框*/
    private EditText sx_id_be_search_hospital_edit;
    /** 点击list选择内容展示*/
    private TextView sx_id_text_show_choose;
    /** 展示内容外框layout*/
    private RelativeLayout sx_id_show_choose_rl;
    /** dialog 取消按钮*/
    private TextView sx_id_cancel_button;
    /** dialog 确认按钮*/
    private TextView sx_id_confirm_button;
    /** 医院输入框*/
    private EditText sx_id_hosptial_edit;
    /** title*/
    private XCTitleCommonLayout titlebar;
    /** 显示医院列表list fragment*/
    private XCListViewFragment list_fragment;
    /** 适配医院数据adapter*/
    private SX_HospitalAdapter mSXHospitalAdapter;
    /** 医院名称临时变量*/
    private String mCurrentHosptial;
    /** dialog*/
    private ConfirmDialog mConfirmDialog;
    /** intent*/
    private Intent mIntent;
    /** 省、市、医院的数据*/
    private List<XCJsonBean> mProvinceXCJsonBean,mCityXCJsonBean,mHospitalXCJsonBean;
    /** 省、市、医院、城市id 临时变量*/
    private String mCurrentProvince,mCurrentCity,mCurrentHospital,mCurrentCityId;
    /** type*/
    private String mType;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sx_l_activity_hospital);
        super.onCreate(savedInstanceState);
        mIntent = new Intent();
        mCurrentHosptial = "";
        mCurrentCityId = "";
        mType = "0";
        mProvinceXCJsonBean = new ArrayList<>();
        mCityXCJsonBean = new ArrayList<>();
        mHospitalXCJsonBean  = new ArrayList<>();
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleCenter(true, "选择医院");
        //Dialog初始化
        int srceenW =  this.getWindowManager().getDefaultDisplay().getWidth();
        mConfirmDialog = new ConfirmDialog(SX_HosptialActivity.this, srceenW,260
                ,R.layout.sx_l_dialog,R.style.xc_s_dialog);
        mConfirmDialog.setCanceledOnTouchOutside(false);
        sx_id_cancel_button = (TextView)mConfirmDialog.findViewById(R.id.sx_id_cancel_button);
        sx_id_confirm_button = (TextView)mConfirmDialog.findViewById(R.id.sx_id_confirm_button);
        sx_id_hosptial_edit = (EditText)mConfirmDialog.findViewById(R.id.sx_id_hosptial_edit);
        sx_id_cancel_button.setOnClickListener(this);
        sx_id_confirm_button.setOnClickListener(this);
        //获取城市列表
        getCityList("1", "");
        list_fragment = new XCListViewFragment();
        mSXHospitalAdapter = new SX_HospitalAdapter(this, null);
        list_fragment.setAdapter(mSXHospitalAdapter);
        list_fragment.setMode(XCListViewFragment.MODE_NOT_PULL);
        list_fragment.setBgZeroHintInfo("没有相关数据", "重新加载", R.mipmap.js_d_icon_no_data);
        addFragment(R.id.sx_id_hosptial_rl, list_fragment);
        //list点击事件
        list_fragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> paramAdapterView, View paramView, int position, long paramLong) {

                printi("songxin", "position===============>" + position);
                if ("1".equals(mType)) {
                    mCurrentProvince = mProvinceXCJsonBean.get(position - 1).getString("name");
                    getCityList(mProvinceXCJsonBean.get(position - 1).getString("id"), mCurrentProvince);
                } else if ("2".equals(mType)) {
                    //请求医院列表
                    mCurrentCity = mCityXCJsonBean.get(position - 1).getString("name");
                    getHospitalList(UtilSP.getUserId(), mCityXCJsonBean.get(position - 1).getString("id"), mCurrentCity);
                } else if ("3".equals(mType)) {
                    if ("0".equals(mHospitalXCJsonBean.get(position - 1).getString("id"))) {
                        mCurrentCityId = mHospitalXCJsonBean.get(position - 1).getString("cityId");
                        mConfirmDialog.show();
                    } else {
                        mCurrentHospital = mHospitalXCJsonBean.get(position - 1).getString("name");
                        YY_DoctorlInfoBean.DataEntity currentData = new YY_DoctorlInfoBean.DataEntity();
                        currentData.setHospitalId(mHospitalXCJsonBean.get(position - 1).getString("id"));
                        currentData.setHospital(mCurrentHospital);
                        mIntent.putExtra("HOSPITAL", currentData);
                        SX_HosptialActivity.this.setResult(3, mIntent);
                        SX_HosptialActivity.this.myFinish();
                    }
                }

                }
            });


        //title左侧点击事件处理
        titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ("3".equals(mType)) {
                    list_fragment.updateSpecialList(mCityXCJsonBean);
                    mType = "2";
                    sx_id_show_choose_rl.setVisibility(View.VISIBLE);
                    sx_id_text_show_choose.setText(mCurrentProvince);
                } else if ("2".equals(mType)) {
                    list_fragment.updateSpecialList(mProvinceXCJsonBean);
                    mType = "1";
                    sx_id_show_choose_rl.setVisibility(View.GONE);
                } else if ("1".equals(mType)) {
                    myFinish();
                }
            }
        });

        titlebar.getXc_id_titlebar_right2_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mConfirmDialog.show();
            }
        });
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_HosptialActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        sx_id_hosptial_rl = getViewById(R.id.sx_id_hosptial_rl);
        sx_id_be_search_hospital_edit = getViewById(R.id.sx_id_be_search_hospital_edit);
        sx_id_text_show_choose = getViewById(R.id.sx_id_text_show_choose);
        sx_id_show_choose_rl = getViewById(R.id.sx_id_show_choose_rl);

    }

    @Override
    public void listeners() {
        sx_id_be_search_hospital_edit.setOnClickListener(this);
        sx_id_text_show_choose.setOnClickListener(this);

    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            //点击搜索医院事件
            case R.id.sx_id_be_search_hospital_edit:{
                myStartActivity(SX_HospitalSearchActivity.class);
                myFinish();
                break;
            }
            //dialog取消事件
            case R.id.sx_id_cancel_button:{
                if(null != mConfirmDialog){
                    mConfirmDialog.dismiss();
                }
                break;
            }
            //点击list选择内容展示
            case R.id.sx_id_text_show_choose:{
               if("3".equals(mType)){
                    list_fragment.updateSpecialList(mCityXCJsonBean);
                    mType = "2";
                    sx_id_show_choose_rl.setVisibility(View.VISIBLE);
                    sx_id_text_show_choose.setText(mCurrentProvince);
                }else if("2".equals(mType)){
                    list_fragment.updateSpecialList(mProvinceXCJsonBean);
                    mType = "1";
                    sx_id_show_choose_rl.setVisibility(View.GONE);
                }else if("1".equals(mType)){
                   myFinish();
                }
                break;
            }
            //dialog确定事件
            case R.id.sx_id_confirm_button:{
                if(UtilString.isBlank(sx_id_hosptial_edit.getText().toString().trim())) {
                    shortToast("输入内容不能为空");
                    return;
                }
                mCurrentHospital = sx_id_hosptial_edit.getText().toString().trim();
                YY_DoctorlInfoBean.DataEntity currentData = new YY_DoctorlInfoBean.DataEntity();
                currentData.setHospitalId("0");
                currentData.setCityId(mCurrentCityId);
                printi("http", "mCurrentHospital----------->" + mCurrentHospital);
                currentData.setHospital(mCurrentHospital);
                mIntent.putExtra("HOSPITAL", currentData);
                SX_HosptialActivity.this.setResult(3, mIntent);
                SX_HosptialActivity.this.myFinish();
                break;
            }

        }
    }


    /**
     * 获取城市列表
     * @param pid
     * @param chooseName
     */
    private void getCityList(String pid,final String chooseName){
        RequestParams params = new RequestParams();
        params.put("pid", pid);
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.city_list), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    List<XCJsonBean> jsons = result_bean.getList("data");
                    if (jsons.size() > 0) {
                        mType = jsons.get(0).getString("type");
                        if (mType.equals("1")) {
                            mProvinceXCJsonBean.clear();
                            mProvinceXCJsonBean.addAll(jsons);
                            list_fragment.updateSpecialList(mProvinceXCJsonBean);
                            jsons.clear();
                        } else if (mType.equals("2")) {
                            mCityXCJsonBean.clear();
                            mCityXCJsonBean.addAll(jsons);
                            list_fragment.updateSpecialList(mCityXCJsonBean);
                            jsons.clear();
                            sx_id_show_choose_rl.setVisibility(View.VISIBLE);
                            sx_id_text_show_choose.setText(chooseName);
                        }
                    }
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_HosptialActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 获取医院列表
     * @param doctorId
     * @param cityId
     * @param chooseName
     */
    private void getHospitalList(String doctorId,final String cityId, final String chooseName){
        RequestParams params = new RequestParams();
        params.put("id", doctorId);
        params.put("cityId", cityId);
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.hospital_list), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2=========>" + new String(arg2));
                if (result_boolean) {
                    List<XCJsonBean> jsons = result_bean.getList("data");
                    mHospitalXCJsonBean.clear();
                    mHospitalXCJsonBean.addAll(jsons);
                    XCJsonBean xcJsonBean = new XCJsonBean();
                    xcJsonBean.setString("id","0");
                    xcJsonBean.setString("name","其他");
                    xcJsonBean.setString("cityId",cityId);
                    mHospitalXCJsonBean.add(xcJsonBean);
                    list_fragment.updateSpecialList(mHospitalXCJsonBean);
                    jsons.clear();
                    sx_id_show_choose_rl.setVisibility(View.VISIBLE);
                    sx_id_text_show_choose.setText(chooseName);
                    mType = "3";
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_HosptialActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    @Override
    protected void onDestroy() {
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 start
        UtilViewShow.destoryDialogs(mConfirmDialog);
        // update by tengfei,date: 2016-11-29 , about:统一dialog销毁 end
        super.onDestroy();
    }
}
