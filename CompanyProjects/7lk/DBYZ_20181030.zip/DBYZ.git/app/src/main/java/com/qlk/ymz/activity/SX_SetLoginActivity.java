package com.qlk.ymz.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.JS_MainActivity;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.JS_ChatListDB;
import com.qlk.ymz.db.im.XCChatModelDb;
import com.qlk.ymz.db.im.chatmodel.JS_ChatListModel;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.model.WebviewBean;
import com.qlk.ymz.parse.Parse2PatientBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.NativeHtml5;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.HospitalBackupsBeanSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.SX_ClearEditText;
import com.qlk.ymz.view.YR_ErrorPromptEditText;
import com.xiaocoder.android.fw.general.dialog.XCSystemVDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilMd5;
import com.xiaocoder.android.fw.general.util.UtilRSA;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;

import java.util.ArrayList;
import java.util.List;

/**
 * SX_SetLoginActivity
 * 用户注册(设置登录页面)
 * @author songxin on 2016/1/7.
 * @version 2.0
 */
public class SX_SetLoginActivity extends DBActivity implements View.OnClickListener {
    /** title左边按钮*/
    private ImageView sx_id_title_left;
    /** title中间文字*/
    private TextView sx_id_title_center;
    /** 设置登录页面用户名输入框*/
    private SX_ClearEditText sx_l_register_username_edit;
    /** 设置登录页面姓名输入框*/
    private YR_ErrorPromptEditText sx_l_register_name_edit;
    /** 设置登录页面新密码输入框*/
    private YR_ErrorPromptEditText sx_l_register_pw_edit;
    /** 设置登录页面点击注册*/
    private Button sx_l_register_button;
    /** 设置登录页面是否同意注册协议*/
    private ImageView sx_l_agreement_for_registration;
    /** 设置登录页面注册协议*/
    private TextView sx_l_agreement_for_registration_show;
    /** 用户名(手机号)*/
    private String mUserName = "";
    /** 密码*/
    private String mPassword = "";
    /** 医生姓名*/
    private String mDoctorName = "";
    /** 设置登录页面是否同意注册协议标记*/
    private boolean mIsEnterRegistration = false;
    /** 跳转标记*/
    private int mFlag = -1;
    /** 等待对话框 */
    private Dialog dialog;
    /** 患者存完数据库,关闭对话框 */
    private  final int CLOSE_DIALOG = 0;
    /** 设备判断完毕 */
    private  final int DEVICE_OVER = 1;
    /** 患者数据请求失败 */
    private  final int PATIENT_REQUEST_ERRO = 2;
    /** 医生信息对象*/
    private XCJsonBean data;
    /** 密码最小长度限制 */
    int minLength;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case CLOSE_DIALOG:

                    if(mFlag == 0){ //注册
                        HospitalBackupsBeanSP.TO_ACTIVITY = NativeHtml5.QLK_HOME;
                        Intent intent = new Intent(SX_SetLoginActivity.this,YY_PersonalDataActivityV2.class);
                        intent.putExtra(JS_MainActivity.FROM_PAGE,JS_MainActivity.FORM_REGISTER);
                        intent.putExtra(JS_MainActivity.IS_SHOWN_IDENTYFY_DIALOG,true);
                        myStartActivity(intent);
                        finish();
                    }else if(mFlag == 1){ //重新设置登录密码
                        Intent intent = new Intent(SX_SetLoginActivity.this, JS_MainActivity.class);
                        intent.putExtra(JS_MainActivity.FROM_PAGE, JS_MainActivity.FROM_LOGIN);
                        myStartActivity(intent);
                        finish();
                    }

                    break;
                case DEVICE_OVER:
                    requestPatientABC();
                    break;
                case PATIENT_REQUEST_ERRO:
                    dismiss();
                    Intent intent = new Intent(SX_SetLoginActivity.this, JS_MainActivity.class);
                    intent.putExtra(JS_MainActivity.FROM_PAGE, JS_MainActivity.FROM_LOGIN);
                    intent.putExtra(JS_MainActivity.PATIENT_REQUEST, JS_MainActivity.PATIENT_REQUEST_ERRO);
                    myStartActivity(intent);
                    finish();
                    break;
            }

        }
    };


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// 设置布局
		setContentView(R.layout.sx_l_activity_set_login);
		super.onCreate(savedInstanceState);
        // created by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(SX_SetLoginActivity.class,"1","","","",false);
        // created by songxin,date：2016-4-25,about：saveInfo,end

        mFlag = getIntent().getIntExtra("toSetLogin",0);
        if(mFlag == 0){
            sx_id_title_center.setText("设置登录密码页面");
            sx_l_register_button.setText("注册");
        }else if(mFlag == 1){
            sx_id_title_center.setText("重新设置登录密码");
            sx_l_register_button.setText("完成");
        }
        if(mFlag == 0){
            getViewById(R.id.pf_title_rl).setBackgroundColor(getResources().getColor(R.color.c_trans));
            getViewById(R.id.line).setVisibility(View.GONE);
        }
        mUserName = getIntent().getStringExtra("USERNAME");
        sx_l_register_username_edit.setText(mUserName);
        sx_l_register_username_edit.setClearIconVisible(false);
        if(mIsEnterRegistration){
            sx_l_agreement_for_registration.setImageResource(R.mipmap.sx_d_register_sure);
        }else{
            sx_l_agreement_for_registration.setImageResource(R.mipmap.sx_d_register_no_sure);
        }
	}

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(SX_SetLoginActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

	// 无网络时,点击屏幕后回调的方法
	@Override
	public void onNetRefresh() {
	}

	// 初始化控件
	@Override
	public void initWidgets() {
        sx_id_title_left = getViewById(R.id.sx_id_title_left);
        sx_id_title_center = getViewById(R.id.sx_id_title_center);
        sx_l_register_username_edit = getViewById(R.id.sx_l_register_username_edit);
        sx_l_register_name_edit = getViewById(R.id.sx_l_register_name_edit);
        sx_l_register_name_edit.sx_clearEditText.setBackgroundColor(getResources().getColor(R.color.c_gray_f0f1f5));
        sx_l_register_pw_edit = getViewById(R.id.sx_l_register_pw_edit);
        sx_l_register_pw_edit.sx_clearEditText.setBackgroundColor(getResources().getColor(R.color.c_gray_f0f1f5));
        sx_l_register_button = getViewById(R.id.sx_l_register_button);
        sx_l_agreement_for_registration = getViewById(R.id.sx_l_agreement_for_registration);
        sx_l_agreement_for_registration_show = getViewById(R.id.sx_l_agreement_for_registration_show);
        dialog = new XCSystemVDialog(SX_SetLoginActivity.this);
        dialog.setCancelable(false);

        // update by 崔毅然 on 2016-8-2 start
        minLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PASSWORD,1,6);
        int maxLength = GlobalConfigSP.getLimitValue(GlobalConfigSP.PASSWORD,0,19);
        sx_l_register_pw_edit.sx_clearEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        sx_l_register_pw_edit.setLimitAttrs(YR_ErrorPromptEditText.PWD_REGULAR, minLength, maxLength);

        int minLengthName = GlobalConfigSP.getLimitValue(GlobalConfigSP.REALNAME,1,1);
        int maxLengthName = GlobalConfigSP.getLimitValue(GlobalConfigSP.REALNAME,0,19);
        sx_l_register_name_edit.sx_clearEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLengthName)});
        sx_l_register_name_edit.setLimitAttrs(minLengthName, maxLengthName);
        // update by 崔毅然 on 2016-8-2 end
    }

	// 设置监听
	@Override
	public void listeners() {
        sx_id_title_left.setOnClickListener(this);
        sx_l_register_button.setOnClickListener(this);
        sx_l_agreement_for_registration.setOnClickListener(this);
        sx_l_agreement_for_registration_show.setOnClickListener(this);
        //监听输入框变化，控制登录按钮颜色，是否可点击

        sx_l_register_username_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                setregisterBtnStatus(s.toString().trim().length() > 0
                        && sx_l_register_name_edit.sx_clearEditText.getText().toString().trim().length() > 0
                        && sx_l_register_pw_edit.sx_clearEditText.getText().toString().trim().length() > 0
                        && mIsEnterRegistration);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        //监听输入框变化，控制登录按钮颜色，是否可点击
        sx_l_register_name_edit.sx_clearEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                setregisterBtnStatus(s.toString().trim().length() > 0
                        && sx_l_register_username_edit.getText().toString().trim().length() >0
                        && sx_l_register_pw_edit.sx_clearEditText.getText().toString().trim().length() >0
                        && mIsEnterRegistration);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        //监听输入框变化，控制登录按钮颜色，是否可点击
        sx_l_register_pw_edit.sx_clearEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                setregisterBtnStatus(s.toString().trim().length() >= minLength
                        && sx_l_register_username_edit.getText().toString().trim().length() >0
                        && sx_l_register_name_edit.sx_clearEditText.getText().toString().trim().length() >0
                        && mIsEnterRegistration);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
	}

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            //返回按钮
            case R.id.sx_id_title_left:{
                finish();
                break;
            }
            //注册按钮
            case R.id.sx_l_register_button:{
                mUserName = sx_l_register_username_edit.getText().toString().trim();
                mPassword = sx_l_register_pw_edit.sx_clearEditText.getText().toString().trim();
                mDoctorName = sx_l_register_name_edit.sx_clearEditText.getText().toString().trim();
                String publicKey = UtilSP.getPublicKey();
                if(TextUtils.isEmpty(publicKey)){
                    requestPubKey(true,mUserName,mPassword);
                }else{
                    doctorRegister(mDoctorName,mUserName, mPassword,publicKey);
                }
                break;
            }
            //是否同意协议按钮
            case R.id.sx_l_agreement_for_registration:{
                mIsEnterRegistration = !mIsEnterRegistration;
                if(mIsEnterRegistration){
                    sx_l_agreement_for_registration.setImageResource(R.mipmap.sx_d_register_sure);
                }else{
                    sx_l_agreement_for_registration.setImageResource(R.mipmap.sx_d_register_not_choose_v2);
                }
                setregisterBtnStatus(sx_l_register_pw_edit.sx_clearEditText.getText().toString().trim().length() >= minLength
                        && sx_l_register_username_edit.getText().toString().trim().length() > 0
                        && sx_l_register_name_edit.sx_clearEditText.getText().toString().trim().length() > 0
                        && mIsEnterRegistration);
                break;
            }
            //注册协议
            case R.id.sx_l_agreement_for_registration_show:{
                WebviewBean bean = new WebviewBean(AppConfig.getH5Url(AppConfig.doctor_service_contract));
                bean.title = "注册协议";
                myStartActivity(JS_WebViewActivity.newIntent(this, bean));
                break;
            }
            default:{
                break;
            }
        }
    }

    /** 设置注册按钮的点击状态
     * @param isCanClick true 可点击； false 不可点击
     * */
    public void setregisterBtnStatus(boolean isCanClick){
        if (isCanClick) {
            sx_l_register_button.setBackgroundResource(R.mipmap.login_bt_bg);
            sx_l_register_button.setClickable(true);
            sx_l_register_button.setTextColor(getResources().getColor(R.color.c_white_ffffff));
        } else {
            sx_l_register_button.setBackgroundResource(R.mipmap.login_bt_wathet_bg);
            sx_l_register_button.setClickable(false);
            sx_l_register_button.setTextColor(getResources().getColor(R.color.c_white_ffffff));
        }
    }


    /**
     * 医生注册
     * @param doctorName 医生名字
     * @param username 用户名
     * @param password 密码
     * @param pubKey 公钥
     */
    private void doctorRegister(String doctorName, final String username, final String password, String pubKey){
        //验证信息
        if (UtilString.isBlank(username)) {
            shortToast("请输入手机号");
            return;
        }
        //update by 崔毅然 on 2016-8-2 修改错误提示显示方式  start
        if (!sx_l_register_name_edit.setErrorText()){
            sx_l_register_name_edit.errorInfo_tv.setVisibility(View.VISIBLE);
            return;
        }
        if (!sx_l_register_pw_edit.setErrorText()){
            sx_l_register_pw_edit.errorInfo_tv.setVisibility(View.VISIBLE);
            return;
        }
        //update by 崔毅然 on 2016-8-2 修改错误提示显示方式  end
        if(!mIsEnterRegistration){
            shortToast("请同意《石榴云医注册协议》后，再尝试。");
            return;
        }
        // created by songxin,date：2016-4-25,about：saveInfo,begin
        BiUtil.saveBiInfo(SX_SetLoginActivity.class,"2","128","sx_l_register_button","",false);
        // created by songxin,date：2016-4-25,about：saveInfo,end

        doctorName = doctorName.replaceAll(" ","");

        //发送请求
        RequestParams params = new RequestParams();
        params.put("phoneNum", username);
        params.put("password", UtilRSA.encryByRSA(pubKey, password));
        params.put("regSource", 0);
        params.put("inviterCode", "");
        params.put("name", doctorName);
        //成功进入填写注册信息
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.login_regist), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2===regist======>" + new String(arg2));
                if (result_boolean) {
//					XCJsonBean userBean = result_bean.getModel("data");
                    requestLoginPubKey(username, password);
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                // update by 崔毅然 on 2016-8-9  修改返回错误msg为显示红字
                if (null != result_bean) {
                    if (!GeneralReqExceptionProcess.checkCode(SX_SetLoginActivity.this,
                            getCode(), "")){
                        sx_l_register_pw_edit.errorInfo_tv.setText(getMsg());
                        sx_l_register_pw_edit.errorInfo_tv.setVisibility(View.VISIBLE);
                    }
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 获取登录key
     * @param username 用户名
     * @param password 密码
     */
    private void requestLoginPubKey(final String username, final String password){
        if (UtilString.isBlank(username)) {
            shortToast("请输入手机号");
            return;
        }
        if (UtilString.isBlank(password)) {
            shortToast("请输入密码");
            return;
        }
        if(!UtilString.isPhoneNum(username)){
            shortToast("手机号格式不对，请重新输入");
            return;
        }

        RequestParams params = new RequestParams();
        params.put("phoneNum", username);
        try {
            if(null != dialog && !isFinishing()){
                dialog.show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.login_genLoginKey), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2===genLoginKey======>" + new String(arg2));
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                        printi("songxin", "genLoginKey==============>" + jsonBeans.get(0).getString("publicKey"));
                        String loginKey = jsonBeans.get(0).getString("loginKey");
                        String doctorId = jsonBeans.get(0).getString("doctorId");
                        requestLogin(doctorId,username,password, loginKey);
                        return;
                    }
                }
                dismiss();
            }
            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                dismiss();
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_SetLoginActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 请求登陆接口
     * @param checkDoctorId      校验doctorId
     * @param loginKey      手机号获取登录key
     * @param password    密码
     */
    public void requestLogin(String checkDoctorId,final String username,String password,String loginKey){
        //发送请求
        RequestParams params = new RequestParams();
        params.put("doctorId", checkDoctorId);
        params.put("loginKey", loginKey);
        params.put("password", UtilRSA.encryByRSA(UtilSP.getPublicKey(), password));
        //设备唯一标识
        params.put("deviceSN", GlobalConfigSP.getDeviceId(this));
        //成功进入填写注册信息
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.login_login), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2===login======>" + new String(arg2));
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans != null && jsonBeans.size() > 0) {
                        UtilSP.putUserId(jsonBeans.get(0).getString("doctorId"));
                        UtilSP.putUserToken(jsonBeans.get(0).getString("token"));
                        //UtilSP.setUserName(username);//这个 username是个手机号不是医生名
                        UtilSP.setUserPhone(username);//设置页要用一下
                        UtilSP.putLogin(true);
//                        UtilSP.setStatus(jsonBeans.get(0).getString("status"));
                        //登陆成功之后服务器返回是否第一次登陆的值
                        UtilSP.setFirstFlag(jsonBeans.get(0).getString("firstFlag"));
                        UtilSP.setInitNotice(UtilSP.INIT_NOTICE_NO);
                        // add by xjs on 20151211 start
                        // 修复JIRA上1383的BUG。因为在“个人资料”页中使用的医生认证状态的SP的名为“authStatus”,所以增加此行代码。
                        UtilSP.setAuthStatus(jsonBeans.get(0).getString("status"));
                        // add by xjs on 20151211 end
                        dShortToast(jsonBeans.get(0).getString("doctorId") + "---登录成功，doctorId");
                        String deviceFlag = UtilString.isBlank(jsonBeans.get(0).getString("deviceFlag")) ? "1" : jsonBeans.get(0).getString("deviceFlag");
                        //用来判断上次登录是否是相同设备 0 表示不同, 1 表示相同
                        if ("0".equals(deviceFlag)){
                            new Thread(new Runnable() {
                                public void run() {
                                    // add by xjs on 20160516 start
                                    // 如果两次登录的设备不同，则要清除“咨询列表DB”及“咨询详情DB”当中的表内容
                                    // 先清除“咨询详情DB”
                                    //----------------zhangpengfie 2016-07-11 add-----------
                                    GlobalConfigSP.putMD5PatientListJson(""); //清除患者列表MD5
                                    //----------------zhangpengfie 2016-07-11 end-----------
                                    String doctorId = UtilSP.getUserId();
                                    ArrayList<JS_ChatListModel> chatListModelObj = JS_ChatListDB.getInstance(SX_SetLoginActivity.this, doctorId).getAllRecord();
                                    int size = chatListModelObj.size();
                                    for(int i=0; i<size; i++) {
                                        String patientId = chatListModelObj.get(i).getUserPatient().getPatientId();
                                        if(!TextUtils.isEmpty(patientId)) {
                                            XCChatModelDb chatDao = XCChatModelDb.getInstance(getApplicationContext(), UtilSP.getIMDetailDbName(doctorId, patientId));
                                            chatDao.deleteAll();
                                        }
                                    }

                                    // 再清除“咨询列表DB”
                                    JS_ChatListDB.getInstance(SX_SetLoginActivity.this, doctorId).removeAllRecord();
                                    // add by xjs on 20160516 end
                                    //清楚首页未读系统消息 add by xd start
                                    UtilSP.setSystemMessage("");
                                    UtilSP.setLateTitle("");
                                    UtilSP.setNoticeDot(false);
                                    //add by xd 20180808 end

                                    handler.sendEmptyMessage(DEVICE_OVER);
                                }
                            }).start();
                        }else {
                            handler.sendEmptyMessage(DEVICE_OVER);
                        }
                        return;
                    }
                }
                dismiss();
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                dismiss();
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if(null != result_bean && GeneralReqExceptionProcess.checkCode(SX_SetLoginActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 获取公钥
     * @param needRequest 是否请求
     * @param mUserName 用户名（手机号）
     * @param mPassword 密码
     */
    private synchronized void  requestPubKey(final boolean needRequest,final String mUserName,final String mPassword) {
        RequestParams params = new RequestParams();
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.login_getPublicKey), params, new XCHttpResponseHandler() {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                printi("songxin", "arg2===regist======>" + new String(arg2));
                if (result_boolean) {
                    List<XCJsonBean> jsonBeans = result_bean.getList("data");
                    if (jsonBeans.size() > 0) {
                        printi("songxin", "PublicKey==============>" + jsonBeans.get(0).getString("publicKey"));
                        String publicKey = jsonBeans.get(0).getString("publicKey");
                        UtilSP.putPublicKey(publicKey);

                        if (needRequest) {
                            doctorRegister(mDoctorName, mUserName, mPassword, publicKey);
                        }
                    }
                }
            }

            // add by xjs on 20151027 19:48 start
            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_SetLoginActivity.this,
                        getCode(),
                        getMsg())) {
                    // 接口请求业务成功时的处理
                }
            }
            // add by xjs on 20151027 19:48 end
        });
    }

    /**
     * 得到患者列表
     */
    public void requestPatientABC() {
        XCHttpAsyn.postAsyn(false, this, AppConfig.getHostUrl(AppConfig.patient_my), new RequestParams(), new XCHttpResponseHandler() {
            public void onSuccess(int code, Header[] headers, final byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    if (result_bean != null) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                String oldJson = GlobalConfigSP.getMD5PatientListJson();
                                String newJson = UtilMd5.MD5Encode(new String(arg2));
                                //比对上次患者列表json和新获得的患者列表json数据,相等不进行存库操作
                                if (!newJson.equals(oldJson)) {
                                    ArrayList<XC_ChatModel> xc_chatModels = new ArrayList();
                                    Parse2PatientBean.parse(xc_chatModels,result_bean);
                                    GlobalConfigSP.putMD5PatientListJson(newJson);
                                    //更新数据库
                                    JS_ChatListDB.getInstance(SX_SetLoginActivity.this, UtilSP.getUserId()).insertAllChatInfo(xc_chatModels);
                                    UtilSP.setPatientSum(xc_chatModels.size() + "");
                                }
                                handler.sendEmptyMessage(CLOSE_DIALOG);
                            }
                        }).start();
                        return;
                    }
                }
                handler.sendEmptyMessage(PATIENT_REQUEST_ERRO);
            }

            @Override
            public void onFailure(int code, Header[] headers, byte[] arg2, Throwable e) {
                super.onFailure(code, headers, arg2, e);
                handler.sendEmptyMessage(PATIENT_REQUEST_ERRO);
            }

            public void onFinish() {
                super.onFinish();
                dismiss();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(SX_SetLoginActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }
    /**
     * 关闭dialog
     * 对对话框的关闭做统一处理,防止页面销毁后出现关闭对话框的情况
     * add by 马杨茗 on 20160520 pm
     */
    public void dismiss() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        dismiss();
    }
}
