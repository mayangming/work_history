package com.qlk.ymz.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by songxin on 2015/9/22.
 *
 * SX_IllnessNotesAdapter
 * 病情备注adapter
 * @author  Changed by songxin on 2016/3/29.
 * @version 2.3
 */
public class SX_IllnessNotesAdapter extends BaseAdapter {
    /** LayoutInflater*/
    private LayoutInflater mInflate;
    /** 病情备注数据*/
    private List<XCJsonBean> mXCJsonBeans;
    /** ViewHolder*/
    private ViewHolder mViewHolder;

    public SX_IllnessNotesAdapter(Context context,List<XCJsonBean> xcJsonBeans){
        if(xcJsonBeans == null){
            this.mXCJsonBeans = new ArrayList<>();
        } else {

            this.mXCJsonBeans = xcJsonBeans;
        }
        mInflate = LayoutInflater.from(context);
    }

    public void setList(List<XCJsonBean> xcJsonBeans){
        if(null != xcJsonBeans && xcJsonBeans.size() != 0){
            this.mXCJsonBeans.clear();
            this.mXCJsonBeans.addAll(xcJsonBeans);
            notifyDataSetChanged();
        }
    }

    @Override
    public int getCount() {
        if(mXCJsonBeans != null
                && mXCJsonBeans.size() > 0
                && mXCJsonBeans.get(0) != null
                && mXCJsonBeans.get(0).getList("monthRecods") != null){

            return mXCJsonBeans.get(0).getList("monthRecods").size();
        } else {
            return 0;
        }
    }

    @Override
    public Object getItem(int position) {
        if(mXCJsonBeans != null
                && mXCJsonBeans.size() > 0
                && mXCJsonBeans.get(0) != null
                && mXCJsonBeans.get(0).getList("monthRecods") != null){

            return mXCJsonBeans.get(0).getList("monthRecods").get(position);
        } else{
            return 0;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(null == convertView){
            mViewHolder = new ViewHolder();
            convertView = mInflate.inflate(R.layout.sx_l_adapter_illness_notes_item,null);
            mViewHolder.sx_id_date_show = (TextView)convertView.findViewById(R.id.sx_id_date_show);
            mViewHolder.sx_id_illness_notes_rl = (RelativeLayout)convertView.findViewById(R.id.sx_id_illness_notes_rl);
            mViewHolder.sx_id_time_show = (TextView)convertView.findViewById(R.id.sx_id_time_show);
            mViewHolder.sx_id_date_show_label_for_illness_notes = (ImageView)convertView.findViewById(R.id.sx_id_date_show_label_for_illness_notes);
            mViewHolder.sx_id_illness_notes_title_content = (TextView)convertView.findViewById(R.id.sx_id_illness_notes_title_content);
            mViewHolder.sx_id_date_show_label_for_recommended_medication = (ImageView)convertView.findViewById(R.id.sx_id_date_show_label_for_recommended_medication);
            mViewHolder.sx_id_time_show_for_recommended_medication = (TextView)convertView.findViewById(R.id.sx_id_time_show_for_recommended_medication);
            mViewHolder.sx_id_recommended_medication_rl = (RelativeLayout)convertView.findViewById(R.id.sx_id_recommended_medication_rl);
            mViewHolder.sx_id_recommended_medication_title_content = (TextView)convertView.findViewById(R.id.sx_id_recommended_medication_title_content);
            mViewHolder.sx_id_line_icon1 = (RelativeLayout)convertView.findViewById(R.id.sx_id_line_icon1);
            mViewHolder.sx_id_line_icon2 = (RelativeLayout)convertView.findViewById(R.id.sx_id_line_icon2);
            convertView.setTag(mViewHolder);
        }else{
            mViewHolder = (ViewHolder)convertView.getTag();
        }
        mViewHolder.sx_id_date_show.setText(mXCJsonBeans.get(0).getList("monthRecods").get(position).getString("stage") + "日");
        //如果病情备注的list==null 隐藏病情备注item
        if(mXCJsonBeans.get(0).getList("monthRecods").get(position).getList("patientRecords").size() == 0){
            mViewHolder.sx_id_line_icon1.setVisibility(View.GONE);
            mViewHolder.sx_id_illness_notes_rl.setVisibility(View.GONE);
            mViewHolder.sx_id_date_show_label_for_illness_notes.setVisibility(View.GONE);
        }else{
            mViewHolder.sx_id_line_icon1.setVisibility(View.VISIBLE);
            mViewHolder.sx_id_date_show_label_for_illness_notes.setVisibility(View.VISIBLE);
            mViewHolder.sx_id_illness_notes_rl.setVisibility(View.VISIBLE);
            mViewHolder.sx_id_time_show.setText(mXCJsonBeans.get(0).getList("monthRecods").get(position).getList("patientRecords").get(0).getString("createdTimeShort"));
            mViewHolder.sx_id_illness_notes_title_content.setText(mXCJsonBeans.get(0).getList("monthRecods").get(position).getList("patientRecords").get(0).getString("record"));
        }
        StringBuffer sb = new StringBuffer();
        List<XCJsonBean> medicationRecoms = mXCJsonBeans.get(0).getList("monthRecods").get(position).getList("medicationRecoms");
        //如果推荐用药的list==null 隐藏推荐用药item
        if(medicationRecoms.size() == 0){
            mViewHolder.sx_id_line_icon2.setVisibility(View.GONE);
            mViewHolder.sx_id_recommended_medication_rl.setVisibility(View.GONE);
            mViewHolder.sx_id_date_show_label_for_recommended_medication.setVisibility(View.GONE);
        }else{
            mViewHolder.sx_id_line_icon2.setVisibility(View.VISIBLE);
            mViewHolder.sx_id_recommended_medication_rl.setVisibility(View.VISIBLE);
            mViewHolder.sx_id_date_show_label_for_recommended_medication.setVisibility(View.VISIBLE);
            for(int i = 0; i < medicationRecoms.size(); i++){
                if(i == medicationRecoms.size() - 1){
                    sb.append(medicationRecoms.get(i).getString("medicationRecomDetails"));
                }else{
                    sb.append(medicationRecoms.get(i).getString("medicationRecomDetails") + ",");
                }
            }
            if(mXCJsonBeans.get(0).getList("monthRecods").get(position).getList("patientRecords").size() == 0){
                mViewHolder.sx_id_date_show_label_for_recommended_medication.setBackgroundResource(R.drawable.sx_d_date_show_label_is_today_begin);
            }else{
                mViewHolder.sx_id_date_show_label_for_recommended_medication.setBackgroundResource(R.drawable.sx_d_date_show_label_is_today);
            }
            mViewHolder.sx_id_time_show_for_recommended_medication.setText(mXCJsonBeans.get(0).getList("monthRecods").get(position).getList("medicationRecoms").get(0).getString("createdTimeShort"));
            mViewHolder.sx_id_recommended_medication_title_content.setText(sb.toString());
        }
        return convertView;
    }

    static class ViewHolder{
        /** 病情备注页日期显示*/
        TextView sx_id_date_show;
        /** 病情备注页病情备注layout*/
        RelativeLayout sx_id_illness_notes_rl;
        /** 并请备注页面病情备注时间显示*/
        TextView sx_id_time_show;
        /** 病情备注页面病情备注icon标签*/
        ImageView sx_id_date_show_label_for_illness_notes;
        /** 病情备注页面病情备注内容*/
        TextView sx_id_illness_notes_title_content;
        /** 病情备注页面推荐用药icon标签*/
        ImageView sx_id_date_show_label_for_recommended_medication;
        /** 病情备注页面推荐用药时间显示*/
        TextView sx_id_time_show_for_recommended_medication;
        /** 病情备注页面推荐用药layout*/
        RelativeLayout sx_id_recommended_medication_rl;
        /** 病情备注页面推荐用药内容*/
        TextView sx_id_recommended_medication_title_content;
        /** icon标签layout*/
        RelativeLayout sx_id_line_icon1;
        /** icon标签layout*/
        RelativeLayout sx_id_line_icon2;
    }
}
