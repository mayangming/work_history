package com.qlk.ymz.db.im;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.NonNull;

import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.im.chatmodel.XC_ChatModel;
import com.qlk.ymz.parse.Parse2ChatContent;
import com.qlk.ymz.parse.Parse2ChatExd;
import com.qlk.ymz.parse.Parse2ChatSession;
import com.qlk.ymz.util.UtilCollection;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by jingyu on 2015/11/24.
 *
 * @version 1.0
 * 聊天详情的db
 */
public class XCChatModelDb extends SQLiteOpenHelper {

    /**
     * 版本 表名
     * 1.5.1 的数据库版本是3
     * 2.0 的数据库版本是4
     * 2.2 的数据库版本是10
     * 2.3 的数据库版本是11
     * 2.3.3的数据库版本是12
     * 2.5的数据库版本是13（推荐用药可以重复推荐）
     */
    public static final int VERSION = 13;
    private static final String mOperatorTableName = "chat_recoder";

    /**
     * 排序常量，有个空格误删
     */
    private static final String SORT_DESC = " DESC";
    private static final String SORT_ASC = " ASC";

    /**
     * 以下是表字段
     */
    private static final String _ID = "_id";
    /**
     * 患者id
     */
    public static final String PATIENT_ID = "patientId";
    /**
     * 患者名
     */
    private static final String PATIENT_NAME = "patientName";
    /**
     * 患者头像
     */
    private static final String PATIENT_IMG_HEAD = "patientImgHead";
    /**
     * 医生id
     */
    private static final String DOCTOR_SELF_ID = "doctorSelfId";
    /**
     * 医生名
     */
    private static final String DOCTOR_SELF_NAME = "doctorSelfName";
    /**
     * 医生头像
     */
    private static final String DOCTOR_SELF_IMG_HEAD = "doctorSelfImgHead";
    /**
     * 发送时间
     */
    private static final String MSG_TIME = "msgTime";
    /**
     * 用药助手
     */
    private static final String MESSAGE_TEXT_RECOMMAND = "messageTextRecommand";
    /**
     * 文本信息
     */
    private static final String MESSAGE_TEXT = "messageText";
    /**
     * 消息类型有 图片 视频 音频 文本 文本+医药链接 文本+推荐用药
     */
    private static final String MSG_TYPE = "msgType";
    /**
     * 每条信息的唯一标示，本地
     */
    private static final String MSG_UNIQUE = "msgUnique";
    /**
     * 声音的本地缓存
     */
    private static final String VOICE_LOCALURI = "voiceLocalUri";
    /**
     * 声音的网络地址
     */
    private static final String VOICE_HTTPURI = "voiceHttpUri";
    /**
     * 视频的本地缓存
     */
    private static final String MOVE_LOCALURI = "moveLocalUri";
    /**
     * 视频的网络地址
     */
    private static final String MOVE_HTTPURI = "moveHttpUri";
    /**
     * 图片的本地缓存
     */
    private static final String PHOTO_LOCALURI = "photoLocalUri";
    /**
     * 图片的网络地址
     */
    private static final String PHOTO_HTTPURI = "photoHttpUri";
    /**
     * 发送者 0 为患者 ， 1为医生
     */
    private static final String SENDER = "sender";
    /**
     * 音频视频的时间
     */
    private static final String MEDIA_DURATION = "mediaDuration";
    /**
     * 音频视频的大小
     */
    private static final String MEDIA_SIZE = "mediaSize";
    /**
     * 患者性别
     */
    private static final String PATIENT_GENDER = "patientGender";
    /**
     * 字母
     */
    private static final String PATIENT_LETTER = "patientLetter";
    /**
     * 患者年龄
     */
    private static final String PATIENT_AGE = "patientAge";
    /**
     * 未读信息
     */
    private static final String UN_READ_MESSAGENUM = "unReadMessageNum";
    /**
     * 是否发送成功   0失败 1 成功 2正在发送
     */
    private static final String IS_SEND_SUCCESS = "isSendSuccess";
    /**
     * 服务端信息ID（说明：信息在服务器端的编号） add by version 1.4
     */
    private static final String MSG_SERVER_ID = "msgServerId";
    /**
     * 声音信息的读取标示（说明：0：未读，1：已读） add by version 1.4
     */
    private static final String IS_READ = "isRead";
    /**
     * 患者被屏蔽标示（说明：0:不屏蔽，1:屏蔽） add by version 1.4
     */
    private static final String IS_SHIELD = "isShield";
    /**
     * 患者昵称
     */
    private static final String PATIENT_NICK_NAME = "patientNickName";
    /**
     * 患者备忘名称
     */
    private static final String PATIENT_MEMO_NAME = "patientMemoName";
    /**
     * 聊天会话ID
     */
    private static final String SESSION_ID = "sessionId";
    /**
     * "0：进行中；1：已结束
     */
    private static final String SESSION_LIFE_CYCLE = "sessionLifeCycle";
    /**
     * "0：免费；1：付费
     */
    private static final String PAY_MODE = "payMode";
    /**
     * "0：未付费；1：已付费
     */
    private static final String PAY_RESULT = "payResult";
    /**
     * 会话开始时间
     */
    private static final String SESSION_BEGIN_TIME = "sessionBeginTime";
    //备用字段
    /**
     * 对应XC_ChatModel 的 sessionEndTime 字段
     */
    private static final String BACK1 = "back1";
    /**
     * 对应 XC_ChatModel 的requireId 字段，购药咨询id
     */
    private static final String BACK2 = "back2";
    /**
     * 现在该字段无效，不存储任何内容
     * 曾经存储过得内容:
     * expireTime:购药咨询失效时间点(涉及消息类型 16:购药咨询、64:推荐用药)
     */
    private static final String BACK3 = "back3";
    /**
     * 对应XC_ChatModel 的 expiration 字段 有效期
     */
    private static final String BACK4 = "back4";
    /**
     * 对应 XC_ChatModel 的 originSendTime 字段，自主用药原始推送时间
     */
    private static final String BACK5 = "back5";
    /**
     * 对应 XC_ChatModle 的 recommandId字段，用于重复推荐用药时使用
     */
    private static final String BACK6 = "back6";
    /**
     * rxNum 处方单编号
     */
    private static final String BACK7 = "back7";
    /**
     * 临床诊断 症状
     */
    private static final String BACK8 = "back8";
    /**
     * 地址
     */
    private static final String BACK9 = "back9";
    /**
     * 患者消息来源的节点
     */
    private static final String BACK10 = "back10";
    /**
     * 推荐用药审核状态
     */
    private static final String BACK11 = "back11";
    /**
     * 处方描述
     */
    private static final String BACK12 = "back12";
    /**
     * 随访id
     */
    private static final String BACK13 = "back13";
    /**
     * 随访类型
     */
    private static final String BACK14 = "back14";
    /**
     * 随访内容
     */
    private static final String BACK15 = "back15";

    /** 2.7版本启用BACK16字段来放置IM消息中的content内容 */
    private static final String BACK16 = "back16";
    /** 2.7版本启用BACK17字段来放置IM消息中的consultPayType内容(会话是否付费(1-付费,0免费) */
    private static final String BACK17 = "back17";
    /** 2.7版本启用BACK18字段来放置消息中的messageId(消息Id) */
    private static final String BACK18 = "back18";
    /** 2.8版本启用BACK19字段放置是否被撤销的字段（0:表示未撤销；1:表示已撤销，该功能开发一半时候被终止） */
    private static final String BACK19 = "back19";
    /** 2.17版本启用BACK20字段放置拓展字段exd的内容 */
    private static final String BACK20 = "back20";
    /** 3.3版本启用BACK21字段放置session的json内容 */
    private static final String BACK21 = "back21";
    private static final String BACK22 = "back22";
    private static final String BACK23 = "back23";
    private static final String BACK24 = "back24";
    private static final String BACK25 = "back25";
    private static final String BACK26 = "back26";
    private static final String BACK27 = "back27";
    private static final String BACK28 = "back28";
    private static final String BACK29 = "back29";
    private static final String BACK30 = "back30";

    /**
     * 装db集合的
     */
    public static Map<String, XCChatModelDb> map = new LinkedHashMap<>();

    /**
     * 后去该数据库实例
     *
     * @param context 上下文
     * @param dbName  数据库名字
     * @return 数据库的单例
     */
    public static XCChatModelDb getInstance(Context context, String dbName) {

        XCChatModelDb db = map.get(dbName);

        if (db != null) {
            return db;
        }

        synchronized (XCChatModelDb.class) {
            if (map.get(dbName) == null) {
                map.put(dbName, new XCChatModelDb(context, dbName));
            }
            return map.get(dbName);
        }

    }

    private XCChatModelDb(Context context, String dbName) {
        super(context, dbName, null, VERSION);

        if (UtilString.isBlank(dbName)) {
            throw new RuntimeException("数据库名不能为空");
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + mOperatorTableName
                + "(" + _ID + " integer primary key autoincrement,"
                + PATIENT_ID + " text, "
                + PATIENT_NAME + " text, "
                + PATIENT_IMG_HEAD + " text, "
                + DOCTOR_SELF_ID + " text, "
                + DOCTOR_SELF_NAME + " text, "
                + DOCTOR_SELF_IMG_HEAD + " text, "
                + MSG_TIME + " text, "
                + MESSAGE_TEXT_RECOMMAND + " text, "
                + MESSAGE_TEXT + " text, "
                + MSG_TYPE + " text, "
                + MSG_UNIQUE + " text, "
                + VOICE_LOCALURI + " text, "
                + VOICE_HTTPURI + " text, "
                + MOVE_LOCALURI + " text, "
                + MOVE_HTTPURI + " text, "
                + PHOTO_LOCALURI + " text, "
                + PHOTO_HTTPURI + " text, "
                + SENDER + " text, "
                + MEDIA_DURATION + " text, "
                + MEDIA_SIZE + " text, "
                + PATIENT_GENDER + " text, "
                + PATIENT_LETTER + " text, "
                + PATIENT_AGE + " text, "
                + UN_READ_MESSAGENUM + " text, "
                + IS_SEND_SUCCESS + " text, "
                + MSG_SERVER_ID + " text, "
                + IS_READ + " text, "
                + IS_SHIELD + " text, "
                //+ FORMATCHATTIME + " text, "
                //+ MSGFORMAT + " text, "
                + PATIENT_NICK_NAME + " text, "
                + PATIENT_MEMO_NAME + " text, "
                + SESSION_ID + " text, "
                + SESSION_LIFE_CYCLE + " text, "
                + PAY_MODE + " text, "
                + PAY_RESULT + " text, "
                + SESSION_BEGIN_TIME + " text, "
                + BACK1 + " text, "
                + BACK2 + " text, "
                + BACK3 + " text, "
                + BACK4 + " text, "
                + BACK5 + " text, "
                + BACK6 + " text, "
                + BACK7 + " text, "
                + BACK8 + " text, "
                + BACK9 + " text, "
                + BACK10 + " text, "
                + BACK11 + " text, "
                + BACK12 + " text, "
                + BACK13 + " text, "
                + BACK14 + " text, "
                + BACK15 + " text, "
                + BACK16 + " text, "
                + BACK17 + " text, "
                + BACK18 + " text, "
                + BACK19 + " text, "
                + BACK20 + " text, "
                + BACK21 + " text, "
                + BACK22 + " text, "
                + BACK23 + " text, "
                + BACK24 + " text, "
                + BACK25 + " text, "
                + BACK26 + " text, "
                + BACK27 + " text, "
                + BACK28 + " text, "
                + BACK29 + " text, "
                + BACK30 + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        XCApplication.base_log.i(XCConfig.TAG_DB, "onUpgrade oldVersion=" + oldVersion
                + " ,newVersion =" + newVersion);
        if (newVersion > oldVersion) {
            //执行删除旧数据操作
            db.execSQL("drop table if exists " + mOperatorTableName);
            //创建新的db
            onCreate(db);
        }
    }

    /**
     * 抽取创建contentValue
     *
     * @param model 需要插入数据库的那条的信息
     * @return contentValue实例
     */
    private ContentValues createContentValue(XC_ChatModel model) {
        ContentValues values = new ContentValues();
        values.put(PATIENT_ID, model.getUserPatient().getPatientId());
        values.put(PATIENT_NAME, model.getUserPatient().getPatientName());
        values.put(PATIENT_IMG_HEAD, model.getUserPatient().getPatientImgHead());
        values.put(DOCTOR_SELF_ID, model.getUserDoctor().getDoctorSelfId());
        values.put(DOCTOR_SELF_NAME, model.getUserDoctor().getDoctorSelfName());
        values.put(DOCTOR_SELF_IMG_HEAD, model.getUserDoctor().getDoctorSelfImgHead());
        values.put(MSG_TIME, model.getMsgTime());
        values.put(MESSAGE_TEXT_RECOMMAND, model.getMessageTextRecommand());
        values.put(MESSAGE_TEXT, model.getMessageText());
        values.put(MSG_TYPE, model.getMsgType());
        values.put(MSG_UNIQUE, model.getMsgUnique());
        values.put(VOICE_LOCALURI, model.getVoiceLocalUri());
        values.put(VOICE_HTTPURI, model.getVoiceHttpUri());
        values.put(MOVE_LOCALURI, model.getMoveLocalUri());
        values.put(MOVE_HTTPURI, model.getMoveHttpUri());
        values.put(PHOTO_LOCALURI, model.getChatModelPhoto().getPhotoLocalUri());
        values.put(PHOTO_HTTPURI, model.getChatModelPhoto().getPhotoHttpUri());
        values.put(SENDER, model.getSender());
        values.put(MEDIA_DURATION, model.getMediaDuration());
        values.put(MEDIA_SIZE, model.getMediaSize());
        values.put(PATIENT_GENDER, model.getUserPatient().getPatientGender());
        values.put(PATIENT_LETTER, model.getUserPatient().getPatientLetter());
        values.put(PATIENT_AGE, model.getUserPatient().getPatientAge());
        values.put(UN_READ_MESSAGENUM, model.getUnReadMessageNum());
        values.put(IS_SEND_SUCCESS, model.getIsSendSuccess());
        values.put(MSG_SERVER_ID, model.getMsgServerId());
        values.put(IS_READ, model.getIsRead());
        values.put(IS_SHIELD, model.getUserPatient().getIsShield());
        values.put(PATIENT_NICK_NAME, model.getUserPatient().getPatientNickName());
        values.put(PATIENT_MEMO_NAME, model.getUserPatient().getPatientMemoName());
        values.put(SESSION_ID, model.getSessionId());
        values.put(SESSION_LIFE_CYCLE, model.getSessionLifeCycle());
        values.put(PAY_MODE, model.getPayMode());
        values.put(PAY_RESULT, model.getPayResult());
        values.put(SESSION_BEGIN_TIME, model.getSessionBeginTime());
        values.put(BACK1, model.getSessionEndTime());
        values.put(BACK2, model.getRequireId());
        values.put(BACK4, model.getExpiration());
        values.put(BACK5, model.getOriginSendTime());
        values.put(BACK6, model.getRecommandId());
        values.put(BACK7, model.getSerialNumber());
        values.put(BACK8, model.getDiagnosis());
        values.put(BACK9, model.getUserPatient().getCityName());
        values.put(BACK10, model.getLastPlatform());
        values.put(BACK11, model.getRecommandStatus());
        values.put(BACK12, model.getAuditDesc());
        values.put(BACK13, model.getVisitId());
        values.put(BACK14, model.getVisitType());
        values.put(BACK15, model.getViewMessage());
        values.put(BACK16, model.getContent());
        values.put(BACK17, model.getUserPatient().getConsultPayType());
        values.put(BACK18, model.getMessageId());
        values.put(BACK19, model.getCancelFlag());
        values.put(BACK20, model.getExd());
        values.put(BACK21, model.getSessionJson());
        return values;
    }

    /* 创建患者信息的ContentValue */
    private ContentValues createUserPatientContentValue(UserPatient userPatient){
        ContentValues values = new ContentValues();
        values.put(PATIENT_NAME,userPatient.getPatientName());
        values.put(PATIENT_IMG_HEAD,userPatient.getPatientImgHead());
        values.put(PATIENT_GENDER,userPatient.getPatientGender());
        values.put(PATIENT_LETTER,userPatient.getPatientLetter());
        values.put(PATIENT_AGE,userPatient.getPatientAge());
        values.put(PATIENT_NICK_NAME,userPatient.getPatientNickName());
        values.put(PATIENT_MEMO_NAME,userPatient.getPatientMemoName());
        values.put(BACK9,userPatient.getCityName());
        return values;
    }

    /**
     * 从数据库中取出数据
     * @param c 查询游标
     * @return 封装好的消息model
     */
    private XC_ChatModel createModel(Cursor c) {
        XC_ChatModel model = new XC_ChatModel();
        model.set_id(c.getString(c.getColumnIndex(_ID)));
        model.getUserPatient().setPatientId(c.getString(c.getColumnIndex(PATIENT_ID)));
        model.getUserPatient().setPatientName(c.getString(c.getColumnIndex(PATIENT_NAME)));
        model.getUserPatient().setPatientImgHead(c.getString(c.getColumnIndex(PATIENT_IMG_HEAD)));
        model.getUserDoctor().setDoctorSelfId(c.getString(c.getColumnIndex(DOCTOR_SELF_ID)));
        model.getUserDoctor().setDoctorSelfName(c.getString(c.getColumnIndex(DOCTOR_SELF_NAME)));
        model.getUserDoctor().setDoctorSelfImgHead(c.getString(c.getColumnIndex(DOCTOR_SELF_IMG_HEAD)));
        model.setMsgTime(c.getString(c.getColumnIndex(MSG_TIME)));
        model.setMessageTextRecommand(c.getString(c.getColumnIndex(MESSAGE_TEXT_RECOMMAND)));
        model.setMessageText(c.getString(c.getColumnIndex(MESSAGE_TEXT)));
        model.setMsgType(c.getString(c.getColumnIndex(MSG_TYPE)));
        model.setMsgUnique(c.getString(c.getColumnIndex(MSG_UNIQUE)));
        model.getChatModelPhoto().setPhotoLocalUri(c.getString(c.getColumnIndex(PHOTO_LOCALURI)));
        model.getChatModelPhoto().setPhotoHttpUri(c.getString(c.getColumnIndex(PHOTO_HTTPURI)));
        model.setVoiceLocalUri(c.getString(c.getColumnIndex(VOICE_LOCALURI)));
        model.setVoiceHttpUri(c.getString(c.getColumnIndex(VOICE_HTTPURI)));
        model.setMoveLocalUri(c.getString(c.getColumnIndex(MOVE_LOCALURI)));
        model.setMoveHttpUri(c.getString(c.getColumnIndex(MOVE_HTTPURI)));
        model.setSender(c.getString(c.getColumnIndex(SENDER)));
        model.setMediaDuration(c.getString(c.getColumnIndex(MEDIA_DURATION)));
        model.setMediaSize(c.getString(c.getColumnIndex(MEDIA_SIZE)));
        model.getUserPatient().setPatientGender(c.getString(c.getColumnIndex(PATIENT_GENDER)));
        model.getUserPatient().setPatientLetter(c.getString(c.getColumnIndex(PATIENT_LETTER)));
        model.getUserPatient().setPatientAge(c.getString(c.getColumnIndex(PATIENT_AGE)));
        model.setUnReadMessageNum(c.getString(c.getColumnIndex(UN_READ_MESSAGENUM)));
        model.setIsSendSuccess(c.getString(c.getColumnIndex(IS_SEND_SUCCESS)));
        model.setMsgServerId(c.getString(c.getColumnIndex(MSG_SERVER_ID)));
        model.setIsRead(c.getString(c.getColumnIndex(IS_READ)));
        model.getUserPatient().setIsShield(c.getString(c.getColumnIndex(IS_SHIELD)));
        model.getUserPatient().setPatientNickName(c.getString(c.getColumnIndex(PATIENT_NICK_NAME)));
        model.getUserPatient().setPatientMemoName(c.getString(c.getColumnIndex(PATIENT_MEMO_NAME)));
        model.setSessionId(c.getString(c.getColumnIndex(SESSION_ID)));
        model.setSessionLifeCycle(c.getString(c.getColumnIndex(SESSION_LIFE_CYCLE)));
        model.setPayMode(c.getString(c.getColumnIndex(PAY_MODE)));
        model.setPayResult(c.getString(c.getColumnIndex(PAY_RESULT)));
        model.setSessionBeginTime(c.getString(c.getColumnIndex(SESSION_BEGIN_TIME)));
        model.setSessionEndTime(c.getString(c.getColumnIndex(BACK1)));
        model.setRequireId(c.getString(c.getColumnIndex(BACK2)));
        model.setExpiration(c.getString(c.getColumnIndex(BACK4)));
        model.setOriginSendTime(c.getString(c.getColumnIndex(BACK5)));
        model.setRecommandId(c.getString(c.getColumnIndex(BACK6)));
        model.setSerialNumber(c.getString(c.getColumnIndex(BACK7)));
        model.setDiagnosis(c.getString(c.getColumnIndex(BACK8)));
        model.getUserPatient().setCityName(c.getString(c.getColumnIndex(BACK9)));
        model.setLastPlatform(c.getString(c.getColumnIndex(BACK10)));
        model.setRecommandStatus(c.getString(c.getColumnIndex(BACK11)));
        model.setAuditDesc(c.getString(c.getColumnIndex(BACK12)));
        model.setVisitId(c.getString(c.getColumnIndex(BACK13)));
        model.setVisitType(c.getString(c.getColumnIndex(BACK14)));
        model.setViewMessage(c.getString(c.getColumnIndex(BACK15)));
        model.setContent(c.getString(c.getColumnIndex(BACK16)));
        model.getUserPatient().setConsultPayType(c.getString(c.getColumnIndex(BACK17)));
        model.setMessageId(c.getString(c.getColumnIndex(BACK18)));
        model.setCancelFlag(c.getString(c.getColumnIndex(BACK19)));
        model.setExd(c.getString(c.getColumnIndex(BACK20)));
        model.setSessionJson(c.getString(c.getColumnIndex(BACK21)));
        Parse2ChatContent.parseContent(model);
        Parse2ChatExd.parseExd(model);
        Parse2ChatSession.parseSession(model);
        return model;
    }
    /* 创建患者信息 */
    private UserPatient createUserPatient(Cursor c){
        UserPatient userPatient = new UserPatient();
        userPatient.setPatientName(c.getString(c.getColumnIndex(PATIENT_NAME)));
        userPatient.setPatientImgHead(c.getString(c.getColumnIndex(PATIENT_IMG_HEAD)));
        userPatient.setPatientGender(c.getString(c.getColumnIndex(PATIENT_GENDER)));
        userPatient.setPatientLetter(c.getString(c.getColumnIndex(PATIENT_LETTER)));
        userPatient.setPatientAge(c.getString(c.getColumnIndex(PATIENT_AGE)));
        userPatient.setPatientMemoName(c.getString(c.getColumnIndex(PATIENT_MEMO_NAME)));
        userPatient.setCityName(c.getString(c.getColumnIndex(BACK9)));
        return userPatient;
    }

    /**
     * 插入一条记录
     *
     * @param model 待插入的消息model
     */
    public synchronized long insert(XC_ChatModel model) {

        if (model == null) {
            return -1;
        }

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = createContentValue(model);
        long id = db.insert(mOperatorTableName, _ID, values);
        XCApplication.base_log.i(XCConfig.TAG_DB, "插入的记录的id是: " + id);
        model.set_id(id + "");
        db.close();
        return id;
    }

    /**
     * 更新记录,网络获取的数据记录是不存db的,没有_id
     */
    public synchronized int update(XC_ChatModel model) {
        if (model == null) {
            return -1;
        }

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = createContentValue(model);
        int rows = db.update(mOperatorTableName, values, MSG_UNIQUE + "=?", new String[]{model.getMsgUnique()});
        XCApplication.base_log.i(XCConfig.TAG_DB, "更新了" + rows + "行");
        db.close();
        return rows;
    }

    /**
     * 删除所有记录
     */
    public synchronized int deleteAll() {
        SQLiteDatabase db = getWritableDatabase();
        int raw = db.delete(mOperatorTableName, null, null);
        db.close();
        return raw;
    }

    /**
     * 删除一条指定信息
     */
    public synchronized int delete(XC_ChatModel model) {
        if (model == null) {
            return -1;
        }
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(mOperatorTableName, MSG_UNIQUE + "=?",
                new String[]{model.getMsgUnique()});
        XCApplication.base_log.i(XCConfig.TAG_DB, "deleteByMsgUnique->" + rows + "行");
        db.close();
        return rows;
    }

    /**
     * @param recommandId 推荐用药id
     */
    public synchronized void deleteByRecomandId(String recommandId) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(mOperatorTableName, BACK6 + "=?", new String[]{recommandId + ""});
        XCApplication.base_log.i(XCConfig.TAG_DB, "deleteByRecomandId-->" + rows + "行");
        db.close();
    }

    /**
     * 查询共有多少条记录
     */
    private synchronized int queryAllCount() {
        int count = 0;
        SQLiteDatabase db = null;
        Cursor c = null;

        try {
            db = getReadableDatabase();
            c = db.query(mOperatorTableName, new String[]{"COUNT(*)"}, null, null, null, null, null);
            c.moveToNext();
            count = c.getInt(0);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close();
            }

            if (db != null) {
                db.close();
            }
        }
        return count;
    }

//    /**
//     * 获取最后一条医生或患者的聊天信息时间 +1毫秒
//     *
//     * @return 时间
//     */
//    public synchronized String queryLastChatFakeTime() {
//        XC_ChatModel lastMsg = queryLastChatMessage();
//        String timeString = lastMsg.getMsgTime();
//        if (!UtilString.isBlank(timeString)) {
//            long time = UtilString.toLong(timeString);
//            if (time != 0) {
//                return (time + 1) + "";
//            }
//        }
//        return "";
//    }

    /**
     * 查询最后一条医生或患者的聊天消息( 1 生成上传json时会用到该方法查询platform , 2 获取最后一条消息时间时也可能会用到)
     */
    public synchronized XC_ChatModel queryLastChatMessage() {

        XC_ChatModel bean = new XC_ChatModel();

        SQLiteDatabase db = null;
        Cursor c = null;

        try {
            db = getReadableDatabase();
            c = db.query(mOperatorTableName, null, SENDER + " != " + XC_ChatModel.SYSTEM, null, null, null, _ID + SORT_DESC, "1");
            if (c != null) {
                while (c.moveToNext()) {
                    bean = createModel(c);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close();
            }

            if (db != null) {
                db.close();
            }
        }
        return bean;
    }

    /**
     * 根据recommandId查询
     */
    public synchronized XC_ChatModel queryByRecommandId(String recommandId) {

        SQLiteDatabase db = null;
        Cursor c = null;

        XC_ChatModel bean = new XC_ChatModel();
        try {
            db = getReadableDatabase();
            c = db.query(mOperatorTableName, null, BACK6 + " = ? ", new String[]{recommandId}, null, null, _ID + SORT_DESC, "1");
            if (c != null) {
                while (c.moveToNext()) {
                    bean = createModel(c);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close();
            }

            if (db != null) {
                db.close();
            }
        }
        return bean;
    }
    /**
     * 根据messageId-宣教的消息ID-查询(宣教功能部分)
     */
    public synchronized XC_ChatModel queryByMessageId(String messageId) {

        SQLiteDatabase db = null;
        Cursor c = null;

        XC_ChatModel bean = new XC_ChatModel();
        try {
            db = getReadableDatabase();
            c = db.query(mOperatorTableName, null, BACK18 + " = ? ", new String[]{messageId}, null, null, _ID + SORT_DESC, "1");
            if (c != null) {
                while (c.moveToNext()) {
                    bean = createModel(c);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close();
            }

            if (db != null) {
                db.close();
            }
        }
        return bean;
    }
    /*
     * // 时间戳调小
     * 1
     * 2
     * 3
     * -100
     * -99
     * -98
     * 5
     * 10
     * -90
     * -89
     * <p/>
     * // 时间戳调大
     * 1
     * 2
     * 6
     * 10
     * 6
     * 7
     * 10
     * 11
     * 7
     */
    /**
     * 如果会话结束了,查询该session的最后一条信息
     */
    public synchronized XC_ChatModel queryLastMsgBySessionIdV2(String sessionId) {

        SQLiteDatabase db = null;
        Cursor c = null;

        XC_ChatModel bean = new XC_ChatModel();
        try {
            db = getReadableDatabase();
            // 如果会话的最后一条信息碰巧与会话结束时间相等
            c = db.query(mOperatorTableName, null, MSG_TYPE + " != " + XC_ChatModel.TYPE_SESSION_END_HINT + " and " + SESSION_ID + " =?", new String[]{sessionId}, null, null, _ID + SORT_DESC, "1");
            if (c != null) {
                while (c.moveToNext()) {
                    bean = createModel(c);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close();
            }

            if (db != null) {
                db.close();
            }
        }
        return bean;
    }

    /**
     * 1 . 分页查找,这里是查询小于time的消息,取一页; 如果是pageNum递增的去取固定条数,当删除消息时,可能有问题
     * 2 . 这里sessionId并未加入到查询条件,仅按时间戳查询, 比如第一个sessionId仅有5条,第二个sessionId有10条,如果是按sessionId查,则不满capactity的数量
     */
    @NonNull
    public synchronized List<XC_ChatModel> queryPageByTimeV1(boolean interceptBlankSessionId, int pageNum, int capacity, String sessionId, String time) {

        List<XC_ChatModel> beans = new ArrayList<>();

        //重新发起会话的时候（此时sessionId为空）是没有信息展示的，下拉之后才有
        //如果sessionId为空,interceptBlankSessionId为false,会查出发送失败的消息
        if (UtilString.isBlank(sessionId) && interceptBlankSessionId) {
            return beans;
        }

        if (UtilString.isBlank(time)) {
            return beans;
        }

        SQLiteDatabase db = null;
        Cursor c = null;

        try {
            db = getReadableDatabase();

            String offset = (pageNum - 1) * capacity + ""; // 偏移量
            String len = capacity + ""; // 个数

            c = db.query(mOperatorTableName, null, MSG_TIME + " < ? and " + MSG_TYPE + " != " + XC_ChatModel.TYPE_SESSION_END_HINT, new String[]{time}, null, null, _ID + SORT_DESC, offset + "," + len);
            if (c != null) {
                while (c.moveToNext()) {
                    XC_ChatModel bean = createModel(c);
                    beans.add(bean);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close();
            }

            if (db != null) {
                db.close();
            }
        }
        // 数据库是按逆序查的,比如10 9 8 7 6
        // 接口也是按逆序返的,比如10 9 8 7 6
        Collections.reverse(beans);

        if (!UtilCollection.isBlank(beans)) {
            // 有一个场景：网络不好时，消息正在发送，此时状态为SEND_ING,杀死应用，下次进来时因为是SENDING状态就会一直转dialog
            for (XC_ChatModel item : beans) {
                if ((XC_ChatModel.SEND_NOT).equals(item.getIsSendSuccess()) || (XC_ChatModel.SEND_ING).equals(item.getIsSendSuccess())) {
                    item.setIsSendSuccess(XC_ChatModel.SEND_FAIL);
                    update(item);
                }
            }
        }

        return beans;
    }

    /**
     * 从网络获取到的消息是没有_id的,对""做了判断,返回0的集合
     */
    @NonNull
    public synchronized List<XC_ChatModel> queryPageByIdV2(boolean intercept, int pageNum, int capacity, String _id) {

        List<XC_ChatModel> beans = new ArrayList<>();

        if (intercept) {
            return beans;
        }

        if (UtilString.isBlank(_id)) {
            return beans;
        }

        SQLiteDatabase db = null;
        Cursor c = null;

        try {
            db = getReadableDatabase();

            String offset = (pageNum - 1) * capacity + ""; // 偏移量
            String len = capacity + ""; // 个数

            c = db.query(mOperatorTableName, null, _ID + " < ? and " + MSG_TYPE + " != " + XC_ChatModel.TYPE_SESSION_END_HINT, new String[]{_id}, null, null, _ID + SORT_DESC, offset + "," + len);
            if (c != null) {
                while (c.moveToNext()) {
                    XC_ChatModel bean = createModel(c);
                    beans.add(bean);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close();
            }

            if (db != null) {
                db.close();
            }
        }
        // 数据库是按逆序查的,比如10 9 8 7 6
        // 接口也是按逆序返的,比如10 9 8 7 6
        Collections.reverse(beans);

        if (!UtilCollection.isBlank(beans)) {
            // 有一个场景：网络不好时，消息正在发送，此时状态为SEND_ING,杀死应用，下次进来时因为是SENDING状态就会一直转dialog
            for (XC_ChatModel item : beans) {
                if ((XC_ChatModel.SEND_NOT).equals(item.getIsSendSuccess()) || (XC_ChatModel.SEND_ING).equals(item.getIsSendSuccess())) {
                    item.setIsSendSuccess(XC_ChatModel.SEND_FAIL);
                    update(item);
                }
            }
        }
        return beans;
    }

    /**
     * 查询会话结束消息
     *
     * @param sessionId 会话id
     * @return 如果没有会话结束model，则返回null，null的返回值有用
     */
    public synchronized XC_ChatModel querySessionEndMsg(String sessionId) {
        XC_ChatModel bean = null;

        if (UtilString.isBlank(sessionId)) {
            return null;
        }

        SQLiteDatabase db = null;
        Cursor c = null;

        try {
            db = getReadableDatabase();
            c = db.query(mOperatorTableName, null, SESSION_ID + " = ? and " + SENDER + " = " + XC_ChatModel.SYSTEM + " and " + MSG_TYPE + " = " + XC_ChatModel.TYPE_SESSION_END_HINT, new String[]{sessionId}, null, null, _ID + SORT_DESC, "1");
            if (c != null) {
                while (c.moveToNext()) {
                    bean = createModel(c);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close();
            }

            if (db != null) {
                db.close();
            }
        }

        return bean;
    }

    /**
     * 正序分页查找
     */
    private synchronized List<XC_ChatModel> queryPageByAsc(int pageNum, int capacity) {

        SQLiteDatabase db = null;
        Cursor c = null;
        List<XC_ChatModel> beans = new ArrayList<>();

        try {
            String offset = (pageNum - 1) * capacity + "";
            String len = capacity + "";

            db = getReadableDatabase();
            c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_ASC, offset + "," + len);

            if (c != null) {
                while (c.moveToNext()) {
                    XC_ChatModel bean = createModel(c);
                    beans.add(bean);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close();
            }

            if (db != null) {
                db.close();
            }
        }
        return beans;
    }

    /**
     * 本地数据库可显示展示的消息数量
     */
    private static final int SAVE_LOCAL_MESSAGE_NUM = 5000;
    /**
     * 本地数据库中消息达到多少时清理一次数据库
     */
    private static final int LIMIT_LOCAL_MESSAGE_NUM = 5500;

    /**
     * 当db数量大于多少时，开始部分删除
     */
    public synchronized void checkChatMsgNum() {
        try {
            int total = queryAllCount();
            if (total >= LIMIT_LOCAL_MESSAGE_NUM) {

                int deleteCount = total - SAVE_LOCAL_MESSAGE_NUM;

                List<XC_ChatModel> xc_chatModels = queryPageByAsc(1, deleteCount);

                if (xc_chatModels != null) {
                    deleteHistory(xc_chatModels);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 批量删除
     */
    private synchronized void deleteHistory(List<XC_ChatModel> xc_chatModels) {
        SQLiteDatabase db = getWritableDatabase();
        for (XC_ChatModel model : xc_chatModels) {
            int rows = db.delete(mOperatorTableName, MSG_UNIQUE + "=?", new String[]{model.getMsgUnique() + ""});
            XCApplication.base_log.i(XCConfig.TAG_DB, "deleteByMsgUnique->" + rows + "行");
        }
        db.close();
    }

    /* 批量修改聊天记录中的患者内容
     * 返回true表示有数据被更改 ,false为没有被更改
     * */
    public synchronized boolean updateMsgHisttory(XC_ChatModel chatModel){
        boolean result;
        UserPatient userPatient = chatModel.getUserPatient();
        String patientId = userPatient.getPatientId();
        List<UserPatient> userPatientList = queryByPatientId(patientId);
        result = !UtilCollection.isBlank(userPatientList);
        for(UserPatient userPatient1 : userPatientList){
            if (UtilString.isBlank(userPatient1.getPatientName())){
                userPatient1.setPatientName(userPatient.getPatientName());
            }
            if (UtilString.isBlank(userPatient1.getPatientImgHead())){
                userPatient1.setPatientImgHead(userPatient.getPatientImgHead());
            }
            if (UtilString.isBlank(userPatient1.getPatientGender())){
                userPatient1.setPatientGender(userPatient.getPatientGender());
            }
            if (UtilString.isBlank(userPatient1.getPatientLetter())){
                userPatient1.setPatientLetter(userPatient.getPatientLetter());
            }
            if (UtilString.isBlank(userPatient1.getPatientAge())){
                userPatient1.setPatientAge(userPatient.getPatientAge());
            }
            if (UtilString.isBlank(userPatient1.getPatientMemoName())){
                userPatient1.setPatientMemoName(userPatient.getPatientMemoName());
            }
            if (UtilString.isBlank(userPatient1.getPatientName())){
                userPatient1.setPatientName(userPatient.getPatientName());
            }
            if (UtilString.isBlank(userPatient1.getCityName())){
                userPatient1.setCityName(userPatient.getCityName());
            }
        }

        SQLiteDatabase db = getWritableDatabase();
        try {
            db.beginTransaction();
            for (UserPatient userPatient1 : userPatientList){
                ContentValues values = createUserPatientContentValue(userPatient1);
                int rows = db.update(mOperatorTableName, values, PATIENT_ID + "=?", new String[]{patientId});
                XCApplication.base_log.i(XCConfig.TAG_DB, "更新了" + rows + "行");
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.endTransaction();
            db.close();
        }
        return result;
    }
    /**
     * 根据patientId查询
     */
    private synchronized List<UserPatient> queryByPatientId(String patientId) {
        SQLiteDatabase db = null;
        Cursor c = null;
        List<UserPatient> chatModels = new ArrayList<>();
        String[] columns = new String[]{
                PATIENT_NAME,
                PATIENT_IMG_HEAD,
                PATIENT_GENDER,
                PATIENT_LETTER,
                PATIENT_AGE,
                PATIENT_MEMO_NAME,
                BACK9,//地址
        };
        String sql = PATIENT_NAME + "='' or "+
                PATIENT_IMG_HEAD+"='' or "+
                PATIENT_GENDER+"='' or "+
                PATIENT_LETTER+"='' or "+
                PATIENT_AGE+"='' or "+
                PATIENT_MEMO_NAME+"='' or "+
                BACK9+"=''"
                ;
        try {
            db = getReadableDatabase();
            c = db.query(mOperatorTableName, columns, PATIENT_ID + " = ?"+" and "+sql, new String[]{patientId}, null, null, _ID + SORT_DESC);
            if (c != null) {
                while (c.moveToNext()) {
                    UserPatient bean = createUserPatient(c);
                    chatModels.add(bean);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return chatModels;
    }

    /**
     * 更改作废标记,只允许病历处方修改
     * @param recommandId 推荐ID
     * @param invalid 作废状态
     */
    public synchronized void updateInvalidForRecommandId(String recommandId,String invalid){
        SQLiteDatabase db;
        Cursor c = null;
        String[] columns = new String[]{BACK16};
        String content = "";
        db = getWritableDatabase();
        try {
            c = db.query(mOperatorTableName,columns,BACK6 + " = ?",new String[]{recommandId},null,null,null);
            if (null != c){
                int count = c.getCount();
                XCApplication.base_log.newE("MYM-------->查询出来的数据量为:"+count);
                if (c.moveToNext()){
                    content = c.getString(c.getColumnIndex(BACK16));
                }
                if (c.getCount() < 1){//如果数据库里面没有该条数据就不再进行处理并返回
                    db.close();
                    return;
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (c != null) {
                c.close();
            }
        }
        //----开始修改json
        try {
            JSONObject jsonObject;
            //3.4版本前面没有存储推荐用药的content(对应消息类型是16)，所以升级到新版本后取不到conten内容无法进入作废赋值,所以要重新存储一个新的content内容
            if (!UtilString.isBlank(content)){
                jsonObject = new JSONObject(content);
            }else {
                jsonObject = new JSONObject();
            }
            jsonObject.put("invalid",invalid);
            content = jsonObject.toString();
        }catch (JSONException e){
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            return;
        }
        ContentValues values = new ContentValues();
        values.put(BACK16,content);
        try {
            db.update(mOperatorTableName, values, BACK6 + "=?", new String[]{recommandId});
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (db != null) {
                db.close();
            }
        }
    }

    //-----------------------------------------------------------------------------------------------------------

//    /**
//     * @param sessionId 会话id
//     */
//    public synchronized List<XC_ChatModel> queryBySessionId(String sessionId) {
//
//        List<XC_ChatModel> beans = new ArrayList<XC_ChatModel>();
//
//        if (UtilString.isBlank(sessionId)) {
//            return beans;
//        }
//
//        SQLiteDatabase db = null;
//        Cursor c = null;
//        try {
//            db = getReadableDatabase();
//            c = db.query(mOperatorTableName, null, SESSION_ID + " = ? and " + MSG_TYPE + " != " + XC_ChatModel.TYPE_SESSION_END_HINT, new String[]{sessionId}, null, null, _ID + SORT_ASC);
//            if (c != null) {
//                while (c.moveToNext()) {
//                    XC_ChatModel bean = createModel(c);
//                    beans.add(bean);
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (c != null) {
//                c.close();
//            }
//
//            if (db != null) {
//                db.close();
//            }
//        }
//        return beans;
//    }
//
//    /**
//     * 以患者id删除记录
//     *
//     * @param patientId 患者id
//     */
//    public synchronized int deleteByPatientId(String patientId) {
//        SQLiteDatabase db = getWritableDatabase();
//        int rows = db.delete(mOperatorTableName, PATIENT_ID + "=?", new String[]{patientId + ""});
//        XCApplication.base_log.i(XCConfig.TAG_DB, "deleteByPatientId-->" + rows + "行");
//        db.close();
//        return rows;
//    }
//
//    /**
//     * 查询所有 queryAll  SORT_ASC
//     */
//    public synchronized List<XC_ChatModel> queryAllInfo() {
//
//        List<XC_ChatModel> beans = new ArrayList<XC_ChatModel>();
//
//        SQLiteDatabase db = null;
//        Cursor c = null;
//
//        try {
//            db = getReadableDatabase();
//            c = db.query(mOperatorTableName, null, null, null, null, null, _ID + SORT_ASC);
//            if (c != null) {
//                while (c.moveToNext()) {
//                    XC_ChatModel bean = createModel(c);
//                    beans.add(bean);
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (c != null) {
//                c.close();
//            }
//
//            if (db != null) {
//                db.close();
//            }
//        }
//        return beans;
//    }
}
