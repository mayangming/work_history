package com.qlk.ymz.adapter.ViewHolder;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.xiaocoder.android.fw.general.view.XCNoScrollListview;

/** 健康体检的ViewHolder */
public class XC_ChatRightCheckHealthHolder extends XC_ChatRightBaseHolder {

    public LinearLayout sk_id_check_health_rl;
    public XCNoScrollListview sk_id_check_health_listview;
    public TextView id_right_check_bill_show;
    public TextView check_health_count;
    public XC_ChatRightCheckHealthHolder(View convertView) {
        super(convertView);
        sk_id_check_health_rl = (LinearLayout) convertView.findViewById(R.id.sk_id_check_health_rl);
        sk_id_check_health_listview = (XCNoScrollListview) convertView.findViewById(R.id.sk_id_check_health_listview);
        id_right_check_bill_show = (TextView) convertView.findViewById(R.id.id_right_check_bill_show);
        check_health_count = (TextView) convertView.findViewById(R.id.check_health_count);
    }
}
