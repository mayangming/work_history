package com.qlk.ymz.activity;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.fragment.XL_PersonBasicInfoFragment;
import com.qlk.ymz.modelflag.XL_PatientBasicBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;

import org.apache.http.Header;

/**
 * 患者基本病情编辑页
 * wangyong
 */
public class PatientInfoBasicEditActivity extends DBActivity {
    private XCTitleCommonLayout titlebar;
    /**
     * 婚姻状态
     */
    TextView xc_id_personbasicinfo_tv_marry;
    /**
     * 身高
     */
    EditText xc_id_personbasicinfo_tv_height;
    /**
     * 体重
     */
    EditText xc_id_personbasicinfo_tv_weight;
    /**
     * 过敏史
     */
    EditText xc_id_personbasicinfo_tv_allergy;
    /**
     * 疾病历史
     */
    EditText xc_id_personbasicinfo_tv_anamnesis;
    /**
     * 家庭病史
     */
    EditText xc_id_personbasicinfo_tv_family_history;
    /**
     * 遗传病史
     */
    EditText xc_id_personbasicinfo_tv_genetic_history;
    /**
     * 抽烟
     */
    EditText xc_id_personbasicinfo_tv_smoke;
    /**
     * 是否饮酒
     */
    EditText xc_id_personbasicinfo_tv_drink;
    /**
     * 患者id不可少哦
     */
    private String mPatientId = "";
    /**
     * 提示布局
     */
    private LinearLayout tipLayout;
    /**
     * 提示内容
     */
    private TextView tipText;
    /**
     * 查看提示
     */
    private TextView tipLook;
    /**
     * 患者基本信息model
     */
    private XL_PatientBasicBean petientBasicBeanFlag;
    private static final int TO_PATIENT_INFO = 232;
    private PopupWindow mPopWindow;
    private LinearLayout mLinearLayout;
    public static final String PATIENT_INFO_BASIC = "patient_info_basic";
    /**
     * 是否保存基本病情对话框
     */
    private YR_CommonDialog PatientInfoDialog;
    /**
     * 是否提醒医生患者填写了基本病情
     */
    private String showTips;
    /**
     * 备注病情id
     */
    public String diseaseId;
    /**
     * 医生是否采用患者填写病情
     */
    public String used = "0";
    /** 备注病情最大长度*/
    private int max_length_remark_disease;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_patient_info_basic_edit);
        super.onCreate(savedInstanceState);
    }


    /** created by songxin,date：2017-9-26,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(PatientInfoBasicEditActivity.class);
    }

    /** created by songxin,date：2017-9-26,about：bi,end */

    /**
     * 初始化头部信息
     */
    public void initTitle() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "编辑基本病情");
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleRight2(true, 0, "保存");
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));
    }

    @Override
    public void initWidgets() {
        max_length_remark_disease = GlobalConfigSP.getLimitValue(GlobalConfigSP.PATIENT_REMARK_DISEASE,0,1000);
        initTitle();
        if (!TextUtils.isEmpty(getIntent().getExtras().getString(CommonConfig.PATIENT_ID))) {
            mPatientId = getIntent().getExtras().getString(CommonConfig.PATIENT_ID);
        }
        XL_PatientBasicBean patient_info = (XL_PatientBasicBean) getIntent().getSerializableExtra(PATIENT_INFO_BASIC);
        mLinearLayout = getViewById(R.id.linear);
        xc_id_personbasicinfo_tv_marry = getViewById(R.id.xc_id_personbasicinfo_tv_marry);
        xc_id_personbasicinfo_tv_height = getViewById(R.id.xc_id_personbasicinfo_tv_height);
        xc_id_personbasicinfo_tv_weight = getViewById(R.id.xc_id_personbasicinfo_tv_weight);
        xc_id_personbasicinfo_tv_allergy = getViewById(R.id.xc_id_personbasicinfo_tv_allergy);
        xc_id_personbasicinfo_tv_anamnesis = getViewById(R.id.xc_id_personbasicinfo_tv_anamnesis);
        xc_id_personbasicinfo_tv_family_history = getViewById(R.id.xc_id_personbasicinfo_tv_family_history);
        xc_id_personbasicinfo_tv_genetic_history = getViewById(R.id.xc_id_personbasicinfo_tv_genetic_history);
        xc_id_personbasicinfo_tv_smoke = getViewById(R.id.xc_id_personbasicinfo_tv_smoke);
        xc_id_personbasicinfo_tv_drink = getViewById(R.id.xc_id_personbasicinfo_tv_drink);
        tipLayout = getViewById(R.id.tip_layout);
        tipText = getViewById(R.id.title_tip_content);
        tipLook = getViewById(R.id.title_tip_setting);
        xc_id_personbasicinfo_tv_allergy.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max_length_remark_disease)});
        xc_id_personbasicinfo_tv_anamnesis.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max_length_remark_disease)});
        xc_id_personbasicinfo_tv_family_history.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max_length_remark_disease)});
        xc_id_personbasicinfo_tv_genetic_history.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max_length_remark_disease)});
        xc_id_personbasicinfo_tv_smoke.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max_length_remark_disease)});
        xc_id_personbasicinfo_tv_drink.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max_length_remark_disease)});

        if (patient_info != null) {
            diseaseId = patient_info.getDiseaseId();
            if (TextUtils.isEmpty(diseaseId)) {
                diseaseId = "";
            }
            showTips = patient_info.getShowTips();
            if ("1".equals(showTips)) {
                tipLayout.setVisibility(View.VISIBLE);
            } else {
                tipLayout.setVisibility(View.GONE);
            }
            petientBasicBeanFlag = patient_info;//保存开始患者信息  方便后面比对是否修改
            showPatientInfo(patient_info);
        }
        initPatientInfoBasicDialog();
    }

    @Override
    public void listeners() {
        xc_id_personbasicinfo_tv_marry.setOnClickListener(this);
        tipLook.setOnClickListener(this);
        titlebar.getXc_id_titlebar_left_layout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (petientBasicBeanFlag != null) {
                    String maritalStatusStr = xc_id_personbasicinfo_tv_marry.getText().toString();
                    String maritalStatus = "";
                    if (CommonConfig.UNMARRIED.equals(maritalStatusStr)) {
                        maritalStatus = "0";
                    } else if (CommonConfig.MARRIED.equals(maritalStatusStr)) {
                        maritalStatus = "1";
                    }
                    String height = xc_id_personbasicinfo_tv_height.getText().toString().trim();
                    String weight = xc_id_personbasicinfo_tv_weight.getText().toString().trim();
                    String familyHistory = xc_id_personbasicinfo_tv_family_history.getText().toString().trim();
                    String pastDisease = xc_id_personbasicinfo_tv_anamnesis.getText().toString().trim();
                    String medicationAllergy = xc_id_personbasicinfo_tv_allergy.getText().toString().trim();
                    String hereditaryDisease = xc_id_personbasicinfo_tv_genetic_history.getText().toString().trim();
                    String smokeHistory = xc_id_personbasicinfo_tv_smoke.getText().toString().trim();
                    String drinkHstory = xc_id_personbasicinfo_tv_drink.getText().toString().trim();
                    String aa = petientBasicBeanFlag.getMaritalStatus();
                    if (!maritalStatus.equals(petientBasicBeanFlag.getMaritalStatus()) || !height.equals(petientBasicBeanFlag.getHeight()) || !weight.equals(petientBasicBeanFlag.getWeight())
                            || !familyHistory.equals(petientBasicBeanFlag.getFamilyHistory()) || !pastDisease.equals(petientBasicBeanFlag.getPastDisease()) || !medicationAllergy.equals(petientBasicBeanFlag.getMedicationAllergy())
                            || !hereditaryDisease.equals(petientBasicBeanFlag.getHereditaryDisease()) || !smokeHistory.equals(petientBasicBeanFlag.getSmokeHistory()) || !drinkHstory.equals(petientBasicBeanFlag.getDrinkHstory())) {
                        PatientInfoDialog.show();
                        return;
                    }
                    finish();
                } else {
                    finish();
                }
            }
        });
        titlebar.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String maritalStatusStr = xc_id_personbasicinfo_tv_marry.getText().toString();
                String maritalStatus = "";
                if (CommonConfig.UNMARRIED.equals(maritalStatusStr)) {
                    maritalStatus = "0";
                } else if (CommonConfig.MARRIED.equals(maritalStatusStr)) {
                    maritalStatus = "1";
                }
                String height = xc_id_personbasicinfo_tv_height.getText().toString().trim();
                String weight = xc_id_personbasicinfo_tv_weight.getText().toString().trim();
                String familyHistory = xc_id_personbasicinfo_tv_family_history.getText().toString().trim();
                String pastDisease = xc_id_personbasicinfo_tv_anamnesis.getText().toString().trim();
                String medicationAllergy = xc_id_personbasicinfo_tv_allergy.getText().toString().trim();
                String hereditaryDisease = xc_id_personbasicinfo_tv_genetic_history.getText().toString().trim();
                String smokeHistory = xc_id_personbasicinfo_tv_smoke.getText().toString().trim();
                String drinkHstory = xc_id_personbasicinfo_tv_drink.getText().toString().trim();
                if (!maritalStatus.equals(petientBasicBeanFlag.getMaritalStatus()) || !height.equals(petientBasicBeanFlag.getHeight()) || !weight.equals(petientBasicBeanFlag.getWeight())
                        || !familyHistory.equals(petientBasicBeanFlag.getFamilyHistory()) || !pastDisease.equals(petientBasicBeanFlag.getPastDisease()) || !medicationAllergy.equals(petientBasicBeanFlag.getMedicationAllergy())
                        || !hereditaryDisease.equals(petientBasicBeanFlag.getHereditaryDisease()) || !smokeHistory.equals(petientBasicBeanFlag.getSmokeHistory()) || !drinkHstory.equals(petientBasicBeanFlag.getDrinkHstory())) {
                    editPatientInfo(maritalStatus, maritalStatusStr, height, weight, medicationAllergy, pastDisease, familyHistory, hereditaryDisease, smokeHistory, drinkHstory);
                } else {
                    shortToast("你还没有做修改");
                }
            }
        });
    }

    @Override
    public void onNetRefresh() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        int id = v.getId();
        switch (id) {
            case R.id.xc_id_personbasicinfo_tv_marry:
                showPopupWindow();
                break;
            case R.id.title_tip_setting:
                Intent intent = new Intent();
                intent.setClass(this, XL_PatientInfoBasicActivity.class);
                intent.putExtra(CommonConfig.PATIENT_ID, mPatientId);
                myStartActivityForResult(intent, TO_PATIENT_INFO);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (RESULT_OK == resultCode) {
            switch (requestCode) {
                case TO_PATIENT_INFO:
                    if (data != null && data.getExtras() != null) {
                        used = "1";
                        tipLayout.setVisibility(View.GONE);
                        XL_PatientBasicBean patient_detail = (XL_PatientBasicBean) data.getExtras().getSerializable(XL_PersonBasicInfoFragment.PATIENT_INFO);
                        showPatientInfo(patient_detail);
                    }
                    break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (mPopWindow != null && mPopWindow.isShowing()) {
            mPopWindow.dismiss();
        } else {
            if (petientBasicBeanFlag != null) {
                String maritalStatusStr = xc_id_personbasicinfo_tv_marry.getText().toString();
                String maritalStatus = "";
                if (CommonConfig.UNMARRIED.equals(maritalStatusStr)) {
                    maritalStatus = "0";
                } else if (CommonConfig.MARRIED.equals(maritalStatusStr)) {
                    maritalStatus = "1";
                }
                String height = xc_id_personbasicinfo_tv_height.getText().toString().trim();
                String weight = xc_id_personbasicinfo_tv_weight.getText().toString().trim();
                String familyHistory = xc_id_personbasicinfo_tv_family_history.getText().toString().trim();
                String pastDisease = xc_id_personbasicinfo_tv_anamnesis.getText().toString().trim();
                String medicationAllergy = xc_id_personbasicinfo_tv_allergy.getText().toString().trim();
                String hereditaryDisease = xc_id_personbasicinfo_tv_genetic_history.getText().toString().trim();
                String smokeHistory = xc_id_personbasicinfo_tv_smoke.getText().toString().trim();
                String drinkHstory = xc_id_personbasicinfo_tv_drink.getText().toString().trim();
                if (!maritalStatus.equals(petientBasicBeanFlag.getMaritalStatus()) || !height.equals(petientBasicBeanFlag.getHeight()) || !weight.equals(petientBasicBeanFlag.getWeight())
                        || !familyHistory.equals(petientBasicBeanFlag.getFamilyHistory()) || !pastDisease.equals(petientBasicBeanFlag.getPastDisease()) || !medicationAllergy.equals(petientBasicBeanFlag.getMedicationAllergy())
                        || !hereditaryDisease.equals(petientBasicBeanFlag.getHereditaryDisease()) || !smokeHistory.equals(petientBasicBeanFlag.getSmokeHistory()) || !drinkHstory.equals(petientBasicBeanFlag.getDrinkHstory())) {
                    PatientInfoDialog.show();
                    return;
                }
                finish();
            } else {
                finish();
            }
        }
    }

    /**
     * 选择婚姻状况
     */
    private void showPopupWindow() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 0.4f;
        getWindow().setAttributes(lp);
        if (mPopWindow == null) {
            View view = LayoutInflater.from(PatientInfoBasicEditActivity.this).inflate(R.layout.select_marriage_layout, null);
            mPopWindow = new PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            TextView unmarried = (TextView) view.findViewById(R.id.unmarried);
            unmarried.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mPopWindow.dismiss();
                    xc_id_personbasicinfo_tv_marry.setText("未婚");
                }
            });
            TextView married = (TextView) view.findViewById(R.id.married);
            married.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mPopWindow.dismiss();
                    xc_id_personbasicinfo_tv_marry.setText("已婚");
                }
            });
            mPopWindow.setTouchable(true);
            mPopWindow.setOutsideTouchable(true);
            mPopWindow.setFocusable(true);
            mPopWindow.setBackgroundDrawable(new BitmapDrawable());
            mPopWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        mPopWindow.showAtLocation(mLinearLayout, Gravity.BOTTOM, 0, 0);
        mPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            public void onDismiss() {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.alpha = 1f;
                getWindow().setAttributes(lp);
            }
        });
    }

    /**
     * 显示患者信息
     *
     * @param patient_detail 患者信息
     */
    private void showPatientInfo(XL_PatientBasicBean patient_detail) {
        if (patient_detail != null) {
            String maritalStatus = patient_detail.getMaritalStatus();
            String height = patient_detail.getHeight();
            String weight = patient_detail.getWeight();
            String familyHistory = patient_detail.getFamilyHistory();
            String pastDisease = patient_detail.getPastDisease();
            String medicationAllergy = patient_detail.getMedicationAllergy();
            String hereditaryDisease = patient_detail.getHereditaryDisease();
            String smokeHistory = patient_detail.getSmokeHistory();
            String drinkHstory = patient_detail.getDrinkHstory();

            if ("0".equals(maritalStatus)) {
                xc_id_personbasicinfo_tv_marry.setText("未婚");
            } else if ("1".equals(maritalStatus)) {
                xc_id_personbasicinfo_tv_marry.setText("已婚");
            }
            xc_id_personbasicinfo_tv_height.setText(height);
            xc_id_personbasicinfo_tv_weight.setText(weight);
            xc_id_personbasicinfo_tv_allergy.setText(medicationAllergy);
            xc_id_personbasicinfo_tv_anamnesis.setText(pastDisease);
            xc_id_personbasicinfo_tv_drink.setText(drinkHstory);
            xc_id_personbasicinfo_tv_family_history.setText(familyHistory);
            xc_id_personbasicinfo_tv_genetic_history.setText(hereditaryDisease);
            xc_id_personbasicinfo_tv_smoke.setText(smokeHistory);
        }
    }

    /**
     * 是否保存基本病情对话框
     */
    private void initPatientInfoBasicDialog() {
        if (PatientInfoDialog == null) {
            PatientInfoDialog = new YR_CommonDialog(PatientInfoBasicEditActivity.this, "还没有保存", "放弃", "取消") {
                @Override
                public void confirmBtn() {
                    PatientInfoDialog.dismiss();
                }

                @Override
                public void cancelBtn() {
                    super.cancelBtn();
                    myFinish();
                }
            };
            PatientInfoDialog.setCanceledOnTouchOutside(true);
        }
    }

    /**
     * 保存患者基本病情
     */
    private void editPatientInfo(String maritalStatus, String maritalStatusStr, String height, String weight, String medicationStr, String pastDisease, String familyHistory, String hereditaryDisease, String smokeHistory, String drinkHistory) {
        RequestParams params = new RequestParams();
        params.put("diseaseId", diseaseId);
        params.put("maritalStatus", maritalStatus);
        params.put("maritalStatusStr", maritalStatusStr);
        params.put("height", height);
        params.put("weight", weight);
        params.put("medicationAllergy", medicationStr);
        params.put("pastDisease", pastDisease);
        params.put("familyHistory", familyHistory);
        params.put("hereditaryDisease", hereditaryDisease);
        params.put("smokeHistory", smokeHistory);
        params.put("drinkHistory", drinkHistory);
        params.put("used", used);
        params.put("patientId", mPatientId);
        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.save_patient_basic_disease), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }

            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(PatientInfoBasicEditActivity.this,
                        getCode(),
                        getMsg())) {

                }
            }
        });
    }
}
