package com.qlk.ymz.fragment;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBFragment;
import com.qlk.ymz.util.QRCodeUtil;
import com.qlk.ymz.util.SP.UtilSP;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.imageloader.XCImageLoaderHelper;

import java.io.File;

public class QRCodeFragment extends DBFragment {
	private static final String KEY_CONTENT = "QRCodeFragment:Position";
	/**患者标记*/
	public static final int PATIENT_TAG = 0;
	/**医生标记*/
	public static final int DOCTOR_TAG = 1;
	/**
	 * 0 患者 1 医生
	 */
	private int mPosition;
	/**头像*/
	private ImageView iv_img;
	/**姓名*/
	private TextView tv_name;
	/**科室*/
	private TextView tv_dep;
	/**工作*/
	private TextView tv_job;
	/**医院*/
	private TextView tv_hospital;
	/**二维码*/
	private ImageView iv_orcode;
	/**logo*/
	private ImageView logo;
	/**备注*/
	private TextView tv_intro;
	/**标签*/
	private TextView tv_titile;
	/**
	 * 图片显示设置
	 */
	private DisplayImageOptions options = XCImageLoaderHelper.getDisplayImageOptions(R.mipmap.sx_d_identity_personal_head_icon_v2);
	/**重试布局*/
	private RelativeLayout iv_orcode_retry_ll;
	/**重试*/
	private TextView iv_orcode_retry;
	/**
	 * 医生的下方文字说明
	 */
	String doctor = "<p>微信扫一扫</p>";

	/**
	 * 患者的下方文字说明
	 */
	String patient = "<p>微信扫一扫</p>";
	private String headerUrl;
	/**患者二维码*/
	private String spreadPatient_qrUrl;
	/**医生二维码*/
	private String spreadDoctor_qrUrl;
	private ORCodeShareListerer orCodeShareListerer;
	private Bitmap qrBitmap;
	public void setOrCodeShareListerer(ORCodeShareListerer orCodeShareListerer) {
		this.orCodeShareListerer = orCodeShareListerer;
	}

	public static QRCodeFragment newInstance(int position) {
		QRCodeFragment fragment = new QRCodeFragment();
		fragment.mPosition = position;
		return fragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if ((savedInstanceState != null)
				&& savedInstanceState.containsKey(KEY_CONTENT)) {
			mPosition = savedInstanceState.getInt(KEY_CONTENT);
		}
		return init(inflater, R.layout.pf_view_orcode);
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putInt(KEY_CONTENT, mPosition);
	}

	@Override
	public void initWidgets() {
		iv_img = getViewById(R.id.iv_img);
		tv_name = getViewById(R.id.tv_name);
		tv_dep = getViewById(R.id.tv_dep);
		tv_job = getViewById(R.id.tv_job);
		tv_hospital = getViewById(R.id.tv_hospital);
		iv_orcode = getViewById(R.id.iv_orcode);
		logo = getViewById(R.id.logo);
		tv_intro = getViewById(R.id.tv_intro);
		tv_titile = getViewById(R.id.tv_titile);
		iv_orcode_retry_ll = getViewById(R.id.iv_orcode_retry_ll);
		iv_orcode_retry = getViewById(R.id.iv_orcode_retry);
		setData();
	}
	private Handler handler = new Handler(){
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == 1){
				if (null != qrBitmap){
					iv_orcode_retry_ll.setVisibility(View.GONE);
					iv_orcode.setImageBitmap(qrBitmap);
				}else {
					iv_orcode_retry_ll.setVisibility(View.VISIBLE);
				}
			}
		}
	};
	public void setData() {
		//患者
		if (mPosition == PATIENT_TAG){
			tv_intro.setText(Html.fromHtml(patient));
			tv_titile.setText("邀请患者");
			tv_titile.setBackgroundResource(R.drawable.pf_pat_bg);
			spreadPatient_qrUrl = UtilSP.getSpreadPatientQrUrl();
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						qrBitmap = QRCodeUtil.createQRImage(spreadPatient_qrUrl, 300, 300,
								BitmapFactory.decodeResource(getResources(), R.mipmap.sx_d_login_logo_v2));
						handler.sendEmptyMessage(1);
					} catch(OutOfMemoryError e) {
						e.printStackTrace();
					}

				}
			}).start();
		}
		//医生
		else if(mPosition == DOCTOR_TAG){
			tv_name.setText(UtilSP.getName());
			tv_intro.setText(Html.fromHtml(doctor));
			tv_titile.setText("邀请医生");
			tv_titile.setBackgroundResource(R.drawable.pf_doc_bg);
			spreadDoctor_qrUrl = UtilSP.getSpreadDoctorQrUrl();
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						qrBitmap = QRCodeUtil.createQRImage(spreadDoctor_qrUrl, 300, 300,
								BitmapFactory.decodeResource(getResources(), R.mipmap.sx_d_login_logo_v2));
						handler.sendEmptyMessage(1);
					} catch(OutOfMemoryError e) {
						e.printStackTrace();
					}
				}
			}).start();
		}
		tv_name.setText(UtilSP.getName());
		tv_dep.setText(getDepartment(UtilSP.getDepartment()));
		tv_job.setText(getJobTitle(UtilSP.getTitle()));
		tv_hospital.setText(getJobTitle(UtilSP.getHospital()));
		headerUrl = UtilSP.getUserHeaderImage();
		if (URLUtil.isValidUrl(headerUrl)
				&& ((headerUrl.endsWith(".jpg"))
				|| (headerUrl.endsWith(".JPG"))
				|| (headerUrl.endsWith(".jpeg"))
				|| (headerUrl.endsWith(".JPEG"))
				|| (headerUrl.endsWith(".bmp"))
				|| (headerUrl.endsWith(".BMP"))
				|| (headerUrl.endsWith(".PNG"))
				|| (headerUrl.endsWith(".png")))) {
			//地址正确
			setDoctorHeadImg();
		} else {
			//否则不加载
			iv_img.setImageResource(R.mipmap.js_d_icon_doctor);
		}
	}

	@Override
	public void listeners() {
		iv_orcode_retry.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (null != orCodeShareListerer){
					orCodeShareListerer.refreshData();
				}
			}
		});
		iv_img.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (null != orCodeShareListerer){
					orCodeShareListerer.showBigHeader();
				}
			}
		});
		iv_orcode.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View view) {
				if (null != orCodeShareListerer){
					orCodeShareListerer.longClick(mPosition);
				}
				return false;
			}
		});
	}
	/**
	 * 处理科室名称（超过8个字的名称显示为头7个字加…显示）
	 *
	 * @param department 原始科室名
	 * @return String 加工后的科室名
	 */
	private String getDepartment(String department) {
		String tempStr = "";

		try {
			int departmentNameLength = department.trim().length();
			if (departmentNameLength > 8) {
				tempStr = department.substring(0, 7) + "…";
			} else {
				tempStr = department;
			}
		} catch (Exception e) {
			tempStr = "";
		}

		return tempStr;
	}

	/**
	 * 处理原职称名（超过7个字的名称显示为头6个字加…显示）
	 *
	 * @param jobTitle 原职称名
	 * @return String 加工后的职称名
	 */
	private String getJobTitle(String jobTitle) {
		String tempStr = "";

		try {
			int jobTitleLength = jobTitle.trim().length();
			if (jobTitleLength > 7) {
				tempStr = jobTitle.substring(0, 6) + "…";
			} else {
				tempStr = jobTitle;
			}
		} catch (Exception e) {
			tempStr = "";
		}

		return tempStr;
	}
	public interface ORCodeShareListerer{
		void longClick(int position);
		void showBigHeader();
		void refreshData();
	}
	//文件存储根目录
	private String getFileRoot(Context context) {
		if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
			File external = context.getExternalFilesDir(null);
			if (external != null) {
				return external.getAbsolutePath();
			}
		}

		return context.getFilesDir().getAbsolutePath();
	}
	/**
	 * 设置医生头像
	 */
	public void setDoctorHeadImg() {
		// 如果医生的认证状态为“已认证”，则显示医生上传的头像
		String doctorAuthenticationStatus = UtilSP.getAuthStatus();
		if ("1".equals(doctorAuthenticationStatus)) {
			XCApplication.displayImage(headerUrl, iv_img, options);
		}
		// 如果医生的认证状态不为“已认证”，则显示医生的默认头像
		else {
			iv_img.setImageResource(R.mipmap.js_d_icon_doctor);
		}
	}
}
