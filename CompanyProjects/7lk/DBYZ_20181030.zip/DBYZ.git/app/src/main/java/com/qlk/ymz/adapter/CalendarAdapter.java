package com.qlk.ymz.adapter;

import android.app.Activity;
import android.support.v4.view.PagerAdapter;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.qlk.ymz.R;
import com.qlk.ymz.parse.Parse2MonthSignInBean;
import com.qlk.ymz.view.WrapContentHeightViewPager;
import com.xiaocoder.android.fw.general.util.UtilString;

import java.util.HashMap;

/**
 * Created by xiedongtd on 2016/11/4.
 * 日历切换月份适配器
 */

public class CalendarAdapter extends PagerAdapter {
    /** 显示多少个月*/
    private int monthNum;
    /** 开始月份*/
    private int startMonth;
    /** 开始年份*/
    private int startYear;
    //依附的activity
    private Activity mActivity;
    //适配的viewpager
    private WrapContentHeightViewPager mWrapContentHeightViewPager;
    //签到记录的数据集
    private HashMap<String, Parse2MonthSignInBean> mMonthSignInBeanHashMap;

    /**
     *
     * @param activity 依附的activity
     * @param wrapContentHeightViewPager 适配的viewpager
     * @param mMonthSignInBeanHashMap 签到记录的数据集
     * @param monthNum  显示月数（有几个月的签到记录）
     * @param key 当前月签到数据的key(用于取hashmap的值)
     */
    public CalendarAdapter(Activity activity,WrapContentHeightViewPager
            wrapContentHeightViewPager,HashMap mMonthSignInBeanHashMap,int monthNum,String key){
        mActivity = activity;
        mWrapContentHeightViewPager = wrapContentHeightViewPager;
        this.mMonthSignInBeanHashMap = mMonthSignInBeanHashMap;
        this.monthNum = monthNum;
        Parse2MonthSignInBean parse2MonthSignInBean = this.mMonthSignInBeanHashMap.get(key);
        if(parse2MonthSignInBean!=null){
            startYear = UtilString.toInt(parse2MonthSignInBean.getOpenYear());
            startMonth = UtilString.toInt(parse2MonthSignInBean.getOpenMonth());
        }
    }

    @Override
    public int getCount() {
        return monthNum;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View inflate = LayoutInflater.from(mActivity).inflate(R.layout.xd_item_calendar_change, null);
        RecyclerView rv_calendar = (RecyclerView) inflate.findViewById(R.id.rv_calendar);
        //此设置优化recyclerview
        rv_calendar.setHasFixedSize(true);
        //添加自定义分割线
        rv_calendar.addItemDecoration(new CalendarItemDecoration(mActivity));
        //设置recyclerview的布局方式
        rv_calendar.setLayoutManager(new GridLayoutManager(mActivity, 7));
        //设置适配器
        CalendarDayAdapter calendarDayAdapter = new CalendarDayAdapter(mActivity);
        rv_calendar.setAdapter(calendarDayAdapter);
        //计算当前position的对应年月
        int i = startYear + (startMonth+position-1)/12;
        int i1 = (startMonth+position-1)%12+1;
        //取出计算当前position的对应年月的签到数据
        Parse2MonthSignInBean parse2MonthSignInBean = mMonthSignInBeanHashMap.get(i + ""+i1);
        //绑定数据
        calendarDayAdapter.bindData(i,i1,parse2MonthSignInBean);
        //在viewpager保存position对于的View
        mWrapContentHeightViewPager.setObjectForPosition(inflate,position);
        container.addView(inflate);
        return inflate;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    private int mChildCount = 0;

    @Override
    public void notifyDataSetChanged() {
        mChildCount = getCount();
        super.notifyDataSetChanged();
    }

    @Override
    public int getItemPosition(Object object)   {
        if ( mChildCount > 0) {
            mChildCount --;
            return POSITION_NONE;//解决不能刷新
        }
        return super.getItemPosition(object);
    }
}

