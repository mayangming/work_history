package com.qlk.ymz.activity;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;

import com.qlk.ymz.R;
import com.qlk.ymz.util.bi.BiUtil;

/**
 * @description 显示裁剪结果的页面
 * @author 徐金山
 * @version 1.5.0
 */
public class JS_ShowImageActivity extends Activity {
    /** 要显示的图片对应的的byte数组类型内容 */
    private byte[] imageByteData = null;
    /** 显示裁剪的结果图片 */
    private ImageView iv_showImage;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.js_activity_show_clip_result_image);

        getInitData();
        findViews();
        processBiz();
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(JS_ShowImageActivity.class);
    }

    /** created by songxin,date：2016-4-23,about：bi,end */

    private void getInitData() {
        imageByteData = getIntent().getByteArrayExtra("bitmap");
    }

    private void findViews() {
        iv_showImage = (ImageView) findViewById(R.id.iv_showImage);
    }

    private void processBiz() {
        iv_showImage.setImageBitmap(getShowImage(imageByteData));
    }

    /**
     * 获取要显示的图片。如果要显示的图片为null，则显示默认图片。
     * @param imageByteData 要显示的图片对应的的byte类型内容
     * @return 要显示的图片
     */
    private Bitmap getShowImage(byte[] imageByteData) {
        Bitmap bitmap = null;

        if(null != imageByteData) {
            bitmap = BitmapFactory.decodeByteArray(imageByteData, 0, imageByteData.length);
        }

        if(null == bitmap) {
            Drawable tempObj = getResources().getDrawable(R.mipmap.sx_d_personal_photos_sample_amplification);
            BitmapDrawable bd = (BitmapDrawable) tempObj;
            bitmap = bd.getBitmap();
        }

        return bitmap;
    }
}
