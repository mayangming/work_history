package com.qlk.ymz.activity;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.db.im.chatmodel.UserPatient;
import com.qlk.ymz.db.medicineUageDosage.MedicineUsageBeanDb;
import com.qlk.ymz.db.medicineUageDosage.XLMedicineUseageDosageDAO;
import com.qlk.ymz.model.DiagnoseBean;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.InventoryInfo;
import com.qlk.ymz.model.SafeMedicationBean;
import com.qlk.ymz.model.XC_PatientDrugInfo;
import com.qlk.ymz.model.medicine.MedicineCycleBean;
import com.qlk.ymz.model.medicine.MedicineCycleUnitBean;
import com.qlk.ymz.model.medicine.MedicineDateAndMethodBean;
import com.qlk.ymz.model.medicine.MedicineDateUnitBean;
import com.qlk.ymz.model.medicine.MedicineDosageBean;
import com.qlk.ymz.model.medicine.MedicineUsageBean;
import com.qlk.ymz.model.record.DrCaseVOBean;
import com.qlk.ymz.model.record.DrRecordVOBean;
import com.qlk.ymz.parse.Parse2DrugBean;
import com.qlk.ymz.parse.Parse2InventoryInfo;
import com.qlk.ymz.parse.Parse2SafeMedication;
import com.qlk.ymz.parse.Parse2UsageBean;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.MedicineUsageUtil;
import com.qlk.ymz.util.RecomMedicineHelper;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.SP.UtilSP;
import com.qlk.ymz.util.UtilNum;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.UsageDialog;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.xiaocoder.android.fw.general.application.XCApplication;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;
import com.xiaocoder.android.fw.general.util.UtilString;

import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Integer.parseInt;

/**
 * @description 用法用量页面
 * @author      赖善琦
 * @version     2.14.0
 *
 */
public class UsageActivityV2 extends DBActivity implements View.OnClickListener{
    /** 标题 */
    private XCTitleCommonLayout sk_id_drug_usage_title;
    /** 页面scrollview */
    private ScrollView usage_content_sv;
    /**药品名称*/
    private TextView usage_drug_name;
    /**规格*/
    private TextView usage_spec;
    /**常规用法*/
    private TextView usage_general_tv;
    /**用量布局*/
    private RelativeLayout usage_consumption_rl;
    /**用量文本*/
    private TextView usage_consumption_tv;
    /**每次 减号 */
    private ImageView usage_consumption_sub_iv;
    /**每次 输入框 */
    private EditText usage_consumption_et;
    /**每次 加号 */
    private ImageView usage_consumption_add_iv;
    /**单位布局 */
    private RelativeLayout usage_company_rl;
    /** 单位文本 */
    private TextView usage_company_tv;
    /**用法布局 */
    private RelativeLayout usage_item_rl;
    /**用法文本*/
    private TextView usage_item_tv;
    /**周期布局 */
    private RelativeLayout usage_cycle_rl;
    /** 周期图标*/
    private ImageView usage_cycle_iv;
    /**周期文本*/
    private TextView usage_cycle_tv;
    /** 周期处安全用量的提示*/
    private TextView tv_cycle_safe_dosage_limit;
    /**购买数量减号 */
    private ImageView usage_num_sub_iv;
    /**购买数量输入框 */
    private EditText usage_num_et;
    /**购买数量加号*/
    private ImageView usage_num_add_iv;
    /**购买单位*/
    private TextView usage_drug_unit_tv;
    /**限购图标*/
    private ImageView sk_id_usage_xg;
    /** 限购信息和预售 布局*/
    private LinearLayout ll_usage_skuLimitInfo;
    /**限购信息1*/
    private TextView tv_usage_skuLimitInfo_1;
    /**预售图标*/
    private ImageView sk_id_usage_presell;
    /**库存不足图标*/
    private ImageView sk_id_usage_short_iv;
    /**限购信息2*/
    private TextView tv_usage_skuLimitInfo_2;
    /**患者限购信息*/
    private TextView tv_usage_patientLimitInfo;
    /** 药品数量处安全用量提示*/
    private TextView tv_num_safe_dosage_limit;
    /**备注输入框*/
    private EditText usage_bakup;
    /**保存按钮 */
    private TextView usage_save_button;
    /** 用量选择完返回的动画控件 */
    private View v_bg_anim;
    /** 药品信息 */
    private DrugBean mDrugBean;
    /** 选择属性的对话框 */
    private UsageDialog mUsageDialog;
    /** 选择对话框的数据集合 */
    List<String> textList = new ArrayList<>();
    /** intent获取药品信息的key */
    public static String DRUG_INFO = "drug_info";
    /** 用法用量请求码 */
    public static int REQUEST_CODE_USAGE = 102;
    /** 自定义属性页面的标记 */
    private int tag;
    /** 用法用量信息 */
    private MedicineUsageBean usageBean = new MedicineUsageBean();
    /** 患者ID */
    private String patientId;
    /**
     * 用药周期文本内容
     */
    private String drugCycleContent_tag_1 = "未选择";
    private String drugCycleContent_tag_2 = "仅支持选择默认单位进行计算";

    /** 用来标识常规用法内容有没有超过三行，控制展开和隐藏,
     * 默认true：没超过。（true：没超过，fals：已超过） */
    private boolean genralFlag = false;

    /**
     * 是否可用刷新周期
     */
    public boolean isRefreshDrugCycle = true;

    /**
     * 是否第一次修改次数，activity onCreate 为第一次
     */
    public boolean isFirstTimeChangeNum = true;

    /**
     * 是否拿到默认用法用量数据
     */
    public boolean isGetDefInfo = false;
    /**
     * 启动此activity
     */
    public static void launch(Context context, DrugBean drugBean,
                              int intentFlag,String commonFlag) {

        Intent intent = new Intent(context,UsageActivityV2.class);
        intent.putExtra(DRUG_INFO,drugBean);
        intent.putExtra(YR_AllMedicineClassActivity.INTER_FLAG,intentFlag);
        intent.putExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION,commonFlag);
        ((Activity)context).startActivityForResult(intent,REQUEST_CODE_USAGE);
    }

    public static void launch(Context context, DrugBean drugBean,
                              int intentFlag) {

        Intent intent = new Intent(context,UsageActivityV2.class);
        intent.putExtra(DRUG_INFO,drugBean);
        intent.putExtra(YR_AllMedicineClassActivity.INTER_FLAG,intentFlag);
        ((Activity)context).startActivityForResult(intent,REQUEST_CODE_USAGE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.sq_actibity_drug_usage);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2018-01-09,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(UsageActivityV2.class);
    }

    /** created by songxin,date：2018-01-09,about：bi,end */

    @Override
    public void onNetRefresh() {
    }

    @Override
    public void initWidgets() {
        sk_id_drug_usage_title = getViewById(R.id.sk_id_drug_usage_title);
        usage_content_sv = getViewById(R.id.usage_content_sv);
        usage_drug_name = getViewById(R.id.usage_drug_name);
        usage_spec = getViewById(R.id.usage_spec);
        usage_general_tv = getViewById(R.id.usage_general_tv);
        usage_consumption_rl = getViewById(R.id.usage_consumption_rl);
        usage_consumption_tv = getViewById(R.id.usage_consumption_tv);
        usage_consumption_sub_iv = getViewById(R.id.usage_consumption_sub_iv);
        usage_consumption_et = getViewById(R.id.usage_consumption_et);
        usage_consumption_add_iv = getViewById(R.id.usage_consumption_add_iv);
        usage_company_rl = getViewById(R.id.usage_company_rl);
        usage_company_tv = getViewById(R.id.usage_company_tv);
        usage_item_rl = getViewById(R.id.usage_item_rl);
        usage_item_tv = getViewById(R.id.usage_item_tv);
        usage_cycle_rl = getViewById(R.id.usage_cycle_rl);
        usage_cycle_tv = getViewById(R.id.usage_cycle_tv);
        usage_num_sub_iv = getViewById(R.id.usage_num_sub_iv);
        usage_num_et = getViewById(R.id.usage_num_et);
        usage_num_add_iv = getViewById(R.id.usage_num_add_iv);
        usage_drug_unit_tv = getViewById(R.id.usage_drug_unit_tv);
        sk_id_usage_xg = getViewById(R.id.sk_id_usage_xg);
        tv_usage_skuLimitInfo_1 = getViewById(R.id.tv_usage_skuLimitInfo_1);
        sk_id_usage_presell = getViewById(R.id.sk_id_usage_presell);
        sk_id_usage_short_iv = getViewById(R.id.sk_id_usage_short_iv);
        tv_usage_skuLimitInfo_2 = getViewById(R.id.tv_usage_skuLimitInfo_2);
        tv_usage_patientLimitInfo = getViewById(R.id.tv_usage_patientLimitInfo);
        tv_cycle_safe_dosage_limit = getViewById(R.id.tv_cycle_safe_dosage_limit);
        tv_num_safe_dosage_limit = getViewById(R.id.tv_num_safe_dosage_limit);
        usage_bakup = getViewById(R.id.usage_bakup);
        usage_save_button = getViewById(R.id.usage_save_button);
        usage_cycle_iv = getViewById(R.id.usage_cycle_iv);
        ll_usage_skuLimitInfo = getViewById(R.id.ll_usage_skuLimitInfo);

        v_bg_anim = getViewById(R.id.v_bg_anim);

        getIntentData();

        getDbData();
        initLimitValue();
        initCheckStockNum();
        requestDefaultUsage();
        setData2Views();

        mUsageDialog = new UsageDialog(this);
    }

    private void getDbData() {
        // 是否包含用法用量详情,如果包含 则不查询数据库
        if(mDrugBean.isContainUsageDetail()){
            usageBean = mDrugBean.getMedicineUsageBean();
            return;
        }
        XLMedicineUseageDosageDAO xlMedicineUseageDosageDAO = new XLMedicineUseageDosageDAO(this, UtilSP.getUserId());
        // 先查询新库
        MedicineUsageBean medicineUsageBean = MedicineUsageBeanDb.getInstance(this,UtilSP.getUserId()).query(mDrugBean.getSkuId());
        // 如果有
        if(medicineUsageBean != null){
            mDrugBean.setContainUsageDetail(true);
            if(mDrugBean.isPatientBuy()) {
                medicineUsageBean.setQuantity(mDrugBean.getMedicineUsageBean().getQuantity());
            }
            mDrugBean.setMedicineUsageBean(medicineUsageBean);

        }else {
            // 若新库没有 则 查询旧库有没有该药物的用法用量
            XCJsonBean beanOld = xlMedicineUseageDosageDAO.getLastUsageDosage(mDrugBean.getId());
            if(beanOld != null){
                mDrugBean.setContainUsageDetail(true);
                // 如果本地有
                mDrugBean = new Parse2DrugBean().parseDBdata2DrugBean(mDrugBean,beanOld);
                updateOldData2NewDBdata();

            }
        }
        usageBean = mDrugBean.getMedicineUsageBean();
    }

    private void getIntentData() {
        mDrugBean = (DrugBean) getIntent().getSerializableExtra(DRUG_INFO);
        try {
            // 患者ID如果取不出来，则认为是常用处方详情的流程，否则为推荐用药流程
            patientId = RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getChatModel().getUserPatient().getPatientId();
        }catch (Exception e){
            e.printStackTrace();
            patientId = "";
        }
    }

    ObjectAnimator objectAnimator;
    private void startAnimator() {
        //背景渐变动画 start
        if(objectAnimator == null) {
            objectAnimator = (ObjectAnimator) AnimatorInflater.loadAnimator(this, R.animator.usage_bg_anim);
            objectAnimator.setTarget(v_bg_anim);
            objectAnimator.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animator) {
                    v_bg_anim.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAnimationEnd(Animator animator) {
                    v_bg_anim.setVisibility(View.INVISIBLE);
                }

                @Override
                public void onAnimationCancel(Animator animator) {

                }

                @Override
                public void onAnimationRepeat(Animator animator) {

                }
            });
        }
        //开始动画
        objectAnimator.start();
        //背景渐变动画 end
    }

    @Override
    public void listeners() {
        usage_company_rl.setOnClickListener(this);
        usage_item_rl.setOnClickListener(this);
        usage_cycle_rl.setOnClickListener(this);
        usage_save_button.setOnClickListener(this);
        usage_consumption_rl.setOnClickListener(this);
        sk_id_usage_presell.setOnClickListener(this);

        mUsageDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {

            }
        });

        mUsageDialog.setOnUsageDialogClickListener(new UsageDialog.OnUsageDialogClickListener() {
            @Override
            public void onCustomClick() {
                toDiyActivity();
            }

            @Override
            public void onSaveClick(String text) {
                saveUsageDialogData(text);
            }

            @Override
            public void onItemClick(String text) {}
        });

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch(v.getId()){

            case R.id.usage_general_tv:
                if(genralFlag){
                    usage_general_tv.setEllipsize(null);
                    usage_general_tv.setMaxLines(1000);
                    genralFlag = false;
                }else {
                    usage_general_tv.setMaxLines(3);
                    usage_general_tv.setEllipsize(TextUtils.TruncateAt.END);
                    genralFlag = true;
                }
                break;

            // 用量布局
            case R.id.usage_consumption_rl:
                tag = UsageDialog.TAG_1;
                textList.clear();
                for (MedicineDosageBean bean: MedicineUsageUtil.getMedicineDosageBeanList()){
                    textList.add(bean.getDosageStr());
                }
                mUsageDialog.getAdapter().checkItem(usage_consumption_tv.getText().toString());
                mUsageDialog.updata(textList);
                mUsageDialog.show();
                break;
            // 单位布局
            case R.id.usage_company_rl :
                tag = UsageDialog.TAG_2;
                textList.clear();
                textList = MedicineUsageUtil.getMedicineUnitList();
                mUsageDialog.getAdapter().checkItem(usage_company_tv.getText().toString());
                mUsageDialog.updata(textList);
                mUsageDialog.show();
                break;
            // 用法布局
            case R.id.usage_item_rl :
                tag = UsageDialog.TAG_3;
                textList.clear();
                for (MedicineDateAndMethodBean bean: MedicineUsageUtil.getMedicineDateAndMethodBeanList()){
                    textList.add(bean.getTakeDate() + bean.getTakeMethod());
                }
                mUsageDialog.getAdapter().checkItem(usage_item_tv.getText().toString());
                mUsageDialog.updata(textList);
                mUsageDialog.show();
                break;
            // 周期布局
            case R.id.usage_cycle_rl :
                tag = UsageDialog.TAG_4;
                textList.clear();
                for (MedicineCycleBean bean: MedicineUsageUtil.getMedicineCycleBeanList()){
                    textList.add(bean.getCycleStr());
                }
                mUsageDialog.getAdapter().checkItem(usage_cycle_tv.getText().toString());
                mUsageDialog.updata(textList);
                mUsageDialog.show();
                break;

            // 保存按钮
            case R.id.usage_save_button :

                String s1 = usage_consumption_tv.getText().toString().trim();
                String s2 = usage_consumption_et.getText().toString().trim();
                String s3 = usage_company_tv.getText().toString().trim();
                String s6 = usage_num_et.getText().toString().trim();

                if(TextUtils.isEmpty(s1)){
                    shortToast("用量不能为空");
                    return;
                }
                if(TextUtils.isEmpty(usageBean.getDosageCycle()) || TextUtils.isEmpty(usageBean.getDosageCount())){
                    shortToast("请补充完整用量信息");
                    return;
                }
                if ("适量".equals(s3)){
                    usageBean.setEachDosageCount("");
                    usageBean.setEachDoseUnit(s3);
                }else if(!TextUtils.isEmpty(s2) && TextUtils.isEmpty(s3)){
                    shortToast("用量单位不能为空");
                    return;
                }else if(TextUtils.isEmpty(s2) && !TextUtils.isEmpty(s3)){
                    shortToast("用量不能为空");
                    return;
                }else if(0 == UtilString.toDouble(s2)){
                    shortToast("用量不能为0");
                    return;
                }else if(!TextUtils.isEmpty(s2) && !TextUtils.isEmpty(s3)){
                    usageBean.setEachDosageCount(s2);
                    usageBean.setEachDoseUnit(s3);
                }
                if(drugCycleContent_tag_1.equals(usage_cycle_tv.getText().toString().trim()) ||
                        drugCycleContent_tag_2.equals(usage_cycle_tv.getText().toString().trim())){
                    usageBean.setDrugCycle("");
                    usageBean.setDrugCycleUnit("");
                }

                if(TextUtils.isEmpty(s6)){
                    shortToast("推荐数量不能为空");
                   return;
                }
                if(UtilSP.isRecomSafe()) {
                    usageBean.setQuantity(s6);
                    requestSafeMedication();
                }else {
                    toSave();
                }

                break;

            // 预售标签
            case R.id.sk_id_usage_presell:
                XCApplication.base_log.shortToast(mDrugBean.getInventoryInfo().getPresellInfo());
                break;

        }
    }

    private void toSave() {
        usageBean.setBakUp(usage_bakup.getText().toString().trim());

        usageBean.setQuantity(usage_num_et.getText().toString().trim());

        String usageStr = usageBean.getDosageStr() + ",";
        if ("适量".equals(usage_company_tv.getText().toString().trim())){
            usageStr = usageStr + "每次适量" + ",";

        }else if(!TextUtils.isEmpty(usageBean.getEachDosageCount()) && !TextUtils.isEmpty(usageBean.getEachDoseUnit())){
            usageStr = usageStr + "每次" + usageBean.getEachDosageCount() + usageBean.getEachDoseUnit() + ",";
        }
        if(TextUtils.isEmpty(usage_item_tv.getText().toString().trim()) || "未选择".equals(usage_item_tv.getText().toString().trim())) {
            usageBean.setUsageTime("");
            usageBean.setUsageMethod("");
        }else {
            usageStr = usageStr + usageBean.getUsageTime() + usageBean.getUsageMethod() + ",";
        }
        if (!TextUtils.isEmpty(usageBean.getDrugCycle()) && !TextUtils.isEmpty(usageBean.getDrugCycleUnit())){
            checkDrugCycleValue();
            if("月".equals(usageBean.getDrugCycleUnit())){
                usageStr = usageStr + usageBean.getDrugCycle() +"个"+ usageBean.getDrugCycleUnit();
            }else {
                usageStr = usageStr + usageBean.getDrugCycle() + usageBean.getDrugCycleUnit();
            }

        }else {
            usageStr = UtilString.getStringWithoutLast(usageStr);
        }

        usageBean.setUsages(usageStr);
        mDrugBean.setPatientBuy(false); // 将自主购药标识置为false
        mDrugBean.setMedicineUsageBean(usageBean);
        mDrugBean.setContainUsageDetail(true);

        // 保存用法用量到库
        MedicineUsageBeanDb.getInstance(this, UtilSP.getUserId()).update(usageBean);

        Intent intent = getIntent();

        // 我的药房 带药箱
        if(0 == intent.getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,-1)){
            intent.putExtra(DRUG_INFO,mDrugBean);
            setResult(Activity.RESULT_OK,intent);
            finish();
        // 我的药房 常用处方详情页
        }else if(1 == intent.getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,-1)){
            CommonPrescriptionsActivity.launch(this,
                    mDrugBean,
                    intent.getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION),
                    intent.getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,0));
            // 推荐用药 带药箱
        }else if(2 == intent.getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,-1)){
            intent.putExtra(DRUG_INFO,mDrugBean);
            setResult(Activity.RESULT_OK,intent);
            finish();
            // 推荐用药 常用处方详情页
        }else if(3 == intent.getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,-1)){
            CommonPrescriptionsActivity.launch(this,mDrugBean,
                    intent.getStringExtra(CommonPrescriptionsActivity.COMMONPRESCRIPTION),
                    intent.getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,3));
            // 推荐用药 处方笺页
        }else if(4 == intent.getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,-1)){

            SQ_RecommendActivity.launch(this,mDrugBean);
        }
    }

    public void saveUsageDialogData(String text){
        int position = mUsageDialog.getCurrentPosition();
        // 未选择任何项的时候为 -1  用量未选择需要单独提示
        if(position < 0 && tag == UsageDialog.TAG_1) {
            shortToast("选择一个用量");
            return;
        }else if((position < 0 && tag == UsageDialog.TAG_2)) {
            shortToast("选择一个单位");
            return;
        }else if((position < 0 && tag == UsageDialog.TAG_3)) {
            shortToast("选择一个用法");
            return;
        }else if((position < 0 && tag == UsageDialog.TAG_4)) {
            shortToast("选择一个周期");
            return;
        }else if(position < 0){
            return;
        }

        // 用量
        if(tag == UsageDialog.TAG_1){

            MedicineDosageBean bean = MedicineUsageUtil.getMedicineDosageBeanList().get(position);
            usageBean.setDosageCount(bean.getFrequency());
            usageBean.setDosageCycle(bean.getDateNumber());
            usageBean.setDosageCycleUnit(bean.getDataUnit());
            usage_consumption_tv.setText(text);
            usageBean.setDosageStr(usage_consumption_tv.getText().toString().trim());
            refreshDrugNum();
        // 次数的单位
        }else if(tag == UsageDialog.TAG_2){
            String dataUnit = MedicineUsageUtil.getMedicineUnitList().get(position);
            usageBean.setEachDoseUnit(dataUnit);
            usage_company_tv.setText(text);
            updateConsumptionState(dataUnit);
            refreshDrugCycle();
            refreshDrugNum();

            // 用法
        }else if(tag == UsageDialog.TAG_3){
            MedicineDateAndMethodBean bean = MedicineUsageUtil.getMedicineDateAndMethodBeanList().get(position);
            usageBean.setUsageTime(bean.getTakeDate());
            usageBean.setUsageMethod(bean.getTakeMethod());
            usage_item_tv.setText(text);
        // 周期
        }else if(tag == UsageDialog.TAG_4){
            MedicineCycleBean bean = MedicineUsageUtil.getMedicineCycleBeanList().get(position);
            usageBean.setDrugCycleUnit(bean.getCycleDateUnit());
            usageBean.setDrugCycle(bean.getDateNumber());
            usage_cycle_tv.setText(text);
            usage_cycle_iv.setVisibility(View.VISIBLE);
            usage_cycle_tv.setTextColor(getResources().getColor(R.color.c_444444));
            usage_cycle_rl.setClickable(true);
            refreshDrugNum();
            startAnimator();
            usage_content_sv.smoothScrollTo(0,2000);
        }
        mUsageDialog.dismiss();
    }

    /**
     * 更新用量次数按钮状态
     * @param dataUnit 单位
     */
    private void updateConsumptionState(String dataUnit) {
        if(dataUnit.equals("适量")){
            usage_consumption_add_iv.setClickable(false);
            usage_consumption_sub_iv.setClickable(false);
            usage_consumption_add_iv.setImageResource(R.mipmap.sk_d_medicine_add4);
            usage_consumption_sub_iv.setImageResource(R.mipmap.sk_d_medicine_sub3);
            usage_consumption_et.setTextColor(getResources().getColor(R.color.c_gray_ececec));
            usage_consumption_et.setFocusable(false);
            usage_consumption_et.setFocusableInTouchMode(false);
        }else if(!usage_consumption_add_iv.isClickable()){
            usage_consumption_add_iv.setClickable(true);
            usage_consumption_add_iv.setImageResource(R.mipmap.sk_d_medicine_add3);
            usage_consumption_sub_iv.setImageResource(R.mipmap.sk_d_medicine_sub2);
            usage_consumption_sub_iv.setClickable(true);
            usage_consumption_et.setTextColor(getResources().getColor(R.color.c_444444));
            usage_consumption_et.setFocusableInTouchMode(true);
            usage_consumption_et.setFocusable(true);
            usage_consumption_et.setSelection(usage_consumption_et.getText().toString().trim().length());
        }
    }

    private void toDiyActivity(){
        Intent intent;
        if(tag == UsageDialog.TAG_1){
            intent = new Intent(this,CustomAmountActivity.class);
            intent.putExtra(UsageDialog.TAG_USAGE_BEAN,usageBean);
            startActivityForResult(intent,UsageDialog.TAG_CUSTOM_1);
        }else if(tag == UsageDialog.TAG_2){
            intent = new Intent(this,CustomUnitActivity.class);
            intent.putExtra(UsageDialog.TAG_USAGE_BEAN,usageBean);
            startActivityForResult(intent,UsageDialog.TAG_CUSTOM_2);
        }else if(tag == UsageDialog.TAG_3){
            intent = new Intent(this,CustomUsageActivity.class);
            intent.putExtra(UsageDialog.TAG_USAGE_BEAN,usageBean);
            startActivityForResult(intent,UsageDialog.TAG_CUSTOM_3);
        }else if(tag == UsageDialog.TAG_4){
            intent = new Intent(this,CustomPeriodActivity.class);
            intent.putExtra(UsageDialog.TAG_USAGE_BEAN,usageBean);
            startActivityForResult(intent,UsageDialog.TAG_CUSTOM_4);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode != Activity.RESULT_OK){
            return;
        }

        tag = requestCode;

        if(requestCode == UsageDialog.TAG_CUSTOM_1){
            usageBean = (MedicineUsageBean)data.getSerializableExtra(UsageDialog.TAG_USAGE_BEAN);
            usageBean.setDosageStr(usageBean.getLocalDosageStr());
            usage_consumption_tv.setText(usageBean.getDosageStr());
            mUsageDialog.dismiss();
            refreshDrugNum();
        }else if(requestCode == UsageDialog.TAG_CUSTOM_2){
            usageBean = (MedicineUsageBean)data.getSerializableExtra(UsageDialog.TAG_USAGE_BEAN);
            usage_company_tv.setText(usageBean.getEachDoseUnit());
            updateConsumptionState(usageBean.getEachDoseUnit());
            mUsageDialog.dismiss();
            refreshDrugCycle();
            refreshDrugNum();
        }else if(requestCode == UsageDialog.TAG_CUSTOM_3){
            usageBean = (MedicineUsageBean)data.getSerializableExtra(UsageDialog.TAG_USAGE_BEAN);
            usage_item_tv.setText( usageBean.getUsageTime() +usageBean.getUsageMethod() );
            mUsageDialog.dismiss();
        }else if(requestCode == UsageDialog.TAG_CUSTOM_4){
            usageBean = (MedicineUsageBean)data.getSerializableExtra(UsageDialog.TAG_USAGE_BEAN);
            mUsageDialog.dismiss();
            // 如果是正整数 去除小数点
            checkDrugCycleValue();
            if("月".equals(usageBean.getDrugCycleUnit())){
                usage_cycle_tv.setText(usageBean.getDrugCycle() + "个" + usageBean.getDrugCycleUnit());
            }else {
                usage_cycle_tv.setText(usageBean.getDrugCycle() + usageBean.getDrugCycleUnit());
            }
            usage_cycle_tv.setTextColor(getResources().getColor(R.color.c_444444));
            usage_cycle_rl.setClickable(true);
            usage_cycle_iv.setVisibility(View.VISIBLE);
            usage_cycle_rl.setClickable(true);
            refreshDrugNum();
            startAnimator();
            usage_content_sv.smoothScrollTo(0,2000);

        }else if(requestCode == SafeMedicationActivity.REQUEST_CODE_SAFE_MEDICATION){
            toSave();
        }

    }

    /**
     * 请求用法用量默认值
     */
    public void requestDefaultUsage(){
        RequestParams params = new RequestParams();
        params.put("skuIds",mDrugBean.getSkuId());

        XCHttpAsyn.postAsyn(this, AppConfig.getHostUrl(AppConfig.getDefaultUsage),params,new XCHttpResponseHandler(){

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean){
                    // 如果没有用法用量
                    if(!mDrugBean.isContainUsageDetail()) {
                        usageBean = new Parse2UsageBean().parseJson(usageBean,result_bean);
                        usage_consumption_tv.setText(usageBean.getDosageStr());
                        usage_consumption_et.setText(usageBean.getEachDosageCount());
                        updateConsumptionState(usageBean.getEachDoseUnit());
                        setData2Views();
                        if(!TextUtils.isEmpty(usageBean.getEachDoseUnit())){
                            usage_company_tv.setText(usageBean.getEachDoseUnit());
                        }else {
                            usage_company_tv.setText("片");
                        }
                    }else {
                        try {
                            XCJsonBean jsonBean = result_bean.getList("data").get(0);
                            usageBean.setPackagSpec(jsonBean.getString("packagSpec"));
                            usageBean.setDefEachDoseUnit(jsonBean.getString("eachDoseUnit"));
                        }catch (Exception e){
                            e.printStackTrace();
                        }

                    }
                }
                isGetDefInfo = true;
                isRefreshDrugCycle = true;
                refreshDrugCycle();

            }
        });

    }

    public void setData2Views(){
        sk_id_drug_usage_title.setTitleCenter(true,"用法用量");
        usage_drug_name.setText(mDrugBean.getRecomName());

        // 默认常规用法
        String usage = mDrugBean.getUsage();
        try {
            Spanned spanned = Html.fromHtml(mDrugBean.getUsage());
            usage = spanned+"";
        }catch (Exception e){
            e.printStackTrace();
        }
        usage_general_tv.setText(usage);
        usage_spec.setText(mDrugBean.getSpec());


        if(TextUtils.isEmpty(usageBean.getDosageCount()) || TextUtils.isEmpty(usageBean.getDosageCycle())){
            // 用量
            usage_consumption_tv.setText("");
        }else {
            // 用量
            usage_consumption_tv.setText(usageBean.getDosageStr());
        }
        // 每次多少
        usage_consumption_et.setText(usageBean.getEachDosageCount());
        usage_company_tv.setText(usageBean.getEachDoseUnit());
        updateConsumptionState(usageBean.getEachDoseUnit());
        // 用法
        if(!TextUtils.isEmpty(usageBean.getUsageTime()) && !TextUtils.isEmpty(usageBean.getUsageMethod())) {
            usage_item_tv.setText(usageBean.getUsageTime() + usageBean.getUsageMethod());
        }else {
            usage_item_tv.setText("");
        }
        if(TextUtils.isEmpty(usageBean.getQuantity())){
            usage_num_et.setText("1");
        }else {
            usage_num_et.setText(usageBean.getQuantity());
        }
        if(TextUtils.isEmpty(usageBean.getQuantityUnit())){
            usage_drug_unit_tv.setText("");
        }else {
            usage_drug_unit_tv.setText(usageBean.getQuantityUnit());
        }
        usage_bakup.setText(usageBean.getBakUp());

    }

    /**
     * 将旧用法用量数据更新到新字段
     */
    public void updateOldData2NewDBdata(){
        usageBean = mDrugBean.getMedicineUsageBean();
        // 将旧数据的字段对应到新字段
        // 几次
        usageBean.setDosageCount(mDrugBean.getEveryDay());
        // 几日
        usageBean.setDosageCycle("1");
        // 日，周，年
        if(!TextUtils.isEmpty(mDrugBean.getCycle()) && mDrugBean.getCycle().length() > 1){
            usageBean.setDosageCycleUnit(mDrugBean.getCycle().substring(1));
        }else if(TextUtils.isEmpty(mDrugBean.getCycle())){
            // 几日
            usageBean.setDosageCycle("");
            usageBean.setDosageCycleUnit(mDrugBean.getCycle());
        }else {
            usageBean.setDosageCycleUnit(mDrugBean.getCycle());
        }
        usageBean.setDosageStr(mDrugBean.getCycle() + mDrugBean.getEveryDay() + "次");
        // 每次多少
        usageBean.setEachDosageCount(mDrugBean.getEveryTime());
        // 单位
        if("选择单位".equals(mDrugBean.getUnit())){
            mDrugBean.setUnit("片");
        }
        usageBean.setEachDoseUnit(mDrugBean.getUnit());
        // 用法
        if("选择用法".equals(mDrugBean.getMethod())){
            mDrugBean.setMethod("");
        }
        if("服用时间".equals(mDrugBean.getUsageTime())){
            mDrugBean.setUsageTime("");
        }
        usageBean.setUsageMethod(mDrugBean.getMethod());
        usageBean.setUsageTime(mDrugBean.getUsageTime());
        // 购买数量,如果不是患者自主购药
        if(!mDrugBean.isPatientBuy()) {
            usageBean.setQuantity(mDrugBean.getCount());
        }
        // 用法用量字符串
        usageBean.setUsages(mDrugBean.getImUsage());
        // 备注
        usageBean.setBakUp(mDrugBean.getNote());

    }

    /**
     * 是否允许请求获取库存接口，false : 允许，true：不允许。默认false
     */
    boolean isRequestGetInventoryInfo = false;
    /**
     * 购买数量编辑框校验库存
     */
    public void initCheckStockNum(){
        usage_num_et.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {

                if ("0".equals(charSequence + "") || "0".equals(charSequence + "") || "000".equals(charSequence + "")) {
                    usage_num_et.setText("1");
                    usage_num_et.setSelection(usage_num_et.getText().toString().trim().length());
                }
                try {
                    // 若超过库存
                    if(!TextUtils.isEmpty(charSequence) && !isRequestGetInventoryInfo){
                        requestGetInventoryInfo();
                    }else {
                        isRequestGetInventoryInfo = false;
                        sk_id_usage_short_iv.setVisibility(View.GONE);
                    }
                }catch (Exception  e){e.printStackTrace();}
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(!isRefreshDrugCycle){
                    isRefreshDrugCycle = true;
                    showSafeHint();
                    return;
                }
                if (!usageBean.getQuantity().equals(editable + "") &&
                        !drugCycleContent_tag_2.equals(usage_cycle_tv.getText())) {

                    usage_cycle_tv.setText(drugCycleContent_tag_1);
                    usage_cycle_tv.setTextColor(getResources().getColor(R.color.c_gray_aaaaaa));
                    usageBean.setDrugCycleUnit("");
                    usageBean.setDrugCycle("");
                }
                showSafeHint();
            }
        });
        usage_cycle_tv.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(drugCycleContent_tag_1.equals(usage_cycle_tv.getText().toString().trim())
                        ||drugCycleContent_tag_2.equals(usage_cycle_tv.getText().toString().trim())){
                    showSafeHint();
                }
            }
        });
    }

    /**
     * 请求查询库存信息
     */
    public void requestGetInventoryInfo(){
        // 若患者ID为空 代表是常用处方详情的流程，不请求库存信息
        if(TextUtils.isEmpty(patientId)) return;

        String skuId = mDrugBean.getSkuId() + "";
        final String num = usage_num_et.getText().toString();

        RequestParams params = new RequestParams();
        params.put("patientId",patientId);
        params.put("skuIds",skuId);
        params.put("nums",num);

        XCHttpAsyn.postAsyn(false,this, AppConfig.getHostUrl(AppConfig.inventory_info),params,new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean && context != null){
                    Parse2InventoryInfo parse2InventoryInfo = new Parse2InventoryInfo();
                    List<InventoryInfo> list = parse2InventoryInfo.parse(result_bean);
                    try {
                        mDrugBean.getInventoryInfo().setStockNum(list.get(0).getStockNum());
                        mDrugBean.getInventoryInfo().setIsPresell(list.get(0).getIsPresell());
                        mDrugBean.getInventoryInfo().setIsShort(list.get(0).getIsShort());
                        mDrugBean.getInventoryInfo().setPresellInfo(list.get(0).getPresellInfo());
                        mDrugBean.getInventoryInfo().setIslimit(list.get(0).getIslimit());
                        mDrugBean.getInventoryInfo().setPatientLimitInfo(list.get(0).getPatientLimitInfo());
                        mDrugBean.getInventoryInfo().setSkuLimitInfo(list.get(0).getSkuLimitInfo());
                        mDrugBean.setDosageWeek(list.get(0).getDosageWeek());
                        mDrugBean.setDosageMonth(list.get(0).getDosageMonth());
                        mDrugBean.setSixtyDosage(list.get(0).getSixtyDosage());
                        initInventoryInfo(mDrugBean,usage_num_et.getText().toString());
                    }catch (Exception e){e.printStackTrace();}
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(context,
                        getCode(),
                        getMsg())) {
                }
            }
        });
    }

    /**
     * 初始化库存信息
     * @param bean 药品model
     * @param columns_count 购买数量
     */
    private void initInventoryInfo(DrugBean bean, String columns_count) {
        tv_usage_skuLimitInfo_1.setText(bean.getInventoryInfo().getSkuLimitInfo());
        tv_usage_skuLimitInfo_2.setText(bean.getInventoryInfo().getSkuLimitInfo());
        tv_usage_patientLimitInfo.setText(bean.getInventoryInfo().getPatientLimitInfo());

        // 是否预售,1 是  0 否
        String isPresell = bean.getInventoryInfo().getIsPresell();
        if("1".equals(isPresell)) {
            sk_id_usage_presell.setVisibility(View.VISIBLE);
            ll_usage_skuLimitInfo.setVisibility(View.VISIBLE);
        }else {
            sk_id_usage_presell.setVisibility(View.GONE);
        }

        try {
            int countInt = Integer.parseInt(columns_count);
            int stockNum = Integer.parseInt(bean.getInventoryInfo().getStockNum()); // 库存数量
            boolean isLimit = "1".equals(bean.getInventoryInfo().getIslimit()); // 是否限购
            if(countInt > stockNum && !"1".equals(isPresell)){
                sk_id_usage_short_iv.setVisibility(View.VISIBLE);
                ll_usage_skuLimitInfo.setVisibility(View.VISIBLE);
                setLimitView(isLimit,tv_usage_skuLimitInfo_1);

            }else if(countInt < stockNum && !"1".equals(isPresell)){
                sk_id_usage_short_iv.setVisibility(View.GONE);
                setLimitView(isLimit,tv_usage_skuLimitInfo_2);

            }else{
                sk_id_usage_short_iv.setVisibility(View.GONE);
                setLimitView(isLimit,tv_usage_skuLimitInfo_1);
            }

            if(countInt < stockNum && !"1".equals(isPresell) && !isLimit){
                ll_usage_skuLimitInfo.setVisibility(View.GONE);
            }

        }catch (Exception e){e.printStackTrace();}

    }

    /**
     * 设置限购view的显示隐藏逻辑
     * @param isLimit 是否限购
     * @param hideView 需要隐藏的view
     */
    private void setLimitView(boolean isLimit,View hideView){
        // 限购标签
        if(isLimit){
            sk_id_usage_xg.setVisibility(View.VISIBLE);
            ll_usage_skuLimitInfo.setVisibility(View.VISIBLE);
        }else {
            sk_id_usage_xg.setVisibility(View.GONE);
        }
        // 限购文案
        if("".equals(tv_usage_skuLimitInfo_1.getText().toString())){
            tv_usage_skuLimitInfo_1.setVisibility(View.GONE);
            tv_usage_skuLimitInfo_2.setVisibility(View.GONE);
        }else {
            tv_usage_skuLimitInfo_1.setVisibility(View.VISIBLE);
            tv_usage_skuLimitInfo_2.setVisibility(View.VISIBLE);
            hideView.setVisibility(View.GONE);
        }
        // 患者限购文案
        if("".equals(tv_usage_patientLimitInfo.getText().toString())){
            tv_usage_patientLimitInfo.setVisibility(View.GONE);
        }else {
            tv_usage_patientLimitInfo.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 设置加号监听
     * @param view 加号view “ + ”
     * @param maxNum 最大值
     * @param isDecimal 是否有小数点 (true:是,false:否)
     */
    public void setNumAddClick(View view,final int maxNum,EditText editText,boolean isDecimal){
        int maxLength = (maxNum + "").length();
        if(isDecimal){
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength + 3)});
        }else {
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        }
        View.OnClickListener numAdd;
        numAdd = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText = (EditText)v.getTag();

                String tempNum = editText.getText().toString().trim();

                // 小数点
                String dot = ".";
                // 小数点后面的数字
                String floatStr = "";
                if(UtilString.isBlank(tempNum)){
                    tempNum = "0";
                }

                try {
                    double aDouble = Double.parseDouble(tempNum);
                }catch (Exception e){
                    e.printStackTrace();
                    return;
                }

                // 检查是否包含小数点 true = 包含
                if(tempNum.contains(dot)){
                    // 保存小数点后面的数字
                    floatStr = tempNum.substring(tempNum.lastIndexOf(dot),tempNum.length());

                    if(tempNum.lastIndexOf(dot) == 0){
                        // 如果小数点在第一位 数字设为 0
                        tempNum = "0";
                    }else{
                        // 否则数字设为小数点前的数字
                        tempNum = tempNum.substring(0 , tempNum.lastIndexOf(dot));
                    }
                }

                int num = parseInt(tempNum);
                if( num < maxNum ){
                    num = num + 1;
                }
                // 结果等于整数
                String numStr = num + "";

                if(num == maxNum){ // 如果整数等于最大值
                    numStr = num + "";
                }

                editText.setText(numStr +floatStr);
                editText.setSelection(editText.getText().toString().trim().length());
            }
        };
        view.setOnClickListener(numAdd);
    }

    /**
     * 设置减号监听
     * @param view 减号view “ — ”
     */
    public void setNumSubClick(View view,final int minNumber){
        View.OnClickListener numSub;
        final int stockNum = UtilString.toInt(mDrugBean.getStockNum());
        numSub = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText = (EditText)v.getTag();
                String tempNum = editText.getText().toString().trim();
                String dot = ".";       // 小数点
                String floatStr = "";   // 小数点后面的数字
                String result = "";

                try {
                    double aDouble = Double.parseDouble(tempNum);
                }catch (Exception e){
                    e.printStackTrace();
                    return;
                }

                int minNum = minNumber;
                if(UtilString.isBlank(tempNum)){
                    return;
                }

                // 检查是否包含小数点 true = 包含
                if(tempNum.contains(dot)){
                    // 保存小数点后面的数字
                    floatStr = tempNum.substring(tempNum.lastIndexOf(dot),tempNum.length());
                    if(tempNum.lastIndexOf(dot) == 0){
                        // 如果小数点在第一位 数字设为最小值
                        tempNum = "" + minNum;
                    }else{
                        // 否则数字设为小数点前的数字
                        tempNum = tempNum.substring(0 , tempNum.lastIndexOf(dot));
                    }

                }

                int num = parseInt(tempNum);
                if( num > minNum ){
                    result = (num - 1) + "";
                }else {
                    result = num + "";
                }
                // 若当前是购买数量减号，并且不为空，并且数量等于库存数量
                if(editText == usage_num_et && !TextUtils.isEmpty(result) && Integer.parseInt(result) < stockNum){
                    isRequestGetInventoryInfo = true;
                }

                editText.setText(result + floatStr);
                editText.setSelection( editText.getText().toString().trim().length() );
            }
        };
        view.setOnClickListener( numSub );
    }


    /**
     * 设置极限值配置
     */
    private void initLimitValue(){
        // 购买数量 设置最大值
        int buyMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.RECOM_NUM,0,999);
        setNumAddClick(usage_num_add_iv,buyMax,usage_num_et,false);
        usage_num_add_iv.setTag(usage_num_et);
        usage_num_sub_iv.setTag(usage_num_et);
        // 购买数量 设置最小值
        int buyMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.RECOM_NUM,1,1);
        setNumSubClick(usage_num_sub_iv,buyMin);

        // 每次用量 设置最大值
        final int oneMax = GlobalConfigSP.getLimitValue(GlobalConfigSP.RECOM_USAGE,0,999);
        usage_consumption_add_iv.setTag(usage_consumption_et);
        usage_consumption_sub_iv.setTag(usage_consumption_et);
        setNumAddClick(usage_consumption_add_iv,oneMax,usage_consumption_et,true);

        // 每次用量 设置最小值
        final int oneMin = GlobalConfigSP.getLimitValue(GlobalConfigSP.RECOM_USAGE,1,0);
        setNumSubClick(usage_consumption_sub_iv,oneMin);

        // 备注最大字数
        usage_bakup.setFilters(new InputFilter[]{new InputFilter.LengthFilter(GlobalConfigSP.getLimitValue(GlobalConfigSP.RECOM_REMARK,0,999))});

        // 每次用量编辑框
        usage_consumption_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String temp = s + "";
                String dot = ".";

                //如果"."在起始位置,则起始位置自动补最小值
                if (temp.trim().substring(0).equals(dot)) {
                    temp = "" + oneMin + temp;
                    usage_consumption_et.setText(temp);
                    usage_consumption_et.setSelection(usage_consumption_et.getText().length());
                }

                //// 如果输入的是 "999."
                //if(temp.equals(oneMax + dot)){
                //    temp = oneMax + "";
                //    usage_consumption_et.setText(temp);
                //    usage_consumption_et.setSelection(usage_consumption_et.getText().length());
                //}
                //// 如果前三位是最大值
                //if(temp.length() > 3 && temp.substring(0,3).equals(""+oneMax)){
                //    temp = oneMax + "";
                //    usage_consumption_et.setText(temp);
                //    usage_consumption_et.setSelection(usage_consumption_et.getText().length());
                //}

                if (!temp.contains(dot) && temp.length() > 3) {
                    //  如果不包含小数点，并且长度大于三位
                    usage_consumption_et.setText(temp.substring(0,temp.length() - 1));
                    usage_consumption_et.setSelection(usage_consumption_et.getText().length());
                }else if(temp.contains(dot)){
                    //如果包含小数点  删除“.”后面超过2位后的数据
                    if (temp.length() - 1 - temp.indexOf(dot) > 2) {
                        s = temp.subSequence(0,
                                temp.indexOf(dot) + 3);
                        usage_consumption_et.setText(s);
                        usage_consumption_et.setSelection(usage_consumption_et.getText().length()); //光标移到最后
                    }

                }
                if(isFirstTimeChangeNum){
                    isFirstTimeChangeNum = false;
                }else {
                    isRefreshDrugCycle = false;
                }

            }

            @Override
            public void afterTextChanged(Editable s) {
                refreshDrugNum();
            }
        });
    }

    /**
     * 更新药品购买数量，根据用法用量计算
     */
    public void refreshDrugNum() {
        // 不做计算
        if(TextUtils.isEmpty(usageBean.getDosageCount())) return;
        if(0 == UtilString.toDouble(usageBean.getDosageCount())) return;
        if(drugCycleContent_tag_2.equals(usage_cycle_tv.getText())) return;
        if(drugCycleContent_tag_1.equals(usage_cycle_tv.getText())) return;

        try {
            // 疗效天数
            double num1 = 0;
            for (MedicineCycleUnitBean bean : MedicineUsageUtil.getMedicineCycleUnitBeanList()) {
                if (usageBean.getDrugCycleUnit().equals(bean.getCycleDateUnit())) {
                    num1 = UtilNum.mul(UtilString.toDouble(usageBean.getDrugCycle()), UtilString.toDouble(bean.getBaseNumber()));
                    break;
                }
            }

            // 最小包装规格 ／ 每次服用数量 ／ 次数周期
            double num2 = 0;
            usageBean.setEachDosageCount(usage_consumption_et.getText().toString().trim());

            num2 = UtilNum.div(UtilString.toDouble(usageBean.getPackagSpec()), UtilString.toDouble(usageBean.getEachDosageCount()), 5);
            num2 = UtilNum.div(num2, UtilString.toDouble(usageBean.getDosageCount()), 5);

            // 单位周期计算数
            double num3 = 0;
            for (MedicineDateUnitBean bean : MedicineUsageUtil.getMedicineDateUnitList()) {
                if (usageBean.getDosageCycleUnit().equals(bean.getDateUnit())) {
                    num3 = UtilNum.mul(UtilString.toDouble(usageBean.getDosageCycle()), UtilString.toDouble(bean.getMolecule()));
                    num3 = UtilNum.div(num3, UtilString.toDouble(bean.getDenominator()), 5);
                    break;
                }
            }

            double sum = Math.ceil( UtilNum.div(num1,UtilNum.mul(num2,num3),5));
            if(sum > 999) sum = 999;
            String sumStr = String.valueOf(sum);
            usageBean.setQuantity(sumStr.substring(0,sumStr.indexOf(".")));
            usage_num_et.setText(usageBean.getQuantity());

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void refreshDrugCycle() {

        if("适量".equals(usageBean.getEachDoseUnit())){

            usage_cycle_tv.setText(drugCycleContent_tag_2);
        }else if(!usageBean.getEachDoseUnit().equals(usageBean.getDefEachDoseUnit())
                || TextUtils.isEmpty(usageBean.getDefEachDoseUnit())
                ){

            usage_cycle_tv.setText(drugCycleContent_tag_2);
        }else if(TextUtils.isEmpty(usageBean.getDrugCycle()) || TextUtils.isEmpty(usageBean.getDrugCycleUnit()) ){

            usage_cycle_tv.setText(drugCycleContent_tag_1);

        }else if(!TextUtils.isEmpty(usageBean.getDrugCycle()) && !TextUtils.isEmpty(usageBean.getDrugCycleUnit())
                && isGetDefInfo && isRefreshDrugCycle){
            // 如果是正整数 并且有小数 去除小数点
            checkDrugCycleValue();
            if("月".equals(usageBean.getDrugCycleUnit())){
                usage_cycle_tv.setText(usageBean.getDrugCycle() + "个" + usageBean.getDrugCycleUnit());
            }else {
                usage_cycle_tv.setText(usageBean.getDrugCycle() + usageBean.getDrugCycleUnit());
            }
        }else {
            usage_cycle_tv.setText(drugCycleContent_tag_1);

        }


        if(drugCycleContent_tag_2.equals(usage_cycle_tv.getText().toString().trim())){
            usage_cycle_iv.setVisibility(View.GONE);
            usage_cycle_tv.setTextColor(getResources().getColor(R.color.c_gray_aaaaaa));
            usage_cycle_rl.setClickable(false);
        }else if(drugCycleContent_tag_1.equals(usage_cycle_tv.getText().toString().trim())){
            usage_cycle_iv.setVisibility(View.VISIBLE);
            usage_cycle_tv.setTextColor(getResources().getColor(R.color.c_gray_aaaaaa));
            usage_cycle_rl.setClickable(true);
        }else {
            usage_cycle_iv.setVisibility(View.VISIBLE);
            usage_cycle_tv.setTextColor(getResources().getColor(R.color.c_444444));
            usage_cycle_rl.setClickable(true);
        }
    }

    /**
     * 去掉正整数时的小数点
     */
    private void checkDrugCycleValue() {
        try {
            String drugCycle = usageBean.getDrugCycle();
            if (drugCycle.contains(".")) {
                drugCycle = drugCycle.substring(0, drugCycle.indexOf("."));
                if (UtilString.toInt(drugCycle) == UtilString.toDouble(usageBean.getDrugCycle())) {
                    usageBean.setDrugCycle(drugCycle + "");
                }
            }
        }catch (Exception e){e.printStackTrace();}
    }

    /**
     * 安全用量提示
     */
    public void showSafeHint(){
        if(UtilSP.isRecomSafe()){
            String hint = "";
            int num = UtilString.toInt(usage_num_et.getText().toString().trim(), 0);
            if(mDrugBean.getSixtyDosage()>0 && num >mDrugBean.getSixtyDosage()){
                hint = "禁止：超出安全用药用量上限(上限2个月)";
                tv_cycle_safe_dosage_limit.setTextColor(getResources().getColor(R.color.c_e2231a));
                tv_num_safe_dosage_limit.setTextColor(getResources().getColor(R.color.c_e2231a));
            }else if(mDrugBean.getDosageMonth()>0 && num >mDrugBean.getDosageMonth()){
                hint = "谨慎：当前药品用量大于30天用量";
                tv_cycle_safe_dosage_limit.setTextColor(getResources().getColor(R.color.c_f5a623));
                tv_num_safe_dosage_limit.setTextColor(getResources().getColor(R.color.c_f5a623));
            }else if(mDrugBean.getDosageWeek()>0 && num >mDrugBean.getDosageWeek()){
                hint = "谨慎：当前药品用量大于7天用量";
                tv_cycle_safe_dosage_limit.setTextColor(getResources().getColor(R.color.c_f5a623));
                tv_num_safe_dosage_limit.setTextColor(getResources().getColor(R.color.c_f5a623));
            }else {
                tv_cycle_safe_dosage_limit.setVisibility(View.GONE);
                tv_num_safe_dosage_limit.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(hint)){
                if(drugCycleContent_tag_1.equals(usage_cycle_tv.getText().toString().trim())
                        ||drugCycleContent_tag_2.equals(usage_cycle_tv.getText().toString().trim())){
                    tv_cycle_safe_dosage_limit.setVisibility(View.GONE);
                    tv_num_safe_dosage_limit.setVisibility(View.VISIBLE);
                    tv_num_safe_dosage_limit.setText(hint);
                }else {
                    tv_num_safe_dosage_limit.setVisibility(View.GONE);
                    tv_cycle_safe_dosage_limit.setVisibility(View.VISIBLE);
                    tv_cycle_safe_dosage_limit.setText(hint);
                }
            }
        }
    }

    /**
     * 新版用药安全提醒
     */
    public void requestSafeMedication(){

        JSONObject jsonObject = createJson();

        XCHttpAsyn.postAsync(true,this,AppConfig.getTuijianUrl(AppConfig.recomCheck+ "?doctorId="+UtilSP.getUserId()+
                "&token="+UtilSP.getUserToken()),jsonObject.toString(),new XCHttpResponseHandler(){
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if(result_boolean && context != null){
                    try {
                        Parse2SafeMedication parse2SafeMedication = new Parse2SafeMedication();
                        SafeMedicationBean safeMedicationBean = parse2SafeMedication.parse(result_bean.getList("data").get(0));
                        if("3".equals(safeMedicationBean.getSafeStatus())){ // 通过
                            toSave();
                        }else if("2".equals(safeMedicationBean.getSafeStatus())){ // 谨慎
                            // 若两次提醒一致
                            if(safeMedicationBean.getSn().equals(RecomMedicineHelper.getInstance().getXC_patientDrugInfo().getSn())){
                                toSave();
                                return;
                            }
                            safeMedicationBean.setBtnTextTag(1);
                            RecomMedicineHelper.getInstance().getXC_patientDrugInfo().setSn(safeMedicationBean.getSn());
                            SafeMedicationActivity.launch(UsageActivityV2.this,safeMedicationBean);
                        }else if("1".equals(safeMedicationBean.getSafeStatus())){ // 禁用
                            safeMedicationBean.setBtnTextTag(1);
                            SafeMedicationActivity.launch(UsageActivityV2.this,safeMedicationBean);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                GeneralReqExceptionProcess.checkCode(context,getCode(),getMsg());
            }
        });
    }

    /**
     * 组建save接口请求json，提交给服务器
     */
    private JSONObject createJson() {

        JSONObject data = new JSONObject();
        try {
            XC_PatientDrugInfo patientDrugInfo = RecomMedicineHelper.getInstance().getXC_patientDrugInfo();
            // 病历
            data.put("patientAge", patientDrugInfo.getRecommendInfo().getPatientAge());
            data.put("patientAgeUnit", patientDrugInfo.getRecommendInfo().getPatientAgeUnit());
            data.put("patientGender", patientDrugInfo.getRecommendInfo().getPatientGender());

            JSONArray diagnosis = new JSONArray();
            for (DiagnoseBean bean : patientDrugInfo.getDiagnoseBeanList()) {
                diagnosis.put(bean.name);
            }
            data.put("diagnosis", diagnosis);
            JSONArray skuIds = new JSONArray();
            // 进入页面的标记
            int flag = getIntent().getIntExtra(YR_AllMedicineClassActivity.INTER_FLAG,-1);
            JSONArray recomSafeItems = new JSONArray();
            JSONObject drugItem;
            boolean isContain = false;
            //  0、1、3：保存到常用处方
            if(0 == flag || 1 == flag || 3 == flag){
                for (DrugBean item :  RecomMedicineHelper.getInstance().getCommonRecipe().getDrugBeans()) {
                    skuIds.put(item.getSkuId());
                    drugItem = new JSONObject();
                    drugItem.put("commonName",item.getCommonName());
                    drugItem.put("productName", item.getName());
                    drugItem.put("recomName", item.getRecomName());
                    drugItem.put("quantity",item.getMedicineUsageBean().getQuantity());
                    drugItem.put("skuId",item.getMedicineUsageBean().getSkuId());
                    recomSafeItems.put(drugItem);
                    if(usageBean.getSkuId().equals(item.getSkuId())){
                        isContain = true;
                        drugItem.put("quantity",usageBean.getQuantity());
                    }

                }
            }else { //  保存到推荐用药列表
                for (DrugBean item : patientDrugInfo.getRecommendInfo().getDrugInfoBean()) {
                    drugItem = new JSONObject();
                    drugItem.put("commonName",item.getCommonName());
                    drugItem.put("productName", item.getName());
                    drugItem.put("quantity",item.getMedicineUsageBean().getQuantity());
                    drugItem.put("skuId",item.getMedicineUsageBean().getSkuId());
                    recomSafeItems.put(drugItem);
                    skuIds.put(item.getSkuId());
                    if(usageBean.getSkuId().equals(item.getSkuId())){
                        isContain = true;
                        drugItem.put("quantity",usageBean.getQuantity());
                    }
                }
            }

            if(!isContain) {
                skuIds.put(usageBean.getSkuId());
                drugItem = new JSONObject();
                drugItem.put("commonName",mDrugBean.getCommonName());
                drugItem.put("productName", mDrugBean.getName());
                drugItem.put("quantity",usageBean.getQuantity());
                drugItem.put("skuId",usageBean.getSkuId());
                recomSafeItems.put(drugItem);
            }
            data.put("recomSafeItems", recomSafeItems);
            data.put("skuIds", skuIds);

            if(null == patientDrugInfo.getChatModel()){
                return data;
            }
            UserPatient userPatient = patientDrugInfo.getChatModel().getUserPatient();
            data.put("patientId", userPatient.getPatientId());

            DrRecordVOBean drRecordVOBean = patientDrugInfo.getDrRecordVOBean();
            if(drRecordVOBean == null) {
                return data;
            }

            DrCaseVOBean mDrCaseVOBean = (DrCaseVOBean) drRecordVOBean.getMdicalRecordVO();
            if(mDrCaseVOBean != null){
                data.put("mainComplaint",mDrCaseVOBean.getMainComplaint());
                data.put("presentDisease",mDrCaseVOBean.getPresentDisease());
            }

            List<DrugBean> drugBeans = patientDrugInfo.getList();
            for (DrugBean item : drugBeans){

            }

        } catch (Exception e) {
            e.printStackTrace();
            XCApplication.base_log.debugShortToast("创建json异常");
        }
        return data;

    }



}
