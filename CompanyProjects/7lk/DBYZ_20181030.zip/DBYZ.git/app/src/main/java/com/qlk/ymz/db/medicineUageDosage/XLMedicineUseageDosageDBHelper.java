package com.qlk.ymz.db.medicineUageDosage;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import com.qlk.ymz.application.DBApplication;
import com.xiaocoder.android.fw.general.application.XCConfig;
import com.xiaocoder.android.fw.general.util.UtilString;

/**
 * @author xilinch on 2015/10/23.
 * @version 1.2.0
 * @modifier xilinch 2015/10/23.
 * @description
 */
public class XLMedicineUseageDosageDBHelper extends SQLiteOpenHelper {
    /**
     * 删除表SQL脚本
     */
    private String drop_script;
    /**
     * 创建表SQLL脚本
     */
    private String create_script;

    public XLMedicineUseageDosageDBHelper(Context context, String dbName, int version, String drop_script, String create_script) {

        super(context, dbName, null, version);

        this.create_script = create_script;
        this.drop_script = drop_script;
        if (UtilString.isBlank(dbName)) {
            throw new RuntimeException("数据库名不能为空");
        }

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        if (!TextUtils.isEmpty(create_script)) {

            db.execSQL(create_script);

        } else {
            DBApplication.base_log.e(XCConfig.TAG_SYSTEM_OUT,
                    XLMedicineUseageDosageDBHelper.class.getSimpleName()
                            + " 创建数据SQL为空!","medicinedb.txt"
                    + " create_script:" + create_script,true);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //edit by xilinch on 20160317
        if (!TextUtils.isEmpty(create_script) && !TextUtils.isEmpty(drop_script)) {

            db.execSQL(drop_script);
            db.execSQL(create_script);

        } else {
            DBApplication.base_log.e(XCConfig.TAG_SYSTEM_OUT,
                    XLMedicineUseageDosageDBHelper.class.getSimpleName()
                    + " 创建数据SQL为空!"
                    + " create_script:" + create_script
                    + " drop_script:" + drop_script, "medicinedb.txt",true);
        }


    }
}
