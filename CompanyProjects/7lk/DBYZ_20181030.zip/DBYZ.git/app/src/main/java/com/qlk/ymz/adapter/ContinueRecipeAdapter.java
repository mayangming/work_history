package com.qlk.ymz.adapter;

import android.content.Context;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qlk.ymz.R;
import com.qlk.ymz.model.DrugBean;
import com.qlk.ymz.model.RecipeBean;
import com.qlk.ymz.util.CommonConfig;
import com.qlk.ymz.view.SwipeLayout.PullSwipeLayoutAdapter;
import com.qlk.ymz.view.SwipeLayout.SwipeOnTouchListener;
import com.qlk.ymz.view.SwipeLayout.SwipeViewHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiedong on 2017/12/14.
 */

public class ContinueRecipeAdapter extends PullSwipeLayoutAdapter<RecipeBean> {

    private ContinueRecipeActionListener mContinueRecipeActionListener;
    /**
     * 构造函数
     *
     * @param context
     * @param contentViewResourceId
     * @param actionViewResourceId
     * @param itemWidth
     * @param contentWidth
     * @param list
     */
    public ContinueRecipeAdapter(Context context, int contentViewResourceId, int actionViewResourceId, int itemWidth, int contentWidth, List<RecipeBean> list) {
        super(context, contentViewResourceId, actionViewResourceId, itemWidth, contentWidth, list);
    }


    @Override
    public void setContentView(View contentView, final int position, HorizontalScrollView parent, SwipeViewHolder holder, SwipeOnTouchListener swipeOnTouchListener) {
        ContentViewHolder viewHolder = ContentViewHolder.getViewHolder(contentView);
        RecipeBean recipeBean = list.get(position);//处方信息
        viewHolder.tv_patient_name.setText("姓名: "+recipeBean.getPatientName());
        if(CommonConfig.GENDER_FEMALE.equals(recipeBean.getPatientGender())){
            viewHolder.tv_patient_gender.setText("女");
        }else if(CommonConfig.GENDER_MALE.equals(recipeBean.getPatientGender())){
            viewHolder.tv_patient_gender.setText("男");
        }
        viewHolder.tv_patient_diagnosis.setText("临床诊断: "+recipeBean.getDiagnosis());
        viewHolder.tv_recipe_time.setText(recipeBean.getRecomTime());
        ArrayList<DrugBean> drugInfoBeans = recipeBean.getDrugBeans();
        viewHolder.tv_first_medicine_name.setText(drugInfoBeans.get(0).getRecomName());
        viewHolder.tv_first_medicine_num.setText("×"+drugInfoBeans.get(0).getQuantity());
        viewHolder.tv_first_use.setText("用法: "+drugInfoBeans.get(0).getImUsage());
        if(drugInfoBeans.size()<2){
            viewHolder.ll_second_medicine.setVisibility(View.GONE);
            viewHolder.tv_second_use.setVisibility(View.GONE);
            viewHolder.tv_ellipsis.setVisibility(View.GONE);
        }else if(drugInfoBeans.size()==2){
            viewHolder.ll_second_medicine.setVisibility(View.VISIBLE);
            viewHolder.tv_second_use.setVisibility(View.VISIBLE);
            viewHolder.tv_second_medicine_name.setText(drugInfoBeans.get(1).getRecomName());
            viewHolder.tv_second_medicine_num.setText("×"+drugInfoBeans.get(1).getQuantity());
            viewHolder.tv_second_use.setText("用法: "+drugInfoBeans.get(1).getImUsage());
            viewHolder.tv_ellipsis.setVisibility(View.GONE);
        }else if(drugInfoBeans.size()>2){
            viewHolder.ll_second_medicine.setVisibility(View.VISIBLE);
            viewHolder.tv_second_use.setVisibility(View.VISIBLE);
            viewHolder.tv_second_medicine_name.setText(drugInfoBeans.get(1).getRecomName());
            viewHolder.tv_second_medicine_num.setText("×"+drugInfoBeans.get(1).getQuantity());
            viewHolder.tv_second_use.setText("用法: "+drugInfoBeans.get(1).getImUsage());
            viewHolder.tv_ellipsis.setVisibility(View.VISIBLE);
        }
        viewHolder.tv_continue_recipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mContinueRecipeActionListener!=null){
                    mContinueRecipeActionListener.continueRecipe(position);
                }
            }
        });
        viewHolder.ll_continue_recipe_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mContinueRecipeActionListener!=null){
                    mContinueRecipeActionListener.onItemClick(position);
                }
            }
        });
    }

    @Override
    public void setActionView(View actionView, final int position, HorizontalScrollView parent) {
        ActionViewHolder viewHolder = ActionViewHolder.getViewHolder(actionView);
        viewHolder.tv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mContinueRecipeActionListener!=null){
                    mContinueRecipeActionListener.delete(position);
                }
            }
        });
    }

    /**
     * 设置删除和续方监听
     * @param continueRecipeActionListener
     */
    public void setContinueRecipeActionListener(ContinueRecipeActionListener continueRecipeActionListener) {
        mContinueRecipeActionListener = continueRecipeActionListener;
    }

    static class ActionViewHolder{
        //删除
        TextView tv_delete;
        public ActionViewHolder(View convertView) {
            tv_delete = (TextView) convertView.findViewById(R.id.tv_delete);
        }

        public static ActionViewHolder getViewHolder(View convertview) {
            ActionViewHolder holder = (ActionViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new ActionViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }

    public interface ContinueRecipeActionListener{
        void delete(int position);
        void continueRecipe(int position);
        void onItemClick(int position);
    }
    static class ContentViewHolder {
        //整个item
        LinearLayout ll_continue_recipe_item;
        //患者姓名
        TextView tv_patient_name;
        //患者性别
        TextView tv_patient_gender;
        //临床诊断
        TextView tv_patient_diagnosis;
        //诊断时间
        TextView tv_recipe_time;
        //第一个药名
        TextView tv_first_medicine_name;
        //第一个药数量
        TextView tv_first_medicine_num;
        //第一个用法
        TextView tv_first_use;
        //第二个药
        LinearLayout ll_second_medicine;
        //第二个药名
        TextView tv_second_medicine_name;
        //第二个药数量
        TextView tv_second_medicine_num;
        //第二个用法
        TextView tv_second_use;
        //省略号
        TextView tv_ellipsis;
        //续方
        TextView tv_continue_recipe;


        public ContentViewHolder(View convertView) {
            ll_continue_recipe_item = (LinearLayout) convertView.findViewById(R.id.ll_continue_recipe_item);
            tv_patient_name = (TextView) convertView.findViewById(R.id.tv_patient_name);
            tv_patient_gender = (TextView) convertView.findViewById(R.id.tv_patient_gender);
            tv_patient_diagnosis = (TextView) convertView.findViewById(R.id.tv_patient_diagnosis);
            tv_recipe_time = (TextView) convertView.findViewById(R.id.tv_recipe_time);
            tv_first_medicine_name = (TextView) convertView.findViewById(R.id.tv_first_medicine_name);
            tv_first_use = (TextView) convertView.findViewById(R.id.tv_first_use);
            tv_first_medicine_num = (TextView) convertView.findViewById(R.id.tv_first_medicine_num);
            ll_second_medicine = (LinearLayout) convertView.findViewById(R.id.ll_second_medicine);
            tv_second_medicine_name = (TextView) convertView.findViewById(R.id.tv_second_medicine_name);
            tv_second_medicine_num = (TextView) convertView.findViewById(R.id.tv_second_medicine_num);
            tv_second_use = (TextView) convertView.findViewById(R.id.tv_second_use);
            tv_ellipsis = (TextView) convertView.findViewById(R.id.tv_ellipsis);
            tv_continue_recipe = (TextView) convertView.findViewById(R.id.tv_continue_recipe);
        }

        public static ContentViewHolder getViewHolder(View convertview) {
            ContentViewHolder holder = (ContentViewHolder) convertview.getTag();
            if (holder == null) {
                holder = new ContentViewHolder(convertview);
                convertview.setTag(holder);
            }
            return holder;
        }
    }
}
