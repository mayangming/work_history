package com.qlk.ymz.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.util.AppConfig;
import com.qlk.ymz.util.GeneralReqExceptionProcess;
import com.qlk.ymz.util.bi.BiUtil;
import com.xiaocoder.android.fw.general.adapter.XCBaseAdapter;
import com.xiaocoder.android.fw.general.base.XCBaseAbsListFragment;
import com.xiaocoder.android.fw.general.fragment.XCListViewFragment;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.jsonxml.XCJsonBean;

import org.apache.http.Header;

import java.util.List;

/**
 * 患者分组管理页
 * Created by sinki on 2015/6/17.
 *
 * update by cyr on 2016-1-7
 * @version 2.0
 * 因需求修改，此页面做了较大修改
 * */
public class YR_PatientGroupManagerActivity extends DBActivity {
    /** 病人分组list */
    private XCListViewFragment listViewFragment;
    /** 添加分组按钮 */
    private TextView tv_add_group_btn;
    /** 病人分组adapter */
    private PatientGroupAdapter patientGroupAdapter;
    /** 患者的分组key */
    public static final String GROUP_ID = "groupId";
    /** 患者分组姓名key */
    public static final String GROUP_NAME = "groupName";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.yr_activity_group_manage);
        super.onCreate(savedInstanceState);

        initTitle();
        requestPatientGroupList(true);
    }

    /** 设置title */
    public void initTitle() {
        findViewById(R.id.sx_id_title_left).setOnClickListener(this);
        ((TextView)findViewById(R.id.sx_id_title_center)).setText("分组管理");
    }

    @Override
    public void initWidgets() {
        tv_add_group_btn = (TextView) findViewById(R.id.tv_add_group_btn);
//      患者列表设置
        patientGroupAdapter = new PatientGroupAdapter(this,null);
        listViewFragment = new XCListViewFragment();
        listViewFragment.setAdapter(patientGroupAdapter);
        listViewFragment.setMode(XCListViewFragment.MODE_NOT_PULL);//设置不能上下拉
        listViewFragment.setBgZeroHintInfo("无分组信息!", "", R.mipmap.js_d_icon_no_data);//无数据遮罩
        listViewFragment.setListViewStyleParam(null, 1, false);
        addFragment(R.id.xc_id_new_patient_list, listViewFragment);
    }

    @Override
    protected void onStart() {
        super.onStart();

        listViewFragment.base_abs_listview.setDividerHeight(0);//去掉listView分割线
        listViewFragment.base_abs_listview.setOverScrollMode(View.OVER_SCROLL_NEVER);//去掉listView拉动时的边框
        /** created by songxin,date：2016-4-23,about：bi,begin */
        BiUtil.savePid(YR_PatientGroupManagerActivity.class);
        /** created by songxin,date：2016-4-23,about：bi,end */
    }

    @Override
    public void listeners() {
        tv_add_group_btn.setOnClickListener(this);

        listViewFragment.setOnListItemClickListener(new XCBaseAbsListFragment.OnAbsListItemClickListener() {
            @Override
            public void onAbsListItemClickListener(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                // 跳转到编辑分组页
                XCJsonBean xcJsonBean = (XCJsonBean) (arg0.getItemAtPosition(arg2));
                Intent intent = new Intent();
                intent.setClass(YR_PatientGroupManagerActivity.this, YR_EditPatientGroupActivity.class);
                intent.putExtra(GROUP_ID, xcJsonBean.getString("id"));
                intent.putExtra(GROUP_NAME, xcJsonBean.getString("groupName"));
                myStartActivityForResult(intent, 2);
            }
        });
    }

    @Override
    public void onNetRefresh() {
        requestPatientGroupList(true);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.tv_add_group_btn://跳到添加分组页面，此页面有从底部进入的动画效果
                myStartActivityForResult(new Intent(this,YR_AddPatientGroupActivity.class),1);
                overridePendingTransition(R.anim.activity_open_up, R.anim.activity_no_move);
                break;
            case R.id.sx_id_title_left:
                myFinish();
                break;
        }
    }

    /** 获得分组列表
     * @param isDialog 是否显示进度条
     * */
    public void  requestPatientGroupList(boolean isDialog){
        XCHttpAsyn.postAsyn(isDialog, this, AppConfig.getHostUrl(AppConfig.patient_group_list), new RequestParams(), new XCHttpResponseHandler(this) {
            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    List<XCJsonBean> result_list = result_bean.getList("data");
                    if (result_list != null) {//更新listView数据
                        listViewFragment.updateSpecialList(result_list);
                    }
                }
            }

            @Override
            public void onFinish() {
                super.onFinish();
                if(listViewFragment != null){
                    listViewFragment.doRefreshComplete();
                }
                if (null != result_bean && GeneralReqExceptionProcess.checkCode(YR_PatientGroupManagerActivity.this,
                        getCode(),
                        getMsg())) {
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //V2.5 建奎要求去掉toast
//        if (resultCode == RESULT_OK) {
//            if (requestCode == 1) {//从新建分组页添加分组操作返回
//                shortToast("添加成功");
//            } else if (requestCode == 2) {//从编辑分组页删除分组操作返回
//                shortToast("删除成功");
//            }
//        }
        requestPatientGroupList(false);
    }

    class PatientGroupAdapter extends XCBaseAdapter<XCJsonBean> {

        public PatientGroupAdapter(Context context,List<XCJsonBean> list){
            super(context, list);
        }

        class ViewHolder{
            TextView tv_group_name_num;
            View v_bottom_line;
            View v_bottom;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {
            ViewHolder holder;
            if(view == null){
                holder = new ViewHolder();
                view = LayoutInflater.from(context).inflate(R.layout.yr_item_patient_group,null);
                holder.tv_group_name_num = (TextView)view.findViewById(R.id.tv_group_name_num);
                holder.v_bottom_line = view.findViewById(R.id.v_bottom_line);
                holder.v_bottom = view.findViewById(R.id.v_bottom);
                view.setTag(holder);
            }else{
                holder = (ViewHolder) view.getTag();
            }
            holder.tv_group_name_num.setText(list.get(position).getString("groupName") + "(" + list.get(position).getInt("groupCount") + ")");
            // 设置底部分割线，如果是当前字母最后一个则隐藏,最后一个底部加一块，防止按钮挡住
            if (list.size() - 1 == position) {
                holder.v_bottom_line.setVisibility(View.GONE);
                holder.v_bottom.setVisibility(View.VISIBLE);
            } else {
                holder.v_bottom_line.setVisibility(View.VISIBLE);
                holder.v_bottom.setVisibility(View.GONE);
            }
            return view;
        }
    }

}
