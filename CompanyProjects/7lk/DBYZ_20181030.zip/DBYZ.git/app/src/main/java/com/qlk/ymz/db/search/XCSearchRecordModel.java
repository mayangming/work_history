package com.qlk.ymz.db.search;

import java.io.Serializable;

/**
 * Created by jingyu on 2015/6/22.
 *
 * @version 1.0
 * @description 搜索记录的Model
 */
public class XCSearchRecordModel implements Serializable {
    /**
     * 序列化值
     */
    public static final long serialVersionUID = 7806487539561624886L;
    /**
     * 关键词
     */
    private String key_word;
    /**
     * 时间long+""
     */
    private String time;

    @Override
    public String toString() {
        return "SearchRecordBean{" + "key_word='" + key_word + '\''
                + ", time='" + time + '\'' + '}';
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public XCSearchRecordModel(String key_word, String time) {
        this.key_word = key_word;
        this.time = time;
    }

    public String getKey_word() {
        return key_word;
    }

    public void setKey_word(String key_word) {
        this.key_word = key_word;
    }

    public XCSearchRecordModel() {
    }
}
