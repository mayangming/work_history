package com.qlk.ymz.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.loopj.android.http.RequestParams;
import com.qlk.ymz.R;
import com.qlk.ymz.base.DBActivity;
import com.qlk.ymz.model.PointInfoBean;
import com.qlk.ymz.model.UserBankBean;
import com.qlk.ymz.util.*;
import com.qlk.ymz.util.SP.GlobalConfigSP;
import com.qlk.ymz.util.bi.BiUtil;
import com.qlk.ymz.view.XCTitleCommonLayout;
import com.qlk.ymz.view.YR_CommonDialog;
import com.xiaocoder.android.fw.general.http.XCHttpAsyn;
import com.xiaocoder.android.fw.general.http.XCHttpResponseHandler;
import com.xiaocoder.android.fw.general.util.UtilViewShow;

import org.apache.http.Header;

/**
 * @version 2.0
 * @Created by xilinch on 2016/1/15.
 * @description 申请提现
 *
 * @version 2.3
 * @author 马杨茗 2016-4-18
 * @description 1、接收积分页面传递过来的 积分信息
 *              2、对传递的积分信息进行处理
 *
 * @version 2.3
 * @author cyr 2016-4-27
 * @description 修改部分bug
 *
 * TODO update by cyr on 2017-1-9 修改PointInfoBean结构，及parse解析方式
 */
public class XL_ApplyCashBackActivityV2 extends DBActivity {

    /** titlebar */
    private XCTitleCommonLayout titlebar;
    // ********************控件********************
    /** 选择银行卡布局 */
    private LinearLayout xl_applycashback_ll_selectcard;
    /** 申请提现银行卡 */
    private TextView xl_applycashback_card;
    /** 可提现金额 */
    private TextView xl_applycashback_mentionMon;
    /** 立即去完善 确认对话框 */
    private YR_CommonDialog mConfirmDialog;
    /** 确认对话框的视图 */
    private View dialog_layout;
    // ********************控件 end ********************
    // ********************变量********************
    /** 获取用户积分信息 */
    private PointInfoBean dataEntity ;
    /** 提现到哪张银行卡 */
    private UserBankBean bankCardEntity;
    /** 可提现金额 */
    private long canMentionMon_float = 0l;
    // ********************常量********************
    /** 选择我的银行卡列表requestCode */
    public static int REQUEST_CODE_BANK = 1000;
    /** 编辑银行卡的requestCode */
    public static int REQUEST_CODE_EDITBANK = 1001;
    /** 银行key */
    public static final String BANK = "bank";
    /** 获取最大提现金额 */
    private String cashMoney = "";
    /** 获取银行卡账号 */
    private String bankName = "";
    /** 获取银行卡后四位账号 */
    private String shortNum = "";
    /** 2.3版本 请求错误码
     * 当请求提现接口时：进入请求页面前，医生为非步长医生；请求时医生变为了步长医生，此处返回特定状态码，做提现异常处理 */
    public static String DOCTOR_STATUS_CHANGES = "30558";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.xl_activity_applycashback);
        super.onCreate(savedInstanceState);
    }

    /** created by songxin,date：2016-4-23,about：bi,begin */
    @Override
    protected void onStart() {
        super.onStart();
        BiUtil.savePid(XL_ApplyCashBackActivityV2.class);
    }
    /** created by songxin,date：2016-4-23,about：bi,end */

    @Override
    public void initWidgets() {
        titlebar = getViewById(R.id.xc_id_model_titlebar);
        titlebar.setTitleCenter(true, "申请提现");
        titlebar.setTitleLeft(true, "");
        titlebar.setTitleRight2(true, 0, "提交申请");
        titlebar.getXc_id_titlebar_left_imageview().setImageResource(R.mipmap.xc_d_chat_back);
        titlebar.getXc_id_titlebar_right2_textview().setTextColor(getResources().getColor(R.color.c_7b7b7b));
        titlebar.getXc_id_titlebar_center_textview().setTextColor(getResources().getColor(R.color.c_444444));
        xl_applycashback_ll_selectcard = getViewById(R.id.xl_applycashback_ll_selectcard);
        xl_applycashback_card = getViewById(R.id.xl_applycashback_card);
        xl_applycashback_mentionMon = getViewById(R.id.xl_applycashback_mentionMon);
        getIntentData();
        setData();
    }

    /** 获取上个页面跳转过来的数据 */
    private void getIntentData(){
        dataEntity = getIntent().getParcelableExtra(XL_PointsActivityV2.POINT_INFO);
        if(dataEntity != null) {
            try{
                canMentionMon_float = Long.parseLong(dataEntity.canMentionMon);
            }catch (Exception e){
                canMentionMon_float = 0;
                e.getStackTrace();
            }
            cashMoney =  StringUtils.getMoneyString(canMentionMon_float);

            if (dataEntity.userBankBean != null) {
                bankCardEntity = dataEntity.userBankBean;
                bankName = bankCardEntity.bankName;
                shortNum = bankCardEntity.shortNum;
            }
        }
    }

    /** 为页面控件设置值 */
    private void setData(){
        if (TextUtils.isEmpty(bankName) || TextUtils.isEmpty(shortNum)) {
            xl_applycashback_card.setText("请选择银行");
        } else {
            xl_applycashback_card.setText(bankName + "(" + shortNum + ")");
        }
        if(TextUtils.isEmpty(cashMoney)){
            cashMoney = "0";
        }
        xl_applycashback_mentionMon.setText(AppConfig.renminbi + cashMoney);
    }

    @Override
    public void listeners() {
        xl_applycashback_ll_selectcard.setOnClickListener(this);
        titlebar.getXc_id_titlebar_left_imageview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFinish();
            }
        });
        titlebar.getXc_id_titlebar_right2_textview().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValid()) {
                    requestData();
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.xl_applycashback_ll_selectcard:
                String[] key = new String[]{"flag", "zeroTextHint"};
                String[] ob = new String[]{"1", "申请提现需先添加银行卡"};
                myStartActivityForResult(YY_EditBankCardActivityV2.class, REQUEST_CODE_BANK, key, ob);
                break;
        }
    }

    /**
     * 显示没有开户行信息提示对话框
     */
    private void showNoBranchDialog() {
        if (mConfirmDialog == null) {
            mConfirmDialog = new YR_CommonDialog(XL_ApplyCashBackActivityV2.this,
                    "需补充当前银行卡的开户信息才可以成功提现哦~", "","立即去完善") {
                @Override
                public void confirmBtn() {
                    if (bankCardEntity != null) {
                        Intent intent = new Intent(XL_ApplyCashBackActivityV2.this, XL_ModifyBankActivity.class);
                        intent.putExtra(XL_ModifyBankActivity.BANKBEAN, bankCardEntity);
                        myStartActivityForResult(intent, REQUEST_CODE_EDITBANK);
                    } else {
                        shortToast("请选择银行卡");
                    }
                    mConfirmDialog.dismiss();
                }
            };
            mConfirmDialog.setCanceledOnTouchOutside(true);
        }
        mConfirmDialog.show();
    }

    /**
     * 判断提交是否合法
     *
     * @return true合法，false非法，默认非法
     */
    private boolean isValid() {
        boolean isValid = false;
        if (dataEntity != null) {
            if ("0".equals(dataEntity.openApply)) {
                shortToast("对不起，暂时没有开放提现申请！");
            } else if (bankCardEntity == null || TextUtils.isEmpty(bankName) || TextUtils.isEmpty(shortNum)) {
                shortToast("请先选择您要提现的银行卡！");
            } else if (canMentionMon_float <= 0) {
                shortToast("对不起，您当前可提现金额为0！");
            } else {
                if (TextUtils.isEmpty(bankCardEntity.branch)) {//无银行卡支行信息
                    showNoBranchDialog();
                } else {//银行卡信息全
                    isValid = true;
                }
            }
        }
        return isValid;
    }

    @Override
    public void onNetRefresh() {
    }

    /** 申请提现请求 */
    private void requestData() {
        RequestParams params = new RequestParams();
        params.put("mentionMon", canMentionMon_float);
        params.put("bankCardId", bankCardEntity.userBankId);

        XCHttpAsyn.getAsyn(this, AppConfig.getHostUrl(AppConfig.applyCash), params, new XCHttpResponseHandler() {

            @Override
            public void onSuccess(int code, Header[] headers, byte[] arg2) {
                super.onSuccess(code, headers, arg2);
                if (result_boolean) {
                    shortToast("恭喜您申请提现 ¥" + StringUtils.getMoneyString(canMentionMon_float) + "成功，请等待审核！");
                    XL_ApplyCashBackActivityV2.this.finish();
                }
            }

            // 对账户冻结情况的判断处理
            public void onFinish() {
                super.onFinish();
                if (null != result_bean) {
                    String  code = getCode();
                    String msg = getMsg();
                    if (DOCTOR_STATUS_CHANGES.equals(code)) {
                        initDrawDialog(msg);
                        return;
                    }
                    if ( GeneralReqExceptionProcess.checkCode(XL_ApplyCashBackActivityV2.this,
                            code,
                            msg)) {
                        // 接口请求业务成功时的处理
                    }
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (RESULT_OK == resultCode) {
            if (REQUEST_CODE_BANK == requestCode) {
                //选择银行返回时，带回来选择的银行卡信息要做非空处理。
                // 在界面上需要更新，如果没有支行信息则需要弹出提示框
                // 同时如果涉及到在编辑银行卡页面删除过银行卡，则还需要刷新接口数据，防止数据过期。
                setBankInfo(data);

                // TODO 需要修改
                String isDeleted = data.getStringExtra("isDeleted");

                if ("1".equals(isDeleted)) {
                    //如果删除过数据，则需要刷新接口
//                        requestMyWalletData();
                    bankName = "";
                    shortNum = "";
                    setData();
                }
            } else if (REQUEST_CODE_EDITBANK == requestCode) {
                //刷新银行卡信息，编辑银行卡以后，对带回来的银行卡数据做非空处理，如果没有支行信息则需要弹出提示框
                setBankInfo(data);
            }
        }
    }

    /**
     * 从编辑银行卡或选择银行卡页面返回时，重置银行卡信息
     * @param data 页面返回携带的数据
     * */
    public void setBankInfo(Intent data) {
        if (data != null && data.getParcelableExtra(BANK) != null) {
            bankCardEntity = data.getParcelableExtra(BANK);
            bankName = TextUtils.isEmpty(bankCardEntity.bankName)?"":bankCardEntity.bankName;
            try {
                if (Long.parseLong(bankCardEntity.userBankId) <= 0 || TextUtils.isEmpty(bankCardEntity.shortNum)) {
                    shortToast("银行卡信息有误");
                    return;
                }
            } catch (Exception e) {
               e.getStackTrace();
            }
            shortNum = bankCardEntity.shortNum;
            xl_applycashback_card.setText(bankName + "(" + shortNum + ")");
            if (TextUtils.isEmpty(bankCardEntity.branch)) {
                showNoBranchDialog();
            }
        } else {
            xl_applycashback_card.setText("请选择银行");
        }
    }

    /** 设置 */
    private YR_CommonDialog mExitDialog;

    /** 2.3添加功能：提现过程中非步长医生转为非步长医生，需要弹出提现错误提示
     * @param msg 错误提示信息
     * */
    public void initDrawDialog(String msg) {
        //设置只有客服号码能点击
        String msgStr = msg + "\n请联系客服解决：";
        SpannableString spannableString1 = new SpannableString(msgStr + GlobalConfigSP.getCustomerServPhone());
        spannableString1.setSpan(new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Uri uri = Uri.parse("tel:" + GlobalConfigSP.getCustomerServPhone());
                Intent intent2 = new Intent(Intent.ACTION_DIAL, uri);
                myStartActivity(intent2);
            }
        },msgStr.length(),spannableString1.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        if (mExitDialog == null) {
            mExitDialog = new YR_CommonDialog(XL_ApplyCashBackActivityV2.this,
                    spannableString1, "","知道了") {
                @Override
                public void confirmBtn() {
                    mExitDialog.dismiss();
                    setResult(RESULT_OK);
                    XL_ApplyCashBackActivityV2.this.finish();

                }
            };
            mExitDialog.setCanceledOnTouchOutside(true);
            if (mExitDialog.tv_rightBtn != null) {
                mExitDialog.tv_content.setMovementMethod(LinkMovementMethod.getInstance());//关联客服电话点击事件，必须加
            }
        }
        mExitDialog.show();
    }

    @Override
    protected void onDestroy() {
        UtilViewShow.destoryDialogs(mExitDialog, mConfirmDialog);
        super.onDestroy();
    }
}
